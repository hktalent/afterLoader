/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.LogFactory;
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.log.NullLogger;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.util.LRUCache;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLPermission;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionImpl
/*      */   extends ConnectionPropertiesImpl
/*      */   implements MySQLConnection
/*      */ {
/*      */   private static final long serialVersionUID = 2877471301981509474L;
/*   82 */   private static final SQLPermission SET_NETWORK_TIMEOUT_PERM = new SQLPermission("setNetworkTimeout");
/*      */   
/*   84 */   private static final SQLPermission ABORT_PERM = new SQLPermission("abort");
/*      */   public static final String JDBC_LOCAL_CHARACTER_SET_RESULTS = "jdbc.local.character_set_results";
/*      */   
/*      */   public String getHost()
/*      */   {
/*   89 */     return this.host;
/*      */   }
/*      */   
/*   92 */   private MySQLConnection proxy = null;
/*      */   
/*   94 */   private InvocationHandler realProxy = null;
/*      */   
/*      */   public boolean isProxySet() {
/*   97 */     return this.proxy != null;
/*      */   }
/*      */   
/*      */   public void setProxy(MySQLConnection proxy) {
/*  101 */     this.proxy = proxy;
/*      */   }
/*      */   
/*      */   public void setRealProxy(InvocationHandler proxy) {
/*  105 */     this.realProxy = proxy;
/*      */   }
/*      */   
/*      */ 
/*      */   private MySQLConnection getProxy()
/*      */   {
/*  111 */     return this.proxy != null ? this.proxy : this;
/*      */   }
/*      */   
/*      */   public MySQLConnection getLoadBalanceSafeProxy() {
/*  115 */     return getMultiHostSafeProxy();
/*      */   }
/*      */   
/*      */   public MySQLConnection getMultiHostSafeProxy() {
/*  119 */     return getProxy();
/*      */   }
/*      */   
/*      */   public Object getConnectionMutex() {
/*  123 */     return this.realProxy != null ? this.realProxy : this;
/*      */   }
/*      */   
/*      */   class ExceptionInterceptorChain implements ExceptionInterceptor {
/*      */     List<Extension> interceptors;
/*      */     
/*      */     ExceptionInterceptorChain(String interceptorClasses) throws SQLException {
/*  130 */       this.interceptors = Util.loadExtensions(ConnectionImpl.this, ConnectionImpl.this.props, interceptorClasses, "Connection.BadExceptionInterceptor", this);
/*      */     }
/*      */     
/*      */     void addRingZero(ExceptionInterceptor interceptor) throws SQLException
/*      */     {
/*  135 */       this.interceptors.add(0, interceptor);
/*      */     }
/*      */     
/*      */     public SQLException interceptException(SQLException sqlEx, Connection conn) {
/*  139 */       if (this.interceptors != null) {
/*  140 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  142 */         while (iter.hasNext()) {
/*  143 */           sqlEx = ((ExceptionInterceptor)iter.next()).interceptException(sqlEx, ConnectionImpl.this);
/*      */         }
/*      */       }
/*      */       
/*  147 */       return sqlEx;
/*      */     }
/*      */     
/*      */     public void destroy() {
/*  151 */       if (this.interceptors != null) {
/*  152 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  154 */         while (iter.hasNext()) {
/*  155 */           ((ExceptionInterceptor)iter.next()).destroy();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void init(Connection conn, Properties properties) throws SQLException
/*      */     {
/*  162 */       if (this.interceptors != null) {
/*  163 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  165 */         while (iter.hasNext()) {
/*  166 */           ((ExceptionInterceptor)iter.next()).init(conn, properties);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static class CompoundCacheKey
/*      */   {
/*      */     String componentOne;
/*      */     
/*      */     String componentTwo;
/*      */     
/*      */     int hashCode;
/*      */     
/*      */ 
/*      */     CompoundCacheKey(String partOne, String partTwo)
/*      */     {
/*  185 */       this.componentOne = partOne;
/*  186 */       this.componentTwo = partTwo;
/*      */       
/*      */ 
/*  189 */       this.hashCode = ((this.componentOne != null ? this.componentOne : "") + this.componentTwo).hashCode();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/*  199 */       if ((obj instanceof CompoundCacheKey)) {
/*  200 */         CompoundCacheKey another = (CompoundCacheKey)obj;
/*      */         
/*  202 */         boolean firstPartEqual = false;
/*      */         
/*  204 */         if (this.componentOne == null) {
/*  205 */           firstPartEqual = another.componentOne == null;
/*      */         } else {
/*  207 */           firstPartEqual = this.componentOne.equals(another.componentOne);
/*      */         }
/*      */         
/*  210 */         return (firstPartEqual) && (this.componentTwo.equals(another.componentTwo));
/*      */       }
/*      */       
/*  213 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int hashCode()
/*      */     {
/*  223 */       return this.hashCode;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  231 */   private static final Object CHARSET_CONVERTER_NOT_AVAILABLE_MARKER = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */   public static Map<?, ?> charsetMap;
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final String DEFAULT_LOGGER_CLASS = "com.mysql.jdbc.log.StandardLogger";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int HISTOGRAM_BUCKETS = 20;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String LOGGER_INSTANCE_NAME = "MySQL";
/*      */   
/*      */ 
/*      */ 
/*  251 */   private static Map<String, Integer> mapTransIsolationNameToValue = null;
/*      */   
/*      */ 
/*  254 */   private static final Log NULL_LOGGER = new NullLogger("MySQL");
/*      */   
/*      */ 
/*      */ 
/*      */   protected static Map<?, ?> roundRobinStatsMap;
/*      */   
/*      */ 
/*  261 */   private static final Map<String, Map<Long, String>> dynamicIndexToCollationMapByUrl = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  266 */   private static final Map<String, Map<Integer, String>> dynamicIndexToCharsetMapByUrl = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  271 */   private static final Map<String, Map<Integer, String>> customIndexToCharsetMapByUrl = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  276 */   private static final Map<String, Map<String, Integer>> customCharsetToMblenMapByUrl = new HashMap();
/*      */   
/*      */   private CacheAdapter<String, Map<String, String>> serverConfigCache;
/*      */   
/*      */   private long queryTimeCount;
/*      */   
/*      */   private double queryTimeSum;
/*      */   
/*      */   private double queryTimeSumSquares;
/*      */   
/*      */   private double queryTimeMean;
/*      */   
/*      */   private transient Timer cancelTimer;
/*      */   private List<Extension> connectionLifecycleInterceptors;
/*      */   private static final Constructor<?> JDBC_4_CONNECTION_CTOR;
/*      */   private static final int DEFAULT_RESULT_SET_TYPE = 1003;
/*      */   private static final int DEFAULT_RESULT_SET_CONCURRENCY = 1007;
/*      */   
/*      */   static
/*      */   {
/*  296 */     mapTransIsolationNameToValue = new HashMap(8);
/*  297 */     mapTransIsolationNameToValue.put("READ-UNCOMMITED", Integer.valueOf(1));
/*  298 */     mapTransIsolationNameToValue.put("READ-UNCOMMITTED", Integer.valueOf(1));
/*  299 */     mapTransIsolationNameToValue.put("READ-COMMITTED", Integer.valueOf(2));
/*  300 */     mapTransIsolationNameToValue.put("REPEATABLE-READ", Integer.valueOf(4));
/*  301 */     mapTransIsolationNameToValue.put("SERIALIZABLE", Integer.valueOf(8));
/*      */     
/*  303 */     if (Util.isJdbc4()) {
/*      */       try {
/*  305 */         JDBC_4_CONNECTION_CTOR = Class.forName("com.mysql.jdbc.JDBC4Connection").getConstructor(new Class[] { String.class, Integer.TYPE, Properties.class, String.class, String.class });
/*      */       }
/*      */       catch (SecurityException e) {
/*  308 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  310 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  312 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  315 */       JDBC_4_CONNECTION_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static SQLException appendMessageToException(SQLException sqlEx, String messageToAppend, ExceptionInterceptor interceptor) {
/*  320 */     String origMessage = sqlEx.getMessage();
/*  321 */     String sqlState = sqlEx.getSQLState();
/*  322 */     int vendorErrorCode = sqlEx.getErrorCode();
/*      */     
/*  324 */     StringBuilder messageBuf = new StringBuilder(origMessage.length() + messageToAppend.length());
/*  325 */     messageBuf.append(origMessage);
/*  326 */     messageBuf.append(messageToAppend);
/*      */     
/*  328 */     SQLException sqlExceptionWithNewMessage = SQLError.createSQLException(messageBuf.toString(), sqlState, vendorErrorCode, interceptor);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  336 */       Method getStackTraceMethod = null;
/*  337 */       Method setStackTraceMethod = null;
/*  338 */       Object theStackTraceAsObject = null;
/*      */       
/*  340 */       Class<?> stackTraceElementClass = Class.forName("java.lang.StackTraceElement");
/*  341 */       Class<?> stackTraceElementArrayClass = Array.newInstance(stackTraceElementClass, new int[] { 0 }).getClass();
/*      */       
/*  343 */       getStackTraceMethod = Throwable.class.getMethod("getStackTrace", new Class[0]);
/*      */       
/*  345 */       setStackTraceMethod = Throwable.class.getMethod("setStackTrace", new Class[] { stackTraceElementArrayClass });
/*      */       
/*  347 */       if ((getStackTraceMethod != null) && (setStackTraceMethod != null)) {
/*  348 */         theStackTraceAsObject = getStackTraceMethod.invoke(sqlEx, new Object[0]);
/*  349 */         setStackTraceMethod.invoke(sqlExceptionWithNewMessage, new Object[] { theStackTraceAsObject });
/*      */       }
/*      */     }
/*      */     catch (NoClassDefFoundError noClassDefFound) {}catch (NoSuchMethodException noSuchMethodEx) {}catch (Throwable catchAll) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  359 */     return sqlExceptionWithNewMessage;
/*      */   }
/*      */   
/*      */   public Timer getCancelTimer() {
/*  363 */     synchronized (getConnectionMutex()) {
/*  364 */       if (this.cancelTimer == null) {
/*  365 */         boolean createdNamedTimer = false;
/*      */         
/*      */         try
/*      */         {
/*  369 */           Constructor<Timer> ctr = Timer.class.getConstructor(new Class[] { String.class, Boolean.TYPE });
/*      */           
/*  371 */           this.cancelTimer = ((Timer)ctr.newInstance(new Object[] { "MySQL Statement Cancellation Timer", Boolean.TRUE }));
/*  372 */           createdNamedTimer = true;
/*      */         } catch (Throwable t) {
/*  374 */           createdNamedTimer = false;
/*      */         }
/*      */         
/*  377 */         if (!createdNamedTimer) {
/*  378 */           this.cancelTimer = new Timer(true);
/*      */         }
/*      */       }
/*      */       
/*  382 */       return this.cancelTimer;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static Connection getInstance(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url)
/*      */     throws SQLException
/*      */   {
/*  395 */     if (!Util.isJdbc4()) {
/*  396 */       return new ConnectionImpl(hostToConnectTo, portToConnectTo, info, databaseToConnectTo, url);
/*      */     }
/*      */     
/*  399 */     return (Connection)Util.handleNewInstance(JDBC_4_CONNECTION_CTOR, new Object[] { hostToConnectTo, Integer.valueOf(portToConnectTo), info, databaseToConnectTo, url }, null);
/*      */   }
/*      */   
/*      */ 
/*  403 */   private static final Random random = new Random();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static synchronized int getNextRoundRobinHostIndex(String url, List<?> hostList)
/*      */   {
/*  412 */     int indexRange = hostList.size();
/*      */     
/*  414 */     int index = random.nextInt(indexRange);
/*      */     
/*  416 */     return index;
/*      */   }
/*      */   
/*      */   private static boolean nullSafeCompare(String s1, String s2) {
/*  420 */     if ((s1 == null) && (s2 == null)) {
/*  421 */       return true;
/*      */     }
/*      */     
/*  424 */     if ((s1 == null) && (s2 != null)) {
/*  425 */       return false;
/*      */     }
/*      */     
/*  428 */     return (s1 != null) && (s1.equals(s2));
/*      */   }
/*      */   
/*      */ 
/*  432 */   private boolean autoCommit = true;
/*      */   
/*      */ 
/*      */ 
/*      */   private CacheAdapter<String, PreparedStatement.ParseInfo> cachedPreparedStatementParams;
/*      */   
/*      */ 
/*      */ 
/*  440 */   private String characterSetMetadata = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  446 */   private String characterSetResultsOnServer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  453 */   private Map<String, Object> charsetConverterMap = new HashMap(CharsetMapping.getNumberOfCharsetsConfigured());
/*      */   
/*      */ 
/*  456 */   private long connectionCreationTimeMillis = 0L;
/*      */   
/*      */ 
/*      */   private long connectionId;
/*      */   
/*      */ 
/*  462 */   private String database = null;
/*      */   
/*      */ 
/*  465 */   private java.sql.DatabaseMetaData dbmd = null;
/*      */   
/*      */ 
/*      */   private TimeZone defaultTimeZone;
/*      */   
/*      */ 
/*      */   private ProfilerEventHandler eventSink;
/*      */   
/*      */ 
/*      */   private Throwable forceClosedReason;
/*      */   
/*  476 */   private boolean hasIsolationLevels = false;
/*      */   
/*      */ 
/*  479 */   private boolean hasQuotedIdentifiers = false;
/*      */   
/*      */ 
/*  482 */   private String host = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  488 */   public Map<Integer, String> indexToMysqlCharset = new HashMap();
/*      */   
/*  490 */   public Map<Integer, String> indexToCustomMysqlCharset = null;
/*      */   
/*  492 */   private Map<String, Integer> mysqlCharsetToCustomMblen = null;
/*      */   
/*      */ 
/*  495 */   private transient MysqlIO io = null;
/*      */   
/*  497 */   private boolean isClientTzUTC = false;
/*      */   
/*      */ 
/*  500 */   private boolean isClosed = true;
/*      */   
/*      */ 
/*  503 */   private boolean isInGlobalTx = false;
/*      */   
/*      */ 
/*  506 */   private boolean isRunningOnJDK13 = false;
/*      */   
/*      */ 
/*  509 */   private int isolationLevel = 2;
/*      */   
/*  511 */   private boolean isServerTzUTC = false;
/*      */   
/*      */ 
/*  514 */   private long lastQueryFinishedTime = 0L;
/*      */   
/*      */ 
/*  517 */   private transient Log log = NULL_LOGGER;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  523 */   private long longestQueryTimeMs = 0L;
/*      */   
/*      */ 
/*  526 */   private boolean lowerCaseTableNames = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  531 */   private long maximumNumberTablesAccessed = 0L;
/*      */   
/*      */ 
/*  534 */   private int sessionMaxRows = -1;
/*      */   
/*      */ 
/*      */   private long metricsLastReportedMs;
/*      */   
/*  539 */   private long minimumNumberTablesAccessed = Long.MAX_VALUE;
/*      */   
/*      */ 
/*  542 */   private String myURL = null;
/*      */   
/*      */ 
/*  545 */   private boolean needsPing = false;
/*      */   
/*  547 */   private int netBufferLength = 16384;
/*      */   
/*  549 */   private boolean noBackslashEscapes = false;
/*      */   
/*  551 */   private long numberOfPreparedExecutes = 0L;
/*      */   
/*  553 */   private long numberOfPrepares = 0L;
/*      */   
/*  555 */   private long numberOfQueriesIssued = 0L;
/*      */   
/*  557 */   private long numberOfResultSetsCreated = 0L;
/*      */   
/*      */   private long[] numTablesMetricsHistBreakpoints;
/*      */   
/*      */   private int[] numTablesMetricsHistCounts;
/*      */   
/*  563 */   private long[] oldHistBreakpoints = null;
/*      */   
/*  565 */   private int[] oldHistCounts = null;
/*      */   
/*      */ 
/*      */   private Map<Statement, Statement> openStatements;
/*      */   
/*      */   private LRUCache parsedCallableStatementCache;
/*      */   
/*  572 */   private boolean parserKnowsUnicode = false;
/*      */   
/*      */ 
/*  575 */   private String password = null;
/*      */   
/*      */ 
/*      */   private long[] perfMetricsHistBreakpoints;
/*      */   
/*      */ 
/*      */   private int[] perfMetricsHistCounts;
/*      */   
/*      */   private String pointOfOrigin;
/*      */   
/*  585 */   private int port = 3306;
/*      */   
/*      */ 
/*  588 */   protected Properties props = null;
/*      */   
/*      */ 
/*  591 */   private boolean readInfoMsg = false;
/*      */   
/*      */ 
/*  594 */   private boolean readOnly = false;
/*      */   
/*      */ 
/*      */   protected LRUCache resultSetMetadataCache;
/*      */   
/*      */ 
/*  600 */   private TimeZone serverTimezoneTZ = null;
/*      */   
/*      */ 
/*  603 */   private Map<String, String> serverVariables = null;
/*      */   
/*  605 */   private long shortestQueryTimeMs = Long.MAX_VALUE;
/*      */   
/*  607 */   private double totalQueryTimeMs = 0.0D;
/*      */   
/*      */ 
/*  610 */   private boolean transactionsSupported = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Map<String, Class<?>> typeMap;
/*      */   
/*      */ 
/*      */ 
/*  619 */   private boolean useAnsiQuotes = false;
/*      */   
/*      */ 
/*  622 */   private String user = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  628 */   private boolean useServerPreparedStmts = false;
/*      */   
/*      */   private LRUCache serverSideStatementCheckCache;
/*      */   
/*      */   private LRUCache serverSideStatementCache;
/*      */   
/*      */   private Calendar sessionCalendar;
/*      */   
/*      */   private Calendar utcCalendar;
/*      */   
/*      */   private String origHostToConnectTo;
/*      */   
/*      */   private int origPortToConnectTo;
/*      */   
/*      */   private String origDatabaseToConnectTo;
/*      */   
/*  644 */   private String errorMessageEncoding = "Cp1252";
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean usePlatformCharsetConverters;
/*      */   
/*      */ 
/*  651 */   private boolean hasTriedMasterFlag = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  657 */   private String statementComment = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean storesLowerCaseTableName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<StatementInterceptorV2> statementInterceptors;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean requiresEscapingEncoder;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String hostPortPair;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConnectionImpl(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url)
/*      */     throws SQLException
/*      */   {
/*  698 */     this.connectionCreationTimeMillis = System.currentTimeMillis();
/*      */     
/*  700 */     if (databaseToConnectTo == null) {
/*  701 */       databaseToConnectTo = "";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  707 */     this.origHostToConnectTo = hostToConnectTo;
/*  708 */     this.origPortToConnectTo = portToConnectTo;
/*  709 */     this.origDatabaseToConnectTo = databaseToConnectTo;
/*      */     try
/*      */     {
/*  712 */       Blob.class.getMethod("truncate", new Class[] { Long.TYPE });
/*      */       
/*  714 */       this.isRunningOnJDK13 = false;
/*      */     } catch (NoSuchMethodException nsme) {
/*  716 */       this.isRunningOnJDK13 = true;
/*      */     }
/*      */     
/*  719 */     this.sessionCalendar = new GregorianCalendar();
/*  720 */     this.utcCalendar = new GregorianCalendar();
/*  721 */     this.utcCalendar.setTimeZone(TimeZone.getTimeZone("GMT"));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  730 */     this.log = LogFactory.getLogger(getLogger(), "MySQL", getExceptionInterceptor());
/*      */     
/*  732 */     this.openStatements = new HashMap();
/*      */     
/*  734 */     if (NonRegisteringDriver.isHostPropertiesList(hostToConnectTo)) {
/*  735 */       Properties hostSpecificProps = NonRegisteringDriver.expandHostKeyValues(hostToConnectTo);
/*      */       
/*  737 */       Enumeration<?> propertyNames = hostSpecificProps.propertyNames();
/*      */       
/*  739 */       while (propertyNames.hasMoreElements()) {
/*  740 */         String propertyName = propertyNames.nextElement().toString();
/*  741 */         String propertyValue = hostSpecificProps.getProperty(propertyName);
/*      */         
/*  743 */         info.setProperty(propertyName, propertyValue);
/*      */       }
/*      */       
/*      */     }
/*  747 */     else if (hostToConnectTo == null) {
/*  748 */       this.host = "localhost";
/*  749 */       this.hostPortPair = (this.host + ":" + portToConnectTo);
/*      */     } else {
/*  751 */       this.host = hostToConnectTo;
/*      */       
/*  753 */       if (hostToConnectTo.indexOf(":") == -1) {
/*  754 */         this.hostPortPair = (this.host + ":" + portToConnectTo);
/*      */       } else {
/*  756 */         this.hostPortPair = this.host;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  761 */     this.port = portToConnectTo;
/*      */     
/*  763 */     this.database = databaseToConnectTo;
/*  764 */     this.myURL = url;
/*  765 */     this.user = info.getProperty("user");
/*  766 */     this.password = info.getProperty("password");
/*      */     
/*  768 */     if ((this.user == null) || (this.user.equals(""))) {
/*  769 */       this.user = "";
/*      */     }
/*      */     
/*  772 */     if (this.password == null) {
/*  773 */       this.password = "";
/*      */     }
/*      */     
/*  776 */     this.props = info;
/*      */     
/*  778 */     initializeDriverProperties(info);
/*      */     
/*      */ 
/*  781 */     this.defaultTimeZone = TimeUtil.getDefaultTimeZone(getCacheDefaultTimezone());
/*      */     
/*  783 */     this.isClientTzUTC = "GMT".equalsIgnoreCase(this.defaultTimeZone.getID());
/*      */     
/*  785 */     if (getUseUsageAdvisor()) {
/*  786 */       this.pointOfOrigin = LogUtils.findCallingClassAndMethod(new Throwable());
/*      */     } else {
/*  788 */       this.pointOfOrigin = "";
/*      */     }
/*      */     try
/*      */     {
/*  792 */       this.dbmd = getMetaData(false, false);
/*  793 */       initializeSafeStatementInterceptors();
/*  794 */       createNewIO(false);
/*  795 */       unSafeStatementInterceptors();
/*      */     } catch (SQLException ex) {
/*  797 */       cleanup(ex);
/*      */       
/*      */ 
/*  800 */       throw ex;
/*      */     } catch (Exception ex) {
/*  802 */       cleanup(ex);
/*      */       
/*  804 */       StringBuilder mesg = new StringBuilder(128);
/*      */       
/*  806 */       if (!getParanoid()) {
/*  807 */         mesg.append("Cannot connect to MySQL server on ");
/*  808 */         mesg.append(this.host);
/*  809 */         mesg.append(":");
/*  810 */         mesg.append(this.port);
/*  811 */         mesg.append(".\n\n");
/*  812 */         mesg.append("Make sure that there is a MySQL server ");
/*  813 */         mesg.append("running on the machine/port you are trying ");
/*  814 */         mesg.append("to connect to and that the machine this software is running on ");
/*  815 */         mesg.append("is able to connect to this host/port (i.e. not firewalled). ");
/*  816 */         mesg.append("Also make sure that the server has not been started with the --skip-networking ");
/*  817 */         mesg.append("flag.\n\n");
/*      */       } else {
/*  819 */         mesg.append("Unable to connect to database.");
/*      */       }
/*      */       
/*  822 */       SQLException sqlEx = SQLError.createSQLException(mesg.toString(), "08S01", getExceptionInterceptor());
/*      */       
/*  824 */       sqlEx.initCause(ex);
/*      */       
/*  826 */       throw sqlEx;
/*      */     }
/*      */     
/*  829 */     NonRegisteringDriver.trackConnection(this);
/*      */   }
/*      */   
/*      */   public void unSafeStatementInterceptors() throws SQLException
/*      */   {
/*  834 */     ArrayList<StatementInterceptorV2> unSafedStatementInterceptors = new ArrayList(this.statementInterceptors.size());
/*      */     
/*  836 */     for (int i = 0; i < this.statementInterceptors.size(); i++) {
/*  837 */       NoSubInterceptorWrapper wrappedInterceptor = (NoSubInterceptorWrapper)this.statementInterceptors.get(i);
/*      */       
/*  839 */       unSafedStatementInterceptors.add(wrappedInterceptor.getUnderlyingInterceptor());
/*      */     }
/*      */     
/*  842 */     this.statementInterceptors = unSafedStatementInterceptors;
/*      */     
/*  844 */     if (this.io != null) {
/*  845 */       this.io.setStatementInterceptors(this.statementInterceptors);
/*      */     }
/*      */   }
/*      */   
/*      */   public void initializeSafeStatementInterceptors() throws SQLException {
/*  850 */     this.isClosed = false;
/*      */     
/*  852 */     List<Extension> unwrappedInterceptors = Util.loadExtensions(this, this.props, getStatementInterceptors(), "MysqlIo.BadStatementInterceptor", getExceptionInterceptor());
/*      */     
/*      */ 
/*  855 */     this.statementInterceptors = new ArrayList(unwrappedInterceptors.size());
/*      */     
/*  857 */     for (int i = 0; i < unwrappedInterceptors.size(); i++) {
/*  858 */       Extension interceptor = (Extension)unwrappedInterceptors.get(i);
/*      */       
/*      */ 
/*  861 */       if ((interceptor instanceof StatementInterceptor)) {
/*  862 */         if (ReflectiveStatementInterceptorAdapter.getV2PostProcessMethod(interceptor.getClass()) != null) {
/*  863 */           this.statementInterceptors.add(new NoSubInterceptorWrapper(new ReflectiveStatementInterceptorAdapter((StatementInterceptor)interceptor)));
/*      */         } else {
/*  865 */           this.statementInterceptors.add(new NoSubInterceptorWrapper(new V1toV2StatementInterceptorAdapter((StatementInterceptor)interceptor)));
/*      */         }
/*      */       } else {
/*  868 */         this.statementInterceptors.add(new NoSubInterceptorWrapper((StatementInterceptorV2)interceptor));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public List<StatementInterceptorV2> getStatementInterceptorsInstances()
/*      */   {
/*  875 */     return this.statementInterceptors;
/*      */   }
/*      */   
/*      */   private void addToHistogram(int[] histogramCounts, long[] histogramBreakpoints, long value, int numberOfTimes, long currentLowerBound, long currentUpperBound)
/*      */   {
/*  880 */     if (histogramCounts == null) {
/*  881 */       createInitialHistogram(histogramBreakpoints, currentLowerBound, currentUpperBound);
/*      */     } else {
/*  883 */       for (int i = 0; i < 20; i++) {
/*  884 */         if (histogramBreakpoints[i] >= value) {
/*  885 */           histogramCounts[i] += numberOfTimes;
/*      */           
/*  887 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void addToPerformanceHistogram(long value, int numberOfTimes) {
/*  894 */     checkAndCreatePerformanceHistogram();
/*      */     
/*  896 */     addToHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, value, numberOfTimes, this.shortestQueryTimeMs == Long.MAX_VALUE ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */   
/*      */   private void addToTablesAccessedHistogram(long value, int numberOfTimes)
/*      */   {
/*  901 */     checkAndCreateTablesAccessedHistogram();
/*      */     
/*  903 */     addToHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, value, numberOfTimes, this.minimumNumberTablesAccessed == Long.MAX_VALUE ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void buildCollationMapping()
/*      */     throws SQLException
/*      */   {
/*  915 */     Map<Integer, String> indexToCharset = null;
/*  916 */     Map<Long, String> sortedCollationMap = null;
/*  917 */     Map<Integer, String> customCharset = null;
/*  918 */     Map<String, Integer> customMblen = null;
/*      */     
/*  920 */     if (getCacheServerConfiguration()) {
/*  921 */       synchronized (dynamicIndexToCharsetMapByUrl) {
/*  922 */         indexToCharset = (Map)dynamicIndexToCharsetMapByUrl.get(getURL());
/*  923 */         sortedCollationMap = (Map)dynamicIndexToCollationMapByUrl.get(getURL());
/*  924 */         customCharset = (Map)customIndexToCharsetMapByUrl.get(getURL());
/*  925 */         customMblen = (Map)customCharsetToMblenMapByUrl.get(getURL());
/*      */       }
/*      */     }
/*      */     
/*  929 */     if (indexToCharset == null) {
/*  930 */       indexToCharset = new HashMap();
/*      */       
/*  932 */       if ((versionMeetsMinimum(4, 1, 0)) && (getDetectCustomCollations()))
/*      */       {
/*  934 */         java.sql.Statement stmt = null;
/*  935 */         ResultSet results = null;
/*      */         try
/*      */         {
/*  938 */           sortedCollationMap = new TreeMap();
/*  939 */           customCharset = new HashMap();
/*  940 */           customMblen = new HashMap();
/*      */           
/*  942 */           stmt = getMetadataSafeStatement();
/*      */           try
/*      */           {
/*  945 */             results = stmt.executeQuery("SHOW COLLATION");
/*  946 */             if (versionMeetsMinimum(5, 0, 0)) {
/*  947 */               Util.resultSetToMap(sortedCollationMap, results, 3, 2);
/*      */             } else {
/*  949 */               while (results.next()) {
/*  950 */                 sortedCollationMap.put(Long.valueOf(results.getLong(3)), results.getString(2));
/*      */               }
/*      */             }
/*      */           } catch (SQLException ex) {
/*  954 */             if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/*  955 */               throw ex;
/*      */             }
/*      */           }
/*      */           
/*  959 */           for (Iterator<Map.Entry<Long, String>> indexIter = sortedCollationMap.entrySet().iterator(); indexIter.hasNext();) {
/*  960 */             Map.Entry<Long, String> indexEntry = (Map.Entry)indexIter.next();
/*      */             
/*  962 */             int collationIndex = ((Long)indexEntry.getKey()).intValue();
/*  963 */             String charsetName = (String)indexEntry.getValue();
/*      */             
/*  965 */             indexToCharset.put(Integer.valueOf(collationIndex), charsetName);
/*      */             
/*      */ 
/*  968 */             if ((collationIndex >= 255) || (!charsetName.equals(CharsetMapping.getMysqlCharsetNameForCollationIndex(Integer.valueOf(collationIndex)))))
/*      */             {
/*  970 */               customCharset.put(Integer.valueOf(collationIndex), charsetName);
/*      */             }
/*      */             
/*      */ 
/*  974 */             if (!CharsetMapping.CHARSET_NAME_TO_CHARSET.containsKey(charsetName)) {
/*  975 */               customMblen.put(charsetName, null);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  980 */           if (customMblen.size() > 0) {
/*      */             try {
/*  982 */               results = stmt.executeQuery("SHOW CHARACTER SET");
/*  983 */               while (results.next()) {
/*  984 */                 String charsetName = results.getString("Charset");
/*  985 */                 if (customMblen.containsKey(charsetName)) {
/*  986 */                   customMblen.put(charsetName, Integer.valueOf(results.getInt("Maxlen")));
/*      */                 }
/*      */               }
/*      */             } catch (SQLException ex) {
/*  990 */               if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/*  991 */                 throw ex;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*  996 */           if (getCacheServerConfiguration()) {
/*  997 */             synchronized (dynamicIndexToCharsetMapByUrl) {
/*  998 */               dynamicIndexToCharsetMapByUrl.put(getURL(), indexToCharset);
/*  999 */               dynamicIndexToCollationMapByUrl.put(getURL(), sortedCollationMap);
/* 1000 */               customIndexToCharsetMapByUrl.put(getURL(), customCharset);
/* 1001 */               customCharsetToMblenMapByUrl.put(getURL(), customMblen);
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (SQLException ex) {
/* 1006 */           throw ex;
/*      */         } catch (RuntimeException ex) {
/* 1008 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1009 */           sqlEx.initCause(ex);
/* 1010 */           throw sqlEx;
/*      */         } finally {
/* 1012 */           if (results != null) {
/*      */             try {
/* 1014 */               results.close();
/*      */             }
/*      */             catch (SQLException sqlE) {}
/*      */           }
/*      */           
/*      */ 
/* 1020 */           if (stmt != null) {
/*      */             try {
/* 1022 */               stmt.close();
/*      */             }
/*      */             catch (SQLException sqlE) {}
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1029 */         for (int i = 1; i < 255; i++) {
/* 1030 */           indexToCharset.put(Integer.valueOf(i), CharsetMapping.getMysqlCharsetNameForCollationIndex(Integer.valueOf(i)));
/*      */         }
/* 1032 */         if (getCacheServerConfiguration()) {
/* 1033 */           synchronized (dynamicIndexToCharsetMapByUrl) {
/* 1034 */             dynamicIndexToCharsetMapByUrl.put(getURL(), indexToCharset);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1041 */     this.indexToMysqlCharset = Collections.unmodifiableMap(indexToCharset);
/* 1042 */     if (customCharset != null) {
/* 1043 */       this.indexToCustomMysqlCharset = Collections.unmodifiableMap(customCharset);
/*      */     }
/* 1045 */     if (customMblen != null) {
/* 1046 */       this.mysqlCharsetToCustomMblen = Collections.unmodifiableMap(customMblen);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean canHandleAsServerPreparedStatement(String sql) throws SQLException {
/* 1051 */     if ((sql == null) || (sql.length() == 0)) {
/* 1052 */       return true;
/*      */     }
/*      */     
/* 1055 */     if (!this.useServerPreparedStmts) {
/* 1056 */       return false;
/*      */     }
/*      */     
/* 1059 */     if (getCachePreparedStatements()) {
/* 1060 */       synchronized (this.serverSideStatementCheckCache) {
/* 1061 */         Boolean flag = (Boolean)this.serverSideStatementCheckCache.get(sql);
/*      */         
/* 1063 */         if (flag != null) {
/* 1064 */           return flag.booleanValue();
/*      */         }
/*      */         
/* 1067 */         boolean canHandle = canHandleAsServerPreparedStatementNoCache(sql);
/*      */         
/* 1069 */         if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 1070 */           this.serverSideStatementCheckCache.put(sql, canHandle ? Boolean.TRUE : Boolean.FALSE);
/*      */         }
/*      */         
/* 1073 */         return canHandle;
/*      */       }
/*      */     }
/*      */     
/* 1077 */     return canHandleAsServerPreparedStatementNoCache(sql);
/*      */   }
/*      */   
/*      */   private boolean canHandleAsServerPreparedStatementNoCache(String sql)
/*      */     throws SQLException
/*      */   {
/* 1083 */     if (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "CALL")) {
/* 1084 */       return false;
/*      */     }
/*      */     
/* 1087 */     boolean canHandleAsStatement = true;
/*      */     
/* 1089 */     if ((!versionMeetsMinimum(5, 0, 7)) && ((StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "SELECT")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "UPDATE")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "REPLACE"))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1101 */       int currentPos = 0;
/* 1102 */       int statementLength = sql.length();
/* 1103 */       int lastPosToLook = statementLength - 7;
/* 1104 */       boolean allowBackslashEscapes = !this.noBackslashEscapes;
/* 1105 */       String quoteChar = this.useAnsiQuotes ? "\"" : "'";
/* 1106 */       boolean foundLimitWithPlaceholder = false;
/*      */       
/* 1108 */       while (currentPos < lastPosToLook) {
/* 1109 */         int limitStart = StringUtils.indexOfIgnoreCase(currentPos, sql, "LIMIT ", quoteChar, quoteChar, allowBackslashEscapes ? StringUtils.SEARCH_MODE__ALL : StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */         
/*      */ 
/* 1112 */         if (limitStart == -1) {
/*      */           break;
/*      */         }
/*      */         
/* 1116 */         currentPos = limitStart + 7;
/*      */         
/* 1118 */         while (currentPos < statementLength) {
/* 1119 */           char c = sql.charAt(currentPos);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1125 */           if ((!Character.isDigit(c)) && (!Character.isWhitespace(c)) && (c != ',') && (c != '?')) {
/*      */             break;
/*      */           }
/*      */           
/* 1129 */           if (c == '?') {
/* 1130 */             foundLimitWithPlaceholder = true;
/* 1131 */             break;
/*      */           }
/*      */           
/* 1134 */           currentPos++;
/*      */         }
/*      */       }
/*      */       
/* 1138 */       canHandleAsStatement = !foundLimitWithPlaceholder;
/* 1139 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "XA ")) {
/* 1140 */       canHandleAsStatement = false;
/* 1141 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "CREATE TABLE")) {
/* 1142 */       canHandleAsStatement = false;
/* 1143 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "DO")) {
/* 1144 */       canHandleAsStatement = false;
/* 1145 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "SET")) {
/* 1146 */       canHandleAsStatement = false;
/* 1147 */     } else if ((StringUtils.startsWithIgnoreCaseAndWs(sql, "SHOW WARNINGS")) && (versionMeetsMinimum(5, 7, 2))) {
/* 1148 */       canHandleAsStatement = false;
/*      */     }
/*      */     
/* 1151 */     return canHandleAsStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void changeUser(String userName, String newPassword)
/*      */     throws SQLException
/*      */   {
/* 1168 */     synchronized (getConnectionMutex()) {
/* 1169 */       checkClosed();
/*      */       
/* 1171 */       if ((userName == null) || (userName.equals(""))) {
/* 1172 */         userName = "";
/*      */       }
/*      */       
/* 1175 */       if (newPassword == null) {
/* 1176 */         newPassword = "";
/*      */       }
/*      */       
/*      */ 
/* 1180 */       this.sessionMaxRows = -1;
/*      */       try
/*      */       {
/* 1183 */         this.io.changeUser(userName, newPassword, this.database);
/*      */       } catch (SQLException ex) {
/* 1185 */         if ((versionMeetsMinimum(5, 6, 13)) && ("28000".equals(ex.getSQLState()))) {
/* 1186 */           cleanup(ex);
/*      */         }
/* 1188 */         throw ex;
/*      */       }
/* 1190 */       this.user = userName;
/* 1191 */       this.password = newPassword;
/*      */       
/* 1193 */       if (versionMeetsMinimum(4, 1, 0)) {
/* 1194 */         configureClientCharacterSet(true);
/*      */       }
/*      */       
/* 1197 */       setSessionVariables();
/*      */       
/* 1199 */       setupServerForTruncationChecks();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean characterSetNamesMatches(String mysqlEncodingName)
/*      */   {
/* 1205 */     return (mysqlEncodingName != null) && (mysqlEncodingName.equalsIgnoreCase((String)this.serverVariables.get("character_set_client"))) && (mysqlEncodingName.equalsIgnoreCase((String)this.serverVariables.get("character_set_connection")));
/*      */   }
/*      */   
/*      */   private void checkAndCreatePerformanceHistogram()
/*      */   {
/* 1210 */     if (this.perfMetricsHistCounts == null) {
/* 1211 */       this.perfMetricsHistCounts = new int[20];
/*      */     }
/*      */     
/* 1214 */     if (this.perfMetricsHistBreakpoints == null) {
/* 1215 */       this.perfMetricsHistBreakpoints = new long[20];
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkAndCreateTablesAccessedHistogram() {
/* 1220 */     if (this.numTablesMetricsHistCounts == null) {
/* 1221 */       this.numTablesMetricsHistCounts = new int[20];
/*      */     }
/*      */     
/* 1224 */     if (this.numTablesMetricsHistBreakpoints == null) {
/* 1225 */       this.numTablesMetricsHistBreakpoints = new long[20];
/*      */     }
/*      */   }
/*      */   
/*      */   public void checkClosed() throws SQLException {
/* 1230 */     if (this.isClosed) {
/* 1231 */       throwConnectionClosedException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void throwConnectionClosedException() throws SQLException {
/* 1236 */     SQLException ex = SQLError.createSQLException("No operations allowed after connection closed.", "08003", getExceptionInterceptor());
/*      */     
/*      */ 
/* 1239 */     if (this.forceClosedReason != null) {
/* 1240 */       ex.initCause(this.forceClosedReason);
/*      */     }
/*      */     
/* 1243 */     throw ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkServerEncoding()
/*      */     throws SQLException
/*      */   {
/* 1253 */     if ((getUseUnicode()) && (getEncoding() != null))
/*      */     {
/* 1255 */       return;
/*      */     }
/*      */     
/* 1258 */     String serverCharset = (String)this.serverVariables.get("character_set");
/*      */     
/* 1260 */     if (serverCharset == null)
/*      */     {
/* 1262 */       serverCharset = (String)this.serverVariables.get("character_set_server");
/*      */     }
/*      */     
/* 1265 */     String mappedServerEncoding = null;
/*      */     
/* 1267 */     if (serverCharset != null) {
/*      */       try {
/* 1269 */         mappedServerEncoding = CharsetMapping.getJavaEncodingForMysqlCharset(serverCharset);
/*      */       } catch (RuntimeException ex) {
/* 1271 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1272 */         sqlEx.initCause(ex);
/* 1273 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1280 */     if ((!getUseUnicode()) && (mappedServerEncoding != null)) {
/* 1281 */       SingleByteCharsetConverter converter = getCharsetConverter(mappedServerEncoding);
/*      */       
/* 1283 */       if (converter != null) {
/* 1284 */         setUseUnicode(true);
/* 1285 */         setEncoding(mappedServerEncoding);
/*      */         
/* 1287 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1294 */     if (serverCharset != null) {
/* 1295 */       if (mappedServerEncoding == null)
/*      */       {
/* 1297 */         if (Character.isLowerCase(serverCharset.charAt(0))) {
/* 1298 */           char[] ach = serverCharset.toCharArray();
/* 1299 */           ach[0] = Character.toUpperCase(serverCharset.charAt(0));
/* 1300 */           setEncoding(new String(ach));
/*      */         }
/*      */       }
/*      */       
/* 1304 */       if (mappedServerEncoding == null) {
/* 1305 */         throw SQLError.createSQLException("Unknown character encoding on server '" + serverCharset + "', use 'characterEncoding=' property " + " to provide correct mapping", "01S00", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1313 */         StringUtils.getBytes("abc", mappedServerEncoding);
/* 1314 */         setEncoding(mappedServerEncoding);
/* 1315 */         setUseUnicode(true);
/*      */       } catch (UnsupportedEncodingException UE) {
/* 1317 */         throw SQLError.createSQLException("The driver can not map the character encoding '" + getEncoding() + "' that your server is using " + "to a character encoding your JVM understands. You can specify this mapping manually by adding \"useUnicode=true\" " + "as well as \"characterEncoding=[an_encoding_your_jvm_understands]\" to your JDBC URL.", "0S100", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkTransactionIsolationLevel()
/*      */     throws SQLException
/*      */   {
/* 1331 */     String txIsolationName = null;
/*      */     
/* 1333 */     if (versionMeetsMinimum(4, 0, 3)) {
/* 1334 */       txIsolationName = "tx_isolation";
/*      */     } else {
/* 1336 */       txIsolationName = "transaction_isolation";
/*      */     }
/*      */     
/* 1339 */     String s = (String)this.serverVariables.get(txIsolationName);
/*      */     
/* 1341 */     if (s != null) {
/* 1342 */       Integer intTI = (Integer)mapTransIsolationNameToValue.get(s);
/*      */       
/* 1344 */       if (intTI != null) {
/* 1345 */         this.isolationLevel = intTI.intValue();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void abortInternal()
/*      */     throws SQLException
/*      */   {
/* 1357 */     if (this.io != null) {
/*      */       try {
/* 1359 */         this.io.forceClose();
/*      */       }
/*      */       catch (Throwable t) {}
/*      */       
/* 1363 */       this.io.releaseResources();
/* 1364 */       this.io = null;
/*      */     }
/*      */     
/* 1367 */     this.isClosed = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cleanup(Throwable whyCleanedUp)
/*      */   {
/*      */     try
/*      */     {
/* 1378 */       if (this.io != null) {
/* 1379 */         if (isClosed()) {
/* 1380 */           this.io.forceClose();
/*      */         } else {
/* 1382 */           realClose(false, false, false, whyCleanedUp);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (SQLException sqlEx) {}
/*      */     
/*      */ 
/* 1389 */     this.isClosed = true;
/*      */   }
/*      */   
/*      */   public void clearHasTriedMaster() {
/* 1393 */     this.hasTriedMasterFlag = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 1412 */     return clientPrepareStatement(sql, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex)
/*      */     throws SQLException
/*      */   {
/* 1419 */     java.sql.PreparedStatement pStmt = clientPrepareStatement(sql);
/*      */     
/* 1421 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
/*      */     
/* 1423 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 1433 */     return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
/*      */   }
/*      */   
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, boolean processEscapeCodesIfNeeded) throws SQLException
/*      */   {
/* 1438 */     checkClosed();
/*      */     
/* 1440 */     String nativeSql = (processEscapeCodesIfNeeded) && (getProcessEscapeCodesForPrepStmts()) ? nativeSQL(sql) : sql;
/*      */     
/* 1442 */     PreparedStatement pStmt = null;
/*      */     
/* 1444 */     if (getCachePreparedStatements()) {
/* 1445 */       PreparedStatement.ParseInfo pStmtInfo = (PreparedStatement.ParseInfo)this.cachedPreparedStatementParams.get(nativeSql);
/*      */       
/* 1447 */       if (pStmtInfo == null) {
/* 1448 */         pStmt = PreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database);
/*      */         
/* 1450 */         this.cachedPreparedStatementParams.put(nativeSql, pStmt.getParseInfo());
/*      */       } else {
/* 1452 */         pStmt = new PreparedStatement(getMultiHostSafeProxy(), nativeSql, this.database, pStmtInfo);
/*      */       }
/*      */     } else {
/* 1455 */       pStmt = PreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database);
/*      */     }
/*      */     
/* 1458 */     pStmt.setResultSetType(resultSetType);
/* 1459 */     pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 1461 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes)
/*      */     throws SQLException
/*      */   {
/* 1469 */     PreparedStatement pStmt = (PreparedStatement)clientPrepareStatement(sql);
/*      */     
/* 1471 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null) && (autoGenKeyIndexes.length > 0));
/*      */     
/* 1473 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames)
/*      */     throws SQLException
/*      */   {
/* 1480 */     PreparedStatement pStmt = (PreparedStatement)clientPrepareStatement(sql);
/*      */     
/* 1482 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null) && (autoGenKeyColNames.length > 0));
/*      */     
/* 1484 */     return pStmt;
/*      */   }
/*      */   
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*      */   {
/* 1489 */     return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/* 1505 */     synchronized (getConnectionMutex()) {
/* 1506 */       if (this.connectionLifecycleInterceptors != null) {
/* 1507 */         new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */         {
/*      */           void forEach(Extension each) throws SQLException {
/* 1510 */             ((ConnectionLifecycleInterceptor)each).close();
/*      */           }
/*      */         }.doForAll();
/*      */       }
/*      */       
/* 1515 */       realClose(true, true, false, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void closeAllOpenStatements()
/*      */     throws SQLException
/*      */   {
/* 1525 */     SQLException postponedException = null;
/*      */     
/* 1527 */     if (this.openStatements != null) {
/* 1528 */       List<Statement> currentlyOpenStatements = new ArrayList();
/*      */       
/*      */ 
/* 1531 */       for (Iterator<Statement> iter = this.openStatements.keySet().iterator(); iter.hasNext();) {
/* 1532 */         currentlyOpenStatements.add(iter.next());
/*      */       }
/*      */       
/* 1535 */       int numStmts = currentlyOpenStatements.size();
/*      */       
/* 1537 */       for (int i = 0; i < numStmts; i++) {
/* 1538 */         StatementImpl stmt = (StatementImpl)currentlyOpenStatements.get(i);
/*      */         try
/*      */         {
/* 1541 */           stmt.realClose(false, true);
/*      */         } catch (SQLException sqlEx) {
/* 1543 */           postponedException = sqlEx;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1548 */       if (postponedException != null) {
/* 1549 */         throw postponedException;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void closeStatement(java.sql.Statement stmt) {
/* 1555 */     if (stmt != null) {
/*      */       try {
/* 1557 */         stmt.close();
/*      */       }
/*      */       catch (SQLException sqlEx) {}
/*      */       
/*      */ 
/* 1562 */       stmt = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void commit()
/*      */     throws SQLException
/*      */   {
/* 1580 */     synchronized (getConnectionMutex()) {
/* 1581 */       checkClosed();
/*      */       try
/*      */       {
/* 1584 */         if (this.connectionLifecycleInterceptors != null) {
/* 1585 */           IterateBlock<Extension> iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Extension each) throws SQLException
/*      */             {
/* 1589 */               if (!((ConnectionLifecycleInterceptor)each).commit()) {
/* 1590 */                 this.stopIterating = true;
/*      */               }
/*      */               
/*      */             }
/* 1594 */           };
/* 1595 */           iter.doForAll();
/*      */           
/* 1597 */           if (!iter.fullIteration()) {
/* 1598 */             jsr 136;return;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1603 */         if ((this.autoCommit) && (!getRelaxAutoCommit()))
/* 1604 */           throw SQLError.createSQLException("Can't call commit when autocommit=true", getExceptionInterceptor());
/* 1605 */         if (this.transactionsSupported) {
/* 1606 */           if ((getUseLocalTransactionState()) && (versionMeetsMinimum(5, 0, 0)) && 
/* 1607 */             (!this.io.inTransactionOnServer())) {
/* 1608 */             jsr 71;return;
/*      */           }
/*      */           
/*      */ 
/* 1612 */           execSQL(null, "commit", -1, null, 1003, 1007, false, this.database, null, false);
/*      */         }
/*      */       } catch (SQLException sqlException) {
/* 1615 */         if ("08S01".equals(sqlException.getSQLState())) {
/* 1616 */           throw SQLError.createSQLException("Communications link failure during commit(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/* 1620 */         throw sqlException;
/*      */       } finally {
/* 1622 */         jsr 5; } localObject2 = returnAddress;this.needsPing = getReconnectAtTxEnd();ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void configureCharsetProperties()
/*      */     throws SQLException
/*      */   {
/* 1635 */     if (getEncoding() != null) {
/*      */       try
/*      */       {
/* 1638 */         String testString = "abc";
/* 1639 */         StringUtils.getBytes(testString, getEncoding());
/*      */       }
/*      */       catch (UnsupportedEncodingException UE) {
/* 1642 */         String oldEncoding = getEncoding();
/*      */         try
/*      */         {
/* 1645 */           setEncoding(CharsetMapping.getJavaEncodingForMysqlCharset(oldEncoding));
/*      */         } catch (RuntimeException ex) {
/* 1647 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1648 */           sqlEx.initCause(ex);
/* 1649 */           throw sqlEx;
/*      */         }
/*      */         
/* 1652 */         if (getEncoding() == null) {
/* 1653 */           throw SQLError.createSQLException("Java does not support the MySQL character encoding '" + oldEncoding + "'.", "01S00", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */         try
/*      */         {
/* 1658 */           String testString = "abc";
/* 1659 */           StringUtils.getBytes(testString, getEncoding());
/*      */         } catch (UnsupportedEncodingException encodingEx) {
/* 1661 */           throw SQLError.createSQLException("Unsupported character encoding '" + getEncoding() + "'.", "01S00", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean configureClientCharacterSet(boolean dontCheckServerMatch)
/*      */     throws SQLException
/*      */   {
/* 1682 */     String realJavaEncoding = getEncoding();
/* 1683 */     boolean characterSetAlreadyConfigured = false;
/*      */     try
/*      */     {
/* 1686 */       if (versionMeetsMinimum(4, 1, 0)) {
/* 1687 */         characterSetAlreadyConfigured = true;
/*      */         
/* 1689 */         setUseUnicode(true);
/*      */         
/* 1691 */         configureCharsetProperties();
/* 1692 */         realJavaEncoding = getEncoding();
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1698 */           if ((this.props != null) && (this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex") != null)) {
/* 1699 */             this.io.serverCharsetIndex = Integer.parseInt(this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex"));
/*      */           }
/*      */           
/* 1702 */           String serverEncodingToSet = CharsetMapping.getJavaEncodingForCollationIndex(Integer.valueOf(this.io.serverCharsetIndex));
/*      */           
/* 1704 */           if ((serverEncodingToSet == null) || (serverEncodingToSet.length() == 0)) {
/* 1705 */             if (realJavaEncoding != null)
/*      */             {
/* 1707 */               setEncoding(realJavaEncoding);
/*      */             } else {
/* 1709 */               throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1716 */           if ((versionMeetsMinimum(4, 1, 0)) && ("ISO8859_1".equalsIgnoreCase(serverEncodingToSet))) {
/* 1717 */             serverEncodingToSet = "Cp1252";
/*      */           }
/* 1719 */           if (("UnicodeBig".equalsIgnoreCase(serverEncodingToSet)) || ("UTF-16".equalsIgnoreCase(serverEncodingToSet)) || ("UTF-16LE".equalsIgnoreCase(serverEncodingToSet)) || ("UTF-32".equalsIgnoreCase(serverEncodingToSet)))
/*      */           {
/* 1721 */             serverEncodingToSet = "UTF-8";
/*      */           }
/*      */           
/* 1724 */           setEncoding(serverEncodingToSet);
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 1727 */           if (realJavaEncoding != null)
/*      */           {
/* 1729 */             setEncoding(realJavaEncoding);
/*      */           } else {
/* 1731 */             throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */         catch (SQLException ex)
/*      */         {
/* 1736 */           throw ex;
/*      */         } catch (RuntimeException ex) {
/* 1738 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1739 */           sqlEx.initCause(ex);
/* 1740 */           throw sqlEx;
/*      */         }
/*      */         
/* 1743 */         if (getEncoding() == null)
/*      */         {
/* 1745 */           setEncoding("ISO8859_1");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1751 */         if (getUseUnicode()) {
/* 1752 */           if (realJavaEncoding != null)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1757 */             if ((realJavaEncoding.equalsIgnoreCase("UTF-8")) || (realJavaEncoding.equalsIgnoreCase("UTF8")))
/*      */             {
/*      */ 
/* 1760 */               boolean utf8mb4Supported = versionMeetsMinimum(5, 5, 2);
/* 1761 */               boolean useutf8mb4 = (utf8mb4Supported) && (CharsetMapping.UTF8MB4_INDEXES.contains(Integer.valueOf(this.io.serverCharsetIndex)));
/*      */               
/* 1763 */               if (!getUseOldUTF8Behavior()) {
/* 1764 */                 if ((dontCheckServerMatch) || (!characterSetNamesMatches("utf8")) || ((utf8mb4Supported) && (!characterSetNamesMatches("utf8mb4")))) {
/* 1765 */                   execSQL(null, "SET NAMES " + (useutf8mb4 ? "utf8mb4" : "utf8"), -1, null, 1003, 1007, false, this.database, null, false);
/*      */                   
/* 1767 */                   this.serverVariables.put("character_set_client", useutf8mb4 ? "utf8mb4" : "utf8");
/* 1768 */                   this.serverVariables.put("character_set_connection", useutf8mb4 ? "utf8mb4" : "utf8");
/*      */                 }
/*      */               } else {
/* 1771 */                 execSQL(null, "SET NAMES latin1", -1, null, 1003, 1007, false, this.database, null, false);
/*      */                 
/* 1773 */                 this.serverVariables.put("character_set_client", "latin1");
/* 1774 */                 this.serverVariables.put("character_set_connection", "latin1");
/*      */               }
/*      */               
/* 1777 */               setEncoding(realJavaEncoding);
/*      */             } else {
/* 1779 */               String mysqlCharsetName = CharsetMapping.getMysqlCharsetForJavaEncoding(realJavaEncoding.toUpperCase(Locale.ENGLISH), this);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1790 */               if (mysqlCharsetName != null)
/*      */               {
/* 1792 */                 if ((dontCheckServerMatch) || (!characterSetNamesMatches(mysqlCharsetName))) {
/* 1793 */                   execSQL(null, "SET NAMES " + mysqlCharsetName, -1, null, 1003, 1007, false, this.database, null, false);
/*      */                   
/* 1795 */                   this.serverVariables.put("character_set_client", mysqlCharsetName);
/* 1796 */                   this.serverVariables.put("character_set_connection", mysqlCharsetName);
/*      */                 }
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 1802 */               setEncoding(realJavaEncoding);
/*      */             }
/* 1804 */           } else if (getEncoding() != null)
/*      */           {
/* 1806 */             String mysqlCharsetName = getServerCharset();
/*      */             
/* 1808 */             if (getUseOldUTF8Behavior()) {
/* 1809 */               mysqlCharsetName = "latin1";
/*      */             }
/*      */             
/* 1812 */             boolean ucs2 = false;
/* 1813 */             if (("ucs2".equalsIgnoreCase(mysqlCharsetName)) || ("utf16".equalsIgnoreCase(mysqlCharsetName)) || ("utf16le".equalsIgnoreCase(mysqlCharsetName)) || ("utf32".equalsIgnoreCase(mysqlCharsetName)))
/*      */             {
/* 1815 */               mysqlCharsetName = "utf8";
/* 1816 */               ucs2 = true;
/* 1817 */               if (getCharacterSetResults() == null) {
/* 1818 */                 setCharacterSetResults("UTF-8");
/*      */               }
/*      */             }
/*      */             
/* 1822 */             if ((dontCheckServerMatch) || (!characterSetNamesMatches(mysqlCharsetName)) || (ucs2)) {
/*      */               try {
/* 1824 */                 execSQL(null, "SET NAMES " + mysqlCharsetName, -1, null, 1003, 1007, false, this.database, null, false);
/*      */                 
/* 1826 */                 this.serverVariables.put("character_set_client", mysqlCharsetName);
/* 1827 */                 this.serverVariables.put("character_set_connection", mysqlCharsetName);
/*      */               } catch (SQLException ex) {
/* 1829 */                 if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/* 1830 */                   throw ex;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 1835 */             realJavaEncoding = getEncoding();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1845 */         String onServer = null;
/* 1846 */         boolean isNullOnServer = false;
/*      */         
/* 1848 */         if (this.serverVariables != null) {
/* 1849 */           onServer = (String)this.serverVariables.get("character_set_results");
/*      */           
/* 1851 */           isNullOnServer = (onServer == null) || ("NULL".equalsIgnoreCase(onServer)) || (onServer.length() == 0);
/*      */         }
/*      */         
/* 1854 */         if (getCharacterSetResults() == null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1859 */           if (!isNullOnServer) {
/*      */             try {
/* 1861 */               execSQL(null, "SET character_set_results = NULL", -1, null, 1003, 1007, false, this.database, null, false);
/*      */             }
/*      */             catch (SQLException ex) {
/* 1864 */               if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/* 1865 */                 throw ex;
/*      */               }
/*      */             }
/* 1868 */             this.serverVariables.put("jdbc.local.character_set_results", null);
/*      */           } else {
/* 1870 */             this.serverVariables.put("jdbc.local.character_set_results", onServer);
/*      */           }
/*      */         }
/*      */         else {
/* 1874 */           if (getUseOldUTF8Behavior()) {
/*      */             try {
/* 1876 */               execSQL(null, "SET NAMES latin1", -1, null, 1003, 1007, false, this.database, null, false);
/*      */               
/* 1878 */               this.serverVariables.put("character_set_client", "latin1");
/* 1879 */               this.serverVariables.put("character_set_connection", "latin1");
/*      */             } catch (SQLException ex) {
/* 1881 */               if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/* 1882 */                 throw ex;
/*      */               }
/*      */             }
/*      */           }
/* 1886 */           String charsetResults = getCharacterSetResults();
/* 1887 */           String mysqlEncodingName = null;
/*      */           
/* 1889 */           if (("UTF-8".equalsIgnoreCase(charsetResults)) || ("UTF8".equalsIgnoreCase(charsetResults))) {
/* 1890 */             mysqlEncodingName = "utf8";
/* 1891 */           } else if ("null".equalsIgnoreCase(charsetResults)) {
/* 1892 */             mysqlEncodingName = "NULL";
/*      */           } else {
/* 1894 */             mysqlEncodingName = CharsetMapping.getMysqlCharsetForJavaEncoding(charsetResults.toUpperCase(Locale.ENGLISH), this);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1901 */           if (mysqlEncodingName == null) {
/* 1902 */             throw SQLError.createSQLException("Can't map " + charsetResults + " given for characterSetResults to a supported MySQL encoding.", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 1906 */           if (!mysqlEncodingName.equalsIgnoreCase((String)this.serverVariables.get("character_set_results"))) {
/* 1907 */             StringBuilder setBuf = new StringBuilder("SET character_set_results = ".length() + mysqlEncodingName.length());
/* 1908 */             setBuf.append("SET character_set_results = ").append(mysqlEncodingName);
/*      */             try
/*      */             {
/* 1911 */               execSQL(null, setBuf.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */             }
/*      */             catch (SQLException ex) {
/* 1914 */               if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/* 1915 */                 throw ex;
/*      */               }
/*      */             }
/*      */             
/* 1919 */             this.serverVariables.put("jdbc.local.character_set_results", mysqlEncodingName);
/*      */             
/*      */ 
/* 1922 */             if (versionMeetsMinimum(5, 5, 0)) {
/* 1923 */               this.errorMessageEncoding = charsetResults;
/*      */             }
/*      */           }
/*      */           else {
/* 1927 */             this.serverVariables.put("jdbc.local.character_set_results", onServer);
/*      */           }
/*      */         }
/*      */         
/* 1931 */         if (getConnectionCollation() != null) {
/* 1932 */           StringBuilder setBuf = new StringBuilder("SET collation_connection = ".length() + getConnectionCollation().length());
/* 1933 */           setBuf.append("SET collation_connection = ").append(getConnectionCollation());
/*      */           try
/*      */           {
/* 1936 */             execSQL(null, setBuf.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */           } catch (SQLException ex) {
/* 1938 */             if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/* 1939 */               throw ex;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1945 */         realJavaEncoding = getEncoding();
/*      */       }
/*      */       
/*      */     }
/*      */     finally
/*      */     {
/* 1951 */       setEncoding(realJavaEncoding);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1959 */       CharsetEncoder enc = Charset.forName(getEncoding()).newEncoder();
/* 1960 */       CharBuffer cbuf = CharBuffer.allocate(1);
/* 1961 */       ByteBuffer bbuf = ByteBuffer.allocate(1);
/*      */       
/* 1963 */       cbuf.put("¥");
/* 1964 */       cbuf.position(0);
/* 1965 */       enc.encode(cbuf, bbuf, true);
/* 1966 */       if (bbuf.get(0) == 92) {
/* 1967 */         this.requiresEscapingEncoder = true;
/*      */       } else {
/* 1969 */         cbuf.clear();
/* 1970 */         bbuf.clear();
/*      */         
/* 1972 */         cbuf.put("₩");
/* 1973 */         cbuf.position(0);
/* 1974 */         enc.encode(cbuf, bbuf, true);
/* 1975 */         if (bbuf.get(0) == 92) {
/* 1976 */           this.requiresEscapingEncoder = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (UnsupportedCharsetException ucex) {
/*      */       try {
/* 1982 */         byte[] bbuf = StringUtils.getBytes("¥", getEncoding());
/* 1983 */         if (bbuf[0] == 92) {
/* 1984 */           this.requiresEscapingEncoder = true;
/*      */         } else {
/* 1986 */           bbuf = StringUtils.getBytes("₩", getEncoding());
/* 1987 */           if (bbuf[0] == 92) {
/* 1988 */             this.requiresEscapingEncoder = true;
/*      */           }
/*      */         }
/*      */       } catch (UnsupportedEncodingException ueex) {
/* 1992 */         throw SQLError.createSQLException("Unable to use encoding: " + getEncoding(), "S1000", ueex, getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1997 */     return characterSetAlreadyConfigured;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void configureTimezone()
/*      */     throws SQLException
/*      */   {
/* 2008 */     String configuredTimeZoneOnServer = (String)this.serverVariables.get("timezone");
/*      */     
/* 2010 */     if (configuredTimeZoneOnServer == null) {
/* 2011 */       configuredTimeZoneOnServer = (String)this.serverVariables.get("time_zone");
/*      */       
/* 2013 */       if ("SYSTEM".equalsIgnoreCase(configuredTimeZoneOnServer)) {
/* 2014 */         configuredTimeZoneOnServer = (String)this.serverVariables.get("system_time_zone");
/*      */       }
/*      */     }
/*      */     
/* 2018 */     String canonicalTimezone = getServerTimezone();
/*      */     
/* 2020 */     if (((getUseTimezone()) || (!getUseLegacyDatetimeCode())) && (configuredTimeZoneOnServer != null))
/*      */     {
/* 2022 */       if ((canonicalTimezone == null) || (StringUtils.isEmptyOrWhitespaceOnly(canonicalTimezone))) {
/*      */         try {
/* 2024 */           canonicalTimezone = TimeUtil.getCanonicalTimezone(configuredTimeZoneOnServer, getExceptionInterceptor());
/*      */         } catch (IllegalArgumentException iae) {
/* 2026 */           throw SQLError.createSQLException(iae.getMessage(), "S1000", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2031 */     if ((canonicalTimezone != null) && (canonicalTimezone.length() > 0)) {
/* 2032 */       this.serverTimezoneTZ = TimeZone.getTimeZone(canonicalTimezone);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2037 */       if ((!canonicalTimezone.equalsIgnoreCase("GMT")) && (this.serverTimezoneTZ.getID().equals("GMT"))) {
/* 2038 */         throw SQLError.createSQLException("No timezone mapping entry for '" + canonicalTimezone + "'", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 2042 */       this.isServerTzUTC = "GMT".equalsIgnoreCase(this.serverTimezoneTZ.getID());
/*      */     }
/*      */   }
/*      */   
/*      */   private void createInitialHistogram(long[] breakpoints, long lowerBound, long upperBound)
/*      */   {
/* 2048 */     double bucketSize = (upperBound - lowerBound) / 20.0D * 1.25D;
/*      */     
/* 2050 */     if (bucketSize < 1.0D) {
/* 2051 */       bucketSize = 1.0D;
/*      */     }
/*      */     
/* 2054 */     for (int i = 0; i < 20; i++) {
/* 2055 */       breakpoints[i] = lowerBound;
/* 2056 */       lowerBound = (lowerBound + bucketSize);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void createNewIO(boolean isForReconnect)
/*      */     throws SQLException
/*      */   {
/* 2071 */     synchronized (getConnectionMutex())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2076 */       Properties mergedProps = exposeAsProperties(this.props);
/*      */       
/* 2078 */       if (!getHighAvailability()) {
/* 2079 */         connectOneTryOnly(isForReconnect, mergedProps);
/*      */         
/* 2081 */         return;
/*      */       }
/*      */       
/* 2084 */       connectWithRetries(isForReconnect, mergedProps);
/*      */     }
/*      */   }
/*      */   
/*      */   private void connectWithRetries(boolean isForReconnect, Properties mergedProps) throws SQLException {
/* 2089 */     double timeout = getInitialTimeout();
/* 2090 */     boolean connectionGood = false;
/*      */     
/* 2092 */     Exception connectionException = null;
/*      */     
/* 2094 */     for (int attemptCount = 0; (attemptCount < getMaxReconnects()) && (!connectionGood); attemptCount++) {
/*      */       try {
/* 2096 */         if (this.io != null) {
/* 2097 */           this.io.forceClose();
/*      */         }
/*      */         
/* 2100 */         coreConnect(mergedProps);
/* 2101 */         pingInternal(false, 0);
/*      */         
/*      */         boolean oldAutoCommit;
/*      */         
/*      */         int oldIsolationLevel;
/*      */         boolean oldReadOnly;
/*      */         String oldCatalog;
/* 2108 */         synchronized (getConnectionMutex()) {
/* 2109 */           this.connectionId = this.io.getThreadId();
/* 2110 */           this.isClosed = false;
/*      */           
/*      */ 
/* 2113 */           oldAutoCommit = getAutoCommit();
/* 2114 */           oldIsolationLevel = this.isolationLevel;
/* 2115 */           oldReadOnly = isReadOnly(false);
/* 2116 */           oldCatalog = getCatalog();
/*      */           
/* 2118 */           this.io.setStatementInterceptors(this.statementInterceptors);
/*      */         }
/*      */         
/*      */ 
/* 2122 */         initializePropsFromServer();
/*      */         
/* 2124 */         if (isForReconnect)
/*      */         {
/* 2126 */           setAutoCommit(oldAutoCommit);
/*      */           
/* 2128 */           if (this.hasIsolationLevels) {
/* 2129 */             setTransactionIsolation(oldIsolationLevel);
/*      */           }
/*      */           
/* 2132 */           setCatalog(oldCatalog);
/* 2133 */           setReadOnly(oldReadOnly);
/*      */         }
/*      */         
/* 2136 */         connectionGood = true;
/*      */       }
/*      */       catch (Exception EEE)
/*      */       {
/* 2140 */         connectionException = EEE;
/* 2141 */         connectionGood = false;
/*      */         
/*      */ 
/* 2144 */         if (!connectionGood) break label190; }
/* 2145 */       break;
/*      */       
/*      */       label190:
/* 2148 */       if (attemptCount > 0) {
/*      */         try {
/* 2150 */           Thread.sleep(timeout * 1000L);
/*      */         }
/*      */         catch (InterruptedException IE) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2157 */     if (!connectionGood)
/*      */     {
/* 2159 */       SQLException chainedEx = SQLError.createSQLException(Messages.getString("Connection.UnableToConnectWithRetries", new Object[] { Integer.valueOf(getMaxReconnects()) }), "08001", getExceptionInterceptor());
/*      */       
/*      */ 
/* 2162 */       chainedEx.initCause(connectionException);
/*      */       
/* 2164 */       throw chainedEx;
/*      */     }
/*      */     
/* 2167 */     if ((getParanoid()) && (!getHighAvailability())) {
/* 2168 */       this.password = null;
/* 2169 */       this.user = null;
/*      */     }
/*      */     
/* 2172 */     if (isForReconnect)
/*      */     {
/*      */ 
/*      */ 
/* 2176 */       Iterator<Statement> statementIter = this.openStatements.values().iterator();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2182 */       Stack<Statement> serverPreparedStatements = null;
/*      */       
/* 2184 */       while (statementIter.hasNext()) {
/* 2185 */         Statement statementObj = (Statement)statementIter.next();
/*      */         
/* 2187 */         if ((statementObj instanceof ServerPreparedStatement)) {
/* 2188 */           if (serverPreparedStatements == null) {
/* 2189 */             serverPreparedStatements = new Stack();
/*      */           }
/*      */           
/* 2192 */           serverPreparedStatements.add(statementObj);
/*      */         }
/*      */       }
/*      */       
/* 2196 */       if (serverPreparedStatements != null) {
/* 2197 */         while (!serverPreparedStatements.isEmpty()) {
/* 2198 */           ((ServerPreparedStatement)serverPreparedStatements.pop()).rePrepare();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void coreConnect(Properties mergedProps) throws SQLException, IOException {
/* 2205 */     int newPort = 3306;
/* 2206 */     String newHost = "localhost";
/*      */     
/* 2208 */     String protocol = mergedProps.getProperty("PROTOCOL");
/*      */     
/* 2210 */     if (protocol != null)
/*      */     {
/*      */ 
/* 2213 */       if ("tcp".equalsIgnoreCase(protocol)) {
/* 2214 */         newHost = normalizeHost(mergedProps.getProperty("HOST"));
/* 2215 */         newPort = parsePortNumber(mergedProps.getProperty("PORT", "3306"));
/* 2216 */       } else if ("pipe".equalsIgnoreCase(protocol)) {
/* 2217 */         setSocketFactoryClassName(NamedPipeSocketFactory.class.getName());
/*      */         
/* 2219 */         String path = mergedProps.getProperty("PATH");
/*      */         
/* 2221 */         if (path != null) {
/* 2222 */           mergedProps.setProperty("namedPipePath", path);
/*      */         }
/*      */       }
/*      */       else {
/* 2226 */         newHost = normalizeHost(mergedProps.getProperty("HOST"));
/* 2227 */         newPort = parsePortNumber(mergedProps.getProperty("PORT", "3306"));
/*      */       }
/*      */     }
/*      */     else {
/* 2231 */       String[] parsedHostPortPair = NonRegisteringDriver.parseHostPortPair(this.hostPortPair);
/* 2232 */       newHost = parsedHostPortPair[0];
/*      */       
/* 2234 */       newHost = normalizeHost(newHost);
/*      */       
/* 2236 */       if (parsedHostPortPair[1] != null) {
/* 2237 */         newPort = parsePortNumber(parsedHostPortPair[1]);
/*      */       }
/*      */     }
/*      */     
/* 2241 */     this.port = newPort;
/* 2242 */     this.host = newHost;
/*      */     
/*      */ 
/* 2245 */     this.sessionMaxRows = -1;
/*      */     
/* 2247 */     this.io = new MysqlIO(newHost, newPort, mergedProps, getSocketFactoryClassName(), getProxy(), getSocketTimeout(), this.largeRowSizeThreshold.getValueAsInt());
/*      */     
/* 2249 */     this.io.doHandshake(this.user, this.password, this.database);
/* 2250 */     if (versionMeetsMinimum(5, 5, 0))
/*      */     {
/* 2252 */       this.errorMessageEncoding = this.io.getEncodingForHandshake();
/*      */     }
/*      */   }
/*      */   
/*      */   private String normalizeHost(String hostname) {
/* 2257 */     if ((hostname == null) || (StringUtils.isEmptyOrWhitespaceOnly(hostname))) {
/* 2258 */       return "localhost";
/*      */     }
/*      */     
/* 2261 */     return hostname;
/*      */   }
/*      */   
/*      */   private int parsePortNumber(String portAsString) throws SQLException {
/* 2265 */     int portNumber = 3306;
/*      */     try {
/* 2267 */       portNumber = Integer.parseInt(portAsString);
/*      */     } catch (NumberFormatException nfe) {
/* 2269 */       throw SQLError.createSQLException("Illegal connection port value '" + portAsString + "'", "01S00", getExceptionInterceptor());
/*      */     }
/*      */     
/* 2272 */     return portNumber;
/*      */   }
/*      */   
/*      */   private void connectOneTryOnly(boolean isForReconnect, Properties mergedProps) throws SQLException {
/* 2276 */     Exception connectionNotEstablishedBecause = null;
/*      */     
/*      */     try
/*      */     {
/* 2280 */       coreConnect(mergedProps);
/* 2281 */       this.connectionId = this.io.getThreadId();
/* 2282 */       this.isClosed = false;
/*      */       
/*      */ 
/* 2285 */       boolean oldAutoCommit = getAutoCommit();
/* 2286 */       int oldIsolationLevel = this.isolationLevel;
/* 2287 */       boolean oldReadOnly = isReadOnly(false);
/* 2288 */       String oldCatalog = getCatalog();
/*      */       
/* 2290 */       this.io.setStatementInterceptors(this.statementInterceptors);
/*      */       
/*      */ 
/* 2293 */       initializePropsFromServer();
/*      */       
/* 2295 */       if (isForReconnect)
/*      */       {
/* 2297 */         setAutoCommit(oldAutoCommit);
/*      */         
/* 2299 */         if (this.hasIsolationLevels) {
/* 2300 */           setTransactionIsolation(oldIsolationLevel);
/*      */         }
/*      */         
/* 2303 */         setCatalog(oldCatalog);
/*      */         
/* 2305 */         setReadOnly(oldReadOnly);
/*      */       }
/* 2307 */       return;
/*      */     }
/*      */     catch (Exception EEE)
/*      */     {
/* 2311 */       if (((EEE instanceof SQLException)) && (((SQLException)EEE).getErrorCode() == 1820) && (!getDisconnectOnExpiredPasswords()))
/*      */       {
/* 2313 */         return;
/*      */       }
/*      */       
/* 2316 */       if (this.io != null) {
/* 2317 */         this.io.forceClose();
/*      */       }
/*      */       
/* 2320 */       connectionNotEstablishedBecause = EEE;
/*      */       
/* 2322 */       if ((EEE instanceof SQLException)) {
/* 2323 */         throw ((SQLException)EEE);
/*      */       }
/*      */       
/* 2326 */       SQLException chainedEx = SQLError.createSQLException(Messages.getString("Connection.UnableToConnect"), "08001", getExceptionInterceptor());
/*      */       
/* 2328 */       chainedEx.initCause(connectionNotEstablishedBecause);
/*      */       
/* 2330 */       throw chainedEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private void createPreparedStatementCaches() throws SQLException {
/* 2335 */     synchronized (getConnectionMutex()) {
/* 2336 */       int cacheSize = getPreparedStatementCacheSize();
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 2341 */         Class<?> factoryClass = Class.forName(getParseInfoCacheFactory());
/*      */         
/*      */ 
/* 2344 */         CacheAdapterFactory<String, PreparedStatement.ParseInfo> cacheFactory = (CacheAdapterFactory)factoryClass.newInstance();
/*      */         
/* 2346 */         this.cachedPreparedStatementParams = cacheFactory.getInstance(this, this.myURL, getPreparedStatementCacheSize(), getPreparedStatementCacheSqlLimit(), this.props);
/*      */       }
/*      */       catch (ClassNotFoundException e)
/*      */       {
/* 2350 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantFindCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */         
/*      */ 
/* 2353 */         sqlEx.initCause(e);
/*      */         
/* 2355 */         throw sqlEx;
/*      */       } catch (InstantiationException e) {
/* 2357 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */         
/*      */ 
/* 2360 */         sqlEx.initCause(e);
/*      */         
/* 2362 */         throw sqlEx;
/*      */       } catch (IllegalAccessException e) {
/* 2364 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */         
/*      */ 
/* 2367 */         sqlEx.initCause(e);
/*      */         
/* 2369 */         throw sqlEx;
/*      */       }
/*      */       
/* 2372 */       if (getUseServerPreparedStmts()) {
/* 2373 */         this.serverSideStatementCheckCache = new LRUCache(cacheSize);
/*      */         
/* 2375 */         this.serverSideStatementCache = new LRUCache(cacheSize)
/*      */         {
/*      */           private static final long serialVersionUID = 7692318650375988114L;
/*      */           
/*      */           protected boolean removeEldestEntry(Map.Entry<Object, Object> eldest)
/*      */           {
/* 2381 */             if (this.maxElements <= 1) {
/* 2382 */               return false;
/*      */             }
/*      */             
/* 2385 */             boolean removeIt = super.removeEldestEntry(eldest);
/*      */             
/* 2387 */             if (removeIt) {
/* 2388 */               ServerPreparedStatement ps = (ServerPreparedStatement)eldest.getValue();
/* 2389 */               ps.isCached = false;
/* 2390 */               ps.setClosed(false);
/*      */               try
/*      */               {
/* 2393 */                 ps.close();
/*      */               }
/*      */               catch (SQLException sqlEx) {}
/*      */             }
/*      */             
/*      */ 
/* 2399 */             return removeIt;
/*      */           }
/*      */         };
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement()
/*      */     throws SQLException
/*      */   {
/* 2416 */     return createStatement(1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 2432 */     checkClosed();
/*      */     
/* 2434 */     StatementImpl stmt = new StatementImpl(getMultiHostSafeProxy(), this.database);
/* 2435 */     stmt.setResultSetType(resultSetType);
/* 2436 */     stmt.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 2438 */     return stmt;
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 2445 */     if ((getPedantic()) && 
/* 2446 */       (resultSetHoldability != 1)) {
/* 2447 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2452 */     return createStatement(resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public void dumpTestcaseQuery(String query) {
/* 2456 */     System.err.println(query);
/*      */   }
/*      */   
/*      */   public Connection duplicate() throws SQLException {
/* 2460 */     return new ConnectionImpl(this.origHostToConnectTo, this.origPortToConnectTo, this.props, this.origDatabaseToConnectTo, this.myURL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata)
/*      */     throws SQLException
/*      */   {
/* 2499 */     return execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata, false);
/*      */   }
/*      */   
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata, boolean isBatch) throws SQLException
/*      */   {
/* 2504 */     synchronized (getConnectionMutex())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2509 */       long queryStartTime = 0L;
/*      */       
/* 2511 */       int endOfQueryPacketPosition = 0;
/*      */       
/* 2513 */       if (packet != null) {
/* 2514 */         endOfQueryPacketPosition = packet.getPosition();
/*      */       }
/*      */       
/* 2517 */       if (getGatherPerformanceMetrics()) {
/* 2518 */         queryStartTime = System.currentTimeMillis();
/*      */       }
/*      */       
/* 2521 */       this.lastQueryFinishedTime = 0L;
/*      */       
/* 2523 */       if ((getHighAvailability()) && ((this.autoCommit) || (getAutoReconnectForPools())) && (this.needsPing) && (!isBatch)) {
/*      */         try {
/* 2525 */           pingInternal(false, 0);
/*      */           
/* 2527 */           this.needsPing = false;
/*      */         } catch (Exception Ex) {
/* 2529 */           createNewIO(true);
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 2534 */         if (packet == null) {
/* 2535 */           encoding = null;
/*      */           
/* 2537 */           if (getUseUnicode()) {
/* 2538 */             encoding = getEncoding();
/*      */           }
/*      */           
/* 2541 */           ResultSetInternalMethods localResultSetInternalMethods = this.io.sqlQueryDirect(callingStatement, sql, encoding, null, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);jsr 236;return localResultSetInternalMethods;
/*      */         }
/*      */         
/*      */ 
/* 2545 */         String encoding = this.io.sqlQueryDirect(callingStatement, null, null, packet, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);jsr 202;return encoding;
/*      */ 
/*      */       }
/*      */       catch (SQLException sqlE)
/*      */       {
/* 2550 */         if (getDumpQueriesOnException()) {
/* 2551 */           String extractedSql = extractSqlFromPacket(sql, packet, endOfQueryPacketPosition);
/* 2552 */           StringBuilder messageBuf = new StringBuilder(extractedSql.length() + 32);
/* 2553 */           messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
/* 2554 */           messageBuf.append(extractedSql);
/* 2555 */           messageBuf.append("\n\n");
/*      */           
/* 2557 */           sqlE = appendMessageToException(sqlE, messageBuf.toString(), getExceptionInterceptor());
/*      */         }
/*      */         
/* 2560 */         if (getHighAvailability()) {
/* 2561 */           this.needsPing = true;
/*      */         } else {
/* 2563 */           String sqlState = sqlE.getSQLState();
/*      */           
/* 2565 */           if ((sqlState != null) && (sqlState.equals("08S01"))) {
/* 2566 */             cleanup(sqlE);
/*      */           }
/*      */         }
/*      */         
/* 2570 */         throw sqlE;
/*      */       } catch (Exception ex) {
/* 2572 */         if (getHighAvailability()) {
/* 2573 */           this.needsPing = true;
/* 2574 */         } else if ((ex instanceof IOException)) {
/* 2575 */           cleanup(ex);
/*      */         }
/*      */         
/* 2578 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.UnexpectedException"), "S1000", getExceptionInterceptor());
/*      */         
/* 2580 */         sqlEx.initCause(ex);
/*      */         
/* 2582 */         throw sqlEx;
/*      */       } finally {
/* 2584 */         jsr 6; } localObject2 = returnAddress; if (getMaintainTimeStats()) {
/* 2585 */         this.lastQueryFinishedTime = System.currentTimeMillis();
/*      */       }
/*      */       
/* 2588 */       if (getGatherPerformanceMetrics()) {
/* 2589 */         long queryTime = System.currentTimeMillis() - queryStartTime;
/*      */         
/* 2591 */         registerQueryExecutionTime(queryTime); }
/* 2592 */       ret;
/*      */     }
/*      */   }
/*      */   
/*      */   public String extractSqlFromPacket(String possibleSqlQuery, Buffer queryPacket, int endOfQueryPacketPosition)
/*      */     throws SQLException
/*      */   {
/* 2599 */     String extractedSql = null;
/*      */     
/* 2601 */     if (possibleSqlQuery != null) {
/* 2602 */       if (possibleSqlQuery.length() > getMaxQuerySizeToLog()) {
/* 2603 */         StringBuilder truncatedQueryBuf = new StringBuilder(possibleSqlQuery.substring(0, getMaxQuerySizeToLog()));
/* 2604 */         truncatedQueryBuf.append(Messages.getString("MysqlIO.25"));
/* 2605 */         extractedSql = truncatedQueryBuf.toString();
/*      */       } else {
/* 2607 */         extractedSql = possibleSqlQuery;
/*      */       }
/*      */     }
/*      */     
/* 2611 */     if (extractedSql == null)
/*      */     {
/*      */ 
/* 2614 */       int extractPosition = endOfQueryPacketPosition;
/*      */       
/* 2616 */       boolean truncated = false;
/*      */       
/* 2618 */       if (endOfQueryPacketPosition > getMaxQuerySizeToLog()) {
/* 2619 */         extractPosition = getMaxQuerySizeToLog();
/* 2620 */         truncated = true;
/*      */       }
/*      */       
/* 2623 */       extractedSql = StringUtils.toString(queryPacket.getByteBuffer(), 5, extractPosition - 5);
/*      */       
/* 2625 */       if (truncated) {
/* 2626 */         extractedSql = extractedSql + Messages.getString("MysqlIO.25");
/*      */       }
/*      */     }
/*      */     
/* 2630 */     return extractedSql;
/*      */   }
/*      */   
/*      */   public StringBuilder generateConnectionCommentBlock(StringBuilder buf)
/*      */   {
/* 2635 */     buf.append("/* conn id ");
/* 2636 */     buf.append(getId());
/* 2637 */     buf.append(" clock: ");
/* 2638 */     buf.append(System.currentTimeMillis());
/* 2639 */     buf.append(" */ ");
/*      */     
/* 2641 */     return buf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 2674 */     if (getDynamicCalendars()) {
/* 2675 */       return Calendar.getInstance();
/*      */     }
/*      */     
/* 2678 */     return getSessionLockedCalendar();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SingleByteCharsetConverter getCharsetConverter(String javaEncodingName)
/*      */     throws SQLException
/*      */   {
/* 2716 */     if (javaEncodingName == null) {
/* 2717 */       return null;
/*      */     }
/*      */     
/* 2720 */     if (this.usePlatformCharsetConverters) {
/* 2721 */       return null;
/*      */     }
/*      */     
/* 2724 */     SingleByteCharsetConverter converter = null;
/*      */     
/* 2726 */     synchronized (this.charsetConverterMap) {
/* 2727 */       Object asObject = this.charsetConverterMap.get(javaEncodingName);
/*      */       
/* 2729 */       if (asObject == CHARSET_CONVERTER_NOT_AVAILABLE_MARKER) {
/* 2730 */         return null;
/*      */       }
/*      */       
/* 2733 */       converter = (SingleByteCharsetConverter)asObject;
/*      */       
/* 2735 */       if (converter == null) {
/*      */         try {
/* 2737 */           converter = SingleByteCharsetConverter.getInstance(javaEncodingName, this);
/*      */           
/* 2739 */           if (converter == null) {
/* 2740 */             this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */           } else {
/* 2742 */             this.charsetConverterMap.put(javaEncodingName, converter);
/*      */           }
/*      */         } catch (UnsupportedEncodingException unsupEncEx) {
/* 2745 */           this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */           
/* 2747 */           converter = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2752 */     return converter;
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public String getCharsetNameForIndex(int charsetIndex)
/*      */     throws SQLException
/*      */   {
/* 2760 */     return getEncodingForIndex(charsetIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncodingForIndex(int charsetIndex)
/*      */     throws SQLException
/*      */   {
/* 2774 */     String javaEncoding = null;
/*      */     
/* 2776 */     if (getUseOldUTF8Behavior()) {
/* 2777 */       return getEncoding();
/*      */     }
/*      */     
/* 2780 */     if (charsetIndex != -1) {
/*      */       try {
/* 2782 */         if (this.indexToMysqlCharset.size() > 0) {
/* 2783 */           javaEncoding = CharsetMapping.getJavaEncodingForMysqlCharset((String)this.indexToMysqlCharset.get(Integer.valueOf(charsetIndex)), getEncoding());
/*      */         }
/*      */         
/* 2786 */         if (javaEncoding == null) {
/* 2787 */           javaEncoding = CharsetMapping.getJavaEncodingForCollationIndex(Integer.valueOf(charsetIndex), getEncoding());
/*      */         }
/*      */       }
/*      */       catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 2791 */         throw SQLError.createSQLException("Unknown character set index for field '" + charsetIndex + "' received from server.", "S1000", getExceptionInterceptor());
/*      */       }
/*      */       catch (RuntimeException ex) {
/* 2794 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 2795 */         sqlEx.initCause(ex);
/* 2796 */         throw sqlEx;
/*      */       }
/*      */       
/*      */ 
/* 2800 */       if (javaEncoding == null) {
/* 2801 */         javaEncoding = getEncoding();
/*      */       }
/*      */     } else {
/* 2804 */       javaEncoding = getEncoding();
/*      */     }
/*      */     
/* 2807 */     return javaEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public TimeZone getDefaultTimeZone()
/*      */   {
/* 2815 */     return getCacheDefaultTimezone() ? this.defaultTimeZone : TimeUtil.getDefaultTimeZone(false);
/*      */   }
/*      */   
/*      */   public String getErrorMessageEncoding() {
/* 2819 */     return this.errorMessageEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getHoldability()
/*      */     throws SQLException
/*      */   {
/* 2826 */     return 2;
/*      */   }
/*      */   
/*      */   public long getId() {
/* 2830 */     return this.connectionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getIdleFor()
/*      */   {
/* 2842 */     synchronized (getConnectionMutex()) {
/* 2843 */       if (this.lastQueryFinishedTime == 0L) {
/* 2844 */         return 0L;
/*      */       }
/*      */       
/* 2847 */       long now = System.currentTimeMillis();
/* 2848 */       long idleTime = now - this.lastQueryFinishedTime;
/*      */       
/* 2850 */       return idleTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MysqlIO getIO()
/*      */     throws SQLException
/*      */   {
/* 2862 */     if ((this.io == null) || (this.isClosed)) {
/* 2863 */       throw SQLError.createSQLException("Operation not allowed on closed connection", "08003", getExceptionInterceptor());
/*      */     }
/*      */     
/* 2866 */     return this.io;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Log getLog()
/*      */     throws SQLException
/*      */   {
/* 2878 */     return this.log;
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(String javaCharsetName) throws SQLException {
/* 2882 */     return getMaxBytesPerChar(null, javaCharsetName);
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(Integer charsetIndex, String javaCharsetName) throws SQLException
/*      */   {
/* 2887 */     String charset = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 2894 */       if (this.indexToCustomMysqlCharset != null) {
/* 2895 */         charset = (String)this.indexToCustomMysqlCharset.get(charsetIndex);
/*      */       }
/*      */       
/* 2898 */       if (charset == null) {
/* 2899 */         charset = CharsetMapping.getMysqlCharsetNameForCollationIndex(charsetIndex);
/*      */       }
/*      */       
/*      */ 
/* 2903 */       if (charset == null) {
/* 2904 */         charset = CharsetMapping.getMysqlCharsetForJavaEncoding(javaCharsetName, this);
/*      */       }
/*      */       
/*      */ 
/* 2908 */       Integer mblen = null;
/* 2909 */       if (this.mysqlCharsetToCustomMblen != null) {
/* 2910 */         mblen = (Integer)this.mysqlCharsetToCustomMblen.get(charset);
/*      */       }
/*      */       
/*      */ 
/* 2914 */       if (mblen == null) {
/* 2915 */         mblen = Integer.valueOf(CharsetMapping.getMblen(charset));
/*      */       }
/*      */       
/* 2918 */       if (mblen != null) {
/* 2919 */         return mblen.intValue();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 2922 */       throw ex;
/*      */     } catch (RuntimeException ex) {
/* 2924 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 2925 */       sqlEx.initCause(ex);
/* 2926 */       throw sqlEx;
/*      */     }
/*      */     
/* 2929 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.DatabaseMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 2943 */     return getMetaData(true, true);
/*      */   }
/*      */   
/*      */   private java.sql.DatabaseMetaData getMetaData(boolean checkClosed, boolean checkForInfoSchema) throws SQLException {
/* 2947 */     if (checkClosed) {
/* 2948 */       checkClosed();
/*      */     }
/*      */     
/* 2951 */     return DatabaseMetaData.getInstance(getMultiHostSafeProxy(), this.database, checkForInfoSchema);
/*      */   }
/*      */   
/*      */   public java.sql.Statement getMetadataSafeStatement() throws SQLException {
/* 2955 */     java.sql.Statement stmt = createStatement();
/*      */     
/* 2957 */     if (stmt.getMaxRows() != 0) {
/* 2958 */       stmt.setMaxRows(0);
/*      */     }
/*      */     
/* 2961 */     stmt.setEscapeProcessing(false);
/*      */     
/* 2963 */     if (stmt.getFetchSize() != 0) {
/* 2964 */       stmt.setFetchSize(0);
/*      */     }
/*      */     
/* 2967 */     return stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getNetBufferLength()
/*      */   {
/* 2974 */     return this.netBufferLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getServerCharacterEncoding()
/*      */   {
/* 2982 */     return getServerCharset();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServerCharset()
/*      */   {
/* 2991 */     if (this.io.versionMeetsMinimum(4, 1, 0)) {
/* 2992 */       String charset = null;
/* 2993 */       if (this.indexToCustomMysqlCharset != null) {
/* 2994 */         charset = (String)this.indexToCustomMysqlCharset.get(Integer.valueOf(this.io.serverCharsetIndex));
/*      */       }
/* 2996 */       if (charset == null) {
/* 2997 */         charset = CharsetMapping.getMysqlCharsetNameForCollationIndex(Integer.valueOf(this.io.serverCharsetIndex));
/*      */       }
/* 2999 */       return charset != null ? charset : (String)this.serverVariables.get("character_set_server");
/*      */     }
/* 3001 */     return (String)this.serverVariables.get("character_set");
/*      */   }
/*      */   
/*      */   public int getServerMajorVersion() {
/* 3005 */     return this.io.getServerMajorVersion();
/*      */   }
/*      */   
/*      */   public int getServerMinorVersion() {
/* 3009 */     return this.io.getServerMinorVersion();
/*      */   }
/*      */   
/*      */   public int getServerSubMinorVersion() {
/* 3013 */     return this.io.getServerSubMinorVersion();
/*      */   }
/*      */   
/*      */   public TimeZone getServerTimezoneTZ() {
/* 3017 */     return this.serverTimezoneTZ;
/*      */   }
/*      */   
/*      */   public String getServerVariable(String variableName) {
/* 3021 */     if (this.serverVariables != null) {
/* 3022 */       return (String)this.serverVariables.get(variableName);
/*      */     }
/*      */     
/* 3025 */     return null;
/*      */   }
/*      */   
/*      */   public String getServerVersion() {
/* 3029 */     return this.io.getServerVersion();
/*      */   }
/*      */   
/*      */   public Calendar getSessionLockedCalendar()
/*      */   {
/* 3034 */     return this.sessionCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/* 3046 */     synchronized (getConnectionMutex()) {
/* 3047 */       if ((this.hasIsolationLevels) && (!getUseLocalSessionState())) {
/* 3048 */         java.sql.Statement stmt = null;
/* 3049 */         ResultSet rs = null;
/*      */         try
/*      */         {
/* 3052 */           stmt = getMetadataSafeStatement();
/*      */           
/* 3054 */           String query = null;
/*      */           
/* 3056 */           int offset = 0;
/*      */           
/* 3058 */           if (versionMeetsMinimum(4, 0, 3)) {
/* 3059 */             query = "SELECT @@session.tx_isolation";
/* 3060 */             offset = 1;
/*      */           } else {
/* 3062 */             query = "SHOW VARIABLES LIKE 'transaction_isolation'";
/* 3063 */             offset = 2;
/*      */           }
/*      */           
/* 3066 */           rs = stmt.executeQuery(query);
/*      */           
/* 3068 */           if (rs.next()) {
/* 3069 */             String s = rs.getString(offset);
/*      */             
/* 3071 */             if (s != null) {
/* 3072 */               Integer intTI = (Integer)mapTransIsolationNameToValue.get(s);
/*      */               
/* 3074 */               if (intTI != null) {
/* 3075 */                 int i = intTI.intValue();jsr 68;return i;
/*      */               }
/*      */             }
/*      */             
/* 3079 */             throw SQLError.createSQLException("Could not map transaction isolation '" + s + " to a valid JDBC level.", "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 3083 */           throw SQLError.createSQLException("Could not retrieve transaction isolation level from server", "S1000", getExceptionInterceptor());
/*      */         }
/*      */         finally
/*      */         {
/* 3087 */           jsr 6; } localObject2 = returnAddress; if (rs != null) {
/*      */           try {
/* 3089 */             rs.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */           
/*      */ 
/* 3094 */           rs = null;
/*      */         }
/*      */         
/* 3097 */         if (stmt != null) {
/*      */           try {
/* 3099 */             stmt.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */           
/*      */ 
/* 3104 */           stmt = null; } ret;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3109 */       return this.isolationLevel;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, Class<?>> getTypeMap()
/*      */     throws SQLException
/*      */   {
/* 3122 */     synchronized (getConnectionMutex()) {
/* 3123 */       if (this.typeMap == null) {
/* 3124 */         this.typeMap = new HashMap();
/*      */       }
/*      */       
/* 3127 */       return this.typeMap;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getURL() {
/* 3132 */     return this.myURL;
/*      */   }
/*      */   
/*      */   public String getUser() {
/* 3136 */     return this.user;
/*      */   }
/*      */   
/*      */   public Calendar getUtcCalendar() {
/* 3140 */     return this.utcCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 3153 */     return null;
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(Connection c) {
/* 3157 */     return this.props.equals(c.getProperties());
/*      */   }
/*      */   
/*      */   public Properties getProperties() {
/* 3161 */     return this.props;
/*      */   }
/*      */   
/*      */   public boolean hasTriedMaster() {
/* 3165 */     return this.hasTriedMasterFlag;
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPreparedExecutes() {
/* 3169 */     if (getGatherPerformanceMetrics()) {
/* 3170 */       this.numberOfPreparedExecutes += 1L;
/*      */       
/*      */ 
/* 3173 */       this.numberOfQueriesIssued += 1L;
/*      */     }
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPrepares() {
/* 3178 */     if (getGatherPerformanceMetrics()) {
/* 3179 */       this.numberOfPrepares += 1L;
/*      */     }
/*      */   }
/*      */   
/*      */   public void incrementNumberOfResultSetsCreated() {
/* 3184 */     if (getGatherPerformanceMetrics()) {
/* 3185 */       this.numberOfResultSetsCreated += 1L;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initializeDriverProperties(Properties info)
/*      */     throws SQLException
/*      */   {
/* 3197 */     initializeProperties(info);
/*      */     
/* 3199 */     String exceptionInterceptorClasses = getExceptionInterceptors();
/*      */     
/* 3201 */     if ((exceptionInterceptorClasses != null) && (!"".equals(exceptionInterceptorClasses))) {
/* 3202 */       this.exceptionInterceptor = new ExceptionInterceptorChain(exceptionInterceptorClasses);
/*      */     }
/*      */     
/* 3205 */     this.usePlatformCharsetConverters = getUseJvmCharsetConverters();
/*      */     
/* 3207 */     this.log = LogFactory.getLogger(getLogger(), "MySQL", getExceptionInterceptor());
/*      */     
/* 3209 */     if ((getProfileSql()) || (getUseUsageAdvisor())) {
/* 3210 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(getMultiHostSafeProxy());
/*      */     }
/*      */     
/* 3213 */     if (getCachePreparedStatements()) {
/* 3214 */       createPreparedStatementCaches();
/*      */     }
/*      */     
/* 3217 */     if ((getNoDatetimeStringSync()) && (getUseTimezone())) {
/* 3218 */       throw SQLError.createSQLException("Can't enable noDatetimeStringSync and useTimezone configuration properties at the same time", "01S00", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3222 */     if (getCacheCallableStatements()) {
/* 3223 */       this.parsedCallableStatementCache = new LRUCache(getCallableStatementCacheSize());
/*      */     }
/*      */     
/* 3226 */     if (getAllowMultiQueries()) {
/* 3227 */       setCacheResultSetMetadata(false);
/*      */     }
/*      */     
/* 3230 */     if (getCacheResultSetMetadata()) {
/* 3231 */       this.resultSetMetadataCache = new LRUCache(getMetadataCacheSize());
/*      */     }
/*      */     
/* 3234 */     if (getSocksProxyHost() != null) {
/* 3235 */       setSocketFactoryClassName("com.mysql.jdbc.SocksProxySocketFactory");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initializePropsFromServer()
/*      */     throws SQLException
/*      */   {
/* 3247 */     String connectionInterceptorClasses = getConnectionLifecycleInterceptors();
/*      */     
/* 3249 */     this.connectionLifecycleInterceptors = null;
/*      */     
/* 3251 */     if (connectionInterceptorClasses != null) {
/* 3252 */       this.connectionLifecycleInterceptors = Util.loadExtensions(this, this.props, connectionInterceptorClasses, "Connection.badLifecycleInterceptor", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3256 */     setSessionVariables();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3262 */     if (!versionMeetsMinimum(4, 1, 0)) {
/* 3263 */       setTransformedBitIsBoolean(false);
/*      */     }
/*      */     
/* 3266 */     this.parserKnowsUnicode = versionMeetsMinimum(4, 1, 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3271 */     if ((getUseServerPreparedStmts()) && (versionMeetsMinimum(4, 1, 0))) {
/* 3272 */       this.useServerPreparedStmts = true;
/*      */       
/* 3274 */       if ((versionMeetsMinimum(5, 0, 0)) && (!versionMeetsMinimum(5, 0, 3))) {
/* 3275 */         this.useServerPreparedStmts = false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3283 */     if (versionMeetsMinimum(3, 21, 22)) {
/* 3284 */       loadServerVariables();
/*      */       
/* 3286 */       if (versionMeetsMinimum(5, 0, 2)) {
/* 3287 */         this.autoIncrementIncrement = getServerVariableAsInt("auto_increment_increment", 1);
/*      */       } else {
/* 3289 */         this.autoIncrementIncrement = 1;
/*      */       }
/*      */       
/* 3292 */       buildCollationMapping();
/*      */       
/* 3294 */       LicenseConfiguration.checkLicenseType(this.serverVariables);
/*      */       
/* 3296 */       String lowerCaseTables = (String)this.serverVariables.get("lower_case_table_names");
/*      */       
/* 3298 */       this.lowerCaseTableNames = (("on".equalsIgnoreCase(lowerCaseTables)) || ("1".equalsIgnoreCase(lowerCaseTables)) || ("2".equalsIgnoreCase(lowerCaseTables)));
/*      */       
/* 3300 */       this.storesLowerCaseTableName = (("1".equalsIgnoreCase(lowerCaseTables)) || ("on".equalsIgnoreCase(lowerCaseTables)));
/*      */       
/* 3302 */       configureTimezone();
/*      */       
/* 3304 */       if (this.serverVariables.containsKey("max_allowed_packet")) {
/* 3305 */         int serverMaxAllowedPacket = getServerVariableAsInt("max_allowed_packet", -1);
/*      */         
/* 3307 */         if ((serverMaxAllowedPacket != -1) && ((serverMaxAllowedPacket < getMaxAllowedPacket()) || (getMaxAllowedPacket() <= 0))) {
/* 3308 */           setMaxAllowedPacket(serverMaxAllowedPacket);
/* 3309 */         } else if ((serverMaxAllowedPacket == -1) && (getMaxAllowedPacket() == -1)) {
/* 3310 */           setMaxAllowedPacket(65535);
/*      */         }
/*      */         
/* 3313 */         if (getUseServerPrepStmts()) {
/* 3314 */           int preferredBlobSendChunkSize = getBlobSendChunkSize();
/*      */           
/*      */ 
/* 3317 */           int packetHeaderSize = 8203;
/* 3318 */           int allowedBlobSendChunkSize = Math.min(preferredBlobSendChunkSize, getMaxAllowedPacket()) - packetHeaderSize;
/*      */           
/* 3320 */           if (allowedBlobSendChunkSize <= 0) {
/* 3321 */             throw SQLError.createSQLException("Connection setting too low for 'maxAllowedPacket'. When 'useServerPrepStmts=true', 'maxAllowedPacket' must be higher than " + packetHeaderSize + ". Check also 'max_allowed_packet' in MySQL configuration files.", "01S00", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3327 */           setBlobSendChunkSize(String.valueOf(allowedBlobSendChunkSize));
/*      */         }
/*      */       }
/*      */       
/* 3331 */       if (this.serverVariables.containsKey("net_buffer_length")) {
/* 3332 */         this.netBufferLength = getServerVariableAsInt("net_buffer_length", 16384);
/*      */       }
/*      */       
/* 3335 */       checkTransactionIsolationLevel();
/*      */       
/* 3337 */       if (!versionMeetsMinimum(4, 1, 0)) {
/* 3338 */         checkServerEncoding();
/*      */       }
/*      */       
/* 3341 */       this.io.checkForCharsetMismatch();
/*      */       
/* 3343 */       if (this.serverVariables.containsKey("sql_mode")) {
/* 3344 */         int sqlMode = 0;
/*      */         
/* 3346 */         String sqlModeAsString = (String)this.serverVariables.get("sql_mode");
/*      */         try {
/* 3348 */           sqlMode = Integer.parseInt(sqlModeAsString);
/*      */         }
/*      */         catch (NumberFormatException nfe) {
/* 3351 */           sqlMode = 0;
/*      */           
/* 3353 */           if (sqlModeAsString != null) {
/* 3354 */             if (sqlModeAsString.indexOf("ANSI_QUOTES") != -1) {
/* 3355 */               sqlMode |= 0x4;
/*      */             }
/*      */             
/* 3358 */             if (sqlModeAsString.indexOf("NO_BACKSLASH_ESCAPES") != -1) {
/* 3359 */               this.noBackslashEscapes = true;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 3364 */         if ((sqlMode & 0x4) > 0) {
/* 3365 */           this.useAnsiQuotes = true;
/*      */         } else {
/* 3367 */           this.useAnsiQuotes = false;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3372 */     boolean overrideDefaultAutocommit = isAutoCommitNonDefaultOnServer();
/*      */     
/* 3374 */     configureClientCharacterSet(false);
/*      */     try
/*      */     {
/* 3377 */       this.errorMessageEncoding = CharsetMapping.getCharacterEncodingForErrorMessages(this);
/*      */     } catch (SQLException ex) {
/* 3379 */       throw ex;
/*      */     } catch (RuntimeException ex) {
/* 3381 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 3382 */       sqlEx.initCause(ex);
/* 3383 */       throw sqlEx;
/*      */     }
/*      */     
/* 3386 */     if (versionMeetsMinimum(3, 23, 15)) {
/* 3387 */       this.transactionsSupported = true;
/*      */       
/* 3389 */       if (!overrideDefaultAutocommit) {
/*      */         try {
/* 3391 */           setAutoCommit(true);
/*      */         } catch (SQLException ex) {
/* 3393 */           if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/* 3394 */             throw ex;
/*      */           }
/*      */         }
/*      */       }
/*      */     } else {
/* 3399 */       this.transactionsSupported = false;
/*      */     }
/*      */     
/* 3402 */     if (versionMeetsMinimum(3, 23, 36)) {
/* 3403 */       this.hasIsolationLevels = true;
/*      */     } else {
/* 3405 */       this.hasIsolationLevels = false;
/*      */     }
/*      */     
/* 3408 */     this.hasQuotedIdentifiers = versionMeetsMinimum(3, 23, 6);
/*      */     
/* 3410 */     this.io.resetMaxBuf();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3416 */     if (this.io.versionMeetsMinimum(4, 1, 0)) {
/* 3417 */       String characterSetResultsOnServerMysql = (String)this.serverVariables.get("jdbc.local.character_set_results");
/*      */       
/* 3419 */       if ((characterSetResultsOnServerMysql == null) || (StringUtils.startsWithIgnoreCaseAndWs(characterSetResultsOnServerMysql, "NULL")) || (characterSetResultsOnServerMysql.length() == 0))
/*      */       {
/* 3421 */         String defaultMetadataCharsetMysql = (String)this.serverVariables.get("character_set_system");
/* 3422 */         String defaultMetadataCharset = null;
/*      */         
/* 3424 */         if (defaultMetadataCharsetMysql != null) {
/* 3425 */           defaultMetadataCharset = CharsetMapping.getJavaEncodingForMysqlCharset(defaultMetadataCharsetMysql);
/*      */         } else {
/* 3427 */           defaultMetadataCharset = "UTF-8";
/*      */         }
/*      */         
/* 3430 */         this.characterSetMetadata = defaultMetadataCharset;
/*      */       } else {
/* 3432 */         this.characterSetResultsOnServer = CharsetMapping.getJavaEncodingForMysqlCharset(characterSetResultsOnServerMysql);
/* 3433 */         this.characterSetMetadata = this.characterSetResultsOnServer;
/*      */       }
/*      */     } else {
/* 3436 */       this.characterSetMetadata = getEncoding();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3443 */     if ((versionMeetsMinimum(4, 1, 0)) && (!versionMeetsMinimum(4, 1, 10)) && (getAllowMultiQueries()) && 
/* 3444 */       (isQueryCacheEnabled())) {
/* 3445 */       setAllowMultiQueries(false);
/*      */     }
/*      */     
/*      */ 
/* 3449 */     if ((versionMeetsMinimum(5, 0, 0)) && ((getUseLocalTransactionState()) || (getElideSetAutoCommits())) && (isQueryCacheEnabled()) && (!versionMeetsMinimum(6, 0, 10)))
/*      */     {
/*      */ 
/* 3452 */       setUseLocalTransactionState(false);
/* 3453 */       setElideSetAutoCommits(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3460 */     setupServerForTruncationChecks();
/*      */   }
/*      */   
/*      */   private boolean isQueryCacheEnabled() {
/* 3464 */     return ("ON".equalsIgnoreCase((String)this.serverVariables.get("query_cache_type"))) && (!"0".equalsIgnoreCase((String)this.serverVariables.get("query_cache_size")));
/*      */   }
/*      */   
/*      */   private int getServerVariableAsInt(String variableName, int fallbackValue) throws SQLException {
/*      */     try {
/* 3469 */       return Integer.parseInt((String)this.serverVariables.get(variableName));
/*      */     } catch (NumberFormatException nfe) {
/* 3471 */       getLog().logWarn(Messages.getString("Connection.BadValueInServerVariables", new Object[] { variableName, this.serverVariables.get(variableName), Integer.valueOf(fallbackValue) }));
/*      */     }
/*      */     
/*      */ 
/* 3475 */     return fallbackValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isAutoCommitNonDefaultOnServer()
/*      */     throws SQLException
/*      */   {
/* 3488 */     boolean overrideDefaultAutocommit = false;
/*      */     
/* 3490 */     String initConnectValue = (String)this.serverVariables.get("init_connect");
/*      */     
/* 3492 */     if ((versionMeetsMinimum(4, 1, 2)) && (initConnectValue != null) && (initConnectValue.length() > 0)) {
/* 3493 */       if (!getElideSetAutoCommits())
/*      */       {
/* 3495 */         ResultSet rs = null;
/* 3496 */         java.sql.Statement stmt = null;
/*      */         try
/*      */         {
/* 3499 */           stmt = getMetadataSafeStatement();
/*      */           
/* 3501 */           rs = stmt.executeQuery("SELECT @@session.autocommit");
/*      */           
/* 3503 */           if (rs.next()) {
/* 3504 */             this.autoCommit = rs.getBoolean(1);
/* 3505 */             if (this.autoCommit != true) {
/* 3506 */               overrideDefaultAutocommit = true;
/*      */             }
/*      */           }
/*      */         }
/*      */         finally {
/* 3511 */           if (rs != null) {
/*      */             try {
/* 3513 */               rs.close();
/*      */             }
/*      */             catch (SQLException sqlEx) {}
/*      */           }
/*      */           
/*      */ 
/* 3519 */           if (stmt != null) {
/*      */             try {
/* 3521 */               stmt.close();
/*      */ 
/*      */             }
/*      */             catch (SQLException sqlEx) {}
/*      */           }
/*      */         }
/*      */       }
/* 3528 */       else if (getIO().isSetNeededForAutoCommitMode(true))
/*      */       {
/* 3530 */         this.autoCommit = false;
/* 3531 */         overrideDefaultAutocommit = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3536 */     return overrideDefaultAutocommit;
/*      */   }
/*      */   
/*      */   public boolean isClientTzUTC() {
/* 3540 */     return this.isClientTzUTC;
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/* 3544 */     return this.isClosed;
/*      */   }
/*      */   
/*      */   public boolean isCursorFetchEnabled() throws SQLException {
/* 3548 */     return (versionMeetsMinimum(5, 0, 2)) && (getUseCursorFetch());
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx() {
/* 3552 */     return this.isInGlobalTx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNoBackslashEscapesSet()
/*      */   {
/* 3575 */     return this.noBackslashEscapes;
/*      */   }
/*      */   
/*      */   public boolean isReadInfoMsgEnabled() {
/* 3579 */     return this.readInfoMsg;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/* 3592 */     return isReadOnly(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRunningOnJDK13()
/*      */   {
/* 3655 */     return this.isRunningOnJDK13;
/*      */   }
/*      */   
/*      */   public boolean isSameResource(Connection otherConnection) {
/* 3659 */     synchronized (getConnectionMutex()) {
/* 3660 */       if (otherConnection == null) {
/* 3661 */         return false;
/*      */       }
/*      */       
/* 3664 */       boolean directCompare = true;
/*      */       
/* 3666 */       String otherHost = ((ConnectionImpl)otherConnection).origHostToConnectTo;
/* 3667 */       String otherOrigDatabase = ((ConnectionImpl)otherConnection).origDatabaseToConnectTo;
/* 3668 */       String otherCurrentCatalog = ((ConnectionImpl)otherConnection).database;
/*      */       
/* 3670 */       if (!nullSafeCompare(otherHost, this.origHostToConnectTo)) {
/* 3671 */         directCompare = false;
/* 3672 */       } else if ((otherHost != null) && (otherHost.indexOf(',') == -1) && (otherHost.indexOf(':') == -1))
/*      */       {
/* 3674 */         directCompare = ((ConnectionImpl)otherConnection).origPortToConnectTo == this.origPortToConnectTo;
/*      */       }
/*      */       
/* 3677 */       if ((directCompare) && (
/* 3678 */         (!nullSafeCompare(otherOrigDatabase, this.origDatabaseToConnectTo)) || (!nullSafeCompare(otherCurrentCatalog, this.database)))) {
/* 3679 */         directCompare = false;
/*      */       }
/*      */       
/*      */ 
/* 3683 */       if (directCompare) {
/* 3684 */         return true;
/*      */       }
/*      */       
/*      */ 
/* 3688 */       String otherResourceId = ((ConnectionImpl)otherConnection).getResourceId();
/* 3689 */       String myResourceId = getResourceId();
/*      */       
/* 3691 */       if ((otherResourceId != null) || (myResourceId != null)) {
/* 3692 */         directCompare = nullSafeCompare(otherResourceId, myResourceId);
/*      */         
/* 3694 */         if (directCompare) {
/* 3695 */           return true;
/*      */         }
/*      */       }
/*      */       
/* 3699 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isServerTzUTC() {
/* 3704 */     return this.isServerTzUTC;
/*      */   }
/*      */   
/* 3707 */   private boolean usingCachedConfig = false;
/*      */   private static final String SERVER_VERSION_STRING_VAR_NAME = "server_version_string";
/*      */   
/* 3710 */   private void createConfigCacheIfNeeded() throws SQLException { synchronized (getConnectionMutex()) {
/* 3711 */       if (this.serverConfigCache != null) {
/* 3712 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 3718 */         Class<?> factoryClass = Class.forName(getServerConfigCacheFactory());
/*      */         
/*      */ 
/* 3721 */         CacheAdapterFactory<String, Map<String, String>> cacheFactory = (CacheAdapterFactory)factoryClass.newInstance();
/*      */         
/* 3723 */         this.serverConfigCache = cacheFactory.getInstance(this, this.myURL, Integer.MAX_VALUE, Integer.MAX_VALUE, this.props);
/*      */         
/* 3725 */         ExceptionInterceptor evictOnCommsError = new ExceptionInterceptor()
/*      */         {
/*      */           public void init(Connection conn, Properties config)
/*      */             throws SQLException
/*      */           {}
/*      */           
/*      */           public void destroy() {}
/*      */           
/*      */           public SQLException interceptException(SQLException sqlEx, Connection conn)
/*      */           {
/* 3735 */             if ((sqlEx.getSQLState() != null) && (sqlEx.getSQLState().startsWith("08"))) {
/* 3736 */               ConnectionImpl.this.serverConfigCache.invalidate(ConnectionImpl.this.getURL());
/*      */             }
/* 3738 */             return null;
/*      */           }
/*      */         };
/*      */         
/* 3742 */         if (this.exceptionInterceptor == null) {
/* 3743 */           this.exceptionInterceptor = evictOnCommsError;
/*      */         } else {
/* 3745 */           ((ExceptionInterceptorChain)this.exceptionInterceptor).addRingZero(evictOnCommsError);
/*      */         }
/*      */       } catch (ClassNotFoundException e) {
/* 3748 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantFindCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */         
/*      */ 
/* 3751 */         sqlEx.initCause(e);
/*      */         
/* 3753 */         throw sqlEx;
/*      */       } catch (InstantiationException e) {
/* 3755 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */         
/*      */ 
/* 3758 */         sqlEx.initCause(e);
/*      */         
/* 3760 */         throw sqlEx;
/*      */       } catch (IllegalAccessException e) {
/* 3762 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] { getParseInfoCacheFactory(), "parseInfoCacheFactory" }), getExceptionInterceptor());
/*      */         
/*      */ 
/* 3765 */         sqlEx.initCause(e);
/*      */         
/* 3767 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void loadServerVariables()
/*      */     throws SQLException
/*      */   {
/* 3783 */     if (getCacheServerConfiguration()) {
/* 3784 */       createConfigCacheIfNeeded();
/*      */       
/* 3786 */       Map<String, String> cachedVariableMap = (Map)this.serverConfigCache.get(getURL());
/*      */       
/* 3788 */       if (cachedVariableMap != null) {
/* 3789 */         String cachedServerVersion = (String)cachedVariableMap.get("server_version_string");
/*      */         
/* 3791 */         if ((cachedServerVersion != null) && (this.io.getServerVersion() != null) && (cachedServerVersion.equals(this.io.getServerVersion()))) {
/* 3792 */           this.serverVariables = cachedVariableMap;
/* 3793 */           this.usingCachedConfig = true;
/*      */           
/* 3795 */           return;
/*      */         }
/*      */         
/* 3798 */         this.serverConfigCache.invalidate(getURL());
/*      */       }
/*      */     }
/*      */     
/* 3802 */     java.sql.Statement stmt = null;
/* 3803 */     ResultSet results = null;
/*      */     try
/*      */     {
/* 3806 */       stmt = getMetadataSafeStatement();
/*      */       
/* 3808 */       String version = this.dbmd.getDriverVersion();
/*      */       
/* 3810 */       if ((version != null) && (version.indexOf('*') != -1)) {
/* 3811 */         StringBuilder buf = new StringBuilder(version.length() + 10);
/*      */         
/* 3813 */         for (int i = 0; i < version.length(); i++) {
/* 3814 */           char c = version.charAt(i);
/*      */           
/* 3816 */           if (c == '*') {
/* 3817 */             buf.append("[star]");
/*      */           } else {
/* 3819 */             buf.append(c);
/*      */           }
/*      */         }
/*      */         
/* 3823 */         version = buf.toString();
/*      */       }
/*      */       
/* 3826 */       String versionComment = "/* " + version + " */";
/*      */       
/* 3828 */       this.serverVariables = new HashMap();
/*      */       try
/*      */       {
/*      */         int col;
/* 3832 */         if (versionMeetsMinimum(5, 0, 3))
/*      */         {
/* 3834 */           Map<String, String> nameToFieldNameMap = new TreeMap();
/* 3835 */           nameToFieldNameMap.put("auto_increment_increment", "@@session.auto_increment_increment");
/* 3836 */           nameToFieldNameMap.put("character_set_client", "@@character_set_client");
/* 3837 */           nameToFieldNameMap.put("character_set_connection", "@@character_set_connection");
/* 3838 */           nameToFieldNameMap.put("character_set_results", "@@character_set_results");
/* 3839 */           nameToFieldNameMap.put("character_set_server", "@@character_set_server");
/* 3840 */           nameToFieldNameMap.put("init_connect", "@@init_connect");
/* 3841 */           nameToFieldNameMap.put("interactive_timeout", "@@interactive_timeout");
/* 3842 */           nameToFieldNameMap.put("license", "@@license");
/* 3843 */           nameToFieldNameMap.put("lower_case_table_names", "@@lower_case_table_names");
/* 3844 */           nameToFieldNameMap.put("max_allowed_packet", "@@max_allowed_packet");
/* 3845 */           nameToFieldNameMap.put("net_buffer_length", "@@net_buffer_length");
/* 3846 */           nameToFieldNameMap.put("net_write_timeout", "@@net_write_timeout");
/* 3847 */           nameToFieldNameMap.put("query_cache_size", "@@query_cache_size");
/* 3848 */           nameToFieldNameMap.put("query_cache_type", "@@query_cache_type");
/* 3849 */           nameToFieldNameMap.put("sql_mode", "@@sql_mode");
/* 3850 */           nameToFieldNameMap.put("system_time_zone", "@@system_time_zone");
/* 3851 */           nameToFieldNameMap.put("time_zone", "@@time_zone");
/* 3852 */           nameToFieldNameMap.put("tx_isolation", "@@tx_isolation");
/* 3853 */           nameToFieldNameMap.put("wait_timeout", "@@wait_timeout");
/* 3854 */           if (!versionMeetsMinimum(5, 5, 0)) {
/* 3855 */             nameToFieldNameMap.put("language", "@@language");
/*      */           }
/*      */           
/* 3858 */           StringBuilder queryBuf = new StringBuilder(versionComment);
/* 3859 */           boolean firstEntry = true;
/* 3860 */           for (String value : nameToFieldNameMap.values()) {
/* 3861 */             if (firstEntry) {
/* 3862 */               queryBuf.append("SELECT ");
/* 3863 */               firstEntry = false;
/*      */             } else {
/* 3865 */               queryBuf.append(", ");
/*      */             }
/* 3867 */             queryBuf.append(value);
/*      */           }
/*      */           
/* 3870 */           results = stmt.executeQuery(queryBuf.toString());
/* 3871 */           if (results.next()) {
/* 3872 */             col = 1;
/* 3873 */             for (String key : nameToFieldNameMap.keySet()) {
/* 3874 */               this.serverVariables.put(key, results.getString(col++));
/*      */             }
/*      */           }
/*      */         } else {
/* 3878 */           results = stmt.executeQuery(versionComment + "SHOW VARIABLES");
/* 3879 */           while (results.next()) {
/* 3880 */             this.serverVariables.put(results.getString(1), results.getString(2));
/*      */           }
/*      */         }
/*      */         
/* 3884 */         results.close();
/* 3885 */         results = null;
/*      */       } catch (SQLException ex) {
/* 3887 */         if ((ex.getErrorCode() != 1820) || (getDisconnectOnExpiredPasswords())) {
/* 3888 */           throw ex;
/*      */         }
/*      */       }
/*      */       
/* 3892 */       if (getCacheServerConfiguration()) {
/* 3893 */         this.serverVariables.put("server_version_string", this.io.getServerVersion());
/*      */         
/* 3895 */         this.serverConfigCache.put(getURL(), this.serverVariables);
/*      */         
/* 3897 */         this.usingCachedConfig = true;
/*      */       }
/*      */     } catch (SQLException e) {
/* 3900 */       throw e;
/*      */     } finally {
/* 3902 */       if (results != null) {
/*      */         try {
/* 3904 */           results.close();
/*      */         }
/*      */         catch (SQLException sqlE) {}
/*      */       }
/*      */       
/* 3909 */       if (stmt != null) {
/*      */         try {
/* 3911 */           stmt.close();
/*      */         }
/*      */         catch (SQLException sqlE) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/* 3918 */   private int autoIncrementIncrement = 0;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   
/* 3921 */   public int getAutoIncrementIncrement() { return this.autoIncrementIncrement; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean lowerCaseTableNames()
/*      */   {
/* 3930 */     return this.lowerCaseTableNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String nativeSQL(String sql)
/*      */     throws SQLException
/*      */   {
/* 3946 */     if (sql == null) {
/* 3947 */       return null;
/*      */     }
/*      */     
/* 3950 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), getMultiHostSafeProxy());
/*      */     
/* 3952 */     if ((escapedSqlResult instanceof String)) {
/* 3953 */       return (String)escapedSqlResult;
/*      */     }
/*      */     
/* 3956 */     return ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */   }
/*      */   
/*      */   private CallableStatement parseCallableStatement(String sql) throws SQLException {
/* 3960 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), getMultiHostSafeProxy());
/*      */     
/* 3962 */     boolean isFunctionCall = false;
/* 3963 */     String parsedSql = null;
/*      */     
/* 3965 */     if ((escapedSqlResult instanceof EscapeProcessorResult)) {
/* 3966 */       parsedSql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/* 3967 */       isFunctionCall = ((EscapeProcessorResult)escapedSqlResult).callingStoredFunction;
/*      */     } else {
/* 3969 */       parsedSql = (String)escapedSqlResult;
/* 3970 */       isFunctionCall = false;
/*      */     }
/*      */     
/* 3973 */     return CallableStatement.getInstance(getMultiHostSafeProxy(), parsedSql, this.database, isFunctionCall);
/*      */   }
/*      */   
/*      */   public boolean parserKnowsUnicode() {
/* 3977 */     return this.parserKnowsUnicode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ping()
/*      */     throws SQLException
/*      */   {
/* 3987 */     pingInternal(true, 0);
/*      */   }
/*      */   
/*      */   public void pingInternal(boolean checkForClosedConnection, int timeoutMillis) throws SQLException {
/* 3991 */     if (checkForClosedConnection) {
/* 3992 */       checkClosed();
/*      */     }
/*      */     
/* 3995 */     long pingMillisLifetime = getSelfDestructOnPingSecondsLifetime();
/* 3996 */     int pingMaxOperations = getSelfDestructOnPingMaxOperations();
/*      */     
/* 3998 */     if (((pingMillisLifetime > 0L) && (System.currentTimeMillis() - this.connectionCreationTimeMillis > pingMillisLifetime)) || ((pingMaxOperations > 0) && (pingMaxOperations <= this.io.getCommandCount())))
/*      */     {
/*      */ 
/* 4001 */       close();
/*      */       
/* 4003 */       throw SQLError.createSQLException(Messages.getString("Connection.exceededConnectionLifetime"), "08S01", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 4007 */     this.io.sendCommand(14, null, null, false, null, timeoutMillis);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql)
/*      */     throws SQLException
/*      */   {
/* 4016 */     return prepareCall(sql, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4035 */     if (versionMeetsMinimum(5, 0, 0)) {
/* 4036 */       CallableStatement cStmt = null;
/*      */       
/* 4038 */       if (!getCacheCallableStatements())
/*      */       {
/* 4040 */         cStmt = parseCallableStatement(sql);
/*      */       } else {
/* 4042 */         synchronized (this.parsedCallableStatementCache) {
/* 4043 */           CompoundCacheKey key = new CompoundCacheKey(getCatalog(), sql);
/*      */           
/* 4045 */           CallableStatement.CallableStatementParamInfo cachedParamInfo = (CallableStatement.CallableStatementParamInfo)this.parsedCallableStatementCache.get(key);
/*      */           
/*      */ 
/* 4048 */           if (cachedParamInfo != null) {
/* 4049 */             cStmt = CallableStatement.getInstance(getMultiHostSafeProxy(), cachedParamInfo);
/*      */           } else {
/* 4051 */             cStmt = parseCallableStatement(sql);
/*      */             
/* 4053 */             synchronized (cStmt) {
/* 4054 */               cachedParamInfo = cStmt.paramInfo;
/*      */             }
/*      */             
/* 4057 */             this.parsedCallableStatementCache.put(key, cachedParamInfo);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 4062 */       cStmt.setResultSetType(resultSetType);
/* 4063 */       cStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */       
/* 4065 */       return cStmt;
/*      */     }
/*      */     
/* 4068 */     throw SQLError.createSQLException("Callable statements not supported.", "S1C00", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4075 */     if ((getPedantic()) && 
/* 4076 */       (resultSetHoldability != 1)) {
/* 4077 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4082 */     CallableStatement cStmt = (CallableStatement)prepareCall(sql, resultSetType, resultSetConcurrency);
/*      */     
/* 4084 */     return cStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 4109 */     return prepareStatement(sql, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int autoGenKeyIndex)
/*      */     throws SQLException
/*      */   {
/* 4116 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4118 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
/*      */     
/* 4120 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4139 */     synchronized (getConnectionMutex()) {
/* 4140 */       checkClosed();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 4145 */       PreparedStatement pStmt = null;
/*      */       
/* 4147 */       boolean canServerPrepare = true;
/*      */       
/* 4149 */       String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */       
/* 4151 */       if ((this.useServerPreparedStmts) && (getEmulateUnsupportedPstmts())) {
/* 4152 */         canServerPrepare = canHandleAsServerPreparedStatement(nativeSql);
/*      */       }
/*      */       
/* 4155 */       if ((this.useServerPreparedStmts) && (canServerPrepare)) {
/* 4156 */         if (getCachePreparedStatements()) {
/* 4157 */           synchronized (this.serverSideStatementCache) {
/* 4158 */             pStmt = (ServerPreparedStatement)this.serverSideStatementCache.remove(sql);
/*      */             
/* 4160 */             if (pStmt != null) {
/* 4161 */               ((ServerPreparedStatement)pStmt).setClosed(false);
/* 4162 */               pStmt.clearParameters();
/*      */             }
/*      */             
/* 4165 */             if (pStmt == null) {
/*      */               try {
/* 4167 */                 pStmt = ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */                 
/* 4169 */                 if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 4170 */                   ((ServerPreparedStatement)pStmt).isCached = true;
/*      */                 }
/*      */                 
/* 4173 */                 pStmt.setResultSetType(resultSetType);
/* 4174 */                 pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */               }
/*      */               catch (SQLException sqlEx) {
/* 4177 */                 if (getEmulateUnsupportedPstmts()) {
/* 4178 */                   pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */                   
/* 4180 */                   if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 4181 */                     this.serverSideStatementCheckCache.put(sql, Boolean.FALSE);
/*      */                   }
/*      */                 } else {
/* 4184 */                   throw sqlEx;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*      */           try {
/* 4191 */             pStmt = ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */             
/* 4193 */             pStmt.setResultSetType(resultSetType);
/* 4194 */             pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */           }
/*      */           catch (SQLException sqlEx) {
/* 4197 */             if (getEmulateUnsupportedPstmts()) {
/* 4198 */               pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */             } else {
/* 4200 */               throw sqlEx;
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 4205 */         pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */       }
/*      */       
/* 4208 */       return pStmt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4216 */     if ((getPedantic()) && 
/* 4217 */       (resultSetHoldability != 1)) {
/* 4218 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4223 */     return prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int[] autoGenKeyIndexes)
/*      */     throws SQLException
/*      */   {
/* 4230 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4232 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndexes != null) && (autoGenKeyIndexes.length > 0));
/*      */     
/* 4234 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, String[] autoGenKeyColNames)
/*      */     throws SQLException
/*      */   {
/* 4241 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4243 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyColNames != null) && (autoGenKeyColNames.length > 0));
/*      */     
/* 4245 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void realClose(boolean calledExplicitly, boolean issueRollback, boolean skipLocalTeardown, Throwable reason)
/*      */     throws SQLException
/*      */   {
/* 4259 */     SQLException sqlEx = null;
/*      */     
/* 4261 */     if (isClosed()) {
/* 4262 */       return;
/*      */     }
/*      */     
/* 4265 */     this.forceClosedReason = reason;
/*      */     try
/*      */     {
/* 4268 */       if (!skipLocalTeardown) {
/* 4269 */         if ((!getAutoCommit()) && (issueRollback)) {
/*      */           try {
/* 4271 */             rollback();
/*      */           } catch (SQLException ex) {
/* 4273 */             sqlEx = ex;
/*      */           }
/*      */         }
/*      */         
/* 4277 */         reportMetrics();
/*      */         
/* 4279 */         if (getUseUsageAdvisor()) {
/* 4280 */           if (!calledExplicitly) {
/* 4281 */             String message = "Connection implicitly closed by Driver. You should call Connection.close() from your code to free resources more efficiently and avoid resource leaks.";
/*      */             
/* 4283 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */           }
/*      */           
/*      */ 
/* 4287 */           long connectionLifeTime = System.currentTimeMillis() - this.connectionCreationTimeMillis;
/*      */           
/* 4289 */           if (connectionLifeTime < 500L) {
/* 4290 */             String message = "Connection lifetime of < .5 seconds. You might be un-necessarily creating short-lived connections and should investigate connection pooling to be more efficient.";
/*      */             
/* 4292 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */           }
/*      */         }
/*      */         
/*      */         try
/*      */         {
/* 4298 */           closeAllOpenStatements();
/*      */         } catch (SQLException ex) {
/* 4300 */           sqlEx = ex;
/*      */         }
/*      */         
/* 4303 */         if (this.io != null) {
/*      */           try {
/* 4305 */             this.io.quit();
/*      */           }
/*      */           catch (Exception e) {}
/*      */         }
/*      */       }
/*      */       else {
/* 4311 */         this.io.forceClose();
/*      */       }
/*      */       
/* 4314 */       if (this.statementInterceptors != null) {
/* 4315 */         for (int i = 0; i < this.statementInterceptors.size(); i++) {
/* 4316 */           ((StatementInterceptorV2)this.statementInterceptors.get(i)).destroy();
/*      */         }
/*      */       }
/*      */       
/* 4320 */       if (this.exceptionInterceptor != null) {
/* 4321 */         this.exceptionInterceptor.destroy();
/*      */       }
/*      */     } finally {
/* 4324 */       this.openStatements = null;
/* 4325 */       if (this.io != null) {
/* 4326 */         this.io.releaseResources();
/* 4327 */         this.io = null;
/*      */       }
/* 4329 */       this.statementInterceptors = null;
/* 4330 */       this.exceptionInterceptor = null;
/* 4331 */       ProfilerEventHandlerFactory.removeInstance(this);
/*      */       
/* 4333 */       synchronized (getConnectionMutex()) {
/* 4334 */         if (this.cancelTimer != null) {
/* 4335 */           this.cancelTimer.cancel();
/*      */         }
/*      */       }
/*      */       
/* 4339 */       this.isClosed = true;
/*      */     }
/*      */     
/* 4342 */     if (sqlEx != null) {
/* 4343 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   public void recachePreparedStatement(ServerPreparedStatement pstmt) throws SQLException
/*      */   {
/* 4349 */     synchronized (getConnectionMutex()) {
/* 4350 */       if (pstmt.isPoolable()) {
/* 4351 */         synchronized (this.serverSideStatementCache) {
/* 4352 */           this.serverSideStatementCache.put(pstmt.originalSql, pstmt);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void decachePreparedStatement(ServerPreparedStatement pstmt) throws SQLException {
/* 4359 */     synchronized (getConnectionMutex()) {
/* 4360 */       if (pstmt.isPoolable()) {
/* 4361 */         synchronized (this.serverSideStatementCache) {
/* 4362 */           this.serverSideStatementCache.remove(pstmt.originalSql);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerQueryExecutionTime(long queryTimeMs)
/*      */   {
/* 4372 */     if (queryTimeMs > this.longestQueryTimeMs) {
/* 4373 */       this.longestQueryTimeMs = queryTimeMs;
/*      */       
/* 4375 */       repartitionPerformanceHistogram();
/*      */     }
/*      */     
/* 4378 */     addToPerformanceHistogram(queryTimeMs, 1);
/*      */     
/* 4380 */     if (queryTimeMs < this.shortestQueryTimeMs) {
/* 4381 */       this.shortestQueryTimeMs = (queryTimeMs == 0L ? 1L : queryTimeMs);
/*      */     }
/*      */     
/* 4384 */     this.numberOfQueriesIssued += 1L;
/*      */     
/* 4386 */     this.totalQueryTimeMs += queryTimeMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerStatement(Statement stmt)
/*      */   {
/* 4396 */     synchronized (this.openStatements) {
/* 4397 */       this.openStatements.put(stmt, stmt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void repartitionHistogram(int[] histCounts, long[] histBreakpoints, long currentLowerBound, long currentUpperBound)
/*      */   {
/* 4410 */     if (this.oldHistCounts == null) {
/* 4411 */       this.oldHistCounts = new int[histCounts.length];
/* 4412 */       this.oldHistBreakpoints = new long[histBreakpoints.length];
/*      */     }
/*      */     
/* 4415 */     System.arraycopy(histCounts, 0, this.oldHistCounts, 0, histCounts.length);
/*      */     
/* 4417 */     System.arraycopy(histBreakpoints, 0, this.oldHistBreakpoints, 0, histBreakpoints.length);
/*      */     
/* 4419 */     createInitialHistogram(histBreakpoints, currentLowerBound, currentUpperBound);
/*      */     
/* 4421 */     for (int i = 0; i < 20; i++) {
/* 4422 */       addToHistogram(histCounts, histBreakpoints, this.oldHistBreakpoints[i], this.oldHistCounts[i], currentLowerBound, currentUpperBound);
/*      */     }
/*      */   }
/*      */   
/*      */   private void repartitionPerformanceHistogram() {
/* 4427 */     checkAndCreatePerformanceHistogram();
/*      */     
/* 4429 */     repartitionHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, this.shortestQueryTimeMs == Long.MAX_VALUE ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */   
/*      */   private void repartitionTablesAccessedHistogram()
/*      */   {
/* 4434 */     checkAndCreateTablesAccessedHistogram();
/*      */     
/* 4436 */     repartitionHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, this.minimumNumberTablesAccessed == Long.MAX_VALUE ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */   
/*      */   private void reportMetrics()
/*      */   {
/* 4441 */     if (getGatherPerformanceMetrics()) {
/* 4442 */       StringBuilder logMessage = new StringBuilder(256);
/*      */       
/* 4444 */       logMessage.append("** Performance Metrics Report **\n");
/* 4445 */       logMessage.append("\nLongest reported query: " + this.longestQueryTimeMs + " ms");
/* 4446 */       logMessage.append("\nShortest reported query: " + this.shortestQueryTimeMs + " ms");
/* 4447 */       logMessage.append("\nAverage query execution time: " + this.totalQueryTimeMs / this.numberOfQueriesIssued + " ms");
/* 4448 */       logMessage.append("\nNumber of statements executed: " + this.numberOfQueriesIssued);
/* 4449 */       logMessage.append("\nNumber of result sets created: " + this.numberOfResultSetsCreated);
/* 4450 */       logMessage.append("\nNumber of statements prepared: " + this.numberOfPrepares);
/* 4451 */       logMessage.append("\nNumber of prepared statement executions: " + this.numberOfPreparedExecutes);
/*      */       
/* 4453 */       if (this.perfMetricsHistBreakpoints != null) {
/* 4454 */         logMessage.append("\n\n\tTiming Histogram:\n");
/* 4455 */         int maxNumPoints = 20;
/* 4456 */         int highestCount = Integer.MIN_VALUE;
/*      */         
/* 4458 */         for (int i = 0; i < 20; i++) {
/* 4459 */           if (this.perfMetricsHistCounts[i] > highestCount) {
/* 4460 */             highestCount = this.perfMetricsHistCounts[i];
/*      */           }
/*      */         }
/*      */         
/* 4464 */         if (highestCount == 0) {
/* 4465 */           highestCount = 1;
/*      */         }
/*      */         
/* 4468 */         for (int i = 0; i < 19; i++)
/*      */         {
/* 4470 */           if (i == 0) {
/* 4471 */             logMessage.append("\n\tless than " + this.perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           } else {
/* 4473 */             logMessage.append("\n\tbetween " + this.perfMetricsHistBreakpoints[i] + " and " + this.perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           }
/*      */           
/*      */ 
/* 4477 */           logMessage.append("\t");
/*      */           
/* 4479 */           int numPointsToGraph = (int)(maxNumPoints * (this.perfMetricsHistCounts[i] / highestCount));
/*      */           
/* 4481 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 4482 */             logMessage.append("*");
/*      */           }
/*      */           
/* 4485 */           if (this.longestQueryTimeMs < this.perfMetricsHistCounts[(i + 1)]) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         
/* 4490 */         if (this.perfMetricsHistBreakpoints[18] < this.longestQueryTimeMs) {
/* 4491 */           logMessage.append("\n\tbetween ");
/* 4492 */           logMessage.append(this.perfMetricsHistBreakpoints[18]);
/* 4493 */           logMessage.append(" and ");
/* 4494 */           logMessage.append(this.perfMetricsHistBreakpoints[19]);
/* 4495 */           logMessage.append(" ms: \t");
/* 4496 */           logMessage.append(this.perfMetricsHistCounts[19]);
/*      */         }
/*      */       }
/*      */       
/* 4500 */       if (this.numTablesMetricsHistBreakpoints != null) {
/* 4501 */         logMessage.append("\n\n\tTable Join Histogram:\n");
/* 4502 */         int maxNumPoints = 20;
/* 4503 */         int highestCount = Integer.MIN_VALUE;
/*      */         
/* 4505 */         for (int i = 0; i < 20; i++) {
/* 4506 */           if (this.numTablesMetricsHistCounts[i] > highestCount) {
/* 4507 */             highestCount = this.numTablesMetricsHistCounts[i];
/*      */           }
/*      */         }
/*      */         
/* 4511 */         if (highestCount == 0) {
/* 4512 */           highestCount = 1;
/*      */         }
/*      */         
/* 4515 */         for (int i = 0; i < 19; i++)
/*      */         {
/* 4517 */           if (i == 0) {
/* 4518 */             logMessage.append("\n\t" + this.numTablesMetricsHistBreakpoints[(i + 1)] + " tables or less: \t\t" + this.numTablesMetricsHistCounts[i]);
/*      */           } else {
/* 4520 */             logMessage.append("\n\tbetween " + this.numTablesMetricsHistBreakpoints[i] + " and " + this.numTablesMetricsHistBreakpoints[(i + 1)] + " tables: \t" + this.numTablesMetricsHistCounts[i]);
/*      */           }
/*      */           
/*      */ 
/* 4524 */           logMessage.append("\t");
/*      */           
/* 4526 */           int numPointsToGraph = (int)(maxNumPoints * (this.numTablesMetricsHistCounts[i] / highestCount));
/*      */           
/* 4528 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 4529 */             logMessage.append("*");
/*      */           }
/*      */           
/* 4532 */           if (this.maximumNumberTablesAccessed < this.numTablesMetricsHistBreakpoints[(i + 1)]) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         
/* 4537 */         if (this.numTablesMetricsHistBreakpoints[18] < this.maximumNumberTablesAccessed) {
/* 4538 */           logMessage.append("\n\tbetween ");
/* 4539 */           logMessage.append(this.numTablesMetricsHistBreakpoints[18]);
/* 4540 */           logMessage.append(" and ");
/* 4541 */           logMessage.append(this.numTablesMetricsHistBreakpoints[19]);
/* 4542 */           logMessage.append(" tables: ");
/* 4543 */           logMessage.append(this.numTablesMetricsHistCounts[19]);
/*      */         }
/*      */       }
/*      */       
/* 4547 */       this.log.logInfo(logMessage);
/*      */       
/* 4549 */       this.metricsLastReportedMs = System.currentTimeMillis();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reportMetricsIfNeeded()
/*      */   {
/* 4558 */     if ((getGatherPerformanceMetrics()) && 
/* 4559 */       (System.currentTimeMillis() - this.metricsLastReportedMs > getReportMetricsIntervalMillis())) {
/* 4560 */       reportMetrics();
/*      */     }
/*      */   }
/*      */   
/*      */   public void reportNumberOfTablesAccessed(int numTablesAccessed)
/*      */   {
/* 4566 */     if (numTablesAccessed < this.minimumNumberTablesAccessed) {
/* 4567 */       this.minimumNumberTablesAccessed = numTablesAccessed;
/*      */     }
/*      */     
/* 4570 */     if (numTablesAccessed > this.maximumNumberTablesAccessed) {
/* 4571 */       this.maximumNumberTablesAccessed = numTablesAccessed;
/*      */       
/* 4573 */       repartitionTablesAccessedHistogram();
/*      */     }
/*      */     
/* 4576 */     addToTablesAccessedHistogram(numTablesAccessed, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetServerState()
/*      */     throws SQLException
/*      */   {
/* 4588 */     if ((!getParanoid()) && (this.io != null) && (versionMeetsMinimum(4, 0, 6))) {
/* 4589 */       changeUser(this.user, this.password);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLException
/*      */   {
/* 4603 */     synchronized (getConnectionMutex()) {
/* 4604 */       checkClosed();
/*      */       try
/*      */       {
/* 4607 */         if (this.connectionLifecycleInterceptors != null) {
/* 4608 */           IterateBlock<Extension> iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Extension each) throws SQLException
/*      */             {
/* 4612 */               if (!((ConnectionLifecycleInterceptor)each).rollback()) {
/* 4613 */                 this.stopIterating = true;
/*      */               }
/*      */               
/*      */             }
/* 4617 */           };
/* 4618 */           iter.doForAll();
/*      */           
/* 4620 */           if (!iter.fullIteration()) {
/* 4621 */             jsr 115;return;
/*      */           }
/*      */         }
/*      */         
/* 4625 */         if ((this.autoCommit) && (!getRelaxAutoCommit())) {
/* 4626 */           throw SQLError.createSQLException("Can't call rollback when autocommit=true", "08003", getExceptionInterceptor());
/*      */         }
/* 4628 */         if (this.transactionsSupported) {
/*      */           try {
/* 4630 */             rollbackNoChecks();
/*      */           }
/*      */           catch (SQLException sqlEx) {
/* 4633 */             if ((getIgnoreNonTxTables()) && (sqlEx.getErrorCode() == 1196)) {
/* 4634 */               return;
/*      */             }
/* 4636 */             throw sqlEx;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (SQLException sqlException) {
/* 4641 */         if ("08S01".equals(sqlException.getSQLState())) {
/* 4642 */           throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/* 4646 */         throw sqlException;
/*      */       } finally {
/* 4648 */         jsr 5; } localObject2 = returnAddress;this.needsPing = getReconnectAtTxEnd();ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback(final Savepoint savepoint)
/*      */     throws SQLException
/*      */   {
/* 4658 */     synchronized (getConnectionMutex()) {
/* 4659 */       if ((versionMeetsMinimum(4, 0, 14)) || (versionMeetsMinimum(4, 1, 1))) {
/* 4660 */         checkClosed();
/*      */         try
/*      */         {
/* 4663 */           if (this.connectionLifecycleInterceptors != null) {
/* 4664 */             IterateBlock<Extension> iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */             {
/*      */               void forEach(Extension each) throws SQLException
/*      */               {
/* 4668 */                 if (!((ConnectionLifecycleInterceptor)each).rollback(savepoint)) {
/* 4669 */                   this.stopIterating = true;
/*      */                 }
/*      */                 
/*      */               }
/* 4673 */             };
/* 4674 */             iter.doForAll();
/*      */             
/* 4676 */             if (!iter.fullIteration()) {
/* 4677 */               jsr 240;return;
/*      */             }
/*      */           }
/*      */           
/* 4681 */           StringBuilder rollbackQuery = new StringBuilder("ROLLBACK TO SAVEPOINT ");
/* 4682 */           rollbackQuery.append('`');
/* 4683 */           rollbackQuery.append(savepoint.getSavepointName());
/* 4684 */           rollbackQuery.append('`');
/*      */           
/* 4686 */           java.sql.Statement stmt = null;
/*      */           try
/*      */           {
/* 4689 */             stmt = getMetadataSafeStatement();
/*      */             
/* 4691 */             stmt.executeUpdate(rollbackQuery.toString());
/*      */           } catch (SQLException sqlEx) {
/* 4693 */             int errno = sqlEx.getErrorCode();
/*      */             
/* 4695 */             if (errno == 1181) {
/* 4696 */               String msg = sqlEx.getMessage();
/*      */               
/* 4698 */               if (msg != null) {
/* 4699 */                 int indexOfError153 = msg.indexOf("153");
/*      */                 
/* 4701 */                 if (indexOfError153 != -1) {
/* 4702 */                   throw SQLError.createSQLException("Savepoint '" + savepoint.getSavepointName() + "' does not exist", "S1009", errno, getExceptionInterceptor());
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 4709 */             if ((getIgnoreNonTxTables()) && (sqlEx.getErrorCode() != 1196)) {
/* 4710 */               throw sqlEx;
/*      */             }
/*      */             
/* 4713 */             if ("08S01".equals(sqlEx.getSQLState())) {
/* 4714 */               throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */             }
/*      */             
/*      */ 
/* 4718 */             throw sqlEx;
/*      */           } finally {
/* 4720 */             closeStatement(stmt);
/*      */           }
/*      */         } finally {
/* 4723 */           jsr 6; } localObject4 = returnAddress;this.needsPing = getReconnectAtTxEnd();ret;
/*      */       }
/*      */       else {
/* 4726 */         throw SQLError.notImplemented();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void rollbackNoChecks() throws SQLException {
/* 4732 */     if ((getUseLocalTransactionState()) && (versionMeetsMinimum(5, 0, 0)) && 
/* 4733 */       (!this.io.inTransactionOnServer())) {
/* 4734 */       return;
/*      */     }
/*      */     
/*      */ 
/* 4738 */     execSQL(null, "rollback", -1, null, 1003, 1007, false, this.database, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 4746 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4748 */     return ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getCatalog(), 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex)
/*      */     throws SQLException
/*      */   {
/* 4756 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4758 */     PreparedStatement pStmt = ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getCatalog(), 1003, 1007);
/*      */     
/*      */ 
/* 4761 */     pStmt.setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
/*      */     
/* 4763 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4770 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4772 */     return ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getCatalog(), resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4780 */     if ((getPedantic()) && 
/* 4781 */       (resultSetHoldability != 1)) {
/* 4782 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4787 */     return serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes)
/*      */     throws SQLException
/*      */   {
/* 4795 */     PreparedStatement pStmt = (PreparedStatement)serverPrepareStatement(sql);
/*      */     
/* 4797 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null) && (autoGenKeyIndexes.length > 0));
/*      */     
/* 4799 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames)
/*      */     throws SQLException
/*      */   {
/* 4806 */     PreparedStatement pStmt = (PreparedStatement)serverPrepareStatement(sql);
/*      */     
/* 4808 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null) && (autoGenKeyColNames.length > 0));
/*      */     
/* 4810 */     return pStmt;
/*      */   }
/*      */   
/*      */   public boolean serverSupportsConvertFn() throws SQLException {
/* 4814 */     return versionMeetsMinimum(4, 0, 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoCommit(final boolean autoCommitFlag)
/*      */     throws SQLException
/*      */   {
/* 4840 */     synchronized (getConnectionMutex()) {
/* 4841 */       checkClosed();
/*      */       
/* 4843 */       if (this.connectionLifecycleInterceptors != null) {
/* 4844 */         IterateBlock<Extension> iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */         {
/*      */           void forEach(Extension each) throws SQLException
/*      */           {
/* 4848 */             if (!((ConnectionLifecycleInterceptor)each).setAutoCommit(autoCommitFlag)) {
/* 4849 */               this.stopIterating = true;
/*      */             }
/*      */             
/*      */           }
/* 4853 */         };
/* 4854 */         iter.doForAll();
/*      */         
/* 4856 */         if (!iter.fullIteration()) {
/* 4857 */           return;
/*      */         }
/*      */       }
/*      */       
/* 4861 */       if (getAutoReconnectForPools()) {
/* 4862 */         setHighAvailability(true);
/*      */       }
/*      */       try
/*      */       {
/* 4866 */         if (this.transactionsSupported)
/*      */         {
/* 4868 */           boolean needsSetOnServer = true;
/*      */           
/* 4870 */           if ((getUseLocalSessionState()) && (this.autoCommit == autoCommitFlag)) {
/* 4871 */             needsSetOnServer = false;
/* 4872 */           } else if (!getHighAvailability()) {
/* 4873 */             needsSetOnServer = getIO().isSetNeededForAutoCommitMode(autoCommitFlag);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 4879 */           this.autoCommit = autoCommitFlag;
/*      */           
/* 4881 */           if (needsSetOnServer) {
/* 4882 */             execSQL(null, autoCommitFlag ? "SET autocommit=1" : "SET autocommit=0", -1, null, 1003, 1007, false, this.database, null, false);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 4887 */           if ((!autoCommitFlag) && (!getRelaxAutoCommit())) {
/* 4888 */             throw SQLError.createSQLException("MySQL Versions Older than 3.23.15 do not support transactions", "08003", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 4892 */           this.autoCommit = autoCommitFlag;
/*      */         }
/*      */       } finally {
/* 4895 */         if (getAutoReconnectForPools()) {
/* 4896 */           setHighAvailability(false);
/*      */         }
/*      */       }
/*      */       
/* 4900 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCatalog(final String catalog)
/*      */     throws SQLException
/*      */   {
/* 4918 */     synchronized (getConnectionMutex()) {
/* 4919 */       checkClosed();
/*      */       
/* 4921 */       if (catalog == null) {
/* 4922 */         throw SQLError.createSQLException("Catalog can not be null", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 4925 */       if (this.connectionLifecycleInterceptors != null) {
/* 4926 */         IterateBlock<Extension> iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */         {
/*      */           void forEach(Extension each) throws SQLException
/*      */           {
/* 4930 */             if (!((ConnectionLifecycleInterceptor)each).setCatalog(catalog)) {
/* 4931 */               this.stopIterating = true;
/*      */             }
/*      */             
/*      */           }
/* 4935 */         };
/* 4936 */         iter.doForAll();
/*      */         
/* 4938 */         if (!iter.fullIteration()) {
/* 4939 */           return;
/*      */         }
/*      */       }
/*      */       
/* 4943 */       if (getUseLocalSessionState()) {
/* 4944 */         if (this.lowerCaseTableNames) {
/* 4945 */           if (!this.database.equalsIgnoreCase(catalog)) {}
/*      */ 
/*      */ 
/*      */         }
/* 4949 */         else if (this.database.equals(catalog)) {
/* 4950 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4955 */       String quotedId = this.dbmd.getIdentifierQuoteString();
/*      */       
/* 4957 */       if ((quotedId == null) || (quotedId.equals(" "))) {
/* 4958 */         quotedId = "";
/*      */       }
/*      */       
/* 4961 */       StringBuilder query = new StringBuilder("USE ");
/* 4962 */       query.append(StringUtils.quoteIdentifier(catalog, quotedId, getPedantic()));
/*      */       
/* 4964 */       execSQL(null, query.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */       
/* 4966 */       this.database = catalog;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInGlobalTx(boolean flag)
/*      */   {
/* 4988 */     this.isInGlobalTx = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadInfoMsgEnabled(boolean flag)
/*      */   {
/* 5001 */     this.readInfoMsg = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadOnly(boolean readOnlyFlag)
/*      */     throws SQLException
/*      */   {
/* 5016 */     checkClosed();
/*      */     
/* 5018 */     setReadOnlyInternal(readOnlyFlag);
/*      */   }
/*      */   
/*      */   public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException
/*      */   {
/* 5023 */     if ((getReadOnlyPropagatesToServer()) && (versionMeetsMinimum(5, 6, 5)) && (
/* 5024 */       (!getUseLocalSessionState()) || (readOnlyFlag != this.readOnly))) {
/* 5025 */       execSQL(null, "set session transaction " + (readOnlyFlag ? "read only" : "read write"), -1, null, 1003, 1007, false, this.database, null, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5030 */     this.readOnly = readOnlyFlag;
/*      */   }
/*      */   
/*      */ 
/*      */   public Savepoint setSavepoint()
/*      */     throws SQLException
/*      */   {
/* 5037 */     MysqlSavepoint savepoint = new MysqlSavepoint(getExceptionInterceptor());
/*      */     
/* 5039 */     setSavepoint(savepoint);
/*      */     
/* 5041 */     return savepoint;
/*      */   }
/*      */   
/*      */   private void setSavepoint(MysqlSavepoint savepoint) throws SQLException
/*      */   {
/* 5046 */     synchronized (getConnectionMutex()) {
/* 5047 */       if ((versionMeetsMinimum(4, 0, 14)) || (versionMeetsMinimum(4, 1, 1))) {
/* 5048 */         checkClosed();
/*      */         
/* 5050 */         StringBuilder savePointQuery = new StringBuilder("SAVEPOINT ");
/* 5051 */         savePointQuery.append('`');
/* 5052 */         savePointQuery.append(savepoint.getSavepointName());
/* 5053 */         savePointQuery.append('`');
/*      */         
/* 5055 */         java.sql.Statement stmt = null;
/*      */         try
/*      */         {
/* 5058 */           stmt = getMetadataSafeStatement();
/*      */           
/* 5060 */           stmt.executeUpdate(savePointQuery.toString());
/*      */         } finally {
/* 5062 */           closeStatement(stmt);
/*      */         }
/*      */       } else {
/* 5065 */         throw SQLError.notImplemented();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Savepoint setSavepoint(String name)
/*      */     throws SQLException
/*      */   {
/* 5074 */     synchronized (getConnectionMutex()) {
/* 5075 */       MysqlSavepoint savepoint = new MysqlSavepoint(name, getExceptionInterceptor());
/*      */       
/* 5077 */       setSavepoint(savepoint);
/*      */       
/* 5079 */       return savepoint;
/*      */     }
/*      */   }
/*      */   
/*      */   private void setSessionVariables() throws SQLException {
/* 5084 */     if ((versionMeetsMinimum(4, 0, 0)) && (getSessionVariables() != null)) {
/* 5085 */       List<String> variablesToSet = StringUtils.split(getSessionVariables(), ",", "\"'", "\"'", false);
/*      */       
/* 5087 */       int numVariablesToSet = variablesToSet.size();
/*      */       
/* 5089 */       java.sql.Statement stmt = null;
/*      */       try
/*      */       {
/* 5092 */         stmt = getMetadataSafeStatement();
/*      */         
/* 5094 */         for (int i = 0; i < numVariablesToSet; i++) {
/* 5095 */           String variableValuePair = (String)variablesToSet.get(i);
/*      */           
/* 5097 */           if (variableValuePair.startsWith("@")) {
/* 5098 */             stmt.executeUpdate("SET " + variableValuePair);
/*      */           } else {
/* 5100 */             stmt.executeUpdate("SET SESSION " + variableValuePair);
/*      */           }
/*      */         }
/*      */       } finally {
/* 5104 */         if (stmt != null) {
/* 5105 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransactionIsolation(int level)
/*      */     throws SQLException
/*      */   {
/* 5117 */     synchronized (getConnectionMutex()) {
/* 5118 */       checkClosed();
/*      */       
/* 5120 */       if (this.hasIsolationLevels) {
/* 5121 */         String sql = null;
/*      */         
/* 5123 */         boolean shouldSendSet = false;
/*      */         
/* 5125 */         if (getAlwaysSendSetIsolation()) {
/* 5126 */           shouldSendSet = true;
/*      */         }
/* 5128 */         else if (level != this.isolationLevel) {
/* 5129 */           shouldSendSet = true;
/*      */         }
/*      */         
/*      */ 
/* 5133 */         if (getUseLocalSessionState()) {
/* 5134 */           shouldSendSet = this.isolationLevel != level;
/*      */         }
/*      */         
/* 5137 */         if (shouldSendSet) {
/* 5138 */           switch (level) {
/*      */           case 0: 
/* 5140 */             throw SQLError.createSQLException("Transaction isolation level NONE not supported by MySQL", getExceptionInterceptor());
/*      */           
/*      */           case 2: 
/* 5143 */             sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED";
/*      */             
/* 5145 */             break;
/*      */           
/*      */           case 1: 
/* 5148 */             sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED";
/*      */             
/* 5150 */             break;
/*      */           
/*      */           case 4: 
/* 5153 */             sql = "SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ";
/*      */             
/* 5155 */             break;
/*      */           
/*      */           case 8: 
/* 5158 */             sql = "SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE";
/*      */             
/* 5160 */             break;
/*      */           case 3: case 5: case 6: 
/*      */           case 7: default: 
/* 5163 */             throw SQLError.createSQLException("Unsupported transaction isolation level '" + level + "'", "S1C00", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */           
/* 5167 */           execSQL(null, sql, -1, null, 1003, 1007, false, this.database, null, false);
/*      */           
/* 5169 */           this.isolationLevel = level;
/*      */         }
/*      */       } else {
/* 5172 */         throw SQLError.createSQLException("Transaction Isolation Levels are not supported on MySQL versions older than 3.23.36.", "S1C00", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTypeMap(Map<String, Class<?>> map)
/*      */     throws SQLException
/*      */   {
/* 5188 */     synchronized (getConnectionMutex()) {
/* 5189 */       this.typeMap = map;
/*      */     }
/*      */   }
/*      */   
/*      */   private void setupServerForTruncationChecks() throws SQLException {
/* 5194 */     if ((getJdbcCompliantTruncation()) && 
/* 5195 */       (versionMeetsMinimum(5, 0, 2))) {
/* 5196 */       String currentSqlMode = (String)this.serverVariables.get("sql_mode");
/*      */       
/* 5198 */       boolean strictTransTablesIsSet = StringUtils.indexOfIgnoreCase(currentSqlMode, "STRICT_TRANS_TABLES") != -1;
/*      */       
/* 5200 */       if ((currentSqlMode == null) || (currentSqlMode.length() == 0) || (!strictTransTablesIsSet)) {
/* 5201 */         StringBuilder commandBuf = new StringBuilder("SET sql_mode='");
/*      */         
/* 5203 */         if ((currentSqlMode != null) && (currentSqlMode.length() > 0)) {
/* 5204 */           commandBuf.append(currentSqlMode);
/* 5205 */           commandBuf.append(",");
/*      */         }
/*      */         
/* 5208 */         commandBuf.append("STRICT_TRANS_TABLES'");
/*      */         
/* 5210 */         execSQL(null, commandBuf.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */         
/* 5212 */         setJdbcCompliantTruncation(false);
/* 5213 */       } else if (strictTransTablesIsSet)
/*      */       {
/* 5215 */         setJdbcCompliantTruncation(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void shutdownServer()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 5230 */       this.io.sendCommand(8, null, null, false, null, 0);
/*      */     } catch (Exception ex) {
/* 5232 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.UnhandledExceptionDuringShutdown"), "S1000", getExceptionInterceptor());
/*      */       
/*      */ 
/* 5235 */       sqlEx.initCause(ex);
/*      */       
/* 5237 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean supportsIsolationLevel() {
/* 5242 */     return this.hasIsolationLevels;
/*      */   }
/*      */   
/*      */   public boolean supportsQuotedIdentifiers() {
/* 5246 */     return this.hasQuotedIdentifiers;
/*      */   }
/*      */   
/*      */   public boolean supportsTransactions() {
/* 5250 */     return this.transactionsSupported;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unregisterStatement(Statement stmt)
/*      */   {
/* 5260 */     if (this.openStatements != null) {
/* 5261 */       synchronized (this.openStatements) {
/* 5262 */         this.openStatements.remove(stmt);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor)
/*      */     throws SQLException
/*      */   {
/* 5274 */     checkClosed();
/*      */     
/* 5276 */     return this.io.versionMeetsMinimum(major, minor, subminor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet)
/*      */     throws SQLException
/*      */   {
/* 5322 */     if (cachedMetaData == null)
/*      */     {
/*      */ 
/* 5325 */       cachedMetaData = new CachedResultSetMetaData();
/*      */       
/*      */ 
/* 5328 */       resultSet.buildIndexMapping();
/* 5329 */       resultSet.initializeWithMetadata();
/*      */       
/* 5331 */       if ((resultSet instanceof UpdatableResultSet)) {
/* 5332 */         ((UpdatableResultSet)resultSet).checkUpdatability();
/*      */       }
/*      */       
/* 5335 */       resultSet.populateCachedMetaData(cachedMetaData);
/*      */       
/* 5337 */       this.resultSetMetadataCache.put(sql, cachedMetaData);
/*      */     } else {
/* 5339 */       resultSet.initializeFromCachedMetaData(cachedMetaData);
/* 5340 */       resultSet.initializeWithMetadata();
/*      */       
/* 5342 */       if ((resultSet instanceof UpdatableResultSet)) {
/* 5343 */         ((UpdatableResultSet)resultSet).checkUpdatability();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStatementComment()
/*      */   {
/* 5356 */     return this.statementComment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatementComment(String comment)
/*      */   {
/* 5369 */     this.statementComment = comment;
/*      */   }
/*      */   
/*      */   public void reportQueryTime(long millisOrNanos) {
/* 5373 */     synchronized (getConnectionMutex()) {
/* 5374 */       this.queryTimeCount += 1L;
/* 5375 */       this.queryTimeSum += millisOrNanos;
/* 5376 */       this.queryTimeSumSquares += millisOrNanos * millisOrNanos;
/* 5377 */       this.queryTimeMean = ((this.queryTimeMean * (this.queryTimeCount - 1L) + millisOrNanos) / this.queryTimeCount);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isAbonormallyLongQuery(long millisOrNanos) {
/* 5382 */     synchronized (getConnectionMutex()) {
/* 5383 */       if (this.queryTimeCount < 15L) {
/* 5384 */         return false;
/*      */       }
/*      */       
/* 5387 */       double stddev = Math.sqrt((this.queryTimeSumSquares - this.queryTimeSum * this.queryTimeSum / this.queryTimeCount) / (this.queryTimeCount - 1L));
/*      */       
/* 5389 */       return millisOrNanos > this.queryTimeMean + 5.0D * stddev;
/*      */     }
/*      */   }
/*      */   
/*      */   public void initializeExtension(Extension ex) throws SQLException {
/* 5394 */     ex.init(this, this.props);
/*      */   }
/*      */   
/*      */   public void transactionBegun() throws SQLException {
/* 5398 */     synchronized (getConnectionMutex()) {
/* 5399 */       if (this.connectionLifecycleInterceptors != null) {
/* 5400 */         IterateBlock<Extension> iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */         {
/*      */           void forEach(Extension each) throws SQLException
/*      */           {
/* 5404 */             ((ConnectionLifecycleInterceptor)each).transactionBegun();
/*      */           }
/*      */           
/* 5407 */         };
/* 5408 */         iter.doForAll();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void transactionCompleted() throws SQLException {
/* 5414 */     synchronized (getConnectionMutex()) {
/* 5415 */       if (this.connectionLifecycleInterceptors != null) {
/* 5416 */         IterateBlock<Extension> iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */         {
/*      */           void forEach(Extension each) throws SQLException
/*      */           {
/* 5420 */             ((ConnectionLifecycleInterceptor)each).transactionCompleted();
/*      */           }
/*      */           
/* 5423 */         };
/* 5424 */         iter.doForAll();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean storesLowerCaseTableName() {
/* 5430 */     return this.storesLowerCaseTableName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ExceptionInterceptor getExceptionInterceptor()
/*      */   {
/* 5437 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   public boolean getRequiresEscapingEncoder() {
/* 5441 */     return this.requiresEscapingEncoder;
/*      */   }
/*      */   
/*      */   public boolean isServerLocal() throws SQLException {
/* 5445 */     synchronized (getConnectionMutex()) {
/* 5446 */       SocketFactory factory = getIO().socketFactory;
/*      */       
/* 5448 */       if ((factory instanceof SocketMetadata)) {
/* 5449 */         return ((SocketMetadata)factory).isLocallyConnected(this);
/*      */       }
/* 5451 */       getLog().logWarn(Messages.getString("Connection.NoMetadataOnSocketFactory"));
/* 5452 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionMaxRows(int max)
/*      */     throws SQLException
/*      */   {
/* 5474 */     synchronized (getConnectionMutex()) {
/* 5475 */       if (this.sessionMaxRows != max) {
/* 5476 */         this.sessionMaxRows = max;
/* 5477 */         execSQL(null, "SET SQL_SELECT_LIMIT=" + (this.sessionMaxRows == -1 ? "DEFAULT" : Integer.valueOf(this.sessionMaxRows)), -1, null, 1003, 1007, false, this.database, null, false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSchema(String schema)
/*      */     throws SQLException
/*      */   {
/* 5486 */     synchronized (getConnectionMutex()) {
/* 5487 */       checkClosed();
/*      */     }
/*      */   }
/*      */   
/*      */   public String getSchema() throws SQLException
/*      */   {
/* 5493 */     synchronized (getConnectionMutex()) {
/* 5494 */       checkClosed();
/*      */       
/* 5496 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void abort(Executor executor)
/*      */     throws SQLException
/*      */   {
/* 5531 */     SecurityManager sec = System.getSecurityManager();
/*      */     
/* 5533 */     if (sec != null) {
/* 5534 */       sec.checkPermission(ABORT_PERM);
/*      */     }
/*      */     
/* 5537 */     if (executor == null) {
/* 5538 */       throw SQLError.createSQLException("Executor can not be null", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 5541 */     executor.execute(new Runnable()
/*      */     {
/*      */       public void run() {
/*      */         try {
/* 5545 */           ConnectionImpl.this.abortInternal();
/*      */         } catch (SQLException e) {
/* 5547 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   public void setNetworkTimeout(Executor executor, final int milliseconds) throws SQLException
/*      */   {
/* 5555 */     synchronized (getConnectionMutex()) {
/* 5556 */       SecurityManager sec = System.getSecurityManager();
/*      */       
/* 5558 */       if (sec != null) {
/* 5559 */         sec.checkPermission(SET_NETWORK_TIMEOUT_PERM);
/*      */       }
/*      */       
/* 5562 */       if (executor == null) {
/* 5563 */         throw SQLError.createSQLException("Executor can not be null", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 5566 */       checkClosed();
/* 5567 */       final MysqlIO mysqlIo = this.io;
/*      */       
/* 5569 */       executor.execute(new Runnable()
/*      */       {
/*      */         public void run() {
/*      */           try {
/* 5573 */             ConnectionImpl.this.setSocketTimeout(milliseconds);
/* 5574 */             mysqlIo.setSocketTimeout(milliseconds);
/*      */           } catch (SQLException e) {
/* 5576 */             throw new RuntimeException(e);
/*      */           }
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException
/*      */   {
/* 5585 */     synchronized (getConnectionMutex()) {
/* 5586 */       checkClosed();
/* 5587 */       return getSocketTimeout();
/*      */     }
/*      */   }
/*      */   
/*      */   public ProfilerEventHandler getProfilerEventHandlerInstance() {
/* 5592 */     return this.eventSink;
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandlerInstance(ProfilerEventHandler h) {
/* 5596 */     this.eventSink = h;
/*      */   }
/*      */   
/*      */   protected ConnectionImpl() {}
/*      */   
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   /* Error */
/*      */   public int getActiveStatementCount()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 133	com/mysql/jdbc/ConnectionImpl:openStatements	Ljava/util/Map;
/*      */     //   4: ifnull +27 -> 31
/*      */     //   7: aload_0
/*      */     //   8: getfield 133	com/mysql/jdbc/ConnectionImpl:openStatements	Ljava/util/Map;
/*      */     //   11: dup
/*      */     //   12: astore_1
/*      */     //   13: monitorenter
/*      */     //   14: aload_0
/*      */     //   15: getfield 133	com/mysql/jdbc/ConnectionImpl:openStatements	Ljava/util/Map;
/*      */     //   18: invokeinterface 244 1 0
/*      */     //   23: aload_1
/*      */     //   24: monitorexit
/*      */     //   25: ireturn
/*      */     //   26: astore_2
/*      */     //   27: aload_1
/*      */     //   28: monitorexit
/*      */     //   29: aload_2
/*      */     //   30: athrow
/*      */     //   31: iconst_0
/*      */     //   32: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #2646	-> byte code offset #0
/*      */     //   Java source line #2647	-> byte code offset #7
/*      */     //   Java source line #2648	-> byte code offset #14
/*      */     //   Java source line #2649	-> byte code offset #26
/*      */     //   Java source line #2652	-> byte code offset #31
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	33	0	this	ConnectionImpl
/*      */     //   12	16	1	Ljava/lang/Object;	Object
/*      */     //   26	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	25	26	finally
/*      */     //   26	29	26	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean getAutoCommit()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 29	com/mysql/jdbc/ConnectionImpl:getConnectionMutex	()Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 51	com/mysql/jdbc/ConnectionImpl:autoCommit	Z
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2664	-> byte code offset #0
/*      */     //   Java source line #2665	-> byte code offset #7
/*      */     //   Java source line #2666	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	ConnectionImpl
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String getCatalog()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 29	com/mysql/jdbc/ConnectionImpl:getConnectionMutex	()Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 59	com/mysql/jdbc/ConnectionImpl:database	Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2693	-> byte code offset #0
/*      */     //   Java source line #2694	-> byte code offset #7
/*      */     //   Java source line #2695	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	ConnectionImpl
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String getCharacterSetMetadata()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 29	com/mysql/jdbc/ConnectionImpl:getConnectionMutex	()Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 52	com/mysql/jdbc/ConnectionImpl:characterSetMetadata	Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2702	-> byte code offset #0
/*      */     //   Java source line #2703	-> byte code offset #7
/*      */     //   Java source line #2704	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	ConnectionImpl
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean isMasterConnection()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 29	com/mysql/jdbc/ConnectionImpl:getConnectionMutex	()Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: iconst_0
/*      */     //   8: aload_1
/*      */     //   9: monitorexit
/*      */     //   10: ireturn
/*      */     //   11: astore_2
/*      */     //   12: aload_1
/*      */     //   13: monitorexit
/*      */     //   14: aload_2
/*      */     //   15: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3563	-> byte code offset #0
/*      */     //   Java source line #3564	-> byte code offset #7
/*      */     //   Java source line #3565	-> byte code offset #11
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	16	0	this	ConnectionImpl
/*      */     //   5	8	1	Ljava/lang/Object;	Object
/*      */     //   11	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	10	11	finally
/*      */     //   11	14	11	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean isReadOnly(boolean useSessionStatus)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: iload_1
/*      */     //   1: ifeq +177 -> 178
/*      */     //   4: aload_0
/*      */     //   5: getfield 69	com/mysql/jdbc/ConnectionImpl:isClosed	Z
/*      */     //   8: ifne +170 -> 178
/*      */     //   11: aload_0
/*      */     //   12: iconst_5
/*      */     //   13: bipush 6
/*      */     //   15: iconst_5
/*      */     //   16: invokevirtual 218	com/mysql/jdbc/ConnectionImpl:versionMeetsMinimum	(III)Z
/*      */     //   19: ifeq +159 -> 178
/*      */     //   22: aload_0
/*      */     //   23: invokevirtual 589	com/mysql/jdbc/ConnectionImpl:getUseLocalSessionState	()Z
/*      */     //   26: ifne +152 -> 178
/*      */     //   29: aload_0
/*      */     //   30: invokevirtual 674	com/mysql/jdbc/ConnectionImpl:getReadOnlyPropagatesToServer	()Z
/*      */     //   33: ifeq +145 -> 178
/*      */     //   36: aconst_null
/*      */     //   37: astore_2
/*      */     //   38: aconst_null
/*      */     //   39: astore_3
/*      */     //   40: aload_0
/*      */     //   41: invokevirtual 222	com/mysql/jdbc/ConnectionImpl:getMetadataSafeStatement	()Ljava/sql/Statement;
/*      */     //   44: astore_2
/*      */     //   45: aload_2
/*      */     //   46: ldc_w 675
/*      */     //   49: invokeinterface 224 2 0
/*      */     //   54: astore_3
/*      */     //   55: aload_3
/*      */     //   56: invokeinterface 226 1 0
/*      */     //   61: ifeq +26 -> 87
/*      */     //   64: aload_3
/*      */     //   65: iconst_1
/*      */     //   66: invokeinterface 676 2 0
/*      */     //   71: ifeq +7 -> 78
/*      */     //   74: iconst_1
/*      */     //   75: goto +4 -> 79
/*      */     //   78: iconst_0
/*      */     //   79: istore 4
/*      */     //   81: jsr +59 -> 140
/*      */     //   84: iload 4
/*      */     //   86: ireturn
/*      */     //   87: goto +39 -> 126
/*      */     //   90: astore 4
/*      */     //   92: aload 4
/*      */     //   94: invokevirtual 9	java/sql/SQLException:getErrorCode	()I
/*      */     //   97: sipush 1820
/*      */     //   100: if_icmpne +10 -> 110
/*      */     //   103: aload_0
/*      */     //   104: invokevirtual 231	com/mysql/jdbc/ConnectionImpl:getDisconnectOnExpiredPasswords	()Z
/*      */     //   107: ifeq +19 -> 126
/*      */     //   110: ldc_w 677
/*      */     //   113: ldc_w 381
/*      */     //   116: aload 4
/*      */     //   118: aload_0
/*      */     //   119: invokevirtual 131	com/mysql/jdbc/ConnectionImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   122: invokestatic 434	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   125: athrow
/*      */     //   126: jsr +14 -> 140
/*      */     //   129: goto +49 -> 178
/*      */     //   132: astore 5
/*      */     //   134: jsr +6 -> 140
/*      */     //   137: aload 5
/*      */     //   139: athrow
/*      */     //   140: astore 6
/*      */     //   142: aload_3
/*      */     //   143: ifnull +16 -> 159
/*      */     //   146: aload_3
/*      */     //   147: invokeinterface 253 1 0
/*      */     //   152: goto +5 -> 157
/*      */     //   155: astore 7
/*      */     //   157: aconst_null
/*      */     //   158: astore_3
/*      */     //   159: aload_2
/*      */     //   160: ifnull +16 -> 176
/*      */     //   163: aload_2
/*      */     //   164: invokeinterface 254 1 0
/*      */     //   169: goto +5 -> 174
/*      */     //   172: astore 7
/*      */     //   174: aconst_null
/*      */     //   175: astore_2
/*      */     //   176: ret 6
/*      */     //   178: aload_0
/*      */     //   179: getfield 99	com/mysql/jdbc/ConnectionImpl:readOnly	Z
/*      */     //   182: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #3609	-> byte code offset #0
/*      */     //   Java source line #3610	-> byte code offset #36
/*      */     //   Java source line #3611	-> byte code offset #38
/*      */     //   Java source line #3615	-> byte code offset #40
/*      */     //   Java source line #3617	-> byte code offset #45
/*      */     //   Java source line #3618	-> byte code offset #55
/*      */     //   Java source line #3619	-> byte code offset #64
/*      */     //   Java source line #3626	-> byte code offset #87
/*      */     //   Java source line #3621	-> byte code offset #90
/*      */     //   Java source line #3622	-> byte code offset #92
/*      */     //   Java source line #3623	-> byte code offset #110
/*      */     //   Java source line #3628	-> byte code offset #126
/*      */     //   Java source line #3648	-> byte code offset #129
/*      */     //   Java source line #3629	-> byte code offset #132
/*      */     //   Java source line #3631	-> byte code offset #146
/*      */     //   Java source line #3634	-> byte code offset #152
/*      */     //   Java source line #3632	-> byte code offset #155
/*      */     //   Java source line #3636	-> byte code offset #157
/*      */     //   Java source line #3639	-> byte code offset #159
/*      */     //   Java source line #3641	-> byte code offset #163
/*      */     //   Java source line #3644	-> byte code offset #169
/*      */     //   Java source line #3642	-> byte code offset #172
/*      */     //   Java source line #3646	-> byte code offset #174
/*      */     //   Java source line #3651	-> byte code offset #178
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	183	0	this	ConnectionImpl
/*      */     //   0	183	1	useSessionStatus	boolean
/*      */     //   37	139	2	stmt	java.sql.Statement
/*      */     //   39	120	3	rs	ResultSet
/*      */     //   79	6	4	bool	boolean
/*      */     //   90	27	4	ex1	SQLException
/*      */     //   132	6	5	localObject1	Object
/*      */     //   140	1	6	localObject2	Object
/*      */     //   155	3	7	ex	Exception
/*      */     //   172	3	7	ex	Exception
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   40	81	90	java/sql/SQLException
/*      */     //   40	84	132	finally
/*      */     //   87	129	132	finally
/*      */     //   132	137	132	finally
/*      */     //   146	152	155	java/lang/Exception
/*      */     //   163	169	172	java/lang/Exception
/*      */   }
/*      */   
/*      */   public void releaseSavepoint(Savepoint arg0)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   /* Error */
/*      */   public void setFailedOver(boolean flag)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 29	com/mysql/jdbc/ConnectionImpl:getConnectionMutex	()Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_2
/*      */     //   8: monitorexit
/*      */     //   9: goto +8 -> 17
/*      */     //   12: astore_3
/*      */     //   13: aload_2
/*      */     //   14: monitorexit
/*      */     //   15: aload_3
/*      */     //   16: athrow
/*      */     //   17: return
/*      */     // Line number table:
/*      */     //   Java source line #4975	-> byte code offset #0
/*      */     //   Java source line #4977	-> byte code offset #7
/*      */     //   Java source line #4978	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	18	0	this	ConnectionImpl
/*      */     //   0	18	1	flag	boolean
/*      */     //   5	9	2	Ljava/lang/Object;	Object
/*      */     //   12	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	9	12	finally
/*      */     //   12	15	12	finally
/*      */   }
/*      */   
/*      */   public void setHoldability(int arg0)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void setPreferSlaveDuringFailover(boolean flag) {}
/*      */   
/*      */   /* Error */
/*      */   public boolean useAnsiQuotedIdentifiers()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 29	com/mysql/jdbc/ConnectionImpl:getConnectionMutex	()Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 105	com/mysql/jdbc/ConnectionImpl:useAnsiQuotes	Z
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5268	-> byte code offset #0
/*      */     //   Java source line #5269	-> byte code offset #7
/*      */     //   Java source line #5270	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	ConnectionImpl
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public CachedResultSetMetaData getCachedMetaData(String sql)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 617	com/mysql/jdbc/ConnectionImpl:resultSetMetadataCache	Lcom/mysql/jdbc/util/LRUCache;
/*      */     //   4: ifnull +29 -> 33
/*      */     //   7: aload_0
/*      */     //   8: getfield 617	com/mysql/jdbc/ConnectionImpl:resultSetMetadataCache	Lcom/mysql/jdbc/util/LRUCache;
/*      */     //   11: dup
/*      */     //   12: astore_2
/*      */     //   13: monitorenter
/*      */     //   14: aload_0
/*      */     //   15: getfield 617	com/mysql/jdbc/ConnectionImpl:resultSetMetadataCache	Lcom/mysql/jdbc/util/LRUCache;
/*      */     //   18: aload_1
/*      */     //   19: invokevirtual 258	com/mysql/jdbc/util/LRUCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   22: checkcast 874	com/mysql/jdbc/CachedResultSetMetaData
/*      */     //   25: aload_2
/*      */     //   26: monitorexit
/*      */     //   27: areturn
/*      */     //   28: astore_3
/*      */     //   29: aload_2
/*      */     //   30: monitorexit
/*      */     //   31: aload_3
/*      */     //   32: athrow
/*      */     //   33: aconst_null
/*      */     //   34: areturn
/*      */     // Line number table:
/*      */     //   Java source line #5294	-> byte code offset #0
/*      */     //   Java source line #5295	-> byte code offset #7
/*      */     //   Java source line #5296	-> byte code offset #14
/*      */     //   Java source line #5297	-> byte code offset #28
/*      */     //   Java source line #5300	-> byte code offset #33
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	35	0	this	ConnectionImpl
/*      */     //   0	35	1	sql	String
/*      */     //   12	18	2	Ljava/lang/Object;	Object
/*      */     //   28	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	27	28	finally
/*      */     //   28	31	28	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getSessionMaxRows()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 29	com/mysql/jdbc/ConnectionImpl:getConnectionMutex	()Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 80	com/mysql/jdbc/ConnectionImpl:sessionMaxRows	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5460	-> byte code offset #0
/*      */     //   Java source line #5461	-> byte code offset #7
/*      */     //   Java source line #5462	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	ConnectionImpl
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ConnectionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */