/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stax.StAXResult;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBC4MysqlSQLXML
/*     */   implements SQLXML
/*     */ {
/*     */   private XMLInputFactory inputFactory;
/*     */   private XMLOutputFactory outputFactory;
/*     */   private String stringRep;
/*     */   private ResultSetInternalMethods owningResultSet;
/*     */   private int columnIndexOfXml;
/*     */   private boolean fromResultSet;
/*  84 */   private boolean isClosed = false;
/*     */   
/*     */   private boolean workingWithResult;
/*     */   
/*     */   private DOMResult asDOMResult;
/*     */   
/*     */   private SAXResult asSAXResult;
/*     */   
/*     */   private SimpleSaxToReader saxToReaderConverter;
/*     */   
/*     */   private StringWriter asStringWriter;
/*     */   
/*     */   private ByteArrayOutputStream asByteArrayOutputStream;
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   protected JDBC4MysqlSQLXML(ResultSetInternalMethods owner, int index, ExceptionInterceptor exceptionInterceptor)
/*     */   {
/* 101 */     this.owningResultSet = owner;
/* 102 */     this.columnIndexOfXml = index;
/* 103 */     this.fromResultSet = true;
/* 104 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */   
/*     */   protected JDBC4MysqlSQLXML(ExceptionInterceptor exceptionInterceptor) {
/* 108 */     this.fromResultSet = false;
/* 109 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */   
/*     */   public synchronized void free() throws SQLException {
/* 113 */     this.stringRep = null;
/* 114 */     this.asDOMResult = null;
/* 115 */     this.asSAXResult = null;
/* 116 */     this.inputFactory = null;
/* 117 */     this.outputFactory = null;
/* 118 */     this.owningResultSet = null;
/* 119 */     this.workingWithResult = false;
/* 120 */     this.isClosed = true;
/*     */   }
/*     */   
/*     */   public synchronized String getString() throws SQLException
/*     */   {
/* 125 */     checkClosed();
/* 126 */     checkWorkingWithResult();
/*     */     
/* 128 */     if (this.fromResultSet) {
/* 129 */       return this.owningResultSet.getString(this.columnIndexOfXml);
/*     */     }
/*     */     
/* 132 */     return this.stringRep;
/*     */   }
/*     */   
/*     */   private synchronized void checkClosed() throws SQLException {
/* 136 */     if (this.isClosed) {
/* 137 */       throw SQLError.createSQLException("SQLXMLInstance has been free()d", this.exceptionInterceptor);
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void checkWorkingWithResult() throws SQLException {
/* 142 */     if (this.workingWithResult) {
/* 143 */       throw SQLError.createSQLException("Can't perform requested operation after getResult() has been called to write XML data", "S1009", this.exceptionInterceptor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setString(String str)
/*     */     throws SQLException
/*     */   {
/* 174 */     checkClosed();
/* 175 */     checkWorkingWithResult();
/*     */     
/* 177 */     this.stringRep = str;
/* 178 */     this.fromResultSet = false;
/*     */   }
/*     */   
/*     */   public synchronized boolean isEmpty() throws SQLException {
/* 182 */     checkClosed();
/* 183 */     checkWorkingWithResult();
/*     */     
/* 185 */     if (!this.fromResultSet) {
/* 186 */       return (this.stringRep == null) || (this.stringRep.length() == 0);
/*     */     }
/*     */     
/* 189 */     return false;
/*     */   }
/*     */   
/*     */   public synchronized InputStream getBinaryStream() throws SQLException {
/* 193 */     checkClosed();
/* 194 */     checkWorkingWithResult();
/*     */     
/* 196 */     return this.owningResultSet.getBinaryStream(this.columnIndexOfXml);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Reader getCharacterStream()
/*     */     throws SQLException
/*     */   {
/* 224 */     checkClosed();
/* 225 */     checkWorkingWithResult();
/*     */     
/* 227 */     return this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Source getSource(Class clazz)
/*     */     throws SQLException
/*     */   {
/* 275 */     checkClosed();
/* 276 */     checkWorkingWithResult();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 281 */     if ((clazz == null) || (clazz.equals(SAXSource.class)))
/*     */     {
/* 283 */       InputSource inputSource = null;
/*     */       
/* 285 */       if (this.fromResultSet) {
/* 286 */         inputSource = new InputSource(this.owningResultSet.getCharacterStream(this.columnIndexOfXml));
/*     */       } else {
/* 288 */         inputSource = new InputSource(new StringReader(this.stringRep));
/*     */       }
/*     */       
/* 291 */       return new SAXSource(inputSource); }
/* 292 */     if (clazz.equals(DOMSource.class)) {
/*     */       try {
/* 294 */         DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
/* 295 */         builderFactory.setNamespaceAware(true);
/* 296 */         DocumentBuilder builder = builderFactory.newDocumentBuilder();
/*     */         
/* 298 */         InputSource inputSource = null;
/*     */         
/* 300 */         if (this.fromResultSet) {
/* 301 */           inputSource = new InputSource(this.owningResultSet.getCharacterStream(this.columnIndexOfXml));
/*     */         } else {
/* 303 */           inputSource = new InputSource(new StringReader(this.stringRep));
/*     */         }
/*     */         
/* 306 */         return new DOMSource(builder.parse(inputSource));
/*     */       } catch (Throwable t) {
/* 308 */         SQLException sqlEx = SQLError.createSQLException(t.getMessage(), "S1009", this.exceptionInterceptor);
/* 309 */         sqlEx.initCause(t);
/*     */         
/* 311 */         throw sqlEx;
/*     */       }
/*     */     }
/* 314 */     if (clazz.equals(StreamSource.class)) {
/* 315 */       Reader reader = null;
/*     */       
/* 317 */       if (this.fromResultSet) {
/* 318 */         reader = this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
/*     */       } else {
/* 320 */         reader = new StringReader(this.stringRep);
/*     */       }
/*     */       
/* 323 */       return new StreamSource(reader); }
/* 324 */     if (clazz.equals(StAXSource.class)) {
/*     */       try {
/* 326 */         Reader reader = null;
/*     */         
/* 328 */         if (this.fromResultSet) {
/* 329 */           reader = this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
/*     */         } else {
/* 331 */           reader = new StringReader(this.stringRep);
/*     */         }
/*     */         
/* 334 */         return new StAXSource(this.inputFactory.createXMLStreamReader(reader));
/*     */       } catch (XMLStreamException ex) {
/* 336 */         SQLException sqlEx = SQLError.createSQLException(ex.getMessage(), "S1009", this.exceptionInterceptor);
/* 337 */         sqlEx.initCause(ex);
/*     */         
/* 339 */         throw sqlEx;
/*     */       }
/*     */     }
/* 342 */     throw SQLError.createSQLException("XML Source of type \"" + clazz.toString() + "\" Not supported.", "S1009", this.exceptionInterceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized OutputStream setBinaryStream()
/*     */     throws SQLException
/*     */   {
/* 366 */     checkClosed();
/* 367 */     checkWorkingWithResult();
/*     */     
/* 369 */     this.workingWithResult = true;
/*     */     
/* 371 */     return setBinaryStreamInternal();
/*     */   }
/*     */   
/*     */   private synchronized OutputStream setBinaryStreamInternal() throws SQLException {
/* 375 */     this.asByteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/* 377 */     return this.asByteArrayOutputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Writer setCharacterStream()
/*     */     throws SQLException
/*     */   {
/* 405 */     checkClosed();
/* 406 */     checkWorkingWithResult();
/*     */     
/* 408 */     this.workingWithResult = true;
/*     */     
/* 410 */     return setCharacterStreamInternal();
/*     */   }
/*     */   
/*     */   private synchronized Writer setCharacterStreamInternal() throws SQLException {
/* 414 */     this.asStringWriter = new StringWriter();
/*     */     
/* 416 */     return this.asStringWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Result setResult(Class clazz)
/*     */     throws SQLException
/*     */   {
/* 462 */     checkClosed();
/* 463 */     checkWorkingWithResult();
/*     */     
/* 465 */     this.workingWithResult = true;
/* 466 */     this.asDOMResult = null;
/* 467 */     this.asSAXResult = null;
/* 468 */     this.saxToReaderConverter = null;
/* 469 */     this.stringRep = null;
/* 470 */     this.asStringWriter = null;
/* 471 */     this.asByteArrayOutputStream = null;
/*     */     
/* 473 */     if ((clazz == null) || (clazz.equals(SAXResult.class))) {
/* 474 */       this.saxToReaderConverter = new SimpleSaxToReader();
/*     */       
/* 476 */       this.asSAXResult = new SAXResult(this.saxToReaderConverter);
/*     */       
/* 478 */       return this.asSAXResult; }
/* 479 */     if (clazz.equals(DOMResult.class))
/*     */     {
/* 481 */       this.asDOMResult = new DOMResult();
/* 482 */       return this.asDOMResult;
/*     */     }
/* 484 */     if (clazz.equals(StreamResult.class))
/* 485 */       return new StreamResult(setCharacterStreamInternal());
/* 486 */     if (clazz.equals(StAXResult.class)) {
/*     */       try {
/* 488 */         if (this.outputFactory == null) {
/* 489 */           this.outputFactory = XMLOutputFactory.newInstance();
/*     */         }
/*     */         
/* 492 */         return new StAXResult(this.outputFactory.createXMLEventWriter(setCharacterStreamInternal()));
/*     */       } catch (XMLStreamException ex) {
/* 494 */         SQLException sqlEx = SQLError.createSQLException(ex.getMessage(), "S1009", this.exceptionInterceptor);
/* 495 */         sqlEx.initCause(ex);
/*     */         
/* 497 */         throw sqlEx;
/*     */       }
/*     */     }
/* 500 */     throw SQLError.createSQLException("XML Result of type \"" + clazz.toString() + "\" Not supported.", "S1009", this.exceptionInterceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Reader binaryInputStreamStreamToReader(ByteArrayOutputStream out)
/*     */   {
/*     */     try
/*     */     {
/* 511 */       String encoding = "UTF-8";
/*     */       try
/*     */       {
/* 514 */         ByteArrayInputStream bIn = new ByteArrayInputStream(out.toByteArray());
/* 515 */         XMLStreamReader reader = this.inputFactory.createXMLStreamReader(bIn);
/*     */         
/* 517 */         int eventType = 0;
/*     */         
/* 519 */         while ((eventType = reader.next()) != 8) {
/* 520 */           if (eventType == 7) {
/* 521 */             String possibleEncoding = reader.getEncoding();
/*     */             
/* 523 */             if (possibleEncoding != null) {
/* 524 */               encoding = possibleEncoding;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 534 */       return new StringReader(new String(out.toByteArray(), encoding));
/*     */     } catch (UnsupportedEncodingException badEnc) {
/* 536 */       throw new RuntimeException(badEnc);
/*     */     }
/*     */   }
/*     */   
/*     */   protected String readerToString(Reader reader) throws SQLException {
/* 541 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 543 */     int charsRead = 0;
/*     */     
/* 545 */     char[] charBuf = new char['Ȁ'];
/*     */     try
/*     */     {
/* 548 */       while ((charsRead = reader.read(charBuf)) != -1) {
/* 549 */         buf.append(charBuf, 0, charsRead);
/*     */       }
/*     */     } catch (IOException ioEx) {
/* 552 */       SQLException sqlEx = SQLError.createSQLException(ioEx.getMessage(), "S1009", this.exceptionInterceptor);
/* 553 */       sqlEx.initCause(ioEx);
/*     */       
/* 555 */       throw sqlEx;
/*     */     }
/*     */     
/* 558 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected synchronized Reader serializeAsCharacterStream() throws SQLException {
/* 562 */     checkClosed();
/* 563 */     if (this.workingWithResult)
/*     */     {
/* 565 */       if (this.stringRep != null) {
/* 566 */         return new StringReader(this.stringRep);
/*     */       }
/*     */       
/* 569 */       if (this.asDOMResult != null) {
/* 570 */         return new StringReader(domSourceToString());
/*     */       }
/*     */       
/* 573 */       if (this.asStringWriter != null) {
/* 574 */         return new StringReader(this.asStringWriter.toString());
/*     */       }
/*     */       
/* 577 */       if (this.asSAXResult != null) {
/* 578 */         return this.saxToReaderConverter.toReader();
/*     */       }
/*     */       
/* 581 */       if (this.asByteArrayOutputStream != null) {
/* 582 */         return binaryInputStreamStreamToReader(this.asByteArrayOutputStream);
/*     */       }
/*     */     }
/*     */     
/* 586 */     return this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
/*     */   }
/*     */   
/*     */   protected String domSourceToString() throws SQLException {
/*     */     try {
/* 591 */       DOMSource source = new DOMSource(this.asDOMResult.getNode());
/* 592 */       Transformer identity = TransformerFactory.newInstance().newTransformer();
/* 593 */       StringWriter stringOut = new StringWriter();
/* 594 */       Result result = new StreamResult(stringOut);
/* 595 */       identity.transform(source, result);
/*     */       
/* 597 */       return stringOut.toString();
/*     */     } catch (Throwable t) {
/* 599 */       SQLException sqlEx = SQLError.createSQLException(t.getMessage(), "S1009", this.exceptionInterceptor);
/* 600 */       sqlEx.initCause(t);
/*     */       
/* 602 */       throw sqlEx;
/*     */     }
/*     */   }
/*     */   
/*     */   protected synchronized String serializeAsString() throws SQLException {
/* 607 */     checkClosed();
/* 608 */     if (this.workingWithResult)
/*     */     {
/* 610 */       if (this.stringRep != null) {
/* 611 */         return this.stringRep;
/*     */       }
/*     */       
/* 614 */       if (this.asDOMResult != null) {
/* 615 */         return domSourceToString();
/*     */       }
/*     */       
/* 618 */       if (this.asStringWriter != null) {
/* 619 */         return this.asStringWriter.toString();
/*     */       }
/*     */       
/* 622 */       if (this.asSAXResult != null) {
/* 623 */         return readerToString(this.saxToReaderConverter.toReader());
/*     */       }
/*     */       
/* 626 */       if (this.asByteArrayOutputStream != null) {
/* 627 */         return readerToString(binaryInputStreamStreamToReader(this.asByteArrayOutputStream));
/*     */       }
/*     */     }
/*     */     
/* 631 */     return this.owningResultSet.getString(this.columnIndexOfXml);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class SimpleSaxToReader
/*     */     extends DefaultHandler
/*     */   {
/*     */     SimpleSaxToReader() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 656 */     StringBuilder buf = new StringBuilder();
/*     */     
/*     */     public void startDocument() throws SAXException {
/* 659 */       this.buf.append("<?xml version='1.0' encoding='UTF-8'?>"); }
/*     */     
/*     */     public void endDocument()
/*     */       throws SAXException
/*     */     {}
/*     */     
/*     */     public void startElement(String namespaceURI, String sName, String qName, Attributes attrs)
/*     */       throws SAXException
/*     */     {
/* 668 */       this.buf.append("<");
/* 669 */       this.buf.append(qName);
/*     */       
/* 671 */       if (attrs != null) {
/* 672 */         for (int i = 0; i < attrs.getLength(); i++) {
/* 673 */           this.buf.append(" ");
/* 674 */           this.buf.append(attrs.getQName(i)).append("=\"");
/* 675 */           escapeCharsForXml(attrs.getValue(i), true);
/* 676 */           this.buf.append("\"");
/*     */         }
/*     */       }
/*     */       
/* 680 */       this.buf.append(">");
/*     */     }
/*     */     
/*     */     public void characters(char[] buf, int offset, int len) throws SAXException {
/* 684 */       if (!this.inCDATA) {
/* 685 */         escapeCharsForXml(buf, offset, len, false);
/*     */       } else {
/* 687 */         this.buf.append(buf, offset, len);
/*     */       }
/*     */     }
/*     */     
/*     */     public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 692 */       characters(ch, start, length);
/*     */     }
/*     */     
/* 695 */     private boolean inCDATA = false;
/*     */     
/*     */     public void startCDATA() throws SAXException {
/* 698 */       this.buf.append("<![CDATA[");
/* 699 */       this.inCDATA = true;
/*     */     }
/*     */     
/*     */     public void endCDATA() throws SAXException {
/* 703 */       this.inCDATA = false;
/* 704 */       this.buf.append("]]>");
/*     */     }
/*     */     
/*     */     public void comment(char[] ch, int start, int length) throws SAXException
/*     */     {
/* 709 */       this.buf.append("<!--");
/* 710 */       for (int i = 0; i < length; i++) {
/* 711 */         this.buf.append(ch[(start + i)]);
/*     */       }
/* 713 */       this.buf.append("-->");
/*     */     }
/*     */     
/*     */     Reader toReader()
/*     */     {
/* 718 */       return new StringReader(this.buf.toString());
/*     */     }
/*     */     
/*     */     private void escapeCharsForXml(String str, boolean isAttributeData) {
/* 722 */       if (str == null) {
/* 723 */         return;
/*     */       }
/*     */       
/* 726 */       int strLen = str.length();
/*     */       
/* 728 */       for (int i = 0; i < strLen; i++) {
/* 729 */         escapeCharsForXml(str.charAt(i), isAttributeData);
/*     */       }
/*     */     }
/*     */     
/*     */     private void escapeCharsForXml(char[] buf, int offset, int len, boolean isAttributeData)
/*     */     {
/* 735 */       if (buf == null) {
/* 736 */         return;
/*     */       }
/*     */       
/* 739 */       for (int i = 0; i < len; i++) {
/* 740 */         escapeCharsForXml(buf[(offset + i)], isAttributeData);
/*     */       }
/*     */     }
/*     */     
/*     */     private void escapeCharsForXml(char c, boolean isAttributeData) {
/* 745 */       switch (c) {
/*     */       case '<': 
/* 747 */         this.buf.append("&lt;");
/* 748 */         break;
/*     */       
/*     */       case '>': 
/* 751 */         this.buf.append("&gt;");
/* 752 */         break;
/*     */       
/*     */       case '&': 
/* 755 */         this.buf.append("&amp;");
/* 756 */         break;
/*     */       
/*     */ 
/*     */       case '"': 
/* 760 */         if (!isAttributeData) {
/* 761 */           this.buf.append("\"");
/*     */         } else {
/* 763 */           this.buf.append("&quot;");
/*     */         }
/*     */         
/* 766 */         break;
/*     */       
/*     */       case '\r': 
/* 769 */         this.buf.append("&#xD;");
/* 770 */         break;
/*     */       
/*     */ 
/*     */       default: 
/* 774 */         if (((c >= '\001') && (c <= '\037') && (c != '\t') && (c != '\n')) || ((c >= '') && (c <= '')) || (c == ' ') || ((isAttributeData) && ((c == '\t') || (c == '\n'))))
/*     */         {
/* 776 */           this.buf.append("&#x");
/* 777 */           this.buf.append(Integer.toHexString(c).toUpperCase());
/* 778 */           this.buf.append(";");
/*     */         } else {
/* 780 */           this.buf.append(c);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/JDBC4MysqlSQLXML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */