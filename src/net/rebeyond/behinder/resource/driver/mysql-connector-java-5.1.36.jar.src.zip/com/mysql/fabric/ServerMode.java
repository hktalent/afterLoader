/*    */ package com.mysql.fabric;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ServerMode
/*    */ {
/* 31 */   OFFLINE,  READ_ONLY,  WRITE_ONLY,  READ_WRITE;
/*    */   
/*    */   private ServerMode() {}
/* 34 */   public static ServerMode getFromConstant(Integer constant) { return values()[constant.intValue()]; }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/ServerMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */