/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.ref.PhantomReference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.net.URLDecoder;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonRegisteringDriver
/*     */   implements Driver
/*     */ {
/*     */   private static final String ALLOWED_QUOTES = "\"'";
/*     */   private static final String REPLICATION_URL_PREFIX = "jdbc:mysql:replication://";
/*     */   private static final String URL_PREFIX = "jdbc:mysql://";
/*     */   private static final String MXJ_URL_PREFIX = "jdbc:mysql:mxj://";
/*     */   public static final String LOADBALANCE_URL_PREFIX = "jdbc:mysql:loadbalance://";
/*  71 */   protected static final ConcurrentHashMap<ConnectionPhantomReference, ConnectionPhantomReference> connectionPhantomRefs = new ConcurrentHashMap();
/*     */   
/*  73 */   protected static final ReferenceQueue<ConnectionImpl> refQueue = new ReferenceQueue();
/*     */   
/*  75 */   public static final String OS = getOSName();
/*  76 */   public static final String PLATFORM = getPlatform();
/*     */   public static final String LICENSE = "GPL";
/*  78 */   public static final String RUNTIME_VENDOR = System.getProperty("java.vendor");
/*  79 */   public static final String RUNTIME_VERSION = System.getProperty("java.version");
/*     */   public static final String VERSION = "5.1.36";
/*     */   public static final String NAME = "MySQL Connector Java";
/*     */   public static final String DBNAME_PROPERTY_KEY = "DBNAME";
/*     */   public static final boolean DEBUG = false;
/*     */   public static final int HOST_NAME_INDEX = 0;
/*     */   public static final String HOST_PROPERTY_KEY = "HOST";
/*     */   public static final String NUM_HOSTS_PROPERTY_KEY = "NUM_HOSTS";
/*     */   public static final String PASSWORD_PROPERTY_KEY = "password";
/*     */   
/*     */   public static String getOSName() {
/*  90 */     return System.getProperty("os.name");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPlatform()
/*     */   {
/* 100 */     return System.getProperty("os.arch");
/*     */   }
/*     */   
/*     */   static {
/* 104 */     AbandonedConnectionCleanupThread referenceThread = new AbandonedConnectionCleanupThread();
/* 105 */     referenceThread.setDaemon(true);
/* 106 */     referenceThread.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int PORT_NUMBER_INDEX = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PORT_PROPERTY_KEY = "PORT";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROPERTIES_TRANSFORM_KEY = "propertiesTransform";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String USE_CONFIG_PROPERTY_KEY = "useConfigs";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String USER_PROPERTY_KEY = "user";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PROTOCOL_PROPERTY_KEY = "PROTOCOL";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String PATH_PROPERTY_KEY = "PATH";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int getMajorVersionInternal()
/*     */   {
/* 166 */     return safeIntParse("5");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int getMinorVersionInternal()
/*     */   {
/* 175 */     return safeIntParse("1");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String[] parseHostPortPair(String hostPortPair)
/*     */     throws SQLException
/*     */   {
/* 194 */     String[] splitValues = new String[2];
/*     */     
/* 196 */     if (StringUtils.startsWithIgnoreCaseAndWs(hostPortPair, "address")) {
/* 197 */       splitValues[0] = hostPortPair.trim();
/* 198 */       splitValues[1] = null;
/*     */       
/* 200 */       return splitValues;
/*     */     }
/*     */     
/* 203 */     int portIndex = hostPortPair.indexOf(":");
/*     */     
/* 205 */     String hostname = null;
/*     */     
/* 207 */     if (portIndex != -1) {
/* 208 */       if (portIndex + 1 < hostPortPair.length()) {
/* 209 */         String portAsString = hostPortPair.substring(portIndex + 1);
/* 210 */         hostname = hostPortPair.substring(0, portIndex);
/*     */         
/* 212 */         splitValues[0] = hostname;
/*     */         
/* 214 */         splitValues[1] = portAsString;
/*     */       } else {
/* 216 */         throw SQLError.createSQLException(Messages.getString("NonRegisteringDriver.37"), "01S00", null);
/*     */       }
/*     */     } else {
/* 219 */       splitValues[0] = hostPortPair;
/* 220 */       splitValues[1] = null;
/*     */     }
/*     */     
/* 223 */     return splitValues;
/*     */   }
/*     */   
/*     */   private static int safeIntParse(String intAsString) {
/*     */     try {
/* 228 */       return Integer.parseInt(intAsString);
/*     */     } catch (NumberFormatException nfe) {}
/* 230 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean acceptsURL(String url)
/*     */     throws SQLException
/*     */   {
/* 260 */     return parseURL(url, null) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public java.sql.Connection connect(String url, Properties info)
/*     */     throws SQLException
/*     */   {
/* 306 */     if (url != null) {
/* 307 */       if (StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:loadbalance://"))
/* 308 */         return connectLoadBalanced(url, info);
/* 309 */       if (StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:replication://")) {
/* 310 */         return connectReplicationConnection(url, info);
/*     */       }
/*     */     }
/*     */     
/* 314 */     Properties props = null;
/*     */     
/* 316 */     if ((props = parseURL(url, info)) == null) {
/* 317 */       return null;
/*     */     }
/*     */     
/* 320 */     if (!"1".equals(props.getProperty("NUM_HOSTS"))) {
/* 321 */       return connectFailover(url, info);
/*     */     }
/*     */     try
/*     */     {
/* 325 */       return ConnectionImpl.getInstance(host(props), port(props), props, database(props), url);
/*     */ 
/*     */     }
/*     */     catch (SQLException sqlEx)
/*     */     {
/*     */ 
/* 331 */       throw sqlEx;
/*     */     } catch (Exception ex) {
/* 333 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("NonRegisteringDriver.17") + ex.toString() + Messages.getString("NonRegisteringDriver.18"), "08001", null);
/*     */       
/*     */ 
/*     */ 
/* 337 */       sqlEx.initCause(ex);
/*     */       
/* 339 */       throw sqlEx;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void trackConnection(Connection newConn)
/*     */   {
/* 345 */     ConnectionPhantomReference phantomRef = new ConnectionPhantomReference((ConnectionImpl)newConn, refQueue);
/* 346 */     connectionPhantomRefs.put(phantomRef, phantomRef);
/*     */   }
/*     */   
/*     */   private java.sql.Connection connectLoadBalanced(String url, Properties info) throws SQLException {
/* 350 */     Properties parsedProps = parseURL(url, info);
/*     */     
/* 352 */     if (parsedProps == null) {
/* 353 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 357 */     parsedProps.remove("roundRobinLoadBalance");
/*     */     
/* 359 */     int numHosts = Integer.parseInt(parsedProps.getProperty("NUM_HOSTS"));
/*     */     
/* 361 */     List<String> hostList = new ArrayList();
/*     */     
/* 363 */     for (int i = 0; i < numHosts; i++) {
/* 364 */       int index = i + 1;
/*     */       
/* 366 */       hostList.add(parsedProps.getProperty(new StringBuilder().append("HOST.").append(index).toString()) + ":" + parsedProps.getProperty(new StringBuilder().append("PORT.").append(index).toString()));
/*     */     }
/*     */     
/* 369 */     LoadBalancingConnectionProxy proxyBal = new LoadBalancingConnectionProxy(hostList, parsedProps);
/*     */     
/* 371 */     return (java.sql.Connection)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { LoadBalancedConnection.class }, proxyBal);
/*     */   }
/*     */   
/*     */   private java.sql.Connection connectFailover(String url, Properties info) throws SQLException
/*     */   {
/* 376 */     Properties parsedProps = parseURL(url, info);
/*     */     
/* 378 */     if (parsedProps == null) {
/* 379 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 383 */     parsedProps.remove("roundRobinLoadBalance");
/*     */     
/* 385 */     int numHosts = Integer.parseInt(parsedProps.getProperty("NUM_HOSTS"));
/*     */     
/* 387 */     List<String> hostList = new ArrayList();
/*     */     
/* 389 */     for (int i = 0; i < numHosts; i++) {
/* 390 */       int index = i + 1;
/*     */       
/* 392 */       hostList.add(parsedProps.getProperty(new StringBuilder().append("HOST.").append(index).toString()) + ":" + parsedProps.getProperty(new StringBuilder().append("PORT.").append(index).toString()));
/*     */     }
/*     */     
/* 395 */     FailoverConnectionProxy connProxy = new FailoverConnectionProxy(hostList, parsedProps);
/*     */     
/* 397 */     return (java.sql.Connection)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { Connection.class }, connProxy);
/*     */   }
/*     */   
/*     */   protected java.sql.Connection connectReplicationConnection(String url, Properties info) throws SQLException
/*     */   {
/* 402 */     Properties parsedProps = parseURL(url, info);
/*     */     
/* 404 */     if (parsedProps == null) {
/* 405 */       return null;
/*     */     }
/*     */     
/* 408 */     Properties masterProps = (Properties)parsedProps.clone();
/* 409 */     Properties slavesProps = (Properties)parsedProps.clone();
/*     */     
/*     */ 
/*     */ 
/* 413 */     slavesProps.setProperty("com.mysql.jdbc.ReplicationConnection.isSlave", "true");
/*     */     
/* 415 */     int numHosts = Integer.parseInt(parsedProps.getProperty("NUM_HOSTS"));
/*     */     
/* 417 */     if (numHosts < 2) {
/* 418 */       throw SQLError.createSQLException("Must specify at least one slave host to connect to for master/slave replication load-balancing functionality", "01S00", null);
/*     */     }
/*     */     
/* 421 */     List<String> slaveHostList = new ArrayList();
/* 422 */     List<String> masterHostList = new ArrayList();
/*     */     
/* 424 */     String firstHost = masterProps.getProperty("HOST.1") + ":" + masterProps.getProperty("PORT.1");
/*     */     
/* 426 */     boolean usesExplicitServerType = isHostPropertiesList(firstHost);
/*     */     
/* 428 */     for (int i = 0; i < numHosts; i++) {
/* 429 */       int index = i + 1;
/*     */       
/* 431 */       masterProps.remove("HOST." + index);
/* 432 */       masterProps.remove("PORT." + index);
/* 433 */       slavesProps.remove("HOST." + index);
/* 434 */       slavesProps.remove("PORT." + index);
/*     */       
/* 436 */       String host = parsedProps.getProperty("HOST." + index);
/* 437 */       String port = parsedProps.getProperty("PORT." + index);
/* 438 */       if (usesExplicitServerType) {
/* 439 */         if (isHostMaster(host)) {
/* 440 */           masterHostList.add(host);
/*     */         } else {
/* 442 */           slaveHostList.add(host);
/*     */         }
/*     */       }
/* 445 */       else if (i == 0) {
/* 446 */         masterHostList.add(host + ":" + port);
/*     */       } else {
/* 448 */         slaveHostList.add(host + ":" + port);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 453 */     slavesProps.remove("NUM_HOSTS");
/* 454 */     masterProps.remove("NUM_HOSTS");
/* 455 */     masterProps.remove("HOST");
/* 456 */     masterProps.remove("PORT");
/* 457 */     slavesProps.remove("HOST");
/* 458 */     slavesProps.remove("PORT");
/*     */     
/* 460 */     return new ReplicationConnection(masterProps, slavesProps, masterHostList, slaveHostList);
/*     */   }
/*     */   
/*     */   private boolean isHostMaster(String host) {
/* 464 */     if (isHostPropertiesList(host)) {
/* 465 */       Properties hostSpecificProps = expandHostKeyValues(host);
/* 466 */       if ((hostSpecificProps.containsKey("type")) && ("master".equalsIgnoreCase(hostSpecificProps.get("type").toString()))) {
/* 467 */         return true;
/*     */       }
/*     */     }
/* 470 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String database(Properties props)
/*     */   {
/* 482 */     return props.getProperty("DBNAME");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMajorVersion()
/*     */   {
/* 491 */     return getMajorVersionInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinorVersion()
/*     */   {
/* 500 */     return getMinorVersionInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DriverPropertyInfo[] getPropertyInfo(String url, Properties info)
/*     */     throws SQLException
/*     */   {
/* 529 */     if (info == null) {
/* 530 */       info = new Properties();
/*     */     }
/*     */     
/* 533 */     if ((url != null) && (url.startsWith("jdbc:mysql://"))) {
/* 534 */       info = parseURL(url, info);
/*     */     }
/*     */     
/* 537 */     DriverPropertyInfo hostProp = new DriverPropertyInfo("HOST", info.getProperty("HOST"));
/* 538 */     hostProp.required = true;
/* 539 */     hostProp.description = Messages.getString("NonRegisteringDriver.3");
/*     */     
/* 541 */     DriverPropertyInfo portProp = new DriverPropertyInfo("PORT", info.getProperty("PORT", "3306"));
/* 542 */     portProp.required = false;
/* 543 */     portProp.description = Messages.getString("NonRegisteringDriver.7");
/*     */     
/* 545 */     DriverPropertyInfo dbProp = new DriverPropertyInfo("DBNAME", info.getProperty("DBNAME"));
/* 546 */     dbProp.required = false;
/* 547 */     dbProp.description = "Database name";
/*     */     
/* 549 */     DriverPropertyInfo userProp = new DriverPropertyInfo("user", info.getProperty("user"));
/* 550 */     userProp.required = true;
/* 551 */     userProp.description = Messages.getString("NonRegisteringDriver.13");
/*     */     
/* 553 */     DriverPropertyInfo passwordProp = new DriverPropertyInfo("password", info.getProperty("password"));
/* 554 */     passwordProp.required = true;
/* 555 */     passwordProp.description = Messages.getString("NonRegisteringDriver.16");
/*     */     
/* 557 */     DriverPropertyInfo[] dpi = ConnectionPropertiesImpl.exposeAsDriverPropertyInfo(info, 5);
/*     */     
/* 559 */     dpi[0] = hostProp;
/* 560 */     dpi[1] = portProp;
/* 561 */     dpi[2] = dbProp;
/* 562 */     dpi[3] = userProp;
/* 563 */     dpi[4] = passwordProp;
/*     */     
/* 565 */     return dpi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String host(Properties props)
/*     */   {
/* 582 */     return props.getProperty("HOST", "localhost");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean jdbcCompliant()
/*     */   {
/* 598 */     return false;
/*     */   }
/*     */   
/*     */   public Properties parseURL(String url, Properties defaults) throws SQLException {
/* 602 */     Properties urlProps = defaults != null ? new Properties(defaults) : new Properties();
/*     */     
/* 604 */     if (url == null) {
/* 605 */       return null;
/*     */     }
/*     */     
/* 608 */     if ((!StringUtils.startsWithIgnoreCase(url, "jdbc:mysql://")) && (!StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:mxj://")) && (!StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:loadbalance://")) && (!StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:replication://")))
/*     */     {
/*     */ 
/* 611 */       return null;
/*     */     }
/*     */     
/* 614 */     int beginningOfSlashes = url.indexOf("//");
/*     */     
/* 616 */     if (StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:mxj://"))
/*     */     {
/* 618 */       urlProps.setProperty("socketFactory", "com.mysql.management.driverlaunched.ServerLauncherSocketFactory");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 625 */     int index = url.indexOf("?");
/*     */     
/* 627 */     if (index != -1) {
/* 628 */       String paramString = url.substring(index + 1, url.length());
/* 629 */       url = url.substring(0, index);
/*     */       
/* 631 */       StringTokenizer queryParams = new StringTokenizer(paramString, "&");
/*     */       
/* 633 */       while (queryParams.hasMoreTokens()) {
/* 634 */         String parameterValuePair = queryParams.nextToken();
/*     */         
/* 636 */         int indexOfEquals = StringUtils.indexOfIgnoreCase(0, parameterValuePair, "=");
/*     */         
/* 638 */         String parameter = null;
/* 639 */         String value = null;
/*     */         
/* 641 */         if (indexOfEquals != -1) {
/* 642 */           parameter = parameterValuePair.substring(0, indexOfEquals);
/*     */           
/* 644 */           if (indexOfEquals + 1 < parameterValuePair.length()) {
/* 645 */             value = parameterValuePair.substring(indexOfEquals + 1);
/*     */           }
/*     */         }
/*     */         
/* 649 */         if ((value != null) && (value.length() > 0) && (parameter != null) && (parameter.length() > 0)) {
/*     */           try {
/* 651 */             urlProps.put(parameter, URLDecoder.decode(value, "UTF-8"));
/*     */           }
/*     */           catch (UnsupportedEncodingException badEncoding) {
/* 654 */             urlProps.put(parameter, URLDecoder.decode(value));
/*     */           }
/*     */           catch (NoSuchMethodError nsme) {
/* 657 */             urlProps.put(parameter, URLDecoder.decode(value));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 663 */     url = url.substring(beginningOfSlashes + 2);
/*     */     
/* 665 */     String hostStuff = null;
/*     */     
/* 667 */     int slashIndex = StringUtils.indexOfIgnoreCase(0, url, "/", "\"'", "\"'", StringUtils.SEARCH_MODE__ALL);
/*     */     
/* 669 */     if (slashIndex != -1) {
/* 670 */       hostStuff = url.substring(0, slashIndex);
/*     */       
/* 672 */       if (slashIndex + 1 < url.length()) {
/* 673 */         urlProps.put("DBNAME", url.substring(slashIndex + 1, url.length()));
/*     */       }
/*     */     } else {
/* 676 */       hostStuff = url;
/*     */     }
/*     */     
/* 679 */     int numHosts = 0;
/*     */     
/* 681 */     if ((hostStuff != null) && (hostStuff.trim().length() > 0)) {
/* 682 */       List<String> hosts = StringUtils.split(hostStuff, ",", "\"'", "\"'", false);
/*     */       
/* 684 */       for (String hostAndPort : hosts) {
/* 685 */         numHosts++;
/*     */         
/* 687 */         String[] hostPortPair = parseHostPortPair(hostAndPort);
/*     */         
/* 689 */         if ((hostPortPair[0] != null) && (hostPortPair[0].trim().length() > 0)) {
/* 690 */           urlProps.setProperty("HOST." + numHosts, hostPortPair[0]);
/*     */         } else {
/* 692 */           urlProps.setProperty("HOST." + numHosts, "localhost");
/*     */         }
/*     */         
/* 695 */         if (hostPortPair[1] != null) {
/* 696 */           urlProps.setProperty("PORT." + numHosts, hostPortPair[1]);
/*     */         } else {
/* 698 */           urlProps.setProperty("PORT." + numHosts, "3306");
/*     */         }
/*     */       }
/*     */     } else {
/* 702 */       numHosts = 1;
/* 703 */       urlProps.setProperty("HOST.1", "localhost");
/* 704 */       urlProps.setProperty("PORT.1", "3306");
/*     */     }
/*     */     
/* 707 */     urlProps.setProperty("NUM_HOSTS", String.valueOf(numHosts));
/* 708 */     urlProps.setProperty("HOST", urlProps.getProperty("HOST.1"));
/* 709 */     urlProps.setProperty("PORT", urlProps.getProperty("PORT.1"));
/*     */     
/* 711 */     String propertiesTransformClassName = urlProps.getProperty("propertiesTransform");
/*     */     
/* 713 */     if (propertiesTransformClassName != null) {
/*     */       try {
/* 715 */         ConnectionPropertiesTransform propTransformer = (ConnectionPropertiesTransform)Class.forName(propertiesTransformClassName).newInstance();
/*     */         
/* 717 */         urlProps = propTransformer.transformProperties(urlProps);
/*     */       } catch (InstantiationException e) {
/* 719 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00", null);
/*     */       }
/*     */       catch (IllegalAccessException e) {
/* 722 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00", null);
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 725 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00", null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 730 */     if ((Util.isColdFusion()) && (urlProps.getProperty("autoConfigureForColdFusion", "true").equalsIgnoreCase("true"))) {
/* 731 */       String configs = urlProps.getProperty("useConfigs");
/*     */       
/* 733 */       StringBuilder newConfigs = new StringBuilder();
/*     */       
/* 735 */       if (configs != null) {
/* 736 */         newConfigs.append(configs);
/* 737 */         newConfigs.append(",");
/*     */       }
/*     */       
/* 740 */       newConfigs.append("coldFusion");
/*     */       
/* 742 */       urlProps.setProperty("useConfigs", newConfigs.toString());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 747 */     String configNames = null;
/*     */     
/* 749 */     if (defaults != null) {
/* 750 */       configNames = defaults.getProperty("useConfigs");
/*     */     }
/*     */     
/* 753 */     if (configNames == null) {
/* 754 */       configNames = urlProps.getProperty("useConfigs");
/*     */     }
/*     */     
/* 757 */     if (configNames != null) {
/* 758 */       List<String> splitNames = StringUtils.split(configNames, ",", true);
/*     */       
/* 760 */       Properties configProps = new Properties();
/*     */       
/* 762 */       Iterator<String> namesIter = splitNames.iterator();
/*     */       
/* 764 */       while (namesIter.hasNext()) {
/* 765 */         String configName = (String)namesIter.next();
/*     */         try
/*     */         {
/* 768 */           InputStream configAsStream = getClass().getResourceAsStream("configs/" + configName + ".properties");
/*     */           
/* 770 */           if (configAsStream == null) {
/* 771 */             throw SQLError.createSQLException("Can't find configuration template named '" + configName + "'", "01S00", null);
/*     */           }
/*     */           
/* 774 */           configProps.load(configAsStream);
/*     */         } catch (IOException ioEx) {
/* 776 */           SQLException sqlEx = SQLError.createSQLException("Unable to load configuration template '" + configName + "' due to underlying IOException: " + ioEx, "01S00", null);
/*     */           
/* 778 */           sqlEx.initCause(ioEx);
/*     */           
/* 780 */           throw sqlEx;
/*     */         }
/*     */       }
/*     */       
/* 784 */       Iterator<Object> propsIter = urlProps.keySet().iterator();
/*     */       
/* 786 */       while (propsIter.hasNext()) {
/* 787 */         String key = propsIter.next().toString();
/* 788 */         String property = urlProps.getProperty(key);
/* 789 */         configProps.setProperty(key, property);
/*     */       }
/*     */       
/* 792 */       urlProps = configProps;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 797 */     if (defaults != null) {
/* 798 */       Iterator<Object> propsIter = defaults.keySet().iterator();
/*     */       
/* 800 */       while (propsIter.hasNext()) {
/* 801 */         String key = propsIter.next().toString();
/* 802 */         if (!key.equals("NUM_HOSTS")) {
/* 803 */           String property = defaults.getProperty(key);
/* 804 */           urlProps.setProperty(key, property);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 809 */     return urlProps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int port(Properties props)
/*     */   {
/* 821 */     return Integer.parseInt(props.getProperty("PORT", "3306"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String property(String name, Properties props)
/*     */   {
/* 835 */     return props.getProperty(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Properties expandHostKeyValues(String host)
/*     */   {
/* 844 */     Properties hostProps = new Properties();
/*     */     
/* 846 */     if (isHostPropertiesList(host)) {
/* 847 */       host = host.substring("address=".length() + 1);
/* 848 */       List<String> hostPropsList = StringUtils.split(host, ")", "'\"", "'\"", true);
/*     */       
/* 850 */       for (String propDef : hostPropsList) {
/* 851 */         if (propDef.startsWith("(")) {
/* 852 */           propDef = propDef.substring(1);
/*     */         }
/*     */         
/* 855 */         List<String> kvp = StringUtils.split(propDef, "=", "'\"", "'\"", true);
/*     */         
/* 857 */         String key = (String)kvp.get(0);
/* 858 */         String value = kvp.size() > 1 ? (String)kvp.get(1) : null;
/*     */         
/* 860 */         if ((value != null) && (((value.startsWith("\"")) && (value.endsWith("\""))) || ((value.startsWith("'")) && (value.endsWith("'"))))) {
/* 861 */           value = value.substring(1, value.length() - 1);
/*     */         }
/*     */         
/* 864 */         if (value != null) {
/* 865 */           if (("HOST".equalsIgnoreCase(key)) || ("DBNAME".equalsIgnoreCase(key)) || ("PORT".equalsIgnoreCase(key)) || ("PROTOCOL".equalsIgnoreCase(key)) || ("PATH".equalsIgnoreCase(key)))
/*     */           {
/* 867 */             key = key.toUpperCase(Locale.ENGLISH);
/* 868 */           } else if (("user".equalsIgnoreCase(key)) || ("password".equalsIgnoreCase(key))) {
/* 869 */             key = key.toLowerCase(Locale.ENGLISH);
/*     */           }
/*     */           
/* 872 */           hostProps.setProperty(key, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 877 */     return hostProps;
/*     */   }
/*     */   
/*     */ 
/* 881 */   public static boolean isHostPropertiesList(String host) { return (host != null) && (StringUtils.startsWithIgnoreCase(host, "address=")); }
/*     */   
/*     */   public NonRegisteringDriver() throws SQLException
/*     */   {}
/*     */   
/*     */   static class ConnectionPhantomReference extends PhantomReference<ConnectionImpl> { private NetworkResources io;
/*     */     
/* 888 */     ConnectionPhantomReference(ConnectionImpl connectionImpl, ReferenceQueue<ConnectionImpl> q) { super(q);
/*     */       try
/*     */       {
/* 891 */         this.io = connectionImpl.getIO().getNetworkResources();
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */     
/*     */     void cleanup()
/*     */     {
/* 898 */       if (this.io != null) {
/*     */         try {
/* 900 */           this.io.forceClose();
/*     */         } finally {
/* 902 */           this.io = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/NonRegisteringDriver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */