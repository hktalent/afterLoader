/*    */ package com.mysql.jdbc.jdbc2.optional;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.XAConnection;
/*    */ import javax.sql.XADataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlXADataSource
/*    */   extends MysqlDataSource
/*    */   implements XADataSource
/*    */ {
/*    */   static final long serialVersionUID = 7911390333152247455L;
/*    */   
/*    */   public XAConnection getXAConnection()
/*    */     throws SQLException
/*    */   {
/* 40 */     java.sql.Connection conn = getConnection();
/*    */     
/* 42 */     return wrapConnection(conn);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public XAConnection getXAConnection(String u, String p)
/*    */     throws SQLException
/*    */   {
/* 50 */     java.sql.Connection conn = getConnection(u, p);
/*    */     
/* 52 */     return wrapConnection(conn);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private XAConnection wrapConnection(java.sql.Connection conn)
/*    */     throws SQLException
/*    */   {
/* 60 */     if ((getPinGlobalTxToPhysicalConnection()) || (((com.mysql.jdbc.Connection)conn).getPinGlobalTxToPhysicalConnection())) {
/* 61 */       return SuspendableXAConnection.getInstance((com.mysql.jdbc.Connection)conn);
/*    */     }
/*    */     
/* 64 */     return MysqlXAConnection.getInstance((com.mysql.jdbc.Connection)conn, getLogXaCommands());
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/jdbc2/optional/MysqlXADataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */