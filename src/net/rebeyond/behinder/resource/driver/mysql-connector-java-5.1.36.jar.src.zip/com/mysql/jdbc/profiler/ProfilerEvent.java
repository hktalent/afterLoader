/*     */ package com.mysql.jdbc.profiler;
/*     */ 
/*     */ import com.mysql.jdbc.StringUtils;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProfilerEvent
/*     */ {
/*     */   public static final byte TYPE_WARN = 0;
/*     */   public static final byte TYPE_OBJECT_CREATION = 1;
/*     */   public static final byte TYPE_PREPARE = 2;
/*     */   public static final byte TYPE_QUERY = 3;
/*     */   public static final byte TYPE_EXECUTE = 4;
/*     */   public static final byte TYPE_FETCH = 5;
/*     */   public static final byte TYPE_SLOW_QUERY = 6;
/*     */   protected byte eventType;
/*     */   protected long connectionId;
/*     */   protected int statementId;
/*     */   protected int resultSetId;
/*     */   protected long eventCreationTime;
/*     */   protected long eventDuration;
/*     */   protected String durationUnits;
/*     */   protected int hostNameIndex;
/*     */   protected String hostName;
/*     */   protected int catalogIndex;
/*     */   protected String catalog;
/*     */   protected int eventCreationPointIndex;
/*     */   protected String eventCreationPointDesc;
/*     */   protected String message;
/*     */   
/*     */   public ProfilerEvent(byte eventType, String hostName, String catalog, long connectionId, int statementId, int resultSetId, long eventCreationTime, long eventDuration, String durationUnits, String eventCreationPointDesc, String eventCreationPoint, String message)
/*     */   {
/* 169 */     this.eventType = eventType;
/* 170 */     this.connectionId = connectionId;
/* 171 */     this.statementId = statementId;
/* 172 */     this.resultSetId = resultSetId;
/* 173 */     this.eventCreationTime = eventCreationTime;
/* 174 */     this.eventDuration = eventDuration;
/* 175 */     this.durationUnits = durationUnits;
/* 176 */     this.eventCreationPointDesc = eventCreationPointDesc;
/* 177 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEventCreationPointAsString()
/*     */   {
/* 186 */     return this.eventCreationPointDesc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 196 */     StringBuilder buf = new StringBuilder(32);
/*     */     
/* 198 */     switch (this.eventType) {
/*     */     case 4: 
/* 200 */       buf.append("EXECUTE");
/* 201 */       break;
/*     */     
/*     */     case 5: 
/* 204 */       buf.append("FETCH");
/* 205 */       break;
/*     */     
/*     */     case 1: 
/* 208 */       buf.append("CONSTRUCT");
/* 209 */       break;
/*     */     
/*     */     case 2: 
/* 212 */       buf.append("PREPARE");
/* 213 */       break;
/*     */     
/*     */     case 3: 
/* 216 */       buf.append("QUERY");
/* 217 */       break;
/*     */     
/*     */     case 0: 
/* 220 */       buf.append("WARN");
/* 221 */       break;
/*     */     case 6: 
/* 223 */       buf.append("SLOW QUERY");
/* 224 */       break;
/*     */     default: 
/* 226 */       buf.append("UNKNOWN");
/*     */     }
/*     */     
/* 229 */     buf.append(" created: ");
/* 230 */     buf.append(new Date(this.eventCreationTime));
/* 231 */     buf.append(" duration: ");
/* 232 */     buf.append(this.eventDuration);
/* 233 */     buf.append(" connection: ");
/* 234 */     buf.append(this.connectionId);
/* 235 */     buf.append(" statement: ");
/* 236 */     buf.append(this.statementId);
/* 237 */     buf.append(" resultset: ");
/* 238 */     buf.append(this.resultSetId);
/*     */     
/* 240 */     if (this.message != null) {
/* 241 */       buf.append(" message: ");
/* 242 */       buf.append(this.message);
/*     */     }
/*     */     
/*     */ 
/* 246 */     if (this.eventCreationPointDesc != null) {
/* 247 */       buf.append("\n\nEvent Created at:\n");
/* 248 */       buf.append(this.eventCreationPointDesc);
/*     */     }
/*     */     
/* 251 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ProfilerEvent unpack(byte[] buf)
/*     */     throws Exception
/*     */   {
/* 264 */     int pos = 0;
/*     */     
/* 266 */     byte eventType = buf[(pos++)];
/* 267 */     long connectionId = readInt(buf, pos);
/* 268 */     pos += 8;
/* 269 */     int statementId = readInt(buf, pos);
/* 270 */     pos += 4;
/* 271 */     int resultSetId = readInt(buf, pos);
/* 272 */     pos += 4;
/* 273 */     long eventCreationTime = readLong(buf, pos);
/* 274 */     pos += 8;
/* 275 */     long eventDuration = readLong(buf, pos);
/* 276 */     pos += 4;
/*     */     
/* 278 */     byte[] eventDurationUnits = readBytes(buf, pos);
/* 279 */     pos += 4;
/*     */     
/* 281 */     if (eventDurationUnits != null) {
/* 282 */       pos += eventDurationUnits.length;
/*     */     }
/*     */     
/* 285 */     readInt(buf, pos);
/* 286 */     pos += 4;
/* 287 */     byte[] eventCreationAsBytes = readBytes(buf, pos);
/* 288 */     pos += 4;
/*     */     
/* 290 */     if (eventCreationAsBytes != null) {
/* 291 */       pos += eventCreationAsBytes.length;
/*     */     }
/*     */     
/* 294 */     byte[] message = readBytes(buf, pos);
/* 295 */     pos += 4;
/*     */     
/* 297 */     if (message != null) {
/* 298 */       pos += message.length;
/*     */     }
/*     */     
/* 301 */     return new ProfilerEvent(eventType, "", "", connectionId, statementId, resultSetId, eventCreationTime, eventDuration, StringUtils.toString(eventDurationUnits, "ISO8859_1"), StringUtils.toString(eventCreationAsBytes, "ISO8859_1"), null, StringUtils.toString(message, "ISO8859_1"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] pack()
/*     */     throws Exception
/*     */   {
/* 314 */     int len = 29;
/*     */     
/* 316 */     byte[] eventCreationAsBytes = null;
/*     */     
/* 318 */     getEventCreationPointAsString();
/*     */     
/* 320 */     if (this.eventCreationPointDesc != null) {
/* 321 */       eventCreationAsBytes = StringUtils.getBytes(this.eventCreationPointDesc, "ISO8859_1");
/* 322 */       len += 4 + eventCreationAsBytes.length;
/*     */     } else {
/* 324 */       len += 4;
/*     */     }
/*     */     
/* 327 */     byte[] messageAsBytes = null;
/*     */     
/* 329 */     if (this.message != null) {
/* 330 */       messageAsBytes = StringUtils.getBytes(this.message, "ISO8859_1");
/* 331 */       len += 4 + messageAsBytes.length;
/*     */     } else {
/* 333 */       len += 4;
/*     */     }
/*     */     
/* 336 */     byte[] durationUnitsAsBytes = null;
/*     */     
/* 338 */     if (this.durationUnits != null) {
/* 339 */       durationUnitsAsBytes = StringUtils.getBytes(this.durationUnits, "ISO8859_1");
/* 340 */       len += 4 + durationUnitsAsBytes.length;
/*     */     } else {
/* 342 */       len += 4;
/* 343 */       durationUnitsAsBytes = StringUtils.getBytes("", "ISO8859_1");
/*     */     }
/*     */     
/* 346 */     byte[] buf = new byte[len];
/*     */     
/* 348 */     int pos = 0;
/*     */     
/* 350 */     buf[(pos++)] = this.eventType;
/* 351 */     pos = writeLong(this.connectionId, buf, pos);
/* 352 */     pos = writeInt(this.statementId, buf, pos);
/* 353 */     pos = writeInt(this.resultSetId, buf, pos);
/* 354 */     pos = writeLong(this.eventCreationTime, buf, pos);
/* 355 */     pos = writeLong(this.eventDuration, buf, pos);
/* 356 */     pos = writeBytes(durationUnitsAsBytes, buf, pos);
/* 357 */     pos = writeInt(this.eventCreationPointIndex, buf, pos);
/*     */     
/* 359 */     if (eventCreationAsBytes != null) {
/* 360 */       pos = writeBytes(eventCreationAsBytes, buf, pos);
/*     */     } else {
/* 362 */       pos = writeInt(0, buf, pos);
/*     */     }
/*     */     
/* 365 */     if (messageAsBytes != null) {
/* 366 */       pos = writeBytes(messageAsBytes, buf, pos);
/*     */     } else {
/* 368 */       pos = writeInt(0, buf, pos);
/*     */     }
/*     */     
/* 371 */     return buf;
/*     */   }
/*     */   
/*     */   private static int writeInt(int i, byte[] buf, int pos)
/*     */   {
/* 376 */     buf[(pos++)] = ((byte)(i & 0xFF));
/* 377 */     buf[(pos++)] = ((byte)(i >>> 8));
/* 378 */     buf[(pos++)] = ((byte)(i >>> 16));
/* 379 */     buf[(pos++)] = ((byte)(i >>> 24));
/*     */     
/* 381 */     return pos;
/*     */   }
/*     */   
/*     */   private static int writeLong(long l, byte[] buf, int pos) {
/* 385 */     buf[(pos++)] = ((byte)(int)(l & 0xFF));
/* 386 */     buf[(pos++)] = ((byte)(int)(l >>> 8));
/* 387 */     buf[(pos++)] = ((byte)(int)(l >>> 16));
/* 388 */     buf[(pos++)] = ((byte)(int)(l >>> 24));
/* 389 */     buf[(pos++)] = ((byte)(int)(l >>> 32));
/* 390 */     buf[(pos++)] = ((byte)(int)(l >>> 40));
/* 391 */     buf[(pos++)] = ((byte)(int)(l >>> 48));
/* 392 */     buf[(pos++)] = ((byte)(int)(l >>> 56));
/*     */     
/* 394 */     return pos;
/*     */   }
/*     */   
/*     */   private static int writeBytes(byte[] msg, byte[] buf, int pos) {
/* 398 */     pos = writeInt(msg.length, buf, pos);
/*     */     
/* 400 */     System.arraycopy(msg, 0, buf, pos, msg.length);
/*     */     
/* 402 */     return pos + msg.length;
/*     */   }
/*     */   
/*     */   private static int readInt(byte[] buf, int pos) {
/* 406 */     return buf[(pos++)] & 0xFF | (buf[(pos++)] & 0xFF) << 8 | (buf[(pos++)] & 0xFF) << 16 | (buf[(pos++)] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */   private static long readLong(byte[] buf, int pos)
/*     */   {
/* 411 */     return buf[(pos++)] & 0xFF | (buf[(pos++)] & 0xFF) << 8 | (buf[(pos++)] & 0xFF) << 16 | (buf[(pos++)] & 0xFF) << 24 | (buf[(pos++)] & 0xFF) << 32 | (buf[(pos++)] & 0xFF) << 40 | (buf[(pos++)] & 0xFF) << 48 | (buf[(pos++)] & 0xFF) << 56;
/*     */   }
/*     */   
/*     */ 
/*     */   private static byte[] readBytes(byte[] buf, int pos)
/*     */   {
/* 417 */     int length = readInt(buf, pos);
/*     */     
/* 419 */     pos += 4;
/*     */     
/* 421 */     byte[] msg = new byte[length];
/* 422 */     System.arraycopy(buf, pos, msg, 0, length);
/*     */     
/* 424 */     return msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCatalog()
/*     */   {
/* 433 */     return this.catalog;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getConnectionId()
/*     */   {
/* 442 */     return this.connectionId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getEventCreationTime()
/*     */   {
/* 452 */     return this.eventCreationTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getEventDuration()
/*     */   {
/* 461 */     return this.eventDuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDurationUnits()
/*     */   {
/* 468 */     return this.durationUnits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getEventType()
/*     */   {
/* 477 */     return this.eventType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getResultSetId()
/*     */   {
/* 486 */     return this.resultSetId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatementId()
/*     */   {
/* 495 */     return this.statementId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 504 */     return this.message;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/profiler/ProfilerEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */