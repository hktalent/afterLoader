/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Buffer
/*     */ {
/*     */   static final int MAX_BYTES_TO_DUMP = 512;
/*     */   static final int NO_LENGTH_LIMIT = -1;
/*     */   static final long NULL_LENGTH = -1L;
/*  40 */   private int bufLength = 0;
/*     */   
/*     */   private byte[] byteBuffer;
/*     */   
/*  44 */   private int position = 0;
/*     */   
/*  46 */   protected boolean wasMultiPacket = false;
/*     */   
/*     */   public Buffer(byte[] buf) {
/*  49 */     this.byteBuffer = buf;
/*  50 */     setBufLength(buf.length);
/*     */   }
/*     */   
/*     */   Buffer(int size) {
/*  54 */     this.byteBuffer = new byte[size];
/*  55 */     setBufLength(this.byteBuffer.length);
/*  56 */     this.position = 4;
/*     */   }
/*     */   
/*     */   final void clear() {
/*  60 */     this.position = 4;
/*     */   }
/*     */   
/*     */   final void dump() {
/*  64 */     dump(getBufLength());
/*     */   }
/*     */   
/*     */   final String dump(int numBytes) {
/*  68 */     return StringUtils.dumpAsHex(getBytes(0, numBytes > getBufLength() ? getBufLength() : numBytes), numBytes > getBufLength() ? getBufLength() : numBytes);
/*     */   }
/*     */   
/*     */   final String dumpClampedBytes(int numBytes) {
/*  72 */     int numBytesToDump = numBytes < 512 ? numBytes : 512;
/*     */     
/*  74 */     String dumped = StringUtils.dumpAsHex(getBytes(0, numBytesToDump > getBufLength() ? getBufLength() : numBytesToDump), numBytesToDump > getBufLength() ? getBufLength() : numBytesToDump);
/*     */     
/*     */ 
/*  77 */     if (numBytesToDump < numBytes) {
/*  78 */       return dumped + " ....(packet exceeds max. dump length)";
/*     */     }
/*     */     
/*  81 */     return dumped;
/*     */   }
/*     */   
/*     */   final void dumpHeader() {
/*  85 */     for (int i = 0; i < 4; i++) {
/*  86 */       String hexVal = Integer.toHexString(readByte(i) & 0xFF);
/*     */       
/*  88 */       if (hexVal.length() == 1) {
/*  89 */         hexVal = "0" + hexVal;
/*     */       }
/*     */       
/*  92 */       System.out.print(hexVal + " ");
/*     */     }
/*     */   }
/*     */   
/*     */   final void dumpNBytes(int start, int nBytes) {
/*  97 */     StringBuilder asciiBuf = new StringBuilder();
/*     */     
/*  99 */     for (int i = start; (i < start + nBytes) && (i < getBufLength()); i++) {
/* 100 */       String hexVal = Integer.toHexString(readByte(i) & 0xFF);
/*     */       
/* 102 */       if (hexVal.length() == 1) {
/* 103 */         hexVal = "0" + hexVal;
/*     */       }
/*     */       
/* 106 */       System.out.print(hexVal + " ");
/*     */       
/* 108 */       if ((readByte(i) > 32) && (readByte(i) < Byte.MAX_VALUE)) {
/* 109 */         asciiBuf.append((char)readByte(i));
/*     */       } else {
/* 111 */         asciiBuf.append(".");
/*     */       }
/*     */       
/* 114 */       asciiBuf.append(" ");
/*     */     }
/*     */     
/* 117 */     System.out.println("    " + asciiBuf.toString());
/*     */   }
/*     */   
/*     */   final void ensureCapacity(int additionalData) throws SQLException {
/* 121 */     if (this.position + additionalData > getBufLength()) {
/* 122 */       if (this.position + additionalData < this.byteBuffer.length)
/*     */       {
/*     */ 
/*     */ 
/* 126 */         setBufLength(this.byteBuffer.length);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 131 */         int newLength = (int)(this.byteBuffer.length * 1.25D);
/*     */         
/* 133 */         if (newLength < this.byteBuffer.length + additionalData) {
/* 134 */           newLength = this.byteBuffer.length + (int)(additionalData * 1.25D);
/*     */         }
/*     */         
/* 137 */         if (newLength < this.byteBuffer.length) {
/* 138 */           newLength = this.byteBuffer.length + additionalData;
/*     */         }
/*     */         
/* 141 */         byte[] newBytes = new byte[newLength];
/*     */         
/* 143 */         System.arraycopy(this.byteBuffer, 0, newBytes, 0, this.byteBuffer.length);
/* 144 */         this.byteBuffer = newBytes;
/* 145 */         setBufLength(this.byteBuffer.length);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int fastSkipLenString()
/*     */   {
/* 156 */     long len = readFieldLength();
/*     */     
/* 158 */     this.position = ((int)(this.position + len));
/*     */     
/* 160 */     return (int)len;
/*     */   }
/*     */   
/*     */   public void fastSkipLenByteArray() {
/* 164 */     long len = readFieldLength();
/*     */     
/* 166 */     if ((len == -1L) || (len == 0L)) {
/* 167 */       return;
/*     */     }
/*     */     
/* 170 */     this.position = ((int)(this.position + len));
/*     */   }
/*     */   
/*     */   protected final byte[] getBufferSource() {
/* 174 */     return this.byteBuffer;
/*     */   }
/*     */   
/*     */   public int getBufLength() {
/* 178 */     return this.bufLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getByteBuffer()
/*     */   {
/* 187 */     return this.byteBuffer;
/*     */   }
/*     */   
/*     */   final byte[] getBytes(int len) {
/* 191 */     byte[] b = new byte[len];
/* 192 */     System.arraycopy(this.byteBuffer, this.position, b, 0, len);
/* 193 */     this.position += len;
/*     */     
/* 195 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes(int offset, int len)
/*     */   {
/* 204 */     byte[] dest = new byte[len];
/* 205 */     System.arraycopy(this.byteBuffer, offset, dest, 0, len);
/*     */     
/* 207 */     return dest;
/*     */   }
/*     */   
/*     */   int getCapacity() {
/* 211 */     return this.byteBuffer.length;
/*     */   }
/*     */   
/*     */   public ByteBuffer getNioBuffer() {
/* 215 */     throw new IllegalArgumentException(Messages.getString("ByteArrayBuffer.0"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPosition()
/*     */   {
/* 224 */     return this.position;
/*     */   }
/*     */   
/*     */   final boolean isLastDataPacket() {
/* 228 */     return (getBufLength() < 9) && ((this.byteBuffer[0] & 0xFF) == 254);
/*     */   }
/*     */   
/*     */   final boolean isAuthMethodSwitchRequestPacket() {
/* 232 */     return (this.byteBuffer[0] & 0xFF) == 254;
/*     */   }
/*     */   
/*     */   final boolean isOKPacket() {
/* 236 */     return (this.byteBuffer[0] & 0xFF) == 0;
/*     */   }
/*     */   
/*     */   final boolean isRawPacket() {
/* 240 */     return (this.byteBuffer[0] & 0xFF) == 1;
/*     */   }
/*     */   
/*     */   final long newReadLength() {
/* 244 */     int sw = this.byteBuffer[(this.position++)] & 0xFF;
/*     */     
/* 246 */     switch (sw) {
/*     */     case 251: 
/* 248 */       return 0L;
/*     */     
/*     */     case 252: 
/* 251 */       return readInt();
/*     */     
/*     */     case 253: 
/* 254 */       return readLongInt();
/*     */     
/*     */     case 254: 
/* 257 */       return readLongLong();
/*     */     }
/*     */     
/* 260 */     return sw;
/*     */   }
/*     */   
/*     */   final byte readByte()
/*     */   {
/* 265 */     return this.byteBuffer[(this.position++)];
/*     */   }
/*     */   
/*     */   final byte readByte(int readAt) {
/* 269 */     return this.byteBuffer[readAt];
/*     */   }
/*     */   
/*     */   final long readFieldLength() {
/* 273 */     int sw = this.byteBuffer[(this.position++)] & 0xFF;
/*     */     
/* 275 */     switch (sw) {
/*     */     case 251: 
/* 277 */       return -1L;
/*     */     
/*     */     case 252: 
/* 280 */       return readInt();
/*     */     
/*     */     case 253: 
/* 283 */       return readLongInt();
/*     */     
/*     */     case 254: 
/* 286 */       return readLongLong();
/*     */     }
/*     */     
/* 289 */     return sw;
/*     */   }
/*     */   
/*     */   final int readInt()
/*     */   {
/* 294 */     byte[] b = this.byteBuffer;
/*     */     
/* 296 */     return b[(this.position++)] & 0xFF | (b[(this.position++)] & 0xFF) << 8;
/*     */   }
/*     */   
/*     */   final int readIntAsLong() {
/* 300 */     byte[] b = this.byteBuffer;
/*     */     
/* 302 */     return b[(this.position++)] & 0xFF | (b[(this.position++)] & 0xFF) << 8 | (b[(this.position++)] & 0xFF) << 16 | (b[(this.position++)] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */   final byte[] readLenByteArray(int offset) {
/* 306 */     long len = readFieldLength();
/*     */     
/* 308 */     if (len == -1L) {
/* 309 */       return null;
/*     */     }
/*     */     
/* 312 */     if (len == 0L) {
/* 313 */       return Constants.EMPTY_BYTE_ARRAY;
/*     */     }
/*     */     
/* 316 */     this.position += offset;
/*     */     
/* 318 */     return getBytes((int)len);
/*     */   }
/*     */   
/*     */   final long readLength() {
/* 322 */     int sw = this.byteBuffer[(this.position++)] & 0xFF;
/*     */     
/* 324 */     switch (sw) {
/*     */     case 251: 
/* 326 */       return 0L;
/*     */     
/*     */     case 252: 
/* 329 */       return readInt();
/*     */     
/*     */     case 253: 
/* 332 */       return readLongInt();
/*     */     
/*     */     case 254: 
/* 335 */       return readLong();
/*     */     }
/*     */     
/* 338 */     return sw;
/*     */   }
/*     */   
/*     */   final long readLong()
/*     */   {
/* 343 */     byte[] b = this.byteBuffer;
/*     */     
/* 345 */     return b[(this.position++)] & 0xFF | (b[(this.position++)] & 0xFF) << 8 | (b[(this.position++)] & 0xFF) << 16 | (b[(this.position++)] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */   final int readLongInt()
/*     */   {
/* 350 */     byte[] b = this.byteBuffer;
/*     */     
/* 352 */     return b[(this.position++)] & 0xFF | (b[(this.position++)] & 0xFF) << 8 | (b[(this.position++)] & 0xFF) << 16;
/*     */   }
/*     */   
/*     */   final long readLongLong() {
/* 356 */     byte[] b = this.byteBuffer;
/*     */     
/* 358 */     return b[(this.position++)] & 0xFF | (b[(this.position++)] & 0xFF) << 8 | (b[(this.position++)] & 0xFF) << 16 | (b[(this.position++)] & 0xFF) << 24 | (b[(this.position++)] & 0xFF) << 32 | (b[(this.position++)] & 0xFF) << 40 | (b[(this.position++)] & 0xFF) << 48 | (b[(this.position++)] & 0xFF) << 56;
/*     */   }
/*     */   
/*     */ 
/*     */   final int readnBytes()
/*     */   {
/* 364 */     int sw = this.byteBuffer[(this.position++)] & 0xFF;
/*     */     
/* 366 */     switch (sw) {
/*     */     case 1: 
/* 368 */       return this.byteBuffer[(this.position++)] & 0xFF;
/*     */     
/*     */     case 2: 
/* 371 */       return readInt();
/*     */     
/*     */     case 3: 
/* 374 */       return readLongInt();
/*     */     
/*     */     case 4: 
/* 377 */       return (int)readLong();
/*     */     }
/*     */     
/* 380 */     return 255;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String readString()
/*     */   {
/* 390 */     int i = this.position;
/* 391 */     int len = 0;
/* 392 */     int maxLen = getBufLength();
/*     */     
/* 394 */     while ((i < maxLen) && (this.byteBuffer[i] != 0)) {
/* 395 */       len++;
/* 396 */       i++;
/*     */     }
/*     */     
/* 399 */     String s = StringUtils.toString(this.byteBuffer, this.position, len);
/* 400 */     this.position += len + 1;
/*     */     
/* 402 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final String readString(String encoding, ExceptionInterceptor exceptionInterceptor)
/*     */     throws SQLException
/*     */   {
/* 413 */     int i = this.position;
/* 414 */     int len = 0;
/* 415 */     int maxLen = getBufLength();
/*     */     
/* 417 */     while ((i < maxLen) && (this.byteBuffer[i] != 0)) {
/* 418 */       len++;
/* 419 */       i++;
/*     */     }
/*     */     try
/*     */     {
/* 423 */       return StringUtils.toString(this.byteBuffer, this.position, len, encoding);
/*     */     } catch (UnsupportedEncodingException uEE) {
/* 425 */       throw SQLError.createSQLException(Messages.getString("ByteArrayBuffer.1") + encoding + "'", "S1009", exceptionInterceptor);
/*     */     }
/*     */     finally {
/* 428 */       this.position += len + 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   final String readString(String encoding, ExceptionInterceptor exceptionInterceptor, int expectedLength)
/*     */     throws SQLException
/*     */   {
/* 436 */     if (this.position + expectedLength > getBufLength()) {
/* 437 */       throw SQLError.createSQLException(Messages.getString("ByteArrayBuffer.2"), "S1009", exceptionInterceptor);
/*     */     }
/*     */     try
/*     */     {
/* 441 */       return StringUtils.toString(this.byteBuffer, this.position, expectedLength, encoding);
/*     */     } catch (UnsupportedEncodingException uEE) {
/* 443 */       throw SQLError.createSQLException(Messages.getString("ByteArrayBuffer.1") + encoding + "'", "S1009", exceptionInterceptor);
/*     */     }
/*     */     finally {
/* 446 */       this.position += expectedLength;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBufLength(int bufLengthToSet) {
/* 451 */     this.bufLength = bufLengthToSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setByteBuffer(byte[] byteBufferToSet)
/*     */   {
/* 461 */     this.byteBuffer = byteBufferToSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPosition(int positionToSet)
/*     */   {
/* 471 */     this.position = positionToSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWasMultiPacket(boolean flag)
/*     */   {
/* 481 */     this.wasMultiPacket = flag;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 486 */     return dumpClampedBytes(getPosition());
/*     */   }
/*     */   
/*     */   public String toSuperString() {
/* 490 */     return super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean wasMultiPacket()
/*     */   {
/* 499 */     return this.wasMultiPacket;
/*     */   }
/*     */   
/*     */   public final void writeByte(byte b) throws SQLException {
/* 503 */     ensureCapacity(1);
/*     */     
/* 505 */     this.byteBuffer[(this.position++)] = b;
/*     */   }
/*     */   
/*     */   public final void writeBytesNoNull(byte[] bytes) throws SQLException
/*     */   {
/* 510 */     int len = bytes.length;
/* 511 */     ensureCapacity(len);
/* 512 */     System.arraycopy(bytes, 0, this.byteBuffer, this.position, len);
/* 513 */     this.position += len;
/*     */   }
/*     */   
/*     */   final void writeBytesNoNull(byte[] bytes, int offset, int length) throws SQLException
/*     */   {
/* 518 */     ensureCapacity(length);
/* 519 */     System.arraycopy(bytes, offset, this.byteBuffer, this.position, length);
/* 520 */     this.position += length;
/*     */   }
/*     */   
/*     */   final void writeDouble(double d) throws SQLException {
/* 524 */     long l = Double.doubleToLongBits(d);
/* 525 */     writeLongLong(l);
/*     */   }
/*     */   
/*     */   final void writeFieldLength(long length) throws SQLException {
/* 529 */     if (length < 251L) {
/* 530 */       writeByte((byte)(int)length);
/* 531 */     } else if (length < 65536L) {
/* 532 */       ensureCapacity(3);
/* 533 */       writeByte((byte)-4);
/* 534 */       writeInt((int)length);
/* 535 */     } else if (length < 16777216L) {
/* 536 */       ensureCapacity(4);
/* 537 */       writeByte((byte)-3);
/* 538 */       writeLongInt((int)length);
/*     */     } else {
/* 540 */       ensureCapacity(9);
/* 541 */       writeByte((byte)-2);
/* 542 */       writeLongLong(length);
/*     */     }
/*     */   }
/*     */   
/*     */   final void writeFloat(float f) throws SQLException {
/* 547 */     ensureCapacity(4);
/*     */     
/* 549 */     int i = Float.floatToIntBits(f);
/* 550 */     byte[] b = this.byteBuffer;
/* 551 */     b[(this.position++)] = ((byte)(i & 0xFF));
/* 552 */     b[(this.position++)] = ((byte)(i >>> 8));
/* 553 */     b[(this.position++)] = ((byte)(i >>> 16));
/* 554 */     b[(this.position++)] = ((byte)(i >>> 24));
/*     */   }
/*     */   
/*     */   final void writeInt(int i) throws SQLException {
/* 558 */     ensureCapacity(2);
/*     */     
/* 560 */     byte[] b = this.byteBuffer;
/* 561 */     b[(this.position++)] = ((byte)(i & 0xFF));
/* 562 */     b[(this.position++)] = ((byte)(i >>> 8));
/*     */   }
/*     */   
/*     */   final void writeLenBytes(byte[] b) throws SQLException
/*     */   {
/* 567 */     int len = b.length;
/* 568 */     ensureCapacity(len + 9);
/* 569 */     writeFieldLength(len);
/* 570 */     System.arraycopy(b, 0, this.byteBuffer, this.position, len);
/* 571 */     this.position += len;
/*     */   }
/*     */   
/*     */   final void writeLenString(String s, String encoding, String serverEncoding, SingleByteCharsetConverter converter, boolean parserKnowsUnicode, MySQLConnection conn)
/*     */     throws UnsupportedEncodingException, SQLException
/*     */   {
/* 577 */     byte[] b = null;
/*     */     
/* 579 */     if (converter != null) {
/* 580 */       b = converter.toBytes(s);
/*     */     } else {
/* 582 */       b = StringUtils.getBytes(s, encoding, serverEncoding, parserKnowsUnicode, conn, conn.getExceptionInterceptor());
/*     */     }
/*     */     
/* 585 */     int len = b.length;
/* 586 */     ensureCapacity(len + 9);
/* 587 */     writeFieldLength(len);
/* 588 */     System.arraycopy(b, 0, this.byteBuffer, this.position, len);
/* 589 */     this.position += len;
/*     */   }
/*     */   
/*     */   final void writeLong(long i) throws SQLException {
/* 593 */     ensureCapacity(4);
/*     */     
/* 595 */     byte[] b = this.byteBuffer;
/* 596 */     b[(this.position++)] = ((byte)(int)(i & 0xFF));
/* 597 */     b[(this.position++)] = ((byte)(int)(i >>> 8));
/* 598 */     b[(this.position++)] = ((byte)(int)(i >>> 16));
/* 599 */     b[(this.position++)] = ((byte)(int)(i >>> 24));
/*     */   }
/*     */   
/*     */   final void writeLongInt(int i) throws SQLException {
/* 603 */     ensureCapacity(3);
/* 604 */     byte[] b = this.byteBuffer;
/* 605 */     b[(this.position++)] = ((byte)(i & 0xFF));
/* 606 */     b[(this.position++)] = ((byte)(i >>> 8));
/* 607 */     b[(this.position++)] = ((byte)(i >>> 16));
/*     */   }
/*     */   
/*     */   final void writeLongLong(long i) throws SQLException {
/* 611 */     ensureCapacity(8);
/* 612 */     byte[] b = this.byteBuffer;
/* 613 */     b[(this.position++)] = ((byte)(int)(i & 0xFF));
/* 614 */     b[(this.position++)] = ((byte)(int)(i >>> 8));
/* 615 */     b[(this.position++)] = ((byte)(int)(i >>> 16));
/* 616 */     b[(this.position++)] = ((byte)(int)(i >>> 24));
/* 617 */     b[(this.position++)] = ((byte)(int)(i >>> 32));
/* 618 */     b[(this.position++)] = ((byte)(int)(i >>> 40));
/* 619 */     b[(this.position++)] = ((byte)(int)(i >>> 48));
/* 620 */     b[(this.position++)] = ((byte)(int)(i >>> 56));
/*     */   }
/*     */   
/*     */   final void writeString(String s) throws SQLException
/*     */   {
/* 625 */     ensureCapacity(s.length() * 3 + 1);
/* 626 */     writeStringNoNull(s);
/* 627 */     this.byteBuffer[(this.position++)] = 0;
/*     */   }
/*     */   
/*     */   final void writeString(String s, String encoding, MySQLConnection conn) throws SQLException
/*     */   {
/* 632 */     ensureCapacity(s.length() * 3 + 1);
/*     */     try {
/* 634 */       writeStringNoNull(s, encoding, encoding, false, conn);
/*     */     } catch (UnsupportedEncodingException ue) {
/* 636 */       throw new SQLException(ue.toString(), "S1000");
/*     */     }
/*     */     
/* 639 */     this.byteBuffer[(this.position++)] = 0;
/*     */   }
/*     */   
/*     */   final void writeStringNoNull(String s) throws SQLException
/*     */   {
/* 644 */     int len = s.length();
/* 645 */     ensureCapacity(len * 3);
/* 646 */     System.arraycopy(StringUtils.getBytes(s), 0, this.byteBuffer, this.position, len);
/* 647 */     this.position += len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void writeStringNoNull(String s, String encoding, String serverEncoding, boolean parserKnowsUnicode, MySQLConnection conn)
/*     */     throws UnsupportedEncodingException, SQLException
/*     */   {
/* 658 */     byte[] b = StringUtils.getBytes(s, encoding, serverEncoding, parserKnowsUnicode, conn, conn.getExceptionInterceptor());
/*     */     
/* 660 */     int len = b.length;
/* 661 */     ensureCapacity(len);
/* 662 */     System.arraycopy(b, 0, this.byteBuffer, this.position, len);
/* 663 */     this.position += len;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/Buffer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */