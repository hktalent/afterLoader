/*    */ package com.mysql.fabric;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerGroup
/*    */ {
/*    */   private String name;
/*    */   private Set<Server> servers;
/*    */   
/*    */   public ServerGroup(String name, Set<Server> servers)
/*    */   {
/* 36 */     this.name = name;
/* 37 */     this.servers = servers;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */   
/*    */   public Set<Server> getServers() {
/* 45 */     return this.servers;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Server getMaster()
/*    */   {
/* 53 */     for (Server s : this.servers) {
/* 54 */       if (s.getRole() == ServerRole.PRIMARY) {
/* 55 */         return s;
/*    */       }
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Server getServer(String hostPortString)
/*    */   {
/* 66 */     for (Server s : this.servers) {
/* 67 */       if (s.getHostPortString().equals(hostPortString)) {
/* 68 */         return s;
/*    */       }
/*    */     }
/* 71 */     return null;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 76 */     return String.format("Group[name=%s, servers=%s]", new Object[] { this.name, this.servers });
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/ServerGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */