/*    */ package com.mysql.fabric;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FabricStateResponse<T>
/*    */ {
/*    */   private T data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private long expireTimeMillis;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FabricStateResponse(T data, int secsTtl)
/*    */   {
/* 31 */     this.data = data;
/* 32 */     this.expireTimeMillis = (System.currentTimeMillis() + 1000 * secsTtl);
/*    */   }
/*    */   
/*    */   public FabricStateResponse(T data, long expireTimeMillis) {
/* 36 */     this.data = data;
/* 37 */     this.expireTimeMillis = expireTimeMillis;
/*    */   }
/*    */   
/*    */   public T getData() {
/* 41 */     return (T)this.data;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public long getExpireTimeMillis()
/*    */   {
/* 48 */     return this.expireTimeMillis;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/FabricStateResponse.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */