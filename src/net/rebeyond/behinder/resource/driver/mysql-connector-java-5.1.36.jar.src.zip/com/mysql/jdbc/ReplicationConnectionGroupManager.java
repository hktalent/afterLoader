/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.jmx.ReplicationGroupManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationConnectionGroupManager
/*     */ {
/*  34 */   private static HashMap<String, ReplicationConnectionGroup> GROUP_MAP = new HashMap();
/*     */   
/*  36 */   private static ReplicationGroupManager mbean = new ReplicationGroupManager();
/*     */   
/*  38 */   private static boolean hasRegisteredJmx = false;
/*     */   
/*     */   public static synchronized ReplicationConnectionGroup getConnectionGroupInstance(String groupName) {
/*  41 */     if (GROUP_MAP.containsKey(groupName)) {
/*  42 */       return (ReplicationConnectionGroup)GROUP_MAP.get(groupName);
/*     */     }
/*  44 */     ReplicationConnectionGroup group = new ReplicationConnectionGroup(groupName);
/*  45 */     GROUP_MAP.put(groupName, group);
/*  46 */     return group;
/*     */   }
/*     */   
/*     */   public static void registerJmx() throws SQLException
/*     */   {
/*  51 */     if (hasRegisteredJmx) {
/*  52 */       return;
/*     */     }
/*     */     
/*  55 */     mbean.registerJmx();
/*  56 */     hasRegisteredJmx = true;
/*     */   }
/*     */   
/*     */   public static ReplicationConnectionGroup getConnectionGroup(String groupName) {
/*  60 */     return (ReplicationConnectionGroup)GROUP_MAP.get(groupName);
/*     */   }
/*     */   
/*     */   public static Collection<ReplicationConnectionGroup> getGroupsMatching(String group) {
/*  64 */     if ((group == null) || (group.equals(""))) {
/*  65 */       Set<ReplicationConnectionGroup> s = new HashSet();
/*     */       
/*  67 */       s.addAll(GROUP_MAP.values());
/*  68 */       return s;
/*     */     }
/*  70 */     Set<ReplicationConnectionGroup> s = new HashSet();
/*  71 */     ReplicationConnectionGroup o = (ReplicationConnectionGroup)GROUP_MAP.get(group);
/*  72 */     if (o != null) {
/*  73 */       s.add(o);
/*     */     }
/*  75 */     return s;
/*     */   }
/*     */   
/*     */   public static void addSlaveHost(String group, String host) throws SQLException
/*     */   {
/*  80 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/*  81 */     for (ReplicationConnectionGroup cg : s) {
/*  82 */       cg.addSlaveHost(host);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void removeSlaveHost(String group, String host) throws SQLException {
/*  87 */     removeSlaveHost(group, host, true);
/*     */   }
/*     */   
/*     */   public static void removeSlaveHost(String group, String host, boolean closeGently) throws SQLException {
/*  91 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/*  92 */     for (ReplicationConnectionGroup cg : s) {
/*  93 */       cg.removeSlaveHost(host, closeGently);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void promoteSlaveToMaster(String group, String newMasterHost) throws SQLException {
/*  98 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/*  99 */     for (ReplicationConnectionGroup cg : s) {
/* 100 */       cg.promoteSlaveToMaster(newMasterHost);
/*     */     }
/*     */   }
/*     */   
/*     */   public static long getSlavePromotionCount(String group) throws SQLException
/*     */   {
/* 106 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 107 */     long promoted = 0L;
/* 108 */     for (ReplicationConnectionGroup cg : s) {
/* 109 */       long tmp = cg.getNumberOfSlavePromotions();
/* 110 */       if (tmp > promoted) {
/* 111 */         promoted = tmp;
/*     */       }
/*     */     }
/* 114 */     return promoted;
/*     */   }
/*     */   
/*     */   public static void removeMasterHost(String group, String host) throws SQLException
/*     */   {
/* 119 */     removeMasterHost(group, host, true);
/*     */   }
/*     */   
/*     */   public static void removeMasterHost(String group, String host, boolean closeGently) throws SQLException {
/* 123 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 124 */     for (ReplicationConnectionGroup cg : s) {
/* 125 */       cg.removeMasterHost(host, closeGently);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getRegisteredReplicationConnectionGroups() {
/* 130 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(null);
/* 131 */     StringBuilder sb = new StringBuilder();
/* 132 */     String sep = "";
/* 133 */     for (ReplicationConnectionGroup cg : s) {
/* 134 */       String group = cg.getGroupName();
/* 135 */       sb.append(sep);
/* 136 */       sb.append(group);
/* 137 */       sep = ",";
/*     */     }
/* 139 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static int getNumberOfMasterPromotion(String groupFilter)
/*     */   {
/* 144 */     int total = 0;
/* 145 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 146 */     for (ReplicationConnectionGroup cg : s) {
/* 147 */       total = (int)(total + cg.getNumberOfSlavePromotions());
/*     */     }
/* 149 */     return total;
/*     */   }
/*     */   
/*     */   public static int getConnectionCountWithHostAsSlave(String groupFilter, String host) {
/* 153 */     int total = 0;
/* 154 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 155 */     for (ReplicationConnectionGroup cg : s) {
/* 156 */       total += cg.getConnectionCountWithHostAsSlave(host);
/*     */     }
/* 158 */     return total;
/*     */   }
/*     */   
/*     */   public static int getConnectionCountWithHostAsMaster(String groupFilter, String host) {
/* 162 */     int total = 0;
/* 163 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 164 */     for (ReplicationConnectionGroup cg : s) {
/* 165 */       total += cg.getConnectionCountWithHostAsMaster(host);
/*     */     }
/* 167 */     return total;
/*     */   }
/*     */   
/*     */   public static Collection<String> getSlaveHosts(String groupFilter) {
/* 171 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 172 */     Collection<String> hosts = new ArrayList();
/* 173 */     for (ReplicationConnectionGroup cg : s) {
/* 174 */       hosts.addAll(cg.getSlaveHosts());
/*     */     }
/* 176 */     return hosts;
/*     */   }
/*     */   
/*     */   public static Collection<String> getMasterHosts(String groupFilter) {
/* 180 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 181 */     Collection<String> hosts = new ArrayList();
/* 182 */     for (ReplicationConnectionGroup cg : s) {
/* 183 */       hosts.addAll(cg.getMasterHosts());
/*     */     }
/* 185 */     return hosts;
/*     */   }
/*     */   
/*     */   public static long getTotalConnectionCount(String group) {
/* 189 */     long connections = 0L;
/* 190 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 191 */     for (ReplicationConnectionGroup cg : s) {
/* 192 */       connections += cg.getTotalConnectionCount();
/*     */     }
/* 194 */     return connections;
/*     */   }
/*     */   
/*     */   public static long getActiveConnectionCount(String group) {
/* 198 */     long connections = 0L;
/* 199 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 200 */     for (ReplicationConnectionGroup cg : s) {
/* 201 */       connections += cg.getActiveConnectionCount();
/*     */     }
/* 203 */     return connections;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ReplicationConnectionGroupManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */