/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BestResponseTimeBalanceStrategy
/*     */   implements BalanceStrategy
/*     */ {
/*     */   public void destroy() {}
/*     */   
/*     */   public void init(Connection conn, Properties props)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */   public ConnectionImpl pickConnection(LoadBalancingConnectionProxy proxy, List<String> configuredHosts, Map<String, ConnectionImpl> liveConnections, long[] responseTimes, int numRetries)
/*     */     throws SQLException
/*     */   {
/*  50 */     Map<String, Long> blackList = proxy.getGlobalBlacklist();
/*     */     
/*  52 */     SQLException ex = null;
/*     */     
/*  54 */     int attempts = 0; ConnectionImpl conn; for (;;) { if (attempts >= numRetries) break label240;
/*  55 */       long minResponseTime = Long.MAX_VALUE;
/*     */       
/*  57 */       int bestHostIndex = 0;
/*     */       
/*     */ 
/*  60 */       if (blackList.size() == configuredHosts.size()) {
/*  61 */         blackList = proxy.getGlobalBlacklist();
/*     */       }
/*     */       
/*  64 */       for (int i = 0; i < responseTimes.length; i++) {
/*  65 */         long candidateResponseTime = responseTimes[i];
/*     */         
/*  67 */         if ((candidateResponseTime < minResponseTime) && (!blackList.containsKey(configuredHosts.get(i)))) {
/*  68 */           if (candidateResponseTime == 0L) {
/*  69 */             bestHostIndex = i;
/*     */             
/*  71 */             break;
/*     */           }
/*     */           
/*  74 */           bestHostIndex = i;
/*  75 */           minResponseTime = candidateResponseTime;
/*     */         }
/*     */       }
/*     */       
/*  79 */       String bestHost = (String)configuredHosts.get(bestHostIndex);
/*     */       
/*  81 */       conn = (ConnectionImpl)liveConnections.get(bestHost);
/*     */       
/*  83 */       if (conn == null)
/*     */         try {
/*  85 */           conn = proxy.createConnectionForHost(bestHost);
/*     */         } catch (SQLException sqlEx) {
/*  87 */           ex = sqlEx;
/*     */           
/*  89 */           if (proxy.shouldExceptionTriggerFailover(sqlEx)) {
/*  90 */             proxy.addToGlobalBlacklist(bestHost);
/*  91 */             blackList.put(bestHost, null);
/*     */             
/*  93 */             if (blackList.size() == configuredHosts.size()) {
/*  94 */               attempts++;
/*     */               try {
/*  96 */                 Thread.sleep(250L);
/*     */               }
/*     */               catch (InterruptedException e) {}
/*  99 */               blackList = proxy.getGlobalBlacklist();
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 105 */             throw sqlEx;
/*     */           }
/*     */         }
/*     */     }
/* 109 */     return conn;
/*     */     
/*     */     label240:
/* 112 */     if (ex != null) {
/* 113 */       throw ex;
/*     */     }
/*     */     
/* 116 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/BestResponseTimeBalanceStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */