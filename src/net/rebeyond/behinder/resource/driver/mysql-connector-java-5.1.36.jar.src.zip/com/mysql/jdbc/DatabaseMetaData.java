/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DatabaseMetaData
/*      */   implements java.sql.DatabaseMetaData
/*      */ {
/*      */   protected static final int MAX_IDENTIFIER_LENGTH = 64;
/*      */   private static final int DEFERRABILITY = 13;
/*      */   private static final int DELETE_RULE = 10;
/*      */   private static final int FK_NAME = 11;
/*      */   private static final int FKCOLUMN_NAME = 7;
/*      */   private static final int FKTABLE_CAT = 4;
/*      */   private static final int FKTABLE_NAME = 6;
/*      */   private static final int FKTABLE_SCHEM = 5;
/*      */   private static final int KEY_SEQ = 8;
/*      */   private static final int PK_NAME = 12;
/*      */   private static final int PKCOLUMN_NAME = 3;
/*      */   private static final int PKTABLE_CAT = 0;
/*      */   private static final int PKTABLE_NAME = 2;
/*      */   private static final int PKTABLE_SCHEM = 1;
/*      */   private static final String SUPPORTS_FK = "SUPPORTS_FK";
/*      */   
/*      */   protected abstract class IteratorWithCleanup<T>
/*      */   {
/*      */     protected IteratorWithCleanup() {}
/*      */     
/*      */     abstract void close()
/*      */       throws SQLException;
/*      */     
/*      */     abstract boolean hasNext()
/*      */       throws SQLException;
/*      */     
/*      */     abstract T next()
/*      */       throws SQLException;
/*      */   }
/*      */   
/*      */   class LocalAndReferencedColumns
/*      */   {
/*      */     String constraintName;
/*      */     List<String> localColumnsList;
/*      */     String referencedCatalog;
/*      */     List<String> referencedColumnsList;
/*      */     String referencedTable;
/*      */     
/*      */     LocalAndReferencedColumns(List<String> localColumns, String refColumns, String constName, String refCatalog)
/*      */     {
/*   86 */       this.localColumnsList = localColumns;
/*   87 */       this.referencedColumnsList = refColumns;
/*   88 */       this.constraintName = constName;
/*   89 */       this.referencedTable = refTable;
/*   90 */       this.referencedCatalog = refCatalog;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class ResultSetIterator extends DatabaseMetaData.IteratorWithCleanup<String> {
/*      */     int colIndex;
/*      */     ResultSet resultSet;
/*      */     
/*      */     ResultSetIterator(ResultSet rs, int index) {
/*   99 */       super();
/*  100 */       this.resultSet = rs;
/*  101 */       this.colIndex = index;
/*      */     }
/*      */     
/*      */     void close() throws SQLException
/*      */     {
/*  106 */       this.resultSet.close();
/*      */     }
/*      */     
/*      */     boolean hasNext() throws SQLException
/*      */     {
/*  111 */       return this.resultSet.next();
/*      */     }
/*      */     
/*      */     String next() throws SQLException
/*      */     {
/*  116 */       return this.resultSet.getObject(this.colIndex).toString();
/*      */     }
/*      */   }
/*      */   
/*      */   protected class SingleStringIterator extends DatabaseMetaData.IteratorWithCleanup<String> {
/*  121 */     boolean onFirst = true;
/*      */     String value;
/*      */     
/*      */     SingleStringIterator(String s) {
/*  125 */       super();
/*  126 */       this.value = s;
/*      */     }
/*      */     
/*      */ 
/*      */     void close()
/*      */       throws SQLException
/*      */     {}
/*      */     
/*      */     boolean hasNext()
/*      */       throws SQLException
/*      */     {
/*  137 */       return this.onFirst;
/*      */     }
/*      */     
/*      */     String next() throws SQLException
/*      */     {
/*  142 */       this.onFirst = false;
/*  143 */       return this.value;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   class TypeDescriptor
/*      */   {
/*      */     int bufferLength;
/*      */     
/*      */ 
/*      */     int charOctetLength;
/*      */     
/*      */     Integer columnSize;
/*      */     
/*      */     short dataType;
/*      */     
/*      */     Integer decimalDigits;
/*      */     
/*      */     String isNullable;
/*      */     
/*      */     int nullability;
/*      */     
/*  166 */     int numPrecRadix = 10;
/*      */     String typeName;
/*      */     
/*      */     TypeDescriptor(String typeInfo, String nullabilityInfo) throws SQLException
/*      */     {
/*  171 */       if (typeInfo == null) {
/*  172 */         throw SQLError.createSQLException("NULL typeinfo not supported.", "S1009", DatabaseMetaData.this.getExceptionInterceptor());
/*      */       }
/*      */       
/*  175 */       String mysqlType = "";
/*  176 */       String fullMysqlType = null;
/*      */       
/*  178 */       if (typeInfo.indexOf("(") != -1) {
/*  179 */         mysqlType = typeInfo.substring(0, typeInfo.indexOf("(")).trim();
/*      */       } else {
/*  181 */         mysqlType = typeInfo;
/*      */       }
/*      */       
/*  184 */       int indexOfUnsignedInMysqlType = StringUtils.indexOfIgnoreCase(mysqlType, "unsigned");
/*      */       
/*  186 */       if (indexOfUnsignedInMysqlType != -1) {
/*  187 */         mysqlType = mysqlType.substring(0, indexOfUnsignedInMysqlType - 1);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  192 */       boolean isUnsigned = false;
/*      */       
/*  194 */       if ((StringUtils.indexOfIgnoreCase(typeInfo, "unsigned") != -1) && (StringUtils.indexOfIgnoreCase(typeInfo, "set") != 0) && (StringUtils.indexOfIgnoreCase(typeInfo, "enum") != 0))
/*      */       {
/*  196 */         fullMysqlType = mysqlType + " unsigned";
/*  197 */         isUnsigned = true;
/*      */       } else {
/*  199 */         fullMysqlType = mysqlType;
/*      */       }
/*      */       
/*  202 */       if (DatabaseMetaData.this.conn.getCapitalizeTypeNames()) {
/*  203 */         fullMysqlType = fullMysqlType.toUpperCase(Locale.ENGLISH);
/*      */       }
/*      */       
/*  206 */       this.dataType = ((short)MysqlDefs.mysqlToJavaType(mysqlType));
/*      */       
/*  208 */       this.typeName = fullMysqlType;
/*      */       
/*      */ 
/*      */ 
/*  212 */       if (StringUtils.startsWithIgnoreCase(typeInfo, "enum")) {
/*  213 */         String temp = typeInfo.substring(typeInfo.indexOf("("), typeInfo.lastIndexOf(")"));
/*  214 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*  215 */         int maxLength = 0;
/*      */         
/*  217 */         while (tokenizer.hasMoreTokens()) {
/*  218 */           maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*      */         }
/*      */         
/*  221 */         this.columnSize = Integer.valueOf(maxLength);
/*  222 */         this.decimalDigits = null;
/*  223 */       } else if (StringUtils.startsWithIgnoreCase(typeInfo, "set")) {
/*  224 */         String temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
/*  225 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*  226 */         int maxLength = 0;
/*      */         
/*  228 */         int numElements = tokenizer.countTokens();
/*      */         
/*  230 */         if (numElements > 0) {
/*  231 */           maxLength += numElements - 1;
/*      */         }
/*      */         
/*  234 */         while (tokenizer.hasMoreTokens()) {
/*  235 */           String setMember = tokenizer.nextToken().trim();
/*      */           
/*  237 */           if ((setMember.startsWith("'")) && (setMember.endsWith("'"))) {
/*  238 */             maxLength += setMember.length() - 2;
/*      */           } else {
/*  240 */             maxLength += setMember.length();
/*      */           }
/*      */         }
/*      */         
/*  244 */         this.columnSize = Integer.valueOf(maxLength);
/*  245 */         this.decimalDigits = null;
/*  246 */       } else if (typeInfo.indexOf(",") != -1)
/*      */       {
/*  248 */         this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")).trim());
/*  249 */         this.decimalDigits = Integer.valueOf(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")).trim());
/*      */       } else {
/*  251 */         this.columnSize = null;
/*  252 */         this.decimalDigits = null;
/*      */         
/*      */ 
/*  255 */         if (((StringUtils.indexOfIgnoreCase(typeInfo, "char") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "text") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "blob") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "binary") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "bit") != -1)) && (typeInfo.indexOf("(") != -1))
/*      */         {
/*      */ 
/*  258 */           int endParenIndex = typeInfo.indexOf(")");
/*      */           
/*  260 */           if (endParenIndex == -1) {
/*  261 */             endParenIndex = typeInfo.length();
/*      */           }
/*      */           
/*  264 */           this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, endParenIndex).trim());
/*      */           
/*      */ 
/*  267 */           if ((DatabaseMetaData.this.conn.getTinyInt1isBit()) && (this.columnSize.intValue() == 1) && (StringUtils.startsWithIgnoreCase(typeInfo, 0, "tinyint")))
/*      */           {
/*  269 */             if (DatabaseMetaData.this.conn.getTransformedBitIsBoolean()) {
/*  270 */               this.dataType = 16;
/*  271 */               this.typeName = "BOOLEAN";
/*      */             } else {
/*  273 */               this.dataType = -7;
/*  274 */               this.typeName = "BIT";
/*      */             }
/*      */           }
/*  277 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinyint")) {
/*  278 */           if ((DatabaseMetaData.this.conn.getTinyInt1isBit()) && (typeInfo.indexOf("(1)") != -1)) {
/*  279 */             if (DatabaseMetaData.this.conn.getTransformedBitIsBoolean()) {
/*  280 */               this.dataType = 16;
/*  281 */               this.typeName = "BOOLEAN";
/*      */             } else {
/*  283 */               this.dataType = -7;
/*  284 */               this.typeName = "BIT";
/*      */             }
/*      */           } else {
/*  287 */             this.columnSize = Integer.valueOf(3);
/*  288 */             this.decimalDigits = Integer.valueOf(0);
/*      */           }
/*  290 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "smallint")) {
/*  291 */           this.columnSize = Integer.valueOf(5);
/*  292 */           this.decimalDigits = Integer.valueOf(0);
/*  293 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumint")) {
/*  294 */           this.columnSize = Integer.valueOf(isUnsigned ? 8 : 7);
/*  295 */           this.decimalDigits = Integer.valueOf(0);
/*  296 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "int")) {
/*  297 */           this.columnSize = Integer.valueOf(10);
/*  298 */           this.decimalDigits = Integer.valueOf(0);
/*  299 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "integer")) {
/*  300 */           this.columnSize = Integer.valueOf(10);
/*  301 */           this.decimalDigits = Integer.valueOf(0);
/*  302 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "bigint")) {
/*  303 */           this.columnSize = Integer.valueOf(isUnsigned ? 20 : 19);
/*  304 */           this.decimalDigits = Integer.valueOf(0);
/*  305 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "int24")) {
/*  306 */           this.columnSize = Integer.valueOf(19);
/*  307 */           this.decimalDigits = Integer.valueOf(0);
/*  308 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "real")) {
/*  309 */           this.columnSize = Integer.valueOf(12);
/*  310 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "float")) {
/*  311 */           this.columnSize = Integer.valueOf(12);
/*  312 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "decimal")) {
/*  313 */           this.columnSize = Integer.valueOf(12);
/*  314 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "numeric")) {
/*  315 */           this.columnSize = Integer.valueOf(12);
/*  316 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "double")) {
/*  317 */           this.columnSize = Integer.valueOf(22);
/*  318 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "char")) {
/*  319 */           this.columnSize = Integer.valueOf(1);
/*  320 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "varchar")) {
/*  321 */           this.columnSize = Integer.valueOf(255);
/*  322 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "timestamp")) {
/*  323 */           this.columnSize = Integer.valueOf(19);
/*  324 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "datetime")) {
/*  325 */           this.columnSize = Integer.valueOf(19);
/*  326 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "date")) {
/*  327 */           this.columnSize = Integer.valueOf(10);
/*  328 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "time")) {
/*  329 */           this.columnSize = Integer.valueOf(8);
/*      */         }
/*  331 */         else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinyblob")) {
/*  332 */           this.columnSize = Integer.valueOf(255);
/*  333 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "blob")) {
/*  334 */           this.columnSize = Integer.valueOf(65535);
/*  335 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumblob")) {
/*  336 */           this.columnSize = Integer.valueOf(16777215);
/*  337 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "longblob")) {
/*  338 */           this.columnSize = Integer.valueOf(Integer.MAX_VALUE);
/*  339 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinytext")) {
/*  340 */           this.columnSize = Integer.valueOf(255);
/*  341 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "text")) {
/*  342 */           this.columnSize = Integer.valueOf(65535);
/*  343 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumtext")) {
/*  344 */           this.columnSize = Integer.valueOf(16777215);
/*  345 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "longtext")) {
/*  346 */           this.columnSize = Integer.valueOf(Integer.MAX_VALUE);
/*  347 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "enum")) {
/*  348 */           this.columnSize = Integer.valueOf(255);
/*  349 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "set")) {
/*  350 */           this.columnSize = Integer.valueOf(255);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  356 */       this.bufferLength = MysqlIO.getMaxBuf();
/*      */       
/*      */ 
/*  359 */       this.numPrecRadix = 10;
/*      */       
/*      */ 
/*  362 */       if (nullabilityInfo != null) {
/*  363 */         if (nullabilityInfo.equals("YES")) {
/*  364 */           this.nullability = 1;
/*  365 */           this.isNullable = "YES";
/*      */         }
/*  367 */         else if (nullabilityInfo.equals("UNKNOWN")) {
/*  368 */           this.nullability = 2;
/*  369 */           this.isNullable = "";
/*      */         }
/*      */         else
/*      */         {
/*  373 */           this.nullability = 0;
/*  374 */           this.isNullable = "NO";
/*      */         }
/*      */       } else {
/*  377 */         this.nullability = 0;
/*  378 */         this.isNullable = "NO";
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected class IndexMetaDataKey
/*      */     implements Comparable<IndexMetaDataKey>
/*      */   {
/*      */     Boolean columnNonUnique;
/*      */     Short columnType;
/*      */     String columnIndexName;
/*      */     Short columnOrdinalPosition;
/*      */     
/*      */     IndexMetaDataKey(boolean columnNonUnique, short columnType, String columnIndexName, short columnOrdinalPosition)
/*      */     {
/*  393 */       this.columnNonUnique = Boolean.valueOf(columnNonUnique);
/*  394 */       this.columnType = Short.valueOf(columnType);
/*  395 */       this.columnIndexName = columnIndexName;
/*  396 */       this.columnOrdinalPosition = Short.valueOf(columnOrdinalPosition);
/*      */     }
/*      */     
/*      */     public int compareTo(IndexMetaDataKey indexInfoKey)
/*      */     {
/*      */       int compareResult;
/*  402 */       if ((compareResult = this.columnNonUnique.compareTo(indexInfoKey.columnNonUnique)) != 0) {
/*  403 */         return compareResult;
/*      */       }
/*  405 */       if ((compareResult = this.columnType.compareTo(indexInfoKey.columnType)) != 0) {
/*  406 */         return compareResult;
/*      */       }
/*  408 */       if ((compareResult = this.columnIndexName.compareTo(indexInfoKey.columnIndexName)) != 0) {
/*  409 */         return compareResult;
/*      */       }
/*  411 */       return this.columnOrdinalPosition.compareTo(indexInfoKey.columnOrdinalPosition);
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj)
/*      */     {
/*  416 */       if (obj == null) {
/*  417 */         return false;
/*      */       }
/*      */       
/*  420 */       if (obj == this) {
/*  421 */         return true;
/*      */       }
/*      */       
/*  424 */       if (!(obj instanceof IndexMetaDataKey)) {
/*  425 */         return false;
/*      */       }
/*  427 */       return compareTo((IndexMetaDataKey)obj) == 0;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class TableMetaDataKey
/*      */     implements Comparable<TableMetaDataKey>
/*      */   {
/*      */     String tableType;
/*      */     String tableCat;
/*      */     String tableSchem;
/*      */     String tableName;
/*      */     
/*      */     TableMetaDataKey(String tableType, String tableCat, String tableSchem, String tableName)
/*      */     {
/*  441 */       this.tableType = (tableType == null ? "" : tableType);
/*  442 */       this.tableCat = (tableCat == null ? "" : tableCat);
/*  443 */       this.tableSchem = (tableSchem == null ? "" : tableSchem);
/*  444 */       this.tableName = (tableName == null ? "" : tableName);
/*      */     }
/*      */     
/*      */     public int compareTo(TableMetaDataKey tablesKey)
/*      */     {
/*      */       int compareResult;
/*  450 */       if ((compareResult = this.tableType.compareTo(tablesKey.tableType)) != 0) {
/*  451 */         return compareResult;
/*      */       }
/*  453 */       if ((compareResult = this.tableCat.compareTo(tablesKey.tableCat)) != 0) {
/*  454 */         return compareResult;
/*      */       }
/*  456 */       if ((compareResult = this.tableSchem.compareTo(tablesKey.tableSchem)) != 0) {
/*  457 */         return compareResult;
/*      */       }
/*  459 */       return this.tableName.compareTo(tablesKey.tableName);
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj)
/*      */     {
/*  464 */       if (obj == null) {
/*  465 */         return false;
/*      */       }
/*      */       
/*  468 */       if (obj == this) {
/*  469 */         return true;
/*      */       }
/*      */       
/*  472 */       if (!(obj instanceof TableMetaDataKey)) {
/*  473 */         return false;
/*      */       }
/*  475 */       return compareTo((TableMetaDataKey)obj) == 0;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class ComparableWrapper<K,  extends Comparable<? super K>, V>
/*      */     implements Comparable<ComparableWrapper<K, V>>
/*      */   {
/*      */     K key;
/*      */     V value;
/*      */     
/*      */     public ComparableWrapper(V key)
/*      */     {
/*  487 */       this.key = key;
/*  488 */       this.value = value;
/*      */     }
/*      */     
/*      */     public K getKey() {
/*  492 */       return (K)this.key;
/*      */     }
/*      */     
/*      */     public V getValue() {
/*  496 */       return (V)this.value;
/*      */     }
/*      */     
/*      */     public int compareTo(ComparableWrapper<K, V> other) {
/*  500 */       return ((Comparable)getKey()).compareTo(other.getKey());
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj)
/*      */     {
/*  505 */       if (obj == null) {
/*  506 */         return false;
/*      */       }
/*      */       
/*  509 */       if (obj == this) {
/*  510 */         return true;
/*      */       }
/*      */       
/*  513 */       if (!(obj instanceof ComparableWrapper)) {
/*  514 */         return false;
/*      */       }
/*      */       
/*  517 */       Object otherKey = ((ComparableWrapper)obj).getKey();
/*  518 */       return this.key.equals(otherKey);
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  523 */       return "{KEY:" + this.key + "; VALUE:" + this.value + "}";
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static enum TableType
/*      */   {
/*  531 */     LOCAL_TEMPORARY("LOCAL TEMPORARY"),  SYSTEM_TABLE("SYSTEM TABLE"),  SYSTEM_VIEW("SYSTEM VIEW"),  TABLE("TABLE", new String[] { "BASE TABLE" }),  VIEW("VIEW"), 
/*  532 */     UNKNOWN("UNKNOWN");
/*      */     
/*      */     private String name;
/*      */     private byte[] nameAsBytes;
/*      */     private String[] synonyms;
/*      */     
/*      */     private TableType(String tableTypeName) {
/*  539 */       this(tableTypeName, null);
/*      */     }
/*      */     
/*      */     private TableType(String tableTypeName, String[] tableTypeSynonyms) {
/*  543 */       this.name = tableTypeName;
/*  544 */       this.nameAsBytes = tableTypeName.getBytes();
/*  545 */       this.synonyms = tableTypeSynonyms;
/*      */     }
/*      */     
/*      */     String getName() {
/*  549 */       return this.name;
/*      */     }
/*      */     
/*      */     byte[] asBytes() {
/*  553 */       return this.nameAsBytes;
/*      */     }
/*      */     
/*      */     boolean equalsTo(String tableTypeName) {
/*  557 */       return this.name.equalsIgnoreCase(tableTypeName);
/*      */     }
/*      */     
/*      */     static TableType getTableTypeEqualTo(String tableTypeName) {
/*  561 */       for (TableType tableType : ) {
/*  562 */         if (tableType.equalsTo(tableTypeName)) {
/*  563 */           return tableType;
/*      */         }
/*      */       }
/*  566 */       return UNKNOWN;
/*      */     }
/*      */     
/*      */     boolean compliesWith(String tableTypeName) {
/*  570 */       if (equalsTo(tableTypeName)) {
/*  571 */         return true;
/*      */       }
/*  573 */       if (this.synonyms != null) {
/*  574 */         for (String synonym : this.synonyms) {
/*  575 */           if (synonym.equalsIgnoreCase(tableTypeName)) {
/*  576 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*  580 */       return false;
/*      */     }
/*      */     
/*      */     static TableType getTableTypeCompliantWith(String tableTypeName) {
/*  584 */       for (TableType tableType : ) {
/*  585 */         if (tableType.compliesWith(tableTypeName)) {
/*  586 */           return tableType;
/*      */         }
/*      */       }
/*  589 */       return UNKNOWN;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static enum ProcedureType
/*      */   {
/*  597 */     PROCEDURE,  FUNCTION;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private ProcedureType() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  634 */   protected static final byte[] TABLE_AS_BYTES = "TABLE".getBytes();
/*      */   
/*  636 */   protected static final byte[] SYSTEM_TABLE_AS_BYTES = "SYSTEM TABLE".getBytes();
/*      */   
/*      */   private static final int UPDATE_RULE = 9;
/*      */   
/*  640 */   protected static final byte[] VIEW_AS_BYTES = "VIEW".getBytes();
/*      */   
/*      */   private static final Constructor<?> JDBC_4_DBMD_SHOW_CTOR;
/*      */   private static final Constructor<?> JDBC_4_DBMD_IS_CTOR;
/*      */   
/*      */   static
/*      */   {
/*  647 */     if (Util.isJdbc4()) {
/*      */       try {
/*  649 */         JDBC_4_DBMD_SHOW_CTOR = Class.forName("com.mysql.jdbc.JDBC4DatabaseMetaData").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */         
/*  651 */         JDBC_4_DBMD_IS_CTOR = Class.forName("com.mysql.jdbc.JDBC4DatabaseMetaDataUsingInfoSchema").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */       }
/*      */       catch (SecurityException e) {
/*  654 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  656 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  658 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  661 */       JDBC_4_DBMD_IS_CTOR = null;
/*  662 */       JDBC_4_DBMD_SHOW_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  667 */   private static final String[] MYSQL_KEYWORDS = { "ACCESSIBLE", "ADD", "ALL", "ALTER", "ANALYZE", "AND", "AS", "ASC", "ASENSITIVE", "BEFORE", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOTH", "BY", "CALL", "CASCADE", "CASE", "CHANGE", "CHAR", "CHARACTER", "CHECK", "COLLATE", "COLUMN", "CONDITION", "CONSTRAINT", "CONTINUE", "CONVERT", "CREATE", "CROSS", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "DATABASE", "DATABASES", "DAY_HOUR", "DAY_MICROSECOND", "DAY_MINUTE", "DAY_SECOND", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELAYED", "DELETE", "DESC", "DESCRIBE", "DETERMINISTIC", "DISTINCT", "DISTINCTROW", "DIV", "DOUBLE", "DROP", "DUAL", "EACH", "ELSE", "ELSEIF", "ENCLOSED", "ESCAPED", "EXISTS", "EXIT", "EXPLAIN", "FALSE", "FETCH", "FLOAT", "FLOAT4", "FLOAT8", "FOR", "FORCE", "FOREIGN", "FROM", "FULLTEXT", "GENERATED", "GET", "GRANT", "GROUP", "HAVING", "HIGH_PRIORITY", "HOUR_MICROSECOND", "HOUR_MINUTE", "HOUR_SECOND", "IF", "IGNORE", "IN", "INDEX", "INFILE", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INT1", "INT2", "INT3", "INT4", "INT8", "INTEGER", "INTERVAL", "INTO", "IO_AFTER_GTIDS", "IO_BEFORE_GTIDS", "IS", "ITERATE", "JOIN", "KEY", "KEYS", "KILL", "LEADING", "LEAVE", "LEFT", "LIKE", "LIMIT", "LINEAR", "LINES", "LOAD", "LOCALTIME", "LOCALTIMESTAMP", "LOCK", "LONG", "LONGBLOB", "LONGTEXT", "LOOP", "LOW_PRIORITY", "MASTER_BIND", "MASTER_SSL_VERIFY_SERVER_CERT", "MATCH", "MAXVALUE", "MEDIUMBLOB", "MEDIUMINT", "MEDIUMTEXT", "MIDDLEINT", "MINUTE_MICROSECOND", "MINUTE_SECOND", "MOD", "MODIFIES", "NATURAL", "NOT", "NO_WRITE_TO_BINLOG", "NULL", "NUMERIC", "ON", "OPTIMIZE", "OPTIMIZER_COSTS", "OPTION", "OPTIONALLY", "OR", "ORDER", "OUT", "OUTER", "OUTFILE", "PARSE_GCOL_EXPR", "PARTITION", "PRECISION", "PRIMARY", "PROCEDURE", "PURGE", "RANGE", "READ", "READS", "READ_WRITE", "REAL", "REFERENCES", "REGEXP", "RELEASE", "RENAME", "REPEAT", "REPLACE", "REQUIRE", "RESIGNAL", "RESTRICT", "RETURN", "REVOKE", "RIGHT", "RLIKE", "SCHEMA", "SCHEMAS", "SECOND_MICROSECOND", "SELECT", "SENSITIVE", "SEPARATOR", "SET", "SHOW", "SIGNAL", "SMALLINT", "SPATIAL", "SPECIFIC", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQL_BIG_RESULT", "SQL_CALC_FOUND_ROWS", "SQL_SMALL_RESULT", "SSL", "STARTING", "STORED", "STRAIGHT_JOIN", "TABLE", "TERMINATED", "THEN", "TINYBLOB", "TINYINT", "TINYTEXT", "TO", "TRAILING", "TRIGGER", "TRUE", "UNDO", "UNION", "UNIQUE", "UNLOCK", "UNSIGNED", "UPDATE", "USAGE", "USE", "USING", "UTC_DATE", "UTC_TIME", "UTC_TIMESTAMP", "VALUES", "VARBINARY", "VARCHAR", "VARCHARACTER", "VARYING", "VIRTUAL", "WHEN", "WHERE", "WHILE", "WITH", "WRITE", "XOR", "YEAR_MONTH", "ZEROFILL" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  688 */   private static final String[] SQL92_KEYWORDS = { "ABSOLUTE", "ACTION", "ADD", "ALL", "ALLOCATE", "ALTER", "AND", "ANY", "ARE", "AS", "ASC", "ASSERTION", "AT", "AUTHORIZATION", "AVG", "BEGIN", "BETWEEN", "BIT", "BIT_LENGTH", "BOTH", "BY", "CASCADE", "CASCADED", "CASE", "CAST", "CATALOG", "CHAR", "CHARACTER", "CHARACTER_LENGTH", "CHAR_LENGTH", "CHECK", "CLOSE", "COALESCE", "COLLATE", "COLLATION", "COLUMN", "COMMIT", "CONNECT", "CONNECTION", "CONSTRAINT", "CONSTRAINTS", "CONTINUE", "CONVERT", "CORRESPONDING", "COUNT", "CREATE", "CROSS", "CURRENT", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "DATE", "DAY", "DEALLOCATE", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DEFERRABLE", "DEFERRED", "DELETE", "DESC", "DESCRIBE", "DESCRIPTOR", "DIAGNOSTICS", "DISCONNECT", "DISTINCT", "DOMAIN", "DOUBLE", "DROP", "ELSE", "END", "END-EXEC", "ESCAPE", "EXCEPT", "EXCEPTION", "EXEC", "EXECUTE", "EXISTS", "EXTERNAL", "EXTRACT", "FALSE", "FETCH", "FIRST", "FLOAT", "FOR", "FOREIGN", "FOUND", "FROM", "FULL", "GET", "GLOBAL", "GO", "GOTO", "GRANT", "GROUP", "HAVING", "HOUR", "IDENTITY", "IMMEDIATE", "IN", "INDICATOR", "INITIALLY", "INNER", "INPUT", "INSENSITIVE", "INSERT", "INT", "INTEGER", "INTERSECT", "INTERVAL", "INTO", "IS", "ISOLATION", "JOIN", "KEY", "LANGUAGE", "LAST", "LEADING", "LEFT", "LEVEL", "LIKE", "LOCAL", "LOWER", "MATCH", "MAX", "MIN", "MINUTE", "MODULE", "MONTH", "NAMES", "NATIONAL", "NATURAL", "NCHAR", "NEXT", "NO", "NOT", "NULL", "NULLIF", "NUMERIC", "OCTET_LENGTH", "OF", "ON", "ONLY", "OPEN", "OPTION", "OR", "ORDER", "OUTER", "OUTPUT", "OVERLAPS", "PAD", "PARTIAL", "POSITION", "PRECISION", "PREPARE", "PRESERVE", "PRIMARY", "PRIOR", "PRIVILEGES", "PROCEDURE", "PUBLIC", "READ", "REAL", "REFERENCES", "RELATIVE", "RESTRICT", "REVOKE", "RIGHT", "ROLLBACK", "ROWS", "SCHEMA", "SCROLL", "SECOND", "SECTION", "SELECT", "SESSION", "SESSION_USER", "SET", "SIZE", "SMALLINT", "SOME", "SPACE", "SQL", "SQLCODE", "SQLERROR", "SQLSTATE", "SUBSTRING", "SUM", "SYSTEM_USER", "TABLE", "TEMPORARY", "THEN", "TIME", "TIMESTAMP", "TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", "TRANSACTION", "TRANSLATE", "TRANSLATION", "TRIM", "TRUE", "UNION", "UNIQUE", "UNKNOWN", "UPDATE", "UPPER", "USAGE", "USER", "USING", "VALUE", "VALUES", "VARCHAR", "VARYING", "VIEW", "WHEN", "WHENEVER", "WHERE", "WITH", "WORK", "WRITE", "YEAR", "ZONE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  707 */   private static final String[] SQL2003_KEYWORDS = { "ABS", "ALL", "ALLOCATE", "ALTER", "AND", "ANY", "ARE", "ARRAY", "AS", "ASENSITIVE", "ASYMMETRIC", "AT", "ATOMIC", "AUTHORIZATION", "AVG", "BEGIN", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOOLEAN", "BOTH", "BY", "CALL", "CALLED", "CARDINALITY", "CASCADED", "CASE", "CAST", "CEIL", "CEILING", "CHAR", "CHARACTER", "CHARACTER_LENGTH", "CHAR_LENGTH", "CHECK", "CLOB", "CLOSE", "COALESCE", "COLLATE", "COLLECT", "COLUMN", "COMMIT", "CONDITION", "CONNECT", "CONSTRAINT", "CONVERT", "CORR", "CORRESPONDING", "COUNT", "COVAR_POP", "COVAR_SAMP", "CREATE", "CROSS", "CUBE", "CUME_DIST", "CURRENT", "CURRENT_DATE", "CURRENT_DEFAULT_TRANSFORM_GROUP", "CURRENT_PATH", "CURRENT_ROLE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_TRANSFORM_GROUP_FOR_TYPE", "CURRENT_USER", "CURSOR", "CYCLE", "DATE", "DAY", "DEALLOCATE", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELETE", "DENSE_RANK", "DEREF", "DESCRIBE", "DETERMINISTIC", "DISCONNECT", "DISTINCT", "DOUBLE", "DROP", "DYNAMIC", "EACH", "ELEMENT", "ELSE", "END", "END-EXEC", "ESCAPE", "EVERY", "EXCEPT", "EXEC", "EXECUTE", "EXISTS", "EXP", "EXTERNAL", "EXTRACT", "FALSE", "FETCH", "FILTER", "FLOAT", "FLOOR", "FOR", "FOREIGN", "FREE", "FROM", "FULL", "FUNCTION", "FUSION", "GET", "GLOBAL", "GRANT", "GROUP", "GROUPING", "HAVING", "HOLD", "HOUR", "IDENTITY", "IN", "INDICATOR", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INTEGER", "INTERSECT", "INTERSECTION", "INTERVAL", "INTO", "IS", "JOIN", "LANGUAGE", "LARGE", "LATERAL", "LEADING", "LEFT", "LIKE", "LN", "LOCAL", "LOCALTIME", "LOCALTIMESTAMP", "LOWER", "MATCH", "MAX", "MEMBER", "MERGE", "METHOD", "MIN", "MINUTE", "MOD", "MODIFIES", "MODULE", "MONTH", "MULTISET", "NATIONAL", "NATURAL", "NCHAR", "NCLOB", "NEW", "NO", "NONE", "NORMALIZE", "NOT", "NULL", "NULLIF", "NUMERIC", "OCTET_LENGTH", "OF", "OLD", "ON", "ONLY", "OPEN", "OR", "ORDER", "OUT", "OUTER", "OVER", "OVERLAPS", "OVERLAY", "PARAMETER", "PARTITION", "PERCENTILE_CONT", "PERCENTILE_DISC", "PERCENT_RANK", "POSITION", "POWER", "PRECISION", "PREPARE", "PRIMARY", "PROCEDURE", "RANGE", "RANK", "READS", "REAL", "RECURSIVE", "REF", "REFERENCES", "REFERENCING", "REGR_AVGX", "REGR_AVGY", "REGR_COUNT", "REGR_INTERCEPT", "REGR_R2", "REGR_SLOPE", "REGR_SXX", "REGR_SXY", "REGR_SYY", "RELEASE", "RESULT", "RETURN", "RETURNS", "REVOKE", "RIGHT", "ROLLBACK", "ROLLUP", "ROW", "ROWS", "ROW_NUMBER", "SAVEPOINT", "SCOPE", "SCROLL", "SEARCH", "SECOND", "SELECT", "SENSITIVE", "SESSION_USER", "SET", "SIMILAR", "SMALLINT", "SOME", "SPECIFIC", "SPECIFICTYPE", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQRT", "START", "STATIC", "STDDEV_POP", "STDDEV_SAMP", "SUBMULTISET", "SUBSTRING", "SUM", "SYMMETRIC", "SYSTEM", "SYSTEM_USER", "TABLE", "TABLESAMPLE", "THEN", "TIME", "TIMESTAMP", "TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", "TRANSLATE", "TRANSLATION", "TREAT", "TRIGGER", "TRIM", "TRUE", "UESCAPE", "UNION", "UNIQUE", "UNKNOWN", "UNNEST", "UPDATE", "UPPER", "USER", "USING", "VALUE", "VALUES", "VARCHAR", "VARYING", "VAR_POP", "VAR_SAMP", "WHEN", "WHENEVER", "WHERE", "WIDTH_BUCKET", "WINDOW", "WITH", "WITHIN", "WITHOUT", "YEAR" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  731 */   private static volatile String mysqlKeywords = null;
/*      */   
/*      */ 
/*      */   protected MySQLConnection conn;
/*      */   
/*      */ 
/*  737 */   protected String database = null;
/*      */   
/*      */   protected final String quotedId;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   
/*      */   protected static DatabaseMetaData getInstance(MySQLConnection connToSet, String databaseToSet, boolean checkForInfoSchema)
/*      */     throws SQLException
/*      */   {
/*  745 */     if (!Util.isJdbc4()) {
/*  746 */       if ((checkForInfoSchema) && (connToSet != null) && (connToSet.getUseInformationSchema()) && (connToSet.versionMeetsMinimum(5, 0, 7))) {
/*  747 */         return new DatabaseMetaDataUsingInfoSchema(connToSet, databaseToSet);
/*      */       }
/*      */       
/*  750 */       return new DatabaseMetaData(connToSet, databaseToSet);
/*      */     }
/*      */     
/*  753 */     if ((checkForInfoSchema) && (connToSet != null) && (connToSet.getUseInformationSchema()) && (connToSet.versionMeetsMinimum(5, 0, 7)))
/*      */     {
/*  755 */       return (DatabaseMetaData)Util.handleNewInstance(JDBC_4_DBMD_IS_CTOR, new Object[] { connToSet, databaseToSet }, connToSet.getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*  759 */     return (DatabaseMetaData)Util.handleNewInstance(JDBC_4_DBMD_SHOW_CTOR, new Object[] { connToSet, databaseToSet }, connToSet.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DatabaseMetaData(MySQLConnection connToSet, String databaseToSet)
/*      */   {
/*  769 */     this.conn = connToSet;
/*  770 */     this.database = databaseToSet;
/*  771 */     this.exceptionInterceptor = this.conn.getExceptionInterceptor();
/*      */     
/*  773 */     String identifierQuote = null;
/*      */     try {
/*  775 */       identifierQuote = getIdentifierQuoteString();
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  778 */       AssertionFailedException.shouldNotHappen(sqlEx);
/*      */     } finally {
/*  780 */       this.quotedId = identifierQuote;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean allProceduresAreCallable()
/*      */     throws SQLException
/*      */   {
/*  792 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean allTablesAreSelectable()
/*      */     throws SQLException
/*      */   {
/*  802 */     return false;
/*      */   }
/*      */   
/*      */   private ResultSet buildResultSet(Field[] fields, ArrayList<ResultSetRow> rows) throws SQLException {
/*  806 */     return buildResultSet(fields, rows, this.conn);
/*      */   }
/*      */   
/*      */   static ResultSet buildResultSet(Field[] fields, ArrayList<ResultSetRow> rows, MySQLConnection c) throws SQLException {
/*  810 */     int fieldsLength = fields.length;
/*      */     
/*  812 */     for (int i = 0; i < fieldsLength; i++) {
/*  813 */       int jdbcType = fields[i].getSQLType();
/*      */       
/*  815 */       switch (jdbcType) {
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/*  819 */         fields[i].setEncoding(c.getCharacterSetMetadata(), c);
/*  820 */         break;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  825 */       fields[i].setConnection(c);
/*  826 */       fields[i].setUseOldNameMetadata(true);
/*      */     }
/*      */     
/*  829 */     return ResultSetImpl.getInstance(c.getCatalog(), fields, new RowDataStatic(rows), c, null, false);
/*      */   }
/*      */   
/*      */   protected void convertToJdbcFunctionList(String catalog, ResultSet proceduresRs, boolean needsClientFiltering, String db, List<ComparableWrapper<String, ResultSetRow>> procedureRows, int nameIndex, Field[] fields) throws SQLException
/*      */   {
/*  834 */     while (proceduresRs.next()) {
/*  835 */       boolean shouldAdd = true;
/*      */       
/*  837 */       if (needsClientFiltering) {
/*  838 */         shouldAdd = false;
/*      */         
/*  840 */         String procDb = proceduresRs.getString(1);
/*      */         
/*  842 */         if ((db == null) && (procDb == null)) {
/*  843 */           shouldAdd = true;
/*  844 */         } else if ((db != null) && (db.equals(procDb))) {
/*  845 */           shouldAdd = true;
/*      */         }
/*      */       }
/*      */       
/*  849 */       if (shouldAdd) {
/*  850 */         String functionName = proceduresRs.getString(nameIndex);
/*      */         
/*  852 */         byte[][] rowData = (byte[][])null;
/*      */         
/*  854 */         if ((fields != null) && (fields.length == 9))
/*      */         {
/*  856 */           rowData = new byte[9][];
/*  857 */           rowData[0] = (catalog == null ? null : s2b(catalog));
/*  858 */           rowData[1] = null;
/*  859 */           rowData[2] = s2b(functionName);
/*  860 */           rowData[3] = null;
/*  861 */           rowData[4] = null;
/*  862 */           rowData[5] = null;
/*  863 */           rowData[6] = s2b(proceduresRs.getString("comment"));
/*  864 */           rowData[7] = s2b(Integer.toString(2));
/*  865 */           rowData[8] = s2b(functionName);
/*      */         }
/*      */         else {
/*  868 */           rowData = new byte[6][];
/*      */           
/*  870 */           rowData[0] = (catalog == null ? null : s2b(catalog));
/*  871 */           rowData[1] = null;
/*  872 */           rowData[2] = s2b(functionName);
/*  873 */           rowData[3] = s2b(proceduresRs.getString("comment"));
/*  874 */           rowData[4] = s2b(Integer.toString(getJDBC4FunctionNoTableConstant()));
/*  875 */           rowData[5] = s2b(functionName);
/*      */         }
/*      */         
/*  878 */         procedureRows.add(new ComparableWrapper(getFullyQualifiedName(catalog, functionName), new ByteArrayRow(rowData, getExceptionInterceptor())));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getFullyQualifiedName(String catalog, String entity)
/*      */   {
/*  888 */     StringBuilder fullyQualifiedName = new StringBuilder(StringUtils.quoteIdentifier(catalog == null ? "" : catalog, this.quotedId, this.conn.getPedantic()));
/*      */     
/*  890 */     fullyQualifiedName.append('.');
/*  891 */     fullyQualifiedName.append(StringUtils.quoteIdentifier(entity, this.quotedId, this.conn.getPedantic()));
/*  892 */     return fullyQualifiedName.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getJDBC4FunctionNoTableConstant()
/*      */   {
/*  902 */     return 0;
/*      */   }
/*      */   
/*      */   protected void convertToJdbcProcedureList(boolean fromSelect, String catalog, ResultSet proceduresRs, boolean needsClientFiltering, String db, List<ComparableWrapper<String, ResultSetRow>> procedureRows, int nameIndex) throws SQLException
/*      */   {
/*  907 */     while (proceduresRs.next()) {
/*  908 */       boolean shouldAdd = true;
/*      */       
/*  910 */       if (needsClientFiltering) {
/*  911 */         shouldAdd = false;
/*      */         
/*  913 */         String procDb = proceduresRs.getString(1);
/*      */         
/*  915 */         if ((db == null) && (procDb == null)) {
/*  916 */           shouldAdd = true;
/*  917 */         } else if ((db != null) && (db.equals(procDb))) {
/*  918 */           shouldAdd = true;
/*      */         }
/*      */       }
/*      */       
/*  922 */       if (shouldAdd) {
/*  923 */         String procedureName = proceduresRs.getString(nameIndex);
/*  924 */         byte[][] rowData = new byte[9][];
/*  925 */         rowData[0] = (catalog == null ? null : s2b(catalog));
/*  926 */         rowData[1] = null;
/*  927 */         rowData[2] = s2b(procedureName);
/*  928 */         rowData[3] = null;
/*  929 */         rowData[4] = null;
/*  930 */         rowData[5] = null;
/*  931 */         rowData[6] = s2b(proceduresRs.getString("comment"));
/*      */         
/*  933 */         boolean isFunction = fromSelect ? "FUNCTION".equalsIgnoreCase(proceduresRs.getString("type")) : false;
/*  934 */         rowData[7] = s2b(isFunction ? Integer.toString(2) : Integer.toString(1));
/*      */         
/*  936 */         rowData[8] = s2b(procedureName);
/*      */         
/*  938 */         procedureRows.add(new ComparableWrapper(getFullyQualifiedName(catalog, procedureName), new ByteArrayRow(rowData, getExceptionInterceptor())));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private ResultSetRow convertTypeDescriptorToProcedureRow(byte[] procNameAsBytes, byte[] procCatAsBytes, String paramName, boolean isOutParam, boolean isInParam, boolean isReturnParam, TypeDescriptor typeDesc, boolean forGetFunctionColumns, int ordinal)
/*      */     throws SQLException
/*      */   {
/*  946 */     byte[][] row = forGetFunctionColumns ? new byte[17][] : new byte[20][];
/*  947 */     row[0] = procCatAsBytes;
/*  948 */     row[1] = null;
/*  949 */     row[2] = procNameAsBytes;
/*  950 */     row[3] = s2b(paramName);
/*  951 */     row[4] = s2b(String.valueOf(getColumnType(isOutParam, isInParam, isReturnParam, forGetFunctionColumns)));
/*  952 */     row[5] = s2b(Short.toString(typeDesc.dataType));
/*  953 */     row[6] = s2b(typeDesc.typeName);
/*  954 */     row[7] = (typeDesc.columnSize == null ? null : s2b(typeDesc.columnSize.toString()));
/*  955 */     row[8] = row[7];
/*  956 */     row[9] = (typeDesc.decimalDigits == null ? null : s2b(typeDesc.decimalDigits.toString()));
/*  957 */     row[10] = s2b(Integer.toString(typeDesc.numPrecRadix));
/*      */     
/*  959 */     switch (typeDesc.nullability) {
/*      */     case 0: 
/*  961 */       row[11] = s2b(String.valueOf(0));
/*  962 */       break;
/*      */     
/*      */     case 1: 
/*  965 */       row[11] = s2b(String.valueOf(1));
/*  966 */       break;
/*      */     
/*      */     case 2: 
/*  969 */       row[11] = s2b(String.valueOf(2));
/*  970 */       break;
/*      */     
/*      */     default: 
/*  973 */       throw SQLError.createSQLException("Internal error while parsing callable statement metadata (unknown nullability value fount)", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */     
/*  977 */     row[12] = null;
/*      */     
/*  979 */     if (forGetFunctionColumns)
/*      */     {
/*  981 */       row[13] = null;
/*      */       
/*      */ 
/*  984 */       row[14] = s2b(String.valueOf(ordinal));
/*      */       
/*      */ 
/*  987 */       row[15] = s2b(typeDesc.isNullable);
/*      */       
/*      */ 
/*  990 */       row[16] = procNameAsBytes;
/*      */     }
/*      */     else {
/*  993 */       row[13] = null;
/*      */       
/*      */ 
/*  996 */       row[14] = null;
/*      */       
/*      */ 
/*  999 */       row[15] = null;
/*      */       
/*      */ 
/* 1002 */       row[16] = null;
/*      */       
/*      */ 
/* 1005 */       row[17] = s2b(String.valueOf(ordinal));
/*      */       
/*      */ 
/* 1008 */       row[18] = s2b(typeDesc.isNullable);
/*      */       
/*      */ 
/* 1011 */       row[19] = procNameAsBytes;
/*      */     }
/*      */     
/* 1014 */     return new ByteArrayRow(row, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getColumnType(boolean isOutParam, boolean isInParam, boolean isReturnParam, boolean forGetFunctionColumns)
/*      */   {
/* 1033 */     if ((isInParam) && (isOutParam))
/* 1034 */       return 2;
/* 1035 */     if (isInParam)
/* 1036 */       return 1;
/* 1037 */     if (isOutParam)
/* 1038 */       return 4;
/* 1039 */     if (isReturnParam) {
/* 1040 */       return 5;
/*      */     }
/* 1042 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected ExceptionInterceptor getExceptionInterceptor()
/*      */   {
/* 1049 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean dataDefinitionCausesTransactionCommit()
/*      */     throws SQLException
/*      */   {
/* 1060 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean dataDefinitionIgnoredInTransactions()
/*      */     throws SQLException
/*      */   {
/* 1070 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean deletesAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/* 1085 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean doesMaxRowSizeIncludeBlobs()
/*      */     throws SQLException
/*      */   {
/* 1097 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<ResultSetRow> extractForeignKeyForTable(ArrayList<ResultSetRow> rows, ResultSet rs, String catalog)
/*      */     throws SQLException
/*      */   {
/* 1114 */     byte[][] row = new byte[3][];
/* 1115 */     row[0] = rs.getBytes(1);
/* 1116 */     row[1] = s2b("SUPPORTS_FK");
/*      */     
/* 1118 */     String createTableString = rs.getString(2);
/* 1119 */     StringTokenizer lineTokenizer = new StringTokenizer(createTableString, "\n");
/* 1120 */     StringBuilder commentBuf = new StringBuilder("comment; ");
/* 1121 */     boolean firstTime = true;
/*      */     
/* 1123 */     while (lineTokenizer.hasMoreTokens()) {
/* 1124 */       String line = lineTokenizer.nextToken().trim();
/*      */       
/* 1126 */       String constraintName = null;
/*      */       
/* 1128 */       if (StringUtils.startsWithIgnoreCase(line, "CONSTRAINT")) {
/* 1129 */         boolean usingBackTicks = true;
/* 1130 */         int beginPos = StringUtils.indexOfQuoteDoubleAware(line, this.quotedId, 0);
/*      */         
/* 1132 */         if (beginPos == -1) {
/* 1133 */           beginPos = line.indexOf("\"");
/* 1134 */           usingBackTicks = false;
/*      */         }
/*      */         
/* 1137 */         if (beginPos != -1) {
/* 1138 */           int endPos = -1;
/*      */           
/* 1140 */           if (usingBackTicks) {
/* 1141 */             endPos = StringUtils.indexOfQuoteDoubleAware(line, this.quotedId, beginPos + 1);
/*      */           } else {
/* 1143 */             endPos = StringUtils.indexOfQuoteDoubleAware(line, "\"", beginPos + 1);
/*      */           }
/*      */           
/* 1146 */           if (endPos != -1) {
/* 1147 */             constraintName = line.substring(beginPos + 1, endPos);
/* 1148 */             line = line.substring(endPos + 1, line.length()).trim();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1153 */       if (line.startsWith("FOREIGN KEY")) {
/* 1154 */         if (line.endsWith(",")) {
/* 1155 */           line = line.substring(0, line.length() - 1);
/*      */         }
/*      */         
/* 1158 */         int indexOfFK = line.indexOf("FOREIGN KEY");
/*      */         
/* 1160 */         String localColumnName = null;
/* 1161 */         String referencedCatalogName = StringUtils.quoteIdentifier(catalog, this.quotedId, this.conn.getPedantic());
/* 1162 */         String referencedTableName = null;
/* 1163 */         String referencedColumnName = null;
/*      */         
/* 1165 */         if (indexOfFK != -1) {
/* 1166 */           int afterFk = indexOfFK + "FOREIGN KEY".length();
/*      */           
/* 1168 */           int indexOfRef = StringUtils.indexOfIgnoreCase(afterFk, line, "REFERENCES", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */           
/* 1170 */           if (indexOfRef != -1)
/*      */           {
/* 1172 */             int indexOfParenOpen = line.indexOf('(', afterFk);
/* 1173 */             int indexOfParenClose = StringUtils.indexOfIgnoreCase(indexOfParenOpen, line, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */             
/*      */ 
/* 1176 */             if ((indexOfParenOpen != -1) && (indexOfParenClose == -1)) {}
/*      */             
/*      */ 
/*      */ 
/* 1180 */             localColumnName = line.substring(indexOfParenOpen + 1, indexOfParenClose);
/*      */             
/* 1182 */             int afterRef = indexOfRef + "REFERENCES".length();
/*      */             
/* 1184 */             int referencedColumnBegin = StringUtils.indexOfIgnoreCase(afterRef, line, "(", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */             
/*      */ 
/* 1187 */             if (referencedColumnBegin != -1) {
/* 1188 */               referencedTableName = line.substring(afterRef, referencedColumnBegin);
/*      */               
/* 1190 */               int referencedColumnEnd = StringUtils.indexOfIgnoreCase(referencedColumnBegin + 1, line, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */               
/*      */ 
/* 1193 */               if (referencedColumnEnd != -1) {
/* 1194 */                 referencedColumnName = line.substring(referencedColumnBegin + 1, referencedColumnEnd);
/*      */               }
/*      */               
/* 1197 */               int indexOfCatalogSep = StringUtils.indexOfIgnoreCase(0, referencedTableName, ".", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */               
/*      */ 
/* 1200 */               if (indexOfCatalogSep != -1) {
/* 1201 */                 referencedCatalogName = referencedTableName.substring(0, indexOfCatalogSep);
/* 1202 */                 referencedTableName = referencedTableName.substring(indexOfCatalogSep + 1);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1208 */         if (!firstTime) {
/* 1209 */           commentBuf.append("; ");
/*      */         } else {
/* 1211 */           firstTime = false;
/*      */         }
/*      */         
/* 1214 */         if (constraintName != null) {
/* 1215 */           commentBuf.append(constraintName);
/*      */         } else {
/* 1217 */           commentBuf.append("not_available");
/*      */         }
/*      */         
/* 1220 */         commentBuf.append("(");
/* 1221 */         commentBuf.append(localColumnName);
/* 1222 */         commentBuf.append(") REFER ");
/* 1223 */         commentBuf.append(referencedCatalogName);
/* 1224 */         commentBuf.append("/");
/* 1225 */         commentBuf.append(referencedTableName);
/* 1226 */         commentBuf.append("(");
/* 1227 */         commentBuf.append(referencedColumnName);
/* 1228 */         commentBuf.append(")");
/*      */         
/* 1230 */         int lastParenIndex = line.lastIndexOf(")");
/*      */         
/* 1232 */         if (lastParenIndex != line.length() - 1) {
/* 1233 */           String cascadeOptions = line.substring(lastParenIndex + 1);
/* 1234 */           commentBuf.append(" ");
/* 1235 */           commentBuf.append(cascadeOptions);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1240 */     row[2] = s2b(commentBuf.toString());
/* 1241 */     rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */     
/* 1243 */     return rows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet extractForeignKeyFromCreateTable(String catalog, String tableName)
/*      */     throws SQLException
/*      */   {
/* 1263 */     ArrayList<String> tableList = new ArrayList();
/* 1264 */     ResultSet rs = null;
/* 1265 */     java.sql.Statement stmt = null;
/*      */     
/* 1267 */     if (tableName != null) {
/* 1268 */       tableList.add(tableName);
/*      */     } else {
/*      */       try {
/* 1271 */         rs = getTables(catalog, "", "%", new String[] { "TABLE" });
/*      */         
/* 1273 */         while (rs.next()) {
/* 1274 */           tableList.add(rs.getString("TABLE_NAME"));
/*      */         }
/*      */       } finally {
/* 1277 */         if (rs != null) {
/* 1278 */           rs.close();
/*      */         }
/*      */         
/* 1281 */         rs = null;
/*      */       }
/*      */     }
/*      */     
/* 1285 */     Object rows = new ArrayList();
/* 1286 */     Field[] fields = new Field[3];
/* 1287 */     fields[0] = new Field("", "Name", 1, Integer.MAX_VALUE);
/* 1288 */     fields[1] = new Field("", "Type", 1, 255);
/* 1289 */     fields[2] = new Field("", "Comment", 1, Integer.MAX_VALUE);
/*      */     
/* 1291 */     int numTables = tableList.size();
/* 1292 */     stmt = this.conn.getMetadataSafeStatement();
/*      */     try
/*      */     {
/* 1295 */       for (int i = 0; i < numTables; i++) {
/* 1296 */         String tableToExtract = (String)tableList.get(i);
/*      */         
/* 1298 */         String query = "SHOW CREATE TABLE " + getFullyQualifiedName(catalog, tableToExtract);
/*      */         try
/*      */         {
/* 1301 */           rs = stmt.executeQuery(query);
/*      */         }
/*      */         catch (SQLException sqlEx) {
/* 1304 */           String sqlState = sqlEx.getSQLState();
/*      */           
/* 1306 */           if ((!"42S02".equals(sqlState)) && (sqlEx.getErrorCode() != 1146)) {
/* 1307 */             throw sqlEx;
/*      */           }
/*      */           
/* 1310 */           continue;
/*      */         }
/*      */         
/* 1313 */         while (rs.next()) {
/* 1314 */           extractForeignKeyForTable((ArrayList)rows, rs, catalog);
/*      */         }
/*      */       }
/*      */     } finally {
/* 1318 */       if (rs != null) {
/* 1319 */         rs.close();
/*      */       }
/*      */       
/* 1322 */       rs = null;
/*      */       
/* 1324 */       if (stmt != null) {
/* 1325 */         stmt.close();
/*      */       }
/*      */       
/* 1328 */       stmt = null;
/*      */     }
/*      */     
/* 1331 */     return buildResultSet(fields, (ArrayList)rows);
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getAttributes(String arg0, String arg1, String arg2, String arg3)
/*      */     throws SQLException
/*      */   {
/* 1338 */     Field[] fields = new Field[21];
/* 1339 */     fields[0] = new Field("", "TYPE_CAT", 1, 32);
/* 1340 */     fields[1] = new Field("", "TYPE_SCHEM", 1, 32);
/* 1341 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/* 1342 */     fields[3] = new Field("", "ATTR_NAME", 1, 32);
/* 1343 */     fields[4] = new Field("", "DATA_TYPE", 5, 32);
/* 1344 */     fields[5] = new Field("", "ATTR_TYPE_NAME", 1, 32);
/* 1345 */     fields[6] = new Field("", "ATTR_SIZE", 4, 32);
/* 1346 */     fields[7] = new Field("", "DECIMAL_DIGITS", 4, 32);
/* 1347 */     fields[8] = new Field("", "NUM_PREC_RADIX", 4, 32);
/* 1348 */     fields[9] = new Field("", "NULLABLE ", 4, 32);
/* 1349 */     fields[10] = new Field("", "REMARKS", 1, 32);
/* 1350 */     fields[11] = new Field("", "ATTR_DEF", 1, 32);
/* 1351 */     fields[12] = new Field("", "SQL_DATA_TYPE", 4, 32);
/* 1352 */     fields[13] = new Field("", "SQL_DATETIME_SUB", 4, 32);
/* 1353 */     fields[14] = new Field("", "CHAR_OCTET_LENGTH", 4, 32);
/* 1354 */     fields[15] = new Field("", "ORDINAL_POSITION", 4, 32);
/* 1355 */     fields[16] = new Field("", "IS_NULLABLE", 1, 32);
/* 1356 */     fields[17] = new Field("", "SCOPE_CATALOG", 1, 32);
/* 1357 */     fields[18] = new Field("", "SCOPE_SCHEMA", 1, 32);
/* 1358 */     fields[19] = new Field("", "SCOPE_TABLE", 1, 32);
/* 1359 */     fields[20] = new Field("", "SOURCE_DATA_TYPE", 5, 32);
/*      */     
/* 1361 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getBestRowIdentifier(String catalog, String schema, final String table, int scope, boolean nullable)
/*      */     throws SQLException
/*      */   {
/* 1407 */     if (table == null) {
/* 1408 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 1411 */     Field[] fields = new Field[8];
/* 1412 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 1413 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 1414 */     fields[2] = new Field("", "DATA_TYPE", 4, 32);
/* 1415 */     fields[3] = new Field("", "TYPE_NAME", 1, 32);
/* 1416 */     fields[4] = new Field("", "COLUMN_SIZE", 4, 10);
/* 1417 */     fields[5] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 1418 */     fields[6] = new Field("", "DECIMAL_DIGITS", 5, 10);
/* 1419 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */     
/* 1421 */     final ArrayList<ResultSetRow> rows = new ArrayList();
/* 1422 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 1426 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(String catalogStr) throws SQLException {
/* 1429 */           ResultSet results = null;
/*      */           try
/*      */           {
/* 1432 */             StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
/* 1433 */             queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 1434 */             queryBuf.append(" FROM ");
/* 1435 */             queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */             
/* 1437 */             results = stmt.executeQuery(queryBuf.toString());
/*      */             
/* 1439 */             while (results.next()) {
/* 1440 */               String keyType = results.getString("Key");
/*      */               
/* 1442 */               if ((keyType != null) && 
/* 1443 */                 (StringUtils.startsWithIgnoreCase(keyType, "PRI"))) {
/* 1444 */                 byte[][] rowVal = new byte[8][];
/* 1445 */                 rowVal[0] = Integer.toString(2).getBytes();
/* 1446 */                 rowVal[1] = results.getBytes("Field");
/*      */                 
/* 1448 */                 String type = results.getString("Type");
/* 1449 */                 int size = MysqlIO.getMaxBuf();
/* 1450 */                 int decimals = 0;
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 1455 */                 if (type.indexOf("enum") != -1) {
/* 1456 */                   String temp = type.substring(type.indexOf("("), type.indexOf(")"));
/* 1457 */                   StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/* 1458 */                   int maxLength = 0;
/*      */                   
/* 1460 */                   while (tokenizer.hasMoreTokens()) {
/* 1461 */                     maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*      */                   }
/*      */                   
/* 1464 */                   size = maxLength;
/* 1465 */                   decimals = 0;
/* 1466 */                   type = "enum";
/* 1467 */                 } else if (type.indexOf("(") != -1) {
/* 1468 */                   if (type.indexOf(",") != -1) {
/* 1469 */                     size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(",")));
/* 1470 */                     decimals = Integer.parseInt(type.substring(type.indexOf(",") + 1, type.indexOf(")")));
/*      */                   } else {
/* 1472 */                     size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(")")));
/*      */                   }
/*      */                   
/* 1475 */                   type = type.substring(0, type.indexOf("("));
/*      */                 }
/*      */                 
/* 1478 */                 rowVal[2] = DatabaseMetaData.this.s2b(String.valueOf(MysqlDefs.mysqlToJavaType(type)));
/* 1479 */                 rowVal[3] = DatabaseMetaData.this.s2b(type);
/* 1480 */                 rowVal[4] = Integer.toString(size + decimals).getBytes();
/* 1481 */                 rowVal[5] = Integer.toString(size + decimals).getBytes();
/* 1482 */                 rowVal[6] = Integer.toString(decimals).getBytes();
/* 1483 */                 rowVal[7] = Integer.toString(1).getBytes();
/*      */                 
/* 1485 */                 rows.add(new ByteArrayRow(rowVal, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (SQLException sqlEx) {
/* 1490 */             if (!"42S02".equals(sqlEx.getSQLState())) {
/* 1491 */               throw sqlEx;
/*      */             }
/*      */           } finally {
/* 1494 */             if (results != null) {
/*      */               try {
/* 1496 */                 results.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/* 1500 */               results = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     } finally {
/* 1506 */       if (stmt != null) {
/* 1507 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 1511 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 1513 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getCallStmtParameterTypes(String catalog, String quotedProcName, ProcedureType procType, String parameterNamePattern, List<ResultSetRow> resultRows, boolean forGetFunctionColumns)
/*      */     throws SQLException
/*      */   {
/* 1525 */     java.sql.Statement paramRetrievalStmt = null;
/* 1526 */     ResultSet paramRetrievalRs = null;
/*      */     
/* 1528 */     if (parameterNamePattern == null) {
/* 1529 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 1530 */         parameterNamePattern = "%";
/*      */       } else {
/* 1532 */         throw SQLError.createSQLException("Parameter/Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1537 */     String parameterDef = null;
/*      */     
/* 1539 */     byte[] procNameAsBytes = null;
/* 1540 */     byte[] procCatAsBytes = null;
/*      */     
/* 1542 */     boolean isProcedureInAnsiMode = false;
/* 1543 */     String storageDefnDelims = null;
/* 1544 */     String storageDefnClosures = null;
/*      */     try
/*      */     {
/* 1547 */       paramRetrievalStmt = this.conn.getMetadataSafeStatement();
/*      */       
/* 1549 */       String oldCatalog = this.conn.getCatalog();
/* 1550 */       if ((this.conn.lowerCaseTableNames()) && (catalog != null) && (catalog.length() != 0) && (oldCatalog != null) && (oldCatalog.length() != 0))
/*      */       {
/*      */ 
/* 1553 */         ResultSet rs = null;
/*      */         try
/*      */         {
/* 1556 */           this.conn.setCatalog(StringUtils.unQuoteIdentifier(catalog, this.quotedId));
/* 1557 */           rs = paramRetrievalStmt.executeQuery("SELECT DATABASE()");
/* 1558 */           rs.next();
/*      */           
/* 1560 */           catalog = rs.getString(1);
/*      */         }
/*      */         finally
/*      */         {
/* 1564 */           this.conn.setCatalog(oldCatalog);
/*      */           
/* 1566 */           if (rs != null) {
/* 1567 */             rs.close();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1572 */       if (paramRetrievalStmt.getMaxRows() != 0) {
/* 1573 */         paramRetrievalStmt.setMaxRows(0);
/*      */       }
/*      */       
/* 1576 */       int dotIndex = -1;
/*      */       
/* 1578 */       if (!" ".equals(this.quotedId)) {
/* 1579 */         dotIndex = StringUtils.indexOfIgnoreCase(0, quotedProcName, ".", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */       }
/*      */       else {
/* 1582 */         dotIndex = quotedProcName.indexOf(".");
/*      */       }
/*      */       
/* 1585 */       String dbName = null;
/*      */       
/* 1587 */       if ((dotIndex != -1) && (dotIndex + 1 < quotedProcName.length())) {
/* 1588 */         dbName = quotedProcName.substring(0, dotIndex);
/* 1589 */         quotedProcName = quotedProcName.substring(dotIndex + 1);
/*      */       } else {
/* 1591 */         dbName = StringUtils.quoteIdentifier(catalog, this.quotedId, this.conn.getPedantic());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1596 */       String tmpProcName = StringUtils.unQuoteIdentifier(quotedProcName, this.quotedId);
/*      */       try {
/* 1598 */         procNameAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
/*      */       } catch (UnsupportedEncodingException ueEx) {
/* 1600 */         procNameAsBytes = s2b(tmpProcName);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1605 */       tmpProcName = StringUtils.unQuoteIdentifier(dbName, this.quotedId);
/*      */       try {
/* 1607 */         procCatAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
/*      */       } catch (UnsupportedEncodingException ueEx) {
/* 1609 */         procCatAsBytes = s2b(tmpProcName);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1615 */       StringBuilder procNameBuf = new StringBuilder();
/* 1616 */       procNameBuf.append(dbName);
/* 1617 */       procNameBuf.append('.');
/* 1618 */       procNameBuf.append(quotedProcName);
/*      */       
/* 1620 */       String fieldName = null;
/* 1621 */       if (procType == ProcedureType.PROCEDURE) {
/* 1622 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE PROCEDURE " + procNameBuf.toString());
/* 1623 */         fieldName = "Create Procedure";
/*      */       } else {
/* 1625 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE FUNCTION " + procNameBuf.toString());
/* 1626 */         fieldName = "Create Function";
/*      */       }
/*      */       
/* 1629 */       if (paramRetrievalRs.next()) {
/* 1630 */         String procedureDef = paramRetrievalRs.getString(fieldName);
/*      */         
/* 1632 */         if ((!this.conn.getNoAccessToProcedureBodies()) && ((procedureDef == null) || (procedureDef.length() == 0))) {
/* 1633 */           throw SQLError.createSQLException("User does not have access to metadata required to determine stored procedure parameter types. If rights can not be granted, configure connection with \"noAccessToProcedureBodies=true\" to have driver generate parameters that represent INOUT strings irregardless of actual parameter types.", "S1000", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1640 */           String sqlMode = paramRetrievalRs.getString("sql_mode");
/*      */           
/* 1642 */           if (StringUtils.indexOfIgnoreCase(sqlMode, "ANSI") != -1) {
/* 1643 */             isProcedureInAnsiMode = true;
/*      */           }
/*      */         }
/*      */         catch (SQLException sqlEx) {}
/*      */         
/*      */ 
/* 1649 */         String identifierMarkers = isProcedureInAnsiMode ? "`\"" : "`";
/* 1650 */         String identifierAndStringMarkers = "'" + identifierMarkers;
/* 1651 */         storageDefnDelims = "(" + identifierMarkers;
/* 1652 */         storageDefnClosures = ")" + identifierMarkers;
/*      */         
/* 1654 */         if ((procedureDef != null) && (procedureDef.length() != 0))
/*      */         {
/* 1656 */           procedureDef = StringUtils.stripComments(procedureDef, identifierAndStringMarkers, identifierAndStringMarkers, true, false, true, true);
/*      */           
/* 1658 */           int openParenIndex = StringUtils.indexOfIgnoreCase(0, procedureDef, "(", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */           
/* 1660 */           int endOfParamDeclarationIndex = 0;
/*      */           
/* 1662 */           endOfParamDeclarationIndex = endPositionOfParameterDeclaration(openParenIndex, procedureDef, this.quotedId);
/*      */           
/* 1664 */           if (procType == ProcedureType.FUNCTION)
/*      */           {
/*      */ 
/*      */ 
/* 1668 */             int returnsIndex = StringUtils.indexOfIgnoreCase(0, procedureDef, " RETURNS ", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */             
/*      */ 
/* 1671 */             int endReturnsDef = findEndOfReturnsClause(procedureDef, returnsIndex);
/*      */             
/*      */ 
/*      */ 
/* 1675 */             int declarationStart = returnsIndex + "RETURNS ".length();
/*      */             
/* 1677 */             while ((declarationStart < procedureDef.length()) && 
/* 1678 */               (Character.isWhitespace(procedureDef.charAt(declarationStart)))) {
/* 1679 */               declarationStart++;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1685 */             String returnsDefn = procedureDef.substring(declarationStart, endReturnsDef).trim();
/* 1686 */             TypeDescriptor returnDescriptor = new TypeDescriptor(returnsDefn, "YES");
/*      */             
/* 1688 */             resultRows.add(convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, "", false, false, true, returnDescriptor, forGetFunctionColumns, 0));
/*      */           }
/*      */           
/*      */ 
/* 1692 */           if ((openParenIndex == -1) || (endOfParamDeclarationIndex == -1))
/*      */           {
/* 1694 */             throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 1698 */           parameterDef = procedureDef.substring(openParenIndex + 1, endOfParamDeclarationIndex);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally {
/* 1703 */       SQLException sqlExRethrow = null;
/*      */       
/* 1705 */       if (paramRetrievalRs != null) {
/*      */         try {
/* 1707 */           paramRetrievalRs.close();
/*      */         } catch (SQLException sqlEx) {
/* 1709 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */         
/* 1712 */         paramRetrievalRs = null;
/*      */       }
/*      */       
/* 1715 */       if (paramRetrievalStmt != null) {
/*      */         try {
/* 1717 */           paramRetrievalStmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1719 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */         
/* 1722 */         paramRetrievalStmt = null;
/*      */       }
/*      */       
/* 1725 */       if (sqlExRethrow != null) {
/* 1726 */         throw sqlExRethrow;
/*      */       }
/*      */     }
/*      */     
/* 1730 */     if (parameterDef != null) {
/* 1731 */       int ordinal = 1;
/*      */       
/* 1733 */       List<String> parseList = StringUtils.split(parameterDef, ",", storageDefnDelims, storageDefnClosures, true);
/*      */       
/* 1735 */       int parseListLen = parseList.size();
/*      */       
/* 1737 */       for (int i = 0; i < parseListLen; i++) {
/* 1738 */         String declaration = (String)parseList.get(i);
/*      */         
/* 1740 */         if (declaration.trim().length() == 0) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/* 1745 */         declaration = declaration.replaceAll("[\\t\\n\\x0B\\f\\r]", " ");
/* 1746 */         StringTokenizer declarationTok = new StringTokenizer(declaration, " \t");
/*      */         
/* 1748 */         String paramName = null;
/* 1749 */         boolean isOutParam = false;
/* 1750 */         boolean isInParam = false;
/*      */         
/* 1752 */         if (declarationTok.hasMoreTokens()) {
/* 1753 */           String possibleParamName = declarationTok.nextToken();
/*      */           
/* 1755 */           if (possibleParamName.equalsIgnoreCase("OUT")) {
/* 1756 */             isOutParam = true;
/*      */             
/* 1758 */             if (declarationTok.hasMoreTokens()) {
/* 1759 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1761 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           }
/* 1764 */           else if (possibleParamName.equalsIgnoreCase("INOUT")) {
/* 1765 */             isOutParam = true;
/* 1766 */             isInParam = true;
/*      */             
/* 1768 */             if (declarationTok.hasMoreTokens()) {
/* 1769 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1771 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           }
/* 1774 */           else if (possibleParamName.equalsIgnoreCase("IN")) {
/* 1775 */             isOutParam = false;
/* 1776 */             isInParam = true;
/*      */             
/* 1778 */             if (declarationTok.hasMoreTokens()) {
/* 1779 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1781 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           else {
/* 1785 */             isOutParam = false;
/* 1786 */             isInParam = true;
/*      */             
/* 1788 */             paramName = possibleParamName;
/*      */           }
/*      */           
/* 1791 */           TypeDescriptor typeDesc = null;
/*      */           
/* 1793 */           if (declarationTok.hasMoreTokens()) {
/* 1794 */             StringBuilder typeInfoBuf = new StringBuilder(declarationTok.nextToken());
/*      */             
/* 1796 */             while (declarationTok.hasMoreTokens()) {
/* 1797 */               typeInfoBuf.append(" ");
/* 1798 */               typeInfoBuf.append(declarationTok.nextToken());
/*      */             }
/*      */             
/* 1801 */             String typeInfo = typeInfoBuf.toString();
/*      */             
/* 1803 */             typeDesc = new TypeDescriptor(typeInfo, "YES");
/*      */           } else {
/* 1805 */             throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter type)", "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 1809 */           if (((paramName.startsWith("`")) && (paramName.endsWith("`"))) || ((isProcedureInAnsiMode) && (paramName.startsWith("\"")) && (paramName.endsWith("\""))))
/*      */           {
/* 1811 */             paramName = paramName.substring(1, paramName.length() - 1);
/*      */           }
/*      */           
/* 1814 */           int wildCompareRes = StringUtils.wildCompare(paramName, parameterNamePattern);
/*      */           
/* 1816 */           if (wildCompareRes != -1) {
/* 1817 */             ResultSetRow row = convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, paramName, isOutParam, isInParam, false, typeDesc, forGetFunctionColumns, ordinal++);
/*      */             
/*      */ 
/* 1820 */             resultRows.add(row);
/*      */           }
/*      */         } else {
/* 1823 */           throw SQLError.createSQLException("Internal error when parsing callable statement metadata (unknown output from 'SHOW CREATE PROCEDURE')", "S1000", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int endPositionOfParameterDeclaration(int beginIndex, String procedureDef, String quoteChar)
/*      */     throws SQLException
/*      */   {
/* 1849 */     int currentPos = beginIndex + 1;
/* 1850 */     int parenDepth = 1;
/*      */     
/* 1852 */     while ((parenDepth > 0) && (currentPos < procedureDef.length())) {
/* 1853 */       int closedParenIndex = StringUtils.indexOfIgnoreCase(currentPos, procedureDef, ")", quoteChar, quoteChar, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */       
/*      */ 
/* 1856 */       if (closedParenIndex != -1) {
/* 1857 */         int nextOpenParenIndex = StringUtils.indexOfIgnoreCase(currentPos, procedureDef, "(", quoteChar, quoteChar, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */         
/*      */ 
/* 1860 */         if ((nextOpenParenIndex != -1) && (nextOpenParenIndex < closedParenIndex)) {
/* 1861 */           parenDepth++;
/* 1862 */           currentPos = closedParenIndex + 1;
/*      */         } else {
/* 1864 */           parenDepth--;
/* 1865 */           currentPos = closedParenIndex;
/*      */         }
/*      */       }
/*      */       else {
/* 1869 */         throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1874 */     return currentPos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int findEndOfReturnsClause(String procedureDefn, int positionOfReturnKeyword)
/*      */     throws SQLException
/*      */   {
/* 1897 */     String openingMarkers = this.quotedId + "(";
/* 1898 */     String closingMarkers = this.quotedId + ")";
/*      */     
/* 1900 */     String[] tokens = { "LANGUAGE", "NOT", "DETERMINISTIC", "CONTAINS", "NO", "READ", "MODIFIES", "SQL", "COMMENT", "BEGIN", "RETURN" };
/*      */     
/* 1902 */     int startLookingAt = positionOfReturnKeyword + "RETURNS".length() + 1;
/*      */     
/* 1904 */     int endOfReturn = -1;
/*      */     
/* 1906 */     for (int i = 0; i < tokens.length; i++) {
/* 1907 */       int nextEndOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, tokens[i], openingMarkers, closingMarkers, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */       
/*      */ 
/* 1910 */       if ((nextEndOfReturn != -1) && (
/* 1911 */         (endOfReturn == -1) || (nextEndOfReturn < endOfReturn))) {
/* 1912 */         endOfReturn = nextEndOfReturn;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1917 */     if (endOfReturn != -1) {
/* 1918 */       return endOfReturn;
/*      */     }
/*      */     
/*      */ 
/* 1922 */     endOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, ":", openingMarkers, closingMarkers, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */     
/*      */ 
/* 1925 */     if (endOfReturn != -1)
/*      */     {
/* 1927 */       for (int i = endOfReturn; i > 0; i--) {
/* 1928 */         if (Character.isWhitespace(procedureDefn.charAt(i))) {
/* 1929 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1936 */     throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCascadeDeleteOption(String cascadeOptions)
/*      */   {
/* 1949 */     int onDeletePos = cascadeOptions.indexOf("ON DELETE");
/*      */     
/* 1951 */     if (onDeletePos != -1) {
/* 1952 */       String deleteOptions = cascadeOptions.substring(onDeletePos, cascadeOptions.length());
/*      */       
/* 1954 */       if (deleteOptions.startsWith("ON DELETE CASCADE"))
/* 1955 */         return 0;
/* 1956 */       if (deleteOptions.startsWith("ON DELETE SET NULL"))
/* 1957 */         return 2;
/* 1958 */       if (deleteOptions.startsWith("ON DELETE RESTRICT"))
/* 1959 */         return 1;
/* 1960 */       if (deleteOptions.startsWith("ON DELETE NO ACTION")) {
/* 1961 */         return 3;
/*      */       }
/*      */     }
/*      */     
/* 1965 */     return 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCascadeUpdateOption(String cascadeOptions)
/*      */   {
/* 1977 */     int onUpdatePos = cascadeOptions.indexOf("ON UPDATE");
/*      */     
/* 1979 */     if (onUpdatePos != -1) {
/* 1980 */       String updateOptions = cascadeOptions.substring(onUpdatePos, cascadeOptions.length());
/*      */       
/* 1982 */       if (updateOptions.startsWith("ON UPDATE CASCADE"))
/* 1983 */         return 0;
/* 1984 */       if (updateOptions.startsWith("ON UPDATE SET NULL"))
/* 1985 */         return 2;
/* 1986 */       if (updateOptions.startsWith("ON UPDATE RESTRICT"))
/* 1987 */         return 1;
/* 1988 */       if (updateOptions.startsWith("ON UPDATE NO ACTION")) {
/* 1989 */         return 3;
/*      */       }
/*      */     }
/*      */     
/* 1993 */     return 3;
/*      */   }
/*      */   
/*      */   protected IteratorWithCleanup<String> getCatalogIterator(String catalogSpec) throws SQLException { IteratorWithCleanup<String> allCatalogsIter;
/*      */     IteratorWithCleanup<String> allCatalogsIter;
/* 1998 */     if (catalogSpec != null) { IteratorWithCleanup<String> allCatalogsIter;
/* 1999 */       if (!catalogSpec.equals("")) { IteratorWithCleanup<String> allCatalogsIter;
/* 2000 */         if (this.conn.getPedantic()) {
/* 2001 */           allCatalogsIter = new SingleStringIterator(catalogSpec);
/*      */         } else {
/* 2003 */           allCatalogsIter = new SingleStringIterator(StringUtils.unQuoteIdentifier(catalogSpec, this.quotedId));
/*      */         }
/*      */       }
/*      */       else {
/* 2007 */         allCatalogsIter = new SingleStringIterator(this.database);
/*      */       } } else { IteratorWithCleanup<String> allCatalogsIter;
/* 2009 */       if (this.conn.getNullCatalogMeansCurrent())
/*      */       {
/* 2011 */         allCatalogsIter = new SingleStringIterator(this.database);
/*      */       } else {
/* 2013 */         allCatalogsIter = new ResultSetIterator(getCatalogs(), 1);
/*      */       }
/*      */     }
/* 2016 */     return allCatalogsIter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCatalogs()
/*      */     throws SQLException
/*      */   {
/* 2034 */     ResultSet results = null;
/* 2035 */     java.sql.Statement stmt = null;
/*      */     try
/*      */     {
/* 2038 */       stmt = this.conn.getMetadataSafeStatement();
/* 2039 */       results = stmt.executeQuery("SHOW DATABASES");
/*      */       
/* 2041 */       int catalogsCount = 0;
/* 2042 */       if (results.last()) {
/* 2043 */         catalogsCount = results.getRow();
/* 2044 */         results.beforeFirst();
/*      */       }
/*      */       
/* 2047 */       List<String> resultsAsList = new ArrayList(catalogsCount);
/* 2048 */       while (results.next()) {
/* 2049 */         resultsAsList.add(results.getString(1));
/*      */       }
/* 2051 */       Collections.sort(resultsAsList);
/*      */       
/* 2053 */       Field[] fields = new Field[1];
/* 2054 */       fields[0] = new Field("", "TABLE_CAT", 12, results.getMetaData().getColumnDisplaySize(1));
/*      */       
/* 2056 */       ArrayList<ResultSetRow> tuples = new ArrayList(catalogsCount);
/* 2057 */       for (String cat : resultsAsList) {
/* 2058 */         byte[][] rowVal = new byte[1][];
/* 2059 */         rowVal[0] = s2b(cat);
/* 2060 */         tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */       }
/*      */       
/* 2063 */       return buildResultSet(fields, tuples);
/*      */     } finally {
/* 2065 */       if (results != null) {
/*      */         try {
/* 2067 */           results.close();
/*      */         } catch (SQLException sqlEx) {
/* 2069 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */         
/* 2072 */         results = null;
/*      */       }
/*      */       
/* 2075 */       if (stmt != null) {
/*      */         try {
/* 2077 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 2079 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */         
/* 2082 */         stmt = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCatalogSeparator()
/*      */     throws SQLException
/*      */   {
/* 2094 */     return ".";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCatalogTerm()
/*      */     throws SQLException
/*      */   {
/* 2107 */     return "database";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 2143 */     Field[] fields = new Field[8];
/* 2144 */     fields[0] = new Field("", "TABLE_CAT", 1, 64);
/* 2145 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 1);
/* 2146 */     fields[2] = new Field("", "TABLE_NAME", 1, 64);
/* 2147 */     fields[3] = new Field("", "COLUMN_NAME", 1, 64);
/* 2148 */     fields[4] = new Field("", "GRANTOR", 1, 77);
/* 2149 */     fields[5] = new Field("", "GRANTEE", 1, 77);
/* 2150 */     fields[6] = new Field("", "PRIVILEGE", 1, 64);
/* 2151 */     fields[7] = new Field("", "IS_GRANTABLE", 1, 3);
/*      */     
/* 2153 */     String grantQuery = "SELECT c.host, c.db, t.grantor, c.user, c.table_name, c.column_name, c.column_priv FROM mysql.columns_priv c, mysql.tables_priv t WHERE c.host = t.host AND c.db = t.db AND c.table_name = t.table_name AND c.db LIKE ? AND c.table_name = ? AND c.column_name LIKE ?";
/*      */     
/*      */ 
/*      */ 
/* 2157 */     PreparedStatement pStmt = null;
/* 2158 */     ResultSet results = null;
/* 2159 */     ArrayList<ResultSetRow> grantRows = new ArrayList();
/*      */     try
/*      */     {
/* 2162 */       pStmt = prepareMetaDataSafeStatement(grantQuery);
/*      */       
/* 2164 */       pStmt.setString(1, (catalog != null) && (catalog.length() != 0) ? catalog : "%");
/* 2165 */       pStmt.setString(2, table);
/* 2166 */       pStmt.setString(3, columnNamePattern);
/*      */       
/* 2168 */       results = pStmt.executeQuery();
/*      */       
/* 2170 */       while (results.next()) {
/* 2171 */         String host = results.getString(1);
/* 2172 */         String db = results.getString(2);
/* 2173 */         String grantor = results.getString(3);
/* 2174 */         String user = results.getString(4);
/*      */         
/* 2176 */         if ((user == null) || (user.length() == 0)) {
/* 2177 */           user = "%";
/*      */         }
/*      */         
/* 2180 */         StringBuilder fullUser = new StringBuilder(user);
/*      */         
/* 2182 */         if ((host != null) && (this.conn.getUseHostsInPrivileges())) {
/* 2183 */           fullUser.append("@");
/* 2184 */           fullUser.append(host);
/*      */         }
/*      */         
/* 2187 */         String columnName = results.getString(6);
/* 2188 */         String allPrivileges = results.getString(7);
/*      */         
/* 2190 */         if (allPrivileges != null) {
/* 2191 */           allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/*      */           
/* 2193 */           StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/*      */           
/* 2195 */           while (st.hasMoreTokens()) {
/* 2196 */             String privilege = st.nextToken().trim();
/* 2197 */             byte[][] tuple = new byte[8][];
/* 2198 */             tuple[0] = s2b(db);
/* 2199 */             tuple[1] = null;
/* 2200 */             tuple[2] = s2b(table);
/* 2201 */             tuple[3] = s2b(columnName);
/*      */             
/* 2203 */             if (grantor != null) {
/* 2204 */               tuple[4] = s2b(grantor);
/*      */             } else {
/* 2206 */               tuple[4] = null;
/*      */             }
/*      */             
/* 2209 */             tuple[5] = s2b(fullUser.toString());
/* 2210 */             tuple[6] = s2b(privilege);
/* 2211 */             tuple[7] = null;
/* 2212 */             grantRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */           }
/*      */         }
/*      */       }
/*      */     } finally {
/* 2217 */       if (results != null) {
/*      */         try {
/* 2219 */           results.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/* 2223 */         results = null;
/*      */       }
/*      */       
/* 2226 */       if (pStmt != null) {
/*      */         try {
/* 2228 */           pStmt.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/* 2232 */         pStmt = null;
/*      */       }
/*      */     }
/*      */     
/* 2236 */     return buildResultSet(fields, grantRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumns(String catalog, final String schemaPattern, final String tableNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 2293 */     if (columnNamePattern == null) {
/* 2294 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 2295 */         columnNamePattern = "%";
/*      */       } else {
/* 2297 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2302 */     final String colPattern = columnNamePattern;
/*      */     
/* 2304 */     Field[] fields = createColumnsFields();
/*      */     
/* 2306 */     final ArrayList<ResultSetRow> rows = new ArrayList();
/* 2307 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 2311 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(String catalogStr) throws SQLException
/*      */         {
/* 2315 */           ArrayList<String> tableNameList = new ArrayList();
/*      */           
/* 2317 */           if (tableNamePattern == null)
/*      */           {
/* 2319 */             ResultSet tables = null;
/*      */             try
/*      */             {
/* 2322 */               tables = DatabaseMetaData.this.getTables(catalogStr, schemaPattern, "%", new String[0]);
/*      */               
/* 2324 */               while (tables.next()) {
/* 2325 */                 String tableNameFromList = tables.getString("TABLE_NAME");
/* 2326 */                 tableNameList.add(tableNameFromList);
/*      */               }
/*      */             } finally {
/* 2329 */               if (tables != null) {
/*      */                 try {
/* 2331 */                   tables.close();
/*      */                 } catch (Exception sqlEx) {
/* 2333 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/* 2336 */                 tables = null;
/*      */               }
/*      */             }
/*      */           } else {
/* 2340 */             ResultSet tables = null;
/*      */             try
/*      */             {
/* 2343 */               tables = DatabaseMetaData.this.getTables(catalogStr, schemaPattern, tableNamePattern, new String[0]);
/*      */               
/* 2345 */               while (tables.next()) {
/* 2346 */                 String tableNameFromList = tables.getString("TABLE_NAME");
/* 2347 */                 tableNameList.add(tableNameFromList);
/*      */               }
/*      */             } finally {
/* 2350 */               if (tables != null) {
/*      */                 try {
/* 2352 */                   tables.close();
/*      */                 } catch (SQLException sqlEx) {
/* 2354 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/* 2357 */                 tables = null;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 2362 */           for (String tableName : tableNameList)
/*      */           {
/* 2364 */             ResultSet results = null;
/*      */             try
/*      */             {
/* 2367 */               StringBuilder queryBuf = new StringBuilder("SHOW ");
/*      */               
/* 2369 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2370 */                 queryBuf.append("FULL ");
/*      */               }
/*      */               
/* 2373 */               queryBuf.append("COLUMNS FROM ");
/* 2374 */               queryBuf.append(StringUtils.quoteIdentifier(tableName, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 2375 */               queryBuf.append(" FROM ");
/* 2376 */               queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 2377 */               queryBuf.append(" LIKE ");
/* 2378 */               queryBuf.append(StringUtils.quoteIdentifier(colPattern, "'", true));
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 2383 */               boolean fixUpOrdinalsRequired = false;
/* 2384 */               Object ordinalFixUpMap = null;
/*      */               
/* 2386 */               if (!colPattern.equals("%")) {
/* 2387 */                 fixUpOrdinalsRequired = true;
/*      */                 
/* 2389 */                 StringBuilder fullColumnQueryBuf = new StringBuilder("SHOW ");
/*      */                 
/* 2391 */                 if (DatabaseMetaData.this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2392 */                   fullColumnQueryBuf.append("FULL ");
/*      */                 }
/*      */                 
/* 2395 */                 fullColumnQueryBuf.append("COLUMNS FROM ");
/* 2396 */                 fullColumnQueryBuf.append(StringUtils.quoteIdentifier(tableName, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */                 
/* 2398 */                 fullColumnQueryBuf.append(" FROM ");
/* 2399 */                 fullColumnQueryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */                 
/*      */ 
/* 2402 */                 results = stmt.executeQuery(fullColumnQueryBuf.toString());
/*      */                 
/* 2404 */                 ordinalFixUpMap = new HashMap();
/*      */                 
/* 2406 */                 int fullOrdinalPos = 1;
/*      */                 
/* 2408 */                 while (results.next()) {
/* 2409 */                   String fullOrdColName = results.getString("Field");
/*      */                   
/* 2411 */                   ((Map)ordinalFixUpMap).put(fullOrdColName, Integer.valueOf(fullOrdinalPos++));
/*      */                 }
/*      */               }
/*      */               
/* 2415 */               results = stmt.executeQuery(queryBuf.toString());
/*      */               
/* 2417 */               int ordPos = 1;
/*      */               
/* 2419 */               while (results.next()) {
/* 2420 */                 byte[][] rowVal = new byte[24][];
/* 2421 */                 rowVal[0] = DatabaseMetaData.this.s2b(catalogStr);
/* 2422 */                 rowVal[1] = null;
/*      */                 
/*      */ 
/* 2425 */                 rowVal[2] = DatabaseMetaData.this.s2b(tableName);
/* 2426 */                 rowVal[3] = results.getBytes("Field");
/*      */                 
/* 2428 */                 DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(DatabaseMetaData.this, results.getString("Type"), results.getString("Null"));
/*      */                 
/* 2430 */                 rowVal[4] = Short.toString(typeDesc.dataType).getBytes();
/*      */                 
/*      */ 
/* 2433 */                 rowVal[5] = DatabaseMetaData.this.s2b(typeDesc.typeName);
/*      */                 
/* 2435 */                 if (typeDesc.columnSize == null) {
/* 2436 */                   rowVal[6] = null;
/*      */                 } else {
/* 2438 */                   String collation = results.getString("Collation");
/* 2439 */                   int mbminlen = 1;
/* 2440 */                   if ((collation != null) && (("TEXT".equals(typeDesc.typeName)) || ("TINYTEXT".equals(typeDesc.typeName)) || ("MEDIUMTEXT".equals(typeDesc.typeName))))
/*      */                   {
/*      */ 
/* 2443 */                     if ((collation.indexOf("ucs2") > -1) || (collation.indexOf("utf16") > -1)) {
/* 2444 */                       mbminlen = 2;
/* 2445 */                     } else if (collation.indexOf("utf32") > -1) {
/* 2446 */                       mbminlen = 4;
/*      */                     }
/*      */                   }
/* 2449 */                   rowVal[6] = (mbminlen == 1 ? DatabaseMetaData.this.s2b(typeDesc.columnSize.toString()) : DatabaseMetaData.this.s2b(Integer.valueOf(typeDesc.columnSize.intValue() / mbminlen).toString()));
/*      */                 }
/*      */                 
/* 2452 */                 rowVal[7] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.bufferLength));
/* 2453 */                 rowVal[8] = (typeDesc.decimalDigits == null ? null : DatabaseMetaData.this.s2b(typeDesc.decimalDigits.toString()));
/* 2454 */                 rowVal[9] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.numPrecRadix));
/* 2455 */                 rowVal[10] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.nullability));
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 try
/*      */                 {
/* 2464 */                   if (DatabaseMetaData.this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2465 */                     rowVal[11] = results.getBytes("Comment");
/*      */                   } else {
/* 2467 */                     rowVal[11] = results.getBytes("Extra");
/*      */                   }
/*      */                 } catch (Exception E) {
/* 2470 */                   rowVal[11] = new byte[0];
/*      */                 }
/*      */                 
/*      */ 
/* 2474 */                 rowVal[12] = results.getBytes("Default");
/*      */                 
/* 2476 */                 rowVal[13] = { 48 };
/* 2477 */                 rowVal[14] = { 48 };
/*      */                 
/* 2479 */                 if ((StringUtils.indexOfIgnoreCase(typeDesc.typeName, "CHAR") != -1) || (StringUtils.indexOfIgnoreCase(typeDesc.typeName, "BLOB") != -1) || (StringUtils.indexOfIgnoreCase(typeDesc.typeName, "TEXT") != -1) || (StringUtils.indexOfIgnoreCase(typeDesc.typeName, "BINARY") != -1))
/*      */                 {
/*      */ 
/*      */ 
/* 2483 */                   rowVal[15] = rowVal[6];
/*      */                 } else {
/* 2485 */                   rowVal[15] = null;
/*      */                 }
/*      */                 
/*      */ 
/* 2489 */                 if (!fixUpOrdinalsRequired) {
/* 2490 */                   rowVal[16] = Integer.toString(ordPos++).getBytes();
/*      */                 } else {
/* 2492 */                   String origColName = results.getString("Field");
/* 2493 */                   Integer realOrdinal = (Integer)((Map)ordinalFixUpMap).get(origColName);
/*      */                   
/* 2495 */                   if (realOrdinal != null) {
/* 2496 */                     rowVal[16] = realOrdinal.toString().getBytes();
/*      */                   } else {
/* 2498 */                     throw SQLError.createSQLException("Can not find column in full column list to determine true ordinal position.", "S1000", DatabaseMetaData.this.getExceptionInterceptor());
/*      */                   }
/*      */                 }
/*      */                 
/*      */ 
/* 2503 */                 rowVal[17] = DatabaseMetaData.this.s2b(typeDesc.isNullable);
/*      */                 
/*      */ 
/* 2506 */                 rowVal[18] = null;
/* 2507 */                 rowVal[19] = null;
/* 2508 */                 rowVal[20] = null;
/* 2509 */                 rowVal[21] = null;
/*      */                 
/* 2511 */                 rowVal[22] = DatabaseMetaData.this.s2b("");
/*      */                 
/* 2513 */                 String extra = results.getString("Extra");
/*      */                 
/* 2515 */                 if (extra != null) {
/* 2516 */                   rowVal[22] = DatabaseMetaData.this.s2b(StringUtils.indexOfIgnoreCase(extra, "auto_increment") != -1 ? "YES" : "NO");
/*      */                 }
/* 2518 */                 rowVal[23] = DatabaseMetaData.this.s2b("");
/*      */                 
/* 2520 */                 rows.add(new ByteArrayRow(rowVal, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             } finally {
/* 2523 */               if (results != null) {
/*      */                 try {
/* 2525 */                   results.close();
/*      */                 }
/*      */                 catch (Exception ex) {}
/*      */                 
/* 2529 */                 results = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     } finally {
/* 2536 */       if (stmt != null) {
/* 2537 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 2541 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 2543 */     return results;
/*      */   }
/*      */   
/*      */   protected Field[] createColumnsFields() {
/* 2547 */     Field[] fields = new Field[24];
/* 2548 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 2549 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 2550 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 2551 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 2552 */     fields[4] = new Field("", "DATA_TYPE", 4, 5);
/* 2553 */     fields[5] = new Field("", "TYPE_NAME", 1, 16);
/* 2554 */     fields[6] = new Field("", "COLUMN_SIZE", 4, Integer.toString(Integer.MAX_VALUE).length());
/* 2555 */     fields[7] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 2556 */     fields[8] = new Field("", "DECIMAL_DIGITS", 4, 10);
/* 2557 */     fields[9] = new Field("", "NUM_PREC_RADIX", 4, 10);
/* 2558 */     fields[10] = new Field("", "NULLABLE", 4, 10);
/* 2559 */     fields[11] = new Field("", "REMARKS", 1, 0);
/* 2560 */     fields[12] = new Field("", "COLUMN_DEF", 1, 0);
/* 2561 */     fields[13] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 2562 */     fields[14] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 2563 */     fields[15] = new Field("", "CHAR_OCTET_LENGTH", 4, Integer.toString(Integer.MAX_VALUE).length());
/* 2564 */     fields[16] = new Field("", "ORDINAL_POSITION", 4, 10);
/* 2565 */     fields[17] = new Field("", "IS_NULLABLE", 1, 3);
/* 2566 */     fields[18] = new Field("", "SCOPE_CATALOG", 1, 255);
/* 2567 */     fields[19] = new Field("", "SCOPE_SCHEMA", 1, 255);
/* 2568 */     fields[20] = new Field("", "SCOPE_TABLE", 1, 255);
/* 2569 */     fields[21] = new Field("", "SOURCE_DATA_TYPE", 5, 10);
/* 2570 */     fields[22] = new Field("", "IS_AUTOINCREMENT", 1, 3);
/* 2571 */     fields[23] = new Field("", "IS_GENERATEDCOLUMN", 1, 3);
/* 2572 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 2583 */     return this.conn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCrossReference(final String primaryCatalog, final String primarySchema, final String primaryTable, final String foreignCatalog, final String foreignSchema, final String foreignTable)
/*      */     throws SQLException
/*      */   {
/* 2642 */     if (primaryTable == null) {
/* 2643 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 2646 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 2648 */     final ArrayList<ResultSetRow> tuples = new ArrayList();
/*      */     
/* 2650 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 2652 */       final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       
/*      */       try
/*      */       {
/* 2656 */         new IterateBlock(getCatalogIterator(foreignCatalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException
/*      */           {
/* 2660 */             ResultSet fkresults = null;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/* 2667 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50)) {
/* 2668 */                 fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr, null);
/*      */               } else {
/* 2670 */                 StringBuilder queryBuf = new StringBuilder("SHOW TABLE STATUS FROM ");
/* 2671 */                 queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */                 
/*      */ 
/* 2674 */                 fkresults = stmt.executeQuery(queryBuf.toString());
/*      */               }
/*      */               
/* 2677 */               String foreignTableWithCase = DatabaseMetaData.this.getTableNameWithCase(foreignTable);
/* 2678 */               String primaryTableWithCase = DatabaseMetaData.this.getTableNameWithCase(primaryTable);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2686 */               while (fkresults.next()) {
/* 2687 */                 String tableType = fkresults.getString("Type");
/*      */                 
/* 2689 */                 if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK")))) {
/* 2690 */                   String comment = fkresults.getString("Comment").trim();
/*      */                   
/* 2692 */                   if (comment != null) {
/* 2693 */                     StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                     
/* 2695 */                     if (commentTokens.hasMoreTokens()) {
/* 2696 */                       String str1 = commentTokens.nextToken();
/*      */                     }
/*      */                     
/*      */ 
/*      */ 
/* 2701 */                     while (commentTokens.hasMoreTokens()) {
/* 2702 */                       String keys = commentTokens.nextToken();
/* 2703 */                       DatabaseMetaData.LocalAndReferencedColumns parsedInfo = DatabaseMetaData.this.parseTableStatusIntoLocalAndReferencedColumns(keys);
/*      */                       
/* 2705 */                       int keySeq = 0;
/*      */                       
/* 2707 */                       Iterator<String> referencingColumns = parsedInfo.localColumnsList.iterator();
/* 2708 */                       Iterator<String> referencedColumns = parsedInfo.referencedColumnsList.iterator();
/*      */                       
/* 2710 */                       while (referencingColumns.hasNext()) {
/* 2711 */                         String referencingColumn = StringUtils.unQuoteIdentifier((String)referencingColumns.next(), DatabaseMetaData.this.quotedId);
/*      */                         
/*      */ 
/*      */ 
/* 2715 */                         byte[][] tuple = new byte[14][];
/* 2716 */                         tuple[4] = (foreignCatalog == null ? null : DatabaseMetaData.this.s2b(foreignCatalog));
/* 2717 */                         tuple[5] = (foreignSchema == null ? null : DatabaseMetaData.this.s2b(foreignSchema));
/* 2718 */                         String dummy = fkresults.getString("Name");
/*      */                         
/* 2720 */                         if (dummy.compareTo(foreignTableWithCase) == 0)
/*      */                         {
/*      */ 
/*      */ 
/* 2724 */                           tuple[6] = DatabaseMetaData.this.s2b(dummy);
/*      */                           
/* 2726 */                           tuple[7] = DatabaseMetaData.this.s2b(referencingColumn);
/* 2727 */                           tuple[0] = (primaryCatalog == null ? null : DatabaseMetaData.this.s2b(primaryCatalog));
/* 2728 */                           tuple[1] = (primarySchema == null ? null : DatabaseMetaData.this.s2b(primarySchema));
/*      */                           
/*      */ 
/* 2731 */                           if (parsedInfo.referencedTable.compareTo(primaryTableWithCase) == 0)
/*      */                           {
/*      */ 
/*      */ 
/* 2735 */                             tuple[2] = DatabaseMetaData.this.s2b(parsedInfo.referencedTable);
/* 2736 */                             tuple[3] = DatabaseMetaData.this.s2b(StringUtils.unQuoteIdentifier((String)referencedColumns.next(), DatabaseMetaData.this.quotedId));
/* 2737 */                             tuple[8] = Integer.toString(keySeq).getBytes();
/*      */                             
/* 2739 */                             int[] actions = DatabaseMetaData.this.getForeignKeyActions(keys);
/*      */                             
/* 2741 */                             tuple[9] = Integer.toString(actions[1]).getBytes();
/* 2742 */                             tuple[10] = Integer.toString(actions[0]).getBytes();
/* 2743 */                             tuple[11] = null;
/* 2744 */                             tuple[12] = null;
/* 2745 */                             tuple[13] = Integer.toString(7).getBytes();
/* 2746 */                             tuples.add(new ByteArrayRow(tuple, DatabaseMetaData.this.getExceptionInterceptor()));
/* 2747 */                             keySeq++;
/*      */                           }
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/* 2755 */             } finally { if (fkresults != null) {
/*      */                 try {
/* 2757 */                   fkresults.close();
/*      */                 } catch (Exception sqlEx) {
/* 2759 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/* 2762 */                 fkresults = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }.doForAll();
/*      */       } finally {
/* 2768 */         if (stmt != null) {
/* 2769 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2774 */     ResultSet results = buildResultSet(fields, tuples);
/*      */     
/* 2776 */     return results;
/*      */   }
/*      */   
/*      */   protected Field[] createFkMetadataFields() {
/* 2780 */     Field[] fields = new Field[14];
/* 2781 */     fields[0] = new Field("", "PKTABLE_CAT", 1, 255);
/* 2782 */     fields[1] = new Field("", "PKTABLE_SCHEM", 1, 0);
/* 2783 */     fields[2] = new Field("", "PKTABLE_NAME", 1, 255);
/* 2784 */     fields[3] = new Field("", "PKCOLUMN_NAME", 1, 32);
/* 2785 */     fields[4] = new Field("", "FKTABLE_CAT", 1, 255);
/* 2786 */     fields[5] = new Field("", "FKTABLE_SCHEM", 1, 0);
/* 2787 */     fields[6] = new Field("", "FKTABLE_NAME", 1, 255);
/* 2788 */     fields[7] = new Field("", "FKCOLUMN_NAME", 1, 32);
/* 2789 */     fields[8] = new Field("", "KEY_SEQ", 5, 2);
/* 2790 */     fields[9] = new Field("", "UPDATE_RULE", 5, 2);
/* 2791 */     fields[10] = new Field("", "DELETE_RULE", 5, 2);
/* 2792 */     fields[11] = new Field("", "FK_NAME", 1, 0);
/* 2793 */     fields[12] = new Field("", "PK_NAME", 1, 0);
/* 2794 */     fields[13] = new Field("", "DEFERRABILITY", 5, 2);
/* 2795 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getDatabaseMajorVersion()
/*      */     throws SQLException
/*      */   {
/* 2802 */     return this.conn.getServerMajorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getDatabaseMinorVersion()
/*      */     throws SQLException
/*      */   {
/* 2809 */     return this.conn.getServerMinorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDatabaseProductName()
/*      */     throws SQLException
/*      */   {
/* 2819 */     return "MySQL";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDatabaseProductVersion()
/*      */     throws SQLException
/*      */   {
/* 2829 */     return this.conn.getServerVersion();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDefaultTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/* 2842 */     if (this.conn.supportsIsolationLevel()) {
/* 2843 */       return 2;
/*      */     }
/*      */     
/* 2846 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDriverMajorVersion()
/*      */   {
/* 2855 */     return NonRegisteringDriver.getMajorVersionInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDriverMinorVersion()
/*      */   {
/* 2864 */     return NonRegisteringDriver.getMinorVersionInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDriverName()
/*      */     throws SQLException
/*      */   {
/* 2874 */     return "MySQL Connector Java";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDriverVersion()
/*      */     throws SQLException
/*      */   {
/* 2884 */     return "mysql-connector-java-5.1.36 ( Revision: 4fc1f969f740409a4e03750316df2c0e429f3dc8 )";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getExportedKeys(String catalog, String schema, final String table)
/*      */     throws SQLException
/*      */   {
/* 2934 */     if (table == null) {
/* 2935 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 2938 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 2940 */     final ArrayList<ResultSetRow> rows = new ArrayList();
/*      */     
/* 2942 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 2944 */       final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       
/*      */       try
/*      */       {
/* 2948 */         new IterateBlock(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException {
/* 2951 */             ResultSet fkresults = null;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/* 2958 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50))
/*      */               {
/*      */ 
/* 2961 */                 fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr, null);
/*      */               } else {
/* 2963 */                 StringBuilder queryBuf = new StringBuilder("SHOW TABLE STATUS FROM ");
/* 2964 */                 queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */                 
/*      */ 
/* 2967 */                 fkresults = stmt.executeQuery(queryBuf.toString());
/*      */               }
/*      */               
/*      */ 
/* 2971 */               String tableNameWithCase = DatabaseMetaData.this.getTableNameWithCase(table);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2977 */               while (fkresults.next()) {
/* 2978 */                 String tableType = fkresults.getString("Type");
/*      */                 
/* 2980 */                 if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK")))) {
/* 2981 */                   String comment = fkresults.getString("Comment").trim();
/*      */                   
/* 2983 */                   if (comment != null) {
/* 2984 */                     StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                     
/* 2986 */                     if (commentTokens.hasMoreTokens()) {
/* 2987 */                       commentTokens.nextToken();
/*      */                       
/*      */ 
/*      */ 
/* 2991 */                       while (commentTokens.hasMoreTokens()) {
/* 2992 */                         String keys = commentTokens.nextToken();
/* 2993 */                         DatabaseMetaData.this.getExportKeyResults(catalogStr, tableNameWithCase, keys, rows, fkresults.getString("Name"));
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */             finally {
/* 3001 */               if (fkresults != null) {
/*      */                 try {
/* 3003 */                   fkresults.close();
/*      */                 } catch (SQLException sqlEx) {
/* 3005 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/* 3008 */                 fkresults = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }.doForAll();
/*      */       } finally {
/* 3014 */         if (stmt != null) {
/* 3015 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3020 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3022 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void getExportKeyResults(String catalog, String exportingTable, String keysComment, List<ResultSetRow> tuples, String fkTableName)
/*      */     throws SQLException
/*      */   {
/* 3045 */     getResultsImpl(catalog, exportingTable, keysComment, tuples, fkTableName, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getExtraNameCharacters()
/*      */     throws SQLException
/*      */   {
/* 3056 */     return "#@";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int[] getForeignKeyActions(String commentString)
/*      */   {
/* 3069 */     int[] actions = { 3, 3 };
/*      */     
/* 3071 */     int lastParenIndex = commentString.lastIndexOf(")");
/*      */     
/* 3073 */     if (lastParenIndex != commentString.length() - 1) {
/* 3074 */       String cascadeOptions = commentString.substring(lastParenIndex + 1).trim().toUpperCase(Locale.ENGLISH);
/*      */       
/* 3076 */       actions[0] = getCascadeDeleteOption(cascadeOptions);
/* 3077 */       actions[1] = getCascadeUpdateOption(cascadeOptions);
/*      */     }
/*      */     
/* 3080 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIdentifierQuoteString()
/*      */     throws SQLException
/*      */   {
/* 3092 */     if (this.conn.supportsQuotedIdentifiers()) {
/* 3093 */       return this.conn.useAnsiQuotedIdentifiers() ? "\"" : "`";
/*      */     }
/*      */     
/*      */ 
/* 3097 */     return " ";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getImportedKeys(String catalog, String schema, final String table)
/*      */     throws SQLException
/*      */   {
/* 3147 */     if (table == null) {
/* 3148 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 3151 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 3153 */     final ArrayList<ResultSetRow> rows = new ArrayList();
/*      */     
/* 3155 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 3157 */       final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       
/*      */       try
/*      */       {
/* 3161 */         new IterateBlock(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException {
/* 3164 */             ResultSet fkresults = null;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/* 3171 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50))
/*      */               {
/*      */ 
/* 3174 */                 fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr, table);
/*      */               } else {
/* 3176 */                 StringBuilder queryBuf = new StringBuilder("SHOW TABLE STATUS ");
/* 3177 */                 queryBuf.append(" FROM ");
/* 3178 */                 queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */                 
/* 3180 */                 queryBuf.append(" LIKE ");
/* 3181 */                 queryBuf.append(StringUtils.quoteIdentifier(table, "'", true));
/*      */                 
/* 3183 */                 fkresults = stmt.executeQuery(queryBuf.toString());
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3190 */               while (fkresults.next()) {
/* 3191 */                 String tableType = fkresults.getString("Type");
/*      */                 
/* 3193 */                 if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK")))) {
/* 3194 */                   String comment = fkresults.getString("Comment").trim();
/*      */                   
/* 3196 */                   if (comment != null) {
/* 3197 */                     StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                     
/* 3199 */                     if (commentTokens.hasMoreTokens()) {
/* 3200 */                       commentTokens.nextToken();
/*      */                       
/* 3202 */                       while (commentTokens.hasMoreTokens()) {
/* 3203 */                         String keys = commentTokens.nextToken();
/* 3204 */                         DatabaseMetaData.this.getImportKeyResults(catalogStr, table, keys, rows);
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             } finally {
/* 3211 */               if (fkresults != null) {
/*      */                 try {
/* 3213 */                   fkresults.close();
/*      */                 } catch (SQLException sqlEx) {
/* 3215 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/* 3218 */                 fkresults = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }.doForAll();
/*      */       } finally {
/* 3224 */         if (stmt != null) {
/* 3225 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3230 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3232 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void getImportKeyResults(String catalog, String importingTable, String keysComment, List<ResultSetRow> tuples)
/*      */     throws SQLException
/*      */   {
/* 3253 */     getResultsImpl(catalog, importingTable, keysComment, tuples, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getIndexInfo(String catalog, String schema, final String table, final boolean unique, boolean approximate)
/*      */     throws SQLException
/*      */   {
/* 3308 */     Field[] fields = createIndexInfoFields();
/*      */     
/* 3310 */     final SortedMap<IndexMetaDataKey, ResultSetRow> sortedRows = new TreeMap();
/* 3311 */     ArrayList<ResultSetRow> rows = new ArrayList();
/* 3312 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 3316 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(String catalogStr) throws SQLException
/*      */         {
/* 3320 */           ResultSet results = null;
/*      */           try
/*      */           {
/* 3323 */             StringBuilder queryBuf = new StringBuilder("SHOW INDEX FROM ");
/* 3324 */             queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 3325 */             queryBuf.append(" FROM ");
/* 3326 */             queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */             try
/*      */             {
/* 3329 */               results = stmt.executeQuery(queryBuf.toString());
/*      */             } catch (SQLException sqlEx) {
/* 3331 */               int errorCode = sqlEx.getErrorCode();
/*      */               
/*      */ 
/* 3334 */               if (!"42S02".equals(sqlEx.getSQLState()))
/*      */               {
/* 3336 */                 if (errorCode != 1146) {
/* 3337 */                   throw sqlEx;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 3342 */             while ((results != null) && (results.next())) {
/* 3343 */               byte[][] row = new byte[14][];
/* 3344 */               row[0] = (catalogStr == null ? new byte[0] : DatabaseMetaData.this.s2b(catalogStr));
/* 3345 */               row[1] = null;
/* 3346 */               row[2] = results.getBytes("Table");
/*      */               
/* 3348 */               boolean indexIsUnique = results.getInt("Non_unique") == 0;
/*      */               
/* 3350 */               row[3] = (!indexIsUnique ? DatabaseMetaData.this.s2b("true") : DatabaseMetaData.this.s2b("false"));
/* 3351 */               row[4] = new byte[0];
/* 3352 */               row[5] = results.getBytes("Key_name");
/* 3353 */               short indexType = 3;
/* 3354 */               row[6] = Integer.toString(indexType).getBytes();
/* 3355 */               row[7] = results.getBytes("Seq_in_index");
/* 3356 */               row[8] = results.getBytes("Column_name");
/* 3357 */               row[9] = results.getBytes("Collation");
/*      */               
/*      */ 
/* 3360 */               long cardinality = results.getLong("Cardinality");
/*      */               
/* 3362 */               if (cardinality > 2147483647L) {
/* 3363 */                 cardinality = 2147483647L;
/*      */               }
/*      */               
/* 3366 */               row[10] = DatabaseMetaData.this.s2b(String.valueOf(cardinality));
/* 3367 */               row[11] = DatabaseMetaData.this.s2b("0");
/* 3368 */               row[12] = null;
/*      */               
/* 3370 */               DatabaseMetaData.IndexMetaDataKey indexInfoKey = new DatabaseMetaData.IndexMetaDataKey(DatabaseMetaData.this, !indexIsUnique, indexType, results.getString("Key_name").toLowerCase(), results.getShort("Seq_in_index"));
/*      */               
/*      */ 
/* 3373 */               if (unique) {
/* 3374 */                 if (indexIsUnique) {
/* 3375 */                   sortedRows.put(indexInfoKey, new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                 }
/*      */               }
/*      */               else {
/* 3379 */                 sortedRows.put(indexInfoKey, new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             }
/*      */           } finally {
/* 3383 */             if (results != null) {
/*      */               try {
/* 3385 */                 results.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/* 3389 */               results = null;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/* 3394 */       }.doForAll();
/* 3395 */       Iterator<ResultSetRow> sortedRowsIterator = sortedRows.values().iterator();
/* 3396 */       while (sortedRowsIterator.hasNext()) {
/* 3397 */         rows.add(sortedRowsIterator.next());
/*      */       }
/*      */       
/* 3400 */       ResultSet indexInfo = buildResultSet(fields, rows);
/*      */       
/* 3402 */       return indexInfo;
/*      */     } finally {
/* 3404 */       if (stmt != null) {
/* 3405 */         stmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected Field[] createIndexInfoFields() {
/* 3411 */     Field[] fields = new Field[13];
/* 3412 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3413 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3414 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3415 */     fields[3] = new Field("", "NON_UNIQUE", 16, 4);
/* 3416 */     fields[4] = new Field("", "INDEX_QUALIFIER", 1, 1);
/* 3417 */     fields[5] = new Field("", "INDEX_NAME", 1, 32);
/* 3418 */     fields[6] = new Field("", "TYPE", 5, 32);
/* 3419 */     fields[7] = new Field("", "ORDINAL_POSITION", 5, 5);
/* 3420 */     fields[8] = new Field("", "COLUMN_NAME", 1, 32);
/* 3421 */     fields[9] = new Field("", "ASC_OR_DESC", 1, 1);
/* 3422 */     fields[10] = new Field("", "CARDINALITY", 4, 20);
/* 3423 */     fields[11] = new Field("", "PAGES", 4, 10);
/* 3424 */     fields[12] = new Field("", "FILTER_CONDITION", 1, 32);
/* 3425 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getJDBCMajorVersion()
/*      */     throws SQLException
/*      */   {
/* 3432 */     return 4;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getJDBCMinorVersion()
/*      */     throws SQLException
/*      */   {
/* 3439 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxBinaryLiteralLength()
/*      */     throws SQLException
/*      */   {
/* 3449 */     return 16777208;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCatalogNameLength()
/*      */     throws SQLException
/*      */   {
/* 3459 */     return 32;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCharLiteralLength()
/*      */     throws SQLException
/*      */   {
/* 3469 */     return 16777208;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnNameLength()
/*      */     throws SQLException
/*      */   {
/* 3479 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInGroupBy()
/*      */     throws SQLException
/*      */   {
/* 3489 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInIndex()
/*      */     throws SQLException
/*      */   {
/* 3499 */     return 16;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInOrderBy()
/*      */     throws SQLException
/*      */   {
/* 3509 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInSelect()
/*      */     throws SQLException
/*      */   {
/* 3519 */     return 256;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInTable()
/*      */     throws SQLException
/*      */   {
/* 3529 */     return 512;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxConnections()
/*      */     throws SQLException
/*      */   {
/* 3539 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCursorNameLength()
/*      */     throws SQLException
/*      */   {
/* 3549 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxIndexLength()
/*      */     throws SQLException
/*      */   {
/* 3559 */     return 256;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxProcedureNameLength()
/*      */     throws SQLException
/*      */   {
/* 3569 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxRowSize()
/*      */     throws SQLException
/*      */   {
/* 3579 */     return 2147483639;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxSchemaNameLength()
/*      */     throws SQLException
/*      */   {
/* 3589 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxStatementLength()
/*      */     throws SQLException
/*      */   {
/* 3599 */     return MysqlIO.getMaxBuf() - 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxStatements()
/*      */     throws SQLException
/*      */   {
/* 3609 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxTableNameLength()
/*      */     throws SQLException
/*      */   {
/* 3619 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxTablesInSelect()
/*      */     throws SQLException
/*      */   {
/* 3629 */     return 256;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxUserNameLength()
/*      */     throws SQLException
/*      */   {
/* 3639 */     return 16;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNumericFunctions()
/*      */     throws SQLException
/*      */   {
/* 3649 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,BIT_COUNT,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MAX,MIN,MOD,PI,POW,POWER,RADIANS,RAND,ROUND,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getPrimaryKeys(String catalog, String schema, final String table)
/*      */     throws SQLException
/*      */   {
/* 3678 */     Field[] fields = new Field[6];
/* 3679 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3680 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3681 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3682 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 3683 */     fields[4] = new Field("", "KEY_SEQ", 5, 5);
/* 3684 */     fields[5] = new Field("", "PK_NAME", 1, 32);
/*      */     
/* 3686 */     if (table == null) {
/* 3687 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 3690 */     final ArrayList<ResultSetRow> rows = new ArrayList();
/* 3691 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 3695 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(String catalogStr) throws SQLException {
/* 3698 */           ResultSet rs = null;
/*      */           
/*      */           try
/*      */           {
/* 3702 */             StringBuilder queryBuf = new StringBuilder("SHOW KEYS FROM ");
/* 3703 */             queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 3704 */             queryBuf.append(" FROM ");
/* 3705 */             queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */             
/* 3707 */             rs = stmt.executeQuery(queryBuf.toString());
/*      */             
/* 3709 */             TreeMap<String, byte[][]> sortMap = new TreeMap();
/*      */             
/* 3711 */             while (rs.next()) {
/* 3712 */               String keyType = rs.getString("Key_name");
/*      */               
/* 3714 */               if ((keyType != null) && (
/* 3715 */                 (keyType.equalsIgnoreCase("PRIMARY")) || (keyType.equalsIgnoreCase("PRI")))) {
/* 3716 */                 byte[][] tuple = new byte[6][];
/* 3717 */                 tuple[0] = (catalogStr == null ? new byte[0] : DatabaseMetaData.this.s2b(catalogStr));
/* 3718 */                 tuple[1] = null;
/* 3719 */                 tuple[2] = DatabaseMetaData.this.s2b(table);
/*      */                 
/* 3721 */                 String columnName = rs.getString("Column_name");
/* 3722 */                 tuple[3] = DatabaseMetaData.this.s2b(columnName);
/* 3723 */                 tuple[4] = DatabaseMetaData.this.s2b(rs.getString("Seq_in_index"));
/* 3724 */                 tuple[5] = DatabaseMetaData.this.s2b(keyType);
/* 3725 */                 sortMap.put(columnName, tuple);
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 3731 */             Iterator<byte[][]> sortedIterator = sortMap.values().iterator();
/*      */             
/* 3733 */             while (sortedIterator.hasNext()) {
/* 3734 */               rows.add(new ByteArrayRow((byte[][])sortedIterator.next(), DatabaseMetaData.this.getExceptionInterceptor()));
/*      */             }
/*      */           }
/*      */           finally {
/* 3738 */             if (rs != null) {
/*      */               try {
/* 3740 */                 rs.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/* 3744 */               rs = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     } finally {
/* 3750 */       if (stmt != null) {
/* 3751 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 3755 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3757 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 3833 */     Field[] fields = createProcedureColumnsFields();
/*      */     
/* 3835 */     return getProcedureOrFunctionColumns(fields, catalog, schemaPattern, procedureNamePattern, columnNamePattern, true, true);
/*      */   }
/*      */   
/*      */   protected Field[] createProcedureColumnsFields() {
/* 3839 */     Field[] fields = new Field[20];
/*      */     
/* 3841 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 512);
/* 3842 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 512);
/* 3843 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 512);
/* 3844 */     fields[3] = new Field("", "COLUMN_NAME", 1, 512);
/* 3845 */     fields[4] = new Field("", "COLUMN_TYPE", 1, 64);
/* 3846 */     fields[5] = new Field("", "DATA_TYPE", 5, 6);
/* 3847 */     fields[6] = new Field("", "TYPE_NAME", 1, 64);
/* 3848 */     fields[7] = new Field("", "PRECISION", 4, 12);
/* 3849 */     fields[8] = new Field("", "LENGTH", 4, 12);
/* 3850 */     fields[9] = new Field("", "SCALE", 5, 12);
/* 3851 */     fields[10] = new Field("", "RADIX", 5, 6);
/* 3852 */     fields[11] = new Field("", "NULLABLE", 5, 6);
/* 3853 */     fields[12] = new Field("", "REMARKS", 1, 512);
/* 3854 */     fields[13] = new Field("", "COLUMN_DEF", 1, 512);
/* 3855 */     fields[14] = new Field("", "SQL_DATA_TYPE", 4, 12);
/* 3856 */     fields[15] = new Field("", "SQL_DATETIME_SUB", 4, 12);
/* 3857 */     fields[16] = new Field("", "CHAR_OCTET_LENGTH", 4, 12);
/* 3858 */     fields[17] = new Field("", "ORDINAL_POSITION", 4, 12);
/* 3859 */     fields[18] = new Field("", "IS_NULLABLE", 1, 512);
/* 3860 */     fields[19] = new Field("", "SPECIFIC_NAME", 1, 512);
/* 3861 */     return fields;
/*      */   }
/*      */   
/*      */   protected ResultSet getProcedureOrFunctionColumns(Field[] fields, String catalog, String schemaPattern, String procedureOrFunctionNamePattern, String columnNamePattern, boolean returnProcedures, boolean returnFunctions)
/*      */     throws SQLException
/*      */   {
/* 3867 */     List<ComparableWrapper<String, ProcedureType>> procsOrFuncsToExtractList = new ArrayList();
/*      */     
/* 3869 */     ResultSet procsAndOrFuncsRs = null;
/*      */     
/* 3871 */     if (supportsStoredProcedures()) {
/*      */       try
/*      */       {
/* 3874 */         String tmpProcedureOrFunctionNamePattern = null;
/*      */         
/* 3876 */         if ((procedureOrFunctionNamePattern != null) && (!procedureOrFunctionNamePattern.equals("%"))) {
/* 3877 */           tmpProcedureOrFunctionNamePattern = StringUtils.sanitizeProcOrFuncName(procedureOrFunctionNamePattern);
/*      */         }
/*      */         
/*      */ 
/* 3881 */         if (tmpProcedureOrFunctionNamePattern == null) {
/* 3882 */           tmpProcedureOrFunctionNamePattern = procedureOrFunctionNamePattern;
/*      */         }
/*      */         else
/*      */         {
/* 3886 */           String tmpCatalog = catalog;
/* 3887 */           List<String> parseList = StringUtils.splitDBdotName(tmpProcedureOrFunctionNamePattern, tmpCatalog, this.quotedId, this.conn.isNoBackslashEscapesSet());
/*      */           
/*      */ 
/*      */ 
/* 3891 */           if (parseList.size() == 2) {
/* 3892 */             tmpCatalog = (String)parseList.get(0);
/* 3893 */             tmpProcedureOrFunctionNamePattern = (String)parseList.get(1);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 3899 */         procsAndOrFuncsRs = getProceduresAndOrFunctions(createFieldMetadataForGetProcedures(), catalog, schemaPattern, tmpProcedureOrFunctionNamePattern, returnProcedures, returnFunctions);
/*      */         
/*      */ 
/* 3902 */         boolean hasResults = false;
/* 3903 */         while (procsAndOrFuncsRs.next()) {
/* 3904 */           procsOrFuncsToExtractList.add(new ComparableWrapper(getFullyQualifiedName(procsAndOrFuncsRs.getString(1), procsAndOrFuncsRs.getString(3)), procsAndOrFuncsRs.getShort(8) == 1 ? ProcedureType.PROCEDURE : ProcedureType.FUNCTION));
/*      */           
/* 3906 */           hasResults = true;
/*      */         }
/*      */         
/*      */ 
/* 3910 */         if (hasResults)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3917 */           Collections.sort(procsOrFuncsToExtractList);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 3924 */         SQLException rethrowSqlEx = null;
/*      */         
/* 3926 */         if (procsAndOrFuncsRs != null) {
/*      */           try {
/* 3928 */             procsAndOrFuncsRs.close();
/*      */           } catch (SQLException sqlEx) {
/* 3930 */             rethrowSqlEx = sqlEx;
/*      */           }
/*      */         }
/*      */         
/* 3934 */         if (rethrowSqlEx != null) {
/* 3935 */           throw rethrowSqlEx;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3940 */     ArrayList<ResultSetRow> resultRows = new ArrayList();
/* 3941 */     int idx = 0;
/* 3942 */     String procNameToCall = "";
/*      */     
/* 3944 */     for (Object procOrFunc : procsOrFuncsToExtractList) {
/* 3945 */       String procName = (String)((ComparableWrapper)procOrFunc).getKey();
/* 3946 */       ProcedureType procType = (ProcedureType)((ComparableWrapper)procOrFunc).getValue();
/*      */       
/*      */ 
/* 3949 */       if (!" ".equals(this.quotedId)) {
/* 3950 */         idx = StringUtils.indexOfIgnoreCase(0, procName, ".", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */       }
/*      */       else {
/* 3953 */         idx = procName.indexOf(".");
/*      */       }
/*      */       
/* 3956 */       if (idx > 0) {
/* 3957 */         catalog = StringUtils.unQuoteIdentifier(procName.substring(0, idx), this.quotedId);
/* 3958 */         procNameToCall = procName;
/*      */       }
/*      */       else {
/* 3961 */         procNameToCall = procName;
/*      */       }
/* 3963 */       getCallStmtParameterTypes(catalog, procNameToCall, procType, columnNamePattern, resultRows, fields.length == 17);
/*      */     }
/*      */     
/* 3966 */     return buildResultSet(fields, resultRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern)
/*      */     throws SQLException
/*      */   {
/* 4006 */     Field[] fields = createFieldMetadataForGetProcedures();
/*      */     
/* 4008 */     return getProceduresAndOrFunctions(fields, catalog, schemaPattern, procedureNamePattern, true, true);
/*      */   }
/*      */   
/*      */   protected Field[] createFieldMetadataForGetProcedures() {
/* 4012 */     Field[] fields = new Field[9];
/* 4013 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 255);
/* 4014 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 255);
/* 4015 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 255);
/* 4016 */     fields[3] = new Field("", "reserved1", 1, 0);
/* 4017 */     fields[4] = new Field("", "reserved2", 1, 0);
/* 4018 */     fields[5] = new Field("", "reserved3", 1, 0);
/* 4019 */     fields[6] = new Field("", "REMARKS", 1, 255);
/* 4020 */     fields[7] = new Field("", "PROCEDURE_TYPE", 5, 6);
/* 4021 */     fields[8] = new Field("", "SPECIFIC_NAME", 1, 255);
/*      */     
/* 4023 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSet getProceduresAndOrFunctions(final Field[] fields, String catalog, String schemaPattern, String procedureNamePattern, final boolean returnProcedures, final boolean returnFunctions)
/*      */     throws SQLException
/*      */   {
/* 4037 */     if ((procedureNamePattern == null) || (procedureNamePattern.length() == 0)) {
/* 4038 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4039 */         procedureNamePattern = "%";
/*      */       } else {
/* 4041 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4046 */     ArrayList<ResultSetRow> procedureRows = new ArrayList();
/*      */     
/* 4048 */     if (supportsStoredProcedures()) {
/* 4049 */       final String procNamePattern = procedureNamePattern;
/*      */       
/* 4051 */       final List<ComparableWrapper<String, ResultSetRow>> procedureRowsToSort = new ArrayList();
/*      */       
/* 4053 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(String catalogStr) throws SQLException {
/* 4056 */           String db = catalogStr;
/*      */           
/* 4058 */           boolean fromSelect = false;
/* 4059 */           ResultSet proceduresRs = null;
/* 4060 */           boolean needsClientFiltering = true;
/*      */           
/* 4062 */           StringBuilder selectFromMySQLProcSQL = new StringBuilder();
/*      */           
/* 4064 */           selectFromMySQLProcSQL.append("SELECT name, type, comment FROM mysql.proc WHERE ");
/* 4065 */           if ((returnProcedures) && (!returnFunctions)) {
/* 4066 */             selectFromMySQLProcSQL.append("type = 'PROCEDURE' and ");
/* 4067 */           } else if ((!returnProcedures) && (returnFunctions)) {
/* 4068 */             selectFromMySQLProcSQL.append("type = 'FUNCTION' and ");
/*      */           }
/* 4070 */           selectFromMySQLProcSQL.append("name like ? and db <=> ? ORDER BY name, type");
/*      */           
/* 4072 */           PreparedStatement proceduresStmt = DatabaseMetaData.this.prepareMetaDataSafeStatement(selectFromMySQLProcSQL.toString());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/* 4079 */             boolean hasTypeColumn = false;
/*      */             
/* 4081 */             if (db != null) {
/* 4082 */               if (DatabaseMetaData.this.conn.lowerCaseTableNames()) {
/* 4083 */                 db = db.toLowerCase();
/*      */               }
/* 4085 */               proceduresStmt.setString(2, db);
/*      */             } else {
/* 4087 */               proceduresStmt.setNull(2, 12);
/*      */             }
/*      */             
/* 4090 */             int nameIndex = 1;
/*      */             
/* 4092 */             proceduresStmt.setString(1, procNamePattern);
/*      */             try
/*      */             {
/* 4095 */               proceduresRs = proceduresStmt.executeQuery();
/* 4096 */               fromSelect = true;
/* 4097 */               needsClientFiltering = false;
/* 4098 */               hasTypeColumn = true;
/*      */ 
/*      */             }
/*      */             catch (SQLException sqlEx)
/*      */             {
/*      */ 
/* 4104 */               proceduresStmt.close();
/*      */               
/* 4106 */               fromSelect = false;
/*      */               
/* 4108 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 1)) {
/* 4109 */                 nameIndex = 2;
/*      */               } else {
/* 4111 */                 nameIndex = 1;
/*      */               }
/*      */               
/* 4114 */               proceduresStmt = DatabaseMetaData.this.prepareMetaDataSafeStatement("SHOW PROCEDURE STATUS LIKE ?");
/*      */               
/* 4116 */               proceduresStmt.setString(1, procNamePattern);
/*      */               
/* 4118 */               proceduresRs = proceduresStmt.executeQuery();
/*      */             }
/*      */             
/* 4121 */             if (returnProcedures) {
/* 4122 */               DatabaseMetaData.this.convertToJdbcProcedureList(fromSelect, db, proceduresRs, needsClientFiltering, db, procedureRowsToSort, nameIndex);
/*      */             }
/*      */             
/* 4125 */             if (!hasTypeColumn)
/*      */             {
/* 4127 */               if (proceduresStmt != null) {
/* 4128 */                 proceduresStmt.close();
/*      */               }
/*      */               
/* 4131 */               proceduresStmt = DatabaseMetaData.this.prepareMetaDataSafeStatement("SHOW FUNCTION STATUS LIKE ?");
/*      */               
/* 4133 */               proceduresStmt.setString(1, procNamePattern);
/*      */               
/* 4135 */               proceduresRs = proceduresStmt.executeQuery();
/*      */             }
/*      */             
/*      */ 
/* 4139 */             if (returnFunctions) {
/* 4140 */               DatabaseMetaData.this.convertToJdbcFunctionList(db, proceduresRs, needsClientFiltering, db, procedureRowsToSort, nameIndex, fields);
/*      */             }
/*      */           }
/*      */           finally {
/* 4144 */             SQLException rethrowSqlEx = null;
/*      */             
/* 4146 */             if (proceduresRs != null) {
/*      */               try {
/* 4148 */                 proceduresRs.close();
/*      */               } catch (SQLException sqlEx) {
/* 4150 */                 rethrowSqlEx = sqlEx;
/*      */               }
/*      */             }
/*      */             
/* 4154 */             if (proceduresStmt != null) {
/*      */               try {
/* 4156 */                 proceduresStmt.close();
/*      */               } catch (SQLException sqlEx) {
/* 4158 */                 rethrowSqlEx = sqlEx;
/*      */               }
/*      */             }
/*      */             
/* 4162 */             if (rethrowSqlEx != null) {
/* 4163 */               throw rethrowSqlEx;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/* 4168 */       }.doForAll();
/* 4169 */       Collections.sort(procedureRowsToSort);
/* 4170 */       for (ComparableWrapper<String, ResultSetRow> procRow : procedureRowsToSort) {
/* 4171 */         procedureRows.add(procRow.getValue());
/*      */       }
/*      */     }
/*      */     
/* 4175 */     return buildResultSet(fields, procedureRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProcedureTerm()
/*      */     throws SQLException
/*      */   {
/* 4186 */     return "PROCEDURE";
/*      */   }
/*      */   
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 4193 */     return 1;
/*      */   }
/*      */   
/*      */   private void getResultsImpl(String catalog, String table, String keysComment, List<ResultSetRow> tuples, String fkTableName, boolean isExport)
/*      */     throws SQLException
/*      */   {
/* 4199 */     LocalAndReferencedColumns parsedInfo = parseTableStatusIntoLocalAndReferencedColumns(keysComment);
/*      */     
/* 4201 */     if ((isExport) && (!parsedInfo.referencedTable.equals(table))) {
/* 4202 */       return;
/*      */     }
/*      */     
/* 4205 */     if (parsedInfo.localColumnsList.size() != parsedInfo.referencedColumnsList.size()) {
/* 4206 */       throw SQLError.createSQLException("Error parsing foreign keys definition, number of local and referenced columns is not the same.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 4210 */     Iterator<String> localColumnNames = parsedInfo.localColumnsList.iterator();
/* 4211 */     Iterator<String> referColumnNames = parsedInfo.referencedColumnsList.iterator();
/*      */     
/* 4213 */     int keySeqIndex = 1;
/*      */     
/* 4215 */     while (localColumnNames.hasNext()) {
/* 4216 */       byte[][] tuple = new byte[14][];
/* 4217 */       String lColumnName = StringUtils.unQuoteIdentifier((String)localColumnNames.next(), this.quotedId);
/* 4218 */       String rColumnName = StringUtils.unQuoteIdentifier((String)referColumnNames.next(), this.quotedId);
/* 4219 */       tuple[4] = (catalog == null ? new byte[0] : s2b(catalog));
/* 4220 */       tuple[5] = null;
/* 4221 */       tuple[6] = s2b(isExport ? fkTableName : table);
/* 4222 */       tuple[7] = s2b(lColumnName);
/* 4223 */       tuple[0] = s2b(parsedInfo.referencedCatalog);
/* 4224 */       tuple[1] = null;
/* 4225 */       tuple[2] = s2b(isExport ? table : parsedInfo.referencedTable);
/* 4226 */       tuple[3] = s2b(rColumnName);
/* 4227 */       tuple[8] = s2b(Integer.toString(keySeqIndex++));
/*      */       
/* 4229 */       int[] actions = getForeignKeyActions(keysComment);
/*      */       
/* 4231 */       tuple[9] = s2b(Integer.toString(actions[1]));
/* 4232 */       tuple[10] = s2b(Integer.toString(actions[0]));
/* 4233 */       tuple[11] = s2b(parsedInfo.constraintName);
/* 4234 */       tuple[12] = null;
/* 4235 */       tuple[13] = s2b(Integer.toString(7));
/* 4236 */       tuples.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSchemas()
/*      */     throws SQLException
/*      */   {
/* 4255 */     Field[] fields = new Field[2];
/* 4256 */     fields[0] = new Field("", "TABLE_SCHEM", 1, 0);
/* 4257 */     fields[1] = new Field("", "TABLE_CATALOG", 1, 0);
/*      */     
/* 4259 */     ArrayList<ResultSetRow> tuples = new ArrayList();
/* 4260 */     ResultSet results = buildResultSet(fields, tuples);
/*      */     
/* 4262 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSchemaTerm()
/*      */     throws SQLException
/*      */   {
/* 4272 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSearchStringEscape()
/*      */     throws SQLException
/*      */   {
/* 4289 */     return "\\";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSQLKeywords()
/*      */     throws SQLException
/*      */   {
/* 4299 */     if (mysqlKeywords != null) {
/* 4300 */       return mysqlKeywords;
/*      */     }
/*      */     
/* 4303 */     synchronized (DatabaseMetaData.class)
/*      */     {
/* 4305 */       if (mysqlKeywords != null) {
/* 4306 */         return mysqlKeywords;
/*      */       }
/*      */       
/* 4309 */       Set<String> mysqlKeywordSet = new TreeSet();
/* 4310 */       StringBuilder mysqlKeywordsBuffer = new StringBuilder();
/*      */       
/* 4312 */       Collections.addAll(mysqlKeywordSet, MYSQL_KEYWORDS);
/* 4313 */       mysqlKeywordSet.removeAll(Arrays.asList(Util.isJdbc4() ? SQL2003_KEYWORDS : SQL92_KEYWORDS));
/*      */       
/* 4315 */       for (String keyword : mysqlKeywordSet) {
/* 4316 */         mysqlKeywordsBuffer.append(",").append(keyword);
/*      */       }
/*      */       
/* 4319 */       mysqlKeywords = mysqlKeywordsBuffer.substring(1);
/* 4320 */       return mysqlKeywords;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getSQLStateType()
/*      */     throws SQLException
/*      */   {
/* 4328 */     if (this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 4329 */       return 2;
/*      */     }
/*      */     
/* 4332 */     if (this.conn.getUseSqlStateCodes()) {
/* 4333 */       return 2;
/*      */     }
/*      */     
/* 4336 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStringFunctions()
/*      */     throws SQLException
/*      */   {
/* 4346 */     return "ASCII,BIN,BIT_LENGTH,CHAR,CHARACTER_LENGTH,CHAR_LENGTH,CONCAT,CONCAT_WS,CONV,ELT,EXPORT_SET,FIELD,FIND_IN_SET,HEX,INSERT,INSTR,LCASE,LEFT,LENGTH,LOAD_FILE,LOCATE,LOCATE,LOWER,LPAD,LTRIM,MAKE_SET,MATCH,MID,OCT,OCTET_LENGTH,ORD,POSITION,QUOTE,REPEAT,REPLACE,REVERSE,RIGHT,RPAD,RTRIM,SOUNDEX,SPACE,STRCMP,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING_INDEX,TRIM,UCASE,UPPER";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSuperTables(String arg0, String arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/* 4356 */     Field[] fields = new Field[4];
/* 4357 */     fields[0] = new Field("", "TABLE_CAT", 1, 32);
/* 4358 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 32);
/* 4359 */     fields[2] = new Field("", "TABLE_NAME", 1, 32);
/* 4360 */     fields[3] = new Field("", "SUPERTABLE_NAME", 1, 32);
/*      */     
/* 4362 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getSuperTypes(String arg0, String arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/* 4369 */     Field[] fields = new Field[6];
/* 4370 */     fields[0] = new Field("", "TYPE_CAT", 1, 32);
/* 4371 */     fields[1] = new Field("", "TYPE_SCHEM", 1, 32);
/* 4372 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/* 4373 */     fields[3] = new Field("", "SUPERTYPE_CAT", 1, 32);
/* 4374 */     fields[4] = new Field("", "SUPERTYPE_SCHEM", 1, 32);
/* 4375 */     fields[5] = new Field("", "SUPERTYPE_NAME", 1, 32);
/*      */     
/* 4377 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSystemFunctions()
/*      */     throws SQLException
/*      */   {
/* 4387 */     return "DATABASE,USER,SYSTEM_USER,SESSION_USER,PASSWORD,ENCRYPT,LAST_INSERT_ID,VERSION";
/*      */   }
/*      */   
/*      */   protected String getTableNameWithCase(String table) {
/* 4391 */     String tableNameWithCase = this.conn.lowerCaseTableNames() ? table.toLowerCase() : table;
/*      */     
/* 4393 */     return tableNameWithCase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern)
/*      */     throws SQLException
/*      */   {
/* 4429 */     if (tableNamePattern == null) {
/* 4430 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4431 */         tableNamePattern = "%";
/*      */       } else {
/* 4433 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4438 */     Field[] fields = new Field[7];
/* 4439 */     fields[0] = new Field("", "TABLE_CAT", 1, 64);
/* 4440 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 1);
/* 4441 */     fields[2] = new Field("", "TABLE_NAME", 1, 64);
/* 4442 */     fields[3] = new Field("", "GRANTOR", 1, 77);
/* 4443 */     fields[4] = new Field("", "GRANTEE", 1, 77);
/* 4444 */     fields[5] = new Field("", "PRIVILEGE", 1, 64);
/* 4445 */     fields[6] = new Field("", "IS_GRANTABLE", 1, 3);
/*      */     
/* 4447 */     String grantQuery = "SELECT host,db,table_name,grantor,user,table_priv FROM mysql.tables_priv WHERE db LIKE ? AND table_name LIKE ?";
/*      */     
/* 4449 */     ResultSet results = null;
/* 4450 */     ArrayList<ResultSetRow> grantRows = new ArrayList();
/* 4451 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/* 4454 */       pStmt = prepareMetaDataSafeStatement(grantQuery);
/*      */       
/* 4456 */       pStmt.setString(1, (catalog != null) && (catalog.length() != 0) ? catalog : "%");
/* 4457 */       pStmt.setString(2, tableNamePattern);
/*      */       
/* 4459 */       results = pStmt.executeQuery();
/*      */       
/* 4461 */       while (results.next()) {
/* 4462 */         String host = results.getString(1);
/* 4463 */         String db = results.getString(2);
/* 4464 */         String table = results.getString(3);
/* 4465 */         String grantor = results.getString(4);
/* 4466 */         String user = results.getString(5);
/*      */         
/* 4468 */         if ((user == null) || (user.length() == 0)) {
/* 4469 */           user = "%";
/*      */         }
/*      */         
/* 4472 */         StringBuilder fullUser = new StringBuilder(user);
/*      */         
/* 4474 */         if ((host != null) && (this.conn.getUseHostsInPrivileges())) {
/* 4475 */           fullUser.append("@");
/* 4476 */           fullUser.append(host);
/*      */         }
/*      */         
/* 4479 */         String allPrivileges = results.getString(6);
/*      */         
/* 4481 */         if (allPrivileges != null) {
/* 4482 */           allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/*      */           
/* 4484 */           StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/*      */           
/* 4486 */           while (st.hasMoreTokens()) {
/* 4487 */             String privilege = st.nextToken().trim();
/*      */             
/*      */ 
/* 4490 */             ResultSet columnResults = null;
/*      */             try
/*      */             {
/* 4493 */               columnResults = getColumns(catalog, schemaPattern, table, "%");
/*      */               
/* 4495 */               while (columnResults.next()) {
/* 4496 */                 byte[][] tuple = new byte[8][];
/* 4497 */                 tuple[0] = s2b(db);
/* 4498 */                 tuple[1] = null;
/* 4499 */                 tuple[2] = s2b(table);
/*      */                 
/* 4501 */                 if (grantor != null) {
/* 4502 */                   tuple[3] = s2b(grantor);
/*      */                 } else {
/* 4504 */                   tuple[3] = null;
/*      */                 }
/*      */                 
/* 4507 */                 tuple[4] = s2b(fullUser.toString());
/* 4508 */                 tuple[5] = s2b(privilege);
/* 4509 */                 tuple[6] = null;
/* 4510 */                 grantRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */               }
/*      */             } finally {
/* 4513 */               if (columnResults != null) {
/*      */                 try {
/* 4515 */                   columnResults.close();
/*      */                 }
/*      */                 catch (Exception ex) {}
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } finally {
/* 4524 */       if (results != null) {
/*      */         try {
/* 4526 */           results.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/* 4530 */         results = null;
/*      */       }
/*      */       
/* 4533 */       if (pStmt != null) {
/*      */         try {
/* 4535 */           pStmt.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/* 4539 */         pStmt = null;
/*      */       }
/*      */     }
/*      */     
/* 4543 */     return buildResultSet(fields, grantRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, final String[] types)
/*      */     throws SQLException
/*      */   {
/* 4581 */     if (tableNamePattern == null) {
/* 4582 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4583 */         tableNamePattern = "%";
/*      */       } else {
/* 4585 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4590 */     final SortedMap<TableMetaDataKey, ResultSetRow> sortedRows = new TreeMap();
/* 4591 */     ArrayList<ResultSetRow> tuples = new ArrayList();
/*      */     
/* 4593 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */ 
/* 4596 */     String tmpCat = "";
/*      */     
/* 4598 */     if ((catalog == null) || (catalog.length() == 0)) {
/* 4599 */       if (this.conn.getNullCatalogMeansCurrent()) {
/* 4600 */         tmpCat = this.database;
/*      */       }
/*      */     } else {
/* 4603 */       tmpCat = catalog;
/*      */     }
/*      */     
/* 4606 */     List<String> parseList = StringUtils.splitDBdotName(tableNamePattern, tmpCat, this.quotedId, this.conn.isNoBackslashEscapesSet());
/*      */     String tableNamePat;
/* 4608 */     final String tableNamePat; if (parseList.size() == 2) {
/* 4609 */       tableNamePat = (String)parseList.get(1);
/*      */     } else {
/* 4611 */       tableNamePat = tableNamePattern;
/*      */     }
/*      */     try
/*      */     {
/* 4615 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(String catalogStr) throws SQLException {
/* 4618 */           boolean operatingOnSystemDB = ("information_schema".equalsIgnoreCase(catalogStr)) || ("mysql".equalsIgnoreCase(catalogStr)) || ("performance_schema".equalsIgnoreCase(catalogStr));
/*      */           
/*      */ 
/* 4621 */           ResultSet results = null;
/*      */           try
/*      */           {
/*      */             try
/*      */             {
/* 4626 */               results = stmt.executeQuery((!DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 2) ? "SHOW TABLES FROM " : "SHOW FULL TABLES FROM ") + StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()) + " LIKE " + StringUtils.quoteIdentifier(tableNamePat, "'", true));
/*      */ 
/*      */             }
/*      */             catch (SQLException sqlEx)
/*      */             {
/* 4631 */               if ("08S01".equals(sqlEx.getSQLState())) {
/* 4632 */                 throw sqlEx;
/*      */               }
/*      */               
/* 4635 */               return;
/*      */             }
/*      */             
/* 4638 */             boolean shouldReportTables = false;
/* 4639 */             boolean shouldReportViews = false;
/* 4640 */             boolean shouldReportSystemTables = false;
/* 4641 */             boolean shouldReportSystemViews = false;
/* 4642 */             boolean shouldReportLocalTemporaries = false;
/*      */             
/* 4644 */             if ((types == null) || (types.length == 0)) {
/* 4645 */               shouldReportTables = true;
/* 4646 */               shouldReportViews = true;
/* 4647 */               shouldReportSystemTables = true;
/* 4648 */               shouldReportSystemViews = true;
/* 4649 */               shouldReportLocalTemporaries = true;
/*      */             } else {
/* 4651 */               for (int i = 0; i < types.length; i++) {
/* 4652 */                 if (DatabaseMetaData.TableType.TABLE.equalsTo(types[i])) {
/* 4653 */                   shouldReportTables = true;
/*      */                 }
/* 4655 */                 else if (DatabaseMetaData.TableType.VIEW.equalsTo(types[i])) {
/* 4656 */                   shouldReportViews = true;
/*      */                 }
/* 4658 */                 else if (DatabaseMetaData.TableType.SYSTEM_TABLE.equalsTo(types[i])) {
/* 4659 */                   shouldReportSystemTables = true;
/*      */                 }
/* 4661 */                 else if (DatabaseMetaData.TableType.SYSTEM_VIEW.equalsTo(types[i])) {
/* 4662 */                   shouldReportSystemViews = true;
/*      */                 }
/* 4664 */                 else if (DatabaseMetaData.TableType.LOCAL_TEMPORARY.equalsTo(types[i])) {
/* 4665 */                   shouldReportLocalTemporaries = true;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 4670 */             int typeColumnIndex = 0;
/* 4671 */             boolean hasTableTypes = false;
/*      */             
/* 4673 */             if (DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 2)) {
/*      */               try
/*      */               {
/* 4676 */                 typeColumnIndex = results.findColumn("table_type");
/* 4677 */                 hasTableTypes = true;
/*      */ 
/*      */               }
/*      */               catch (SQLException sqlEx)
/*      */               {
/*      */                 try
/*      */                 {
/* 4684 */                   typeColumnIndex = results.findColumn("Type");
/* 4685 */                   hasTableTypes = true;
/*      */                 } catch (SQLException sqlEx2) {
/* 4687 */                   hasTableTypes = false;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 4692 */             while (results.next()) {
/* 4693 */               byte[][] row = new byte[10][];
/* 4694 */               row[0] = (catalogStr == null ? null : DatabaseMetaData.this.s2b(catalogStr));
/* 4695 */               row[1] = null;
/* 4696 */               row[2] = results.getBytes(1);
/* 4697 */               row[4] = new byte[0];
/* 4698 */               row[5] = null;
/* 4699 */               row[6] = null;
/* 4700 */               row[7] = null;
/* 4701 */               row[8] = null;
/* 4702 */               row[9] = null;
/*      */               
/* 4704 */               if (hasTableTypes) {
/* 4705 */                 String tableType = results.getString(typeColumnIndex);
/*      */                 
/* 4707 */                 switch (DatabaseMetaData.11.$SwitchMap$com$mysql$jdbc$DatabaseMetaData$TableType[DatabaseMetaData.TableType.getTableTypeCompliantWith(tableType).ordinal()]) {
/*      */                 case 1: 
/* 4709 */                   boolean reportTable = false;
/* 4710 */                   DatabaseMetaData.TableMetaDataKey tablesKey = null;
/*      */                   
/* 4712 */                   if ((operatingOnSystemDB) && (shouldReportSystemTables)) {
/* 4713 */                     row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
/* 4714 */                     tablesKey = new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), catalogStr, null, results.getString(1));
/* 4715 */                     reportTable = true;
/*      */                   }
/* 4717 */                   else if ((!operatingOnSystemDB) && (shouldReportTables)) {
/* 4718 */                     row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
/* 4719 */                     tablesKey = new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.TABLE.getName(), catalogStr, null, results.getString(1));
/* 4720 */                     reportTable = true;
/*      */                   }
/*      */                   
/* 4723 */                   if (reportTable) {
/* 4724 */                     sortedRows.put(tablesKey, new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                   }
/*      */                   
/*      */                   break;
/*      */                 case 2: 
/* 4729 */                   if (shouldReportViews) {
/* 4730 */                     row[3] = DatabaseMetaData.TableType.VIEW.asBytes();
/* 4731 */                     sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.VIEW.getName(), catalogStr, null, results.getString(1)), new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                   }
/*      */                   
/*      */ 
/*      */                   break;
/*      */                 case 3: 
/* 4737 */                   if (shouldReportSystemTables) {
/* 4738 */                     row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
/* 4739 */                     sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), catalogStr, null, results.getString(1)), new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                   }
/*      */                   
/*      */ 
/*      */                   break;
/*      */                 case 4: 
/* 4745 */                   if (shouldReportSystemViews) {
/* 4746 */                     row[3] = DatabaseMetaData.TableType.SYSTEM_VIEW.asBytes();
/* 4747 */                     sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.SYSTEM_VIEW.getName(), catalogStr, null, results.getString(1)), new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                   }
/*      */                   
/*      */ 
/*      */                   break;
/*      */                 case 5: 
/* 4753 */                   if (shouldReportLocalTemporaries) {
/* 4754 */                     row[3] = DatabaseMetaData.TableType.LOCAL_TEMPORARY.asBytes();
/* 4755 */                     sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.LOCAL_TEMPORARY.getName(), catalogStr, null, results.getString(1)), new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                   }
/*      */                   
/*      */ 
/*      */                   break;
/*      */                 default: 
/* 4761 */                   row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
/* 4762 */                   sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.TABLE.getName(), catalogStr, null, results.getString(1)), new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                 
/*      */                 }
/*      */                 
/*      */               }
/* 4767 */               else if (shouldReportTables)
/*      */               {
/* 4769 */                 row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
/* 4770 */                 sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.TABLE.getName(), catalogStr, null, results.getString(1)), new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */               
/*      */             }
/*      */           }
/*      */           finally
/*      */           {
/* 4777 */             if (results != null) {
/*      */               try {
/* 4779 */                 results.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/* 4783 */               results = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     } finally {
/* 4789 */       if (stmt != null) {
/* 4790 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 4794 */     tuples.addAll(sortedRows.values());
/* 4795 */     ResultSet tables = buildResultSet(createTablesFields(), tuples);
/*      */     
/* 4797 */     return tables;
/*      */   }
/*      */   
/*      */   protected Field[] createTablesFields() {
/* 4801 */     Field[] fields = new Field[10];
/* 4802 */     fields[0] = new Field("", "TABLE_CAT", 12, 255);
/* 4803 */     fields[1] = new Field("", "TABLE_SCHEM", 12, 0);
/* 4804 */     fields[2] = new Field("", "TABLE_NAME", 12, 255);
/* 4805 */     fields[3] = new Field("", "TABLE_TYPE", 12, 5);
/* 4806 */     fields[4] = new Field("", "REMARKS", 12, 0);
/* 4807 */     fields[5] = new Field("", "TYPE_CAT", 12, 0);
/* 4808 */     fields[6] = new Field("", "TYPE_SCHEM", 12, 0);
/* 4809 */     fields[7] = new Field("", "TYPE_NAME", 12, 0);
/* 4810 */     fields[8] = new Field("", "SELF_REFERENCING_COL_NAME", 12, 0);
/* 4811 */     fields[9] = new Field("", "REF_GENERATION", 12, 0);
/* 4812 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTableTypes()
/*      */     throws SQLException
/*      */   {
/* 4831 */     ArrayList<ResultSetRow> tuples = new ArrayList();
/* 4832 */     Field[] fields = { new Field("", "TABLE_TYPE", 12, 256) };
/*      */     
/* 4834 */     boolean minVersion5_0_1 = this.conn.versionMeetsMinimum(5, 0, 1);
/*      */     
/* 4836 */     tuples.add(new ByteArrayRow(new byte[][] { TableType.LOCAL_TEMPORARY.asBytes() }, getExceptionInterceptor()));
/* 4837 */     tuples.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_TABLE.asBytes() }, getExceptionInterceptor()));
/* 4838 */     if (minVersion5_0_1) {
/* 4839 */       tuples.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_VIEW.asBytes() }, getExceptionInterceptor()));
/*      */     }
/* 4841 */     tuples.add(new ByteArrayRow(new byte[][] { TableType.TABLE.asBytes() }, getExceptionInterceptor()));
/* 4842 */     if (minVersion5_0_1) {
/* 4843 */       tuples.add(new ByteArrayRow(new byte[][] { TableType.VIEW.asBytes() }, getExceptionInterceptor()));
/*      */     }
/*      */     
/* 4846 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTimeDateFunctions()
/*      */     throws SQLException
/*      */   {
/* 4856 */     return "DAYOFWEEK,WEEKDAY,DAYOFMONTH,DAYOFYEAR,MONTH,DAYNAME,MONTHNAME,QUARTER,WEEK,YEAR,HOUR,MINUTE,SECOND,PERIOD_ADD,PERIOD_DIFF,TO_DAYS,FROM_DAYS,DATE_FORMAT,TIME_FORMAT,CURDATE,CURRENT_DATE,CURTIME,CURRENT_TIME,NOW,SYSDATE,CURRENT_TIMESTAMP,UNIX_TIMESTAMP,FROM_UNIXTIME,SEC_TO_TIME,TIME_TO_SEC";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTypeInfo()
/*      */     throws SQLException
/*      */   {
/* 4950 */     Field[] fields = new Field[18];
/* 4951 */     fields[0] = new Field("", "TYPE_NAME", 1, 32);
/* 4952 */     fields[1] = new Field("", "DATA_TYPE", 4, 5);
/* 4953 */     fields[2] = new Field("", "PRECISION", 4, 10);
/* 4954 */     fields[3] = new Field("", "LITERAL_PREFIX", 1, 4);
/* 4955 */     fields[4] = new Field("", "LITERAL_SUFFIX", 1, 4);
/* 4956 */     fields[5] = new Field("", "CREATE_PARAMS", 1, 32);
/* 4957 */     fields[6] = new Field("", "NULLABLE", 5, 5);
/* 4958 */     fields[7] = new Field("", "CASE_SENSITIVE", 16, 3);
/* 4959 */     fields[8] = new Field("", "SEARCHABLE", 5, 3);
/* 4960 */     fields[9] = new Field("", "UNSIGNED_ATTRIBUTE", 16, 3);
/* 4961 */     fields[10] = new Field("", "FIXED_PREC_SCALE", 16, 3);
/* 4962 */     fields[11] = new Field("", "AUTO_INCREMENT", 16, 3);
/* 4963 */     fields[12] = new Field("", "LOCAL_TYPE_NAME", 1, 32);
/* 4964 */     fields[13] = new Field("", "MINIMUM_SCALE", 5, 5);
/* 4965 */     fields[14] = new Field("", "MAXIMUM_SCALE", 5, 5);
/* 4966 */     fields[15] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 4967 */     fields[16] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 4968 */     fields[17] = new Field("", "NUM_PREC_RADIX", 4, 10);
/*      */     
/* 4970 */     byte[][] rowVal = (byte[][])null;
/* 4971 */     ArrayList<ResultSetRow> tuples = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4979 */     rowVal = new byte[18][];
/* 4980 */     rowVal[0] = s2b("BIT");
/* 4981 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */     
/*      */ 
/* 4984 */     rowVal[2] = s2b("1");
/* 4985 */     rowVal[3] = s2b("");
/* 4986 */     rowVal[4] = s2b("");
/* 4987 */     rowVal[5] = s2b("");
/* 4988 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 4991 */     rowVal[7] = s2b("true");
/* 4992 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 4995 */     rowVal[9] = s2b("false");
/* 4996 */     rowVal[10] = s2b("false");
/* 4997 */     rowVal[11] = s2b("false");
/* 4998 */     rowVal[12] = s2b("BIT");
/* 4999 */     rowVal[13] = s2b("0");
/* 5000 */     rowVal[14] = s2b("0");
/* 5001 */     rowVal[15] = s2b("0");
/* 5002 */     rowVal[16] = s2b("0");
/* 5003 */     rowVal[17] = s2b("10");
/* 5004 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5009 */     rowVal = new byte[18][];
/* 5010 */     rowVal[0] = s2b("BOOL");
/* 5011 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */     
/*      */ 
/* 5014 */     rowVal[2] = s2b("1");
/* 5015 */     rowVal[3] = s2b("");
/* 5016 */     rowVal[4] = s2b("");
/* 5017 */     rowVal[5] = s2b("");
/* 5018 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5021 */     rowVal[7] = s2b("true");
/* 5022 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5025 */     rowVal[9] = s2b("false");
/* 5026 */     rowVal[10] = s2b("false");
/* 5027 */     rowVal[11] = s2b("false");
/* 5028 */     rowVal[12] = s2b("BOOL");
/* 5029 */     rowVal[13] = s2b("0");
/* 5030 */     rowVal[14] = s2b("0");
/* 5031 */     rowVal[15] = s2b("0");
/* 5032 */     rowVal[16] = s2b("0");
/* 5033 */     rowVal[17] = s2b("10");
/* 5034 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5039 */     rowVal = new byte[18][];
/* 5040 */     rowVal[0] = s2b("TINYINT");
/* 5041 */     rowVal[1] = Integer.toString(-6).getBytes();
/*      */     
/*      */ 
/* 5044 */     rowVal[2] = s2b("3");
/* 5045 */     rowVal[3] = s2b("");
/* 5046 */     rowVal[4] = s2b("");
/* 5047 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5048 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5051 */     rowVal[7] = s2b("false");
/* 5052 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5055 */     rowVal[9] = s2b("true");
/* 5056 */     rowVal[10] = s2b("false");
/* 5057 */     rowVal[11] = s2b("true");
/* 5058 */     rowVal[12] = s2b("TINYINT");
/* 5059 */     rowVal[13] = s2b("0");
/* 5060 */     rowVal[14] = s2b("0");
/* 5061 */     rowVal[15] = s2b("0");
/* 5062 */     rowVal[16] = s2b("0");
/* 5063 */     rowVal[17] = s2b("10");
/* 5064 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5066 */     rowVal = new byte[18][];
/* 5067 */     rowVal[0] = s2b("TINYINT UNSIGNED");
/* 5068 */     rowVal[1] = Integer.toString(-6).getBytes();
/*      */     
/*      */ 
/* 5071 */     rowVal[2] = s2b("3");
/* 5072 */     rowVal[3] = s2b("");
/* 5073 */     rowVal[4] = s2b("");
/* 5074 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5075 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5078 */     rowVal[7] = s2b("false");
/* 5079 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5082 */     rowVal[9] = s2b("true");
/* 5083 */     rowVal[10] = s2b("false");
/* 5084 */     rowVal[11] = s2b("true");
/* 5085 */     rowVal[12] = s2b("TINYINT UNSIGNED");
/* 5086 */     rowVal[13] = s2b("0");
/* 5087 */     rowVal[14] = s2b("0");
/* 5088 */     rowVal[15] = s2b("0");
/* 5089 */     rowVal[16] = s2b("0");
/* 5090 */     rowVal[17] = s2b("10");
/* 5091 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5096 */     rowVal = new byte[18][];
/* 5097 */     rowVal[0] = s2b("BIGINT");
/* 5098 */     rowVal[1] = Integer.toString(-5).getBytes();
/*      */     
/*      */ 
/* 5101 */     rowVal[2] = s2b("19");
/* 5102 */     rowVal[3] = s2b("");
/* 5103 */     rowVal[4] = s2b("");
/* 5104 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5105 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5108 */     rowVal[7] = s2b("false");
/* 5109 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5112 */     rowVal[9] = s2b("true");
/* 5113 */     rowVal[10] = s2b("false");
/* 5114 */     rowVal[11] = s2b("true");
/* 5115 */     rowVal[12] = s2b("BIGINT");
/* 5116 */     rowVal[13] = s2b("0");
/* 5117 */     rowVal[14] = s2b("0");
/* 5118 */     rowVal[15] = s2b("0");
/* 5119 */     rowVal[16] = s2b("0");
/* 5120 */     rowVal[17] = s2b("10");
/* 5121 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5123 */     rowVal = new byte[18][];
/* 5124 */     rowVal[0] = s2b("BIGINT UNSIGNED");
/* 5125 */     rowVal[1] = Integer.toString(-5).getBytes();
/*      */     
/*      */ 
/* 5128 */     rowVal[2] = s2b("20");
/* 5129 */     rowVal[3] = s2b("");
/* 5130 */     rowVal[4] = s2b("");
/* 5131 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5132 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5135 */     rowVal[7] = s2b("false");
/* 5136 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5139 */     rowVal[9] = s2b("true");
/* 5140 */     rowVal[10] = s2b("false");
/* 5141 */     rowVal[11] = s2b("true");
/* 5142 */     rowVal[12] = s2b("BIGINT UNSIGNED");
/* 5143 */     rowVal[13] = s2b("0");
/* 5144 */     rowVal[14] = s2b("0");
/* 5145 */     rowVal[15] = s2b("0");
/* 5146 */     rowVal[16] = s2b("0");
/* 5147 */     rowVal[17] = s2b("10");
/* 5148 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5153 */     rowVal = new byte[18][];
/* 5154 */     rowVal[0] = s2b("LONG VARBINARY");
/* 5155 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5158 */     rowVal[2] = s2b("16777215");
/* 5159 */     rowVal[3] = s2b("'");
/* 5160 */     rowVal[4] = s2b("'");
/* 5161 */     rowVal[5] = s2b("");
/* 5162 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5165 */     rowVal[7] = s2b("true");
/* 5166 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5169 */     rowVal[9] = s2b("false");
/* 5170 */     rowVal[10] = s2b("false");
/* 5171 */     rowVal[11] = s2b("false");
/* 5172 */     rowVal[12] = s2b("LONG VARBINARY");
/* 5173 */     rowVal[13] = s2b("0");
/* 5174 */     rowVal[14] = s2b("0");
/* 5175 */     rowVal[15] = s2b("0");
/* 5176 */     rowVal[16] = s2b("0");
/* 5177 */     rowVal[17] = s2b("10");
/* 5178 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5183 */     rowVal = new byte[18][];
/* 5184 */     rowVal[0] = s2b("MEDIUMBLOB");
/* 5185 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5188 */     rowVal[2] = s2b("16777215");
/* 5189 */     rowVal[3] = s2b("'");
/* 5190 */     rowVal[4] = s2b("'");
/* 5191 */     rowVal[5] = s2b("");
/* 5192 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5195 */     rowVal[7] = s2b("true");
/* 5196 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5199 */     rowVal[9] = s2b("false");
/* 5200 */     rowVal[10] = s2b("false");
/* 5201 */     rowVal[11] = s2b("false");
/* 5202 */     rowVal[12] = s2b("MEDIUMBLOB");
/* 5203 */     rowVal[13] = s2b("0");
/* 5204 */     rowVal[14] = s2b("0");
/* 5205 */     rowVal[15] = s2b("0");
/* 5206 */     rowVal[16] = s2b("0");
/* 5207 */     rowVal[17] = s2b("10");
/* 5208 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5213 */     rowVal = new byte[18][];
/* 5214 */     rowVal[0] = s2b("LONGBLOB");
/* 5215 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5218 */     rowVal[2] = Integer.toString(Integer.MAX_VALUE).getBytes();
/*      */     
/*      */ 
/* 5221 */     rowVal[3] = s2b("'");
/* 5222 */     rowVal[4] = s2b("'");
/* 5223 */     rowVal[5] = s2b("");
/* 5224 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5227 */     rowVal[7] = s2b("true");
/* 5228 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5231 */     rowVal[9] = s2b("false");
/* 5232 */     rowVal[10] = s2b("false");
/* 5233 */     rowVal[11] = s2b("false");
/* 5234 */     rowVal[12] = s2b("LONGBLOB");
/* 5235 */     rowVal[13] = s2b("0");
/* 5236 */     rowVal[14] = s2b("0");
/* 5237 */     rowVal[15] = s2b("0");
/* 5238 */     rowVal[16] = s2b("0");
/* 5239 */     rowVal[17] = s2b("10");
/* 5240 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5245 */     rowVal = new byte[18][];
/* 5246 */     rowVal[0] = s2b("BLOB");
/* 5247 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5250 */     rowVal[2] = s2b("65535");
/* 5251 */     rowVal[3] = s2b("'");
/* 5252 */     rowVal[4] = s2b("'");
/* 5253 */     rowVal[5] = s2b("");
/* 5254 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5257 */     rowVal[7] = s2b("true");
/* 5258 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5261 */     rowVal[9] = s2b("false");
/* 5262 */     rowVal[10] = s2b("false");
/* 5263 */     rowVal[11] = s2b("false");
/* 5264 */     rowVal[12] = s2b("BLOB");
/* 5265 */     rowVal[13] = s2b("0");
/* 5266 */     rowVal[14] = s2b("0");
/* 5267 */     rowVal[15] = s2b("0");
/* 5268 */     rowVal[16] = s2b("0");
/* 5269 */     rowVal[17] = s2b("10");
/* 5270 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5275 */     rowVal = new byte[18][];
/* 5276 */     rowVal[0] = s2b("TINYBLOB");
/* 5277 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5280 */     rowVal[2] = s2b("255");
/* 5281 */     rowVal[3] = s2b("'");
/* 5282 */     rowVal[4] = s2b("'");
/* 5283 */     rowVal[5] = s2b("");
/* 5284 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5287 */     rowVal[7] = s2b("true");
/* 5288 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5291 */     rowVal[9] = s2b("false");
/* 5292 */     rowVal[10] = s2b("false");
/* 5293 */     rowVal[11] = s2b("false");
/* 5294 */     rowVal[12] = s2b("TINYBLOB");
/* 5295 */     rowVal[13] = s2b("0");
/* 5296 */     rowVal[14] = s2b("0");
/* 5297 */     rowVal[15] = s2b("0");
/* 5298 */     rowVal[16] = s2b("0");
/* 5299 */     rowVal[17] = s2b("10");
/* 5300 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5306 */     rowVal = new byte[18][];
/* 5307 */     rowVal[0] = s2b("VARBINARY");
/* 5308 */     rowVal[1] = Integer.toString(-3).getBytes();
/*      */     
/*      */ 
/* 5311 */     rowVal[2] = s2b("255");
/* 5312 */     rowVal[3] = s2b("'");
/* 5313 */     rowVal[4] = s2b("'");
/* 5314 */     rowVal[5] = s2b("(M)");
/* 5315 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5318 */     rowVal[7] = s2b("true");
/* 5319 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5322 */     rowVal[9] = s2b("false");
/* 5323 */     rowVal[10] = s2b("false");
/* 5324 */     rowVal[11] = s2b("false");
/* 5325 */     rowVal[12] = s2b("VARBINARY");
/* 5326 */     rowVal[13] = s2b("0");
/* 5327 */     rowVal[14] = s2b("0");
/* 5328 */     rowVal[15] = s2b("0");
/* 5329 */     rowVal[16] = s2b("0");
/* 5330 */     rowVal[17] = s2b("10");
/* 5331 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5337 */     rowVal = new byte[18][];
/* 5338 */     rowVal[0] = s2b("BINARY");
/* 5339 */     rowVal[1] = Integer.toString(-2).getBytes();
/*      */     
/*      */ 
/* 5342 */     rowVal[2] = s2b("255");
/* 5343 */     rowVal[3] = s2b("'");
/* 5344 */     rowVal[4] = s2b("'");
/* 5345 */     rowVal[5] = s2b("(M)");
/* 5346 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5349 */     rowVal[7] = s2b("true");
/* 5350 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5353 */     rowVal[9] = s2b("false");
/* 5354 */     rowVal[10] = s2b("false");
/* 5355 */     rowVal[11] = s2b("false");
/* 5356 */     rowVal[12] = s2b("BINARY");
/* 5357 */     rowVal[13] = s2b("0");
/* 5358 */     rowVal[14] = s2b("0");
/* 5359 */     rowVal[15] = s2b("0");
/* 5360 */     rowVal[16] = s2b("0");
/* 5361 */     rowVal[17] = s2b("10");
/* 5362 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5367 */     rowVal = new byte[18][];
/* 5368 */     rowVal[0] = s2b("LONG VARCHAR");
/* 5369 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5372 */     rowVal[2] = s2b("16777215");
/* 5373 */     rowVal[3] = s2b("'");
/* 5374 */     rowVal[4] = s2b("'");
/* 5375 */     rowVal[5] = s2b("");
/* 5376 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5379 */     rowVal[7] = s2b("false");
/* 5380 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5383 */     rowVal[9] = s2b("false");
/* 5384 */     rowVal[10] = s2b("false");
/* 5385 */     rowVal[11] = s2b("false");
/* 5386 */     rowVal[12] = s2b("LONG VARCHAR");
/* 5387 */     rowVal[13] = s2b("0");
/* 5388 */     rowVal[14] = s2b("0");
/* 5389 */     rowVal[15] = s2b("0");
/* 5390 */     rowVal[16] = s2b("0");
/* 5391 */     rowVal[17] = s2b("10");
/* 5392 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5397 */     rowVal = new byte[18][];
/* 5398 */     rowVal[0] = s2b("MEDIUMTEXT");
/* 5399 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5402 */     rowVal[2] = s2b("16777215");
/* 5403 */     rowVal[3] = s2b("'");
/* 5404 */     rowVal[4] = s2b("'");
/* 5405 */     rowVal[5] = s2b("");
/* 5406 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5409 */     rowVal[7] = s2b("false");
/* 5410 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5413 */     rowVal[9] = s2b("false");
/* 5414 */     rowVal[10] = s2b("false");
/* 5415 */     rowVal[11] = s2b("false");
/* 5416 */     rowVal[12] = s2b("MEDIUMTEXT");
/* 5417 */     rowVal[13] = s2b("0");
/* 5418 */     rowVal[14] = s2b("0");
/* 5419 */     rowVal[15] = s2b("0");
/* 5420 */     rowVal[16] = s2b("0");
/* 5421 */     rowVal[17] = s2b("10");
/* 5422 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5427 */     rowVal = new byte[18][];
/* 5428 */     rowVal[0] = s2b("LONGTEXT");
/* 5429 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5432 */     rowVal[2] = Integer.toString(Integer.MAX_VALUE).getBytes();
/*      */     
/*      */ 
/* 5435 */     rowVal[3] = s2b("'");
/* 5436 */     rowVal[4] = s2b("'");
/* 5437 */     rowVal[5] = s2b("");
/* 5438 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5441 */     rowVal[7] = s2b("false");
/* 5442 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5445 */     rowVal[9] = s2b("false");
/* 5446 */     rowVal[10] = s2b("false");
/* 5447 */     rowVal[11] = s2b("false");
/* 5448 */     rowVal[12] = s2b("LONGTEXT");
/* 5449 */     rowVal[13] = s2b("0");
/* 5450 */     rowVal[14] = s2b("0");
/* 5451 */     rowVal[15] = s2b("0");
/* 5452 */     rowVal[16] = s2b("0");
/* 5453 */     rowVal[17] = s2b("10");
/* 5454 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5459 */     rowVal = new byte[18][];
/* 5460 */     rowVal[0] = s2b("TEXT");
/* 5461 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5464 */     rowVal[2] = s2b("65535");
/* 5465 */     rowVal[3] = s2b("'");
/* 5466 */     rowVal[4] = s2b("'");
/* 5467 */     rowVal[5] = s2b("");
/* 5468 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5471 */     rowVal[7] = s2b("false");
/* 5472 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5475 */     rowVal[9] = s2b("false");
/* 5476 */     rowVal[10] = s2b("false");
/* 5477 */     rowVal[11] = s2b("false");
/* 5478 */     rowVal[12] = s2b("TEXT");
/* 5479 */     rowVal[13] = s2b("0");
/* 5480 */     rowVal[14] = s2b("0");
/* 5481 */     rowVal[15] = s2b("0");
/* 5482 */     rowVal[16] = s2b("0");
/* 5483 */     rowVal[17] = s2b("10");
/* 5484 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5489 */     rowVal = new byte[18][];
/* 5490 */     rowVal[0] = s2b("TINYTEXT");
/* 5491 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5494 */     rowVal[2] = s2b("255");
/* 5495 */     rowVal[3] = s2b("'");
/* 5496 */     rowVal[4] = s2b("'");
/* 5497 */     rowVal[5] = s2b("");
/* 5498 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5501 */     rowVal[7] = s2b("false");
/* 5502 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5505 */     rowVal[9] = s2b("false");
/* 5506 */     rowVal[10] = s2b("false");
/* 5507 */     rowVal[11] = s2b("false");
/* 5508 */     rowVal[12] = s2b("TINYTEXT");
/* 5509 */     rowVal[13] = s2b("0");
/* 5510 */     rowVal[14] = s2b("0");
/* 5511 */     rowVal[15] = s2b("0");
/* 5512 */     rowVal[16] = s2b("0");
/* 5513 */     rowVal[17] = s2b("10");
/* 5514 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5519 */     rowVal = new byte[18][];
/* 5520 */     rowVal[0] = s2b("CHAR");
/* 5521 */     rowVal[1] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5524 */     rowVal[2] = s2b("255");
/* 5525 */     rowVal[3] = s2b("'");
/* 5526 */     rowVal[4] = s2b("'");
/* 5527 */     rowVal[5] = s2b("(M)");
/* 5528 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5531 */     rowVal[7] = s2b("false");
/* 5532 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5535 */     rowVal[9] = s2b("false");
/* 5536 */     rowVal[10] = s2b("false");
/* 5537 */     rowVal[11] = s2b("false");
/* 5538 */     rowVal[12] = s2b("CHAR");
/* 5539 */     rowVal[13] = s2b("0");
/* 5540 */     rowVal[14] = s2b("0");
/* 5541 */     rowVal[15] = s2b("0");
/* 5542 */     rowVal[16] = s2b("0");
/* 5543 */     rowVal[17] = s2b("10");
/* 5544 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/* 5548 */     int decimalPrecision = 254;
/*      */     
/* 5550 */     if (this.conn.versionMeetsMinimum(5, 0, 3)) {
/* 5551 */       if (this.conn.versionMeetsMinimum(5, 0, 6)) {
/* 5552 */         decimalPrecision = 65;
/*      */       } else {
/* 5554 */         decimalPrecision = 64;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5561 */     rowVal = new byte[18][];
/* 5562 */     rowVal[0] = s2b("NUMERIC");
/* 5563 */     rowVal[1] = Integer.toString(2).getBytes();
/*      */     
/*      */ 
/* 5566 */     rowVal[2] = s2b(String.valueOf(decimalPrecision));
/* 5567 */     rowVal[3] = s2b("");
/* 5568 */     rowVal[4] = s2b("");
/* 5569 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 5570 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5573 */     rowVal[7] = s2b("false");
/* 5574 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5577 */     rowVal[9] = s2b("false");
/* 5578 */     rowVal[10] = s2b("false");
/* 5579 */     rowVal[11] = s2b("true");
/* 5580 */     rowVal[12] = s2b("NUMERIC");
/* 5581 */     rowVal[13] = s2b("-308");
/* 5582 */     rowVal[14] = s2b("308");
/* 5583 */     rowVal[15] = s2b("0");
/* 5584 */     rowVal[16] = s2b("0");
/* 5585 */     rowVal[17] = s2b("10");
/* 5586 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5591 */     rowVal = new byte[18][];
/* 5592 */     rowVal[0] = s2b("DECIMAL");
/* 5593 */     rowVal[1] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5596 */     rowVal[2] = s2b(String.valueOf(decimalPrecision));
/* 5597 */     rowVal[3] = s2b("");
/* 5598 */     rowVal[4] = s2b("");
/* 5599 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 5600 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5603 */     rowVal[7] = s2b("false");
/* 5604 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5607 */     rowVal[9] = s2b("false");
/* 5608 */     rowVal[10] = s2b("false");
/* 5609 */     rowVal[11] = s2b("true");
/* 5610 */     rowVal[12] = s2b("DECIMAL");
/* 5611 */     rowVal[13] = s2b("-308");
/* 5612 */     rowVal[14] = s2b("308");
/* 5613 */     rowVal[15] = s2b("0");
/* 5614 */     rowVal[16] = s2b("0");
/* 5615 */     rowVal[17] = s2b("10");
/* 5616 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5621 */     rowVal = new byte[18][];
/* 5622 */     rowVal[0] = s2b("INTEGER");
/* 5623 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 5626 */     rowVal[2] = s2b("10");
/* 5627 */     rowVal[3] = s2b("");
/* 5628 */     rowVal[4] = s2b("");
/* 5629 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5630 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5633 */     rowVal[7] = s2b("false");
/* 5634 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5637 */     rowVal[9] = s2b("true");
/* 5638 */     rowVal[10] = s2b("false");
/* 5639 */     rowVal[11] = s2b("true");
/* 5640 */     rowVal[12] = s2b("INTEGER");
/* 5641 */     rowVal[13] = s2b("0");
/* 5642 */     rowVal[14] = s2b("0");
/* 5643 */     rowVal[15] = s2b("0");
/* 5644 */     rowVal[16] = s2b("0");
/* 5645 */     rowVal[17] = s2b("10");
/* 5646 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5648 */     rowVal = new byte[18][];
/* 5649 */     rowVal[0] = s2b("INTEGER UNSIGNED");
/* 5650 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 5653 */     rowVal[2] = s2b("10");
/* 5654 */     rowVal[3] = s2b("");
/* 5655 */     rowVal[4] = s2b("");
/* 5656 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5657 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5660 */     rowVal[7] = s2b("false");
/* 5661 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5664 */     rowVal[9] = s2b("true");
/* 5665 */     rowVal[10] = s2b("false");
/* 5666 */     rowVal[11] = s2b("true");
/* 5667 */     rowVal[12] = s2b("INTEGER UNSIGNED");
/* 5668 */     rowVal[13] = s2b("0");
/* 5669 */     rowVal[14] = s2b("0");
/* 5670 */     rowVal[15] = s2b("0");
/* 5671 */     rowVal[16] = s2b("0");
/* 5672 */     rowVal[17] = s2b("10");
/* 5673 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5678 */     rowVal = new byte[18][];
/* 5679 */     rowVal[0] = s2b("INT");
/* 5680 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 5683 */     rowVal[2] = s2b("10");
/* 5684 */     rowVal[3] = s2b("");
/* 5685 */     rowVal[4] = s2b("");
/* 5686 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5687 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5690 */     rowVal[7] = s2b("false");
/* 5691 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5694 */     rowVal[9] = s2b("true");
/* 5695 */     rowVal[10] = s2b("false");
/* 5696 */     rowVal[11] = s2b("true");
/* 5697 */     rowVal[12] = s2b("INT");
/* 5698 */     rowVal[13] = s2b("0");
/* 5699 */     rowVal[14] = s2b("0");
/* 5700 */     rowVal[15] = s2b("0");
/* 5701 */     rowVal[16] = s2b("0");
/* 5702 */     rowVal[17] = s2b("10");
/* 5703 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5705 */     rowVal = new byte[18][];
/* 5706 */     rowVal[0] = s2b("INT UNSIGNED");
/* 5707 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 5710 */     rowVal[2] = s2b("10");
/* 5711 */     rowVal[3] = s2b("");
/* 5712 */     rowVal[4] = s2b("");
/* 5713 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5714 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5717 */     rowVal[7] = s2b("false");
/* 5718 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5721 */     rowVal[9] = s2b("true");
/* 5722 */     rowVal[10] = s2b("false");
/* 5723 */     rowVal[11] = s2b("true");
/* 5724 */     rowVal[12] = s2b("INT UNSIGNED");
/* 5725 */     rowVal[13] = s2b("0");
/* 5726 */     rowVal[14] = s2b("0");
/* 5727 */     rowVal[15] = s2b("0");
/* 5728 */     rowVal[16] = s2b("0");
/* 5729 */     rowVal[17] = s2b("10");
/* 5730 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5735 */     rowVal = new byte[18][];
/* 5736 */     rowVal[0] = s2b("MEDIUMINT");
/* 5737 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 5740 */     rowVal[2] = s2b("7");
/* 5741 */     rowVal[3] = s2b("");
/* 5742 */     rowVal[4] = s2b("");
/* 5743 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5744 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5747 */     rowVal[7] = s2b("false");
/* 5748 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5751 */     rowVal[9] = s2b("true");
/* 5752 */     rowVal[10] = s2b("false");
/* 5753 */     rowVal[11] = s2b("true");
/* 5754 */     rowVal[12] = s2b("MEDIUMINT");
/* 5755 */     rowVal[13] = s2b("0");
/* 5756 */     rowVal[14] = s2b("0");
/* 5757 */     rowVal[15] = s2b("0");
/* 5758 */     rowVal[16] = s2b("0");
/* 5759 */     rowVal[17] = s2b("10");
/* 5760 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5762 */     rowVal = new byte[18][];
/* 5763 */     rowVal[0] = s2b("MEDIUMINT UNSIGNED");
/* 5764 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 5767 */     rowVal[2] = s2b("8");
/* 5768 */     rowVal[3] = s2b("");
/* 5769 */     rowVal[4] = s2b("");
/* 5770 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5771 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5774 */     rowVal[7] = s2b("false");
/* 5775 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5778 */     rowVal[9] = s2b("true");
/* 5779 */     rowVal[10] = s2b("false");
/* 5780 */     rowVal[11] = s2b("true");
/* 5781 */     rowVal[12] = s2b("MEDIUMINT UNSIGNED");
/* 5782 */     rowVal[13] = s2b("0");
/* 5783 */     rowVal[14] = s2b("0");
/* 5784 */     rowVal[15] = s2b("0");
/* 5785 */     rowVal[16] = s2b("0");
/* 5786 */     rowVal[17] = s2b("10");
/* 5787 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5792 */     rowVal = new byte[18][];
/* 5793 */     rowVal[0] = s2b("SMALLINT");
/* 5794 */     rowVal[1] = Integer.toString(5).getBytes();
/*      */     
/*      */ 
/* 5797 */     rowVal[2] = s2b("5");
/* 5798 */     rowVal[3] = s2b("");
/* 5799 */     rowVal[4] = s2b("");
/* 5800 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5801 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5804 */     rowVal[7] = s2b("false");
/* 5805 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5808 */     rowVal[9] = s2b("true");
/* 5809 */     rowVal[10] = s2b("false");
/* 5810 */     rowVal[11] = s2b("true");
/* 5811 */     rowVal[12] = s2b("SMALLINT");
/* 5812 */     rowVal[13] = s2b("0");
/* 5813 */     rowVal[14] = s2b("0");
/* 5814 */     rowVal[15] = s2b("0");
/* 5815 */     rowVal[16] = s2b("0");
/* 5816 */     rowVal[17] = s2b("10");
/* 5817 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5819 */     rowVal = new byte[18][];
/* 5820 */     rowVal[0] = s2b("SMALLINT UNSIGNED");
/* 5821 */     rowVal[1] = Integer.toString(5).getBytes();
/*      */     
/*      */ 
/* 5824 */     rowVal[2] = s2b("5");
/* 5825 */     rowVal[3] = s2b("");
/* 5826 */     rowVal[4] = s2b("");
/* 5827 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5828 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5831 */     rowVal[7] = s2b("false");
/* 5832 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5835 */     rowVal[9] = s2b("true");
/* 5836 */     rowVal[10] = s2b("false");
/* 5837 */     rowVal[11] = s2b("true");
/* 5838 */     rowVal[12] = s2b("SMALLINT UNSIGNED");
/* 5839 */     rowVal[13] = s2b("0");
/* 5840 */     rowVal[14] = s2b("0");
/* 5841 */     rowVal[15] = s2b("0");
/* 5842 */     rowVal[16] = s2b("0");
/* 5843 */     rowVal[17] = s2b("10");
/* 5844 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5850 */     rowVal = new byte[18][];
/* 5851 */     rowVal[0] = s2b("FLOAT");
/* 5852 */     rowVal[1] = Integer.toString(7).getBytes();
/*      */     
/*      */ 
/* 5855 */     rowVal[2] = s2b("10");
/* 5856 */     rowVal[3] = s2b("");
/* 5857 */     rowVal[4] = s2b("");
/* 5858 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5859 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5862 */     rowVal[7] = s2b("false");
/* 5863 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5866 */     rowVal[9] = s2b("false");
/* 5867 */     rowVal[10] = s2b("false");
/* 5868 */     rowVal[11] = s2b("true");
/* 5869 */     rowVal[12] = s2b("FLOAT");
/* 5870 */     rowVal[13] = s2b("-38");
/* 5871 */     rowVal[14] = s2b("38");
/* 5872 */     rowVal[15] = s2b("0");
/* 5873 */     rowVal[16] = s2b("0");
/* 5874 */     rowVal[17] = s2b("10");
/* 5875 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5880 */     rowVal = new byte[18][];
/* 5881 */     rowVal[0] = s2b("DOUBLE");
/* 5882 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */     
/*      */ 
/* 5885 */     rowVal[2] = s2b("17");
/* 5886 */     rowVal[3] = s2b("");
/* 5887 */     rowVal[4] = s2b("");
/* 5888 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5889 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5892 */     rowVal[7] = s2b("false");
/* 5893 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5896 */     rowVal[9] = s2b("false");
/* 5897 */     rowVal[10] = s2b("false");
/* 5898 */     rowVal[11] = s2b("true");
/* 5899 */     rowVal[12] = s2b("DOUBLE");
/* 5900 */     rowVal[13] = s2b("-308");
/* 5901 */     rowVal[14] = s2b("308");
/* 5902 */     rowVal[15] = s2b("0");
/* 5903 */     rowVal[16] = s2b("0");
/* 5904 */     rowVal[17] = s2b("10");
/* 5905 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5910 */     rowVal = new byte[18][];
/* 5911 */     rowVal[0] = s2b("DOUBLE PRECISION");
/* 5912 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */     
/*      */ 
/* 5915 */     rowVal[2] = s2b("17");
/* 5916 */     rowVal[3] = s2b("");
/* 5917 */     rowVal[4] = s2b("");
/* 5918 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5919 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5922 */     rowVal[7] = s2b("false");
/* 5923 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5926 */     rowVal[9] = s2b("false");
/* 5927 */     rowVal[10] = s2b("false");
/* 5928 */     rowVal[11] = s2b("true");
/* 5929 */     rowVal[12] = s2b("DOUBLE PRECISION");
/* 5930 */     rowVal[13] = s2b("-308");
/* 5931 */     rowVal[14] = s2b("308");
/* 5932 */     rowVal[15] = s2b("0");
/* 5933 */     rowVal[16] = s2b("0");
/* 5934 */     rowVal[17] = s2b("10");
/* 5935 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5940 */     rowVal = new byte[18][];
/* 5941 */     rowVal[0] = s2b("REAL");
/* 5942 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */     
/*      */ 
/* 5945 */     rowVal[2] = s2b("17");
/* 5946 */     rowVal[3] = s2b("");
/* 5947 */     rowVal[4] = s2b("");
/* 5948 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5949 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5952 */     rowVal[7] = s2b("false");
/* 5953 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5956 */     rowVal[9] = s2b("false");
/* 5957 */     rowVal[10] = s2b("false");
/* 5958 */     rowVal[11] = s2b("true");
/* 5959 */     rowVal[12] = s2b("REAL");
/* 5960 */     rowVal[13] = s2b("-308");
/* 5961 */     rowVal[14] = s2b("308");
/* 5962 */     rowVal[15] = s2b("0");
/* 5963 */     rowVal[16] = s2b("0");
/* 5964 */     rowVal[17] = s2b("10");
/* 5965 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5970 */     rowVal = new byte[18][];
/* 5971 */     rowVal[0] = s2b("VARCHAR");
/* 5972 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */     
/*      */ 
/* 5975 */     rowVal[2] = s2b("255");
/* 5976 */     rowVal[3] = s2b("'");
/* 5977 */     rowVal[4] = s2b("'");
/* 5978 */     rowVal[5] = s2b("(M)");
/* 5979 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5982 */     rowVal[7] = s2b("false");
/* 5983 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 5986 */     rowVal[9] = s2b("false");
/* 5987 */     rowVal[10] = s2b("false");
/* 5988 */     rowVal[11] = s2b("false");
/* 5989 */     rowVal[12] = s2b("VARCHAR");
/* 5990 */     rowVal[13] = s2b("0");
/* 5991 */     rowVal[14] = s2b("0");
/* 5992 */     rowVal[15] = s2b("0");
/* 5993 */     rowVal[16] = s2b("0");
/* 5994 */     rowVal[17] = s2b("10");
/* 5995 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6000 */     rowVal = new byte[18][];
/* 6001 */     rowVal[0] = s2b("ENUM");
/* 6002 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */     
/*      */ 
/* 6005 */     rowVal[2] = s2b("65535");
/* 6006 */     rowVal[3] = s2b("'");
/* 6007 */     rowVal[4] = s2b("'");
/* 6008 */     rowVal[5] = s2b("");
/* 6009 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 6012 */     rowVal[7] = s2b("false");
/* 6013 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 6016 */     rowVal[9] = s2b("false");
/* 6017 */     rowVal[10] = s2b("false");
/* 6018 */     rowVal[11] = s2b("false");
/* 6019 */     rowVal[12] = s2b("ENUM");
/* 6020 */     rowVal[13] = s2b("0");
/* 6021 */     rowVal[14] = s2b("0");
/* 6022 */     rowVal[15] = s2b("0");
/* 6023 */     rowVal[16] = s2b("0");
/* 6024 */     rowVal[17] = s2b("10");
/* 6025 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6030 */     rowVal = new byte[18][];
/* 6031 */     rowVal[0] = s2b("SET");
/* 6032 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */     
/*      */ 
/* 6035 */     rowVal[2] = s2b("64");
/* 6036 */     rowVal[3] = s2b("'");
/* 6037 */     rowVal[4] = s2b("'");
/* 6038 */     rowVal[5] = s2b("");
/* 6039 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 6042 */     rowVal[7] = s2b("false");
/* 6043 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 6046 */     rowVal[9] = s2b("false");
/* 6047 */     rowVal[10] = s2b("false");
/* 6048 */     rowVal[11] = s2b("false");
/* 6049 */     rowVal[12] = s2b("SET");
/* 6050 */     rowVal[13] = s2b("0");
/* 6051 */     rowVal[14] = s2b("0");
/* 6052 */     rowVal[15] = s2b("0");
/* 6053 */     rowVal[16] = s2b("0");
/* 6054 */     rowVal[17] = s2b("10");
/* 6055 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6060 */     rowVal = new byte[18][];
/* 6061 */     rowVal[0] = s2b("DATE");
/* 6062 */     rowVal[1] = Integer.toString(91).getBytes();
/*      */     
/*      */ 
/* 6065 */     rowVal[2] = s2b("0");
/* 6066 */     rowVal[3] = s2b("'");
/* 6067 */     rowVal[4] = s2b("'");
/* 6068 */     rowVal[5] = s2b("");
/* 6069 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 6072 */     rowVal[7] = s2b("false");
/* 6073 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 6076 */     rowVal[9] = s2b("false");
/* 6077 */     rowVal[10] = s2b("false");
/* 6078 */     rowVal[11] = s2b("false");
/* 6079 */     rowVal[12] = s2b("DATE");
/* 6080 */     rowVal[13] = s2b("0");
/* 6081 */     rowVal[14] = s2b("0");
/* 6082 */     rowVal[15] = s2b("0");
/* 6083 */     rowVal[16] = s2b("0");
/* 6084 */     rowVal[17] = s2b("10");
/* 6085 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6090 */     rowVal = new byte[18][];
/* 6091 */     rowVal[0] = s2b("TIME");
/* 6092 */     rowVal[1] = Integer.toString(92).getBytes();
/*      */     
/*      */ 
/* 6095 */     rowVal[2] = s2b("0");
/* 6096 */     rowVal[3] = s2b("'");
/* 6097 */     rowVal[4] = s2b("'");
/* 6098 */     rowVal[5] = s2b("");
/* 6099 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 6102 */     rowVal[7] = s2b("false");
/* 6103 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 6106 */     rowVal[9] = s2b("false");
/* 6107 */     rowVal[10] = s2b("false");
/* 6108 */     rowVal[11] = s2b("false");
/* 6109 */     rowVal[12] = s2b("TIME");
/* 6110 */     rowVal[13] = s2b("0");
/* 6111 */     rowVal[14] = s2b("0");
/* 6112 */     rowVal[15] = s2b("0");
/* 6113 */     rowVal[16] = s2b("0");
/* 6114 */     rowVal[17] = s2b("10");
/* 6115 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6120 */     rowVal = new byte[18][];
/* 6121 */     rowVal[0] = s2b("DATETIME");
/* 6122 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */     
/*      */ 
/* 6125 */     rowVal[2] = s2b("0");
/* 6126 */     rowVal[3] = s2b("'");
/* 6127 */     rowVal[4] = s2b("'");
/* 6128 */     rowVal[5] = s2b("");
/* 6129 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 6132 */     rowVal[7] = s2b("false");
/* 6133 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 6136 */     rowVal[9] = s2b("false");
/* 6137 */     rowVal[10] = s2b("false");
/* 6138 */     rowVal[11] = s2b("false");
/* 6139 */     rowVal[12] = s2b("DATETIME");
/* 6140 */     rowVal[13] = s2b("0");
/* 6141 */     rowVal[14] = s2b("0");
/* 6142 */     rowVal[15] = s2b("0");
/* 6143 */     rowVal[16] = s2b("0");
/* 6144 */     rowVal[17] = s2b("10");
/* 6145 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6150 */     rowVal = new byte[18][];
/* 6151 */     rowVal[0] = s2b("TIMESTAMP");
/* 6152 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */     
/*      */ 
/* 6155 */     rowVal[2] = s2b("0");
/* 6156 */     rowVal[3] = s2b("'");
/* 6157 */     rowVal[4] = s2b("'");
/* 6158 */     rowVal[5] = s2b("[(M)]");
/* 6159 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 6162 */     rowVal[7] = s2b("false");
/* 6163 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 6166 */     rowVal[9] = s2b("false");
/* 6167 */     rowVal[10] = s2b("false");
/* 6168 */     rowVal[11] = s2b("false");
/* 6169 */     rowVal[12] = s2b("TIMESTAMP");
/* 6170 */     rowVal[13] = s2b("0");
/* 6171 */     rowVal[14] = s2b("0");
/* 6172 */     rowVal[15] = s2b("0");
/* 6173 */     rowVal[16] = s2b("0");
/* 6174 */     rowVal[17] = s2b("10");
/* 6175 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 6177 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types)
/*      */     throws SQLException
/*      */   {
/* 6218 */     Field[] fields = new Field[7];
/* 6219 */     fields[0] = new Field("", "TYPE_CAT", 12, 32);
/* 6220 */     fields[1] = new Field("", "TYPE_SCHEM", 12, 32);
/* 6221 */     fields[2] = new Field("", "TYPE_NAME", 12, 32);
/* 6222 */     fields[3] = new Field("", "CLASS_NAME", 12, 32);
/* 6223 */     fields[4] = new Field("", "DATA_TYPE", 4, 10);
/* 6224 */     fields[5] = new Field("", "REMARKS", 12, 32);
/* 6225 */     fields[6] = new Field("", "BASE_TYPE", 5, 10);
/*      */     
/* 6227 */     ArrayList<ResultSetRow> tuples = new ArrayList();
/*      */     
/* 6229 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getURL()
/*      */     throws SQLException
/*      */   {
/* 6239 */     return this.conn.getURL();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserName()
/*      */     throws SQLException
/*      */   {
/* 6249 */     if (this.conn.getUseHostsInPrivileges()) {
/* 6250 */       java.sql.Statement stmt = null;
/* 6251 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 6254 */         stmt = this.conn.getMetadataSafeStatement();
/*      */         
/* 6256 */         rs = stmt.executeQuery("SELECT USER()");
/* 6257 */         rs.next();
/*      */         
/* 6259 */         return rs.getString(1);
/*      */       } finally {
/* 6261 */         if (rs != null) {
/*      */           try {
/* 6263 */             rs.close();
/*      */           } catch (Exception ex) {
/* 6265 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           }
/*      */           
/* 6268 */           rs = null;
/*      */         }
/*      */         
/* 6271 */         if (stmt != null) {
/*      */           try {
/* 6273 */             stmt.close();
/*      */           } catch (Exception ex) {
/* 6275 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           }
/*      */           
/* 6278 */           stmt = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 6283 */     return this.conn.getUser();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getVersionColumns(String catalog, String schema, final String table)
/*      */     throws SQLException
/*      */   {
/* 6320 */     if (table == null) {
/* 6321 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 6324 */     Field[] fields = new Field[8];
/* 6325 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 6326 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 6327 */     fields[2] = new Field("", "DATA_TYPE", 4, 5);
/* 6328 */     fields[3] = new Field("", "TYPE_NAME", 1, 16);
/* 6329 */     fields[4] = new Field("", "COLUMN_SIZE", 4, 16);
/* 6330 */     fields[5] = new Field("", "BUFFER_LENGTH", 4, 16);
/* 6331 */     fields[6] = new Field("", "DECIMAL_DIGITS", 5, 16);
/* 6332 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */     
/* 6334 */     final ArrayList<ResultSetRow> rows = new ArrayList();
/*      */     
/* 6336 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 6340 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(String catalogStr) throws SQLException
/*      */         {
/* 6344 */           ResultSet results = null;
/* 6345 */           boolean with_where = DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 0);
/*      */           try
/*      */           {
/* 6348 */             StringBuilder whereBuf = new StringBuilder(" Extra LIKE '%on update CURRENT_TIMESTAMP%'");
/* 6349 */             List<String> rsFields = new ArrayList();
/*      */             
/*      */ 
/*      */ 
/* 6353 */             if (!DatabaseMetaData.this.conn.versionMeetsMinimum(5, 1, 23))
/*      */             {
/* 6355 */               whereBuf = new StringBuilder();
/* 6356 */               boolean firstTime = true;
/*      */               
/* 6358 */               String query = "SHOW CREATE TABLE " + DatabaseMetaData.this.getFullyQualifiedName(catalogStr, table);
/*      */               
/* 6360 */               results = stmt.executeQuery(query);
/* 6361 */               while (results.next()) {
/* 6362 */                 String createTableString = results.getString(2);
/* 6363 */                 StringTokenizer lineTokenizer = new StringTokenizer(createTableString, "\n");
/*      */                 
/* 6365 */                 while (lineTokenizer.hasMoreTokens()) {
/* 6366 */                   String line = lineTokenizer.nextToken().trim();
/* 6367 */                   if (StringUtils.indexOfIgnoreCase(line, "on update CURRENT_TIMESTAMP") > -1) {
/* 6368 */                     boolean usingBackTicks = true;
/* 6369 */                     int beginPos = line.indexOf(DatabaseMetaData.this.quotedId);
/*      */                     
/* 6371 */                     if (beginPos == -1) {
/* 6372 */                       beginPos = line.indexOf("\"");
/* 6373 */                       usingBackTicks = false;
/*      */                     }
/*      */                     
/* 6376 */                     if (beginPos != -1) {
/* 6377 */                       int endPos = -1;
/*      */                       
/* 6379 */                       if (usingBackTicks) {
/* 6380 */                         endPos = line.indexOf(DatabaseMetaData.this.quotedId, beginPos + 1);
/*      */                       } else {
/* 6382 */                         endPos = line.indexOf("\"", beginPos + 1);
/*      */                       }
/*      */                       
/* 6385 */                       if (endPos != -1) {
/* 6386 */                         if (with_where) {
/* 6387 */                           if (!firstTime) {
/* 6388 */                             whereBuf.append(" or");
/*      */                           } else {
/* 6390 */                             firstTime = false;
/*      */                           }
/* 6392 */                           whereBuf.append(" Field='");
/* 6393 */                           whereBuf.append(line.substring(beginPos + 1, endPos));
/* 6394 */                           whereBuf.append("'");
/*      */                         } else {
/* 6396 */                           rsFields.add(line.substring(beginPos + 1, endPos));
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 6405 */             if ((whereBuf.length() > 0) || (rsFields.size() > 0)) {
/* 6406 */               StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
/* 6407 */               queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 6408 */               queryBuf.append(" FROM ");
/* 6409 */               queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 6410 */               if (with_where) {
/* 6411 */                 queryBuf.append(" WHERE");
/* 6412 */                 queryBuf.append(whereBuf.toString());
/*      */               }
/*      */               
/* 6415 */               results = stmt.executeQuery(queryBuf.toString());
/*      */               
/* 6417 */               while (results.next()) {
/* 6418 */                 if ((with_where) || (rsFields.contains(results.getString("Field")))) {
/* 6419 */                   DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(DatabaseMetaData.this, results.getString("Type"), results.getString("Null"));
/* 6420 */                   byte[][] rowVal = new byte[8][];
/*      */                   
/* 6422 */                   rowVal[0] = null;
/*      */                   
/* 6424 */                   rowVal[1] = results.getBytes("Field");
/*      */                   
/* 6426 */                   rowVal[2] = Short.toString(typeDesc.dataType).getBytes();
/*      */                   
/* 6428 */                   rowVal[3] = DatabaseMetaData.this.s2b(typeDesc.typeName);
/*      */                   
/* 6430 */                   rowVal[4] = (typeDesc.columnSize == null ? null : DatabaseMetaData.this.s2b(typeDesc.columnSize.toString()));
/*      */                   
/* 6432 */                   rowVal[5] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.bufferLength));
/*      */                   
/* 6434 */                   rowVal[6] = (typeDesc.decimalDigits == null ? null : DatabaseMetaData.this.s2b(typeDesc.decimalDigits.toString()));
/*      */                   
/* 6436 */                   rowVal[7] = Integer.toString(1).getBytes();
/*      */                   
/* 6438 */                   rows.add(new ByteArrayRow(rowVal, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                 }
/*      */               }
/*      */             }
/*      */           } catch (SQLException sqlEx) {
/* 6443 */             if (!"42S02".equals(sqlEx.getSQLState())) {
/* 6444 */               throw sqlEx;
/*      */             }
/*      */           } finally {
/* 6447 */             if (results != null) {
/*      */               try {
/* 6449 */                 results.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/* 6453 */               results = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     }
/*      */     finally {
/* 6460 */       if (stmt != null) {
/* 6461 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 6465 */     return buildResultSet(fields, rows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean insertsAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/* 6479 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCatalogAtStart()
/*      */     throws SQLException
/*      */   {
/* 6490 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/* 6500 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean locatorsUpdateCopy()
/*      */     throws SQLException
/*      */   {
/* 6507 */     return !this.conn.getEmulateLocators();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullPlusNonNullIsNull()
/*      */     throws SQLException
/*      */   {
/* 6518 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedAtEnd()
/*      */     throws SQLException
/*      */   {
/* 6528 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedAtStart()
/*      */     throws SQLException
/*      */   {
/* 6538 */     return (this.conn.versionMeetsMinimum(4, 0, 2)) && (!this.conn.versionMeetsMinimum(4, 0, 11));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedHigh()
/*      */     throws SQLException
/*      */   {
/* 6548 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedLow()
/*      */     throws SQLException
/*      */   {
/* 6558 */     return !nullsAreSortedHigh();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean othersDeletesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6566 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean othersInsertsAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6574 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean othersUpdatesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6587 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean ownDeletesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6595 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean ownInsertsAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6603 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean ownUpdatesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6616 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected LocalAndReferencedColumns parseTableStatusIntoLocalAndReferencedColumns(String keysComment)
/*      */     throws SQLException
/*      */   {
/* 6631 */     String columnsDelimitter = ",";
/*      */     
/* 6633 */     int indexOfOpenParenLocalColumns = StringUtils.indexOfIgnoreCase(0, keysComment, "(", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */     
/* 6635 */     if (indexOfOpenParenLocalColumns == -1) {
/* 6636 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of local columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 6640 */     String constraintName = StringUtils.unQuoteIdentifier(keysComment.substring(0, indexOfOpenParenLocalColumns).trim(), this.quotedId);
/* 6641 */     keysComment = keysComment.substring(indexOfOpenParenLocalColumns, keysComment.length());
/*      */     
/* 6643 */     String keysCommentTrimmed = keysComment.trim();
/*      */     
/* 6645 */     int indexOfCloseParenLocalColumns = StringUtils.indexOfIgnoreCase(0, keysCommentTrimmed, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */     
/*      */ 
/* 6648 */     if (indexOfCloseParenLocalColumns == -1) {
/* 6649 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of local columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 6653 */     String localColumnNamesString = keysCommentTrimmed.substring(1, indexOfCloseParenLocalColumns);
/*      */     
/* 6655 */     int indexOfRefer = StringUtils.indexOfIgnoreCase(0, keysCommentTrimmed, "REFER ", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */     
/* 6657 */     if (indexOfRefer == -1) {
/* 6658 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced tables list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 6662 */     int indexOfOpenParenReferCol = StringUtils.indexOfIgnoreCase(indexOfRefer, keysCommentTrimmed, "(", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */     
/*      */ 
/* 6665 */     if (indexOfOpenParenReferCol == -1) {
/* 6666 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 6670 */     String referCatalogTableString = keysCommentTrimmed.substring(indexOfRefer + "REFER ".length(), indexOfOpenParenReferCol);
/*      */     
/* 6672 */     int indexOfSlash = StringUtils.indexOfIgnoreCase(0, referCatalogTableString, "/", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */     
/* 6674 */     if (indexOfSlash == -1) {
/* 6675 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find name of referenced catalog.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 6679 */     String referCatalog = StringUtils.unQuoteIdentifier(referCatalogTableString.substring(0, indexOfSlash), this.quotedId);
/* 6680 */     String referTable = StringUtils.unQuoteIdentifier(referCatalogTableString.substring(indexOfSlash + 1).trim(), this.quotedId);
/*      */     
/* 6682 */     int indexOfCloseParenRefer = StringUtils.indexOfIgnoreCase(indexOfOpenParenReferCol, keysCommentTrimmed, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */     
/*      */ 
/* 6685 */     if (indexOfCloseParenRefer == -1) {
/* 6686 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of referenced columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 6690 */     String referColumnNamesString = keysCommentTrimmed.substring(indexOfOpenParenReferCol + 1, indexOfCloseParenRefer);
/*      */     
/* 6692 */     List<String> referColumnsList = StringUtils.split(referColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/* 6693 */     List<String> localColumnsList = StringUtils.split(localColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/*      */     
/* 6695 */     return new LocalAndReferencedColumns(localColumnsList, referColumnsList, constraintName, referCatalog, referTable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] s2b(String s)
/*      */     throws SQLException
/*      */   {
/* 6705 */     if (s == null) {
/* 6706 */       return null;
/*      */     }
/*      */     
/* 6709 */     return StringUtils.getBytes(s, this.conn.getCharacterSetMetadata(), this.conn.getServerCharset(), this.conn.parserKnowsUnicode(), this.conn, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesLowerCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6721 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesLowerCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6732 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesMixedCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6743 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesMixedCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6754 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesUpperCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6765 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesUpperCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6776 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsAlterTableWithAddColumn()
/*      */     throws SQLException
/*      */   {
/* 6786 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsAlterTableWithDropColumn()
/*      */     throws SQLException
/*      */   {
/* 6796 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsANSI92EntryLevelSQL()
/*      */     throws SQLException
/*      */   {
/* 6807 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsANSI92FullSQL()
/*      */     throws SQLException
/*      */   {
/* 6817 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsANSI92IntermediateSQL()
/*      */     throws SQLException
/*      */   {
/* 6827 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsBatchUpdates()
/*      */     throws SQLException
/*      */   {
/* 6837 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInDataManipulation()
/*      */     throws SQLException
/*      */   {
/* 6848 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInIndexDefinitions()
/*      */     throws SQLException
/*      */   {
/* 6859 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions()
/*      */     throws SQLException
/*      */   {
/* 6870 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInProcedureCalls()
/*      */     throws SQLException
/*      */   {
/* 6881 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInTableDefinitions()
/*      */     throws SQLException
/*      */   {
/* 6892 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsColumnAliasing()
/*      */     throws SQLException
/*      */   {
/* 6906 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsConvert()
/*      */     throws SQLException
/*      */   {
/* 6916 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsConvert(int fromType, int toType)
/*      */     throws SQLException
/*      */   {
/* 6932 */     switch (fromType)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 12: 
/* 6943 */       switch (toType) {
/*      */       case -6: 
/*      */       case -5: 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 7: 
/*      */       case 8: 
/*      */       case 12: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 1111: 
/* 6963 */         return true;
/*      */       }
/*      */       
/* 6966 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -7: 
/* 6973 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 6988 */       switch (toType) {
/*      */       case -6: 
/*      */       case -5: 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 7: 
/*      */       case 8: 
/*      */       case 12: 
/* 7004 */         return true;
/*      */       }
/*      */       
/* 7007 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */     case 0: 
/* 7012 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1111: 
/* 7019 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 7026 */         return true;
/*      */       }
/*      */       
/* 7029 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 91: 
/* 7035 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 7042 */         return true;
/*      */       }
/*      */       
/* 7045 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 92: 
/* 7051 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 7058 */         return true;
/*      */       }
/*      */       
/* 7061 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 93: 
/* 7069 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/*      */       case 91: 
/*      */       case 92: 
/* 7078 */         return true;
/*      */       }
/*      */       
/* 7081 */       return false;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 7086 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCoreSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 7097 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCorrelatedSubqueries()
/*      */     throws SQLException
/*      */   {
/* 7108 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions()
/*      */     throws SQLException
/*      */   {
/* 7119 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsDataManipulationTransactionsOnly()
/*      */     throws SQLException
/*      */   {
/* 7129 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsDifferentTableCorrelationNames()
/*      */     throws SQLException
/*      */   {
/* 7141 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsExpressionsInOrderBy()
/*      */     throws SQLException
/*      */   {
/* 7151 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsExtendedSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 7161 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsFullOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 7171 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsGetGeneratedKeys()
/*      */   {
/* 7178 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGroupBy()
/*      */     throws SQLException
/*      */   {
/* 7188 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGroupByBeyondSelect()
/*      */     throws SQLException
/*      */   {
/* 7199 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGroupByUnrelated()
/*      */     throws SQLException
/*      */   {
/* 7209 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsIntegrityEnhancementFacility()
/*      */     throws SQLException
/*      */   {
/* 7219 */     if (!this.conn.getOverrideSupportsIntegrityEnhancementFacility()) {
/* 7220 */       return false;
/*      */     }
/*      */     
/* 7223 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsLikeEscapeClause()
/*      */     throws SQLException
/*      */   {
/* 7234 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsLimitedOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 7245 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMinimumSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 7256 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMixedCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7266 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMixedCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7277 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean supportsMultipleOpenResults()
/*      */     throws SQLException
/*      */   {
/* 7284 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMultipleResultSets()
/*      */     throws SQLException
/*      */   {
/* 7294 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMultipleTransactions()
/*      */     throws SQLException
/*      */   {
/* 7305 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean supportsNamedParameters()
/*      */     throws SQLException
/*      */   {
/* 7312 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsNonNullableColumns()
/*      */     throws SQLException
/*      */   {
/* 7323 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossCommit()
/*      */     throws SQLException
/*      */   {
/* 7335 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossRollback()
/*      */     throws SQLException
/*      */   {
/* 7347 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenStatementsAcrossCommit()
/*      */     throws SQLException
/*      */   {
/* 7359 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenStatementsAcrossRollback()
/*      */     throws SQLException
/*      */   {
/* 7371 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOrderByUnrelated()
/*      */     throws SQLException
/*      */   {
/* 7381 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 7391 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsPositionedDelete()
/*      */     throws SQLException
/*      */   {
/* 7401 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsPositionedUpdate()
/*      */     throws SQLException
/*      */   {
/* 7411 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsResultSetConcurrency(int type, int concurrency)
/*      */     throws SQLException
/*      */   {
/* 7428 */     switch (type) {
/*      */     case 1004: 
/* 7430 */       if ((concurrency == 1007) || (concurrency == 1008)) {
/* 7431 */         return true;
/*      */       }
/* 7433 */       throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */     
/*      */ 
/*      */     case 1003: 
/* 7437 */       if ((concurrency == 1007) || (concurrency == 1008)) {
/* 7438 */         return true;
/*      */       }
/* 7440 */       throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */     
/*      */ 
/*      */     case 1005: 
/* 7444 */       return false;
/*      */     }
/* 7446 */     throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsResultSetHoldability(int holdability)
/*      */     throws SQLException
/*      */   {
/* 7456 */     return holdability == 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsResultSetType(int type)
/*      */     throws SQLException
/*      */   {
/* 7470 */     return type == 1004;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsSavepoints()
/*      */     throws SQLException
/*      */   {
/* 7478 */     return (this.conn.versionMeetsMinimum(4, 0, 14)) || (this.conn.versionMeetsMinimum(4, 1, 1));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInDataManipulation()
/*      */     throws SQLException
/*      */   {
/* 7488 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInIndexDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7498 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInPrivilegeDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7508 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInProcedureCalls()
/*      */     throws SQLException
/*      */   {
/* 7518 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInTableDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7528 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSelectForUpdate()
/*      */     throws SQLException
/*      */   {
/* 7538 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean supportsStatementPooling()
/*      */     throws SQLException
/*      */   {
/* 7545 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsStoredProcedures()
/*      */     throws SQLException
/*      */   {
/* 7556 */     return this.conn.versionMeetsMinimum(5, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInComparisons()
/*      */     throws SQLException
/*      */   {
/* 7567 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInExists()
/*      */     throws SQLException
/*      */   {
/* 7578 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInIns()
/*      */     throws SQLException
/*      */   {
/* 7589 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInQuantifieds()
/*      */     throws SQLException
/*      */   {
/* 7600 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsTableCorrelationNames()
/*      */     throws SQLException
/*      */   {
/* 7611 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsTransactionIsolationLevel(int level)
/*      */     throws SQLException
/*      */   {
/* 7625 */     if (this.conn.supportsIsolationLevel()) {
/* 7626 */       switch (level) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 4: 
/*      */       case 8: 
/* 7631 */         return true;
/*      */       }
/*      */       
/* 7634 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 7638 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsTransactions()
/*      */     throws SQLException
/*      */   {
/* 7649 */     return this.conn.supportsTransactions();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsUnion()
/*      */     throws SQLException
/*      */   {
/* 7659 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsUnionAll()
/*      */     throws SQLException
/*      */   {
/* 7669 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean updatesAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/* 7683 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean usesLocalFilePerTable()
/*      */     throws SQLException
/*      */   {
/* 7693 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean usesLocalFiles()
/*      */     throws SQLException
/*      */   {
/* 7703 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getClientInfoProperties()
/*      */     throws SQLException
/*      */   {
/* 7735 */     Field[] fields = new Field[4];
/* 7736 */     fields[0] = new Field("", "NAME", 12, 255);
/* 7737 */     fields[1] = new Field("", "MAX_LEN", 4, 10);
/* 7738 */     fields[2] = new Field("", "DEFAULT_VALUE", 12, 255);
/* 7739 */     fields[3] = new Field("", "DESCRIPTION", 12, 255);
/*      */     
/* 7741 */     return buildResultSet(fields, new ArrayList(), this.conn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 7752 */     Field[] fields = createFunctionColumnsFields();
/*      */     
/* 7754 */     return getProcedureOrFunctionColumns(fields, catalog, schemaPattern, functionNamePattern, columnNamePattern, false, true);
/*      */   }
/*      */   
/*      */   protected Field[] createFunctionColumnsFields() {
/* 7758 */     Field[] fields = { new Field("", "FUNCTION_CAT", 12, 512), new Field("", "FUNCTION_SCHEM", 12, 512), new Field("", "FUNCTION_NAME", 12, 512), new Field("", "COLUMN_NAME", 12, 512), new Field("", "COLUMN_TYPE", 12, 64), new Field("", "DATA_TYPE", 5, 6), new Field("", "TYPE_NAME", 12, 64), new Field("", "PRECISION", 4, 12), new Field("", "LENGTH", 4, 12), new Field("", "SCALE", 5, 12), new Field("", "RADIX", 5, 6), new Field("", "NULLABLE", 5, 6), new Field("", "REMARKS", 12, 512), new Field("", "CHAR_OCTET_LENGTH", 4, 32), new Field("", "ORDINAL_POSITION", 4, 32), new Field("", "IS_NULLABLE", 12, 12), new Field("", "SPECIFIC_NAME", 12, 64) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7765 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern)
/*      */     throws SQLException
/*      */   {
/* 7813 */     Field[] fields = new Field[6];
/*      */     
/* 7815 */     fields[0] = new Field("", "FUNCTION_CAT", 1, 255);
/* 7816 */     fields[1] = new Field("", "FUNCTION_SCHEM", 1, 255);
/* 7817 */     fields[2] = new Field("", "FUNCTION_NAME", 1, 255);
/* 7818 */     fields[3] = new Field("", "REMARKS", 1, 255);
/* 7819 */     fields[4] = new Field("", "FUNCTION_TYPE", 5, 6);
/* 7820 */     fields[5] = new Field("", "SPECIFIC_NAME", 1, 255);
/*      */     
/* 7822 */     return getProceduresAndOrFunctions(fields, catalog, schemaPattern, functionNamePattern, false, true);
/*      */   }
/*      */   
/*      */   public boolean providesQueryObjectGenerator() throws SQLException {
/* 7826 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSchemas(String catalog, String schemaPattern)
/*      */     throws SQLException
/*      */   {
/* 7835 */     Field[] fields = { new Field("", "TABLE_SCHEM", 12, 255), new Field("", "TABLE_CATALOG", 12, 255) };
/*      */     
/* 7837 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException {
/* 7841 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PreparedStatement prepareMetaDataSafeStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 7852 */     PreparedStatement pStmt = this.conn.clientPrepareStatement(sql);
/*      */     
/* 7854 */     if (pStmt.getMaxRows() != 0) {
/* 7855 */       pStmt.setMaxRows(0);
/*      */     }
/*      */     
/* 7858 */     ((Statement)pStmt).setHoldResultsOpenOverClose(true);
/*      */     
/* 7860 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 7873 */     Field[] fields = { new Field("", "TABLE_CAT", 12, 512), new Field("", "TABLE_SCHEM", 12, 512), new Field("", "TABLE_NAME", 12, 512), new Field("", "COLUMN_NAME", 12, 512), new Field("", "DATA_TYPE", 4, 12), new Field("", "COLUMN_SIZE", 4, 12), new Field("", "DECIMAL_DIGITS", 4, 12), new Field("", "NUM_PREC_RADIX", 4, 12), new Field("", "COLUMN_USAGE", 12, 512), new Field("", "REMARKS", 12, 512), new Field("", "CHAR_OCTET_LENGTH", 4, 12), new Field("", "IS_NULLABLE", 12, 512) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7880 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */   public boolean generatedKeyAlwaysReturned() throws SQLException
/*      */   {
/* 7885 */     return true;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/DatabaseMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */