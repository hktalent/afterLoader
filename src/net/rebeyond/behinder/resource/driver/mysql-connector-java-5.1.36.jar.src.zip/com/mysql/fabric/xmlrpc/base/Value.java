/*     */ package com.mysql.fabric.xmlrpc.base;
/*     */ 
/*     */ import java.util.GregorianCalendar;
/*     */ import javax.xml.datatype.DatatypeConfigurationException;
/*     */ import javax.xml.datatype.DatatypeFactory;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Value
/*     */ {
/*     */   public static final byte TYPE_i4 = 0;
/*     */   public static final byte TYPE_int = 1;
/*     */   public static final byte TYPE_boolean = 2;
/*     */   public static final byte TYPE_string = 3;
/*     */   public static final byte TYPE_double = 4;
/*     */   public static final byte TYPE_dateTime_iso8601 = 5;
/*     */   public static final byte TYPE_base64 = 6;
/*     */   public static final byte TYPE_struct = 7;
/*     */   public static final byte TYPE_array = 8;
/*  44 */   protected Object objValue = "";
/*  45 */   protected byte objType = 3;
/*  46 */   private DatatypeFactory dtf = null;
/*     */   
/*     */   public Value() {}
/*     */   
/*     */   public Value(int value)
/*     */   {
/*  52 */     setInt(value);
/*     */   }
/*     */   
/*     */   public Value(String value) {
/*  56 */     setString(value);
/*     */   }
/*     */   
/*     */   public Value(boolean value) {
/*  60 */     setBoolean(value);
/*     */   }
/*     */   
/*     */   public Value(double value) {
/*  64 */     setDouble(value);
/*     */   }
/*     */   
/*     */   public Value(GregorianCalendar value) throws DatatypeConfigurationException {
/*  68 */     setDateTime(value);
/*     */   }
/*     */   
/*     */   public Value(byte[] value) {
/*  72 */     setBase64(value);
/*     */   }
/*     */   
/*     */   public Value(Struct value) {
/*  76 */     setStruct(value);
/*     */   }
/*     */   
/*     */   public Value(Array value) {
/*  80 */     setArray(value);
/*     */   }
/*     */   
/*     */   public Object getValue() {
/*  84 */     return this.objValue;
/*     */   }
/*     */   
/*     */   public byte getType() {
/*  88 */     return this.objType;
/*     */   }
/*     */   
/*     */   public void setInt(int value) {
/*  92 */     this.objValue = Integer.valueOf(value);
/*  93 */     this.objType = 1;
/*     */   }
/*     */   
/*     */   public void setInt(String value) {
/*  97 */     this.objValue = Integer.valueOf(value);
/*  98 */     this.objType = 1;
/*     */   }
/*     */   
/*     */   public void setString(String value) {
/* 102 */     this.objValue = value;
/* 103 */     this.objType = 3;
/*     */   }
/*     */   
/*     */   public void appendString(String value) {
/* 107 */     this.objValue = (this.objValue != null ? this.objValue + value : value);
/* 108 */     this.objType = 3;
/*     */   }
/*     */   
/*     */   public void setBoolean(boolean value) {
/* 112 */     this.objValue = Boolean.valueOf(value);
/* 113 */     this.objType = 2;
/*     */   }
/*     */   
/*     */   public void setBoolean(String value) {
/* 117 */     if ((value.trim().equals("1")) || (value.trim().equalsIgnoreCase("true"))) {
/* 118 */       this.objValue = Boolean.valueOf(true);
/*     */     } else {
/* 120 */       this.objValue = Boolean.valueOf(false);
/*     */     }
/* 122 */     this.objType = 2;
/*     */   }
/*     */   
/*     */   public void setDouble(double value) {
/* 126 */     this.objValue = Double.valueOf(value);
/* 127 */     this.objType = 4;
/*     */   }
/*     */   
/*     */   public void setDouble(String value) {
/* 131 */     this.objValue = Double.valueOf(value);
/* 132 */     this.objType = 4;
/*     */   }
/*     */   
/*     */   public void setDateTime(GregorianCalendar value) throws DatatypeConfigurationException {
/* 136 */     if (this.dtf == null) {
/* 137 */       this.dtf = DatatypeFactory.newInstance();
/*     */     }
/* 139 */     this.objValue = this.dtf.newXMLGregorianCalendar(value);
/* 140 */     this.objType = 5;
/*     */   }
/*     */   
/*     */   public void setDateTime(String value) throws DatatypeConfigurationException {
/* 144 */     if (this.dtf == null) {
/* 145 */       this.dtf = DatatypeFactory.newInstance();
/*     */     }
/* 147 */     this.objValue = this.dtf.newXMLGregorianCalendar(value);
/* 148 */     this.objType = 5;
/*     */   }
/*     */   
/*     */   public void setBase64(byte[] value) {
/* 152 */     this.objValue = value;
/* 153 */     this.objType = 6;
/*     */   }
/*     */   
/*     */   public void setStruct(Struct value) {
/* 157 */     this.objValue = value;
/* 158 */     this.objType = 7;
/*     */   }
/*     */   
/*     */   public void setArray(Array value) {
/* 162 */     this.objValue = value;
/* 163 */     this.objType = 8;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 168 */     StringBuilder sb = new StringBuilder("<value>");
/* 169 */     switch (this.objType) {
/*     */     case 0: 
/* 171 */       sb.append("<i4>" + ((Integer)this.objValue).toString() + "</i4>");
/* 172 */       break;
/*     */     case 1: 
/* 174 */       sb.append("<int>" + ((Integer)this.objValue).toString() + "</int>");
/* 175 */       break;
/*     */     
/*     */     case 2: 
/* 178 */       sb.append("<boolean>" + (((Boolean)this.objValue).booleanValue() ? 1 : 0) + "</boolean>");
/* 179 */       break;
/*     */     
/*     */     case 4: 
/* 182 */       sb.append("<double>" + ((Double)this.objValue).toString() + "</double>");
/* 183 */       break;
/*     */     
/*     */     case 5: 
/* 186 */       sb.append("<dateTime.iso8601>" + ((XMLGregorianCalendar)this.objValue).toString() + "</dateTime.iso8601>");
/* 187 */       break;
/*     */     
/*     */     case 6: 
/* 190 */       sb.append("<base64>" + ((byte[])this.objValue).toString() + "</base64>");
/* 191 */       break;
/*     */     
/*     */     case 7: 
/* 194 */       sb.append(((Struct)this.objValue).toString());
/* 195 */       break;
/*     */     
/*     */     case 8: 
/* 198 */       sb.append(((Array)this.objValue).toString());
/* 199 */       break;
/*     */     case 3: 
/*     */     default: 
/* 202 */       sb.append("<string>" + escapeXMLChars(this.objValue.toString()) + "</string>");
/*     */     }
/* 204 */     sb.append("</value>");
/* 205 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private String escapeXMLChars(String s) {
/* 209 */     StringBuilder sb = new StringBuilder(s.length());
/*     */     
/* 211 */     for (int i = 0; i < s.length(); i++) {
/* 212 */       char c = s.charAt(i);
/* 213 */       switch (c) {
/*     */       case '&': 
/* 215 */         sb.append("&amp;");
/* 216 */         break;
/*     */       case '<': 
/* 218 */         sb.append("&lt;");
/* 219 */         break;
/*     */       case '>': 
/* 221 */         sb.append("&gt;");
/* 222 */         break;
/*     */       default: 
/* 224 */         sb.append(c);
/*     */       }
/*     */       
/*     */     }
/* 228 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/xmlrpc/base/Value.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */