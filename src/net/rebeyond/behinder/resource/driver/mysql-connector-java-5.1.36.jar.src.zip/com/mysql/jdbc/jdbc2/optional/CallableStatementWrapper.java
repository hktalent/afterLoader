/*      */ package com.mysql.jdbc.jdbc2.optional;
/*      */ 
/*      */ import com.mysql.jdbc.SQLError;
/*      */ import com.mysql.jdbc.Util;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CallableStatementWrapper
/*      */   extends PreparedStatementWrapper
/*      */   implements CallableStatement
/*      */ {
/*      */   private static final Constructor<?> JDBC_4_CALLABLE_STATEMENT_WRAPPER_CTOR;
/*      */   
/*      */   static
/*      */   {
/*   54 */     if (Util.isJdbc4()) {
/*      */       try {
/*   56 */         JDBC_4_CALLABLE_STATEMENT_WRAPPER_CTOR = Class.forName("com.mysql.jdbc.jdbc2.optional.JDBC4CallableStatementWrapper").getConstructor(new Class[] { ConnectionWrapper.class, MysqlPooledConnection.class, CallableStatement.class });
/*      */       }
/*      */       catch (SecurityException e) {
/*   59 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*   61 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*   63 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*   66 */       JDBC_4_CALLABLE_STATEMENT_WRAPPER_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static CallableStatementWrapper getInstance(ConnectionWrapper c, MysqlPooledConnection conn, CallableStatement toWrap) throws SQLException {
/*   71 */     if (!Util.isJdbc4()) {
/*   72 */       return new CallableStatementWrapper(c, conn, toWrap);
/*      */     }
/*      */     
/*   75 */     return (CallableStatementWrapper)Util.handleNewInstance(JDBC_4_CALLABLE_STATEMENT_WRAPPER_CTOR, new Object[] { c, conn, toWrap }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatementWrapper(ConnectionWrapper c, MysqlPooledConnection conn, CallableStatement toWrap)
/*      */   {
/*   85 */     super(c, conn, toWrap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*   95 */       if (this.wrappedStmt != null) {
/*   96 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterIndex, sqlType);
/*      */       } else {
/*   98 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  101 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  112 */       if (this.wrappedStmt != null) {
/*  113 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterIndex, sqlType, scale);
/*      */       } else {
/*  115 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  118 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  129 */       if (this.wrappedStmt != null) {
/*  130 */         return ((CallableStatement)this.wrappedStmt).wasNull();
/*      */       }
/*  132 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  135 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  138 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getString(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  148 */       if (this.wrappedStmt != null) {
/*  149 */         return ((CallableStatement)this.wrappedStmt).getString(parameterIndex);
/*      */       }
/*  151 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  154 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*  156 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  166 */       if (this.wrappedStmt != null) {
/*  167 */         return ((CallableStatement)this.wrappedStmt).getBoolean(parameterIndex);
/*      */       }
/*  169 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  172 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  175 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public byte getByte(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  185 */       if (this.wrappedStmt != null) {
/*  186 */         return ((CallableStatement)this.wrappedStmt).getByte(parameterIndex);
/*      */       }
/*  188 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  191 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  194 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public short getShort(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  204 */       if (this.wrappedStmt != null) {
/*  205 */         return ((CallableStatement)this.wrappedStmt).getShort(parameterIndex);
/*      */       }
/*  207 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  210 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  213 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getInt(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  223 */       if (this.wrappedStmt != null) {
/*  224 */         return ((CallableStatement)this.wrappedStmt).getInt(parameterIndex);
/*      */       }
/*  226 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  229 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  232 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public long getLong(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  242 */       if (this.wrappedStmt != null) {
/*  243 */         return ((CallableStatement)this.wrappedStmt).getLong(parameterIndex);
/*      */       }
/*  245 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  248 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  251 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public float getFloat(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  261 */       if (this.wrappedStmt != null) {
/*  262 */         return ((CallableStatement)this.wrappedStmt).getFloat(parameterIndex);
/*      */       }
/*  264 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  267 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  270 */     return 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public double getDouble(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  280 */       if (this.wrappedStmt != null) {
/*  281 */         return ((CallableStatement)this.wrappedStmt).getDouble(parameterIndex);
/*      */       }
/*  283 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  286 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  289 */     return 0.0D;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int parameterIndex, int scale)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  299 */       if (this.wrappedStmt != null) {
/*  300 */         return ((CallableStatement)this.wrappedStmt).getBigDecimal(parameterIndex, scale);
/*      */       }
/*  302 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  305 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  308 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  318 */       if (this.wrappedStmt != null) {
/*  319 */         return ((CallableStatement)this.wrappedStmt).getBytes(parameterIndex);
/*      */       }
/*  321 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  324 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  327 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Date getDate(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  337 */       if (this.wrappedStmt != null) {
/*  338 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterIndex);
/*      */       }
/*  340 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  343 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  346 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getTime(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  356 */       if (this.wrappedStmt != null) {
/*  357 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterIndex);
/*      */       }
/*  359 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  362 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  365 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  375 */       if (this.wrappedStmt != null) {
/*  376 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterIndex);
/*      */       }
/*  378 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  381 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  384 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  394 */       if (this.wrappedStmt != null) {
/*  395 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterIndex);
/*      */       }
/*  397 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  400 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  403 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  413 */       if (this.wrappedStmt != null) {
/*  414 */         return ((CallableStatement)this.wrappedStmt).getBigDecimal(parameterIndex);
/*      */       }
/*  416 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  419 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  422 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(int parameterIndex, Map<String, Class<?>> typeMap)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  432 */       if (this.wrappedStmt != null) {
/*  433 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterIndex, typeMap);
/*      */       }
/*  435 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  438 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*  440 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Ref getRef(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  450 */       if (this.wrappedStmt != null) {
/*  451 */         return ((CallableStatement)this.wrappedStmt).getRef(parameterIndex);
/*      */       }
/*  453 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  456 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  459 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Blob getBlob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  469 */       if (this.wrappedStmt != null) {
/*  470 */         return ((CallableStatement)this.wrappedStmt).getBlob(parameterIndex);
/*      */       }
/*  472 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  475 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  478 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Clob getClob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  488 */       if (this.wrappedStmt != null) {
/*  489 */         return ((CallableStatement)this.wrappedStmt).getClob(parameterIndex);
/*      */       }
/*  491 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  494 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*  496 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Array getArray(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  506 */       if (this.wrappedStmt != null) {
/*  507 */         return ((CallableStatement)this.wrappedStmt).getArray(parameterIndex);
/*      */       }
/*  509 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  512 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*  514 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Date getDate(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  524 */       if (this.wrappedStmt != null) {
/*  525 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterIndex, cal);
/*      */       }
/*  527 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  530 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*  532 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getTime(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  542 */       if (this.wrappedStmt != null) {
/*  543 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterIndex, cal);
/*      */       }
/*  545 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  548 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*  550 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  560 */       if (this.wrappedStmt != null) {
/*  561 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterIndex, cal);
/*      */       }
/*  563 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  566 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*  568 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int paramIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  578 */       if (this.wrappedStmt != null) {
/*  579 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(paramIndex, sqlType, typeName);
/*      */       } else {
/*  581 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  584 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  595 */       if (this.wrappedStmt != null) {
/*  596 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType);
/*      */       } else {
/*  598 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  601 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  612 */       if (this.wrappedStmt != null) {
/*  613 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType, scale);
/*      */       } else {
/*  615 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  618 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  629 */       if (this.wrappedStmt != null) {
/*  630 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType, typeName);
/*      */       } else {
/*  632 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  635 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public URL getURL(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  646 */       if (this.wrappedStmt != null) {
/*  647 */         return ((CallableStatement)this.wrappedStmt).getURL(parameterIndex);
/*      */       }
/*  649 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  652 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/*  655 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setURL(String parameterName, URL val)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  665 */       if (this.wrappedStmt != null) {
/*  666 */         ((CallableStatement)this.wrappedStmt).setURL(parameterName, val);
/*      */       } else {
/*  668 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  671 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  682 */       if (this.wrappedStmt != null) {
/*  683 */         ((CallableStatement)this.wrappedStmt).setNull(parameterName, sqlType);
/*      */       } else {
/*  685 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  688 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBoolean(String parameterName, boolean x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  699 */       if (this.wrappedStmt != null) {
/*  700 */         ((CallableStatement)this.wrappedStmt).setBoolean(parameterName, x);
/*      */       } else {
/*  702 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  705 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setByte(String parameterName, byte x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  716 */       if (this.wrappedStmt != null) {
/*  717 */         ((CallableStatement)this.wrappedStmt).setByte(parameterName, x);
/*      */       } else {
/*  719 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  722 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setShort(String parameterName, short x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  733 */       if (this.wrappedStmt != null) {
/*  734 */         ((CallableStatement)this.wrappedStmt).setShort(parameterName, x);
/*      */       } else {
/*  736 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  739 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setInt(String parameterName, int x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  750 */       if (this.wrappedStmt != null) {
/*  751 */         ((CallableStatement)this.wrappedStmt).setInt(parameterName, x);
/*      */       } else {
/*  753 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  756 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLong(String parameterName, long x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  767 */       if (this.wrappedStmt != null) {
/*  768 */         ((CallableStatement)this.wrappedStmt).setLong(parameterName, x);
/*      */       } else {
/*  770 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  773 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFloat(String parameterName, float x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  784 */       if (this.wrappedStmt != null) {
/*  785 */         ((CallableStatement)this.wrappedStmt).setFloat(parameterName, x);
/*      */       } else {
/*  787 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  790 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDouble(String parameterName, double x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  801 */       if (this.wrappedStmt != null) {
/*  802 */         ((CallableStatement)this.wrappedStmt).setDouble(parameterName, x);
/*      */       } else {
/*  804 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  807 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(String parameterName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  818 */       if (this.wrappedStmt != null) {
/*  819 */         ((CallableStatement)this.wrappedStmt).setBigDecimal(parameterName, x);
/*      */       } else {
/*  821 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  824 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setString(String parameterName, String x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  835 */       if (this.wrappedStmt != null) {
/*  836 */         ((CallableStatement)this.wrappedStmt).setString(parameterName, x);
/*      */       } else {
/*  838 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  841 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBytes(String parameterName, byte[] x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  852 */       if (this.wrappedStmt != null) {
/*  853 */         ((CallableStatement)this.wrappedStmt).setBytes(parameterName, x);
/*      */       } else {
/*  855 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  858 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDate(String parameterName, Date x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  869 */       if (this.wrappedStmt != null) {
/*  870 */         ((CallableStatement)this.wrappedStmt).setDate(parameterName, x);
/*      */       } else {
/*  872 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  875 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTime(String parameterName, Time x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  886 */       if (this.wrappedStmt != null) {
/*  887 */         ((CallableStatement)this.wrappedStmt).setTime(parameterName, x);
/*      */       } else {
/*  889 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  892 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  903 */       if (this.wrappedStmt != null) {
/*  904 */         ((CallableStatement)this.wrappedStmt).setTimestamp(parameterName, x);
/*      */       } else {
/*  906 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  909 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  920 */       if (this.wrappedStmt != null) {
/*  921 */         ((CallableStatement)this.wrappedStmt).setAsciiStream(parameterName, x, length);
/*      */       } else {
/*  923 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  926 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  938 */       if (this.wrappedStmt != null) {
/*  939 */         ((CallableStatement)this.wrappedStmt).setBinaryStream(parameterName, x, length);
/*      */       } else {
/*  941 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  944 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(String parameterName, Object x, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  955 */       if (this.wrappedStmt != null) {
/*  956 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x, targetSqlType, scale);
/*      */       } else {
/*  958 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  961 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(String parameterName, Object x, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  972 */       if (this.wrappedStmt != null) {
/*  973 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x, targetSqlType);
/*      */       } else {
/*  975 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  978 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(String parameterName, Object x)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  989 */       if (this.wrappedStmt != null) {
/*  990 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x);
/*      */       } else {
/*  992 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/*  995 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(String parameterName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1006 */       if (this.wrappedStmt != null) {
/* 1007 */         ((CallableStatement)this.wrappedStmt).setCharacterStream(parameterName, reader, length);
/*      */       } else {
/* 1009 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/* 1012 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDate(String parameterName, Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1023 */       if (this.wrappedStmt != null) {
/* 1024 */         ((CallableStatement)this.wrappedStmt).setDate(parameterName, x, cal);
/*      */       } else {
/* 1026 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/* 1029 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTime(String parameterName, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1040 */       if (this.wrappedStmt != null) {
/* 1041 */         ((CallableStatement)this.wrappedStmt).setTime(parameterName, x, cal);
/*      */       } else {
/* 1043 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/* 1046 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1057 */       if (this.wrappedStmt != null) {
/* 1058 */         ((CallableStatement)this.wrappedStmt).setTimestamp(parameterName, x, cal);
/*      */       } else {
/* 1060 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/* 1063 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1074 */       if (this.wrappedStmt != null) {
/* 1075 */         ((CallableStatement)this.wrappedStmt).setNull(parameterName, sqlType, typeName);
/*      */       } else {
/* 1077 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     } catch (SQLException sqlEx) {
/* 1080 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getString(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1091 */       if (this.wrappedStmt != null) {
/* 1092 */         return ((CallableStatement)this.wrappedStmt).getString(parameterName);
/*      */       }
/* 1094 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1097 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/* 1099 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1109 */       if (this.wrappedStmt != null) {
/* 1110 */         return ((CallableStatement)this.wrappedStmt).getBoolean(parameterName);
/*      */       }
/* 1112 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1115 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1118 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public byte getByte(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1128 */       if (this.wrappedStmt != null) {
/* 1129 */         return ((CallableStatement)this.wrappedStmt).getByte(parameterName);
/*      */       }
/* 1131 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1134 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1137 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public short getShort(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1147 */       if (this.wrappedStmt != null) {
/* 1148 */         return ((CallableStatement)this.wrappedStmt).getShort(parameterName);
/*      */       }
/* 1150 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1153 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1156 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getInt(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1166 */       if (this.wrappedStmt != null) {
/* 1167 */         return ((CallableStatement)this.wrappedStmt).getInt(parameterName);
/*      */       }
/* 1169 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1172 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1175 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public long getLong(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1185 */       if (this.wrappedStmt != null) {
/* 1186 */         return ((CallableStatement)this.wrappedStmt).getLong(parameterName);
/*      */       }
/* 1188 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1191 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1194 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public float getFloat(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1204 */       if (this.wrappedStmt != null) {
/* 1205 */         return ((CallableStatement)this.wrappedStmt).getFloat(parameterName);
/*      */       }
/* 1207 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1210 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1213 */     return 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public double getDouble(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1223 */       if (this.wrappedStmt != null) {
/* 1224 */         return ((CallableStatement)this.wrappedStmt).getDouble(parameterName);
/*      */       }
/* 1226 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1229 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1232 */     return 0.0D;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1242 */       if (this.wrappedStmt != null) {
/* 1243 */         return ((CallableStatement)this.wrappedStmt).getBytes(parameterName);
/*      */       }
/* 1245 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1248 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1251 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Date getDate(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1261 */       if (this.wrappedStmt != null) {
/* 1262 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterName);
/*      */       }
/* 1264 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1267 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1270 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getTime(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1280 */       if (this.wrappedStmt != null) {
/* 1281 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterName);
/*      */       }
/* 1283 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1286 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1289 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1299 */       if (this.wrappedStmt != null) {
/* 1300 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterName);
/*      */       }
/* 1302 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1305 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1308 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1318 */       if (this.wrappedStmt != null) {
/* 1319 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterName);
/*      */       }
/* 1321 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1324 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1327 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1337 */       if (this.wrappedStmt != null) {
/* 1338 */         return ((CallableStatement)this.wrappedStmt).getBigDecimal(parameterName);
/*      */       }
/* 1340 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1343 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1346 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(String parameterName, Map<String, Class<?>> typeMap)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1356 */       if (this.wrappedStmt != null) {
/* 1357 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterName, typeMap);
/*      */       }
/* 1359 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1362 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/* 1364 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Ref getRef(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1374 */       if (this.wrappedStmt != null) {
/* 1375 */         return ((CallableStatement)this.wrappedStmt).getRef(parameterName);
/*      */       }
/* 1377 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1380 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1383 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Blob getBlob(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1393 */       if (this.wrappedStmt != null) {
/* 1394 */         return ((CallableStatement)this.wrappedStmt).getBlob(parameterName);
/*      */       }
/* 1396 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1399 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1402 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Clob getClob(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1412 */       if (this.wrappedStmt != null) {
/* 1413 */         return ((CallableStatement)this.wrappedStmt).getClob(parameterName);
/*      */       }
/* 1415 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1418 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/* 1420 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Array getArray(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1430 */       if (this.wrappedStmt != null) {
/* 1431 */         return ((CallableStatement)this.wrappedStmt).getArray(parameterName);
/*      */       }
/* 1433 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1436 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/* 1438 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Date getDate(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1448 */       if (this.wrappedStmt != null) {
/* 1449 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterName, cal);
/*      */       }
/* 1451 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1454 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/* 1456 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getTime(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1466 */       if (this.wrappedStmt != null) {
/* 1467 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterName, cal);
/*      */       }
/* 1469 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1472 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/* 1474 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1484 */       if (this.wrappedStmt != null) {
/* 1485 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterName, cal);
/*      */       }
/* 1487 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1490 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/* 1492 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public URL getURL(String parameterName)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1502 */       if (this.wrappedStmt != null) {
/* 1503 */         return ((CallableStatement)this.wrappedStmt).getURL(parameterName);
/*      */       }
/* 1505 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1508 */       checkAndFireConnectionError(sqlEx);
/*      */     }
/*      */     
/* 1511 */     return null;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/jdbc2/optional/CallableStatementWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */