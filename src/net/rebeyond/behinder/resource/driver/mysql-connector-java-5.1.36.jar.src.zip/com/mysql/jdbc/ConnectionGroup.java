/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionGroup
/*     */ {
/*     */   private String groupName;
/*  37 */   private long connections = 0L;
/*  38 */   private long activeConnections = 0L;
/*  39 */   private HashMap<Long, LoadBalancingConnectionProxy> connectionProxies = new HashMap();
/*  40 */   private Set<String> hostList = new HashSet();
/*  41 */   private boolean isInitialized = false;
/*  42 */   private long closedProxyTotalPhysicalConnections = 0L;
/*  43 */   private long closedProxyTotalTransactions = 0L;
/*  44 */   private int activeHosts = 0;
/*  45 */   private Set<String> closedHosts = new HashSet();
/*     */   
/*     */   ConnectionGroup(String groupName) {
/*  48 */     this.groupName = groupName;
/*     */   }
/*     */   
/*     */   public long registerConnectionProxy(LoadBalancingConnectionProxy proxy, List<String> localHostList)
/*     */   {
/*     */     long currentConnectionId;
/*  54 */     synchronized (this) {
/*  55 */       if (!this.isInitialized) {
/*  56 */         this.hostList.addAll(localHostList);
/*  57 */         this.isInitialized = true;
/*  58 */         this.activeHosts = localHostList.size();
/*     */       }
/*  60 */       currentConnectionId = ++this.connections;
/*  61 */       this.connectionProxies.put(Long.valueOf(currentConnectionId), proxy);
/*     */     }
/*  63 */     this.activeConnections += 1L;
/*     */     
/*  65 */     return currentConnectionId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getGroupName()
/*     */   {
/*  75 */     return this.groupName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> getInitialHosts()
/*     */   {
/*  84 */     return this.hostList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getActiveHostCount()
/*     */   {
/*  93 */     return this.activeHosts;
/*     */   }
/*     */   
/*     */   public Collection<String> getClosedHosts() {
/*  97 */     return this.closedHosts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTotalLogicalConnectionCount()
/*     */   {
/* 106 */     return this.connections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getActiveLogicalConnectionCount()
/*     */   {
/* 115 */     return this.activeConnections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getActivePhysicalConnectionCount()
/*     */   {
/* 124 */     long result = 0L;
/* 125 */     Map<Long, LoadBalancingConnectionProxy> proxyMap = new HashMap();
/* 126 */     synchronized (this.connectionProxies) {
/* 127 */       proxyMap.putAll(this.connectionProxies);
/*     */     }
/* 129 */     Iterator<Map.Entry<Long, LoadBalancingConnectionProxy>> i = proxyMap.entrySet().iterator();
/* 130 */     while (i.hasNext()) {
/* 131 */       LoadBalancingConnectionProxy proxy = (LoadBalancingConnectionProxy)((Map.Entry)i.next()).getValue();
/* 132 */       result += proxy.getActivePhysicalConnectionCount();
/*     */     }
/*     */     
/* 135 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTotalPhysicalConnectionCount()
/*     */   {
/* 144 */     long allConnections = this.closedProxyTotalPhysicalConnections;
/* 145 */     Map<Long, LoadBalancingConnectionProxy> proxyMap = new HashMap();
/* 146 */     synchronized (this.connectionProxies) {
/* 147 */       proxyMap.putAll(this.connectionProxies);
/*     */     }
/* 149 */     Iterator<Map.Entry<Long, LoadBalancingConnectionProxy>> i = proxyMap.entrySet().iterator();
/* 150 */     while (i.hasNext()) {
/* 151 */       LoadBalancingConnectionProxy proxy = (LoadBalancingConnectionProxy)((Map.Entry)i.next()).getValue();
/* 152 */       allConnections += proxy.getTotalPhysicalConnectionCount();
/*     */     }
/*     */     
/* 155 */     return allConnections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTotalTransactionCount()
/*     */   {
/* 165 */     long transactions = this.closedProxyTotalTransactions;
/* 166 */     Map<Long, LoadBalancingConnectionProxy> proxyMap = new HashMap();
/* 167 */     synchronized (this.connectionProxies) {
/* 168 */       proxyMap.putAll(this.connectionProxies);
/*     */     }
/* 170 */     Iterator<Map.Entry<Long, LoadBalancingConnectionProxy>> i = proxyMap.entrySet().iterator();
/* 171 */     while (i.hasNext()) {
/* 172 */       LoadBalancingConnectionProxy proxy = (LoadBalancingConnectionProxy)((Map.Entry)i.next()).getValue();
/* 173 */       transactions += proxy.getTransactionCount();
/*     */     }
/*     */     
/* 176 */     return transactions;
/*     */   }
/*     */   
/*     */   public void closeConnectionProxy(LoadBalancingConnectionProxy proxy) {
/* 180 */     this.activeConnections -= 1L;
/* 181 */     this.connectionProxies.remove(Long.valueOf(proxy.getConnectionGroupProxyID()));
/* 182 */     this.closedProxyTotalPhysicalConnections += proxy.getTotalPhysicalConnectionCount();
/* 183 */     this.closedProxyTotalTransactions += proxy.getTransactionCount();
/*     */   }
/*     */   
/*     */   public void removeHost(String host) throws SQLException
/*     */   {
/* 188 */     removeHost(host, false);
/*     */   }
/*     */   
/*     */   public void removeHost(String host, boolean killExistingConnections) throws SQLException {
/* 192 */     removeHost(host, killExistingConnections, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeHost(String host, boolean killExistingConnections, boolean waitForGracefulFailover)
/*     */     throws SQLException
/*     */   {
/* 202 */     if (this.activeHosts == 1) {
/* 203 */       throw SQLError.createSQLException("Cannot remove host, only one configured host active.", null);
/*     */     }
/*     */     
/* 206 */     if (this.hostList.remove(host)) {
/* 207 */       this.activeHosts -= 1;
/*     */     } else {
/* 209 */       throw SQLError.createSQLException("Host is not configured: " + host, null);
/*     */     }
/*     */     
/* 212 */     if (killExistingConnections)
/*     */     {
/* 214 */       Map<Long, LoadBalancingConnectionProxy> proxyMap = new HashMap();
/* 215 */       synchronized (this.connectionProxies) {
/* 216 */         proxyMap.putAll(this.connectionProxies);
/*     */       }
/*     */       
/* 219 */       Iterator<Map.Entry<Long, LoadBalancingConnectionProxy>> i = proxyMap.entrySet().iterator();
/* 220 */       while (i.hasNext()) {
/* 221 */         LoadBalancingConnectionProxy proxy = (LoadBalancingConnectionProxy)((Map.Entry)i.next()).getValue();
/* 222 */         if (waitForGracefulFailover) {
/* 223 */           proxy.removeHostWhenNotInUse(host);
/*     */         } else {
/* 225 */           proxy.removeHost(host);
/*     */         }
/*     */       }
/*     */     }
/* 229 */     this.closedHosts.add(host);
/*     */   }
/*     */   
/*     */   public void addHost(String host) {
/* 233 */     addHost(host, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addHost(String host, boolean forExisting)
/*     */   {
/* 243 */     synchronized (this) {
/* 244 */       if (this.hostList.add(host)) {
/* 245 */         this.activeHosts += 1;
/*     */       }
/*     */     }
/*     */     
/* 249 */     if (!forExisting) {
/* 250 */       return;
/*     */     }
/*     */     
/*     */ 
/* 254 */     Map<Long, LoadBalancingConnectionProxy> proxyMap = new HashMap();
/* 255 */     synchronized (this.connectionProxies) {
/* 256 */       proxyMap.putAll(this.connectionProxies);
/*     */     }
/*     */     
/* 259 */     Object i = proxyMap.entrySet().iterator();
/* 260 */     while (((Iterator)i).hasNext()) {
/* 261 */       LoadBalancingConnectionProxy proxy = (LoadBalancingConnectionProxy)((Map.Entry)((Iterator)i).next()).getValue();
/* 262 */       proxy.addHost(host);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ConnectionGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */