/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocsConnectionPropsHelper
/*    */   extends ConnectionPropertiesImpl
/*    */ {
/*    */   static final long serialVersionUID = -1580779062220390294L;
/*    */   
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 31 */     System.out.println(new DocsConnectionPropsHelper().exposeAsXml());
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/DocsConnectionPropsHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */