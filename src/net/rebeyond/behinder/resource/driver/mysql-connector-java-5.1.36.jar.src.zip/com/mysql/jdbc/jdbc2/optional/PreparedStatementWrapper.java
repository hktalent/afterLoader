/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import com.mysql.jdbc.ResultSetInternalMethods;
/*     */ import com.mysql.jdbc.SQLError;
/*     */ import com.mysql.jdbc.Util;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.Ref;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreparedStatementWrapper
/*     */   extends StatementWrapper
/*     */   implements java.sql.PreparedStatement
/*     */ {
/*     */   private static final Constructor<?> JDBC_4_PREPARED_STATEMENT_WRAPPER_CTOR;
/*     */   
/*     */   static
/*     */   {
/*  55 */     if (Util.isJdbc4()) {
/*     */       try {
/*  57 */         JDBC_4_PREPARED_STATEMENT_WRAPPER_CTOR = Class.forName("com.mysql.jdbc.jdbc2.optional.JDBC4PreparedStatementWrapper").getConstructor(new Class[] { ConnectionWrapper.class, MysqlPooledConnection.class, java.sql.PreparedStatement.class });
/*     */       }
/*     */       catch (SecurityException e) {
/*  60 */         throw new RuntimeException(e);
/*     */       } catch (NoSuchMethodException e) {
/*  62 */         throw new RuntimeException(e);
/*     */       } catch (ClassNotFoundException e) {
/*  64 */         throw new RuntimeException(e);
/*     */       }
/*     */     } else {
/*  67 */       JDBC_4_PREPARED_STATEMENT_WRAPPER_CTOR = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static PreparedStatementWrapper getInstance(ConnectionWrapper c, MysqlPooledConnection conn, java.sql.PreparedStatement toWrap) throws SQLException {
/*  72 */     if (!Util.isJdbc4()) {
/*  73 */       return new PreparedStatementWrapper(c, conn, toWrap);
/*     */     }
/*     */     
/*  76 */     return (PreparedStatementWrapper)Util.handleNewInstance(JDBC_4_PREPARED_STATEMENT_WRAPPER_CTOR, new Object[] { c, conn, toWrap }, conn.getExceptionInterceptor());
/*     */   }
/*     */   
/*     */   PreparedStatementWrapper(ConnectionWrapper c, MysqlPooledConnection conn, java.sql.PreparedStatement toWrap)
/*     */   {
/*  81 */     super(c, conn, toWrap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setArray(int parameterIndex, Array x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/*  91 */       if (this.wrappedStmt != null) {
/*  92 */         ((java.sql.PreparedStatement)this.wrappedStmt).setArray(parameterIndex, x);
/*     */       } else {
/*  94 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/*  97 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 108 */       if (this.wrappedStmt != null) {
/* 109 */         ((java.sql.PreparedStatement)this.wrappedStmt).setAsciiStream(parameterIndex, x, length);
/*     */       } else {
/* 111 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 114 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 125 */       if (this.wrappedStmt != null) {
/* 126 */         ((java.sql.PreparedStatement)this.wrappedStmt).setBigDecimal(parameterIndex, x);
/*     */       } else {
/* 128 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 131 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 142 */       if (this.wrappedStmt != null) {
/* 143 */         ((java.sql.PreparedStatement)this.wrappedStmt).setBinaryStream(parameterIndex, x, length);
/*     */       } else {
/* 145 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 148 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBlob(int parameterIndex, Blob x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 159 */       if (this.wrappedStmt != null) {
/* 160 */         ((java.sql.PreparedStatement)this.wrappedStmt).setBlob(parameterIndex, x);
/*     */       } else {
/* 162 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 165 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBoolean(int parameterIndex, boolean x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 176 */       if (this.wrappedStmt != null) {
/* 177 */         ((java.sql.PreparedStatement)this.wrappedStmt).setBoolean(parameterIndex, x);
/*     */       } else {
/* 179 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 182 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setByte(int parameterIndex, byte x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 193 */       if (this.wrappedStmt != null) {
/* 194 */         ((java.sql.PreparedStatement)this.wrappedStmt).setByte(parameterIndex, x);
/*     */       } else {
/* 196 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 199 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBytes(int parameterIndex, byte[] x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 210 */       if (this.wrappedStmt != null) {
/* 211 */         ((java.sql.PreparedStatement)this.wrappedStmt).setBytes(parameterIndex, x);
/*     */       } else {
/* 213 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 216 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 227 */       if (this.wrappedStmt != null) {
/* 228 */         ((java.sql.PreparedStatement)this.wrappedStmt).setCharacterStream(parameterIndex, reader, length);
/*     */       } else {
/* 230 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 233 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setClob(int parameterIndex, Clob x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 244 */       if (this.wrappedStmt != null) {
/* 245 */         ((java.sql.PreparedStatement)this.wrappedStmt).setClob(parameterIndex, x);
/*     */       } else {
/* 247 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 250 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 261 */       if (this.wrappedStmt != null) {
/* 262 */         ((java.sql.PreparedStatement)this.wrappedStmt).setDate(parameterIndex, x);
/*     */       } else {
/* 264 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 267 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 278 */       if (this.wrappedStmt != null) {
/* 279 */         ((java.sql.PreparedStatement)this.wrappedStmt).setDate(parameterIndex, x, cal);
/*     */       } else {
/* 281 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 284 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDouble(int parameterIndex, double x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 295 */       if (this.wrappedStmt != null) {
/* 296 */         ((java.sql.PreparedStatement)this.wrappedStmt).setDouble(parameterIndex, x);
/*     */       } else {
/* 298 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 301 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFloat(int parameterIndex, float x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 312 */       if (this.wrappedStmt != null) {
/* 313 */         ((java.sql.PreparedStatement)this.wrappedStmt).setFloat(parameterIndex, x);
/*     */       } else {
/* 315 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 318 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setInt(int parameterIndex, int x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 329 */       if (this.wrappedStmt != null) {
/* 330 */         ((java.sql.PreparedStatement)this.wrappedStmt).setInt(parameterIndex, x);
/*     */       } else {
/* 332 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 335 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLong(int parameterIndex, long x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 346 */       if (this.wrappedStmt != null) {
/* 347 */         ((java.sql.PreparedStatement)this.wrappedStmt).setLong(parameterIndex, x);
/*     */       } else {
/* 349 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 352 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResultSetMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 363 */       if (this.wrappedStmt != null) {
/* 364 */         return ((java.sql.PreparedStatement)this.wrappedStmt).getMetaData();
/*     */       }
/*     */       
/* 367 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 369 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 372 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setNull(int parameterIndex, int sqlType)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 382 */       if (this.wrappedStmt != null) {
/* 383 */         ((java.sql.PreparedStatement)this.wrappedStmt).setNull(parameterIndex, sqlType);
/*     */       } else {
/* 385 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 388 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setNull(int parameterIndex, int sqlType, String typeName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 399 */       if (this.wrappedStmt != null) {
/* 400 */         ((java.sql.PreparedStatement)this.wrappedStmt).setNull(parameterIndex, sqlType, typeName);
/*     */       } else {
/* 402 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 405 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 416 */       if (this.wrappedStmt != null) {
/* 417 */         ((java.sql.PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x);
/*     */       } else {
/* 419 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 422 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 433 */       if (this.wrappedStmt != null) {
/* 434 */         ((java.sql.PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType);
/*     */       } else {
/* 436 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 439 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scale)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 450 */       if (this.wrappedStmt != null) {
/* 451 */         ((java.sql.PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType, scale);
/*     */       } else {
/* 453 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 456 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ParameterMetaData getParameterMetaData()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 467 */       if (this.wrappedStmt != null) {
/* 468 */         return ((java.sql.PreparedStatement)this.wrappedStmt).getParameterMetaData();
/*     */       }
/*     */       
/* 471 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 473 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 476 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRef(int parameterIndex, Ref x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 486 */       if (this.wrappedStmt != null) {
/* 487 */         ((java.sql.PreparedStatement)this.wrappedStmt).setRef(parameterIndex, x);
/*     */       } else {
/* 489 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 492 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setShort(int parameterIndex, short x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 503 */       if (this.wrappedStmt != null) {
/* 504 */         ((java.sql.PreparedStatement)this.wrappedStmt).setShort(parameterIndex, x);
/*     */       } else {
/* 506 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 509 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setString(int parameterIndex, String x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 520 */       if (this.wrappedStmt != null) {
/* 521 */         ((java.sql.PreparedStatement)this.wrappedStmt).setString(parameterIndex, x);
/*     */       } else {
/* 523 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 526 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 537 */       if (this.wrappedStmt != null) {
/* 538 */         ((java.sql.PreparedStatement)this.wrappedStmt).setTime(parameterIndex, x);
/*     */       } else {
/* 540 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 543 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 554 */       if (this.wrappedStmt != null) {
/* 555 */         ((java.sql.PreparedStatement)this.wrappedStmt).setTime(parameterIndex, x, cal);
/*     */       } else {
/* 557 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 560 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 571 */       if (this.wrappedStmt != null) {
/* 572 */         ((java.sql.PreparedStatement)this.wrappedStmt).setTimestamp(parameterIndex, x);
/*     */       } else {
/* 574 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 577 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 588 */       if (this.wrappedStmt != null) {
/* 589 */         ((java.sql.PreparedStatement)this.wrappedStmt).setTimestamp(parameterIndex, x, cal);
/*     */       } else {
/* 591 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 594 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setURL(int parameterIndex, URL x)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 605 */       if (this.wrappedStmt != null) {
/* 606 */         ((java.sql.PreparedStatement)this.wrappedStmt).setURL(parameterIndex, x);
/*     */       } else {
/* 608 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 611 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 628 */       if (this.wrappedStmt != null) {
/* 629 */         ((java.sql.PreparedStatement)this.wrappedStmt).setUnicodeStream(parameterIndex, x, length);
/*     */       } else {
/* 631 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 634 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addBatch()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 645 */       if (this.wrappedStmt != null) {
/* 646 */         ((java.sql.PreparedStatement)this.wrappedStmt).addBatch();
/*     */       } else {
/* 648 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 651 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearParameters()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 662 */       if (this.wrappedStmt != null) {
/* 663 */         ((java.sql.PreparedStatement)this.wrappedStmt).clearParameters();
/*     */       } else {
/* 665 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 668 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean execute()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 679 */       if (this.wrappedStmt != null) {
/* 680 */         return ((java.sql.PreparedStatement)this.wrappedStmt).execute();
/*     */       }
/*     */       
/* 683 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 685 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 688 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultSet executeQuery()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 701 */       if (this.wrappedStmt != null) {
/* 702 */         ResultSet rs = ((java.sql.PreparedStatement)this.wrappedStmt).executeQuery();
/*     */         
/* 704 */         ((ResultSetInternalMethods)rs).setWrapperStatement(this);
/*     */         
/* 706 */         return rs;
/*     */       }
/*     */       
/* 709 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 711 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 714 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int executeUpdate()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 727 */       if (this.wrappedStmt != null) {
/* 728 */         return ((java.sql.PreparedStatement)this.wrappedStmt).executeUpdate();
/*     */       }
/*     */       
/* 731 */       throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 733 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 736 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 743 */     StringBuilder buf = new StringBuilder(super.toString());
/*     */     
/* 745 */     if (this.wrappedStmt != null) {
/* 746 */       buf.append(": ");
/*     */       try {
/* 748 */         buf.append(((com.mysql.jdbc.PreparedStatement)this.wrappedStmt).asSql());
/*     */       } catch (SQLException sqlEx) {
/* 750 */         buf.append("EXCEPTION: " + sqlEx.toString());
/*     */       }
/*     */     }
/*     */     
/* 754 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/jdbc2/optional/PreparedStatementWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */