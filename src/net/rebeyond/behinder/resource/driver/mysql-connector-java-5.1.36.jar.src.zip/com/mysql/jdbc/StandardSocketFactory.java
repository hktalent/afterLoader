/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.log.Log;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardSocketFactory
/*     */   implements SocketFactory, SocketMetadata
/*     */ {
/*     */   public static final String TCP_NO_DELAY_PROPERTY_NAME = "tcpNoDelay";
/*     */   public static final String TCP_KEEP_ALIVE_DEFAULT_VALUE = "true";
/*     */   public static final String TCP_KEEP_ALIVE_PROPERTY_NAME = "tcpKeepAlive";
/*     */   public static final String TCP_RCV_BUF_PROPERTY_NAME = "tcpRcvBuf";
/*     */   public static final String TCP_SND_BUF_PROPERTY_NAME = "tcpSndBuf";
/*     */   public static final String TCP_TRAFFIC_CLASS_PROPERTY_NAME = "tcpTrafficClass";
/*     */   public static final String TCP_RCV_BUF_DEFAULT_VALUE = "0";
/*     */   public static final String TCP_SND_BUF_DEFAULT_VALUE = "0";
/*     */   public static final String TCP_TRAFFIC_CLASS_DEFAULT_VALUE = "0";
/*     */   public static final String TCP_NO_DELAY_DEFAULT_VALUE = "true";
/*  64 */   protected String host = null;
/*     */   
/*     */ 
/*  67 */   protected int port = 3306;
/*     */   
/*     */ 
/*  70 */   protected Socket rawSocket = null;
/*     */   
/*     */ 
/*  73 */   protected int loginTimeoutCountdown = DriverManager.getLoginTimeout() * 1000;
/*     */   
/*     */ 
/*  76 */   protected long loginTimeoutCheckTimestamp = System.currentTimeMillis();
/*     */   
/*     */ 
/*  79 */   protected int socketTimeoutBackup = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String IS_LOCAL_HOSTNAME_REPLACEMENT_PROPERTY_NAME = "com.mysql.jdbc.test.isLocalHostnameReplacement";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket afterHandshake()
/*     */     throws SocketException, IOException
/*     */   {
/*  93 */     resetLoginTimeCountdown();
/*  94 */     this.rawSocket.setSoTimeout(this.socketTimeoutBackup);
/*  95 */     return this.rawSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket beforeHandshake()
/*     */     throws SocketException, IOException
/*     */   {
/* 110 */     resetLoginTimeCountdown();
/* 111 */     this.socketTimeoutBackup = this.rawSocket.getSoTimeout();
/* 112 */     this.rawSocket.setSoTimeout(getRealTimeout(this.socketTimeoutBackup));
/* 113 */     return this.rawSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Socket createSocket(Properties props)
/*     */   {
/* 123 */     return new Socket();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void configureSocket(Socket sock, Properties props)
/*     */     throws SocketException, IOException
/*     */   {
/* 135 */     sock.setTcpNoDelay(Boolean.valueOf(props.getProperty("tcpNoDelay", "true")).booleanValue());
/*     */     
/* 137 */     String keepAlive = props.getProperty("tcpKeepAlive", "true");
/*     */     
/* 139 */     if ((keepAlive != null) && (keepAlive.length() > 0)) {
/* 140 */       sock.setKeepAlive(Boolean.valueOf(keepAlive).booleanValue());
/*     */     }
/*     */     
/* 143 */     int receiveBufferSize = Integer.parseInt(props.getProperty("tcpRcvBuf", "0"));
/*     */     
/* 145 */     if (receiveBufferSize > 0) {
/* 146 */       sock.setReceiveBufferSize(receiveBufferSize);
/*     */     }
/*     */     
/* 149 */     int sendBufferSize = Integer.parseInt(props.getProperty("tcpSndBuf", "0"));
/*     */     
/* 151 */     if (sendBufferSize > 0) {
/* 152 */       sock.setSendBufferSize(sendBufferSize);
/*     */     }
/*     */     
/* 155 */     int trafficClass = Integer.parseInt(props.getProperty("tcpTrafficClass", "0"));
/*     */     
/* 157 */     if (trafficClass > 0) {
/* 158 */       sock.setTrafficClass(trafficClass);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Socket connect(String hostname, int portNumber, Properties props)
/*     */     throws SocketException, IOException
/*     */   {
/* 167 */     if (props != null) {
/* 168 */       this.host = hostname;
/*     */       
/* 170 */       this.port = portNumber;
/*     */       
/* 172 */       String localSocketHostname = props.getProperty("localSocketAddress");
/* 173 */       InetSocketAddress localSockAddr = null;
/* 174 */       if ((localSocketHostname != null) && (localSocketHostname.length() > 0)) {
/* 175 */         localSockAddr = new InetSocketAddress(InetAddress.getByName(localSocketHostname), 0);
/*     */       }
/*     */       
/* 178 */       String connectTimeoutStr = props.getProperty("connectTimeout");
/*     */       
/* 180 */       int connectTimeout = 0;
/*     */       
/* 182 */       if (connectTimeoutStr != null) {
/*     */         try {
/* 184 */           connectTimeout = Integer.parseInt(connectTimeoutStr);
/*     */         } catch (NumberFormatException nfe) {
/* 186 */           throw new SocketException("Illegal value '" + connectTimeoutStr + "' for connectTimeout");
/*     */         }
/*     */       }
/*     */       
/* 190 */       if (this.host != null) {
/* 191 */         InetAddress[] possibleAddresses = InetAddress.getAllByName(this.host);
/*     */         
/* 193 */         if (possibleAddresses.length == 0) {
/* 194 */           throw new SocketException("No addresses for host");
/*     */         }
/*     */         
/*     */ 
/* 198 */         SocketException lastException = null;
/*     */         
/*     */ 
/*     */ 
/* 202 */         for (int i = 0; i < possibleAddresses.length; i++) {
/*     */           try {
/* 204 */             this.rawSocket = createSocket(props);
/*     */             
/* 206 */             configureSocket(this.rawSocket, props);
/*     */             
/* 208 */             InetSocketAddress sockAddr = new InetSocketAddress(possibleAddresses[i], this.port);
/*     */             
/* 210 */             if (localSockAddr != null) {
/* 211 */               this.rawSocket.bind(localSockAddr);
/*     */             }
/*     */             
/* 214 */             this.rawSocket.connect(sockAddr, getRealTimeout(connectTimeout));
/*     */           }
/*     */           catch (SocketException ex)
/*     */           {
/* 218 */             lastException = ex;
/* 219 */             resetLoginTimeCountdown();
/* 220 */             this.rawSocket = null;
/*     */           }
/*     */         }
/*     */         
/* 224 */         if ((this.rawSocket == null) && (lastException != null)) {
/* 225 */           throw lastException;
/*     */         }
/*     */         
/* 228 */         resetLoginTimeCountdown();
/*     */         
/* 230 */         return this.rawSocket;
/*     */       }
/*     */     }
/*     */     
/* 234 */     throw new SocketException("Unable to create socket");
/*     */   }
/*     */   
/*     */   public boolean isLocallyConnected(ConnectionImpl conn)
/*     */     throws SQLException
/*     */   {
/* 240 */     long threadId = conn.getId();
/* 241 */     Statement processListStmt = conn.getMetadataSafeStatement();
/* 242 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 245 */       String processHost = null;
/*     */       
/* 247 */       rs = processListStmt.executeQuery("SHOW PROCESSLIST");
/*     */       
/* 249 */       while (rs.next()) {
/* 250 */         long id = rs.getLong(1);
/*     */         
/* 252 */         if (threadId == id)
/*     */         {
/* 254 */           processHost = rs.getString(3);
/*     */           
/* 256 */           break;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 261 */       if (System.getProperty("com.mysql.jdbc.test.isLocalHostnameReplacement") != null) {
/* 262 */         processHost = System.getProperty("com.mysql.jdbc.test.isLocalHostnameReplacement");
/* 263 */       } else if (conn.getProperties().getProperty("com.mysql.jdbc.test.isLocalHostnameReplacement") != null) {
/* 264 */         processHost = conn.getProperties().getProperty("com.mysql.jdbc.test.isLocalHostnameReplacement");
/*     */       }
/*     */       
/* 267 */       if ((processHost != null) && 
/* 268 */         (processHost.indexOf(":") != -1)) {
/* 269 */         processHost = processHost.split(":")[0];
/*     */         try
/*     */         {
/* 272 */           boolean isLocal = false;
/*     */           
/* 274 */           whereMysqlThinksIConnectedFrom = InetAddress.getByName(processHost);
/* 275 */           SocketAddress remoteSocketAddr = this.rawSocket.getRemoteSocketAddress();
/*     */           InetAddress whereIConnectedTo;
/* 277 */           if ((remoteSocketAddr instanceof InetSocketAddress)) {
/* 278 */             whereIConnectedTo = ((InetSocketAddress)remoteSocketAddr).getAddress();
/*     */             
/* 280 */             isLocal = whereMysqlThinksIConnectedFrom.equals(whereIConnectedTo);
/*     */           }
/*     */           
/* 283 */           return isLocal;
/*     */         } catch (UnknownHostException e) { InetAddress whereMysqlThinksIConnectedFrom;
/* 285 */           conn.getLog().logWarn(Messages.getString("Connection.CantDetectLocalConnect", new Object[] { this.host }), e);
/*     */           
/* 287 */           return 0;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 292 */       return 0;
/*     */     } finally {
/* 294 */       processListStmt.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void resetLoginTimeCountdown()
/*     */     throws SocketException
/*     */   {
/* 305 */     if (this.loginTimeoutCountdown > 0) {
/* 306 */       long now = System.currentTimeMillis();
/* 307 */       this.loginTimeoutCountdown = ((int)(this.loginTimeoutCountdown - (now - this.loginTimeoutCheckTimestamp)));
/* 308 */       if (this.loginTimeoutCountdown <= 0) {
/* 309 */         throw new SocketException(Messages.getString("Connection.LoginTimeout"));
/*     */       }
/* 311 */       this.loginTimeoutCheckTimestamp = now;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getRealTimeout(int expectedTimeout)
/*     */   {
/* 323 */     if ((this.loginTimeoutCountdown > 0) && ((expectedTimeout == 0) || (expectedTimeout > this.loginTimeoutCountdown))) {
/* 324 */       return this.loginTimeoutCountdown;
/*     */     }
/* 326 */     return expectedTimeout;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/StandardSocketFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */