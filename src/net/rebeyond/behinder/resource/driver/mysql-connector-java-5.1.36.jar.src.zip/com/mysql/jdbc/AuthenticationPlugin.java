package com.mysql.jdbc;

import java.sql.SQLException;
import java.util.List;

public abstract interface AuthenticationPlugin
  extends Extension
{
  public abstract String getProtocolPluginName();
  
  public abstract boolean requiresConfidentiality();
  
  public abstract boolean isReusable();
  
  public abstract void setAuthenticationParameters(String paramString1, String paramString2);
  
  public abstract boolean nextAuthenticationStep(Buffer paramBuffer, List<Buffer> paramList)
    throws SQLException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/AuthenticationPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */