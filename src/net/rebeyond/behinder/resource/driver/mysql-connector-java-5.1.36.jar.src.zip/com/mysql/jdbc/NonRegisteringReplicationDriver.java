/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonRegisteringReplicationDriver
/*    */   extends NonRegisteringDriver
/*    */ {
/*    */   public NonRegisteringReplicationDriver()
/*    */     throws SQLException
/*    */   {}
/*    */   
/*    */   public Connection connect(String url, Properties info)
/*    */     throws SQLException
/*    */   {
/* 46 */     return connectReplicationConnection(url, info);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/NonRegisteringReplicationDriver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */