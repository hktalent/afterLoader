/*     */ package com.mysql.jdbc.authentication;
/*     */ 
/*     */ import com.mysql.jdbc.AuthenticationPlugin;
/*     */ import com.mysql.jdbc.Buffer;
/*     */ import com.mysql.jdbc.Connection;
/*     */ import com.mysql.jdbc.Messages;
/*     */ import com.mysql.jdbc.SQLError;
/*     */ import com.mysql.jdbc.Security;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlNativePasswordPlugin
/*     */   implements AuthenticationPlugin
/*     */ {
/*     */   private Connection connection;
/*     */   private Properties properties;
/*  46 */   private String password = null;
/*     */   
/*     */   public void init(Connection conn, Properties props) throws SQLException {
/*  49 */     this.connection = conn;
/*  50 */     this.properties = props;
/*     */   }
/*     */   
/*     */   public void destroy() {
/*  54 */     this.password = null;
/*     */   }
/*     */   
/*     */   public String getProtocolPluginName() {
/*  58 */     return "mysql_native_password";
/*     */   }
/*     */   
/*     */   public boolean requiresConfidentiality() {
/*  62 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isReusable() {
/*  66 */     return true;
/*     */   }
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/*  70 */     this.password = password;
/*     */   }
/*     */   
/*     */   public boolean nextAuthenticationStep(Buffer fromServer, List<Buffer> toServer) throws SQLException
/*     */   {
/*     */     try {
/*  76 */       toServer.clear();
/*     */       
/*  78 */       Buffer bresp = null;
/*     */       
/*  80 */       String pwd = this.password;
/*  81 */       if (pwd == null) {
/*  82 */         pwd = this.properties.getProperty("password");
/*     */       }
/*     */       
/*  85 */       if ((fromServer == null) || (pwd == null) || (pwd.length() == 0)) {
/*  86 */         bresp = new Buffer(new byte[0]);
/*     */       } else {
/*  88 */         bresp = new Buffer(Security.scramble411(pwd, fromServer.readString(), this.connection.getPasswordCharacterEncoding()));
/*     */       }
/*  90 */       toServer.add(bresp);
/*     */     }
/*     */     catch (NoSuchAlgorithmException nse) {
/*  93 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", null);
/*     */     } catch (UnsupportedEncodingException e) {
/*  95 */       throw SQLError.createSQLException(Messages.getString("MysqlNativePasswordPlugin.1", new Object[] { this.connection.getPasswordCharacterEncoding() }), "S1000", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 100 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/authentication/MysqlNativePasswordPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */