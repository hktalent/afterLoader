package com.mysql.jdbc;

abstract interface OutputStreamWatcher
{
  public abstract void streamClosed(WatchableOutputStream paramWatchableOutputStream);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/OutputStreamWatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */