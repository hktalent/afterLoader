/*    */ package com.mysql.jdbc.authentication;
/*    */ 
/*    */ import com.mysql.jdbc.AuthenticationPlugin;
/*    */ import com.mysql.jdbc.Buffer;
/*    */ import com.mysql.jdbc.Connection;
/*    */ import com.mysql.jdbc.StringUtils;
/*    */ import com.mysql.jdbc.Util;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlOldPasswordPlugin
/*    */   implements AuthenticationPlugin
/*    */ {
/*    */   private Connection connection;
/*    */   private Properties properties;
/* 43 */   private String password = null;
/*    */   
/*    */   public void init(Connection conn, Properties props) throws SQLException {
/* 46 */     this.connection = conn;
/* 47 */     this.properties = props;
/*    */   }
/*    */   
/*    */   public void destroy() {
/* 51 */     this.password = null;
/*    */   }
/*    */   
/*    */   public String getProtocolPluginName() {
/* 55 */     return "mysql_old_password";
/*    */   }
/*    */   
/*    */   public boolean requiresConfidentiality() {
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isReusable() {
/* 63 */     return true;
/*    */   }
/*    */   
/*    */   public void setAuthenticationParameters(String user, String password) {
/* 67 */     this.password = password;
/*    */   }
/*    */   
/*    */   public boolean nextAuthenticationStep(Buffer fromServer, List<Buffer> toServer) throws SQLException {
/* 71 */     toServer.clear();
/*    */     
/* 73 */     Buffer bresp = null;
/*    */     
/* 75 */     String pwd = this.password;
/* 76 */     if (pwd == null) {
/* 77 */       pwd = this.properties.getProperty("password");
/*    */     }
/*    */     
/* 80 */     if ((fromServer == null) || (pwd == null) || (pwd.length() == 0)) {
/* 81 */       bresp = new Buffer(new byte[0]);
/*    */     } else {
/* 83 */       bresp = new Buffer(StringUtils.getBytes(Util.newCrypt(pwd, fromServer.readString().substring(0, 8), this.connection.getPasswordCharacterEncoding())));
/*    */       
/*    */ 
/* 86 */       bresp.setPosition(bresp.getBufLength());
/* 87 */       int oldBufLength = bresp.getBufLength();
/*    */       
/* 89 */       bresp.writeByte((byte)0);
/*    */       
/* 91 */       bresp.setBufLength(oldBufLength + 1);
/* 92 */       bresp.setPosition(0);
/*    */     }
/* 94 */     toServer.add(bresp);
/*    */     
/* 96 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/authentication/MysqlOldPasswordPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */