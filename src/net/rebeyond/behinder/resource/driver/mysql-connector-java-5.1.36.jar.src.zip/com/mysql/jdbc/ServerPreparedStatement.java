/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.List;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ServerPreparedStatement
/*      */   extends PreparedStatement
/*      */ {
/*      */   private static final Constructor<?> JDBC_4_SPS_CTOR;
/*      */   protected static final int BLOB_STREAM_READ_BUF_SIZE = 8192;
/*      */   
/*      */   static
/*      */   {
/*   62 */     if (Util.isJdbc4()) {
/*      */       try {
/*   64 */         JDBC_4_SPS_CTOR = Class.forName("com.mysql.jdbc.JDBC4ServerPreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, Integer.TYPE, Integer.TYPE });
/*      */       }
/*      */       catch (SecurityException e) {
/*   67 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*   69 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*   71 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*   74 */       JDBC_4_SPS_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class BatchedBindValues
/*      */   {
/*      */     public ServerPreparedStatement.BindValue[] batchedParameterValues;
/*      */     
/*      */     BatchedBindValues(ServerPreparedStatement.BindValue[] paramVals)
/*      */     {
/*   84 */       int numParams = paramVals.length;
/*      */       
/*   86 */       this.batchedParameterValues = new ServerPreparedStatement.BindValue[numParams];
/*      */       
/*   88 */       for (int i = 0; i < numParams; i++) {
/*   89 */         this.batchedParameterValues[i] = new ServerPreparedStatement.BindValue(paramVals[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class BindValue
/*      */   {
/*   96 */     public long boundBeforeExecutionNum = 0L;
/*      */     
/*      */     public long bindLength;
/*      */     
/*      */     public int bufferType;
/*      */     
/*      */     public double doubleBinding;
/*      */     
/*      */     public float floatBinding;
/*      */     
/*      */     public boolean isLongData;
/*      */     
/*      */     public boolean isNull;
/*      */     
/*  110 */     public boolean isSet = false;
/*      */     
/*      */     public long longBinding;
/*      */     
/*      */     public Object value;
/*      */     
/*      */     BindValue() {}
/*      */     
/*      */     BindValue(BindValue copyMe)
/*      */     {
/*  120 */       this.value = copyMe.value;
/*  121 */       this.isSet = copyMe.isSet;
/*  122 */       this.isLongData = copyMe.isLongData;
/*  123 */       this.isNull = copyMe.isNull;
/*  124 */       this.bufferType = copyMe.bufferType;
/*  125 */       this.bindLength = copyMe.bindLength;
/*  126 */       this.longBinding = copyMe.longBinding;
/*  127 */       this.floatBinding = copyMe.floatBinding;
/*  128 */       this.doubleBinding = copyMe.doubleBinding;
/*      */     }
/*      */     
/*      */     void reset() {
/*  132 */       this.isSet = false;
/*  133 */       this.value = null;
/*  134 */       this.isLongData = false;
/*      */       
/*  136 */       this.longBinding = 0L;
/*  137 */       this.floatBinding = 0.0F;
/*  138 */       this.doubleBinding = 0.0D;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  143 */       return toString(false);
/*      */     }
/*      */     
/*      */     public String toString(boolean quoteIfNeeded) {
/*  147 */       if (this.isLongData) {
/*  148 */         return "' STREAM DATA '";
/*      */       }
/*      */       
/*  151 */       switch (this.bufferType) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 8: 
/*  156 */         return String.valueOf(this.longBinding);
/*      */       case 4: 
/*  158 */         return String.valueOf(this.floatBinding);
/*      */       case 5: 
/*  160 */         return String.valueOf(this.doubleBinding);
/*      */       case 7: 
/*      */       case 10: 
/*      */       case 11: 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 253: 
/*      */       case 254: 
/*  168 */         if (quoteIfNeeded) {
/*  169 */           return "'" + String.valueOf(this.value) + "'";
/*      */         }
/*  171 */         return String.valueOf(this.value);
/*      */       }
/*      */       
/*  174 */       if ((this.value instanceof byte[])) {
/*  175 */         return "byte data";
/*      */       }
/*  177 */       if (quoteIfNeeded) {
/*  178 */         return "'" + String.valueOf(this.value) + "'";
/*      */       }
/*  180 */       return String.valueOf(this.value);
/*      */     }
/*      */     
/*      */     long getBoundLength()
/*      */     {
/*  185 */       if (this.isNull) {
/*  186 */         return 0L;
/*      */       }
/*      */       
/*  189 */       if (this.isLongData) {
/*  190 */         return this.bindLength;
/*      */       }
/*      */       
/*  193 */       switch (this.bufferType)
/*      */       {
/*      */       case 1: 
/*  196 */         return 1L;
/*      */       case 2: 
/*  198 */         return 2L;
/*      */       case 3: 
/*  200 */         return 4L;
/*      */       case 8: 
/*  202 */         return 8L;
/*      */       case 4: 
/*  204 */         return 4L;
/*      */       case 5: 
/*  206 */         return 8L;
/*      */       case 11: 
/*  208 */         return 9L;
/*      */       case 10: 
/*  210 */         return 7L;
/*      */       case 7: 
/*      */       case 12: 
/*  213 */         return 11L;
/*      */       case 0: 
/*      */       case 15: 
/*      */       case 246: 
/*      */       case 253: 
/*      */       case 254: 
/*  219 */         if ((this.value instanceof byte[])) {
/*  220 */           return ((byte[])this.value).length;
/*      */         }
/*  222 */         return ((String)this.value).length();
/*      */       }
/*      */       
/*  225 */       return 0L;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  245 */   private boolean hasOnDuplicateKeyUpdate = false;
/*      */   
/*      */   private void storeTime(Buffer intoBuf, Time tm) throws SQLException
/*      */   {
/*  249 */     intoBuf.ensureCapacity(9);
/*  250 */     intoBuf.writeByte((byte)8);
/*  251 */     intoBuf.writeByte((byte)0);
/*  252 */     intoBuf.writeLong(0L);
/*      */     
/*  254 */     Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */     
/*  256 */     synchronized (sessionCalendar) {
/*  257 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try {
/*  259 */         sessionCalendar.setTime(tm);
/*  260 */         intoBuf.writeByte((byte)sessionCalendar.get(11));
/*  261 */         intoBuf.writeByte((byte)sessionCalendar.get(12));
/*  262 */         intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */       }
/*      */       finally
/*      */       {
/*  266 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  276 */   private boolean detectedLongParameterSwitch = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int fieldCount;
/*      */   
/*      */ 
/*      */ 
/*  285 */   private boolean invalid = false;
/*      */   
/*      */ 
/*      */   private SQLException invalidationException;
/*      */   
/*      */ 
/*      */   private Buffer outByteBuffer;
/*      */   
/*      */ 
/*      */   private BindValue[] parameterBindings;
/*      */   
/*      */ 
/*      */   private Field[] parameterFields;
/*      */   
/*      */ 
/*      */   private Field[] resultFields;
/*      */   
/*  302 */   private boolean sendTypesToServer = false;
/*      */   
/*      */ 
/*      */   private long serverStatementId;
/*      */   
/*      */ 
/*  308 */   private int stringTypeCode = 254;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean serverNeedsResetBeforeEachExecution;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static ServerPreparedStatement getInstance(MySQLConnection conn, String sql, String catalog, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  321 */     if (!Util.isJdbc4()) {
/*  322 */       return new ServerPreparedStatement(conn, sql, catalog, resultSetType, resultSetConcurrency);
/*      */     }
/*      */     try
/*      */     {
/*  326 */       return (ServerPreparedStatement)JDBC_4_SPS_CTOR.newInstance(new Object[] { conn, sql, catalog, Integer.valueOf(resultSetType), Integer.valueOf(resultSetConcurrency) });
/*      */     }
/*      */     catch (IllegalArgumentException e) {
/*  329 */       throw new SQLException(e.toString(), "S1000");
/*      */     } catch (InstantiationException e) {
/*  331 */       throw new SQLException(e.toString(), "S1000");
/*      */     } catch (IllegalAccessException e) {
/*  333 */       throw new SQLException(e.toString(), "S1000");
/*      */     } catch (InvocationTargetException e) {
/*  335 */       Throwable target = e.getTargetException();
/*      */       
/*  337 */       if ((target instanceof SQLException)) {
/*  338 */         throw ((SQLException)target);
/*      */       }
/*      */       
/*  341 */       throw new SQLException(target.toString(), "S1000");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ServerPreparedStatement(MySQLConnection conn, String sql, String catalog, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  359 */     super(conn, catalog);
/*      */     
/*  361 */     checkNullOrEmptyQuery(sql);
/*      */     
/*  363 */     int startOfStatement = findStartOfStatement(sql);
/*      */     
/*  365 */     this.firstCharOfStmt = StringUtils.firstAlphaCharUc(sql, startOfStatement);
/*      */     
/*  367 */     this.hasOnDuplicateKeyUpdate = ((this.firstCharOfStmt == 'I') && (containsOnDuplicateKeyInString(sql)));
/*      */     
/*  369 */     if (this.connection.versionMeetsMinimum(5, 0, 0)) {
/*  370 */       this.serverNeedsResetBeforeEachExecution = (!this.connection.versionMeetsMinimum(5, 0, 3));
/*      */     } else {
/*  372 */       this.serverNeedsResetBeforeEachExecution = (!this.connection.versionMeetsMinimum(4, 1, 10));
/*      */     }
/*      */     
/*  375 */     this.useAutoSlowLog = this.connection.getAutoSlowLog();
/*  376 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */     
/*  378 */     String statementComment = this.connection.getStatementComment();
/*      */     
/*  380 */     this.originalSql = ("/* " + statementComment + " */ " + sql);
/*      */     
/*  382 */     if (this.connection.versionMeetsMinimum(4, 1, 2)) {
/*  383 */       this.stringTypeCode = 253;
/*      */     } else {
/*  385 */       this.stringTypeCode = 254;
/*      */     }
/*      */     try
/*      */     {
/*  389 */       serverPrepare(sql);
/*      */     } catch (SQLException sqlEx) {
/*  391 */       realClose(false, true);
/*      */       
/*  393 */       throw sqlEx;
/*      */     } catch (Exception ex) {
/*  395 */       realClose(false, true);
/*      */       
/*  397 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/*  398 */       sqlEx.initCause(ex);
/*      */       
/*  400 */       throw sqlEx;
/*      */     }
/*      */     
/*  403 */     setResultSetType(resultSetType);
/*  404 */     setResultSetConcurrency(resultSetConcurrency);
/*      */     
/*  406 */     this.parameterTypes = new int[this.parameterCount];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  419 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  421 */       if (this.batchedArgs == null) {
/*  422 */         this.batchedArgs = new ArrayList();
/*      */       }
/*      */       
/*  425 */       this.batchedArgs.add(new BatchedBindValues(this.parameterBindings));
/*      */     }
/*      */   }
/*      */   
/*      */   public String asSql(boolean quoteStreamsAndUnknowns)
/*      */     throws SQLException
/*      */   {
/*  432 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  434 */       PreparedStatement pStmtForSub = null;
/*      */       try
/*      */       {
/*  437 */         pStmtForSub = PreparedStatement.getInstance(this.connection, this.originalSql, this.currentCatalog);
/*      */         
/*  439 */         int numParameters = pStmtForSub.parameterCount;
/*  440 */         int ourNumParameters = this.parameterCount;
/*      */         
/*  442 */         for (int i = 0; (i < numParameters) && (i < ourNumParameters); i++) {
/*  443 */           if (this.parameterBindings[i] != null) {
/*  444 */             if (this.parameterBindings[i].isNull) {
/*  445 */               pStmtForSub.setNull(i + 1, 0);
/*      */             } else {
/*  447 */               BindValue bindValue = this.parameterBindings[i];
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*  452 */               switch (bindValue.bufferType)
/*      */               {
/*      */               case 1: 
/*  455 */                 pStmtForSub.setByte(i + 1, (byte)(int)bindValue.longBinding);
/*  456 */                 break;
/*      */               case 2: 
/*  458 */                 pStmtForSub.setShort(i + 1, (short)(int)bindValue.longBinding);
/*  459 */                 break;
/*      */               case 3: 
/*  461 */                 pStmtForSub.setInt(i + 1, (int)bindValue.longBinding);
/*  462 */                 break;
/*      */               case 8: 
/*  464 */                 pStmtForSub.setLong(i + 1, bindValue.longBinding);
/*  465 */                 break;
/*      */               case 4: 
/*  467 */                 pStmtForSub.setFloat(i + 1, bindValue.floatBinding);
/*  468 */                 break;
/*      */               case 5: 
/*  470 */                 pStmtForSub.setDouble(i + 1, bindValue.doubleBinding);
/*  471 */                 break;
/*      */               case 6: case 7: default: 
/*  473 */                 pStmtForSub.setObject(i + 1, this.parameterBindings[i].value);
/*      */               }
/*      */               
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  480 */         i = pStmtForSub.asSql(quoteStreamsAndUnknowns);jsr 16;return i;
/*      */       } finally {
/*  482 */         jsr 6; } localObject2 = returnAddress; if (pStmtForSub != null) {
/*      */         try {
/*  484 */           pStmtForSub.close();
/*      */         } catch (SQLException sqlEx) {}
/*      */       }
/*  487 */       ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected MySQLConnection checkClosed()
/*      */     throws SQLException
/*      */   {
/*  500 */     if (this.invalid) {
/*  501 */       throw this.invalidationException;
/*      */     }
/*      */     
/*  504 */     return super.checkClosed();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  512 */     synchronized (checkClosed().getConnectionMutex()) {
/*  513 */       clearParametersInternal(true);
/*      */     }
/*      */   }
/*      */   
/*      */   private void clearParametersInternal(boolean clearServerParameters) throws SQLException {
/*  518 */     boolean hadLongData = false;
/*      */     
/*  520 */     if (this.parameterBindings != null) {
/*  521 */       for (int i = 0; i < this.parameterCount; i++) {
/*  522 */         if ((this.parameterBindings[i] != null) && (this.parameterBindings[i].isLongData)) {
/*  523 */           hadLongData = true;
/*      */         }
/*      */         
/*  526 */         this.parameterBindings[i].reset();
/*      */       }
/*      */     }
/*      */     
/*  530 */     if ((clearServerParameters) && (hadLongData)) {
/*  531 */       serverResetStatement();
/*      */       
/*  533 */       this.detectedLongParameterSwitch = false;
/*      */     }
/*      */   }
/*      */   
/*  537 */   protected boolean isCached = false;
/*      */   
/*      */   private boolean useAutoSlowLog;
/*      */   
/*      */   private Calendar serverTzCalendar;
/*      */   private Calendar defaultTzCalendar;
/*      */   
/*      */   protected void setClosed(boolean flag)
/*      */   {
/*  546 */     this.isClosed = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  554 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/*  556 */     if (locallyScopedConn == null) {
/*  557 */       return;
/*      */     }
/*      */     
/*  560 */     synchronized (locallyScopedConn.getConnectionMutex())
/*      */     {
/*  562 */       if ((this.isCached) && (!this.isClosed)) {
/*  563 */         clearParameters();
/*      */         
/*  565 */         this.isClosed = true;
/*      */         
/*  567 */         this.connection.recachePreparedStatement(this);
/*  568 */         return;
/*      */       }
/*      */       
/*  571 */       realClose(true, true);
/*      */     }
/*      */   }
/*      */   
/*      */   private void dumpCloseForTestcase() throws SQLException {
/*  576 */     synchronized (checkClosed().getConnectionMutex()) {
/*  577 */       StringBuilder buf = new StringBuilder();
/*  578 */       this.connection.generateConnectionCommentBlock(buf);
/*  579 */       buf.append("DEALLOCATE PREPARE debug_stmt_");
/*  580 */       buf.append(this.statementId);
/*  581 */       buf.append(";\n");
/*      */       
/*  583 */       this.connection.dumpTestcaseQuery(buf.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   private void dumpExecuteForTestcase() throws SQLException {
/*  588 */     synchronized (checkClosed().getConnectionMutex()) {
/*  589 */       StringBuilder buf = new StringBuilder();
/*      */       
/*  591 */       for (int i = 0; i < this.parameterCount; i++) {
/*  592 */         this.connection.generateConnectionCommentBlock(buf);
/*      */         
/*  594 */         buf.append("SET @debug_stmt_param");
/*  595 */         buf.append(this.statementId);
/*  596 */         buf.append("_");
/*  597 */         buf.append(i);
/*  598 */         buf.append("=");
/*      */         
/*  600 */         if (this.parameterBindings[i].isNull) {
/*  601 */           buf.append("NULL");
/*      */         } else {
/*  603 */           buf.append(this.parameterBindings[i].toString(true));
/*      */         }
/*      */         
/*  606 */         buf.append(";\n");
/*      */       }
/*      */       
/*  609 */       this.connection.generateConnectionCommentBlock(buf);
/*      */       
/*  611 */       buf.append("EXECUTE debug_stmt_");
/*  612 */       buf.append(this.statementId);
/*      */       
/*  614 */       if (this.parameterCount > 0) {
/*  615 */         buf.append(" USING ");
/*  616 */         for (int i = 0; i < this.parameterCount; i++) {
/*  617 */           if (i > 0) {
/*  618 */             buf.append(", ");
/*      */           }
/*      */           
/*  621 */           buf.append("@debug_stmt_param");
/*  622 */           buf.append(this.statementId);
/*  623 */           buf.append("_");
/*  624 */           buf.append(i);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  629 */       buf.append(";\n");
/*      */       
/*  631 */       this.connection.dumpTestcaseQuery(buf.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   private void dumpPrepareForTestcase() throws SQLException {
/*  636 */     synchronized (checkClosed().getConnectionMutex()) {
/*  637 */       StringBuilder buf = new StringBuilder(this.originalSql.length() + 64);
/*      */       
/*  639 */       this.connection.generateConnectionCommentBlock(buf);
/*      */       
/*  641 */       buf.append("PREPARE debug_stmt_");
/*  642 */       buf.append(this.statementId);
/*  643 */       buf.append(" FROM \"");
/*  644 */       buf.append(this.originalSql);
/*  645 */       buf.append("\";\n");
/*      */       
/*  647 */       this.connection.dumpTestcaseQuery(buf.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   protected int[] executeBatchSerially(int batchTimeout) throws SQLException { MySQLConnection locallyScopedConn;
/*      */     BindValue[] oldBindValues;
/*  653 */     synchronized (checkClosed().getConnectionMutex()) {
/*  654 */       locallyScopedConn = this.connection;
/*      */       
/*  656 */       if (locallyScopedConn.isReadOnly()) {
/*  657 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.2") + Messages.getString("ServerPreparedStatement.3"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*  661 */       clearWarnings();
/*      */       
/*      */ 
/*      */ 
/*  665 */       oldBindValues = this.parameterBindings;
/*      */     }
/*      */     try {
/*  668 */       int[] updateCounts = null;
/*      */       
/*  670 */       if (this.batchedArgs != null) {
/*  671 */         nbrCommands = this.batchedArgs.size();
/*  672 */         updateCounts = new int[nbrCommands];
/*      */         
/*  674 */         if (this.retrieveGeneratedKeys) {
/*  675 */           this.batchedGeneratedKeys = new ArrayList(nbrCommands);
/*      */         }
/*      */         
/*  678 */         for (int i = 0; i < nbrCommands; i++) {
/*  679 */           updateCounts[i] = -3;
/*      */         }
/*      */         
/*  682 */         SQLException sqlEx = null;
/*      */         
/*  684 */         int commandIndex = 0;
/*      */         
/*  686 */         BindValue[] previousBindValuesForBatch = null;
/*      */         
/*  688 */         StatementImpl.CancelTask timeoutTask = null;
/*      */         try
/*      */         {
/*  691 */           if ((locallyScopedConn.getEnableQueryTimeouts()) && (batchTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0))) {
/*  692 */             timeoutTask = new StatementImpl.CancelTask(this, this);
/*  693 */             locallyScopedConn.getCancelTimer().schedule(timeoutTask, batchTimeout);
/*      */           }
/*      */           
/*  696 */           for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*  697 */             Object arg = this.batchedArgs.get(commandIndex);
/*      */             
/*  699 */             if ((arg instanceof String)) {
/*  700 */               updateCounts[commandIndex] = executeUpdate((String)arg);
/*      */             } else {
/*  702 */               this.parameterBindings = ((BatchedBindValues)arg).batchedParameterValues;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */               try
/*      */               {
/*  709 */                 if (previousBindValuesForBatch != null) {
/*  710 */                   for (int j = 0; j < this.parameterBindings.length; j++) {
/*  711 */                     if (this.parameterBindings[j].bufferType != previousBindValuesForBatch[j].bufferType) {
/*  712 */                       this.sendTypesToServer = true;
/*      */                       
/*  714 */                       break;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 try
/*      */                 {
/*  720 */                   updateCounts[commandIndex] = executeUpdate(false, true);
/*      */                 } finally {
/*  722 */                   previousBindValuesForBatch = this.parameterBindings;
/*      */                 }
/*      */                 
/*  725 */                 if (this.retrieveGeneratedKeys) {
/*  726 */                   ResultSet rs = null;
/*      */                   
/*      */ 
/*      */ 
/*      */                   try
/*      */                   {
/*  732 */                     rs = getGeneratedKeysInternal();
/*      */                     
/*  734 */                     while (rs.next()) {
/*  735 */                       this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */                     }
/*      */                   } finally {
/*  738 */                     if (rs != null) {
/*  739 */                       rs.close();
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               } catch (SQLException ex) {
/*  744 */                 updateCounts[commandIndex] = -3;
/*      */                 
/*  746 */                 if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */                 {
/*  748 */                   sqlEx = ex;
/*      */                 } else {
/*  750 */                   int[] newUpdateCounts = new int[commandIndex];
/*  751 */                   System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */                   
/*  753 */                   throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         } finally {
/*  759 */           if (timeoutTask != null) {
/*  760 */             timeoutTask.cancel();
/*      */             
/*  762 */             locallyScopedConn.getCancelTimer().purge();
/*      */           }
/*      */           
/*  765 */           resetCancelledState();
/*      */         }
/*      */         
/*  768 */         if (sqlEx != null) {
/*  769 */           throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */         }
/*      */       }
/*      */       
/*  773 */       int nbrCommands = updateCounts != null ? updateCounts : new int[0];jsr 16;return nbrCommands;
/*      */     } finally {
/*  775 */       jsr 6; } localObject8 = returnAddress;this.parameterBindings = oldBindValues;
/*  776 */     this.sendTypesToServer = true;
/*      */     
/*  778 */     clearBatch();ret;
/*      */     
/*  780 */     localObject9 = finally;throw ((Throwable)localObject9);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, Field[] metadataFromCache, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/*  789 */     synchronized (checkClosed().getConnectionMutex()) {
/*  790 */       this.numberOfExecutions += 1;
/*      */       
/*      */       try
/*      */       {
/*  794 */         return serverExecute(maxRowsToRetrieve, createStreamingResultSet, metadataFromCache);
/*      */       }
/*      */       catch (SQLException sqlEx) {
/*  797 */         if (this.connection.getEnablePacketDebug()) {
/*  798 */           this.connection.getIO().dumpPacketRingBuffer();
/*      */         }
/*      */         
/*  801 */         if (this.connection.getDumpQueriesOnException()) {
/*  802 */           String extractedSql = toString();
/*  803 */           StringBuilder messageBuf = new StringBuilder(extractedSql.length() + 32);
/*  804 */           messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
/*  805 */           messageBuf.append(extractedSql);
/*  806 */           messageBuf.append("\n\n");
/*      */           
/*  808 */           sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
/*      */         }
/*      */         
/*  811 */         throw sqlEx;
/*      */       } catch (Exception ex) {
/*  813 */         if (this.connection.getEnablePacketDebug()) {
/*  814 */           this.connection.getIO().dumpPacketRingBuffer();
/*      */         }
/*      */         
/*  817 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/*      */         
/*  819 */         if (this.connection.getDumpQueriesOnException()) {
/*  820 */           String extractedSql = toString();
/*  821 */           StringBuilder messageBuf = new StringBuilder(extractedSql.length() + 32);
/*  822 */           messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
/*  823 */           messageBuf.append(extractedSql);
/*  824 */           messageBuf.append("\n\n");
/*      */           
/*  826 */           sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
/*      */         }
/*      */         
/*  829 */         sqlEx.initCause(ex);
/*      */         
/*  831 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Buffer fillSendPacket()
/*      */     throws SQLException
/*      */   {
/*  841 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths)
/*      */     throws SQLException
/*      */   {
/*  850 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BindValue getBinding(int parameterIndex, boolean forLongData)
/*      */     throws SQLException
/*      */   {
/*  864 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  866 */       if (this.parameterBindings.length == 0) {
/*  867 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.8"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*  871 */       parameterIndex--;
/*      */       
/*  873 */       if ((parameterIndex < 0) || (parameterIndex >= this.parameterBindings.length)) {
/*  874 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.9") + (parameterIndex + 1) + Messages.getString("ServerPreparedStatement.10") + this.parameterBindings.length, "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  879 */       if (this.parameterBindings[parameterIndex] == null) {
/*  880 */         this.parameterBindings[parameterIndex] = new BindValue();
/*      */       }
/*  882 */       else if ((this.parameterBindings[parameterIndex].isLongData) && (!forLongData)) {
/*  883 */         this.detectedLongParameterSwitch = true;
/*      */       }
/*      */       
/*      */ 
/*  887 */       this.parameterBindings[parameterIndex].isSet = true;
/*  888 */       this.parameterBindings[parameterIndex].boundBeforeExecutionNum = this.numberOfExecutions;
/*      */       
/*  890 */       return this.parameterBindings[parameterIndex];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BindValue[] getParameterBindValues()
/*      */   {
/*  902 */     return this.parameterBindings;
/*      */   }
/*      */   
/*      */ 
/*      */   byte[] getBytes(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*  909 */     synchronized (checkClosed().getConnectionMutex()) {
/*  910 */       BindValue bindValue = getBinding(parameterIndex, false);
/*      */       
/*  912 */       if (bindValue.isNull)
/*  913 */         return null;
/*  914 */       if (bindValue.isLongData) {
/*  915 */         throw SQLError.notImplemented();
/*      */       }
/*  917 */       if (this.outByteBuffer == null) {
/*  918 */         this.outByteBuffer = new Buffer(this.connection.getNetBufferLength());
/*      */       }
/*      */       
/*  921 */       this.outByteBuffer.clear();
/*      */       
/*  923 */       int originalPosition = this.outByteBuffer.getPosition();
/*      */       
/*  925 */       storeBinding(this.outByteBuffer, bindValue, this.connection.getIO());
/*      */       
/*  927 */       int newPosition = this.outByteBuffer.getPosition();
/*      */       
/*  929 */       int length = newPosition - originalPosition;
/*      */       
/*  931 */       byte[] valueAsBytes = new byte[length];
/*      */       
/*  933 */       System.arraycopy(this.outByteBuffer.getByteBuffer(), originalPosition, valueAsBytes, 0, length);
/*      */       
/*  935 */       return valueAsBytes;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  945 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  947 */       if (this.resultFields == null) {
/*  948 */         return null;
/*      */       }
/*      */       
/*  951 */       return new ResultSetMetaData(this.resultFields, this.connection.getUseOldAliasMetadataBehavior(), this.connection.getYearIsDateType(), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/*  961 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  963 */       if (this.parameterMetaData == null) {
/*  964 */         this.parameterMetaData = new MysqlParameterMetadata(this.parameterFields, this.parameterCount, getExceptionInterceptor());
/*      */       }
/*      */       
/*  967 */       return this.parameterMetaData;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isNull(int paramIndex)
/*      */   {
/*  976 */     throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.7"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/*  990 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/*  992 */     if (locallyScopedConn == null) {
/*  993 */       return;
/*      */     }
/*      */     
/*  996 */     synchronized (locallyScopedConn.getConnectionMutex())
/*      */     {
/*  998 */       if (this.connection != null) {
/*  999 */         if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1000 */           dumpCloseForTestcase();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1010 */         SQLException exceptionDuringClose = null;
/*      */         
/* 1012 */         if ((calledExplicitly) && (!this.connection.isClosed())) {
/* 1013 */           synchronized (this.connection.getConnectionMutex())
/*      */           {
/*      */             try {
/* 1016 */               MysqlIO mysql = this.connection.getIO();
/*      */               
/* 1018 */               Buffer packet = mysql.getSharedSendPacket();
/*      */               
/* 1020 */               packet.writeByte((byte)25);
/* 1021 */               packet.writeLong(this.serverStatementId);
/*      */               
/* 1023 */               mysql.sendCommand(25, null, packet, true, null, 0);
/*      */             } catch (SQLException sqlEx) {
/* 1025 */               exceptionDuringClose = sqlEx;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1030 */         if (this.isCached) {
/* 1031 */           this.connection.decachePreparedStatement(this);
/*      */         }
/* 1033 */         super.realClose(calledExplicitly, closeOpenResults);
/*      */         
/* 1035 */         clearParametersInternal(false);
/* 1036 */         this.parameterBindings = null;
/*      */         
/* 1038 */         this.parameterFields = null;
/* 1039 */         this.resultFields = null;
/*      */         
/* 1041 */         if (exceptionDuringClose != null) {
/* 1042 */           throw exceptionDuringClose;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void rePrepare()
/*      */     throws SQLException
/*      */   {
/* 1056 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1057 */       this.invalidationException = null;
/*      */       try
/*      */       {
/* 1060 */         serverPrepare(this.originalSql);
/*      */       }
/*      */       catch (SQLException sqlEx) {
/* 1063 */         this.invalidationException = sqlEx;
/*      */       } catch (Exception ex) {
/* 1065 */         this.invalidationException = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/* 1066 */         this.invalidationException.initCause(ex);
/*      */       }
/*      */       
/* 1069 */       if (this.invalidationException != null) {
/* 1070 */         this.invalid = true;
/*      */         
/* 1072 */         this.parameterBindings = null;
/*      */         
/* 1074 */         this.parameterFields = null;
/* 1075 */         this.resultFields = null;
/*      */         
/* 1077 */         if (this.results != null) {
/*      */           try {
/* 1079 */             this.results.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */         }
/*      */         
/* 1084 */         if (this.generatedKeysResults != null) {
/*      */           try {
/* 1086 */             this.generatedKeysResults.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */         }
/*      */         try
/*      */         {
/* 1092 */           closeAllOpenResults();
/*      */         }
/*      */         catch (Exception e) {}
/*      */         
/* 1096 */         if ((this.connection != null) && 
/* 1097 */           (!this.connection.getDontTrackOpenResources())) {
/* 1098 */           this.connection.unregisterStatement(this);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ResultSetInternalMethods serverExecute(int maxRowsToRetrieve, boolean createStreamingResultSet, Field[] metadataFromCache)
/*      */     throws SQLException
/*      */   {
/* 1136 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1137 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1139 */       if (mysql.shouldIntercept()) {
/* 1140 */         ResultSetInternalMethods interceptedResults = mysql.invokeStatementInterceptorsPre(this.originalSql, this, true);
/*      */         
/* 1142 */         if (interceptedResults != null) {
/* 1143 */           return interceptedResults;
/*      */         }
/*      */       }
/*      */       
/* 1147 */       if (this.detectedLongParameterSwitch)
/*      */       {
/* 1149 */         boolean firstFound = false;
/* 1150 */         long boundTimeToCheck = 0L;
/*      */         
/* 1152 */         for (int i = 0; i < this.parameterCount - 1; i++) {
/* 1153 */           if (this.parameterBindings[i].isLongData) {
/* 1154 */             if ((firstFound) && (boundTimeToCheck != this.parameterBindings[i].boundBeforeExecutionNum)) {
/* 1155 */               throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.11") + Messages.getString("ServerPreparedStatement.12"), "S1C00", getExceptionInterceptor());
/*      */             }
/*      */             
/*      */ 
/* 1159 */             firstFound = true;
/* 1160 */             boundTimeToCheck = this.parameterBindings[i].boundBeforeExecutionNum;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1166 */         serverResetStatement();
/*      */       }
/*      */       
/*      */ 
/* 1170 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1171 */         if (!this.parameterBindings[i].isSet) {
/* 1172 */           throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.13") + (i + 1) + Messages.getString("ServerPreparedStatement.14"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1181 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1182 */         if (this.parameterBindings[i].isLongData) {
/* 1183 */           serverLongData(i, this.parameterBindings[i]);
/*      */         }
/*      */       }
/*      */       
/* 1187 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1188 */         dumpExecuteForTestcase();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1195 */       Buffer packet = mysql.getSharedSendPacket();
/*      */       
/* 1197 */       packet.clear();
/* 1198 */       packet.writeByte((byte)23);
/* 1199 */       packet.writeLong(this.serverStatementId);
/*      */       
/*      */ 
/*      */ 
/* 1203 */       if (this.connection.versionMeetsMinimum(4, 1, 2))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1209 */         if ((this.resultFields != null) && (this.connection.isCursorFetchEnabled()) && (getResultSetType() == 1003) && (getResultSetConcurrency() == 1007) && (getFetchSize() > 0))
/*      */         {
/* 1211 */           packet.writeByte((byte)1);
/*      */         }
/*      */         else {
/* 1214 */           packet.writeByte((byte)0);
/*      */         }
/*      */         
/* 1217 */         packet.writeLong(1L);
/*      */       }
/*      */       
/*      */ 
/* 1221 */       int nullCount = (this.parameterCount + 7) / 8;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1226 */       int nullBitsPosition = packet.getPosition();
/*      */       
/* 1228 */       for (int i = 0; i < nullCount; i++) {
/* 1229 */         packet.writeByte((byte)0);
/*      */       }
/*      */       
/* 1232 */       byte[] nullBitsBuffer = new byte[nullCount];
/*      */       
/*      */ 
/* 1235 */       packet.writeByte((byte)(this.sendTypesToServer ? 1 : 0));
/*      */       
/* 1237 */       if (this.sendTypesToServer)
/*      */       {
/*      */ 
/*      */ 
/* 1241 */         for (int i = 0; i < this.parameterCount; i++) {
/* 1242 */           packet.writeInt(this.parameterBindings[i].bufferType);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1249 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1250 */         if (!this.parameterBindings[i].isLongData) {
/* 1251 */           if (!this.parameterBindings[i].isNull) {
/* 1252 */             storeBinding(packet, this.parameterBindings[i], mysql);
/*      */           } else {
/* 1254 */             int tmp589_588 = (i / 8); byte[] tmp589_582 = nullBitsBuffer;tmp589_582[tmp589_588] = ((byte)(tmp589_582[tmp589_588] | 1 << (i & 0x7)));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1262 */       int endPosition = packet.getPosition();
/* 1263 */       packet.setPosition(nullBitsPosition);
/* 1264 */       packet.writeBytesNoNull(nullBitsBuffer);
/* 1265 */       packet.setPosition(endPosition);
/*      */       
/* 1267 */       long begin = 0L;
/*      */       
/* 1269 */       boolean logSlowQueries = this.connection.getLogSlowQueries();
/* 1270 */       boolean gatherPerformanceMetrics = this.connection.getGatherPerformanceMetrics();
/*      */       
/* 1272 */       if ((this.profileSQL) || (logSlowQueries) || (gatherPerformanceMetrics)) {
/* 1273 */         begin = mysql.getCurrentTimeNanosOrMillis();
/*      */       }
/*      */       
/* 1276 */       resetCancelledState();
/*      */       
/* 1278 */       StatementImpl.CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1281 */         if ((this.connection.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (this.connection.versionMeetsMinimum(5, 0, 0))) {
/* 1282 */           timeoutTask = new StatementImpl.CancelTask(this, this);
/* 1283 */           this.connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */         
/* 1286 */         statementBegins();
/*      */         
/* 1288 */         Buffer resultPacket = mysql.sendCommand(23, null, packet, false, null, 0);
/*      */         
/* 1290 */         long queryEndTime = 0L;
/*      */         
/* 1292 */         if ((logSlowQueries) || (gatherPerformanceMetrics) || (this.profileSQL)) {
/* 1293 */           queryEndTime = mysql.getCurrentTimeNanosOrMillis();
/*      */         }
/*      */         
/* 1296 */         if (timeoutTask != null) {
/* 1297 */           timeoutTask.cancel();
/*      */           
/* 1299 */           this.connection.getCancelTimer().purge();
/*      */           
/* 1301 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1302 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1305 */           timeoutTask = null;
/*      */         }
/*      */         
/* 1308 */         synchronized (this.cancelTimeoutMutex) {
/* 1309 */           if (this.wasCancelled) {
/* 1310 */             SQLException cause = null;
/*      */             
/* 1312 */             if (this.wasCancelledByTimeout) {
/* 1313 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 1315 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 1318 */             resetCancelledState();
/*      */             
/* 1320 */             throw cause;
/*      */           }
/*      */         }
/*      */         
/* 1324 */         boolean queryWasSlow = false;
/*      */         
/* 1326 */         if ((logSlowQueries) || (gatherPerformanceMetrics)) {
/* 1327 */           long elapsedTime = queryEndTime - begin;
/*      */           
/* 1329 */           if (logSlowQueries) {
/* 1330 */             if (this.useAutoSlowLog) {
/* 1331 */               queryWasSlow = elapsedTime > this.connection.getSlowQueryThresholdMillis();
/*      */             } else {
/* 1333 */               queryWasSlow = this.connection.isAbonormallyLongQuery(elapsedTime);
/*      */               
/* 1335 */               this.connection.reportQueryTime(elapsedTime);
/*      */             }
/*      */           }
/*      */           
/* 1339 */           if (queryWasSlow)
/*      */           {
/* 1341 */             StringBuilder mesgBuf = new StringBuilder(48 + this.originalSql.length());
/* 1342 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.15"));
/* 1343 */             mesgBuf.append(mysql.getSlowQueryThreshold());
/* 1344 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.15a"));
/* 1345 */             mesgBuf.append(elapsedTime);
/* 1346 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.16"));
/*      */             
/* 1348 */             mesgBuf.append("as prepared: ");
/* 1349 */             mesgBuf.append(this.originalSql);
/* 1350 */             mesgBuf.append("\n\n with parameters bound:\n\n");
/* 1351 */             mesgBuf.append(asSql(true));
/*      */             
/* 1353 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)6, "", this.currentCatalog, this.connection.getId(), getId(), 0, System.currentTimeMillis(), elapsedTime, mysql.getQueryTimingUnits(), null, LogUtils.findCallingClassAndMethod(new Throwable()), mesgBuf.toString()));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1358 */           if (gatherPerformanceMetrics) {
/* 1359 */             this.connection.registerQueryExecutionTime(elapsedTime);
/*      */           }
/*      */         }
/*      */         
/* 1363 */         this.connection.incrementNumberOfPreparedExecutes();
/*      */         
/* 1365 */         if (this.profileSQL) {
/* 1366 */           this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */           
/* 1368 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)4, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), mysql.getCurrentTimeNanosOrMillis() - begin, mysql.getQueryTimingUnits(), null, LogUtils.findCallingClassAndMethod(new Throwable()), truncateQueryToLog(asSql(true))));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1373 */         ResultSetInternalMethods rs = mysql.readAllResults(this, maxRowsToRetrieve, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, resultPacket, true, this.fieldCount, metadataFromCache);
/*      */         
/*      */ 
/* 1376 */         if (mysql.shouldIntercept()) {
/* 1377 */           ResultSetInternalMethods interceptedResults = mysql.invokeStatementInterceptorsPost(this.originalSql, this, rs, true, null);
/*      */           
/* 1379 */           if (interceptedResults != null) {
/* 1380 */             rs = interceptedResults;
/*      */           }
/*      */         }
/*      */         
/* 1384 */         if (this.profileSQL) {
/* 1385 */           long fetchEndTime = mysql.getCurrentTimeNanosOrMillis();
/*      */           
/* 1387 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)5, "", this.currentCatalog, this.connection.getId(), getId(), 0, System.currentTimeMillis(), fetchEndTime - queryEndTime, mysql.getQueryTimingUnits(), null, LogUtils.findCallingClassAndMethod(new Throwable()), null));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1396 */         if ((queryWasSlow) && (this.connection.getExplainSlowQueries())) {
/* 1397 */           queryAsString = asSql(true);
/*      */           
/* 1399 */           mysql.explainSlowQuery(StringUtils.getBytes((String)queryAsString), (String)queryAsString);
/*      */         }
/*      */         
/* 1402 */         if ((!createStreamingResultSet) && (this.serverNeedsResetBeforeEachExecution)) {
/* 1403 */           serverResetStatement();
/*      */         }
/*      */         
/* 1406 */         this.sendTypesToServer = false;
/* 1407 */         this.results = rs;
/*      */         
/* 1409 */         if (mysql.hadWarnings()) {
/* 1410 */           mysql.scanForAndThrowDataTruncation();
/*      */         }
/*      */         
/* 1413 */         Object queryAsString = rs;jsr 45;return (ResultSetInternalMethods)queryAsString;
/*      */       } catch (SQLException sqlEx) {
/* 1415 */         if (mysql.shouldIntercept()) {
/* 1416 */           mysql.invokeStatementInterceptorsPost(this.originalSql, this, null, true, sqlEx);
/*      */         }
/*      */         
/* 1419 */         throw sqlEx;
/*      */       } finally {
/* 1421 */         jsr 6; } localObject3 = returnAddress;this.statementExecuting.set(false);
/*      */       
/* 1423 */       if (timeoutTask != null) {
/* 1424 */         timeoutTask.cancel();
/* 1425 */         this.connection.getCancelTimer().purge(); } ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void serverLongData(int parameterIndex, BindValue longData)
/*      */     throws SQLException
/*      */   {
/* 1457 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1458 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1460 */       Buffer packet = mysql.getSharedSendPacket();
/*      */       
/* 1462 */       Object value = longData.value;
/*      */       
/* 1464 */       if ((value instanceof byte[])) {
/* 1465 */         packet.clear();
/* 1466 */         packet.writeByte((byte)24);
/* 1467 */         packet.writeLong(this.serverStatementId);
/* 1468 */         packet.writeInt(parameterIndex);
/*      */         
/* 1470 */         packet.writeBytesNoNull((byte[])longData.value);
/*      */         
/* 1472 */         mysql.sendCommand(24, null, packet, true, null, 0);
/* 1473 */       } else if ((value instanceof InputStream)) {
/* 1474 */         storeStream(mysql, parameterIndex, packet, (InputStream)value);
/* 1475 */       } else if ((value instanceof Blob)) {
/* 1476 */         storeStream(mysql, parameterIndex, packet, ((Blob)value).getBinaryStream());
/* 1477 */       } else if ((value instanceof Reader)) {
/* 1478 */         storeReader(mysql, parameterIndex, packet, (Reader)value);
/*      */       } else {
/* 1480 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.18") + value.getClass().getName() + "'", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void serverPrepare(String sql) throws SQLException
/*      */   {
/* 1487 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1488 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1490 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1491 */         dumpPrepareForTestcase();
/*      */       }
/*      */       try
/*      */       {
/* 1495 */         long begin = 0L;
/*      */         
/* 1497 */         if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA")) {
/* 1498 */           this.isLoadDataQuery = true;
/*      */         } else {
/* 1500 */           this.isLoadDataQuery = false;
/*      */         }
/*      */         
/* 1503 */         if (this.connection.getProfileSql()) {
/* 1504 */           begin = System.currentTimeMillis();
/*      */         }
/*      */         
/* 1507 */         String characterEncoding = null;
/* 1508 */         String connectionEncoding = this.connection.getEncoding();
/*      */         
/* 1510 */         if ((!this.isLoadDataQuery) && (this.connection.getUseUnicode()) && (connectionEncoding != null)) {
/* 1511 */           characterEncoding = connectionEncoding;
/*      */         }
/*      */         
/* 1514 */         Buffer prepareResultPacket = mysql.sendCommand(22, sql, null, false, characterEncoding, 0);
/*      */         
/* 1516 */         if (this.connection.versionMeetsMinimum(4, 1, 1))
/*      */         {
/* 1518 */           prepareResultPacket.setPosition(1);
/*      */         }
/*      */         else {
/* 1521 */           prepareResultPacket.setPosition(0);
/*      */         }
/*      */         
/* 1524 */         this.serverStatementId = prepareResultPacket.readLong();
/* 1525 */         this.fieldCount = prepareResultPacket.readInt();
/* 1526 */         this.parameterCount = prepareResultPacket.readInt();
/* 1527 */         this.parameterBindings = new BindValue[this.parameterCount];
/*      */         
/* 1529 */         for (int i = 0; i < this.parameterCount; i++) {
/* 1530 */           this.parameterBindings[i] = new BindValue();
/*      */         }
/*      */         
/* 1533 */         this.connection.incrementNumberOfPrepares();
/*      */         
/* 1535 */         if (this.profileSQL) {
/* 1536 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)2, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), mysql.getCurrentTimeNanosOrMillis() - begin, mysql.getQueryTimingUnits(), null, LogUtils.findCallingClassAndMethod(new Throwable()), truncateQueryToLog(sql)));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1541 */         if ((this.parameterCount > 0) && 
/* 1542 */           (this.connection.versionMeetsMinimum(4, 1, 2)) && (!mysql.isVersion(5, 0, 0))) {
/* 1543 */           this.parameterFields = new Field[this.parameterCount];
/*      */           
/* 1545 */           Buffer metaDataPacket = mysql.readPacket();
/*      */           
/* 1547 */           int i = 0;
/*      */           
/* 1549 */           while ((!metaDataPacket.isLastDataPacket()) && (i < this.parameterCount)) {
/* 1550 */             this.parameterFields[(i++)] = mysql.unpackField(metaDataPacket, false);
/* 1551 */             metaDataPacket = mysql.readPacket();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1556 */         if (this.fieldCount > 0) {
/* 1557 */           this.resultFields = new Field[this.fieldCount];
/*      */           
/* 1559 */           Buffer fieldPacket = mysql.readPacket();
/*      */           
/* 1561 */           int i = 0;
/*      */           
/*      */ 
/* 1564 */           while ((!fieldPacket.isLastDataPacket()) && (i < this.fieldCount)) {
/* 1565 */             this.resultFields[(i++)] = mysql.unpackField(fieldPacket, false);
/* 1566 */             fieldPacket = mysql.readPacket();
/*      */           }
/*      */         }
/*      */       } catch (SQLException sqlEx) {
/* 1570 */         if (this.connection.getDumpQueriesOnException()) {
/* 1571 */           StringBuilder messageBuf = new StringBuilder(this.originalSql.length() + 32);
/* 1572 */           messageBuf.append("\n\nQuery being prepared when exception was thrown:\n\n");
/* 1573 */           messageBuf.append(this.originalSql);
/*      */           
/* 1575 */           sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
/*      */         }
/*      */         
/* 1578 */         throw sqlEx;
/*      */       }
/*      */       finally {
/* 1581 */         this.connection.getIO().clearInputStream();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private String truncateQueryToLog(String sql) throws SQLException {
/* 1587 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1588 */       String query = null;
/*      */       
/* 1590 */       if (sql.length() > this.connection.getMaxQuerySizeToLog()) {
/* 1591 */         StringBuilder queryBuf = new StringBuilder(this.connection.getMaxQuerySizeToLog() + 12);
/* 1592 */         queryBuf.append(sql.substring(0, this.connection.getMaxQuerySizeToLog()));
/* 1593 */         queryBuf.append(Messages.getString("MysqlIO.25"));
/*      */         
/* 1595 */         query = queryBuf.toString();
/*      */       } else {
/* 1597 */         query = sql;
/*      */       }
/*      */       
/* 1600 */       return query;
/*      */     }
/*      */   }
/*      */   
/*      */   private void serverResetStatement() throws SQLException {
/* 1605 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1607 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1609 */       Buffer packet = mysql.getSharedSendPacket();
/*      */       
/* 1611 */       packet.clear();
/* 1612 */       packet.writeByte((byte)26);
/* 1613 */       packet.writeLong(this.serverStatementId);
/*      */       try
/*      */       {
/* 1616 */         mysql.sendCommand(26, null, packet, !this.connection.versionMeetsMinimum(4, 1, 2), null, 0);
/*      */       } catch (SQLException sqlEx) {
/* 1618 */         throw sqlEx;
/*      */       } catch (Exception ex) {
/* 1620 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/* 1621 */         sqlEx.initCause(ex);
/*      */         
/* 1623 */         throw sqlEx;
/*      */       } finally {
/* 1625 */         mysql.clearInputStream();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/* 1635 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1643 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1644 */       if (x == null) {
/* 1645 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 1647 */         BindValue binding = getBinding(parameterIndex, true);
/* 1648 */         setType(binding, 252);
/*      */         
/* 1650 */         binding.value = x;
/* 1651 */         binding.isNull = false;
/* 1652 */         binding.isLongData = true;
/*      */         
/* 1654 */         if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1655 */           binding.bindLength = length;
/*      */         } else {
/* 1657 */           binding.bindLength = -1L;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1668 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1670 */       if (x == null) {
/* 1671 */         setNull(parameterIndex, 3);
/*      */       }
/*      */       else {
/* 1674 */         BindValue binding = getBinding(parameterIndex, false);
/*      */         
/* 1676 */         if (this.connection.versionMeetsMinimum(5, 0, 3)) {
/* 1677 */           setType(binding, 246);
/*      */         } else {
/* 1679 */           setType(binding, this.stringTypeCode);
/*      */         }
/*      */         
/* 1682 */         binding.value = StringUtils.fixDecimalExponent(StringUtils.consistentToString(x));
/* 1683 */         binding.isNull = false;
/* 1684 */         binding.isLongData = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1694 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1696 */       if (x == null) {
/* 1697 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 1699 */         BindValue binding = getBinding(parameterIndex, true);
/* 1700 */         setType(binding, 252);
/*      */         
/* 1702 */         binding.value = x;
/* 1703 */         binding.isNull = false;
/* 1704 */         binding.isLongData = true;
/*      */         
/* 1706 */         if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1707 */           binding.bindLength = length;
/*      */         } else {
/* 1709 */           binding.bindLength = -1L;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBlob(int parameterIndex, Blob x)
/*      */     throws SQLException
/*      */   {
/* 1720 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1722 */       if (x == null) {
/* 1723 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 1725 */         BindValue binding = getBinding(parameterIndex, true);
/* 1726 */         setType(binding, 252);
/*      */         
/* 1728 */         binding.value = x;
/* 1729 */         binding.isNull = false;
/* 1730 */         binding.isLongData = true;
/*      */         
/* 1732 */         if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1733 */           binding.bindLength = x.length();
/*      */         } else {
/* 1735 */           binding.bindLength = -1L;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1746 */     setByte(parameterIndex, (byte)(x ? 1 : 0));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 1754 */     checkClosed();
/*      */     
/* 1756 */     BindValue binding = getBinding(parameterIndex, false);
/* 1757 */     setType(binding, 1);
/*      */     
/* 1759 */     binding.value = null;
/* 1760 */     binding.longBinding = x;
/* 1761 */     binding.isNull = false;
/* 1762 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1770 */     checkClosed();
/*      */     
/* 1772 */     if (x == null) {
/* 1773 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1775 */       BindValue binding = getBinding(parameterIndex, false);
/* 1776 */       setType(binding, 253);
/*      */       
/* 1778 */       binding.value = x;
/* 1779 */       binding.isNull = false;
/* 1780 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1789 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1791 */       if (reader == null) {
/* 1792 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 1794 */         BindValue binding = getBinding(parameterIndex, true);
/* 1795 */         setType(binding, 252);
/*      */         
/* 1797 */         binding.value = reader;
/* 1798 */         binding.isNull = false;
/* 1799 */         binding.isLongData = true;
/*      */         
/* 1801 */         if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1802 */           binding.bindLength = length;
/*      */         } else {
/* 1804 */           binding.bindLength = -1L;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setClob(int parameterIndex, Clob x)
/*      */     throws SQLException
/*      */   {
/* 1815 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1817 */       if (x == null) {
/* 1818 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 1820 */         BindValue binding = getBinding(parameterIndex, true);
/* 1821 */         setType(binding, 252);
/*      */         
/* 1823 */         binding.value = x.getCharacterStream();
/* 1824 */         binding.isNull = false;
/* 1825 */         binding.isLongData = true;
/*      */         
/* 1827 */         if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1828 */           binding.bindLength = x.length();
/*      */         } else {
/* 1830 */           binding.bindLength = -1L;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x)
/*      */     throws SQLException
/*      */   {
/* 1850 */     setDate(parameterIndex, x, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1869 */     if (x == null) {
/* 1870 */       setNull(parameterIndex, 91);
/*      */     } else {
/* 1872 */       BindValue binding = getBinding(parameterIndex, false);
/* 1873 */       setType(binding, 10);
/*      */       
/* 1875 */       binding.value = x;
/* 1876 */       binding.isNull = false;
/* 1877 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 1886 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1888 */       if ((!this.connection.getAllowNanAndInf()) && ((x == Double.POSITIVE_INFINITY) || (x == Double.NEGATIVE_INFINITY) || (Double.isNaN(x)))) {
/* 1889 */         throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1894 */       BindValue binding = getBinding(parameterIndex, false);
/* 1895 */       setType(binding, 5);
/*      */       
/* 1897 */       binding.value = null;
/* 1898 */       binding.doubleBinding = x;
/* 1899 */       binding.isNull = false;
/* 1900 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 1909 */     checkClosed();
/*      */     
/* 1911 */     BindValue binding = getBinding(parameterIndex, false);
/* 1912 */     setType(binding, 4);
/*      */     
/* 1914 */     binding.value = null;
/* 1915 */     binding.floatBinding = x;
/* 1916 */     binding.isNull = false;
/* 1917 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 1925 */     checkClosed();
/*      */     
/* 1927 */     BindValue binding = getBinding(parameterIndex, false);
/* 1928 */     setType(binding, 3);
/*      */     
/* 1930 */     binding.value = null;
/* 1931 */     binding.longBinding = x;
/* 1932 */     binding.isNull = false;
/* 1933 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 1941 */     checkClosed();
/*      */     
/* 1943 */     BindValue binding = getBinding(parameterIndex, false);
/* 1944 */     setType(binding, 8);
/*      */     
/* 1946 */     binding.value = null;
/* 1947 */     binding.longBinding = x;
/* 1948 */     binding.isNull = false;
/* 1949 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1957 */     checkClosed();
/*      */     
/* 1959 */     BindValue binding = getBinding(parameterIndex, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1965 */     if (binding.bufferType == 0) {
/* 1966 */       setType(binding, 6);
/*      */     }
/*      */     
/* 1969 */     binding.value = null;
/* 1970 */     binding.isNull = true;
/* 1971 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1979 */     checkClosed();
/*      */     
/* 1981 */     BindValue binding = getBinding(parameterIndex, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1986 */     if (binding.bufferType == 0) {
/* 1987 */       setType(binding, 6);
/*      */     }
/*      */     
/* 1990 */     binding.value = null;
/* 1991 */     binding.isNull = true;
/* 1992 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/* 2000 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 2008 */     checkClosed();
/*      */     
/* 2010 */     BindValue binding = getBinding(parameterIndex, false);
/* 2011 */     setType(binding, 2);
/*      */     
/* 2013 */     binding.value = null;
/* 2014 */     binding.longBinding = x;
/* 2015 */     binding.isNull = false;
/* 2016 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 2024 */     checkClosed();
/*      */     
/* 2026 */     if (x == null) {
/* 2027 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 2029 */       BindValue binding = getBinding(parameterIndex, false);
/*      */       
/* 2031 */       setType(binding, this.stringTypeCode);
/*      */       
/* 2033 */       binding.value = x;
/* 2034 */       binding.isNull = false;
/* 2035 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 2052 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2053 */       setTimeInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2074 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2075 */       setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 2095 */     if (x == null) {
/* 2096 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 2098 */       BindValue binding = getBinding(parameterIndex, false);
/* 2099 */       setType(binding, 11);
/*      */       
/* 2101 */       if (!this.useLegacyDatetimeCode) {
/* 2102 */         binding.value = x;
/*      */       } else {
/* 2104 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 2106 */         binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */       }
/*      */       
/*      */ 
/* 2110 */       binding.isNull = false;
/* 2111 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2129 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2130 */       setTimestampInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2150 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2151 */       setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */     }
/*      */   }
/*      */   
/*      */   private void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 2156 */     if (x == null) {
/* 2157 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 2159 */       BindValue binding = getBinding(parameterIndex, false);
/* 2160 */       setType(binding, 12);
/*      */       
/* 2162 */       if (!this.useLegacyDatetimeCode) {
/* 2163 */         binding.value = x;
/*      */       } else {
/* 2165 */         Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */         
/*      */ 
/* 2168 */         binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         
/*      */ 
/* 2171 */         binding.isNull = false;
/* 2172 */         binding.isLongData = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setType(BindValue oldValue, int bufferType) throws SQLException {
/* 2178 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2179 */       if (oldValue.bufferType != bufferType) {
/* 2180 */         this.sendTypesToServer = true;
/*      */       }
/*      */       
/* 2183 */       oldValue.bufferType = bufferType;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2201 */     checkClosed();
/*      */     
/* 2203 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setURL(int parameterIndex, URL x)
/*      */     throws SQLException
/*      */   {
/* 2211 */     checkClosed();
/*      */     
/* 2213 */     setString(parameterIndex, x.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void storeBinding(Buffer packet, BindValue bindValue, MysqlIO mysql)
/*      */     throws SQLException
/*      */   {
/* 2226 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 2228 */         Object value = bindValue.value;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2233 */         switch (bindValue.bufferType)
/*      */         {
/*      */         case 1: 
/* 2236 */           packet.writeByte((byte)(int)bindValue.longBinding);
/* 2237 */           return;
/*      */         case 2: 
/* 2239 */           packet.ensureCapacity(2);
/* 2240 */           packet.writeInt((int)bindValue.longBinding);
/* 2241 */           return;
/*      */         case 3: 
/* 2243 */           packet.ensureCapacity(4);
/* 2244 */           packet.writeLong((int)bindValue.longBinding);
/* 2245 */           return;
/*      */         case 8: 
/* 2247 */           packet.ensureCapacity(8);
/* 2248 */           packet.writeLongLong(bindValue.longBinding);
/* 2249 */           return;
/*      */         case 4: 
/* 2251 */           packet.ensureCapacity(4);
/* 2252 */           packet.writeFloat(bindValue.floatBinding);
/* 2253 */           return;
/*      */         case 5: 
/* 2255 */           packet.ensureCapacity(8);
/* 2256 */           packet.writeDouble(bindValue.doubleBinding);
/* 2257 */           return;
/*      */         case 11: 
/* 2259 */           storeTime(packet, (Time)value);
/* 2260 */           return;
/*      */         case 7: 
/*      */         case 10: 
/*      */         case 12: 
/* 2264 */           storeDateTime(packet, (java.util.Date)value, mysql, bindValue.bufferType);
/* 2265 */           return;
/*      */         case 0: 
/*      */         case 15: 
/*      */         case 246: 
/*      */         case 253: 
/*      */         case 254: 
/* 2271 */           if ((value instanceof byte[])) {
/* 2272 */             packet.writeLenBytes((byte[])value);
/* 2273 */           } else if (!this.isLoadDataQuery) {
/* 2274 */             packet.writeLenString((String)value, this.charEncoding, this.connection.getServerCharset(), this.charConverter, this.connection.parserKnowsUnicode(), this.connection);
/*      */           }
/*      */           else {
/* 2277 */             packet.writeLenBytes(StringUtils.getBytes((String)value));
/*      */           }
/*      */           
/* 2280 */           return;
/*      */         }
/*      */       }
/*      */       catch (UnsupportedEncodingException uEE) {
/* 2284 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.22") + this.connection.getEncoding() + "'", "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void storeDateTime412AndOlder(Buffer intoBuf, java.util.Date dt, int bufferType) throws SQLException
/*      */   {
/* 2291 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2292 */       Calendar sessionCalendar = null;
/*      */       
/* 2294 */       if (!this.useLegacyDatetimeCode) {
/* 2295 */         if (bufferType == 10) {
/* 2296 */           sessionCalendar = getDefaultTzCalendar();
/*      */         } else {
/* 2298 */           sessionCalendar = getServerTzCalendar();
/*      */         }
/*      */       } else {
/* 2301 */         sessionCalendar = ((dt instanceof Timestamp)) && (this.connection.getUseJDBCCompliantTimezoneShift()) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */       }
/*      */       
/*      */ 
/* 2305 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try
/*      */       {
/* 2308 */         intoBuf.ensureCapacity(8);
/* 2309 */         intoBuf.writeByte((byte)7);
/*      */         
/* 2311 */         sessionCalendar.setTime(dt);
/*      */         
/* 2313 */         int year = sessionCalendar.get(1);
/* 2314 */         int month = sessionCalendar.get(2) + 1;
/* 2315 */         int date = sessionCalendar.get(5);
/*      */         
/* 2317 */         intoBuf.writeInt(year);
/* 2318 */         intoBuf.writeByte((byte)month);
/* 2319 */         intoBuf.writeByte((byte)date);
/*      */         
/* 2321 */         if ((dt instanceof java.sql.Date)) {
/* 2322 */           intoBuf.writeByte((byte)0);
/* 2323 */           intoBuf.writeByte((byte)0);
/* 2324 */           intoBuf.writeByte((byte)0);
/*      */         } else {
/* 2326 */           intoBuf.writeByte((byte)sessionCalendar.get(11));
/* 2327 */           intoBuf.writeByte((byte)sessionCalendar.get(12));
/* 2328 */           intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */         }
/*      */       } finally {
/* 2331 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void storeDateTime(Buffer intoBuf, java.util.Date dt, MysqlIO mysql, int bufferType)
/*      */     throws SQLException
/*      */   {
/* 2344 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2345 */       if (this.connection.versionMeetsMinimum(4, 1, 3)) {
/* 2346 */         storeDateTime413AndNewer(intoBuf, dt, bufferType);
/*      */       } else {
/* 2348 */         storeDateTime412AndOlder(intoBuf, dt, bufferType);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void storeDateTime413AndNewer(Buffer intoBuf, java.util.Date dt, int bufferType) throws SQLException {
/* 2354 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2355 */       Calendar sessionCalendar = null;
/*      */       
/* 2357 */       if (!this.useLegacyDatetimeCode) {
/* 2358 */         if (bufferType == 10) {
/* 2359 */           sessionCalendar = getDefaultTzCalendar();
/*      */         } else {
/* 2361 */           sessionCalendar = getServerTzCalendar();
/*      */         }
/*      */       } else {
/* 2364 */         sessionCalendar = ((dt instanceof Timestamp)) && (this.connection.getUseJDBCCompliantTimezoneShift()) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */       }
/*      */       
/*      */ 
/* 2368 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try
/*      */       {
/* 2371 */         sessionCalendar.setTime(dt);
/*      */         
/* 2373 */         if ((dt instanceof java.sql.Date)) {
/* 2374 */           sessionCalendar.set(11, 0);
/* 2375 */           sessionCalendar.set(12, 0);
/* 2376 */           sessionCalendar.set(13, 0);
/*      */         }
/*      */         
/* 2379 */         byte length = 7;
/*      */         
/* 2381 */         if ((dt instanceof Timestamp)) {
/* 2382 */           length = 11;
/*      */         }
/*      */         
/* 2385 */         intoBuf.ensureCapacity(length);
/*      */         
/* 2387 */         intoBuf.writeByte(length);
/*      */         
/* 2389 */         int year = sessionCalendar.get(1);
/* 2390 */         int month = sessionCalendar.get(2) + 1;
/* 2391 */         int date = sessionCalendar.get(5);
/*      */         
/* 2393 */         intoBuf.writeInt(year);
/* 2394 */         intoBuf.writeByte((byte)month);
/* 2395 */         intoBuf.writeByte((byte)date);
/*      */         
/* 2397 */         if ((dt instanceof java.sql.Date)) {
/* 2398 */           intoBuf.writeByte((byte)0);
/* 2399 */           intoBuf.writeByte((byte)0);
/* 2400 */           intoBuf.writeByte((byte)0);
/*      */         } else {
/* 2402 */           intoBuf.writeByte((byte)sessionCalendar.get(11));
/* 2403 */           intoBuf.writeByte((byte)sessionCalendar.get(12));
/* 2404 */           intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */         }
/*      */         
/* 2407 */         if (length == 11)
/*      */         {
/* 2409 */           intoBuf.writeLong(((Timestamp)dt).getNanos() / 1000);
/*      */         }
/*      */       }
/*      */       finally {
/* 2413 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Calendar getServerTzCalendar() throws SQLException {
/* 2419 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2420 */       if (this.serverTzCalendar == null) {
/* 2421 */         this.serverTzCalendar = new GregorianCalendar(this.connection.getServerTimezoneTZ());
/*      */       }
/*      */       
/* 2424 */       return this.serverTzCalendar;
/*      */     }
/*      */   }
/*      */   
/*      */   private Calendar getDefaultTzCalendar() throws SQLException {
/* 2429 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2430 */       if (this.defaultTzCalendar == null) {
/* 2431 */         this.defaultTzCalendar = new GregorianCalendar(TimeZone.getDefault());
/*      */       }
/*      */       
/* 2434 */       return this.defaultTzCalendar;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void storeReader(MysqlIO mysql, int parameterIndex, Buffer packet, Reader inStream)
/*      */     throws SQLException
/*      */   {
/* 2442 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2443 */       String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */       
/* 2445 */       String clobEncoding = forcedEncoding == null ? this.connection.getEncoding() : forcedEncoding;
/*      */       
/* 2447 */       int maxBytesChar = 2;
/*      */       
/* 2449 */       if (clobEncoding != null) {
/* 2450 */         if (!clobEncoding.equals("UTF-16")) {
/* 2451 */           maxBytesChar = this.connection.getMaxBytesPerChar(clobEncoding);
/*      */           
/* 2453 */           if (maxBytesChar == 1) {
/* 2454 */             maxBytesChar = 2;
/*      */           }
/*      */         } else {
/* 2457 */           maxBytesChar = 4;
/*      */         }
/*      */       }
/*      */       
/* 2461 */       char[] buf = new char[8192 / maxBytesChar];
/*      */       
/* 2463 */       int numRead = 0;
/*      */       
/* 2465 */       int bytesInPacket = 0;
/* 2466 */       int totalBytesRead = 0;
/* 2467 */       int bytesReadAtLastSend = 0;
/* 2468 */       int packetIsFullAt = this.connection.getBlobSendChunkSize();
/*      */       try
/*      */       {
/* 2471 */         packet.clear();
/* 2472 */         packet.writeByte((byte)24);
/* 2473 */         packet.writeLong(this.serverStatementId);
/* 2474 */         packet.writeInt(parameterIndex);
/*      */         
/* 2476 */         boolean readAny = false;
/*      */         
/* 2478 */         while ((numRead = inStream.read(buf)) != -1) {
/* 2479 */           readAny = true;
/*      */           
/* 2481 */           byte[] valueAsBytes = StringUtils.getBytes(buf, null, clobEncoding, this.connection.getServerCharset(), 0, numRead, this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           
/*      */ 
/* 2484 */           packet.writeBytesNoNull(valueAsBytes, 0, valueAsBytes.length);
/*      */           
/* 2486 */           bytesInPacket += valueAsBytes.length;
/* 2487 */           totalBytesRead += valueAsBytes.length;
/*      */           
/* 2489 */           if (bytesInPacket >= packetIsFullAt) {
/* 2490 */             bytesReadAtLastSend = totalBytesRead;
/*      */             
/* 2492 */             mysql.sendCommand(24, null, packet, true, null, 0);
/*      */             
/* 2494 */             bytesInPacket = 0;
/* 2495 */             packet.clear();
/* 2496 */             packet.writeByte((byte)24);
/* 2497 */             packet.writeLong(this.serverStatementId);
/* 2498 */             packet.writeInt(parameterIndex);
/*      */           }
/*      */         }
/*      */         
/* 2502 */         if (totalBytesRead != bytesReadAtLastSend) {
/* 2503 */           mysql.sendCommand(24, null, packet, true, null, 0);
/*      */         }
/*      */         
/* 2506 */         if (!readAny) {
/* 2507 */           mysql.sendCommand(24, null, packet, true, null, 0);
/*      */         }
/*      */       } catch (IOException ioEx) {
/* 2510 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.24") + ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */         
/* 2512 */         sqlEx.initCause(ioEx);
/*      */         
/* 2514 */         throw sqlEx;
/*      */       } finally {
/* 2516 */         if ((this.connection.getAutoClosePStmtStreams()) && 
/* 2517 */           (inStream != null)) {
/*      */           try {
/* 2519 */             inStream.close();
/*      */           }
/*      */           catch (IOException ioEx) {}
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void storeStream(MysqlIO mysql, int parameterIndex, Buffer packet, InputStream inStream)
/*      */     throws SQLException
/*      */   {
/* 2530 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2531 */       byte[] buf = new byte[' '];
/*      */       
/* 2533 */       int numRead = 0;
/*      */       try
/*      */       {
/* 2536 */         int bytesInPacket = 0;
/* 2537 */         int totalBytesRead = 0;
/* 2538 */         int bytesReadAtLastSend = 0;
/* 2539 */         int packetIsFullAt = this.connection.getBlobSendChunkSize();
/*      */         
/* 2541 */         packet.clear();
/* 2542 */         packet.writeByte((byte)24);
/* 2543 */         packet.writeLong(this.serverStatementId);
/* 2544 */         packet.writeInt(parameterIndex);
/*      */         
/* 2546 */         boolean readAny = false;
/*      */         
/* 2548 */         while ((numRead = inStream.read(buf)) != -1)
/*      */         {
/* 2550 */           readAny = true;
/*      */           
/* 2552 */           packet.writeBytesNoNull(buf, 0, numRead);
/* 2553 */           bytesInPacket += numRead;
/* 2554 */           totalBytesRead += numRead;
/*      */           
/* 2556 */           if (bytesInPacket >= packetIsFullAt) {
/* 2557 */             bytesReadAtLastSend = totalBytesRead;
/*      */             
/* 2559 */             mysql.sendCommand(24, null, packet, true, null, 0);
/*      */             
/* 2561 */             bytesInPacket = 0;
/* 2562 */             packet.clear();
/* 2563 */             packet.writeByte((byte)24);
/* 2564 */             packet.writeLong(this.serverStatementId);
/* 2565 */             packet.writeInt(parameterIndex);
/*      */           }
/*      */         }
/*      */         
/* 2569 */         if (totalBytesRead != bytesReadAtLastSend) {
/* 2570 */           mysql.sendCommand(24, null, packet, true, null, 0);
/*      */         }
/*      */         
/* 2573 */         if (!readAny) {
/* 2574 */           mysql.sendCommand(24, null, packet, true, null, 0);
/*      */         }
/*      */       } catch (IOException ioEx) {
/* 2577 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.25") + ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */         
/* 2579 */         sqlEx.initCause(ioEx);
/*      */         
/* 2581 */         throw sqlEx;
/*      */       } finally {
/* 2583 */         if ((this.connection.getAutoClosePStmtStreams()) && 
/* 2584 */           (inStream != null)) {
/*      */           try {
/* 2586 */             inStream.close();
/*      */           }
/*      */           catch (IOException ioEx) {}
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2601 */     StringBuilder toStringBuf = new StringBuilder();
/*      */     
/* 2603 */     toStringBuf.append("com.mysql.jdbc.ServerPreparedStatement[");
/* 2604 */     toStringBuf.append(this.serverStatementId);
/* 2605 */     toStringBuf.append("] - ");
/*      */     try
/*      */     {
/* 2608 */       toStringBuf.append(asSql());
/*      */     } catch (SQLException sqlEx) {
/* 2610 */       toStringBuf.append(Messages.getString("ServerPreparedStatement.6"));
/* 2611 */       toStringBuf.append(sqlEx);
/*      */     }
/*      */     
/* 2614 */     return toStringBuf.toString();
/*      */   }
/*      */   
/*      */   protected long getServerStatementId() {
/* 2618 */     return this.serverStatementId;
/*      */   }
/*      */   
/* 2621 */   private boolean hasCheckedRewrite = false;
/* 2622 */   private boolean canRewrite = false;
/*      */   
/*      */   public boolean canRewriteAsMultiValueInsertAtSqlLevel() throws SQLException
/*      */   {
/* 2626 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2627 */       if (!this.hasCheckedRewrite) {
/* 2628 */         this.hasCheckedRewrite = true;
/* 2629 */         this.canRewrite = canRewrite(this.originalSql, isOnDuplicateKeyUpdate(), getLocationOfOnDuplicateKeyUpdate(), 0);
/*      */         
/* 2631 */         this.parseInfo = new PreparedStatement.ParseInfo(this.originalSql, this.connection, this.connection.getMetaData(), this.charEncoding, this.charConverter);
/*      */       }
/*      */       
/* 2634 */       return this.canRewrite;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean canRewriteAsMultivalueInsertStatement() throws SQLException {
/* 2639 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2640 */       if (!canRewriteAsMultiValueInsertAtSqlLevel()) {
/* 2641 */         return false;
/*      */       }
/*      */       
/* 2644 */       BindValue[] currentBindValues = null;
/* 2645 */       BindValue[] previousBindValues = null;
/*      */       
/* 2647 */       int nbrCommands = this.batchedArgs.size();
/*      */       
/*      */ 
/*      */ 
/* 2651 */       for (int commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/* 2652 */         Object arg = this.batchedArgs.get(commandIndex);
/*      */         
/* 2654 */         if (!(arg instanceof String))
/*      */         {
/* 2656 */           currentBindValues = ((BatchedBindValues)arg).batchedParameterValues;
/*      */           
/*      */ 
/*      */ 
/* 2660 */           if (previousBindValues != null) {
/* 2661 */             for (int j = 0; j < this.parameterBindings.length; j++) {
/* 2662 */               if (currentBindValues[j].bufferType != previousBindValues[j].bufferType) {
/* 2663 */                 return false;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2670 */       return true;
/*      */     }
/*      */   }
/*      */   
/* 2674 */   private int locationOfOnDuplicateKeyUpdate = -2;
/*      */   
/*      */   protected int getLocationOfOnDuplicateKeyUpdate() throws SQLException
/*      */   {
/* 2678 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2679 */       if (this.locationOfOnDuplicateKeyUpdate == -2) {
/* 2680 */         this.locationOfOnDuplicateKeyUpdate = getOnDuplicateKeyLocation(this.originalSql, this.connection.getDontCheckOnDuplicateKeyUpdateInSQL(), this.connection.getRewriteBatchedStatements(), this.connection.isNoBackslashEscapesSet());
/*      */       }
/*      */       
/*      */ 
/* 2684 */       return this.locationOfOnDuplicateKeyUpdate;
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean isOnDuplicateKeyUpdate() throws SQLException {
/* 2689 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2690 */       return getLocationOfOnDuplicateKeyUpdate() != -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs)
/*      */     throws SQLException
/*      */   {
/* 2702 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2703 */       long sizeOfEntireBatch = 10L;
/* 2704 */       long maxSizeOfParameterSet = 0L;
/*      */       
/* 2706 */       for (int i = 0; i < numBatchedArgs; i++) {
/* 2707 */         BindValue[] paramArg = ((BatchedBindValues)this.batchedArgs.get(i)).batchedParameterValues;
/*      */         
/* 2709 */         long sizeOfParameterSet = 0L;
/*      */         
/* 2711 */         sizeOfParameterSet += (this.parameterCount + 7) / 8;
/*      */         
/* 2713 */         sizeOfParameterSet += this.parameterCount * 2;
/*      */         
/* 2715 */         for (int j = 0; j < this.parameterBindings.length; j++) {
/* 2716 */           if (!paramArg[j].isNull)
/*      */           {
/* 2718 */             long size = paramArg[j].getBoundLength();
/*      */             
/* 2720 */             if (paramArg[j].isLongData) {
/* 2721 */               if (size != -1L) {
/* 2722 */                 sizeOfParameterSet += size;
/*      */               }
/*      */             } else {
/* 2725 */               sizeOfParameterSet += size;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 2730 */         sizeOfEntireBatch += sizeOfParameterSet;
/*      */         
/* 2732 */         if (sizeOfParameterSet > maxSizeOfParameterSet) {
/* 2733 */           maxSizeOfParameterSet = sizeOfParameterSet;
/*      */         }
/*      */       }
/*      */       
/* 2737 */       return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
/*      */     }
/*      */   }
/*      */   
/*      */   protected int setOneBatchedParameterSet(java.sql.PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet) throws SQLException
/*      */   {
/* 2743 */     BindValue[] paramArg = ((BatchedBindValues)paramSet).batchedParameterValues;
/*      */     
/* 2745 */     for (int j = 0; j < paramArg.length; j++) {
/* 2746 */       if (paramArg[j].isNull) {
/* 2747 */         batchedStatement.setNull(batchedParamIndex++, 0);
/*      */       }
/* 2749 */       else if (paramArg[j].isLongData) {
/* 2750 */         Object value = paramArg[j].value;
/*      */         
/* 2752 */         if ((value instanceof InputStream)) {
/* 2753 */           batchedStatement.setBinaryStream(batchedParamIndex++, (InputStream)value, (int)paramArg[j].bindLength);
/*      */         } else {
/* 2755 */           batchedStatement.setCharacterStream(batchedParamIndex++, (Reader)value, (int)paramArg[j].bindLength);
/*      */         }
/*      */       }
/*      */       else {
/* 2759 */         switch (paramArg[j].bufferType)
/*      */         {
/*      */         case 1: 
/* 2762 */           batchedStatement.setByte(batchedParamIndex++, (byte)(int)paramArg[j].longBinding);
/* 2763 */           break;
/*      */         case 2: 
/* 2765 */           batchedStatement.setShort(batchedParamIndex++, (short)(int)paramArg[j].longBinding);
/* 2766 */           break;
/*      */         case 3: 
/* 2768 */           batchedStatement.setInt(batchedParamIndex++, (int)paramArg[j].longBinding);
/* 2769 */           break;
/*      */         case 8: 
/* 2771 */           batchedStatement.setLong(batchedParamIndex++, paramArg[j].longBinding);
/* 2772 */           break;
/*      */         case 4: 
/* 2774 */           batchedStatement.setFloat(batchedParamIndex++, paramArg[j].floatBinding);
/* 2775 */           break;
/*      */         case 5: 
/* 2777 */           batchedStatement.setDouble(batchedParamIndex++, paramArg[j].doubleBinding);
/* 2778 */           break;
/*      */         case 11: 
/* 2780 */           batchedStatement.setTime(batchedParamIndex++, (Time)paramArg[j].value);
/* 2781 */           break;
/*      */         case 10: 
/* 2783 */           batchedStatement.setDate(batchedParamIndex++, (java.sql.Date)paramArg[j].value);
/* 2784 */           break;
/*      */         case 7: 
/*      */         case 12: 
/* 2787 */           batchedStatement.setTimestamp(batchedParamIndex++, (Timestamp)paramArg[j].value);
/* 2788 */           break;
/*      */         case 0: 
/*      */         case 15: 
/*      */         case 246: 
/*      */         case 253: 
/*      */         case 254: 
/* 2794 */           Object value = paramArg[j].value;
/*      */           
/* 2796 */           if ((value instanceof byte[])) {
/* 2797 */             batchedStatement.setBytes(batchedParamIndex, (byte[])value);
/*      */           } else {
/* 2799 */             batchedStatement.setString(batchedParamIndex, (String)value);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 2804 */           if ((batchedStatement instanceof ServerPreparedStatement)) {
/* 2805 */             BindValue asBound = ((ServerPreparedStatement)batchedStatement).getBinding(batchedParamIndex, false);
/* 2806 */             asBound.bufferType = paramArg[j].bufferType;
/*      */           }
/*      */           
/* 2809 */           batchedParamIndex++;
/*      */           
/* 2811 */           break;
/*      */         default: 
/* 2813 */           throw new IllegalArgumentException("Unknown type when re-binding parameter into batched statement for parameter index " + batchedParamIndex);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2820 */     return batchedParamIndex;
/*      */   }
/*      */   
/*      */   protected boolean containsOnDuplicateKeyUpdateInSQL()
/*      */   {
/* 2825 */     return this.hasOnDuplicateKeyUpdate;
/*      */   }
/*      */   
/*      */   protected PreparedStatement prepareBatchedInsertSQL(MySQLConnection localConn, int numBatches) throws SQLException
/*      */   {
/* 2830 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 2832 */         PreparedStatement pstmt = new ServerPreparedStatement(localConn, this.parseInfo.getSqlForBatch(numBatches), this.currentCatalog, this.resultSetConcurrency, this.resultSetType);
/*      */         
/* 2834 */         pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);
/*      */         
/* 2836 */         return pstmt;
/*      */       } catch (UnsupportedEncodingException e) {
/* 2838 */         SQLException sqlEx = SQLError.createSQLException("Unable to prepare batch statement", "S1000", getExceptionInterceptor());
/*      */         
/* 2840 */         sqlEx.initCause(e);
/*      */         
/* 2842 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ServerPreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */