/*     */ package com.mysql.jdbc.util;
/*     */ 
/*     */ import com.mysql.jdbc.log.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadAheadInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   private InputStream underlyingStream;
/*     */   private byte[] buf;
/*     */   protected int endOfCurrentData;
/*     */   protected int currentPosition;
/*  46 */   protected boolean doDebug = false;
/*     */   protected Log log;
/*     */   
/*     */   private void fill(int readAtLeastTheseManyBytes) throws IOException
/*     */   {
/*  51 */     checkClosed();
/*     */     
/*  53 */     this.currentPosition = 0;
/*     */     
/*  55 */     this.endOfCurrentData = this.currentPosition;
/*     */     
/*     */ 
/*     */ 
/*  59 */     int bytesToRead = Math.min(this.buf.length - this.currentPosition, readAtLeastTheseManyBytes);
/*     */     
/*  61 */     int bytesAvailable = this.underlyingStream.available();
/*     */     
/*  63 */     if (bytesAvailable > bytesToRead)
/*     */     {
/*     */ 
/*     */ 
/*  67 */       bytesToRead = Math.min(this.buf.length - this.currentPosition, bytesAvailable);
/*     */     }
/*     */     
/*  70 */     if (this.doDebug) {
/*  71 */       StringBuilder debugBuf = new StringBuilder();
/*  72 */       debugBuf.append("  ReadAheadInputStream.fill(");
/*  73 */       debugBuf.append(readAtLeastTheseManyBytes);
/*  74 */       debugBuf.append("), buffer_size=");
/*  75 */       debugBuf.append(this.buf.length);
/*  76 */       debugBuf.append(", current_position=");
/*  77 */       debugBuf.append(this.currentPosition);
/*  78 */       debugBuf.append(", need to read ");
/*  79 */       debugBuf.append(Math.min(this.buf.length - this.currentPosition, readAtLeastTheseManyBytes));
/*  80 */       debugBuf.append(" bytes to fill request,");
/*     */       
/*  82 */       if (bytesAvailable > 0) {
/*  83 */         debugBuf.append(" underlying InputStream reports ");
/*  84 */         debugBuf.append(bytesAvailable);
/*     */         
/*  86 */         debugBuf.append(" total bytes available,");
/*     */       }
/*     */       
/*  89 */       debugBuf.append(" attempting to read ");
/*  90 */       debugBuf.append(bytesToRead);
/*  91 */       debugBuf.append(" bytes.");
/*     */       
/*  93 */       if (this.log != null) {
/*  94 */         this.log.logTrace(debugBuf.toString());
/*     */       } else {
/*  96 */         System.err.println(debugBuf.toString());
/*     */       }
/*     */     }
/*     */     
/* 100 */     int n = this.underlyingStream.read(this.buf, this.currentPosition, bytesToRead);
/*     */     
/* 102 */     if (n > 0) {
/* 103 */       this.endOfCurrentData = (n + this.currentPosition);
/*     */     }
/*     */   }
/*     */   
/*     */   private int readFromUnderlyingStreamIfNecessary(byte[] b, int off, int len) throws IOException {
/* 108 */     checkClosed();
/*     */     
/* 110 */     int avail = this.endOfCurrentData - this.currentPosition;
/*     */     
/* 112 */     if (this.doDebug) {
/* 113 */       StringBuilder debugBuf = new StringBuilder();
/* 114 */       debugBuf.append("ReadAheadInputStream.readIfNecessary(");
/* 115 */       debugBuf.append(b);
/* 116 */       debugBuf.append(",");
/* 117 */       debugBuf.append(off);
/* 118 */       debugBuf.append(",");
/* 119 */       debugBuf.append(len);
/* 120 */       debugBuf.append(")");
/*     */       
/* 122 */       if (avail <= 0) {
/* 123 */         debugBuf.append(" not all data available in buffer, must read from stream");
/*     */         
/* 125 */         if (len >= this.buf.length) {
/* 126 */           debugBuf.append(", amount requested > buffer, returning direct read() from stream");
/*     */         }
/*     */       }
/*     */       
/* 130 */       if (this.log != null) {
/* 131 */         this.log.logTrace(debugBuf.toString());
/*     */       } else {
/* 133 */         System.err.println(debugBuf.toString());
/*     */       }
/*     */     }
/*     */     
/* 137 */     if (avail <= 0)
/*     */     {
/* 139 */       if (len >= this.buf.length) {
/* 140 */         return this.underlyingStream.read(b, off, len);
/*     */       }
/*     */       
/* 143 */       fill(len);
/*     */       
/* 145 */       avail = this.endOfCurrentData - this.currentPosition;
/*     */       
/* 147 */       if (avail <= 0) {
/* 148 */         return -1;
/*     */       }
/*     */     }
/*     */     
/* 152 */     int bytesActuallyRead = avail < len ? avail : len;
/*     */     
/* 154 */     System.arraycopy(this.buf, this.currentPosition, b, off, bytesActuallyRead);
/*     */     
/* 156 */     this.currentPosition += bytesActuallyRead;
/*     */     
/* 158 */     return bytesActuallyRead;
/*     */   }
/*     */   
/*     */   public synchronized int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 163 */     checkClosed();
/* 164 */     if ((off | len | off + len | b.length - (off + len)) < 0)
/* 165 */       throw new IndexOutOfBoundsException();
/* 166 */     if (len == 0) {
/* 167 */       return 0;
/*     */     }
/*     */     
/* 170 */     int totalBytesRead = 0;
/*     */     for (;;)
/*     */     {
/* 173 */       int bytesReadThisRound = readFromUnderlyingStreamIfNecessary(b, off + totalBytesRead, len - totalBytesRead);
/*     */       
/*     */ 
/* 176 */       if (bytesReadThisRound <= 0) {
/* 177 */         if (totalBytesRead == 0) {
/* 178 */           totalBytesRead = bytesReadThisRound;
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 184 */         totalBytesRead += bytesReadThisRound;
/*     */         
/*     */ 
/* 187 */         if (totalBytesRead < len)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 192 */           if (this.underlyingStream.available() <= 0)
/*     */             break;
/*     */         }
/*     */       }
/*     */     }
/* 197 */     return totalBytesRead;
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 202 */     checkClosed();
/*     */     
/* 204 */     if (this.currentPosition >= this.endOfCurrentData) {
/* 205 */       fill(1);
/* 206 */       if (this.currentPosition >= this.endOfCurrentData) {
/* 207 */         return -1;
/*     */       }
/*     */     }
/*     */     
/* 211 */     return this.buf[(this.currentPosition++)] & 0xFF;
/*     */   }
/*     */   
/*     */   public int available() throws IOException
/*     */   {
/* 216 */     checkClosed();
/*     */     
/* 218 */     return this.underlyingStream.available() + (this.endOfCurrentData - this.currentPosition);
/*     */   }
/*     */   
/*     */   private void checkClosed() throws IOException
/*     */   {
/* 223 */     if (this.buf == null) {
/* 224 */       throw new IOException("Stream closed");
/*     */     }
/*     */   }
/*     */   
/*     */   public ReadAheadInputStream(InputStream toBuffer, boolean debug, Log logTo) {
/* 229 */     this(toBuffer, 4096, debug, logTo);
/*     */   }
/*     */   
/*     */   public ReadAheadInputStream(InputStream toBuffer, int bufferSize, boolean debug, Log logTo) {
/* 233 */     this.underlyingStream = toBuffer;
/* 234 */     this.buf = new byte[bufferSize];
/* 235 */     this.doDebug = debug;
/* 236 */     this.log = logTo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 246 */     if (this.underlyingStream != null) {
/*     */       try {
/* 248 */         this.underlyingStream.close();
/*     */       } finally {
/* 250 */         this.underlyingStream = null;
/* 251 */         this.buf = null;
/* 252 */         this.log = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 264 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 274 */     checkClosed();
/* 275 */     if (n <= 0L) {
/* 276 */       return 0L;
/*     */     }
/*     */     
/* 279 */     long bytesAvailInBuffer = this.endOfCurrentData - this.currentPosition;
/*     */     
/* 281 */     if (bytesAvailInBuffer <= 0L)
/*     */     {
/* 283 */       fill((int)n);
/* 284 */       bytesAvailInBuffer = this.endOfCurrentData - this.currentPosition;
/* 285 */       if (bytesAvailInBuffer <= 0L) {
/* 286 */         return 0L;
/*     */       }
/*     */     }
/*     */     
/* 290 */     long bytesSkipped = bytesAvailInBuffer < n ? bytesAvailInBuffer : n;
/* 291 */     this.currentPosition = ((int)(this.currentPosition + bytesSkipped));
/* 292 */     return bytesSkipped;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/util/ReadAheadInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */