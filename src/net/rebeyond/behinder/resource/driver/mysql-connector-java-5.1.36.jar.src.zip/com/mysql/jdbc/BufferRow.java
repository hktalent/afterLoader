/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferRow
/*     */   extends ResultSetRow
/*     */ {
/*     */   private Buffer rowFromServer;
/*  55 */   private int homePosition = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private int preNullBitmaskHomePosition = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private int lastRequestedIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   private int lastRequestedPos;
/*     */   
/*     */ 
/*     */ 
/*     */   private Field[] metadata;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isBinaryEncoded;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean[] isNull;
/*     */   
/*     */ 
/*     */   private List<InputStream> openStreams;
/*     */   
/*     */ 
/*     */ 
/*     */   public BufferRow(Buffer buf, Field[] fields, boolean isBinaryEncoded, ExceptionInterceptor exceptionInterceptor)
/*     */     throws SQLException
/*     */   {
/*  92 */     super(exceptionInterceptor);
/*     */     
/*  94 */     this.rowFromServer = buf;
/*  95 */     this.metadata = fields;
/*  96 */     this.isBinaryEncoded = isBinaryEncoded;
/*  97 */     this.homePosition = this.rowFromServer.getPosition();
/*  98 */     this.preNullBitmaskHomePosition = this.homePosition;
/*     */     
/* 100 */     if (fields != null) {
/* 101 */       setMetadata(fields);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void closeOpenStreams()
/*     */   {
/* 107 */     if (this.openStreams != null)
/*     */     {
/*     */ 
/*     */ 
/* 111 */       Iterator<InputStream> iter = this.openStreams.iterator();
/*     */       
/* 113 */       while (iter.hasNext()) {
/*     */         try
/*     */         {
/* 116 */           ((InputStream)iter.next()).close();
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */       
/*     */ 
/* 122 */       this.openStreams.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private int findAndSeekToOffset(int index) throws SQLException {
/* 127 */     if (!this.isBinaryEncoded)
/*     */     {
/* 129 */       if (index == 0) {
/* 130 */         this.lastRequestedIndex = 0;
/* 131 */         this.lastRequestedPos = this.homePosition;
/* 132 */         this.rowFromServer.setPosition(this.homePosition);
/*     */         
/* 134 */         return 0;
/*     */       }
/*     */       
/* 137 */       if (index == this.lastRequestedIndex) {
/* 138 */         this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */         
/* 140 */         return this.lastRequestedPos;
/*     */       }
/*     */       
/* 143 */       int startingIndex = 0;
/*     */       
/* 145 */       if (index > this.lastRequestedIndex) {
/* 146 */         if (this.lastRequestedIndex >= 0) {
/* 147 */           startingIndex = this.lastRequestedIndex;
/*     */         } else {
/* 149 */           startingIndex = 0;
/*     */         }
/*     */         
/* 152 */         this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */       } else {
/* 154 */         this.rowFromServer.setPosition(this.homePosition);
/*     */       }
/*     */       
/* 157 */       for (int i = startingIndex; i < index; i++) {
/* 158 */         this.rowFromServer.fastSkipLenByteArray();
/*     */       }
/*     */       
/* 161 */       this.lastRequestedIndex = index;
/* 162 */       this.lastRequestedPos = this.rowFromServer.getPosition();
/*     */       
/* 164 */       return this.lastRequestedPos;
/*     */     }
/*     */     
/* 167 */     return findAndSeekToOffsetForBinaryEncoding(index);
/*     */   }
/*     */   
/*     */   private int findAndSeekToOffsetForBinaryEncoding(int index) throws SQLException {
/* 171 */     if (index == 0) {
/* 172 */       this.lastRequestedIndex = 0;
/* 173 */       this.lastRequestedPos = this.homePosition;
/* 174 */       this.rowFromServer.setPosition(this.homePosition);
/*     */       
/* 176 */       return 0;
/*     */     }
/*     */     
/* 179 */     if (index == this.lastRequestedIndex) {
/* 180 */       this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */       
/* 182 */       return this.lastRequestedPos;
/*     */     }
/*     */     
/* 185 */     int startingIndex = 0;
/*     */     
/* 187 */     if (index > this.lastRequestedIndex) {
/* 188 */       if (this.lastRequestedIndex >= 0) {
/* 189 */         startingIndex = this.lastRequestedIndex;
/*     */       }
/*     */       else {
/* 192 */         startingIndex = 0;
/* 193 */         this.lastRequestedPos = this.homePosition;
/*     */       }
/*     */       
/* 196 */       this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */     } else {
/* 198 */       this.rowFromServer.setPosition(this.homePosition);
/*     */     }
/*     */     
/* 201 */     for (int i = startingIndex; i < index; i++) {
/* 202 */       if (this.isNull[i] == 0)
/*     */       {
/*     */ 
/*     */ 
/* 206 */         int curPosition = this.rowFromServer.getPosition();
/*     */         
/* 208 */         switch (this.metadata[i].getMysqlType())
/*     */         {
/*     */         case 6: 
/*     */           break;
/*     */         
/*     */         case 1: 
/* 214 */           this.rowFromServer.setPosition(curPosition + 1);
/* 215 */           break;
/*     */         
/*     */         case 2: 
/*     */         case 13: 
/* 219 */           this.rowFromServer.setPosition(curPosition + 2);
/*     */           
/* 221 */           break;
/*     */         case 3: 
/*     */         case 9: 
/* 224 */           this.rowFromServer.setPosition(curPosition + 4);
/*     */           
/* 226 */           break;
/*     */         case 8: 
/* 228 */           this.rowFromServer.setPosition(curPosition + 8);
/*     */           
/* 230 */           break;
/*     */         case 4: 
/* 232 */           this.rowFromServer.setPosition(curPosition + 4);
/*     */           
/* 234 */           break;
/*     */         case 5: 
/* 236 */           this.rowFromServer.setPosition(curPosition + 8);
/*     */           
/* 238 */           break;
/*     */         case 11: 
/* 240 */           this.rowFromServer.fastSkipLenByteArray();
/*     */           
/* 242 */           break;
/*     */         
/*     */         case 10: 
/* 245 */           this.rowFromServer.fastSkipLenByteArray();
/*     */           
/* 247 */           break;
/*     */         case 7: 
/*     */         case 12: 
/* 250 */           this.rowFromServer.fastSkipLenByteArray();
/*     */           
/* 252 */           break;
/*     */         case 0: 
/*     */         case 15: 
/*     */         case 16: 
/*     */         case 246: 
/*     */         case 249: 
/*     */         case 250: 
/*     */         case 251: 
/*     */         case 252: 
/*     */         case 253: 
/*     */         case 254: 
/*     */         case 255: 
/* 264 */           this.rowFromServer.fastSkipLenByteArray();
/*     */           
/* 266 */           break;
/*     */         
/*     */         default: 
/* 269 */           throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + this.metadata[i].getMysqlType() + Messages.getString("MysqlIO.98") + (i + 1) + Messages.getString("MysqlIO.99") + this.metadata.length + Messages.getString("MysqlIO.100"), "S1000", this.exceptionInterceptor);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/* 275 */     this.lastRequestedIndex = index;
/* 276 */     this.lastRequestedPos = this.rowFromServer.getPosition();
/*     */     
/* 278 */     return this.lastRequestedPos;
/*     */   }
/*     */   
/*     */   public synchronized InputStream getBinaryInputStream(int columnIndex) throws SQLException
/*     */   {
/* 283 */     if ((this.isBinaryEncoded) && 
/* 284 */       (isNull(columnIndex))) {
/* 285 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 289 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 291 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 293 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 295 */     if (length == -1L) {
/* 296 */       return null;
/*     */     }
/*     */     
/* 299 */     InputStream stream = new ByteArrayInputStream(this.rowFromServer.getByteBuffer(), offset, (int)length);
/*     */     
/* 301 */     if (this.openStreams == null) {
/* 302 */       this.openStreams = new LinkedList();
/*     */     }
/*     */     
/* 305 */     return stream;
/*     */   }
/*     */   
/*     */   public byte[] getColumnValue(int index) throws SQLException
/*     */   {
/* 310 */     findAndSeekToOffset(index);
/*     */     
/* 312 */     if (!this.isBinaryEncoded) {
/* 313 */       return this.rowFromServer.readLenByteArray(0);
/*     */     }
/*     */     
/* 316 */     if (this.isNull[index] != 0) {
/* 317 */       return null;
/*     */     }
/*     */     
/* 320 */     switch (this.metadata[index].getMysqlType()) {
/*     */     case 6: 
/* 322 */       return null;
/*     */     
/*     */     case 1: 
/* 325 */       return new byte[] { this.rowFromServer.readByte() };
/*     */     
/*     */     case 2: 
/*     */     case 13: 
/* 329 */       return this.rowFromServer.getBytes(2);
/*     */     
/*     */     case 3: 
/*     */     case 9: 
/* 333 */       return this.rowFromServer.getBytes(4);
/*     */     
/*     */     case 8: 
/* 336 */       return this.rowFromServer.getBytes(8);
/*     */     
/*     */     case 4: 
/* 339 */       return this.rowFromServer.getBytes(4);
/*     */     
/*     */     case 5: 
/* 342 */       return this.rowFromServer.getBytes(8);
/*     */     
/*     */     case 0: 
/*     */     case 7: 
/*     */     case 10: 
/*     */     case 11: 
/*     */     case 12: 
/*     */     case 15: 
/*     */     case 16: 
/*     */     case 246: 
/*     */     case 249: 
/*     */     case 250: 
/*     */     case 251: 
/*     */     case 252: 
/*     */     case 253: 
/*     */     case 254: 
/*     */     case 255: 
/* 359 */       return this.rowFromServer.readLenByteArray(0);
/*     */     }
/*     */     
/* 362 */     throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + this.metadata[index].getMysqlType() + Messages.getString("MysqlIO.98") + (index + 1) + Messages.getString("MysqlIO.99") + this.metadata.length + Messages.getString("MysqlIO.100"), "S1000", this.exceptionInterceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getInt(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 371 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 373 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 375 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 377 */     if (length == -1L) {
/* 378 */       return 0;
/*     */     }
/*     */     
/* 381 */     return StringUtils.getInt(this.rowFromServer.getByteBuffer(), offset, offset + (int)length);
/*     */   }
/*     */   
/*     */   public long getLong(int columnIndex) throws SQLException
/*     */   {
/* 386 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 388 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 390 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 392 */     if (length == -1L) {
/* 393 */       return 0L;
/*     */     }
/*     */     
/* 396 */     return StringUtils.getLong(this.rowFromServer.getByteBuffer(), offset, offset + (int)length);
/*     */   }
/*     */   
/*     */   public double getNativeDouble(int columnIndex) throws SQLException
/*     */   {
/* 401 */     if (isNull(columnIndex)) {
/* 402 */       return 0.0D;
/*     */     }
/*     */     
/* 405 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 407 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 409 */     return getNativeDouble(this.rowFromServer.getByteBuffer(), offset);
/*     */   }
/*     */   
/*     */   public float getNativeFloat(int columnIndex) throws SQLException
/*     */   {
/* 414 */     if (isNull(columnIndex)) {
/* 415 */       return 0.0F;
/*     */     }
/*     */     
/* 418 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 420 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 422 */     return getNativeFloat(this.rowFromServer.getByteBuffer(), offset);
/*     */   }
/*     */   
/*     */   public int getNativeInt(int columnIndex) throws SQLException
/*     */   {
/* 427 */     if (isNull(columnIndex)) {
/* 428 */       return 0;
/*     */     }
/*     */     
/* 431 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 433 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 435 */     return getNativeInt(this.rowFromServer.getByteBuffer(), offset);
/*     */   }
/*     */   
/*     */   public long getNativeLong(int columnIndex) throws SQLException
/*     */   {
/* 440 */     if (isNull(columnIndex)) {
/* 441 */       return 0L;
/*     */     }
/*     */     
/* 444 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 446 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 448 */     return getNativeLong(this.rowFromServer.getByteBuffer(), offset);
/*     */   }
/*     */   
/*     */   public short getNativeShort(int columnIndex) throws SQLException
/*     */   {
/* 453 */     if (isNull(columnIndex)) {
/* 454 */       return 0;
/*     */     }
/*     */     
/* 457 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 459 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 461 */     return getNativeShort(this.rowFromServer.getByteBuffer(), offset);
/*     */   }
/*     */   
/*     */   public Timestamp getNativeTimestamp(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*     */     throws SQLException
/*     */   {
/* 467 */     if (isNull(columnIndex)) {
/* 468 */       return null;
/*     */     }
/*     */     
/* 471 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 473 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 475 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 477 */     return getNativeTimestamp(this.rowFromServer.getByteBuffer(), offset, (int)length, targetCalendar, tz, rollForward, conn, rs);
/*     */   }
/*     */   
/*     */   public Reader getReader(int columnIndex) throws SQLException
/*     */   {
/* 482 */     InputStream stream = getBinaryInputStream(columnIndex);
/*     */     
/* 484 */     if (stream == null) {
/* 485 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 489 */       return new InputStreamReader(stream, this.metadata[columnIndex].getEncoding());
/*     */     } catch (UnsupportedEncodingException e) {
/* 491 */       SQLException sqlEx = SQLError.createSQLException("", this.exceptionInterceptor);
/*     */       
/* 493 */       sqlEx.initCause(e);
/*     */       
/* 495 */       throw sqlEx;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getString(int columnIndex, String encoding, MySQLConnection conn) throws SQLException
/*     */   {
/* 501 */     if ((this.isBinaryEncoded) && 
/* 502 */       (isNull(columnIndex))) {
/* 503 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 507 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 509 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 511 */     if (length == -1L) {
/* 512 */       return null;
/*     */     }
/*     */     
/* 515 */     if (length == 0L) {
/* 516 */       return "";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 521 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 523 */     return getString(encoding, conn, this.rowFromServer.getByteBuffer(), offset, (int)length);
/*     */   }
/*     */   
/*     */   public Time getTimeFast(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*     */     throws SQLException
/*     */   {
/* 529 */     if (isNull(columnIndex)) {
/* 530 */       return null;
/*     */     }
/*     */     
/* 533 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 535 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 537 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 539 */     return getTimeFast(columnIndex, this.rowFromServer.getByteBuffer(), offset, (int)length, targetCalendar, tz, rollForward, conn, rs);
/*     */   }
/*     */   
/*     */   public Timestamp getTimestampFast(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*     */     throws SQLException
/*     */   {
/* 545 */     if (isNull(columnIndex)) {
/* 546 */       return null;
/*     */     }
/*     */     
/* 549 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 551 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 553 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 555 */     return getTimestampFast(columnIndex, this.rowFromServer.getByteBuffer(), offset, (int)length, targetCalendar, tz, rollForward, conn, rs);
/*     */   }
/*     */   
/*     */   public boolean isFloatingPointNumber(int index) throws SQLException
/*     */   {
/* 560 */     if (this.isBinaryEncoded) {
/* 561 */       switch (this.metadata[index].getSQLType()) {
/*     */       case 2: 
/*     */       case 3: 
/*     */       case 6: 
/*     */       case 8: 
/* 566 */         return true;
/*     */       }
/* 568 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 572 */     findAndSeekToOffset(index);
/*     */     
/* 574 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 576 */     if (length == -1L) {
/* 577 */       return false;
/*     */     }
/*     */     
/* 580 */     if (length == 0L) {
/* 581 */       return false;
/*     */     }
/*     */     
/* 584 */     int offset = this.rowFromServer.getPosition();
/* 585 */     byte[] buffer = this.rowFromServer.getByteBuffer();
/*     */     
/* 587 */     for (int i = 0; i < (int)length; i++) {
/* 588 */       char c = (char)buffer[(offset + i)];
/*     */       
/* 590 */       if ((c == 'e') || (c == 'E')) {
/* 591 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 595 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isNull(int index) throws SQLException
/*     */   {
/* 600 */     if (!this.isBinaryEncoded) {
/* 601 */       findAndSeekToOffset(index);
/*     */       
/* 603 */       return this.rowFromServer.readFieldLength() == -1L;
/*     */     }
/*     */     
/* 606 */     return this.isNull[index];
/*     */   }
/*     */   
/*     */   public long length(int index) throws SQLException
/*     */   {
/* 611 */     findAndSeekToOffset(index);
/*     */     
/* 613 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 615 */     if (length == -1L) {
/* 616 */       return 0L;
/*     */     }
/*     */     
/* 619 */     return length;
/*     */   }
/*     */   
/*     */   public void setColumnValue(int index, byte[] value) throws SQLException
/*     */   {
/* 624 */     throw new OperationNotSupportedException();
/*     */   }
/*     */   
/*     */   public ResultSetRow setMetadata(Field[] f) throws SQLException
/*     */   {
/* 629 */     super.setMetadata(f);
/*     */     
/* 631 */     if (this.isBinaryEncoded) {
/* 632 */       setupIsNullBitmask();
/*     */     }
/*     */     
/* 635 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupIsNullBitmask()
/*     */     throws SQLException
/*     */   {
/* 644 */     if (this.isNull != null) {
/* 645 */       return;
/*     */     }
/*     */     
/* 648 */     this.rowFromServer.setPosition(this.preNullBitmaskHomePosition);
/*     */     
/* 650 */     int nullCount = (this.metadata.length + 9) / 8;
/*     */     
/* 652 */     byte[] nullBitMask = new byte[nullCount];
/*     */     
/* 654 */     for (int i = 0; i < nullCount; i++) {
/* 655 */       nullBitMask[i] = this.rowFromServer.readByte();
/*     */     }
/*     */     
/* 658 */     this.homePosition = this.rowFromServer.getPosition();
/*     */     
/* 660 */     this.isNull = new boolean[this.metadata.length];
/*     */     
/* 662 */     int nullMaskPos = 0;
/* 663 */     int bit = 4;
/*     */     
/* 665 */     for (int i = 0; i < this.metadata.length; i++)
/*     */     {
/* 667 */       this.isNull[i] = ((nullBitMask[nullMaskPos] & bit) != 0 ? 1 : false);
/*     */       
/* 669 */       if ((bit <<= 1 & 0xFF) == 0) {
/* 670 */         bit = 1;
/*     */         
/* 672 */         nullMaskPos++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Date getDateFast(int columnIndex, MySQLConnection conn, ResultSetImpl rs, Calendar targetCalendar) throws SQLException
/*     */   {
/* 679 */     if (isNull(columnIndex)) {
/* 680 */       return null;
/*     */     }
/*     */     
/* 683 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 685 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 687 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 689 */     return getDateFast(columnIndex, this.rowFromServer.getByteBuffer(), offset, (int)length, conn, rs, targetCalendar);
/*     */   }
/*     */   
/*     */   public Date getNativeDate(int columnIndex, MySQLConnection conn, ResultSetImpl rs, Calendar cal) throws SQLException
/*     */   {
/* 694 */     if (isNull(columnIndex)) {
/* 695 */       return null;
/*     */     }
/*     */     
/* 698 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 700 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 702 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 704 */     return getNativeDate(columnIndex, this.rowFromServer.getByteBuffer(), offset, (int)length, conn, rs, cal);
/*     */   }
/*     */   
/*     */   public Object getNativeDateTimeValue(int columnIndex, Calendar targetCalendar, int jdbcType, int mysqlType, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*     */     throws SQLException
/*     */   {
/* 710 */     if (isNull(columnIndex)) {
/* 711 */       return null;
/*     */     }
/*     */     
/* 714 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 716 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 718 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 720 */     return getNativeDateTimeValue(columnIndex, this.rowFromServer.getByteBuffer(), offset, (int)length, targetCalendar, jdbcType, mysqlType, tz, rollForward, conn, rs);
/*     */   }
/*     */   
/*     */ 
/*     */   public Time getNativeTime(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*     */     throws SQLException
/*     */   {
/* 727 */     if (isNull(columnIndex)) {
/* 728 */       return null;
/*     */     }
/*     */     
/* 731 */     findAndSeekToOffset(columnIndex);
/*     */     
/* 733 */     long length = this.rowFromServer.readFieldLength();
/*     */     
/* 735 */     int offset = this.rowFromServer.getPosition();
/*     */     
/* 737 */     return getNativeTime(columnIndex, this.rowFromServer.getByteBuffer(), offset, (int)length, targetCalendar, tz, rollForward, conn, rs);
/*     */   }
/*     */   
/*     */   public int getBytesSize()
/*     */   {
/* 742 */     return this.rowFromServer.getBufLength();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/BufferRow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */