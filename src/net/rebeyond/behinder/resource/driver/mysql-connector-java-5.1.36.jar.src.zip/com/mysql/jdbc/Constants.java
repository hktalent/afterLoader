/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Constants
/*    */ {
/* 33 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 38 */   public static final String MILLIS_I18N = Messages.getString("Milliseconds");
/*    */   
/* 40 */   public static final byte[] SLASH_STAR_SPACE_AS_BYTES = { 47, 42, 32 };
/*    */   
/* 42 */   public static final byte[] SPACE_STAR_SLASH_SPACE_AS_BYTES = { 32, 42, 47, 32 };
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/Constants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */