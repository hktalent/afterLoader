/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import com.mysql.jdbc.ResultSetInternalMethods;
/*     */ import com.mysql.jdbc.SQLError;
/*     */ import com.mysql.jdbc.Util;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatementWrapper
/*     */   extends WrapperBase
/*     */   implements java.sql.Statement
/*     */ {
/*     */   private static final Constructor<?> JDBC_4_STATEMENT_WRAPPER_CTOR;
/*     */   protected java.sql.Statement wrappedStmt;
/*     */   protected ConnectionWrapper wrappedConn;
/*     */   
/*     */   static
/*     */   {
/*  43 */     if (Util.isJdbc4()) {
/*     */       try {
/*  45 */         JDBC_4_STATEMENT_WRAPPER_CTOR = Class.forName("com.mysql.jdbc.jdbc2.optional.JDBC4StatementWrapper").getConstructor(new Class[] { ConnectionWrapper.class, MysqlPooledConnection.class, java.sql.Statement.class });
/*     */       }
/*     */       catch (SecurityException e) {
/*  48 */         throw new RuntimeException(e);
/*     */       } catch (NoSuchMethodException e) {
/*  50 */         throw new RuntimeException(e);
/*     */       } catch (ClassNotFoundException e) {
/*  52 */         throw new RuntimeException(e);
/*     */       }
/*     */     } else {
/*  55 */       JDBC_4_STATEMENT_WRAPPER_CTOR = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static StatementWrapper getInstance(ConnectionWrapper c, MysqlPooledConnection conn, java.sql.Statement toWrap) throws SQLException {
/*  60 */     if (!Util.isJdbc4()) {
/*  61 */       return new StatementWrapper(c, conn, toWrap);
/*     */     }
/*     */     
/*  64 */     return (StatementWrapper)Util.handleNewInstance(JDBC_4_STATEMENT_WRAPPER_CTOR, new Object[] { c, conn, toWrap }, conn.getExceptionInterceptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StatementWrapper(ConnectionWrapper c, MysqlPooledConnection conn, java.sql.Statement toWrap)
/*     */   {
/*  72 */     super(conn);
/*  73 */     this.wrappedStmt = toWrap;
/*  74 */     this.wrappedConn = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/*  84 */       if (this.wrappedStmt != null) {
/*  85 */         return this.wrappedConn;
/*     */       }
/*     */       
/*  88 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/*  90 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/*  93 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCursorName(String name)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 103 */       if (this.wrappedStmt != null) {
/* 104 */         this.wrappedStmt.setCursorName(name);
/*     */       } else {
/* 106 */         throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 109 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEscapeProcessing(boolean enable)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 120 */       if (this.wrappedStmt != null) {
/* 121 */         this.wrappedStmt.setEscapeProcessing(enable);
/*     */       } else {
/* 123 */         throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 126 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFetchDirection(int direction)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 137 */       if (this.wrappedStmt != null) {
/* 138 */         this.wrappedStmt.setFetchDirection(direction);
/*     */       } else {
/* 140 */         throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 143 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFetchDirection()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 154 */       if (this.wrappedStmt != null) {
/* 155 */         return this.wrappedStmt.getFetchDirection();
/*     */       }
/*     */       
/* 158 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 160 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 163 */     return 1000;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFetchSize(int rows)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 173 */       if (this.wrappedStmt != null) {
/* 174 */         this.wrappedStmt.setFetchSize(rows);
/*     */       } else {
/* 176 */         throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 179 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFetchSize()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 190 */       if (this.wrappedStmt != null) {
/* 191 */         return this.wrappedStmt.getFetchSize();
/*     */       }
/*     */       
/* 194 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 196 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 199 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResultSet getGeneratedKeys()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 209 */       if (this.wrappedStmt != null) {
/* 210 */         return this.wrappedStmt.getGeneratedKeys();
/*     */       }
/*     */       
/* 213 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 215 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 218 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMaxFieldSize(int max)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 228 */       if (this.wrappedStmt != null) {
/* 229 */         this.wrappedStmt.setMaxFieldSize(max);
/*     */       } else {
/* 231 */         throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 234 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxFieldSize()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 245 */       if (this.wrappedStmt != null) {
/* 246 */         return this.wrappedStmt.getMaxFieldSize();
/*     */       }
/*     */       
/* 249 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 251 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 254 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMaxRows(int max)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 264 */       if (this.wrappedStmt != null) {
/* 265 */         this.wrappedStmt.setMaxRows(max);
/*     */       } else {
/* 267 */         throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 270 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxRows()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 281 */       if (this.wrappedStmt != null) {
/* 282 */         return this.wrappedStmt.getMaxRows();
/*     */       }
/*     */       
/* 285 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 287 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 290 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getMoreResults()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 300 */       if (this.wrappedStmt != null) {
/* 301 */         return this.wrappedStmt.getMoreResults();
/*     */       }
/*     */       
/* 304 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 306 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 309 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 319 */       if (this.wrappedStmt != null) {
/* 320 */         return this.wrappedStmt.getMoreResults(current);
/*     */       }
/*     */       
/* 323 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 325 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 328 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setQueryTimeout(int seconds)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 338 */       if (this.wrappedStmt != null) {
/* 339 */         this.wrappedStmt.setQueryTimeout(seconds);
/*     */       } else {
/* 341 */         throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 344 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getQueryTimeout()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 355 */       if (this.wrappedStmt != null) {
/* 356 */         return this.wrappedStmt.getQueryTimeout();
/*     */       }
/*     */       
/* 359 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 361 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 364 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 374 */       if (this.wrappedStmt != null) {
/* 375 */         ResultSet rs = this.wrappedStmt.getResultSet();
/*     */         
/* 377 */         if (rs != null) {
/* 378 */           ((ResultSetInternalMethods)rs).setWrapperStatement(this);
/*     */         }
/* 380 */         return rs;
/*     */       }
/*     */       
/* 383 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 385 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 388 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getResultSetConcurrency()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 398 */       if (this.wrappedStmt != null) {
/* 399 */         return this.wrappedStmt.getResultSetConcurrency();
/*     */       }
/*     */       
/* 402 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 404 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 407 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getResultSetHoldability()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 417 */       if (this.wrappedStmt != null) {
/* 418 */         return this.wrappedStmt.getResultSetHoldability();
/*     */       }
/*     */       
/* 421 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 423 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 426 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getResultSetType()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 436 */       if (this.wrappedStmt != null) {
/* 437 */         return this.wrappedStmt.getResultSetType();
/*     */       }
/*     */       
/* 440 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 442 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 445 */     return 1003;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getUpdateCount()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 455 */       if (this.wrappedStmt != null) {
/* 456 */         return this.wrappedStmt.getUpdateCount();
/*     */       }
/*     */       
/* 459 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 461 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 464 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 474 */       if (this.wrappedStmt != null) {
/* 475 */         return this.wrappedStmt.getWarnings();
/*     */       }
/*     */       
/* 478 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 480 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 483 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 493 */       if (this.wrappedStmt != null) {
/* 494 */         this.wrappedStmt.addBatch(sql);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 497 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void cancel()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 508 */       if (this.wrappedStmt != null) {
/* 509 */         this.wrappedStmt.cancel();
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 512 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearBatch()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 523 */       if (this.wrappedStmt != null) {
/* 524 */         this.wrappedStmt.clearBatch();
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 527 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 538 */       if (this.wrappedStmt != null) {
/* 539 */         this.wrappedStmt.clearWarnings();
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 542 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 553 */       if (this.wrappedStmt != null) {
/* 554 */         this.wrappedStmt.close();
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 557 */       checkAndFireConnectionError(sqlEx);
/*     */     } finally {
/* 559 */       this.wrappedStmt = null;
/* 560 */       this.pooledConnection = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean execute(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 571 */       if (this.wrappedStmt != null) {
/* 572 */         return this.wrappedStmt.execute(sql, autoGeneratedKeys);
/*     */       }
/*     */       
/* 575 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 577 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 580 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean execute(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 590 */       if (this.wrappedStmt != null) {
/* 591 */         return this.wrappedStmt.execute(sql, columnIndexes);
/*     */       }
/*     */       
/* 594 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 596 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 599 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean execute(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 609 */       if (this.wrappedStmt != null) {
/* 610 */         return this.wrappedStmt.execute(sql, columnNames);
/*     */       }
/*     */       
/* 613 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 615 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 618 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 628 */       if (this.wrappedStmt != null) {
/* 629 */         return this.wrappedStmt.execute(sql);
/*     */       }
/*     */       
/* 632 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 634 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 637 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 647 */       if (this.wrappedStmt != null) {
/* 648 */         return this.wrappedStmt.executeBatch();
/*     */       }
/*     */       
/* 651 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 653 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 656 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 666 */       if (this.wrappedStmt != null)
/*     */       {
/* 668 */         ResultSet rs = this.wrappedStmt.executeQuery(sql);
/* 669 */         ((ResultSetInternalMethods)rs).setWrapperStatement(this);
/*     */         
/* 671 */         return rs;
/*     */       }
/*     */       
/* 674 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 676 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 679 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 689 */       if (this.wrappedStmt != null) {
/* 690 */         return this.wrappedStmt.executeUpdate(sql, autoGeneratedKeys);
/*     */       }
/*     */       
/* 693 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 695 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 698 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int executeUpdate(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 708 */       if (this.wrappedStmt != null) {
/* 709 */         return this.wrappedStmt.executeUpdate(sql, columnIndexes);
/*     */       }
/*     */       
/* 712 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 714 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 717 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int executeUpdate(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 728 */       if (this.wrappedStmt != null) {
/* 729 */         return this.wrappedStmt.executeUpdate(sql, columnNames);
/*     */       }
/*     */       
/* 732 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 734 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 737 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int executeUpdate(String sql)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 747 */       if (this.wrappedStmt != null) {
/* 748 */         return this.wrappedStmt.executeUpdate(sql);
/*     */       }
/*     */       
/* 751 */       throw SQLError.createSQLException("Statement already closed", "S1009", this.exceptionInterceptor);
/*     */     } catch (SQLException sqlEx) {
/* 753 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */     
/* 756 */     return -1;
/*     */   }
/*     */   
/*     */   public void enableStreamingResults() throws SQLException {
/*     */     try {
/* 761 */       if (this.wrappedStmt != null) {
/* 762 */         ((com.mysql.jdbc.Statement)this.wrappedStmt).enableStreamingResults();
/*     */       } else {
/* 764 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 767 */       checkAndFireConnectionError(sqlEx);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/jdbc2/optional/StatementWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */