/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DatabaseMetaDataUsingInfoSchema
/*      */   extends DatabaseMetaData
/*      */ {
/*      */   private boolean hasReferentialConstraintsView;
/*      */   private final boolean hasParametersView;
/*      */   
/*      */   protected static enum JDBC4FunctionConstant
/*      */   {
/*   38 */     FUNCTION_COLUMN_UNKNOWN,  FUNCTION_COLUMN_IN,  FUNCTION_COLUMN_INOUT,  FUNCTION_COLUMN_OUT,  FUNCTION_COLUMN_RETURN,  FUNCTION_COLUMN_RESULT, 
/*      */     
/*   40 */     FUNCTION_NO_NULLS,  FUNCTION_NULLABLE,  FUNCTION_NULLABLE_UNKNOWN;
/*      */     
/*      */     private JDBC4FunctionConstant() {}
/*      */   }
/*      */   
/*      */   protected DatabaseMetaDataUsingInfoSchema(MySQLConnection connToSet, String databaseToSet) throws SQLException
/*      */   {
/*   47 */     super(connToSet, databaseToSet);
/*      */     
/*   49 */     this.hasReferentialConstraintsView = this.conn.versionMeetsMinimum(5, 1, 10);
/*      */     
/*   51 */     ResultSet rs = null;
/*      */     try
/*      */     {
/*   54 */       rs = super.getTables("INFORMATION_SCHEMA", null, "PARAMETERS", new String[0]);
/*      */       
/*   56 */       this.hasParametersView = rs.next();
/*      */     } finally {
/*   58 */       if (rs != null) {
/*   59 */         rs.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected ResultSet executeMetadataQuery(PreparedStatement pStmt) throws SQLException {
/*   65 */     ResultSet rs = pStmt.executeQuery();
/*   66 */     ((ResultSetInternalMethods)rs).setOwningStatement(null);
/*      */     
/*   68 */     return rs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/*  105 */     if (columnNamePattern == null) {
/*  106 */       if (this.conn.getNullNamePatternMatchesAll()) {
/*  107 */         columnNamePattern = "%";
/*      */       } else {
/*  109 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  114 */     if ((catalog == null) && 
/*  115 */       (this.conn.getNullCatalogMeansCurrent())) {
/*  116 */       catalog = this.database;
/*      */     }
/*      */     
/*      */ 
/*  120 */     String sql = "SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME,COLUMN_NAME, NULL AS GRANTOR, GRANTEE, PRIVILEGE_TYPE AS PRIVILEGE, IS_GRANTABLE FROM INFORMATION_SCHEMA.COLUMN_PRIVILEGES WHERE TABLE_SCHEMA LIKE ? AND TABLE_NAME =? AND COLUMN_NAME LIKE ? ORDER BY COLUMN_NAME, PRIVILEGE_TYPE";
/*      */     
/*      */ 
/*      */ 
/*  124 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  127 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */       
/*  129 */       if (catalog != null) {
/*  130 */         pStmt.setString(1, catalog);
/*      */       } else {
/*  132 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  135 */       pStmt.setString(2, table);
/*  136 */       pStmt.setString(3, columnNamePattern);
/*      */       
/*  138 */       ResultSet rs = executeMetadataQuery(pStmt);
/*  139 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(new Field[] { new Field("", "TABLE_CAT", 1, 64), new Field("", "TABLE_SCHEM", 1, 1), new Field("", "TABLE_NAME", 1, 64), new Field("", "COLUMN_NAME", 1, 64), new Field("", "GRANTOR", 1, 77), new Field("", "GRANTEE", 1, 77), new Field("", "PRIVILEGE", 1, 64), new Field("", "IS_GRANTABLE", 1, 3) });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  144 */       return rs;
/*      */     } finally {
/*  146 */       if (pStmt != null) {
/*  147 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumns(String catalog, String schemaPattern, String tableName, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/*  192 */     if (columnNamePattern == null) {
/*  193 */       if (this.conn.getNullNamePatternMatchesAll()) {
/*  194 */         columnNamePattern = "%";
/*      */       } else {
/*  196 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  201 */     if ((catalog == null) && 
/*  202 */       (this.conn.getNullCatalogMeansCurrent())) {
/*  203 */       catalog = this.database;
/*      */     }
/*      */     
/*      */ 
/*  207 */     StringBuilder sqlBuf = new StringBuilder("SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME, COLUMN_NAME,");
/*  208 */     MysqlDefs.appendJdbcTypeMappingQuery(sqlBuf, "DATA_TYPE");
/*      */     
/*  210 */     sqlBuf.append(" AS DATA_TYPE, ");
/*      */     
/*  212 */     if (this.conn.getCapitalizeTypeNames()) {
/*  213 */       sqlBuf.append("UPPER(CASE WHEN LOCATE('unsigned', COLUMN_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 AND LOCATE('set', DATA_TYPE) <> 1 AND LOCATE('enum', DATA_TYPE) <> 1 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END) AS TYPE_NAME,");
/*      */     }
/*      */     else {
/*  216 */       sqlBuf.append("CASE WHEN LOCATE('unsigned', COLUMN_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 AND LOCATE('set', DATA_TYPE) <> 1 AND LOCATE('enum', DATA_TYPE) <> 1 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END AS TYPE_NAME,");
/*      */     }
/*      */     
/*      */ 
/*  220 */     sqlBuf.append("CASE WHEN LCASE(DATA_TYPE)='date' THEN 10 WHEN LCASE(DATA_TYPE)='time' THEN 8 WHEN LCASE(DATA_TYPE)='datetime' THEN 19 WHEN LCASE(DATA_TYPE)='timestamp' THEN 19 WHEN CHARACTER_MAXIMUM_LENGTH IS NULL THEN NUMERIC_PRECISION WHEN CHARACTER_MAXIMUM_LENGTH > 2147483647 THEN 2147483647 ELSE CHARACTER_MAXIMUM_LENGTH END AS COLUMN_SIZE, " + MysqlIO.getMaxBuf() + " AS BUFFER_LENGTH," + "NUMERIC_SCALE AS DECIMAL_DIGITS," + "10 AS NUM_PREC_RADIX," + "CASE WHEN IS_NULLABLE='NO' THEN " + 0 + " ELSE CASE WHEN IS_NULLABLE='YES' THEN " + 1 + " ELSE " + 2 + " END END AS NULLABLE," + "COLUMN_COMMENT AS REMARKS," + "COLUMN_DEFAULT AS COLUMN_DEF," + "0 AS SQL_DATA_TYPE," + "0 AS SQL_DATETIME_SUB," + "CASE WHEN CHARACTER_OCTET_LENGTH > " + Integer.MAX_VALUE + " THEN " + Integer.MAX_VALUE + " ELSE CHARACTER_OCTET_LENGTH END AS CHAR_OCTET_LENGTH," + "ORDINAL_POSITION," + "IS_NULLABLE," + "NULL AS SCOPE_CATALOG," + "NULL AS SCOPE_SCHEMA," + "NULL AS SCOPE_TABLE," + "NULL AS SOURCE_DATA_TYPE," + "IF (EXTRA LIKE '%auto_increment%','YES','NO') AS IS_AUTOINCREMENT FROM INFORMATION_SCHEMA.COLUMNS WHERE ");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  254 */     boolean operatingOnInformationSchema = "information_schema".equalsIgnoreCase(catalog);
/*      */     
/*  256 */     if (catalog != null) {
/*  257 */       if ((operatingOnInformationSchema) || ((StringUtils.indexOfIgnoreCase(0, catalog, "%") == -1) && (StringUtils.indexOfIgnoreCase(0, catalog, "_") == -1)))
/*      */       {
/*  259 */         sqlBuf.append("TABLE_SCHEMA = ? AND ");
/*      */       } else {
/*  261 */         sqlBuf.append("TABLE_SCHEMA LIKE ? AND ");
/*      */       }
/*      */     }
/*      */     else {
/*  265 */       sqlBuf.append("TABLE_SCHEMA LIKE ? AND ");
/*      */     }
/*      */     
/*  268 */     if (tableName != null) {
/*  269 */       if ((StringUtils.indexOfIgnoreCase(0, tableName, "%") == -1) && (StringUtils.indexOfIgnoreCase(0, tableName, "_") == -1)) {
/*  270 */         sqlBuf.append("TABLE_NAME = ? AND ");
/*      */       } else {
/*  272 */         sqlBuf.append("TABLE_NAME LIKE ? AND ");
/*      */       }
/*      */     }
/*      */     else {
/*  276 */       sqlBuf.append("TABLE_NAME LIKE ? AND ");
/*      */     }
/*      */     
/*  279 */     if ((StringUtils.indexOfIgnoreCase(0, columnNamePattern, "%") == -1) && (StringUtils.indexOfIgnoreCase(0, columnNamePattern, "_") == -1)) {
/*  280 */       sqlBuf.append("COLUMN_NAME = ? ");
/*      */     } else {
/*  282 */       sqlBuf.append("COLUMN_NAME LIKE ? ");
/*      */     }
/*  284 */     sqlBuf.append("ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION");
/*      */     
/*  286 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  289 */       pStmt = prepareMetaDataSafeStatement(sqlBuf.toString());
/*      */       
/*  291 */       if (catalog != null) {
/*  292 */         pStmt.setString(1, catalog);
/*      */       } else {
/*  294 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  297 */       pStmt.setString(2, tableName);
/*  298 */       pStmt.setString(3, columnNamePattern);
/*      */       
/*  300 */       ResultSet rs = executeMetadataQuery(pStmt);
/*      */       
/*  302 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createColumnsFields());
/*  303 */       return rs;
/*      */     } finally {
/*  305 */       if (pStmt != null) {
/*  306 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCrossReference(String primaryCatalog, String primarySchema, String primaryTable, String foreignCatalog, String foreignSchema, String foreignTable)
/*      */     throws SQLException
/*      */   {
/*  368 */     if (primaryTable == null) {
/*  369 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  372 */     if ((primaryCatalog == null) && 
/*  373 */       (this.conn.getNullCatalogMeansCurrent())) {
/*  374 */       primaryCatalog = this.database;
/*      */     }
/*      */     
/*      */ 
/*  378 */     if ((foreignCatalog == null) && 
/*  379 */       (this.conn.getNullCatalogMeansCurrent())) {
/*  380 */       foreignCatalog = this.database;
/*      */     }
/*      */     
/*      */ 
/*  384 */     String sql = "SELECT A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT,NULL AS PKTABLE_SCHEM, A.REFERENCED_TABLE_NAME AS PKTABLE_NAME,A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME, A.TABLE_SCHEMA AS FKTABLE_CAT, NULL AS FKTABLE_SCHEM, A.TABLE_NAME AS FKTABLE_NAME, A.COLUMN_NAME AS FKCOLUMN_NAME, A.ORDINAL_POSITION AS KEY_SEQ," + generateUpdateRuleClause() + " AS UPDATE_RULE," + generateDeleteRuleClause() + " AS DELETE_RULE," + "A.CONSTRAINT_NAME AS FK_NAME," + "(SELECT CONSTRAINT_NAME FROM" + " INFORMATION_SCHEMA.TABLE_CONSTRAINTS" + " WHERE TABLE_SCHEMA = A.REFERENCED_TABLE_SCHEMA AND" + " TABLE_NAME = A.REFERENCED_TABLE_NAME AND" + " CONSTRAINT_TYPE IN ('UNIQUE','PRIMARY KEY') LIMIT 1)" + " AS PK_NAME," + 7 + " AS DEFERRABILITY " + "FROM " + "INFORMATION_SCHEMA.KEY_COLUMN_USAGE A JOIN " + "INFORMATION_SCHEMA.TABLE_CONSTRAINTS B " + "USING (TABLE_SCHEMA, TABLE_NAME, CONSTRAINT_NAME) " + generateOptionalRefContraintsJoin() + "WHERE " + "B.CONSTRAINT_TYPE = 'FOREIGN KEY' " + "AND A.REFERENCED_TABLE_SCHEMA LIKE ? AND A.REFERENCED_TABLE_NAME=? " + "AND A.TABLE_SCHEMA LIKE ? AND A.TABLE_NAME=? ORDER BY A.TABLE_SCHEMA, A.TABLE_NAME, A.ORDINAL_POSITION";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  410 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  413 */       pStmt = prepareMetaDataSafeStatement(sql);
/*  414 */       if (primaryCatalog != null) {
/*  415 */         pStmt.setString(1, primaryCatalog);
/*      */       } else {
/*  417 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  420 */       pStmt.setString(2, primaryTable);
/*      */       
/*  422 */       if (foreignCatalog != null) {
/*  423 */         pStmt.setString(3, foreignCatalog);
/*      */       } else {
/*  425 */         pStmt.setString(3, "%");
/*      */       }
/*      */       
/*  428 */       pStmt.setString(4, foreignTable);
/*      */       
/*  430 */       ResultSet rs = executeMetadataQuery(pStmt);
/*  431 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createFkMetadataFields());
/*      */       
/*  433 */       return rs;
/*      */     } finally {
/*  435 */       if (pStmt != null) {
/*  436 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getExportedKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/*  491 */     if (table == null) {
/*  492 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  495 */     if ((catalog == null) && 
/*  496 */       (this.conn.getNullCatalogMeansCurrent())) {
/*  497 */       catalog = this.database;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  503 */     String sql = "SELECT A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT, NULL AS PKTABLE_SCHEM, A.REFERENCED_TABLE_NAME AS PKTABLE_NAME, A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME, A.TABLE_SCHEMA AS FKTABLE_CAT, NULL AS FKTABLE_SCHEM, A.TABLE_NAME AS FKTABLE_NAME,A.COLUMN_NAME AS FKCOLUMN_NAME, A.ORDINAL_POSITION AS KEY_SEQ," + generateUpdateRuleClause() + " AS UPDATE_RULE," + generateDeleteRuleClause() + " AS DELETE_RULE," + "A.CONSTRAINT_NAME AS FK_NAME," + "(SELECT CONSTRAINT_NAME FROM" + " INFORMATION_SCHEMA.TABLE_CONSTRAINTS" + " WHERE TABLE_SCHEMA = A.REFERENCED_TABLE_SCHEMA AND" + " TABLE_NAME = A.REFERENCED_TABLE_NAME AND" + " CONSTRAINT_TYPE IN ('UNIQUE','PRIMARY KEY') LIMIT 1)" + " AS PK_NAME," + 7 + " AS DEFERRABILITY " + "FROM " + "INFORMATION_SCHEMA.KEY_COLUMN_USAGE A JOIN " + "INFORMATION_SCHEMA.TABLE_CONSTRAINTS B " + "USING (TABLE_SCHEMA, TABLE_NAME, CONSTRAINT_NAME) " + generateOptionalRefContraintsJoin() + "WHERE " + "B.CONSTRAINT_TYPE = 'FOREIGN KEY' " + "AND A.REFERENCED_TABLE_SCHEMA LIKE ? AND A.REFERENCED_TABLE_NAME=? " + "ORDER BY A.TABLE_SCHEMA, A.TABLE_NAME, A.ORDINAL_POSITION";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  529 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  532 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */       
/*  534 */       if (catalog != null) {
/*  535 */         pStmt.setString(1, catalog);
/*      */       } else {
/*  537 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  540 */       pStmt.setString(2, table);
/*      */       
/*  542 */       ResultSet rs = executeMetadataQuery(pStmt);
/*      */       
/*  544 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createFkMetadataFields());
/*      */       
/*  546 */       return rs;
/*      */     } finally {
/*  548 */       if (pStmt != null) {
/*  549 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private String generateOptionalRefContraintsJoin()
/*      */   {
/*  556 */     return this.hasReferentialConstraintsView ? "JOIN INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS R ON (R.CONSTRAINT_NAME = B.CONSTRAINT_NAME AND R.TABLE_NAME = B.TABLE_NAME AND R.CONSTRAINT_SCHEMA = B.TABLE_SCHEMA) " : "";
/*      */   }
/*      */   
/*      */   private String generateDeleteRuleClause()
/*      */   {
/*  561 */     return this.hasReferentialConstraintsView ? "CASE WHEN R.DELETE_RULE='CASCADE' THEN " + String.valueOf(0) + " WHEN R.DELETE_RULE='SET NULL' THEN " + String.valueOf(2) + " WHEN R.DELETE_RULE='SET DEFAULT' THEN " + String.valueOf(4) + " WHEN R.DELETE_RULE='RESTRICT' THEN " + String.valueOf(1) + " WHEN R.DELETE_RULE='NO ACTION' THEN " + String.valueOf(3) + " ELSE " + String.valueOf(3) + " END " : String.valueOf(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String generateUpdateRuleClause()
/*      */   {
/*  569 */     return this.hasReferentialConstraintsView ? "CASE WHEN R.UPDATE_RULE='CASCADE' THEN " + String.valueOf(0) + " WHEN R.UPDATE_RULE='SET NULL' THEN " + String.valueOf(2) + " WHEN R.UPDATE_RULE='SET DEFAULT' THEN " + String.valueOf(4) + " WHEN R.UPDATE_RULE='RESTRICT' THEN " + String.valueOf(1) + " WHEN R.UPDATE_RULE='NO ACTION' THEN " + String.valueOf(3) + " ELSE " + String.valueOf(3) + " END " : String.valueOf(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getImportedKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/*  624 */     if (table == null) {
/*  625 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  628 */     if ((catalog == null) && 
/*  629 */       (this.conn.getNullCatalogMeansCurrent())) {
/*  630 */       catalog = this.database;
/*      */     }
/*      */     
/*      */ 
/*  634 */     String sql = "SELECT A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT, NULL AS PKTABLE_SCHEM, A.REFERENCED_TABLE_NAME AS PKTABLE_NAME,A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME, A.TABLE_SCHEMA AS FKTABLE_CAT, NULL AS FKTABLE_SCHEM, A.TABLE_NAME AS FKTABLE_NAME, A.COLUMN_NAME AS FKCOLUMN_NAME, A.ORDINAL_POSITION AS KEY_SEQ," + generateUpdateRuleClause() + " AS UPDATE_RULE," + generateDeleteRuleClause() + " AS DELETE_RULE," + "A.CONSTRAINT_NAME AS FK_NAME," + "(SELECT CONSTRAINT_NAME FROM" + " INFORMATION_SCHEMA.TABLE_CONSTRAINTS" + " WHERE TABLE_SCHEMA = A.REFERENCED_TABLE_SCHEMA AND" + " TABLE_NAME = A.REFERENCED_TABLE_NAME AND" + " CONSTRAINT_TYPE IN ('UNIQUE','PRIMARY KEY') LIMIT 1)" + " AS PK_NAME," + 7 + " AS DEFERRABILITY " + "FROM " + "INFORMATION_SCHEMA.KEY_COLUMN_USAGE A " + "JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS B USING " + "(CONSTRAINT_NAME, TABLE_NAME) " + generateOptionalRefContraintsJoin() + "WHERE " + "B.CONSTRAINT_TYPE = 'FOREIGN KEY' " + "AND A.TABLE_SCHEMA LIKE ? " + "AND A.TABLE_NAME=? " + "AND A.REFERENCED_TABLE_SCHEMA IS NOT NULL " + "ORDER BY A.REFERENCED_TABLE_SCHEMA, A.REFERENCED_TABLE_NAME, A.ORDINAL_POSITION";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  662 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  665 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */       
/*  667 */       if (catalog != null) {
/*  668 */         pStmt.setString(1, catalog);
/*      */       } else {
/*  670 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  673 */       pStmt.setString(2, table);
/*      */       
/*  675 */       ResultSet rs = executeMetadataQuery(pStmt);
/*      */       
/*  677 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createFkMetadataFields());
/*      */       
/*  679 */       return rs;
/*      */     } finally {
/*  681 */       if (pStmt != null) {
/*  682 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate)
/*      */     throws SQLException
/*      */   {
/*  736 */     StringBuilder sqlBuf = new StringBuilder("SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME, NON_UNIQUE,");
/*  737 */     sqlBuf.append("TABLE_SCHEMA AS INDEX_QUALIFIER, INDEX_NAME,3 AS TYPE, SEQ_IN_INDEX AS ORDINAL_POSITION, COLUMN_NAME,");
/*  738 */     sqlBuf.append("COLLATION AS ASC_OR_DESC, CARDINALITY, NULL AS PAGES, NULL AS FILTER_CONDITION FROM INFORMATION_SCHEMA.STATISTICS WHERE ");
/*  739 */     sqlBuf.append("TABLE_SCHEMA LIKE ? AND TABLE_NAME LIKE ?");
/*      */     
/*  741 */     if (unique) {
/*  742 */       sqlBuf.append(" AND NON_UNIQUE=0 ");
/*      */     }
/*      */     
/*  745 */     sqlBuf.append("ORDER BY NON_UNIQUE, INDEX_NAME, SEQ_IN_INDEX");
/*      */     
/*  747 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  750 */       if ((catalog == null) && 
/*  751 */         (this.conn.getNullCatalogMeansCurrent())) {
/*  752 */         catalog = this.database;
/*      */       }
/*      */       
/*      */ 
/*  756 */       pStmt = prepareMetaDataSafeStatement(sqlBuf.toString());
/*      */       
/*  758 */       if (catalog != null) {
/*  759 */         pStmt.setString(1, catalog);
/*      */       } else {
/*  761 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  764 */       pStmt.setString(2, table);
/*      */       
/*  766 */       ResultSet rs = executeMetadataQuery(pStmt);
/*      */       
/*  768 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createIndexInfoFields());
/*      */       
/*  770 */       return rs;
/*      */     } finally {
/*  772 */       if (pStmt != null) {
/*  773 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getPrimaryKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/*  805 */     if ((catalog == null) && 
/*  806 */       (this.conn.getNullCatalogMeansCurrent())) {
/*  807 */       catalog = this.database;
/*      */     }
/*      */     
/*      */ 
/*  811 */     if (table == null) {
/*  812 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  815 */     String sql = "SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME, COLUMN_NAME, SEQ_IN_INDEX AS KEY_SEQ, 'PRIMARY' AS PK_NAME FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA LIKE ? AND TABLE_NAME LIKE ? AND INDEX_NAME='PRIMARY' ORDER BY TABLE_SCHEMA, TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX";
/*      */     
/*      */ 
/*      */ 
/*  819 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  822 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */       
/*  824 */       if (catalog != null) {
/*  825 */         pStmt.setString(1, catalog);
/*      */       } else {
/*  827 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  830 */       pStmt.setString(2, table);
/*      */       
/*  832 */       ResultSet rs = executeMetadataQuery(pStmt);
/*  833 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(new Field[] { new Field("", "TABLE_CAT", 1, 255), new Field("", "TABLE_SCHEM", 1, 0), new Field("", "TABLE_NAME", 1, 255), new Field("", "COLUMN_NAME", 1, 32), new Field("", "KEY_SEQ", 5, 5), new Field("", "PK_NAME", 1, 32) });
/*      */       
/*      */ 
/*      */ 
/*  837 */       return rs;
/*      */     } finally {
/*  839 */       if (pStmt != null) {
/*  840 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern)
/*      */     throws SQLException
/*      */   {
/*  884 */     if ((procedureNamePattern == null) || (procedureNamePattern.length() == 0)) {
/*  885 */       if (this.conn.getNullNamePatternMatchesAll()) {
/*  886 */         procedureNamePattern = "%";
/*      */       } else {
/*  888 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  893 */     String db = null;
/*      */     
/*  895 */     if (catalog == null) {
/*  896 */       if (this.conn.getNullCatalogMeansCurrent()) {
/*  897 */         db = this.database;
/*      */       }
/*      */     } else {
/*  900 */       db = catalog;
/*      */     }
/*      */     
/*  903 */     String sql = "SELECT ROUTINE_SCHEMA AS PROCEDURE_CAT, NULL AS PROCEDURE_SCHEM, ROUTINE_NAME AS PROCEDURE_NAME, NULL AS RESERVED_1, NULL AS RESERVED_2, NULL AS RESERVED_3, ROUTINE_COMMENT AS REMARKS, CASE WHEN ROUTINE_TYPE = 'PROCEDURE' THEN 1 WHEN ROUTINE_TYPE='FUNCTION' THEN 2 ELSE 0 END AS PROCEDURE_TYPE, ROUTINE_NAME AS SPECIFIC_NAME FROM INFORMATION_SCHEMA.ROUTINES WHERE " + getRoutineTypeConditionForGetProcedures() + "ROUTINE_SCHEMA LIKE ? AND ROUTINE_NAME LIKE ? ORDER BY ROUTINE_SCHEMA, ROUTINE_NAME, ROUTINE_TYPE";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  909 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  912 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */       
/*  914 */       if (db != null) {
/*  915 */         pStmt.setString(1, db);
/*      */       } else {
/*  917 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/*  920 */       pStmt.setString(2, procedureNamePattern);
/*      */       
/*  922 */       ResultSet rs = executeMetadataQuery(pStmt);
/*  923 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createFieldMetadataForGetProcedures());
/*      */       
/*  925 */       return rs;
/*      */     } finally {
/*  927 */       if (pStmt != null) {
/*  928 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getRoutineTypeConditionForGetProcedures()
/*      */   {
/*  940 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 1008 */     if (!this.hasParametersView) {
/* 1009 */       return getProcedureColumnsNoISParametersView(catalog, schemaPattern, procedureNamePattern, columnNamePattern);
/*      */     }
/*      */     
/* 1012 */     if ((procedureNamePattern == null) || (procedureNamePattern.length() == 0)) {
/* 1013 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 1014 */         procedureNamePattern = "%";
/*      */       } else {
/* 1016 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1021 */     String db = null;
/*      */     
/* 1023 */     if (catalog == null) {
/* 1024 */       if (this.conn.getNullCatalogMeansCurrent()) {
/* 1025 */         db = this.database;
/*      */       }
/*      */     } else {
/* 1028 */       db = catalog;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1047 */     StringBuilder sqlBuf = new StringBuilder("SELECT SPECIFIC_SCHEMA AS PROCEDURE_CAT, NULL AS `PROCEDURE_SCHEM`, SPECIFIC_NAME AS `PROCEDURE_NAME`, IFNULL(PARAMETER_NAME, '') AS `COLUMN_NAME`, CASE WHEN PARAMETER_MODE = 'IN' THEN 1 WHEN PARAMETER_MODE = 'OUT' THEN 4 WHEN PARAMETER_MODE = 'INOUT' THEN 2 WHEN ORDINAL_POSITION = 0 THEN 5 ELSE 0 END AS `COLUMN_TYPE`, ");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1053 */     MysqlDefs.appendJdbcTypeMappingQuery(sqlBuf, "DATA_TYPE");
/*      */     
/* 1055 */     sqlBuf.append(" AS `DATA_TYPE`, ");
/*      */     
/*      */ 
/* 1058 */     if (this.conn.getCapitalizeTypeNames()) {
/* 1059 */       sqlBuf.append("UPPER(CASE WHEN LOCATE('unsigned', DATA_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END) AS `TYPE_NAME`,");
/*      */     }
/*      */     else {
/* 1062 */       sqlBuf.append("CASE WHEN LOCATE('unsigned', DATA_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END AS `TYPE_NAME`,");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1067 */     sqlBuf.append("NUMERIC_PRECISION AS `PRECISION`, ");
/*      */     
/* 1069 */     sqlBuf.append("CASE WHEN LCASE(DATA_TYPE)='date' THEN 10 WHEN LCASE(DATA_TYPE)='time' THEN 8 WHEN LCASE(DATA_TYPE)='datetime' THEN 19 WHEN LCASE(DATA_TYPE)='timestamp' THEN 19 WHEN CHARACTER_MAXIMUM_LENGTH IS NULL THEN NUMERIC_PRECISION WHEN CHARACTER_MAXIMUM_LENGTH > 2147483647 THEN 2147483647 ELSE CHARACTER_MAXIMUM_LENGTH END AS LENGTH, ");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1074 */     sqlBuf.append("NUMERIC_SCALE AS `SCALE`, ");
/*      */     
/* 1076 */     sqlBuf.append("10 AS RADIX,");
/* 1077 */     sqlBuf.append("1 AS `NULLABLE`, NULL AS `REMARKS`, NULL AS `COLUMN_DEF`, NULL AS `SQL_DATA_TYPE`, NULL AS `SQL_DATETIME_SUB`, CHARACTER_OCTET_LENGTH AS `CHAR_OCTET_LENGTH`, ORDINAL_POSITION, 'YES' AS `IS_NULLABLE`, SPECIFIC_NAME FROM INFORMATION_SCHEMA.PARAMETERS WHERE " + getRoutineTypeConditionForGetProcedureColumns() + "SPECIFIC_SCHEMA LIKE ? AND SPECIFIC_NAME LIKE ? AND (PARAMETER_NAME LIKE ? OR PARAMETER_NAME IS NULL) " + "ORDER BY SPECIFIC_SCHEMA, SPECIFIC_NAME, ROUTINE_TYPE, ORDINAL_POSITION");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1083 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/* 1086 */       pStmt = prepareMetaDataSafeStatement(sqlBuf.toString());
/*      */       
/* 1088 */       if (db != null) {
/* 1089 */         pStmt.setString(1, db);
/*      */       } else {
/* 1091 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/* 1094 */       pStmt.setString(2, procedureNamePattern);
/* 1095 */       pStmt.setString(3, columnNamePattern);
/*      */       
/* 1097 */       ResultSet rs = executeMetadataQuery(pStmt);
/* 1098 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createProcedureColumnsFields());
/*      */       
/* 1100 */       return rs;
/*      */     } finally {
/* 1102 */       if (pStmt != null) {
/* 1103 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSet getProcedureColumnsNoISParametersView(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 1115 */     return super.getProcedureColumns(catalog, schemaPattern, procedureNamePattern, columnNamePattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getRoutineTypeConditionForGetProcedureColumns()
/*      */   {
/* 1125 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types)
/*      */     throws SQLException
/*      */   {
/* 1163 */     if ((catalog == null) && 
/* 1164 */       (this.conn.getNullCatalogMeansCurrent())) {
/* 1165 */       catalog = this.database;
/*      */     }
/*      */     
/*      */ 
/* 1169 */     if (tableNamePattern == null) {
/* 1170 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 1171 */         tableNamePattern = "%";
/*      */       } else {
/* 1173 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1179 */     String tmpCat = "";
/*      */     
/* 1181 */     if ((catalog == null) || (catalog.length() == 0)) {
/* 1182 */       if (this.conn.getNullCatalogMeansCurrent()) {
/* 1183 */         tmpCat = this.database;
/*      */       }
/*      */     } else {
/* 1186 */       tmpCat = catalog;
/*      */     }
/*      */     
/* 1189 */     List<String> parseList = StringUtils.splitDBdotName(tableNamePattern, tmpCat, this.quotedId, this.conn.isNoBackslashEscapesSet());
/*      */     String tableNamePat;
/* 1191 */     String tableNamePat; if (parseList.size() == 2) {
/* 1192 */       tableNamePat = (String)parseList.get(1);
/*      */     } else {
/* 1194 */       tableNamePat = tableNamePattern;
/*      */     }
/*      */     
/* 1197 */     PreparedStatement pStmt = null;
/*      */     
/* 1199 */     String sql = "SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME, CASE WHEN TABLE_TYPE='BASE TABLE' THEN CASE WHEN TABLE_SCHEMA = 'mysql' OR TABLE_SCHEMA = 'performance_schema' THEN 'SYSTEM TABLE' ELSE 'TABLE' END WHEN TABLE_TYPE='TEMPORARY' THEN 'LOCAL_TEMPORARY' ELSE TABLE_TYPE END AS TABLE_TYPE, TABLE_COMMENT AS REMARKS, NULL AS TYPE_CAT, NULL AS TYPE_SCHEM, NULL AS TYPE_NAME, NULL AS SELF_REFERENCING_COL_NAME, NULL AS REF_GENERATION FROM INFORMATION_SCHEMA.TABLES WHERE ";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1205 */     boolean operatingOnInformationSchema = "information_schema".equalsIgnoreCase(catalog);
/* 1206 */     if (catalog != null) {
/* 1207 */       if ((operatingOnInformationSchema) || ((StringUtils.indexOfIgnoreCase(0, catalog, "%") == -1) && (StringUtils.indexOfIgnoreCase(0, catalog, "_") == -1)))
/*      */       {
/* 1209 */         sql = sql + "TABLE_SCHEMA = ? ";
/*      */       } else {
/* 1211 */         sql = sql + "TABLE_SCHEMA LIKE ? ";
/*      */       }
/*      */     }
/*      */     else {
/* 1215 */       sql = sql + "TABLE_SCHEMA LIKE ? ";
/*      */     }
/*      */     
/* 1218 */     if (tableNamePat != null) {
/* 1219 */       if ((StringUtils.indexOfIgnoreCase(0, tableNamePat, "%") == -1) && (StringUtils.indexOfIgnoreCase(0, tableNamePat, "_") == -1)) {
/* 1220 */         sql = sql + "AND TABLE_NAME = ? ";
/*      */       } else {
/* 1222 */         sql = sql + "AND TABLE_NAME LIKE ? ";
/*      */       }
/*      */     }
/*      */     else {
/* 1226 */       sql = sql + "AND TABLE_NAME LIKE ? ";
/*      */     }
/* 1228 */     sql = sql + "HAVING TABLE_TYPE IN (?,?,?,?,?) ";
/* 1229 */     sql = sql + "ORDER BY TABLE_TYPE, TABLE_SCHEMA, TABLE_NAME";
/*      */     try {
/* 1231 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */       
/* 1233 */       if (catalog != null) {
/* 1234 */         pStmt.setString(1, catalog);
/*      */       } else {
/* 1236 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/* 1239 */       pStmt.setString(2, tableNamePat);
/*      */       
/*      */       int i;
/* 1242 */       if ((types == null) || (types.length == 0)) {
/* 1243 */         DatabaseMetaData.TableType[] tableTypes = DatabaseMetaData.TableType.values();
/* 1244 */         for (int i = 0; i < 5; i++) {
/* 1245 */           pStmt.setString(3 + i, tableTypes[i].getName());
/*      */         }
/*      */       } else {
/* 1248 */         for (int i = 0; i < 5; i++) {
/* 1249 */           pStmt.setNull(3 + i, 12);
/*      */         }
/*      */         
/* 1252 */         int idx = 3;
/* 1253 */         for (i = 0; i < types.length; i++) {
/* 1254 */           DatabaseMetaData.TableType tableType = DatabaseMetaData.TableType.getTableTypeEqualTo(types[i]);
/* 1255 */           if (tableType != DatabaseMetaData.TableType.UNKNOWN) {
/* 1256 */             pStmt.setString(idx++, tableType.getName());
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1261 */       ResultSet rs = executeMetadataQuery(pStmt);
/*      */       
/* 1263 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createTablesFields());
/*      */       
/* 1265 */       return rs;
/*      */     } finally {
/* 1267 */       if (pStmt != null) {
/* 1268 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean gethasParametersView() {
/* 1274 */     return this.hasParametersView;
/*      */   }
/*      */   
/*      */   public ResultSet getVersionColumns(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/* 1280 */     if ((catalog == null) && 
/* 1281 */       (this.conn.getNullCatalogMeansCurrent())) {
/* 1282 */       catalog = this.database;
/*      */     }
/*      */     
/*      */ 
/* 1286 */     if (table == null) {
/* 1287 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 1290 */     StringBuilder sqlBuf = new StringBuilder("SELECT NULL AS SCOPE, COLUMN_NAME, ");
/*      */     
/* 1292 */     MysqlDefs.appendJdbcTypeMappingQuery(sqlBuf, "DATA_TYPE");
/* 1293 */     sqlBuf.append(" AS DATA_TYPE, ");
/*      */     
/* 1295 */     sqlBuf.append("COLUMN_TYPE AS TYPE_NAME, ");
/* 1296 */     sqlBuf.append("CASE WHEN LCASE(DATA_TYPE)='date' THEN 10 WHEN LCASE(DATA_TYPE)='time' THEN 8 WHEN LCASE(DATA_TYPE)='datetime' THEN 19 WHEN LCASE(DATA_TYPE)='timestamp' THEN 19 WHEN CHARACTER_MAXIMUM_LENGTH IS NULL THEN NUMERIC_PRECISION WHEN CHARACTER_MAXIMUM_LENGTH > 2147483647 THEN 2147483647 ELSE CHARACTER_MAXIMUM_LENGTH END AS COLUMN_SIZE, ");
/*      */     
/*      */ 
/*      */ 
/* 1300 */     sqlBuf.append(MysqlIO.getMaxBuf() + " AS BUFFER_LENGTH,NUMERIC_SCALE AS DECIMAL_DIGITS, " + Integer.toString(1) + " AS PSEUDO_COLUMN FROM INFORMATION_SCHEMA.COLUMNS " + "WHERE TABLE_SCHEMA LIKE ? AND TABLE_NAME LIKE ? AND EXTRA LIKE '%on update CURRENT_TIMESTAMP%'");
/*      */     
/*      */ 
/*      */ 
/* 1304 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/* 1307 */       pStmt = prepareMetaDataSafeStatement(sqlBuf.toString());
/*      */       
/* 1309 */       if (catalog != null) {
/* 1310 */         pStmt.setString(1, catalog);
/*      */       } else {
/* 1312 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/* 1315 */       pStmt.setString(2, table);
/*      */       
/* 1317 */       ResultSet rs = executeMetadataQuery(pStmt);
/* 1318 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(new Field[] { new Field("", "SCOPE", 5, 5), new Field("", "COLUMN_NAME", 1, 32), new Field("", "DATA_TYPE", 4, 5), new Field("", "TYPE_NAME", 1, 16), new Field("", "COLUMN_SIZE", 4, 16), new Field("", "BUFFER_LENGTH", 4, 16), new Field("", "DECIMAL_DIGITS", 5, 16), new Field("", "PSEUDO_COLUMN", 5, 5) });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1323 */       return rs;
/*      */     } finally {
/* 1325 */       if (pStmt != null) {
/* 1326 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 1418 */     if (!this.hasParametersView) {
/* 1419 */       return super.getFunctionColumns(catalog, schemaPattern, functionNamePattern, columnNamePattern);
/*      */     }
/*      */     
/* 1422 */     if ((functionNamePattern == null) || (functionNamePattern.length() == 0)) {
/* 1423 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 1424 */         functionNamePattern = "%";
/*      */       } else {
/* 1426 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1431 */     String db = null;
/*      */     
/* 1433 */     if (catalog == null) {
/* 1434 */       if (this.conn.getNullCatalogMeansCurrent()) {
/* 1435 */         db = this.database;
/*      */       }
/*      */     } else {
/* 1438 */       db = catalog;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1446 */     StringBuilder sqlBuf = new StringBuilder("SELECT SPECIFIC_SCHEMA AS FUNCTION_CAT, NULL AS `FUNCTION_SCHEM`, SPECIFIC_NAME AS `FUNCTION_NAME`, ");
/* 1447 */     sqlBuf.append("IFNULL(PARAMETER_NAME, '') AS `COLUMN_NAME`, CASE WHEN PARAMETER_MODE = 'IN' THEN ");
/* 1448 */     sqlBuf.append(getJDBC4FunctionConstant(JDBC4FunctionConstant.FUNCTION_COLUMN_IN));
/* 1449 */     sqlBuf.append(" WHEN PARAMETER_MODE = 'OUT' THEN ");
/* 1450 */     sqlBuf.append(getJDBC4FunctionConstant(JDBC4FunctionConstant.FUNCTION_COLUMN_OUT));
/* 1451 */     sqlBuf.append(" WHEN PARAMETER_MODE = 'INOUT' THEN ");
/* 1452 */     sqlBuf.append(getJDBC4FunctionConstant(JDBC4FunctionConstant.FUNCTION_COLUMN_INOUT));
/* 1453 */     sqlBuf.append(" WHEN ORDINAL_POSITION = 0 THEN ");
/* 1454 */     sqlBuf.append(getJDBC4FunctionConstant(JDBC4FunctionConstant.FUNCTION_COLUMN_RETURN));
/* 1455 */     sqlBuf.append(" ELSE ");
/* 1456 */     sqlBuf.append(getJDBC4FunctionConstant(JDBC4FunctionConstant.FUNCTION_COLUMN_UNKNOWN));
/* 1457 */     sqlBuf.append(" END AS `COLUMN_TYPE`, ");
/*      */     
/*      */ 
/* 1460 */     MysqlDefs.appendJdbcTypeMappingQuery(sqlBuf, "DATA_TYPE");
/*      */     
/* 1462 */     sqlBuf.append(" AS `DATA_TYPE`, ");
/*      */     
/*      */ 
/* 1465 */     if (this.conn.getCapitalizeTypeNames()) {
/* 1466 */       sqlBuf.append("UPPER(CASE WHEN LOCATE('unsigned', DATA_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END) AS `TYPE_NAME`,");
/*      */     }
/*      */     else {
/* 1469 */       sqlBuf.append("CASE WHEN LOCATE('unsigned', DATA_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END AS `TYPE_NAME`,");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1474 */     sqlBuf.append("NUMERIC_PRECISION AS `PRECISION`, ");
/*      */     
/* 1476 */     sqlBuf.append("CASE WHEN LCASE(DATA_TYPE)='date' THEN 10 WHEN LCASE(DATA_TYPE)='time' THEN 8 WHEN LCASE(DATA_TYPE)='datetime' THEN 19 WHEN LCASE(DATA_TYPE)='timestamp' THEN 19 WHEN CHARACTER_MAXIMUM_LENGTH IS NULL THEN NUMERIC_PRECISION WHEN CHARACTER_MAXIMUM_LENGTH > 2147483647 THEN 2147483647 ELSE CHARACTER_MAXIMUM_LENGTH END AS LENGTH, ");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1481 */     sqlBuf.append("NUMERIC_SCALE AS `SCALE`, ");
/*      */     
/* 1483 */     sqlBuf.append("10 AS RADIX,");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1490 */     sqlBuf.append(getJDBC4FunctionConstant(JDBC4FunctionConstant.FUNCTION_NULLABLE) + " AS `NULLABLE`,  NULL AS `REMARKS`, " + "CHARACTER_OCTET_LENGTH AS `CHAR_OCTET_LENGTH`,  ORDINAL_POSITION, 'YES' AS `IS_NULLABLE`, SPECIFIC_NAME " + "FROM INFORMATION_SCHEMA.PARAMETERS WHERE " + "SPECIFIC_SCHEMA LIKE ? AND SPECIFIC_NAME LIKE ? AND (PARAMETER_NAME LIKE ? OR PARAMETER_NAME IS NULL) " + "AND ROUTINE_TYPE='FUNCTION' ORDER BY SPECIFIC_SCHEMA, SPECIFIC_NAME, ORDINAL_POSITION");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1496 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/* 1499 */       pStmt = prepareMetaDataSafeStatement(sqlBuf.toString());
/*      */       
/* 1501 */       if (db != null) {
/* 1502 */         pStmt.setString(1, db);
/*      */       } else {
/* 1504 */         pStmt.setString(1, "%");
/*      */       }
/*      */       
/* 1507 */       pStmt.setString(2, functionNamePattern);
/* 1508 */       pStmt.setString(3, columnNamePattern);
/*      */       
/* 1510 */       ResultSet rs = executeMetadataQuery(pStmt);
/* 1511 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(createFunctionColumnsFields());
/*      */       
/* 1513 */       return rs;
/*      */     } finally {
/* 1515 */       if (pStmt != null) {
/* 1516 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getJDBC4FunctionConstant(JDBC4FunctionConstant constant)
/*      */   {
/* 1531 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern)
/*      */     throws SQLException
/*      */   {
/* 1581 */     if ((functionNamePattern == null) || (functionNamePattern.length() == 0)) {
/* 1582 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 1583 */         functionNamePattern = "%";
/*      */       } else {
/* 1585 */         throw SQLError.createSQLException("Function name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1590 */     String db = null;
/*      */     
/* 1592 */     if (catalog == null) {
/* 1593 */       if (this.conn.getNullCatalogMeansCurrent()) {
/* 1594 */         db = this.database;
/*      */       }
/*      */     } else {
/* 1597 */       db = catalog;
/*      */     }
/*      */     
/* 1600 */     String sql = "SELECT ROUTINE_SCHEMA AS FUNCTION_CAT, NULL AS FUNCTION_SCHEM, ROUTINE_NAME AS FUNCTION_NAME, ROUTINE_COMMENT AS REMARKS, " + getJDBC4FunctionNoTableConstant() + " AS FUNCTION_TYPE, ROUTINE_NAME AS SPECIFIC_NAME FROM INFORMATION_SCHEMA.ROUTINES " + "WHERE ROUTINE_TYPE LIKE 'FUNCTION' AND ROUTINE_SCHEMA LIKE ? AND " + "ROUTINE_NAME LIKE ? ORDER BY FUNCTION_CAT, FUNCTION_SCHEM, FUNCTION_NAME, SPECIFIC_NAME";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1605 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/* 1608 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */       
/* 1610 */       pStmt.setString(1, db != null ? db : "%");
/* 1611 */       pStmt.setString(2, functionNamePattern);
/*      */       
/* 1613 */       ResultSet rs = executeMetadataQuery(pStmt);
/* 1614 */       ((ResultSetInternalMethods)rs).redefineFieldsForDBMD(new Field[] { new Field("", "FUNCTION_CAT", 1, 255), new Field("", "FUNCTION_SCHEM", 1, 255), new Field("", "FUNCTION_NAME", 1, 255), new Field("", "REMARKS", 1, 255), new Field("", "FUNCTION_TYPE", 5, 6), new Field("", "SPECIFIC_NAME", 1, 255) });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1619 */       return rs;
/*      */     } finally {
/* 1621 */       if (pStmt != null) {
/* 1622 */         pStmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getJDBC4FunctionNoTableConstant()
/*      */   {
/* 1635 */     return 0;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/DatabaseMetaDataUsingInfoSchema.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */