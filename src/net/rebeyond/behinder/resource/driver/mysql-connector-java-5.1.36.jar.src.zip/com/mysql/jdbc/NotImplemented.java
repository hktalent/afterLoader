/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotImplemented
/*    */   extends SQLException
/*    */ {
/*    */   static final long serialVersionUID = 7768433826547599990L;
/*    */   
/*    */   public NotImplemented()
/*    */   {
/* 37 */     super(Messages.getString("NotImplemented.0"), "S1C00");
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/NotImplemented.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */