/*    */ package com.mysql.fabric;
/*    */ 
/*    */ import com.mysql.fabric.proto.xmlrpc.ResultSetParser;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Response
/*    */ {
/*    */   private int protocolVersion;
/*    */   private String fabricUuid;
/*    */   private int ttl;
/*    */   private String errorMessage;
/*    */   private List<Map> resultSet;
/*    */   
/*    */   public Response(List responseData)
/*    */     throws FabricCommunicationException
/*    */   {
/* 43 */     this.protocolVersion = ((Integer)responseData.get(0)).intValue();
/* 44 */     if (this.protocolVersion != 1) {
/* 45 */       throw new FabricCommunicationException("Unknown protocol version: " + this.protocolVersion);
/*    */     }
/* 47 */     this.fabricUuid = ((String)responseData.get(1));
/* 48 */     this.ttl = ((Integer)responseData.get(2)).intValue();
/* 49 */     this.errorMessage = ((String)responseData.get(3));
/* 50 */     if ("".equals(this.errorMessage)) {
/* 51 */       this.errorMessage = null;
/*    */     }
/* 53 */     List resultSets = (List)responseData.get(4);
/* 54 */     if (resultSets.size() > 0) {
/* 55 */       Map<String, ?> resultData = (Map)resultSets.get(0);
/* 56 */       this.resultSet = new ResultSetParser().parse((Map)resultData.get("info"), (List)resultData.get("rows"));
/*    */     }
/*    */   }
/*    */   
/*    */   public int getProtocolVersion() {
/* 61 */     return this.protocolVersion;
/*    */   }
/*    */   
/*    */   public String getFabricUuid() {
/* 65 */     return this.fabricUuid;
/*    */   }
/*    */   
/*    */   public int getTtl() {
/* 69 */     return this.ttl;
/*    */   }
/*    */   
/*    */   public String getErrorMessage() {
/* 73 */     return this.errorMessage;
/*    */   }
/*    */   
/*    */   public List<Map> getResultSet() {
/* 77 */     return this.resultSet;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/Response.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */