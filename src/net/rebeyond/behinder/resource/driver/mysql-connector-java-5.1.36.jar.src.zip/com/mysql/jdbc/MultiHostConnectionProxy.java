/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MultiHostConnectionProxy
/*     */   implements InvocationHandler
/*     */ {
/*     */   private static final String METHOD_GET_MULTI_HOST_SAFE_PROXY = "getMultiHostSafeProxy";
/*     */   private static final String METHOD_EQUALS = "equals";
/*     */   private static final String METHOD_HASH_CODE = "hashCode";
/*     */   private static final String METHOD_CLOSE = "close";
/*     */   private static final String METHOD_ABORT_INTERNAL = "abortInternal";
/*     */   private static final String METHOD_ABORT = "abort";
/*     */   private static final String METHOD_IS_CLOSED = "isClosed";
/*     */   List<String> hostList;
/*     */   Properties localProps;
/*  52 */   boolean autoReconnect = false;
/*     */   
/*  54 */   MySQLConnection thisAsConnection = null;
/*  55 */   MySQLConnection currentConnection = null;
/*     */   
/*  57 */   boolean isClosed = false;
/*  58 */   boolean closedExplicitly = false;
/*  59 */   String closedReason = null;
/*     */   private static Constructor<?> JDBC_4_MS_CONNECTION_CTOR;
/*     */   
/*     */   static {
/*  63 */     if (Util.isJdbc4()) {
/*     */       try {
/*  65 */         JDBC_4_MS_CONNECTION_CTOR = Class.forName("com.mysql.jdbc.JDBC4MultiHostMySQLConnection").getConstructor(new Class[] { MultiHostConnectionProxy.class });
/*     */       }
/*     */       catch (SecurityException e) {
/*  68 */         throw new RuntimeException(e);
/*     */       } catch (NoSuchMethodException e) {
/*  70 */         throw new RuntimeException(e);
/*     */       } catch (ClassNotFoundException e) {
/*  72 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   class JdbcInterfaceProxy
/*     */     implements InvocationHandler
/*     */   {
/*  81 */     Object invokeOn = null;
/*     */     
/*     */     JdbcInterfaceProxy(Object toInvokeOn) {
/*  84 */       this.invokeOn = toInvokeOn;
/*     */     }
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  88 */       Object result = null;
/*     */       try
/*     */       {
/*  91 */         result = method.invoke(this.invokeOn, args);
/*  92 */         result = MultiHostConnectionProxy.this.proxyIfIsJdbcInterface(result);
/*     */       } catch (InvocationTargetException e) {
/*  94 */         MultiHostConnectionProxy.this.dealWithInvocationException(e);
/*     */       }
/*     */       
/*  97 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MultiHostConnectionProxy()
/*     */     throws SQLException
/*     */   {
/* 108 */     this.thisAsConnection = getNewWrapperForThisAsConnection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MultiHostConnectionProxy(List<String> hosts, Properties props)
/*     */     throws SQLException
/*     */   {
/* 120 */     this();
/* 121 */     initializeHostsSpecs(hosts, props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int initializeHostsSpecs(List<String> hosts, Properties props)
/*     */   {
/* 136 */     this.autoReconnect = (("true".equalsIgnoreCase(props.getProperty("autoReconnect"))) || ("true".equalsIgnoreCase(props.getProperty("autoReconnectForPools"))));
/*     */     
/* 138 */     this.hostList = hosts;
/* 139 */     int numHosts = this.hostList.size();
/*     */     
/* 141 */     this.localProps = ((Properties)props.clone());
/* 142 */     this.localProps.remove("HOST");
/* 143 */     this.localProps.remove("PORT");
/*     */     
/* 145 */     for (int i = 0; i < numHosts; i++) {
/* 146 */       this.localProps.remove("HOST." + (i + 1));
/* 147 */       this.localProps.remove("PORT." + (i + 1));
/*     */     }
/*     */     
/* 150 */     this.localProps.remove("NUM_HOSTS");
/* 151 */     this.localProps.setProperty("useLocalSessionState", "true");
/*     */     
/* 153 */     return numHosts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MySQLConnection getNewWrapperForThisAsConnection()
/*     */     throws SQLException
/*     */   {
/* 163 */     if ((Util.isJdbc4()) || (JDBC_4_MS_CONNECTION_CTOR != null)) {
/* 164 */       return (MySQLConnection)Util.handleNewInstance(JDBC_4_MS_CONNECTION_CTOR, new Object[] { this }, null);
/*     */     }
/*     */     
/* 167 */     return new MultiHostMySQLConnection(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object proxyIfIsJdbcInterface(Object toProxy)
/*     */   {
/* 179 */     if (toProxy != null) {
/* 180 */       Class<?> clazz = toProxy.getClass();
/* 181 */       if (Util.isJdbcInterface(clazz)) {
/* 182 */         return Proxy.newProxyInstance(clazz.getClassLoader(), Util.getImplementedInterfaces(clazz), getNewJdbcInterfaceProxy(toProxy));
/*     */       }
/*     */     }
/* 185 */     return toProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   InvocationHandler getNewJdbcInterfaceProxy(Object toProxy)
/*     */   {
/* 197 */     return new JdbcInterfaceProxy(toProxy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void dealWithInvocationException(InvocationTargetException e)
/*     */     throws SQLException, Throwable, InvocationTargetException
/*     */   {
/* 207 */     Throwable t = e.getTargetException();
/*     */     
/* 209 */     if (t != null) {
/* 210 */       if (shouldExceptionTriggerConnectionSwitch(t)) {
/* 211 */         invalidateCurrentConnection();
/* 212 */         pickNewConnection();
/*     */       }
/* 214 */       throw t;
/*     */     }
/* 216 */     throw e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void invalidateCurrentConnection()
/*     */     throws SQLException
/*     */   {
/* 231 */     invalidateConnection(this.currentConnection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void invalidateConnection(MySQLConnection conn)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 242 */       if ((conn != null) && (!conn.isClosed())) {
/* 243 */         conn.realClose(true, !conn.getAutoCommit(), true, null);
/*     */       }
/*     */     }
/*     */     catch (SQLException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized ConnectionImpl createConnectionForHost(String hostPortSpec)
/*     */     throws SQLException
/*     */   {
/* 264 */     Properties connProps = (Properties)this.localProps.clone();
/*     */     
/* 266 */     String[] hostPortPair = NonRegisteringDriver.parseHostPortPair(hostPortSpec);
/* 267 */     String hostName = hostPortPair[0];
/* 268 */     String portNumber = hostPortPair[1];
/* 269 */     String dbName = connProps.getProperty("DBNAME");
/*     */     
/* 271 */     if (hostName == null) {
/* 272 */       throw new SQLException("Could not find a hostname to start a connection to");
/*     */     }
/* 274 */     if (portNumber == null) {
/* 275 */       portNumber = "3306";
/*     */     }
/*     */     
/* 278 */     connProps.setProperty("HOST", hostName);
/* 279 */     connProps.setProperty("PORT", portNumber);
/* 280 */     connProps.setProperty("HOST.1", hostName);
/* 281 */     connProps.setProperty("PORT.1", portNumber);
/* 282 */     connProps.setProperty("NUM_HOSTS", "1");
/* 283 */     connProps.setProperty("roundRobinLoadBalance", "false");
/*     */     
/* 285 */     ConnectionImpl conn = (ConnectionImpl)ConnectionImpl.getInstance(hostName, Integer.parseInt(portNumber), connProps, dbName, "jdbc:mysql://" + hostName + ":" + portNumber + "/");
/*     */     
/*     */ 
/* 288 */     conn.setProxy(this.thisAsConnection);
/* 289 */     conn.setRealProxy(this);
/*     */     
/* 291 */     return conn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void syncSessionState(Connection source, Connection target)
/*     */     throws SQLException
/*     */   {
/* 303 */     if ((source == null) || (target == null)) {
/* 304 */       return;
/*     */     }
/* 306 */     syncSessionState(source, target, source.isReadOnly());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void syncSessionState(Connection source, Connection target, boolean readOnly)
/*     */     throws SQLException
/*     */   {
/* 320 */     target.setReadOnly(readOnly);
/*     */     
/* 322 */     if ((source == null) || (target == null)) {
/* 323 */       return;
/*     */     }
/* 325 */     target.setAutoCommit(source.getAutoCommit());
/* 326 */     target.setCatalog(source.getCatalog());
/* 327 */     target.setTransactionIsolation(source.getTransactionIsolation());
/* 328 */     target.setSessionMaxRows(source.getSessionMaxRows());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Object invoke(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/* 352 */     String methodName = method.getName();
/*     */     
/* 354 */     if ("getMultiHostSafeProxy".equals(methodName)) {
/* 355 */       return this.currentConnection;
/*     */     }
/*     */     
/* 358 */     if ("equals".equals(methodName))
/*     */     {
/* 360 */       return Boolean.valueOf(args[0].equals(this));
/*     */     }
/*     */     
/* 363 */     if ("hashCode".equals(methodName)) {
/* 364 */       return Integer.valueOf(hashCode());
/*     */     }
/*     */     
/* 367 */     if ("close".equals(methodName)) {
/* 368 */       doClose();
/* 369 */       this.isClosed = true;
/* 370 */       this.closedReason = "Connection explicitly closed.";
/* 371 */       this.closedExplicitly = true;
/* 372 */       return null;
/*     */     }
/*     */     
/* 375 */     if ("abortInternal".equals(methodName)) {
/* 376 */       doAbortInternal();
/* 377 */       this.currentConnection.abortInternal();
/* 378 */       this.isClosed = true;
/* 379 */       this.closedReason = "Connection explicitly closed.";
/* 380 */       return null;
/*     */     }
/*     */     
/* 383 */     if (("abort".equals(methodName)) && (args.length == 1)) {
/* 384 */       doAbort((Executor)args[0]);
/* 385 */       this.isClosed = true;
/* 386 */       this.closedReason = "Connection explicitly closed.";
/* 387 */       return null;
/*     */     }
/*     */     
/* 390 */     if ("isClosed".equals(methodName)) {
/* 391 */       return Boolean.valueOf(this.isClosed);
/*     */     }
/*     */     
/* 394 */     return invokeMore(proxy, method, args);
/*     */   }
/*     */   
/*     */   abstract boolean shouldExceptionTriggerConnectionSwitch(Throwable paramThrowable);
/*     */   
/*     */   abstract void pickNewConnection()
/*     */     throws SQLException;
/*     */   
/*     */   abstract void doClose()
/*     */     throws SQLException;
/*     */   
/*     */   abstract void doAbortInternal()
/*     */     throws SQLException;
/*     */   
/*     */   abstract void doAbort(Executor paramExecutor)
/*     */     throws SQLException;
/*     */   
/*     */   abstract Object invokeMore(Object paramObject, Method paramMethod, Object[] paramArrayOfObject)
/*     */     throws Throwable;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/MultiHostConnectionProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */