/*    */ package com.mysql.fabric.xmlrpc.base;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Param
/*    */ {
/*    */   protected Value value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Param() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Param(Value value)
/*    */   {
/* 34 */     this.value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Value getValue()
/*    */   {
/* 41 */     return this.value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setValue(Value value)
/*    */   {
/* 48 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 53 */     StringBuilder sb = new StringBuilder("<param>");
/* 54 */     sb.append(this.value.toString());
/* 55 */     sb.append("</param>");
/* 56 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/xmlrpc/base/Param.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */