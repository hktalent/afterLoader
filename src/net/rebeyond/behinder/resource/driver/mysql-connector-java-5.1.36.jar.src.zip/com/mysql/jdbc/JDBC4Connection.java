/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.Array;
/*     */ import java.sql.NClob;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Struct;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBC4Connection
/*     */   extends ConnectionImpl
/*     */ {
/*     */   private JDBC4ClientInfoProvider infoProvider;
/*     */   
/*     */   public JDBC4Connection(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url)
/*     */     throws SQLException
/*     */   {
/*  44 */     super(hostToConnectTo, portToConnectTo, info, databaseToConnectTo, url);
/*     */   }
/*     */   
/*     */   public SQLXML createSQLXML() throws SQLException {
/*  48 */     return new JDBC4MysqlSQLXML(getExceptionInterceptor());
/*     */   }
/*     */   
/*     */   public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
/*  52 */     throw SQLError.notImplemented();
/*     */   }
/*     */   
/*     */   public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
/*  56 */     throw SQLError.notImplemented();
/*     */   }
/*     */   
/*     */   public Properties getClientInfo() throws SQLException {
/*  60 */     return getClientInfoProviderImpl().getClientInfo(this);
/*     */   }
/*     */   
/*     */   public String getClientInfo(String name) throws SQLException {
/*  64 */     return getClientInfoProviderImpl().getClientInfo(this, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValid(int timeout)
/*     */     throws SQLException
/*     */   {
/*  89 */     synchronized (getConnectionMutex()) {
/*  90 */       if (isClosed()) {
/*  91 */         return false;
/*     */       }
/*     */       try
/*     */       {
/*     */         try {
/*  96 */           pingInternal(false, timeout * 1000);
/*     */         } catch (Throwable t) {
/*     */           try {
/*  99 */             abortInternal();
/*     */           }
/*     */           catch (Throwable ignoreThrown) {}
/*     */           
/*     */ 
/* 104 */           return false;
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {
/* 108 */         return false;
/*     */       }
/*     */       
/* 111 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setClientInfo(Properties properties) throws SQLClientInfoException {
/*     */     try {
/* 117 */       getClientInfoProviderImpl().setClientInfo(this, properties);
/*     */     } catch (SQLClientInfoException ciEx) {
/* 119 */       throw ciEx;
/*     */     } catch (SQLException sqlEx) {
/* 121 */       SQLClientInfoException clientInfoEx = new SQLClientInfoException();
/* 122 */       clientInfoEx.initCause(sqlEx);
/*     */       
/* 124 */       throw clientInfoEx;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setClientInfo(String name, String value) throws SQLClientInfoException {
/*     */     try {
/* 130 */       getClientInfoProviderImpl().setClientInfo(this, name, value);
/*     */     } catch (SQLClientInfoException ciEx) {
/* 132 */       throw ciEx;
/*     */     } catch (SQLException sqlEx) {
/* 134 */       SQLClientInfoException clientInfoEx = new SQLClientInfoException();
/* 135 */       clientInfoEx.initCause(sqlEx);
/*     */       
/* 137 */       throw clientInfoEx;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWrapperFor(Class<?> iface)
/*     */     throws SQLException
/*     */   {
/* 159 */     checkClosed();
/*     */     
/*     */ 
/* 162 */     return iface.isInstance(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T unwrap(Class<T> iface)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 184 */       return (T)iface.cast(this);
/*     */     } catch (ClassCastException cce) {
/* 186 */       throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", getExceptionInterceptor());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public java.sql.Blob createBlob()
/*     */   {
/* 194 */     return new Blob(getExceptionInterceptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public java.sql.Clob createClob()
/*     */   {
/* 201 */     return new Clob(getExceptionInterceptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NClob createNClob()
/*     */   {
/* 208 */     return new JDBC4NClob(getExceptionInterceptor());
/*     */   }
/*     */   
/*     */   protected JDBC4ClientInfoProvider getClientInfoProviderImpl() throws SQLException {
/* 212 */     synchronized (getConnectionMutex()) {
/* 213 */       if (this.infoProvider == null) {
/*     */         try {
/*     */           try {
/* 216 */             this.infoProvider = ((JDBC4ClientInfoProvider)Util.getInstance(getClientInfoProvider(), new Class[0], new Object[0], getExceptionInterceptor()));
/*     */           }
/*     */           catch (SQLException sqlEx) {
/* 219 */             if ((sqlEx.getCause() instanceof ClassCastException))
/*     */             {
/* 221 */               this.infoProvider = ((JDBC4ClientInfoProvider)Util.getInstance("com.mysql.jdbc." + getClientInfoProvider(), new Class[0], new Object[0], getExceptionInterceptor()));
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (ClassCastException cce) {
/* 226 */           throw SQLError.createSQLException(Messages.getString("JDBC4Connection.ClientInfoNotImplemented", new Object[] { getClientInfoProvider() }), "S1009", getExceptionInterceptor());
/*     */         }
/*     */         
/*     */ 
/* 230 */         this.infoProvider.initialize(this, this.props);
/*     */       }
/*     */       
/* 233 */       return this.infoProvider;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/JDBC4Connection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */