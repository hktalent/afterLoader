package com.mysql.jdbc;

import java.util.Set;

public abstract interface CacheAdapter<K, V>
{
  public abstract V get(K paramK);
  
  public abstract void put(K paramK, V paramV);
  
  public abstract void invalidate(K paramK);
  
  public abstract void invalidateAll(Set<K> paramSet);
  
  public abstract void invalidateAll();
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/CacheAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */