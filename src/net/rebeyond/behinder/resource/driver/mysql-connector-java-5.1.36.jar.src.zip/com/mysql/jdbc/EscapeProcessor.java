/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EscapeProcessor
/*     */ {
/*     */   private static Map<String, String> JDBC_CONVERT_TO_MYSQL_TYPE_MAP;
/*     */   private static Map<String, String> JDBC_NO_CONVERT_TO_MYSQL_EXPRESSION_MAP;
/*     */   
/*     */   static
/*     */   {
/*  48 */     Map<String, String> tempMap = new HashMap();
/*     */     
/*  50 */     tempMap.put("BIGINT", "0 + ?");
/*  51 */     tempMap.put("BINARY", "BINARY");
/*  52 */     tempMap.put("BIT", "0 + ?");
/*  53 */     tempMap.put("CHAR", "CHAR");
/*  54 */     tempMap.put("DATE", "DATE");
/*  55 */     tempMap.put("DECIMAL", "0.0 + ?");
/*  56 */     tempMap.put("DOUBLE", "0.0 + ?");
/*  57 */     tempMap.put("FLOAT", "0.0 + ?");
/*  58 */     tempMap.put("INTEGER", "0 + ?");
/*  59 */     tempMap.put("LONGVARBINARY", "BINARY");
/*  60 */     tempMap.put("LONGVARCHAR", "CONCAT(?)");
/*  61 */     tempMap.put("REAL", "0.0 + ?");
/*  62 */     tempMap.put("SMALLINT", "CONCAT(?)");
/*  63 */     tempMap.put("TIME", "TIME");
/*  64 */     tempMap.put("TIMESTAMP", "DATETIME");
/*  65 */     tempMap.put("TINYINT", "CONCAT(?)");
/*  66 */     tempMap.put("VARBINARY", "BINARY");
/*  67 */     tempMap.put("VARCHAR", "CONCAT(?)");
/*     */     
/*  69 */     JDBC_CONVERT_TO_MYSQL_TYPE_MAP = Collections.unmodifiableMap(tempMap);
/*     */     
/*  71 */     tempMap = new HashMap(JDBC_CONVERT_TO_MYSQL_TYPE_MAP);
/*     */     
/*  73 */     tempMap.put("BINARY", "CONCAT(?)");
/*  74 */     tempMap.put("CHAR", "CONCAT(?)");
/*  75 */     tempMap.remove("DATE");
/*  76 */     tempMap.put("LONGVARBINARY", "CONCAT(?)");
/*  77 */     tempMap.remove("TIME");
/*  78 */     tempMap.remove("TIMESTAMP");
/*  79 */     tempMap.put("VARBINARY", "CONCAT(?)");
/*     */     
/*  81 */     JDBC_NO_CONVERT_TO_MYSQL_EXPRESSION_MAP = Collections.unmodifiableMap(tempMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Object escapeSQL(String sql, boolean serverSupportsConvertFn, MySQLConnection conn)
/*     */     throws SQLException
/*     */   {
/*  97 */     boolean replaceEscapeSequence = false;
/*  98 */     String escapeSequence = null;
/*     */     
/* 100 */     if (sql == null) {
/* 101 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 107 */     int beginBrace = sql.indexOf('{');
/* 108 */     int nextEndBrace = beginBrace == -1 ? -1 : sql.indexOf('}', beginBrace);
/*     */     
/* 110 */     if (nextEndBrace == -1) {
/* 111 */       return sql;
/*     */     }
/*     */     
/* 114 */     StringBuilder newSql = new StringBuilder();
/*     */     
/* 116 */     EscapeTokenizer escapeTokenizer = new EscapeTokenizer(sql);
/*     */     
/* 118 */     byte usesVariables = 0;
/* 119 */     boolean callingStoredFunction = false;
/*     */     
/* 121 */     while (escapeTokenizer.hasMoreTokens()) {
/* 122 */       String token = escapeTokenizer.nextToken();
/*     */       
/* 124 */       if (token.length() != 0) {
/* 125 */         if (token.charAt(0) == '{')
/*     */         {
/* 127 */           if (!token.endsWith("}")) {
/* 128 */             throw SQLError.createSQLException("Not a valid escape sequence: " + token, conn.getExceptionInterceptor());
/*     */           }
/*     */           
/* 131 */           if (token.length() > 2) {
/* 132 */             int nestedBrace = token.indexOf('{', 2);
/*     */             
/* 134 */             if (nestedBrace != -1) {
/* 135 */               StringBuilder buf = new StringBuilder(token.substring(0, 1));
/*     */               
/* 137 */               Object remainingResults = escapeSQL(token.substring(1, token.length() - 1), serverSupportsConvertFn, conn);
/*     */               
/* 139 */               String remaining = null;
/*     */               
/* 141 */               if ((remainingResults instanceof String)) {
/* 142 */                 remaining = (String)remainingResults;
/*     */               } else {
/* 144 */                 remaining = ((EscapeProcessorResult)remainingResults).escapedSql;
/*     */                 
/* 146 */                 if (usesVariables != 1) {
/* 147 */                   usesVariables = ((EscapeProcessorResult)remainingResults).usesVariables;
/*     */                 }
/*     */               }
/*     */               
/* 151 */               buf.append(remaining);
/*     */               
/* 153 */               buf.append('}');
/*     */               
/* 155 */               token = buf.toString();
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 161 */           String collapsedToken = removeWhitespace(token);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 166 */           if (StringUtils.startsWithIgnoreCase(collapsedToken, "{escape")) {
/*     */             try {
/* 168 */               StringTokenizer st = new StringTokenizer(token, " '");
/* 169 */               st.nextToken();
/* 170 */               escapeSequence = st.nextToken();
/*     */               
/* 172 */               if (escapeSequence.length() < 3) {
/* 173 */                 newSql.append(token);
/*     */               }
/*     */               else {
/* 176 */                 escapeSequence = escapeSequence.substring(1, escapeSequence.length() - 1);
/* 177 */                 replaceEscapeSequence = true;
/*     */               }
/*     */             } catch (NoSuchElementException e) {
/* 180 */               newSql.append(token);
/*     */             }
/* 182 */           } else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{fn")) {
/* 183 */             int startPos = token.toLowerCase().indexOf("fn ") + 3;
/* 184 */             int endPos = token.length() - 1;
/*     */             
/* 186 */             String fnToken = token.substring(startPos, endPos);
/*     */             
/*     */ 
/*     */ 
/* 190 */             if (StringUtils.startsWithIgnoreCaseAndWs(fnToken, "convert")) {
/* 191 */               newSql.append(processConvertToken(fnToken, serverSupportsConvertFn, conn));
/*     */             }
/*     */             else {
/* 194 */               newSql.append(fnToken);
/*     */             }
/* 196 */           } else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{d")) {
/* 197 */             int startPos = token.indexOf('\'') + 1;
/* 198 */             int endPos = token.lastIndexOf('\'');
/*     */             
/* 200 */             if ((startPos == -1) || (endPos == -1)) {
/* 201 */               newSql.append(token);
/*     */             }
/*     */             else {
/* 204 */               String argument = token.substring(startPos, endPos);
/*     */               try
/*     */               {
/* 207 */                 StringTokenizer st = new StringTokenizer(argument, " -");
/* 208 */                 String year4 = st.nextToken();
/* 209 */                 String month2 = st.nextToken();
/* 210 */                 String day2 = st.nextToken();
/* 211 */                 String dateString = "'" + year4 + "-" + month2 + "-" + day2 + "'";
/* 212 */                 newSql.append(dateString);
/*     */               } catch (NoSuchElementException e) {
/* 214 */                 throw SQLError.createSQLException("Syntax error for DATE escape sequence '" + argument + "'", "42000", conn.getExceptionInterceptor());
/*     */               }
/*     */             }
/*     */           }
/* 218 */           else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{ts")) {
/* 219 */             processTimestampToken(conn, newSql, token);
/* 220 */           } else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{t")) {
/* 221 */             processTimeToken(conn, newSql, token);
/* 222 */           } else if ((StringUtils.startsWithIgnoreCase(collapsedToken, "{call")) || (StringUtils.startsWithIgnoreCase(collapsedToken, "{?=call")))
/*     */           {
/* 224 */             int startPos = StringUtils.indexOfIgnoreCase(token, "CALL") + 5;
/* 225 */             int endPos = token.length() - 1;
/*     */             
/* 227 */             if (StringUtils.startsWithIgnoreCase(collapsedToken, "{?=call")) {
/* 228 */               callingStoredFunction = true;
/* 229 */               newSql.append("SELECT ");
/* 230 */               newSql.append(token.substring(startPos, endPos));
/*     */             } else {
/* 232 */               callingStoredFunction = false;
/* 233 */               newSql.append("CALL ");
/* 234 */               newSql.append(token.substring(startPos, endPos));
/*     */             }
/*     */             
/* 237 */             for (int i = endPos - 1; i >= startPos; i--) {
/* 238 */               char c = token.charAt(i);
/*     */               
/* 240 */               if (!Character.isWhitespace(c))
/*     */               {
/*     */ 
/*     */ 
/* 244 */                 if (c == ')') break;
/* 245 */                 newSql.append("()"); break;
/*     */               }
/*     */               
/*     */             }
/*     */           }
/* 250 */           else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{oj"))
/*     */           {
/* 252 */             newSql.append(token);
/*     */           }
/*     */           else {
/* 255 */             newSql.append(token);
/*     */           }
/*     */         } else {
/* 258 */           newSql.append(token);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 263 */     String escapedSql = newSql.toString();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 268 */     if (replaceEscapeSequence) {
/* 269 */       String currentSql = escapedSql;
/*     */       
/* 271 */       while (currentSql.indexOf(escapeSequence) != -1) {
/* 272 */         int escapePos = currentSql.indexOf(escapeSequence);
/* 273 */         String lhs = currentSql.substring(0, escapePos);
/* 274 */         String rhs = currentSql.substring(escapePos + 1, currentSql.length());
/* 275 */         currentSql = lhs + "\\" + rhs;
/*     */       }
/*     */       
/* 278 */       escapedSql = currentSql;
/*     */     }
/*     */     
/* 281 */     EscapeProcessorResult epr = new EscapeProcessorResult();
/* 282 */     epr.escapedSql = escapedSql;
/* 283 */     epr.callingStoredFunction = callingStoredFunction;
/*     */     
/* 285 */     if (usesVariables != 1) {
/* 286 */       if (escapeTokenizer.sawVariableUse()) {
/* 287 */         epr.usesVariables = 1;
/*     */       } else {
/* 289 */         epr.usesVariables = 0;
/*     */       }
/*     */     }
/*     */     
/* 293 */     return epr;
/*     */   }
/*     */   
/*     */   private static void processTimeToken(MySQLConnection conn, StringBuilder newSql, String token) throws SQLException {
/* 297 */     int startPos = token.indexOf('\'') + 1;
/* 298 */     int endPos = token.lastIndexOf('\'');
/*     */     
/* 300 */     if ((startPos == -1) || (endPos == -1)) {
/* 301 */       newSql.append(token);
/*     */     }
/*     */     else {
/* 304 */       String argument = token.substring(startPos, endPos);
/*     */       try
/*     */       {
/* 307 */         StringTokenizer st = new StringTokenizer(argument, " :.");
/* 308 */         String hour = st.nextToken();
/* 309 */         String minute = st.nextToken();
/* 310 */         String second = st.nextToken();
/*     */         
/* 312 */         boolean serverSupportsFractionalSecond = false;
/* 313 */         String fractionalSecond = "";
/*     */         
/* 315 */         if ((st.hasMoreTokens()) && 
/* 316 */           (conn.versionMeetsMinimum(5, 6, 4))) {
/* 317 */           serverSupportsFractionalSecond = true;
/* 318 */           fractionalSecond = "." + st.nextToken();
/*     */         }
/*     */         
/*     */ 
/* 322 */         if ((conn != null) && ((!conn.getUseTimezone()) || (!conn.getUseLegacyDatetimeCode()))) {
/* 323 */           newSql.append("'");
/* 324 */           newSql.append(hour);
/* 325 */           newSql.append(":");
/* 326 */           newSql.append(minute);
/* 327 */           newSql.append(":");
/* 328 */           newSql.append(second);
/* 329 */           newSql.append(fractionalSecond);
/* 330 */           newSql.append("'");
/*     */         } else {
/* 332 */           Calendar sessionCalendar = null;
/*     */           
/* 334 */           if (conn != null) {
/* 335 */             sessionCalendar = conn.getCalendarInstanceForSessionOrNew();
/*     */           } else {
/* 337 */             sessionCalendar = new GregorianCalendar();
/*     */           }
/*     */           try
/*     */           {
/* 341 */             int hourInt = Integer.parseInt(hour);
/* 342 */             int minuteInt = Integer.parseInt(minute);
/* 343 */             int secondInt = Integer.parseInt(second);
/*     */             
/* 345 */             Time toBeAdjusted = TimeUtil.fastTimeCreate(sessionCalendar, hourInt, minuteInt, secondInt, conn.getExceptionInterceptor());
/*     */             
/* 347 */             Time inServerTimezone = TimeUtil.changeTimezone(conn, sessionCalendar, null, toBeAdjusted, sessionCalendar.getTimeZone(), conn.getServerTimezoneTZ(), false);
/*     */             
/*     */ 
/* 350 */             newSql.append("'");
/* 351 */             newSql.append(inServerTimezone.toString());
/*     */             
/* 353 */             if (serverSupportsFractionalSecond) {
/* 354 */               newSql.append(fractionalSecond);
/*     */             }
/*     */             
/* 357 */             newSql.append("'");
/*     */           }
/*     */           catch (NumberFormatException nfe) {
/* 360 */             throw SQLError.createSQLException("Syntax error in TIMESTAMP escape sequence '" + token + "'.", "S1009", conn.getExceptionInterceptor());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (NoSuchElementException e) {
/* 365 */         throw SQLError.createSQLException("Syntax error for escape sequence '" + argument + "'", "42000", conn.getExceptionInterceptor());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void processTimestampToken(MySQLConnection conn, StringBuilder newSql, String token) throws SQLException {
/* 371 */     int startPos = token.indexOf('\'') + 1;
/* 372 */     int endPos = token.lastIndexOf('\'');
/*     */     
/* 374 */     if ((startPos == -1) || (endPos == -1)) {
/* 375 */       newSql.append(token);
/*     */     }
/*     */     else {
/* 378 */       String argument = token.substring(startPos, endPos);
/*     */       try
/*     */       {
/* 381 */         if ((conn != null) && (!conn.getUseLegacyDatetimeCode())) {
/* 382 */           Timestamp ts = Timestamp.valueOf(argument);
/* 383 */           SimpleDateFormat tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss", Locale.US);
/*     */           
/* 385 */           tsdf.setTimeZone(conn.getServerTimezoneTZ());
/*     */           
/* 387 */           newSql.append(tsdf.format(ts));
/*     */           
/* 389 */           if ((ts.getNanos() > 0) && (conn.versionMeetsMinimum(5, 6, 4))) {
/* 390 */             newSql.append('.');
/* 391 */             newSql.append(TimeUtil.formatNanos(ts.getNanos(), true, true));
/*     */           }
/*     */           
/* 394 */           newSql.append('\'');
/*     */         }
/*     */         else {
/* 397 */           StringTokenizer st = new StringTokenizer(argument, " .-:");
/*     */           try {
/* 399 */             String year4 = st.nextToken();
/* 400 */             String month2 = st.nextToken();
/* 401 */             String day2 = st.nextToken();
/* 402 */             String hour = st.nextToken();
/* 403 */             String minute = st.nextToken();
/* 404 */             String second = st.nextToken();
/*     */             
/* 406 */             boolean serverSupportsFractionalSecond = false;
/* 407 */             String fractionalSecond = "";
/* 408 */             if ((st.hasMoreTokens()) && 
/* 409 */               (conn.versionMeetsMinimum(5, 6, 4))) {
/* 410 */               serverSupportsFractionalSecond = true;
/* 411 */               fractionalSecond = "." + st.nextToken();
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 427 */             if ((conn != null) && (!conn.getUseTimezone()) && (!conn.getUseJDBCCompliantTimezoneShift())) {
/* 428 */               newSql.append("'").append(year4).append("-").append(month2).append("-").append(day2).append(" ").append(hour).append(":").append(minute).append(":").append(second).append(fractionalSecond).append("'");
/*     */             }
/*     */             else {
/*     */               Calendar sessionCalendar;
/*     */               Calendar sessionCalendar;
/* 433 */               if (conn != null) {
/* 434 */                 sessionCalendar = conn.getCalendarInstanceForSessionOrNew();
/*     */               } else {
/* 436 */                 sessionCalendar = new GregorianCalendar();
/* 437 */                 sessionCalendar.setTimeZone(TimeZone.getTimeZone("GMT"));
/*     */               }
/*     */               try
/*     */               {
/* 441 */                 int year4Int = Integer.parseInt(year4);
/* 442 */                 int month2Int = Integer.parseInt(month2);
/* 443 */                 int day2Int = Integer.parseInt(day2);
/* 444 */                 int hourInt = Integer.parseInt(hour);
/* 445 */                 int minuteInt = Integer.parseInt(minute);
/* 446 */                 int secondInt = Integer.parseInt(second);
/*     */                 
/* 448 */                 boolean useGmtMillis = conn.getUseGmtMillisForDatetimes();
/*     */                 
/* 450 */                 Timestamp toBeAdjusted = TimeUtil.fastTimestampCreate(useGmtMillis, useGmtMillis ? Calendar.getInstance(TimeZone.getTimeZone("GMT")) : null, sessionCalendar, year4Int, month2Int, day2Int, hourInt, minuteInt, secondInt, 0);
/*     */                 
/*     */ 
/*     */ 
/* 454 */                 Timestamp inServerTimezone = TimeUtil.changeTimezone(conn, sessionCalendar, null, toBeAdjusted, sessionCalendar.getTimeZone(), conn.getServerTimezoneTZ(), false);
/*     */                 
/*     */ 
/* 457 */                 newSql.append("'");
/*     */                 
/* 459 */                 String timezoneLiteral = inServerTimezone.toString();
/*     */                 
/* 461 */                 int indexOfDot = timezoneLiteral.indexOf(".");
/*     */                 
/* 463 */                 if (indexOfDot != -1) {
/* 464 */                   timezoneLiteral = timezoneLiteral.substring(0, indexOfDot);
/*     */                 }
/*     */                 
/* 467 */                 newSql.append(timezoneLiteral);
/*     */                 
/* 469 */                 if (serverSupportsFractionalSecond) {
/* 470 */                   newSql.append(fractionalSecond);
/*     */                 }
/* 472 */                 newSql.append("'");
/*     */               }
/*     */               catch (NumberFormatException nfe) {
/* 475 */                 throw SQLError.createSQLException("Syntax error in TIMESTAMP escape sequence '" + token + "'.", "S1009", conn.getExceptionInterceptor());
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (NoSuchElementException e) {
/* 480 */             throw SQLError.createSQLException("Syntax error for TIMESTAMP escape sequence '" + argument + "'", "42000", conn.getExceptionInterceptor());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException illegalArgumentException) {
/* 485 */         SQLException sqlEx = SQLError.createSQLException("Syntax error for TIMESTAMP escape sequence '" + argument + "'", "42000", conn.getExceptionInterceptor());
/*     */         
/* 487 */         sqlEx.initCause(illegalArgumentException);
/*     */         
/* 489 */         throw sqlEx;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String processConvertToken(String functionToken, boolean serverSupportsConvertFn, MySQLConnection conn)
/*     */     throws SQLException
/*     */   {
/* 532 */     int firstIndexOfParen = functionToken.indexOf("(");
/*     */     
/* 534 */     if (firstIndexOfParen == -1) {
/* 535 */       throw SQLError.createSQLException("Syntax error while processing {fn convert (... , ...)} token, missing opening parenthesis in token '" + functionToken + "'.", "42000", conn.getExceptionInterceptor());
/*     */     }
/*     */     
/*     */ 
/* 539 */     int indexOfComma = functionToken.lastIndexOf(",");
/*     */     
/* 541 */     if (indexOfComma == -1) {
/* 542 */       throw SQLError.createSQLException("Syntax error while processing {fn convert (... , ...)} token, missing comma in token '" + functionToken + "'.", "42000", conn.getExceptionInterceptor());
/*     */     }
/*     */     
/*     */ 
/* 546 */     int indexOfCloseParen = functionToken.indexOf(')', indexOfComma);
/*     */     
/* 548 */     if (indexOfCloseParen == -1) {
/* 549 */       throw SQLError.createSQLException("Syntax error while processing {fn convert (... , ...)} token, missing closing parenthesis in token '" + functionToken + "'.", "42000", conn.getExceptionInterceptor());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 554 */     String expression = functionToken.substring(firstIndexOfParen + 1, indexOfComma);
/* 555 */     String type = functionToken.substring(indexOfComma + 1, indexOfCloseParen);
/*     */     
/* 557 */     String newType = null;
/*     */     
/* 559 */     String trimmedType = type.trim();
/*     */     
/* 561 */     if (StringUtils.startsWithIgnoreCase(trimmedType, "SQL_")) {
/* 562 */       trimmedType = trimmedType.substring(4, trimmedType.length());
/*     */     }
/*     */     
/* 565 */     if (serverSupportsConvertFn) {
/* 566 */       newType = (String)JDBC_CONVERT_TO_MYSQL_TYPE_MAP.get(trimmedType.toUpperCase(Locale.ENGLISH));
/*     */     } else {
/* 568 */       newType = (String)JDBC_NO_CONVERT_TO_MYSQL_EXPRESSION_MAP.get(trimmedType.toUpperCase(Locale.ENGLISH));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 573 */       if (newType == null) {
/* 574 */         throw SQLError.createSQLException("Can't find conversion re-write for type '" + type + "' that is applicable for this server version while processing escape tokens.", "S1000", conn.getExceptionInterceptor());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 580 */     if (newType == null) {
/* 581 */       throw SQLError.createSQLException("Unsupported conversion type '" + type.trim() + "' found while processing escape token.", "S1000", conn.getExceptionInterceptor());
/*     */     }
/*     */     
/*     */ 
/* 585 */     int replaceIndex = newType.indexOf("?");
/*     */     
/* 587 */     if (replaceIndex != -1) {
/* 588 */       StringBuilder convertRewrite = new StringBuilder(newType.substring(0, replaceIndex));
/* 589 */       convertRewrite.append(expression);
/* 590 */       convertRewrite.append(newType.substring(replaceIndex + 1, newType.length()));
/*     */       
/* 592 */       return convertRewrite.toString();
/*     */     }
/*     */     
/* 595 */     StringBuilder castRewrite = new StringBuilder("CAST(");
/* 596 */     castRewrite.append(expression);
/* 597 */     castRewrite.append(" AS ");
/* 598 */     castRewrite.append(newType);
/* 599 */     castRewrite.append(")");
/*     */     
/* 601 */     return castRewrite.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String removeWhitespace(String toCollapse)
/*     */   {
/* 615 */     if (toCollapse == null) {
/* 616 */       return null;
/*     */     }
/*     */     
/* 619 */     int length = toCollapse.length();
/*     */     
/* 621 */     StringBuilder collapsed = new StringBuilder(length);
/*     */     
/* 623 */     for (int i = 0; i < length; i++) {
/* 624 */       char c = toCollapse.charAt(i);
/*     */       
/* 626 */       if (!Character.isWhitespace(c)) {
/* 627 */         collapsed.append(c);
/*     */       }
/*     */     }
/*     */     
/* 631 */     return collapsed.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/EscapeProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */