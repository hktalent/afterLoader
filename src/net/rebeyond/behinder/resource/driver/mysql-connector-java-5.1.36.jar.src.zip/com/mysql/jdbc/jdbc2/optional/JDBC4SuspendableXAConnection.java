/*    */ package com.mysql.jdbc.jdbc2.optional;
/*    */ 
/*    */ import com.mysql.jdbc.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.sql.StatementEvent;
/*    */ import javax.sql.StatementEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JDBC4SuspendableXAConnection
/*    */   extends SuspendableXAConnection
/*    */ {
/* 39 */   private final Map<StatementEventListener, StatementEventListener> statementEventListeners = new HashMap();
/*    */   
/*    */   public JDBC4SuspendableXAConnection(Connection connection) throws SQLException {
/* 42 */     super(connection);
/*    */   }
/*    */   
/*    */   public synchronized void close() throws SQLException {
/* 46 */     super.close();
/*    */     
/* 48 */     this.statementEventListeners.clear();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addStatementEventListener(StatementEventListener listener)
/*    */   {
/* 63 */     synchronized (this.statementEventListeners) {
/* 64 */       this.statementEventListeners.put(listener, listener);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void removeStatementEventListener(StatementEventListener listener)
/*    */   {
/* 78 */     synchronized (this.statementEventListeners) {
/* 79 */       this.statementEventListeners.remove(listener);
/*    */     }
/*    */   }
/*    */   
/*    */   void fireStatementEvent(StatementEvent event) throws SQLException {
/* 84 */     synchronized (this.statementEventListeners) {
/* 85 */       for (StatementEventListener listener : this.statementEventListeners.keySet()) {
/* 86 */         listener.statementClosed(event);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/jdbc2/optional/JDBC4SuspendableXAConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */