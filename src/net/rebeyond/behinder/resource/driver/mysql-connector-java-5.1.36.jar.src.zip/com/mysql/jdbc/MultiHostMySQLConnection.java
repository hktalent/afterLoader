/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.util.Calendar;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MultiHostMySQLConnection
/*      */   implements MySQLConnection
/*      */ {
/*      */   protected MultiHostConnectionProxy proxy;
/*      */   
/*      */   public MultiHostMySQLConnection(MultiHostConnectionProxy proxy)
/*      */   {
/*   49 */     this.proxy = proxy;
/*      */   }
/*      */   
/*      */   public MultiHostConnectionProxy getProxy() {
/*   53 */     return this.proxy;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected MySQLConnection getActiveMySQLConnection()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 2	com/mysql/jdbc/MultiHostMySQLConnection:proxy	Lcom/mysql/jdbc/MultiHostConnectionProxy;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 2	com/mysql/jdbc/MultiHostMySQLConnection:proxy	Lcom/mysql/jdbc/MultiHostConnectionProxy;
/*      */     //   11: getfield 3	com/mysql/jdbc/MultiHostConnectionProxy:currentConnection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   14: aload_1
/*      */     //   15: monitorexit
/*      */     //   16: areturn
/*      */     //   17: astore_2
/*      */     //   18: aload_1
/*      */     //   19: monitorexit
/*      */     //   20: aload_2
/*      */     //   21: athrow
/*      */     // Line number table:
/*      */     //   Java source line #57	-> byte code offset #0
/*      */     //   Java source line #58	-> byte code offset #7
/*      */     //   Java source line #59	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	22	0	this	MultiHostMySQLConnection
/*      */     //   5	14	1	Ljava/lang/Object;	Object
/*      */     //   17	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	16	17	finally
/*      */     //   17	20	17	finally
/*      */   }
/*      */   
/*      */   public void abortInternal()
/*      */     throws SQLException
/*      */   {
/*   63 */     getActiveMySQLConnection().abortInternal();
/*      */   }
/*      */   
/*      */   public void changeUser(String userName, String newPassword) throws SQLException {
/*   67 */     getActiveMySQLConnection().changeUser(userName, newPassword);
/*      */   }
/*      */   
/*      */   public void checkClosed() throws SQLException {
/*   71 */     getActiveMySQLConnection().checkClosed();
/*      */   }
/*      */   
/*      */   public void clearHasTriedMaster() {
/*   75 */     getActiveMySQLConnection().clearHasTriedMaster();
/*      */   }
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*   79 */     getActiveMySQLConnection().clearWarnings();
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*   83 */     return getActiveMySQLConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*   87 */     return getActiveMySQLConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*   91 */     return getActiveMySQLConnection().clientPrepareStatement(sql, autoGenKeyIndex);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*   95 */     return getActiveMySQLConnection().clientPrepareStatement(sql, autoGenKeyIndexes);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*   99 */     return getActiveMySQLConnection().clientPrepareStatement(sql, autoGenKeyColNames);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*  103 */     return getActiveMySQLConnection().clientPrepareStatement(sql);
/*      */   }
/*      */   
/*      */   public void close() throws SQLException {
/*  107 */     getActiveMySQLConnection().close();
/*      */   }
/*      */   
/*      */   public void commit() throws SQLException {
/*  111 */     getActiveMySQLConnection().commit();
/*      */   }
/*      */   
/*      */   public void createNewIO(boolean isForReconnect) throws SQLException {
/*  115 */     getActiveMySQLConnection().createNewIO(isForReconnect);
/*      */   }
/*      */   
/*      */   public java.sql.Statement createStatement() throws SQLException {
/*  119 */     return getActiveMySQLConnection().createStatement();
/*      */   }
/*      */   
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  123 */     return getActiveMySQLConnection().createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/*  127 */     return getActiveMySQLConnection().createStatement(resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public void dumpTestcaseQuery(String query) {
/*  131 */     getActiveMySQLConnection().dumpTestcaseQuery(query);
/*      */   }
/*      */   
/*      */   public Connection duplicate() throws SQLException {
/*  135 */     return getActiveMySQLConnection().duplicate();
/*      */   }
/*      */   
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata, boolean isBatch) throws SQLException
/*      */   {
/*  140 */     return getActiveMySQLConnection().execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata, isBatch);
/*      */   }
/*      */   
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata)
/*      */     throws SQLException
/*      */   {
/*  146 */     return getActiveMySQLConnection().execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);
/*      */   }
/*      */   
/*      */   public String extractSqlFromPacket(String possibleSqlQuery, Buffer queryPacket, int endOfQueryPacketPosition) throws SQLException
/*      */   {
/*  151 */     return getActiveMySQLConnection().extractSqlFromPacket(possibleSqlQuery, queryPacket, endOfQueryPacketPosition);
/*      */   }
/*      */   
/*      */   public String exposeAsXml() throws SQLException {
/*  155 */     return getActiveMySQLConnection().exposeAsXml();
/*      */   }
/*      */   
/*      */   public boolean getAllowLoadLocalInfile() {
/*  159 */     return getActiveMySQLConnection().getAllowLoadLocalInfile();
/*      */   }
/*      */   
/*      */   public boolean getAllowMultiQueries() {
/*  163 */     return getActiveMySQLConnection().getAllowMultiQueries();
/*      */   }
/*      */   
/*      */   public boolean getAllowNanAndInf() {
/*  167 */     return getActiveMySQLConnection().getAllowNanAndInf();
/*      */   }
/*      */   
/*      */   public boolean getAllowUrlInLocalInfile() {
/*  171 */     return getActiveMySQLConnection().getAllowUrlInLocalInfile();
/*      */   }
/*      */   
/*      */   public boolean getAlwaysSendSetIsolation() {
/*  175 */     return getActiveMySQLConnection().getAlwaysSendSetIsolation();
/*      */   }
/*      */   
/*      */   public boolean getAutoClosePStmtStreams() {
/*  179 */     return getActiveMySQLConnection().getAutoClosePStmtStreams();
/*      */   }
/*      */   
/*      */   public boolean getAutoDeserialize() {
/*  183 */     return getActiveMySQLConnection().getAutoDeserialize();
/*      */   }
/*      */   
/*      */   public boolean getAutoGenerateTestcaseScript() {
/*  187 */     return getActiveMySQLConnection().getAutoGenerateTestcaseScript();
/*      */   }
/*      */   
/*      */   public boolean getAutoReconnectForPools() {
/*  191 */     return getActiveMySQLConnection().getAutoReconnectForPools();
/*      */   }
/*      */   
/*      */   public boolean getAutoSlowLog() {
/*  195 */     return getActiveMySQLConnection().getAutoSlowLog();
/*      */   }
/*      */   
/*      */   public int getBlobSendChunkSize() {
/*  199 */     return getActiveMySQLConnection().getBlobSendChunkSize();
/*      */   }
/*      */   
/*      */   public boolean getBlobsAreStrings() {
/*  203 */     return getActiveMySQLConnection().getBlobsAreStrings();
/*      */   }
/*      */   
/*      */   public boolean getCacheCallableStatements() {
/*  207 */     return getActiveMySQLConnection().getCacheCallableStatements();
/*      */   }
/*      */   
/*      */   public boolean getCacheCallableStmts() {
/*  211 */     return getActiveMySQLConnection().getCacheCallableStmts();
/*      */   }
/*      */   
/*      */   public boolean getCachePrepStmts() {
/*  215 */     return getActiveMySQLConnection().getCachePrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getCachePreparedStatements() {
/*  219 */     return getActiveMySQLConnection().getCachePreparedStatements();
/*      */   }
/*      */   
/*      */   public boolean getCacheResultSetMetadata() {
/*  223 */     return getActiveMySQLConnection().getCacheResultSetMetadata();
/*      */   }
/*      */   
/*      */   public boolean getCacheServerConfiguration() {
/*  227 */     return getActiveMySQLConnection().getCacheServerConfiguration();
/*      */   }
/*      */   
/*      */   public int getCallableStatementCacheSize() {
/*  231 */     return getActiveMySQLConnection().getCallableStatementCacheSize();
/*      */   }
/*      */   
/*      */   public int getCallableStmtCacheSize() {
/*  235 */     return getActiveMySQLConnection().getCallableStmtCacheSize();
/*      */   }
/*      */   
/*      */   public boolean getCapitalizeTypeNames() {
/*  239 */     return getActiveMySQLConnection().getCapitalizeTypeNames();
/*      */   }
/*      */   
/*      */   public String getCharacterSetResults() {
/*  243 */     return getActiveMySQLConnection().getCharacterSetResults();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStorePassword() {
/*  247 */     return getActiveMySQLConnection().getClientCertificateKeyStorePassword();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStoreType() {
/*  251 */     return getActiveMySQLConnection().getClientCertificateKeyStoreType();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStoreUrl() {
/*  255 */     return getActiveMySQLConnection().getClientCertificateKeyStoreUrl();
/*      */   }
/*      */   
/*      */   public String getClientInfoProvider() {
/*  259 */     return getActiveMySQLConnection().getClientInfoProvider();
/*      */   }
/*      */   
/*      */   public String getClobCharacterEncoding() {
/*  263 */     return getActiveMySQLConnection().getClobCharacterEncoding();
/*      */   }
/*      */   
/*      */   public boolean getClobberStreamingResults() {
/*  267 */     return getActiveMySQLConnection().getClobberStreamingResults();
/*      */   }
/*      */   
/*      */   public boolean getCompensateOnDuplicateKeyUpdateCounts() {
/*  271 */     return getActiveMySQLConnection().getCompensateOnDuplicateKeyUpdateCounts();
/*      */   }
/*      */   
/*      */   public int getConnectTimeout() {
/*  275 */     return getActiveMySQLConnection().getConnectTimeout();
/*      */   }
/*      */   
/*      */   public String getConnectionCollation() {
/*  279 */     return getActiveMySQLConnection().getConnectionCollation();
/*      */   }
/*      */   
/*      */   public String getConnectionLifecycleInterceptors() {
/*  283 */     return getActiveMySQLConnection().getConnectionLifecycleInterceptors();
/*      */   }
/*      */   
/*      */   public boolean getContinueBatchOnError() {
/*  287 */     return getActiveMySQLConnection().getContinueBatchOnError();
/*      */   }
/*      */   
/*      */   public boolean getCreateDatabaseIfNotExist() {
/*  291 */     return getActiveMySQLConnection().getCreateDatabaseIfNotExist();
/*      */   }
/*      */   
/*      */   public int getDefaultFetchSize() {
/*  295 */     return getActiveMySQLConnection().getDefaultFetchSize();
/*      */   }
/*      */   
/*      */   public boolean getDontTrackOpenResources() {
/*  299 */     return getActiveMySQLConnection().getDontTrackOpenResources();
/*      */   }
/*      */   
/*      */   public boolean getDumpMetadataOnColumnNotFound() {
/*  303 */     return getActiveMySQLConnection().getDumpMetadataOnColumnNotFound();
/*      */   }
/*      */   
/*      */   public boolean getDumpQueriesOnException() {
/*  307 */     return getActiveMySQLConnection().getDumpQueriesOnException();
/*      */   }
/*      */   
/*      */   public boolean getDynamicCalendars() {
/*  311 */     return getActiveMySQLConnection().getDynamicCalendars();
/*      */   }
/*      */   
/*      */   public boolean getElideSetAutoCommits() {
/*  315 */     return getActiveMySQLConnection().getElideSetAutoCommits();
/*      */   }
/*      */   
/*      */   public boolean getEmptyStringsConvertToZero() {
/*  319 */     return getActiveMySQLConnection().getEmptyStringsConvertToZero();
/*      */   }
/*      */   
/*      */   public boolean getEmulateLocators() {
/*  323 */     return getActiveMySQLConnection().getEmulateLocators();
/*      */   }
/*      */   
/*      */   public boolean getEmulateUnsupportedPstmts() {
/*  327 */     return getActiveMySQLConnection().getEmulateUnsupportedPstmts();
/*      */   }
/*      */   
/*      */   public boolean getEnablePacketDebug() {
/*  331 */     return getActiveMySQLConnection().getEnablePacketDebug();
/*      */   }
/*      */   
/*      */   public boolean getEnableQueryTimeouts() {
/*  335 */     return getActiveMySQLConnection().getEnableQueryTimeouts();
/*      */   }
/*      */   
/*      */   public String getEncoding() {
/*  339 */     return getActiveMySQLConnection().getEncoding();
/*      */   }
/*      */   
/*      */   public String getExceptionInterceptors() {
/*  343 */     return getActiveMySQLConnection().getExceptionInterceptors();
/*      */   }
/*      */   
/*      */   public boolean getExplainSlowQueries() {
/*  347 */     return getActiveMySQLConnection().getExplainSlowQueries();
/*      */   }
/*      */   
/*      */   public boolean getFailOverReadOnly() {
/*  351 */     return getActiveMySQLConnection().getFailOverReadOnly();
/*      */   }
/*      */   
/*      */   public boolean getFunctionsNeverReturnBlobs() {
/*  355 */     return getActiveMySQLConnection().getFunctionsNeverReturnBlobs();
/*      */   }
/*      */   
/*      */   public boolean getGatherPerfMetrics() {
/*  359 */     return getActiveMySQLConnection().getGatherPerfMetrics();
/*      */   }
/*      */   
/*      */   public boolean getGatherPerformanceMetrics() {
/*  363 */     return getActiveMySQLConnection().getGatherPerformanceMetrics();
/*      */   }
/*      */   
/*      */   public boolean getGenerateSimpleParameterMetadata() {
/*  367 */     return getActiveMySQLConnection().getGenerateSimpleParameterMetadata();
/*      */   }
/*      */   
/*      */   public boolean getIgnoreNonTxTables() {
/*  371 */     return getActiveMySQLConnection().getIgnoreNonTxTables();
/*      */   }
/*      */   
/*      */   public boolean getIncludeInnodbStatusInDeadlockExceptions() {
/*  375 */     return getActiveMySQLConnection().getIncludeInnodbStatusInDeadlockExceptions();
/*      */   }
/*      */   
/*      */   public int getInitialTimeout() {
/*  379 */     return getActiveMySQLConnection().getInitialTimeout();
/*      */   }
/*      */   
/*      */   public boolean getInteractiveClient() {
/*  383 */     return getActiveMySQLConnection().getInteractiveClient();
/*      */   }
/*      */   
/*      */   public boolean getIsInteractiveClient() {
/*  387 */     return getActiveMySQLConnection().getIsInteractiveClient();
/*      */   }
/*      */   
/*      */   public boolean getJdbcCompliantTruncation() {
/*  391 */     return getActiveMySQLConnection().getJdbcCompliantTruncation();
/*      */   }
/*      */   
/*      */   public boolean getJdbcCompliantTruncationForReads() {
/*  395 */     return getActiveMySQLConnection().getJdbcCompliantTruncationForReads();
/*      */   }
/*      */   
/*      */   public String getLargeRowSizeThreshold() {
/*  399 */     return getActiveMySQLConnection().getLargeRowSizeThreshold();
/*      */   }
/*      */   
/*      */   public int getLoadBalanceBlacklistTimeout() {
/*  403 */     return getActiveMySQLConnection().getLoadBalanceBlacklistTimeout();
/*      */   }
/*      */   
/*      */   public int getLoadBalancePingTimeout() {
/*  407 */     return getActiveMySQLConnection().getLoadBalancePingTimeout();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceStrategy() {
/*  411 */     return getActiveMySQLConnection().getLoadBalanceStrategy();
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceValidateConnectionOnSwapServer() {
/*  415 */     return getActiveMySQLConnection().getLoadBalanceValidateConnectionOnSwapServer();
/*      */   }
/*      */   
/*      */   public String getLocalSocketAddress() {
/*  419 */     return getActiveMySQLConnection().getLocalSocketAddress();
/*      */   }
/*      */   
/*      */   public int getLocatorFetchBufferSize() {
/*  423 */     return getActiveMySQLConnection().getLocatorFetchBufferSize();
/*      */   }
/*      */   
/*      */   public boolean getLogSlowQueries() {
/*  427 */     return getActiveMySQLConnection().getLogSlowQueries();
/*      */   }
/*      */   
/*      */   public boolean getLogXaCommands() {
/*  431 */     return getActiveMySQLConnection().getLogXaCommands();
/*      */   }
/*      */   
/*      */   public String getLogger() {
/*  435 */     return getActiveMySQLConnection().getLogger();
/*      */   }
/*      */   
/*      */   public String getLoggerClassName() {
/*  439 */     return getActiveMySQLConnection().getLoggerClassName();
/*      */   }
/*      */   
/*      */   public boolean getMaintainTimeStats() {
/*  443 */     return getActiveMySQLConnection().getMaintainTimeStats();
/*      */   }
/*      */   
/*      */   public int getMaxAllowedPacket() {
/*  447 */     return getActiveMySQLConnection().getMaxAllowedPacket();
/*      */   }
/*      */   
/*      */   public int getMaxQuerySizeToLog() {
/*  451 */     return getActiveMySQLConnection().getMaxQuerySizeToLog();
/*      */   }
/*      */   
/*      */   public int getMaxReconnects() {
/*  455 */     return getActiveMySQLConnection().getMaxReconnects();
/*      */   }
/*      */   
/*      */   public int getMaxRows() {
/*  459 */     return getActiveMySQLConnection().getMaxRows();
/*      */   }
/*      */   
/*      */   public int getMetadataCacheSize() {
/*  463 */     return getActiveMySQLConnection().getMetadataCacheSize();
/*      */   }
/*      */   
/*      */   public int getNetTimeoutForStreamingResults() {
/*  467 */     return getActiveMySQLConnection().getNetTimeoutForStreamingResults();
/*      */   }
/*      */   
/*      */   public boolean getNoAccessToProcedureBodies() {
/*  471 */     return getActiveMySQLConnection().getNoAccessToProcedureBodies();
/*      */   }
/*      */   
/*      */   public boolean getNoDatetimeStringSync() {
/*  475 */     return getActiveMySQLConnection().getNoDatetimeStringSync();
/*      */   }
/*      */   
/*      */   public boolean getNoTimezoneConversionForTimeType() {
/*  479 */     return getActiveMySQLConnection().getNoTimezoneConversionForTimeType();
/*      */   }
/*      */   
/*      */   public boolean getNoTimezoneConversionForDateType() {
/*  483 */     return getActiveMySQLConnection().getNoTimezoneConversionForDateType();
/*      */   }
/*      */   
/*      */   public boolean getCacheDefaultTimezone() {
/*  487 */     return getActiveMySQLConnection().getCacheDefaultTimezone();
/*      */   }
/*      */   
/*      */   public boolean getNullCatalogMeansCurrent() {
/*  491 */     return getActiveMySQLConnection().getNullCatalogMeansCurrent();
/*      */   }
/*      */   
/*      */   public boolean getNullNamePatternMatchesAll() {
/*  495 */     return getActiveMySQLConnection().getNullNamePatternMatchesAll();
/*      */   }
/*      */   
/*      */   public boolean getOverrideSupportsIntegrityEnhancementFacility() {
/*  499 */     return getActiveMySQLConnection().getOverrideSupportsIntegrityEnhancementFacility();
/*      */   }
/*      */   
/*      */   public int getPacketDebugBufferSize() {
/*  503 */     return getActiveMySQLConnection().getPacketDebugBufferSize();
/*      */   }
/*      */   
/*      */   public boolean getPadCharsWithSpace() {
/*  507 */     return getActiveMySQLConnection().getPadCharsWithSpace();
/*      */   }
/*      */   
/*      */   public boolean getParanoid() {
/*  511 */     return getActiveMySQLConnection().getParanoid();
/*      */   }
/*      */   
/*      */   public String getPasswordCharacterEncoding() {
/*  515 */     return getActiveMySQLConnection().getPasswordCharacterEncoding();
/*      */   }
/*      */   
/*      */   public boolean getPedantic() {
/*  519 */     return getActiveMySQLConnection().getPedantic();
/*      */   }
/*      */   
/*      */   public boolean getPinGlobalTxToPhysicalConnection() {
/*  523 */     return getActiveMySQLConnection().getPinGlobalTxToPhysicalConnection();
/*      */   }
/*      */   
/*      */   public boolean getPopulateInsertRowWithDefaultValues() {
/*  527 */     return getActiveMySQLConnection().getPopulateInsertRowWithDefaultValues();
/*      */   }
/*      */   
/*      */   public int getPrepStmtCacheSize() {
/*  531 */     return getActiveMySQLConnection().getPrepStmtCacheSize();
/*      */   }
/*      */   
/*      */   public int getPrepStmtCacheSqlLimit() {
/*  535 */     return getActiveMySQLConnection().getPrepStmtCacheSqlLimit();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSize() {
/*  539 */     return getActiveMySQLConnection().getPreparedStatementCacheSize();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSqlLimit() {
/*  543 */     return getActiveMySQLConnection().getPreparedStatementCacheSqlLimit();
/*      */   }
/*      */   
/*      */   public boolean getProcessEscapeCodesForPrepStmts() {
/*  547 */     return getActiveMySQLConnection().getProcessEscapeCodesForPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getProfileSQL() {
/*  551 */     return getActiveMySQLConnection().getProfileSQL();
/*      */   }
/*      */   
/*      */   public boolean getProfileSql() {
/*  555 */     return getActiveMySQLConnection().getProfileSql();
/*      */   }
/*      */   
/*      */   public String getProfilerEventHandler() {
/*  559 */     return getActiveMySQLConnection().getProfilerEventHandler();
/*      */   }
/*      */   
/*      */   public String getPropertiesTransform() {
/*  563 */     return getActiveMySQLConnection().getPropertiesTransform();
/*      */   }
/*      */   
/*      */   public int getQueriesBeforeRetryMaster() {
/*  567 */     return getActiveMySQLConnection().getQueriesBeforeRetryMaster();
/*      */   }
/*      */   
/*      */   public boolean getQueryTimeoutKillsConnection() {
/*  571 */     return getActiveMySQLConnection().getQueryTimeoutKillsConnection();
/*      */   }
/*      */   
/*      */   public boolean getReconnectAtTxEnd() {
/*  575 */     return getActiveMySQLConnection().getReconnectAtTxEnd();
/*      */   }
/*      */   
/*      */   public boolean getRelaxAutoCommit() {
/*  579 */     return getActiveMySQLConnection().getRelaxAutoCommit();
/*      */   }
/*      */   
/*      */   public int getReportMetricsIntervalMillis() {
/*  583 */     return getActiveMySQLConnection().getReportMetricsIntervalMillis();
/*      */   }
/*      */   
/*      */   public boolean getRequireSSL() {
/*  587 */     return getActiveMySQLConnection().getRequireSSL();
/*      */   }
/*      */   
/*      */   public String getResourceId() {
/*  591 */     return getActiveMySQLConnection().getResourceId();
/*      */   }
/*      */   
/*      */   public int getResultSetSizeThreshold() {
/*  595 */     return getActiveMySQLConnection().getResultSetSizeThreshold();
/*      */   }
/*      */   
/*      */   public boolean getRetainStatementAfterResultSetClose() {
/*  599 */     return getActiveMySQLConnection().getRetainStatementAfterResultSetClose();
/*      */   }
/*      */   
/*      */   public int getRetriesAllDown() {
/*  603 */     return getActiveMySQLConnection().getRetriesAllDown();
/*      */   }
/*      */   
/*      */   public boolean getRewriteBatchedStatements() {
/*  607 */     return getActiveMySQLConnection().getRewriteBatchedStatements();
/*      */   }
/*      */   
/*      */   public boolean getRollbackOnPooledClose() {
/*  611 */     return getActiveMySQLConnection().getRollbackOnPooledClose();
/*      */   }
/*      */   
/*      */   public boolean getRoundRobinLoadBalance() {
/*  615 */     return getActiveMySQLConnection().getRoundRobinLoadBalance();
/*      */   }
/*      */   
/*      */   public boolean getRunningCTS13() {
/*  619 */     return getActiveMySQLConnection().getRunningCTS13();
/*      */   }
/*      */   
/*      */   public int getSecondsBeforeRetryMaster() {
/*  623 */     return getActiveMySQLConnection().getSecondsBeforeRetryMaster();
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingMaxOperations() {
/*  627 */     return getActiveMySQLConnection().getSelfDestructOnPingMaxOperations();
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingSecondsLifetime() {
/*  631 */     return getActiveMySQLConnection().getSelfDestructOnPingSecondsLifetime();
/*      */   }
/*      */   
/*      */   public String getServerTimezone() {
/*  635 */     return getActiveMySQLConnection().getServerTimezone();
/*      */   }
/*      */   
/*      */   public String getSessionVariables() {
/*  639 */     return getActiveMySQLConnection().getSessionVariables();
/*      */   }
/*      */   
/*      */   public int getSlowQueryThresholdMillis() {
/*  643 */     return getActiveMySQLConnection().getSlowQueryThresholdMillis();
/*      */   }
/*      */   
/*      */   public long getSlowQueryThresholdNanos() {
/*  647 */     return getActiveMySQLConnection().getSlowQueryThresholdNanos();
/*      */   }
/*      */   
/*      */   public String getSocketFactory() {
/*  651 */     return getActiveMySQLConnection().getSocketFactory();
/*      */   }
/*      */   
/*      */   public String getSocketFactoryClassName() {
/*  655 */     return getActiveMySQLConnection().getSocketFactoryClassName();
/*      */   }
/*      */   
/*      */   public int getSocketTimeout() {
/*  659 */     return getActiveMySQLConnection().getSocketTimeout();
/*      */   }
/*      */   
/*      */   public String getStatementInterceptors() {
/*  663 */     return getActiveMySQLConnection().getStatementInterceptors();
/*      */   }
/*      */   
/*      */   public boolean getStrictFloatingPoint() {
/*  667 */     return getActiveMySQLConnection().getStrictFloatingPoint();
/*      */   }
/*      */   
/*      */   public boolean getStrictUpdates() {
/*  671 */     return getActiveMySQLConnection().getStrictUpdates();
/*      */   }
/*      */   
/*      */   public boolean getTcpKeepAlive() {
/*  675 */     return getActiveMySQLConnection().getTcpKeepAlive();
/*      */   }
/*      */   
/*      */   public boolean getTcpNoDelay() {
/*  679 */     return getActiveMySQLConnection().getTcpNoDelay();
/*      */   }
/*      */   
/*      */   public int getTcpRcvBuf() {
/*  683 */     return getActiveMySQLConnection().getTcpRcvBuf();
/*      */   }
/*      */   
/*      */   public int getTcpSndBuf() {
/*  687 */     return getActiveMySQLConnection().getTcpSndBuf();
/*      */   }
/*      */   
/*      */   public int getTcpTrafficClass() {
/*  691 */     return getActiveMySQLConnection().getTcpTrafficClass();
/*      */   }
/*      */   
/*      */   public boolean getTinyInt1isBit() {
/*  695 */     return getActiveMySQLConnection().getTinyInt1isBit();
/*      */   }
/*      */   
/*      */   public boolean getTraceProtocol() {
/*  699 */     return getActiveMySQLConnection().getTraceProtocol();
/*      */   }
/*      */   
/*      */   public boolean getTransformedBitIsBoolean() {
/*  703 */     return getActiveMySQLConnection().getTransformedBitIsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getTreatUtilDateAsTimestamp() {
/*  707 */     return getActiveMySQLConnection().getTreatUtilDateAsTimestamp();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStorePassword() {
/*  711 */     return getActiveMySQLConnection().getTrustCertificateKeyStorePassword();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStoreType() {
/*  715 */     return getActiveMySQLConnection().getTrustCertificateKeyStoreType();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStoreUrl() {
/*  719 */     return getActiveMySQLConnection().getTrustCertificateKeyStoreUrl();
/*      */   }
/*      */   
/*      */   public boolean getUltraDevHack() {
/*  723 */     return getActiveMySQLConnection().getUltraDevHack();
/*      */   }
/*      */   
/*      */   public boolean getUseAffectedRows() {
/*  727 */     return getActiveMySQLConnection().getUseAffectedRows();
/*      */   }
/*      */   
/*      */   public boolean getUseBlobToStoreUTF8OutsideBMP() {
/*  731 */     return getActiveMySQLConnection().getUseBlobToStoreUTF8OutsideBMP();
/*      */   }
/*      */   
/*      */   public boolean getUseColumnNamesInFindColumn() {
/*  735 */     return getActiveMySQLConnection().getUseColumnNamesInFindColumn();
/*      */   }
/*      */   
/*      */   public boolean getUseCompression() {
/*  739 */     return getActiveMySQLConnection().getUseCompression();
/*      */   }
/*      */   
/*      */   public String getUseConfigs() {
/*  743 */     return getActiveMySQLConnection().getUseConfigs();
/*      */   }
/*      */   
/*      */   public boolean getUseCursorFetch() {
/*  747 */     return getActiveMySQLConnection().getUseCursorFetch();
/*      */   }
/*      */   
/*      */   public boolean getUseDirectRowUnpack() {
/*  751 */     return getActiveMySQLConnection().getUseDirectRowUnpack();
/*      */   }
/*      */   
/*      */   public boolean getUseDynamicCharsetInfo() {
/*  755 */     return getActiveMySQLConnection().getUseDynamicCharsetInfo();
/*      */   }
/*      */   
/*      */   public boolean getUseFastDateParsing() {
/*  759 */     return getActiveMySQLConnection().getUseFastDateParsing();
/*      */   }
/*      */   
/*      */   public boolean getUseFastIntParsing() {
/*  763 */     return getActiveMySQLConnection().getUseFastIntParsing();
/*      */   }
/*      */   
/*      */   public boolean getUseGmtMillisForDatetimes() {
/*  767 */     return getActiveMySQLConnection().getUseGmtMillisForDatetimes();
/*      */   }
/*      */   
/*      */   public boolean getUseHostsInPrivileges() {
/*  771 */     return getActiveMySQLConnection().getUseHostsInPrivileges();
/*      */   }
/*      */   
/*      */   public boolean getUseInformationSchema() {
/*  775 */     return getActiveMySQLConnection().getUseInformationSchema();
/*      */   }
/*      */   
/*      */   public boolean getUseJDBCCompliantTimezoneShift() {
/*  779 */     return getActiveMySQLConnection().getUseJDBCCompliantTimezoneShift();
/*      */   }
/*      */   
/*      */   public boolean getUseJvmCharsetConverters() {
/*  783 */     return getActiveMySQLConnection().getUseJvmCharsetConverters();
/*      */   }
/*      */   
/*      */   public boolean getUseLegacyDatetimeCode() {
/*  787 */     return getActiveMySQLConnection().getUseLegacyDatetimeCode();
/*      */   }
/*      */   
/*      */   public boolean getUseLocalSessionState() {
/*  791 */     return getActiveMySQLConnection().getUseLocalSessionState();
/*      */   }
/*      */   
/*      */   public boolean getUseLocalTransactionState() {
/*  795 */     return getActiveMySQLConnection().getUseLocalTransactionState();
/*      */   }
/*      */   
/*      */   public boolean getUseNanosForElapsedTime() {
/*  799 */     return getActiveMySQLConnection().getUseNanosForElapsedTime();
/*      */   }
/*      */   
/*      */   public boolean getUseOldAliasMetadataBehavior() {
/*  803 */     return getActiveMySQLConnection().getUseOldAliasMetadataBehavior();
/*      */   }
/*      */   
/*      */   public boolean getUseOldUTF8Behavior() {
/*  807 */     return getActiveMySQLConnection().getUseOldUTF8Behavior();
/*      */   }
/*      */   
/*      */   public boolean getUseOnlyServerErrorMessages() {
/*  811 */     return getActiveMySQLConnection().getUseOnlyServerErrorMessages();
/*      */   }
/*      */   
/*      */   public boolean getUseReadAheadInput() {
/*  815 */     return getActiveMySQLConnection().getUseReadAheadInput();
/*      */   }
/*      */   
/*      */   public boolean getUseSSL() {
/*  819 */     return getActiveMySQLConnection().getUseSSL();
/*      */   }
/*      */   
/*      */   public boolean getUseSSPSCompatibleTimezoneShift() {
/*  823 */     return getActiveMySQLConnection().getUseSSPSCompatibleTimezoneShift();
/*      */   }
/*      */   
/*      */   public boolean getUseServerPrepStmts() {
/*  827 */     return getActiveMySQLConnection().getUseServerPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseServerPreparedStmts() {
/*  831 */     return getActiveMySQLConnection().getUseServerPreparedStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseSqlStateCodes() {
/*  835 */     return getActiveMySQLConnection().getUseSqlStateCodes();
/*      */   }
/*      */   
/*      */   public boolean getUseStreamLengthsInPrepStmts() {
/*  839 */     return getActiveMySQLConnection().getUseStreamLengthsInPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseTimezone() {
/*  843 */     return getActiveMySQLConnection().getUseTimezone();
/*      */   }
/*      */   
/*      */   public boolean getUseUltraDevWorkAround() {
/*  847 */     return getActiveMySQLConnection().getUseUltraDevWorkAround();
/*      */   }
/*      */   
/*      */   public boolean getUseUnbufferedInput() {
/*  851 */     return getActiveMySQLConnection().getUseUnbufferedInput();
/*      */   }
/*      */   
/*      */   public boolean getUseUnicode() {
/*  855 */     return getActiveMySQLConnection().getUseUnicode();
/*      */   }
/*      */   
/*      */   public boolean getUseUsageAdvisor() {
/*  859 */     return getActiveMySQLConnection().getUseUsageAdvisor();
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpExcludedColumnNamePattern() {
/*  863 */     return getActiveMySQLConnection().getUtf8OutsideBmpExcludedColumnNamePattern();
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpIncludedColumnNamePattern() {
/*  867 */     return getActiveMySQLConnection().getUtf8OutsideBmpIncludedColumnNamePattern();
/*      */   }
/*      */   
/*      */   public boolean getVerifyServerCertificate() {
/*  871 */     return getActiveMySQLConnection().getVerifyServerCertificate();
/*      */   }
/*      */   
/*      */   public boolean getYearIsDateType() {
/*  875 */     return getActiveMySQLConnection().getYearIsDateType();
/*      */   }
/*      */   
/*      */   public String getZeroDateTimeBehavior() {
/*  879 */     return getActiveMySQLConnection().getZeroDateTimeBehavior();
/*      */   }
/*      */   
/*      */   public void setAllowLoadLocalInfile(boolean property) {
/*  883 */     getActiveMySQLConnection().setAllowLoadLocalInfile(property);
/*      */   }
/*      */   
/*      */   public void setAllowMultiQueries(boolean property) {
/*  887 */     getActiveMySQLConnection().setAllowMultiQueries(property);
/*      */   }
/*      */   
/*      */   public void setAllowNanAndInf(boolean flag) {
/*  891 */     getActiveMySQLConnection().setAllowNanAndInf(flag);
/*      */   }
/*      */   
/*      */   public void setAllowUrlInLocalInfile(boolean flag) {
/*  895 */     getActiveMySQLConnection().setAllowUrlInLocalInfile(flag);
/*      */   }
/*      */   
/*      */   public void setAlwaysSendSetIsolation(boolean flag) {
/*  899 */     getActiveMySQLConnection().setAlwaysSendSetIsolation(flag);
/*      */   }
/*      */   
/*      */   public void setAutoClosePStmtStreams(boolean flag) {
/*  903 */     getActiveMySQLConnection().setAutoClosePStmtStreams(flag);
/*      */   }
/*      */   
/*      */   public void setAutoDeserialize(boolean flag) {
/*  907 */     getActiveMySQLConnection().setAutoDeserialize(flag);
/*      */   }
/*      */   
/*      */   public void setAutoGenerateTestcaseScript(boolean flag) {
/*  911 */     getActiveMySQLConnection().setAutoGenerateTestcaseScript(flag);
/*      */   }
/*      */   
/*      */   public void setAutoReconnect(boolean flag) {
/*  915 */     getActiveMySQLConnection().setAutoReconnect(flag);
/*      */   }
/*      */   
/*      */   public void setAutoReconnectForConnectionPools(boolean property) {
/*  919 */     getActiveMySQLConnection().setAutoReconnectForConnectionPools(property);
/*      */   }
/*      */   
/*      */   public void setAutoReconnectForPools(boolean flag) {
/*  923 */     getActiveMySQLConnection().setAutoReconnectForPools(flag);
/*      */   }
/*      */   
/*      */   public void setAutoSlowLog(boolean flag) {
/*  927 */     getActiveMySQLConnection().setAutoSlowLog(flag);
/*      */   }
/*      */   
/*      */   public void setBlobSendChunkSize(String value) throws SQLException {
/*  931 */     getActiveMySQLConnection().setBlobSendChunkSize(value);
/*      */   }
/*      */   
/*      */   public void setBlobsAreStrings(boolean flag) {
/*  935 */     getActiveMySQLConnection().setBlobsAreStrings(flag);
/*      */   }
/*      */   
/*      */   public void setCacheCallableStatements(boolean flag) {
/*  939 */     getActiveMySQLConnection().setCacheCallableStatements(flag);
/*      */   }
/*      */   
/*      */   public void setCacheCallableStmts(boolean flag) {
/*  943 */     getActiveMySQLConnection().setCacheCallableStmts(flag);
/*      */   }
/*      */   
/*      */   public void setCachePrepStmts(boolean flag) {
/*  947 */     getActiveMySQLConnection().setCachePrepStmts(flag);
/*      */   }
/*      */   
/*      */   public void setCachePreparedStatements(boolean flag) {
/*  951 */     getActiveMySQLConnection().setCachePreparedStatements(flag);
/*      */   }
/*      */   
/*      */   public void setCacheResultSetMetadata(boolean property) {
/*  955 */     getActiveMySQLConnection().setCacheResultSetMetadata(property);
/*      */   }
/*      */   
/*      */   public void setCacheServerConfiguration(boolean flag) {
/*  959 */     getActiveMySQLConnection().setCacheServerConfiguration(flag);
/*      */   }
/*      */   
/*      */   public void setCallableStatementCacheSize(int size) throws SQLException {
/*  963 */     getActiveMySQLConnection().setCallableStatementCacheSize(size);
/*      */   }
/*      */   
/*      */   public void setCallableStmtCacheSize(int cacheSize) throws SQLException {
/*  967 */     getActiveMySQLConnection().setCallableStmtCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */   public void setCapitalizeDBMDTypes(boolean property) {
/*  971 */     getActiveMySQLConnection().setCapitalizeDBMDTypes(property);
/*      */   }
/*      */   
/*      */   public void setCapitalizeTypeNames(boolean flag) {
/*  975 */     getActiveMySQLConnection().setCapitalizeTypeNames(flag);
/*      */   }
/*      */   
/*      */   public void setCharacterEncoding(String encoding) {
/*  979 */     getActiveMySQLConnection().setCharacterEncoding(encoding);
/*      */   }
/*      */   
/*      */   public void setCharacterSetResults(String characterSet) {
/*  983 */     getActiveMySQLConnection().setCharacterSetResults(characterSet);
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStorePassword(String value) {
/*  987 */     getActiveMySQLConnection().setClientCertificateKeyStorePassword(value);
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStoreType(String value) {
/*  991 */     getActiveMySQLConnection().setClientCertificateKeyStoreType(value);
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStoreUrl(String value) {
/*  995 */     getActiveMySQLConnection().setClientCertificateKeyStoreUrl(value);
/*      */   }
/*      */   
/*      */   public void setClientInfoProvider(String classname) {
/*  999 */     getActiveMySQLConnection().setClientInfoProvider(classname);
/*      */   }
/*      */   
/*      */   public void setClobCharacterEncoding(String encoding) {
/* 1003 */     getActiveMySQLConnection().setClobCharacterEncoding(encoding);
/*      */   }
/*      */   
/*      */   public void setClobberStreamingResults(boolean flag) {
/* 1007 */     getActiveMySQLConnection().setClobberStreamingResults(flag);
/*      */   }
/*      */   
/*      */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) {
/* 1011 */     getActiveMySQLConnection().setCompensateOnDuplicateKeyUpdateCounts(flag);
/*      */   }
/*      */   
/*      */   public void setConnectTimeout(int timeoutMs) throws SQLException {
/* 1015 */     getActiveMySQLConnection().setConnectTimeout(timeoutMs);
/*      */   }
/*      */   
/*      */   public void setConnectionCollation(String collation) {
/* 1019 */     getActiveMySQLConnection().setConnectionCollation(collation);
/*      */   }
/*      */   
/*      */   public void setConnectionLifecycleInterceptors(String interceptors) {
/* 1023 */     getActiveMySQLConnection().setConnectionLifecycleInterceptors(interceptors);
/*      */   }
/*      */   
/*      */   public void setContinueBatchOnError(boolean property) {
/* 1027 */     getActiveMySQLConnection().setContinueBatchOnError(property);
/*      */   }
/*      */   
/*      */   public void setCreateDatabaseIfNotExist(boolean flag) {
/* 1031 */     getActiveMySQLConnection().setCreateDatabaseIfNotExist(flag);
/*      */   }
/*      */   
/*      */   public void setDefaultFetchSize(int n) throws SQLException {
/* 1035 */     getActiveMySQLConnection().setDefaultFetchSize(n);
/*      */   }
/*      */   
/*      */   public void setDetectServerPreparedStmts(boolean property) {
/* 1039 */     getActiveMySQLConnection().setDetectServerPreparedStmts(property);
/*      */   }
/*      */   
/*      */   public void setDontTrackOpenResources(boolean flag) {
/* 1043 */     getActiveMySQLConnection().setDontTrackOpenResources(flag);
/*      */   }
/*      */   
/*      */   public void setDumpMetadataOnColumnNotFound(boolean flag) {
/* 1047 */     getActiveMySQLConnection().setDumpMetadataOnColumnNotFound(flag);
/*      */   }
/*      */   
/*      */   public void setDumpQueriesOnException(boolean flag) {
/* 1051 */     getActiveMySQLConnection().setDumpQueriesOnException(flag);
/*      */   }
/*      */   
/*      */   public void setDynamicCalendars(boolean flag) {
/* 1055 */     getActiveMySQLConnection().setDynamicCalendars(flag);
/*      */   }
/*      */   
/*      */   public void setElideSetAutoCommits(boolean flag) {
/* 1059 */     getActiveMySQLConnection().setElideSetAutoCommits(flag);
/*      */   }
/*      */   
/*      */   public void setEmptyStringsConvertToZero(boolean flag) {
/* 1063 */     getActiveMySQLConnection().setEmptyStringsConvertToZero(flag);
/*      */   }
/*      */   
/*      */   public void setEmulateLocators(boolean property) {
/* 1067 */     getActiveMySQLConnection().setEmulateLocators(property);
/*      */   }
/*      */   
/*      */   public void setEmulateUnsupportedPstmts(boolean flag) {
/* 1071 */     getActiveMySQLConnection().setEmulateUnsupportedPstmts(flag);
/*      */   }
/*      */   
/*      */   public void setEnablePacketDebug(boolean flag) {
/* 1075 */     getActiveMySQLConnection().setEnablePacketDebug(flag);
/*      */   }
/*      */   
/*      */   public void setEnableQueryTimeouts(boolean flag) {
/* 1079 */     getActiveMySQLConnection().setEnableQueryTimeouts(flag);
/*      */   }
/*      */   
/*      */   public void setEncoding(String property) {
/* 1083 */     getActiveMySQLConnection().setEncoding(property);
/*      */   }
/*      */   
/*      */   public void setExceptionInterceptors(String exceptionInterceptors) {
/* 1087 */     getActiveMySQLConnection().setExceptionInterceptors(exceptionInterceptors);
/*      */   }
/*      */   
/*      */   public void setExplainSlowQueries(boolean flag) {
/* 1091 */     getActiveMySQLConnection().setExplainSlowQueries(flag);
/*      */   }
/*      */   
/*      */   public void setFailOverReadOnly(boolean flag) {
/* 1095 */     getActiveMySQLConnection().setFailOverReadOnly(flag);
/*      */   }
/*      */   
/*      */   public void setFunctionsNeverReturnBlobs(boolean flag) {
/* 1099 */     getActiveMySQLConnection().setFunctionsNeverReturnBlobs(flag);
/*      */   }
/*      */   
/*      */   public void setGatherPerfMetrics(boolean flag) {
/* 1103 */     getActiveMySQLConnection().setGatherPerfMetrics(flag);
/*      */   }
/*      */   
/*      */   public void setGatherPerformanceMetrics(boolean flag) {
/* 1107 */     getActiveMySQLConnection().setGatherPerformanceMetrics(flag);
/*      */   }
/*      */   
/*      */   public void setGenerateSimpleParameterMetadata(boolean flag) {
/* 1111 */     getActiveMySQLConnection().setGenerateSimpleParameterMetadata(flag);
/*      */   }
/*      */   
/*      */   public void setHoldResultsOpenOverStatementClose(boolean flag) {
/* 1115 */     getActiveMySQLConnection().setHoldResultsOpenOverStatementClose(flag);
/*      */   }
/*      */   
/*      */   public void setIgnoreNonTxTables(boolean property) {
/* 1119 */     getActiveMySQLConnection().setIgnoreNonTxTables(property);
/*      */   }
/*      */   
/*      */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) {
/* 1123 */     getActiveMySQLConnection().setIncludeInnodbStatusInDeadlockExceptions(flag);
/*      */   }
/*      */   
/*      */   public void setInitialTimeout(int property) throws SQLException {
/* 1127 */     getActiveMySQLConnection().setInitialTimeout(property);
/*      */   }
/*      */   
/*      */   public void setInteractiveClient(boolean property) {
/* 1131 */     getActiveMySQLConnection().setInteractiveClient(property);
/*      */   }
/*      */   
/*      */   public void setIsInteractiveClient(boolean property) {
/* 1135 */     getActiveMySQLConnection().setIsInteractiveClient(property);
/*      */   }
/*      */   
/*      */   public void setJdbcCompliantTruncation(boolean flag) {
/* 1139 */     getActiveMySQLConnection().setJdbcCompliantTruncation(flag);
/*      */   }
/*      */   
/*      */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads) {
/* 1143 */     getActiveMySQLConnection().setJdbcCompliantTruncationForReads(jdbcCompliantTruncationForReads);
/*      */   }
/*      */   
/*      */   public void setLargeRowSizeThreshold(String value) throws SQLException {
/* 1147 */     getActiveMySQLConnection().setLargeRowSizeThreshold(value);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) throws SQLException {
/* 1151 */     getActiveMySQLConnection().setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout);
/*      */   }
/*      */   
/*      */   public void setLoadBalancePingTimeout(int loadBalancePingTimeout) throws SQLException {
/* 1155 */     getActiveMySQLConnection().setLoadBalancePingTimeout(loadBalancePingTimeout);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceStrategy(String strategy) {
/* 1159 */     getActiveMySQLConnection().setLoadBalanceStrategy(strategy);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceValidateConnectionOnSwapServer(boolean loadBalanceValidateConnectionOnSwapServer) {
/* 1163 */     getActiveMySQLConnection().setLoadBalanceValidateConnectionOnSwapServer(loadBalanceValidateConnectionOnSwapServer);
/*      */   }
/*      */   
/*      */   public void setLocalSocketAddress(String address) {
/* 1167 */     getActiveMySQLConnection().setLocalSocketAddress(address);
/*      */   }
/*      */   
/*      */   public void setLocatorFetchBufferSize(String value) throws SQLException {
/* 1171 */     getActiveMySQLConnection().setLocatorFetchBufferSize(value);
/*      */   }
/*      */   
/*      */   public void setLogSlowQueries(boolean flag) {
/* 1175 */     getActiveMySQLConnection().setLogSlowQueries(flag);
/*      */   }
/*      */   
/*      */   public void setLogXaCommands(boolean flag) {
/* 1179 */     getActiveMySQLConnection().setLogXaCommands(flag);
/*      */   }
/*      */   
/*      */   public void setLogger(String property) {
/* 1183 */     getActiveMySQLConnection().setLogger(property);
/*      */   }
/*      */   
/*      */   public void setLoggerClassName(String className) {
/* 1187 */     getActiveMySQLConnection().setLoggerClassName(className);
/*      */   }
/*      */   
/*      */   public void setMaintainTimeStats(boolean flag) {
/* 1191 */     getActiveMySQLConnection().setMaintainTimeStats(flag);
/*      */   }
/*      */   
/*      */   public void setMaxQuerySizeToLog(int sizeInBytes) throws SQLException {
/* 1195 */     getActiveMySQLConnection().setMaxQuerySizeToLog(sizeInBytes);
/*      */   }
/*      */   
/*      */   public void setMaxReconnects(int property) throws SQLException {
/* 1199 */     getActiveMySQLConnection().setMaxReconnects(property);
/*      */   }
/*      */   
/*      */   public void setMaxRows(int property) throws SQLException {
/* 1203 */     getActiveMySQLConnection().setMaxRows(property);
/*      */   }
/*      */   
/*      */   public void setMetadataCacheSize(int value) throws SQLException {
/* 1207 */     getActiveMySQLConnection().setMetadataCacheSize(value);
/*      */   }
/*      */   
/*      */   public void setNetTimeoutForStreamingResults(int value) throws SQLException {
/* 1211 */     getActiveMySQLConnection().setNetTimeoutForStreamingResults(value);
/*      */   }
/*      */   
/*      */   public void setNoAccessToProcedureBodies(boolean flag) {
/* 1215 */     getActiveMySQLConnection().setNoAccessToProcedureBodies(flag);
/*      */   }
/*      */   
/*      */   public void setNoDatetimeStringSync(boolean flag) {
/* 1219 */     getActiveMySQLConnection().setNoDatetimeStringSync(flag);
/*      */   }
/*      */   
/*      */   public void setNoTimezoneConversionForTimeType(boolean flag) {
/* 1223 */     getActiveMySQLConnection().setNoTimezoneConversionForTimeType(flag);
/*      */   }
/*      */   
/*      */   public void setNoTimezoneConversionForDateType(boolean flag) {
/* 1227 */     getActiveMySQLConnection().setNoTimezoneConversionForDateType(flag);
/*      */   }
/*      */   
/*      */   public void setCacheDefaultTimezone(boolean flag) {
/* 1231 */     getActiveMySQLConnection().setCacheDefaultTimezone(flag);
/*      */   }
/*      */   
/*      */   public void setNullCatalogMeansCurrent(boolean value) {
/* 1235 */     getActiveMySQLConnection().setNullCatalogMeansCurrent(value);
/*      */   }
/*      */   
/*      */   public void setNullNamePatternMatchesAll(boolean value) {
/* 1239 */     getActiveMySQLConnection().setNullNamePatternMatchesAll(value);
/*      */   }
/*      */   
/*      */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag) {
/* 1243 */     getActiveMySQLConnection().setOverrideSupportsIntegrityEnhancementFacility(flag);
/*      */   }
/*      */   
/*      */   public void setPacketDebugBufferSize(int size) throws SQLException {
/* 1247 */     getActiveMySQLConnection().setPacketDebugBufferSize(size);
/*      */   }
/*      */   
/*      */   public void setPadCharsWithSpace(boolean flag) {
/* 1251 */     getActiveMySQLConnection().setPadCharsWithSpace(flag);
/*      */   }
/*      */   
/*      */   public void setParanoid(boolean property) {
/* 1255 */     getActiveMySQLConnection().setParanoid(property);
/*      */   }
/*      */   
/*      */   public void setPasswordCharacterEncoding(String characterSet) {
/* 1259 */     getActiveMySQLConnection().setPasswordCharacterEncoding(characterSet);
/*      */   }
/*      */   
/*      */   public void setPedantic(boolean property) {
/* 1263 */     getActiveMySQLConnection().setPedantic(property);
/*      */   }
/*      */   
/*      */   public void setPinGlobalTxToPhysicalConnection(boolean flag) {
/* 1267 */     getActiveMySQLConnection().setPinGlobalTxToPhysicalConnection(flag);
/*      */   }
/*      */   
/*      */   public void setPopulateInsertRowWithDefaultValues(boolean flag) {
/* 1271 */     getActiveMySQLConnection().setPopulateInsertRowWithDefaultValues(flag);
/*      */   }
/*      */   
/*      */   public void setPrepStmtCacheSize(int cacheSize) throws SQLException {
/* 1275 */     getActiveMySQLConnection().setPrepStmtCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */   public void setPrepStmtCacheSqlLimit(int sqlLimit) throws SQLException {
/* 1279 */     getActiveMySQLConnection().setPrepStmtCacheSqlLimit(sqlLimit);
/*      */   }
/*      */   
/*      */   public void setPreparedStatementCacheSize(int cacheSize) throws SQLException {
/* 1283 */     getActiveMySQLConnection().setPreparedStatementCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit) throws SQLException {
/* 1287 */     getActiveMySQLConnection().setPreparedStatementCacheSqlLimit(cacheSqlLimit);
/*      */   }
/*      */   
/*      */   public void setProcessEscapeCodesForPrepStmts(boolean flag) {
/* 1291 */     getActiveMySQLConnection().setProcessEscapeCodesForPrepStmts(flag);
/*      */   }
/*      */   
/*      */   public void setProfileSQL(boolean flag) {
/* 1295 */     getActiveMySQLConnection().setProfileSQL(flag);
/*      */   }
/*      */   
/*      */   public void setProfileSql(boolean property) {
/* 1299 */     getActiveMySQLConnection().setProfileSql(property);
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandler(String handler) {
/* 1303 */     getActiveMySQLConnection().setProfilerEventHandler(handler);
/*      */   }
/*      */   
/*      */   public void setPropertiesTransform(String value) {
/* 1307 */     getActiveMySQLConnection().setPropertiesTransform(value);
/*      */   }
/*      */   
/*      */   public void setQueriesBeforeRetryMaster(int property) throws SQLException {
/* 1311 */     getActiveMySQLConnection().setQueriesBeforeRetryMaster(property);
/*      */   }
/*      */   
/*      */   public void setQueryTimeoutKillsConnection(boolean queryTimeoutKillsConnection) {
/* 1315 */     getActiveMySQLConnection().setQueryTimeoutKillsConnection(queryTimeoutKillsConnection);
/*      */   }
/*      */   
/*      */   public void setReconnectAtTxEnd(boolean property) {
/* 1319 */     getActiveMySQLConnection().setReconnectAtTxEnd(property);
/*      */   }
/*      */   
/*      */   public void setRelaxAutoCommit(boolean property) {
/* 1323 */     getActiveMySQLConnection().setRelaxAutoCommit(property);
/*      */   }
/*      */   
/*      */   public void setReportMetricsIntervalMillis(int millis) throws SQLException {
/* 1327 */     getActiveMySQLConnection().setReportMetricsIntervalMillis(millis);
/*      */   }
/*      */   
/*      */   public void setRequireSSL(boolean property) {
/* 1331 */     getActiveMySQLConnection().setRequireSSL(property);
/*      */   }
/*      */   
/*      */   public void setResourceId(String resourceId) {
/* 1335 */     getActiveMySQLConnection().setResourceId(resourceId);
/*      */   }
/*      */   
/*      */   public void setResultSetSizeThreshold(int threshold) throws SQLException {
/* 1339 */     getActiveMySQLConnection().setResultSetSizeThreshold(threshold);
/*      */   }
/*      */   
/*      */   public void setRetainStatementAfterResultSetClose(boolean flag) {
/* 1343 */     getActiveMySQLConnection().setRetainStatementAfterResultSetClose(flag);
/*      */   }
/*      */   
/*      */   public void setRetriesAllDown(int retriesAllDown) throws SQLException {
/* 1347 */     getActiveMySQLConnection().setRetriesAllDown(retriesAllDown);
/*      */   }
/*      */   
/*      */   public void setRewriteBatchedStatements(boolean flag) {
/* 1351 */     getActiveMySQLConnection().setRewriteBatchedStatements(flag);
/*      */   }
/*      */   
/*      */   public void setRollbackOnPooledClose(boolean flag) {
/* 1355 */     getActiveMySQLConnection().setRollbackOnPooledClose(flag);
/*      */   }
/*      */   
/*      */   public void setRoundRobinLoadBalance(boolean flag) {
/* 1359 */     getActiveMySQLConnection().setRoundRobinLoadBalance(flag);
/*      */   }
/*      */   
/*      */   public void setRunningCTS13(boolean flag) {
/* 1363 */     getActiveMySQLConnection().setRunningCTS13(flag);
/*      */   }
/*      */   
/*      */   public void setSecondsBeforeRetryMaster(int property) throws SQLException {
/* 1367 */     getActiveMySQLConnection().setSecondsBeforeRetryMaster(property);
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingMaxOperations(int maxOperations) throws SQLException {
/* 1371 */     getActiveMySQLConnection().setSelfDestructOnPingMaxOperations(maxOperations);
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingSecondsLifetime(int seconds) throws SQLException {
/* 1375 */     getActiveMySQLConnection().setSelfDestructOnPingSecondsLifetime(seconds);
/*      */   }
/*      */   
/*      */   public void setServerTimezone(String property) {
/* 1379 */     getActiveMySQLConnection().setServerTimezone(property);
/*      */   }
/*      */   
/*      */   public void setSessionVariables(String variables) {
/* 1383 */     getActiveMySQLConnection().setSessionVariables(variables);
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdMillis(int millis) throws SQLException {
/* 1387 */     getActiveMySQLConnection().setSlowQueryThresholdMillis(millis);
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdNanos(long nanos) throws SQLException {
/* 1391 */     getActiveMySQLConnection().setSlowQueryThresholdNanos(nanos);
/*      */   }
/*      */   
/*      */   public void setSocketFactory(String name) {
/* 1395 */     getActiveMySQLConnection().setSocketFactory(name);
/*      */   }
/*      */   
/*      */   public void setSocketFactoryClassName(String property) {
/* 1399 */     getActiveMySQLConnection().setSocketFactoryClassName(property);
/*      */   }
/*      */   
/*      */   public void setSocketTimeout(int property) throws SQLException {
/* 1403 */     getActiveMySQLConnection().setSocketTimeout(property);
/*      */   }
/*      */   
/*      */   public void setStatementInterceptors(String value) {
/* 1407 */     getActiveMySQLConnection().setStatementInterceptors(value);
/*      */   }
/*      */   
/*      */   public void setStrictFloatingPoint(boolean property) {
/* 1411 */     getActiveMySQLConnection().setStrictFloatingPoint(property);
/*      */   }
/*      */   
/*      */   public void setStrictUpdates(boolean property) {
/* 1415 */     getActiveMySQLConnection().setStrictUpdates(property);
/*      */   }
/*      */   
/*      */   public void setTcpKeepAlive(boolean flag) {
/* 1419 */     getActiveMySQLConnection().setTcpKeepAlive(flag);
/*      */   }
/*      */   
/*      */   public void setTcpNoDelay(boolean flag) {
/* 1423 */     getActiveMySQLConnection().setTcpNoDelay(flag);
/*      */   }
/*      */   
/*      */   public void setTcpRcvBuf(int bufSize) throws SQLException {
/* 1427 */     getActiveMySQLConnection().setTcpRcvBuf(bufSize);
/*      */   }
/*      */   
/*      */   public void setTcpSndBuf(int bufSize) throws SQLException {
/* 1431 */     getActiveMySQLConnection().setTcpSndBuf(bufSize);
/*      */   }
/*      */   
/*      */   public void setTcpTrafficClass(int classFlags) throws SQLException {
/* 1435 */     getActiveMySQLConnection().setTcpTrafficClass(classFlags);
/*      */   }
/*      */   
/*      */   public void setTinyInt1isBit(boolean flag) {
/* 1439 */     getActiveMySQLConnection().setTinyInt1isBit(flag);
/*      */   }
/*      */   
/*      */   public void setTraceProtocol(boolean flag) {
/* 1443 */     getActiveMySQLConnection().setTraceProtocol(flag);
/*      */   }
/*      */   
/*      */   public void setTransformedBitIsBoolean(boolean flag) {
/* 1447 */     getActiveMySQLConnection().setTransformedBitIsBoolean(flag);
/*      */   }
/*      */   
/*      */   public void setTreatUtilDateAsTimestamp(boolean flag) {
/* 1451 */     getActiveMySQLConnection().setTreatUtilDateAsTimestamp(flag);
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStorePassword(String value) {
/* 1455 */     getActiveMySQLConnection().setTrustCertificateKeyStorePassword(value);
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStoreType(String value) {
/* 1459 */     getActiveMySQLConnection().setTrustCertificateKeyStoreType(value);
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStoreUrl(String value) {
/* 1463 */     getActiveMySQLConnection().setTrustCertificateKeyStoreUrl(value);
/*      */   }
/*      */   
/*      */   public void setUltraDevHack(boolean flag) {
/* 1467 */     getActiveMySQLConnection().setUltraDevHack(flag);
/*      */   }
/*      */   
/*      */   public void setUseAffectedRows(boolean flag) {
/* 1471 */     getActiveMySQLConnection().setUseAffectedRows(flag);
/*      */   }
/*      */   
/*      */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag) {
/* 1475 */     getActiveMySQLConnection().setUseBlobToStoreUTF8OutsideBMP(flag);
/*      */   }
/*      */   
/*      */   public void setUseColumnNamesInFindColumn(boolean flag) {
/* 1479 */     getActiveMySQLConnection().setUseColumnNamesInFindColumn(flag);
/*      */   }
/*      */   
/*      */   public void setUseCompression(boolean property) {
/* 1483 */     getActiveMySQLConnection().setUseCompression(property);
/*      */   }
/*      */   
/*      */   public void setUseConfigs(String configs) {
/* 1487 */     getActiveMySQLConnection().setUseConfigs(configs);
/*      */   }
/*      */   
/*      */   public void setUseCursorFetch(boolean flag) {
/* 1491 */     getActiveMySQLConnection().setUseCursorFetch(flag);
/*      */   }
/*      */   
/*      */   public void setUseDirectRowUnpack(boolean flag) {
/* 1495 */     getActiveMySQLConnection().setUseDirectRowUnpack(flag);
/*      */   }
/*      */   
/*      */   public void setUseDynamicCharsetInfo(boolean flag) {
/* 1499 */     getActiveMySQLConnection().setUseDynamicCharsetInfo(flag);
/*      */   }
/*      */   
/*      */   public void setUseFastDateParsing(boolean flag) {
/* 1503 */     getActiveMySQLConnection().setUseFastDateParsing(flag);
/*      */   }
/*      */   
/*      */   public void setUseFastIntParsing(boolean flag) {
/* 1507 */     getActiveMySQLConnection().setUseFastIntParsing(flag);
/*      */   }
/*      */   
/*      */   public void setUseGmtMillisForDatetimes(boolean flag) {
/* 1511 */     getActiveMySQLConnection().setUseGmtMillisForDatetimes(flag);
/*      */   }
/*      */   
/*      */   public void setUseHostsInPrivileges(boolean property) {
/* 1515 */     getActiveMySQLConnection().setUseHostsInPrivileges(property);
/*      */   }
/*      */   
/*      */   public void setUseInformationSchema(boolean flag) {
/* 1519 */     getActiveMySQLConnection().setUseInformationSchema(flag);
/*      */   }
/*      */   
/*      */   public void setUseJDBCCompliantTimezoneShift(boolean flag) {
/* 1523 */     getActiveMySQLConnection().setUseJDBCCompliantTimezoneShift(flag);
/*      */   }
/*      */   
/*      */   public void setUseJvmCharsetConverters(boolean flag) {
/* 1527 */     getActiveMySQLConnection().setUseJvmCharsetConverters(flag);
/*      */   }
/*      */   
/*      */   public void setUseLegacyDatetimeCode(boolean flag) {
/* 1531 */     getActiveMySQLConnection().setUseLegacyDatetimeCode(flag);
/*      */   }
/*      */   
/*      */   public void setUseLocalSessionState(boolean flag) {
/* 1535 */     getActiveMySQLConnection().setUseLocalSessionState(flag);
/*      */   }
/*      */   
/*      */   public void setUseLocalTransactionState(boolean flag) {
/* 1539 */     getActiveMySQLConnection().setUseLocalTransactionState(flag);
/*      */   }
/*      */   
/*      */   public void setUseNanosForElapsedTime(boolean flag) {
/* 1543 */     getActiveMySQLConnection().setUseNanosForElapsedTime(flag);
/*      */   }
/*      */   
/*      */   public void setUseOldAliasMetadataBehavior(boolean flag) {
/* 1547 */     getActiveMySQLConnection().setUseOldAliasMetadataBehavior(flag);
/*      */   }
/*      */   
/*      */   public void setUseOldUTF8Behavior(boolean flag) {
/* 1551 */     getActiveMySQLConnection().setUseOldUTF8Behavior(flag);
/*      */   }
/*      */   
/*      */   public void setUseOnlyServerErrorMessages(boolean flag) {
/* 1555 */     getActiveMySQLConnection().setUseOnlyServerErrorMessages(flag);
/*      */   }
/*      */   
/*      */   public void setUseReadAheadInput(boolean flag) {
/* 1559 */     getActiveMySQLConnection().setUseReadAheadInput(flag);
/*      */   }
/*      */   
/*      */   public void setUseSSL(boolean property) {
/* 1563 */     getActiveMySQLConnection().setUseSSL(property);
/*      */   }
/*      */   
/*      */   public void setUseSSPSCompatibleTimezoneShift(boolean flag) {
/* 1567 */     getActiveMySQLConnection().setUseSSPSCompatibleTimezoneShift(flag);
/*      */   }
/*      */   
/*      */   public void setUseServerPrepStmts(boolean flag) {
/* 1571 */     getActiveMySQLConnection().setUseServerPrepStmts(flag);
/*      */   }
/*      */   
/*      */   public void setUseServerPreparedStmts(boolean flag) {
/* 1575 */     getActiveMySQLConnection().setUseServerPreparedStmts(flag);
/*      */   }
/*      */   
/*      */   public void setUseSqlStateCodes(boolean flag) {
/* 1579 */     getActiveMySQLConnection().setUseSqlStateCodes(flag);
/*      */   }
/*      */   
/*      */   public void setUseStreamLengthsInPrepStmts(boolean property) {
/* 1583 */     getActiveMySQLConnection().setUseStreamLengthsInPrepStmts(property);
/*      */   }
/*      */   
/*      */   public void setUseTimezone(boolean property) {
/* 1587 */     getActiveMySQLConnection().setUseTimezone(property);
/*      */   }
/*      */   
/*      */   public void setUseUltraDevWorkAround(boolean property) {
/* 1591 */     getActiveMySQLConnection().setUseUltraDevWorkAround(property);
/*      */   }
/*      */   
/*      */   public void setUseUnbufferedInput(boolean flag) {
/* 1595 */     getActiveMySQLConnection().setUseUnbufferedInput(flag);
/*      */   }
/*      */   
/*      */   public void setUseUnicode(boolean flag) {
/* 1599 */     getActiveMySQLConnection().setUseUnicode(flag);
/*      */   }
/*      */   
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag) {
/* 1603 */     getActiveMySQLConnection().setUseUsageAdvisor(useUsageAdvisorFlag);
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) {
/* 1607 */     getActiveMySQLConnection().setUtf8OutsideBmpExcludedColumnNamePattern(regexPattern);
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) {
/* 1611 */     getActiveMySQLConnection().setUtf8OutsideBmpIncludedColumnNamePattern(regexPattern);
/*      */   }
/*      */   
/*      */   public void setVerifyServerCertificate(boolean flag) {
/* 1615 */     getActiveMySQLConnection().setVerifyServerCertificate(flag);
/*      */   }
/*      */   
/*      */   public void setYearIsDateType(boolean flag) {
/* 1619 */     getActiveMySQLConnection().setYearIsDateType(flag);
/*      */   }
/*      */   
/*      */   public void setZeroDateTimeBehavior(String behavior) {
/* 1623 */     getActiveMySQLConnection().setZeroDateTimeBehavior(behavior);
/*      */   }
/*      */   
/*      */   public boolean useUnbufferedInput() {
/* 1627 */     return getActiveMySQLConnection().useUnbufferedInput();
/*      */   }
/*      */   
/*      */   public StringBuilder generateConnectionCommentBlock(StringBuilder buf) {
/* 1631 */     return getActiveMySQLConnection().generateConnectionCommentBlock(buf);
/*      */   }
/*      */   
/*      */   public int getActiveStatementCount() {
/* 1635 */     return getActiveMySQLConnection().getActiveStatementCount();
/*      */   }
/*      */   
/*      */   public boolean getAutoCommit() throws SQLException {
/* 1639 */     return getActiveMySQLConnection().getAutoCommit();
/*      */   }
/*      */   
/*      */   public int getAutoIncrementIncrement() {
/* 1643 */     return getActiveMySQLConnection().getAutoIncrementIncrement();
/*      */   }
/*      */   
/*      */   public CachedResultSetMetaData getCachedMetaData(String sql) {
/* 1647 */     return getActiveMySQLConnection().getCachedMetaData(sql);
/*      */   }
/*      */   
/*      */   public Calendar getCalendarInstanceForSessionOrNew() {
/* 1651 */     return getActiveMySQLConnection().getCalendarInstanceForSessionOrNew();
/*      */   }
/*      */   
/*      */   public Timer getCancelTimer() {
/* 1655 */     return getActiveMySQLConnection().getCancelTimer();
/*      */   }
/*      */   
/*      */   public String getCatalog() throws SQLException {
/* 1659 */     return getActiveMySQLConnection().getCatalog();
/*      */   }
/*      */   
/*      */   public String getCharacterSetMetadata() {
/* 1663 */     return getActiveMySQLConnection().getCharacterSetMetadata();
/*      */   }
/*      */   
/*      */   public SingleByteCharsetConverter getCharsetConverter(String javaEncodingName) throws SQLException {
/* 1667 */     return getActiveMySQLConnection().getCharsetConverter(javaEncodingName);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public String getCharsetNameForIndex(int charsetIndex)
/*      */     throws SQLException
/*      */   {
/* 1675 */     return getEncodingForIndex(charsetIndex);
/*      */   }
/*      */   
/*      */   public String getEncodingForIndex(int collationIndex) throws SQLException {
/* 1679 */     return getActiveMySQLConnection().getEncodingForIndex(collationIndex);
/*      */   }
/*      */   
/*      */   public TimeZone getDefaultTimeZone() {
/* 1683 */     return getActiveMySQLConnection().getDefaultTimeZone();
/*      */   }
/*      */   
/*      */   public String getErrorMessageEncoding() {
/* 1687 */     return getActiveMySQLConnection().getErrorMessageEncoding();
/*      */   }
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/* 1691 */     return getActiveMySQLConnection().getExceptionInterceptor();
/*      */   }
/*      */   
/*      */   public int getHoldability() throws SQLException {
/* 1695 */     return getActiveMySQLConnection().getHoldability();
/*      */   }
/*      */   
/*      */   public String getHost() {
/* 1699 */     return getActiveMySQLConnection().getHost();
/*      */   }
/*      */   
/*      */   public long getId() {
/* 1703 */     return getActiveMySQLConnection().getId();
/*      */   }
/*      */   
/*      */   public long getIdleFor() {
/* 1707 */     return getActiveMySQLConnection().getIdleFor();
/*      */   }
/*      */   
/*      */   public MysqlIO getIO() throws SQLException {
/* 1711 */     return getActiveMySQLConnection().getIO();
/*      */   }
/*      */   
/*      */   public MySQLConnection getLoadBalanceSafeProxy() {
/* 1715 */     return getMultiHostSafeProxy();
/*      */   }
/*      */   
/*      */   public MySQLConnection getMultiHostSafeProxy() {
/* 1719 */     return getActiveMySQLConnection().getMultiHostSafeProxy();
/*      */   }
/*      */   
/*      */   public Log getLog() throws SQLException {
/* 1723 */     return getActiveMySQLConnection().getLog();
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(String javaCharsetName) throws SQLException {
/* 1727 */     return getActiveMySQLConnection().getMaxBytesPerChar(javaCharsetName);
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(Integer charsetIndex, String javaCharsetName) throws SQLException {
/* 1731 */     return getActiveMySQLConnection().getMaxBytesPerChar(charsetIndex, javaCharsetName);
/*      */   }
/*      */   
/*      */   public DatabaseMetaData getMetaData() throws SQLException {
/* 1735 */     return getActiveMySQLConnection().getMetaData();
/*      */   }
/*      */   
/*      */   public java.sql.Statement getMetadataSafeStatement() throws SQLException {
/* 1739 */     return getActiveMySQLConnection().getMetadataSafeStatement();
/*      */   }
/*      */   
/*      */   public int getNetBufferLength() {
/* 1743 */     return getActiveMySQLConnection().getNetBufferLength();
/*      */   }
/*      */   
/*      */   public Properties getProperties() {
/* 1747 */     return getActiveMySQLConnection().getProperties();
/*      */   }
/*      */   
/*      */   public boolean getRequiresEscapingEncoder() {
/* 1751 */     return getActiveMySQLConnection().getRequiresEscapingEncoder();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getServerCharacterEncoding()
/*      */   {
/* 1759 */     return getServerCharset();
/*      */   }
/*      */   
/*      */   public String getServerCharset() {
/* 1763 */     return getActiveMySQLConnection().getServerCharset();
/*      */   }
/*      */   
/*      */   public int getServerMajorVersion() {
/* 1767 */     return getActiveMySQLConnection().getServerMajorVersion();
/*      */   }
/*      */   
/*      */   public int getServerMinorVersion() {
/* 1771 */     return getActiveMySQLConnection().getServerMinorVersion();
/*      */   }
/*      */   
/*      */   public int getServerSubMinorVersion() {
/* 1775 */     return getActiveMySQLConnection().getServerSubMinorVersion();
/*      */   }
/*      */   
/*      */   public TimeZone getServerTimezoneTZ() {
/* 1779 */     return getActiveMySQLConnection().getServerTimezoneTZ();
/*      */   }
/*      */   
/*      */   public String getServerVariable(String variableName) {
/* 1783 */     return getActiveMySQLConnection().getServerVariable(variableName);
/*      */   }
/*      */   
/*      */   public String getServerVersion() {
/* 1787 */     return getActiveMySQLConnection().getServerVersion();
/*      */   }
/*      */   
/*      */   public Calendar getSessionLockedCalendar() {
/* 1791 */     return getActiveMySQLConnection().getSessionLockedCalendar();
/*      */   }
/*      */   
/*      */   public String getStatementComment() {
/* 1795 */     return getActiveMySQLConnection().getStatementComment();
/*      */   }
/*      */   
/*      */   public List<StatementInterceptorV2> getStatementInterceptorsInstances() {
/* 1799 */     return getActiveMySQLConnection().getStatementInterceptorsInstances();
/*      */   }
/*      */   
/*      */   public int getTransactionIsolation() throws SQLException {
/* 1803 */     return getActiveMySQLConnection().getTransactionIsolation();
/*      */   }
/*      */   
/*      */   public Map<String, Class<?>> getTypeMap() throws SQLException {
/* 1807 */     return getActiveMySQLConnection().getTypeMap();
/*      */   }
/*      */   
/*      */   public String getURL() {
/* 1811 */     return getActiveMySQLConnection().getURL();
/*      */   }
/*      */   
/*      */   public String getUser() {
/* 1815 */     return getActiveMySQLConnection().getUser();
/*      */   }
/*      */   
/*      */   public Calendar getUtcCalendar() {
/* 1819 */     return getActiveMySQLConnection().getUtcCalendar();
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 1823 */     return getActiveMySQLConnection().getWarnings();
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(Connection c) {
/* 1827 */     return getActiveMySQLConnection().hasSameProperties(c);
/*      */   }
/*      */   
/*      */   public boolean hasTriedMaster() {
/* 1831 */     return getActiveMySQLConnection().hasTriedMaster();
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPreparedExecutes() {
/* 1835 */     getActiveMySQLConnection().incrementNumberOfPreparedExecutes();
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPrepares() {
/* 1839 */     getActiveMySQLConnection().incrementNumberOfPrepares();
/*      */   }
/*      */   
/*      */   public void incrementNumberOfResultSetsCreated() {
/* 1843 */     getActiveMySQLConnection().incrementNumberOfResultSetsCreated();
/*      */   }
/*      */   
/*      */   public void initializeExtension(Extension ex) throws SQLException {
/* 1847 */     getActiveMySQLConnection().initializeExtension(ex);
/*      */   }
/*      */   
/*      */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet) throws SQLException {
/* 1851 */     getActiveMySQLConnection().initializeResultsMetadataFromCache(sql, cachedMetaData, resultSet);
/*      */   }
/*      */   
/*      */   public void initializeSafeStatementInterceptors() throws SQLException {
/* 1855 */     getActiveMySQLConnection().initializeSafeStatementInterceptors();
/*      */   }
/*      */   
/*      */   public boolean isAbonormallyLongQuery(long millisOrNanos) {
/* 1859 */     return getActiveMySQLConnection().isAbonormallyLongQuery(millisOrNanos);
/*      */   }
/*      */   
/*      */   public boolean isClientTzUTC() {
/* 1863 */     return getActiveMySQLConnection().isClientTzUTC();
/*      */   }
/*      */   
/*      */   public boolean isCursorFetchEnabled() throws SQLException {
/* 1867 */     return getActiveMySQLConnection().isCursorFetchEnabled();
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx() {
/* 1871 */     return getActiveMySQLConnection().isInGlobalTx();
/*      */   }
/*      */   
/*      */   public boolean isMasterConnection() {
/* 1875 */     return getActiveMySQLConnection().isMasterConnection();
/*      */   }
/*      */   
/*      */   public boolean isNoBackslashEscapesSet() {
/* 1879 */     return getActiveMySQLConnection().isNoBackslashEscapesSet();
/*      */   }
/*      */   
/*      */   public boolean isReadInfoMsgEnabled() {
/* 1883 */     return getActiveMySQLConnection().isReadInfoMsgEnabled();
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() throws SQLException {
/* 1887 */     return getActiveMySQLConnection().isReadOnly();
/*      */   }
/*      */   
/*      */   public boolean isReadOnly(boolean useSessionStatus) throws SQLException {
/* 1891 */     return getActiveMySQLConnection().isReadOnly(useSessionStatus);
/*      */   }
/*      */   
/*      */   public boolean isRunningOnJDK13() {
/* 1895 */     return getActiveMySQLConnection().isRunningOnJDK13();
/*      */   }
/*      */   
/*      */   public boolean isSameResource(Connection otherConnection) {
/* 1899 */     return getActiveMySQLConnection().isSameResource(otherConnection);
/*      */   }
/*      */   
/*      */   public boolean isServerTzUTC() {
/* 1903 */     return getActiveMySQLConnection().isServerTzUTC();
/*      */   }
/*      */   
/*      */   public boolean lowerCaseTableNames() {
/* 1907 */     return getActiveMySQLConnection().lowerCaseTableNames();
/*      */   }
/*      */   
/*      */   public String nativeSQL(String sql) throws SQLException {
/* 1911 */     return getActiveMySQLConnection().nativeSQL(sql);
/*      */   }
/*      */   
/*      */   public boolean parserKnowsUnicode() {
/* 1915 */     return getActiveMySQLConnection().parserKnowsUnicode();
/*      */   }
/*      */   
/*      */   public void ping() throws SQLException {
/* 1919 */     getActiveMySQLConnection().ping();
/*      */   }
/*      */   
/*      */   public void pingInternal(boolean checkForClosedConnection, int timeoutMillis) throws SQLException {
/* 1923 */     getActiveMySQLConnection().pingInternal(checkForClosedConnection, timeoutMillis);
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 1927 */     return getActiveMySQLConnection().prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 1931 */     return getActiveMySQLConnection().prepareCall(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String sql) throws SQLException {
/* 1935 */     return getActiveMySQLConnection().prepareCall(sql);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 1939 */     return getActiveMySQLConnection().prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 1943 */     return getActiveMySQLConnection().prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/* 1947 */     return getActiveMySQLConnection().prepareStatement(sql, autoGenKeyIndex);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/* 1951 */     return getActiveMySQLConnection().prepareStatement(sql, autoGenKeyIndexes);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/* 1955 */     return getActiveMySQLConnection().prepareStatement(sql, autoGenKeyColNames);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/* 1959 */     return getActiveMySQLConnection().prepareStatement(sql);
/*      */   }
/*      */   
/*      */   public void realClose(boolean calledExplicitly, boolean issueRollback, boolean skipLocalTeardown, Throwable reason) throws SQLException {
/* 1963 */     getActiveMySQLConnection().realClose(calledExplicitly, issueRollback, skipLocalTeardown, reason);
/*      */   }
/*      */   
/*      */   public void recachePreparedStatement(ServerPreparedStatement pstmt) throws SQLException {
/* 1967 */     getActiveMySQLConnection().recachePreparedStatement(pstmt);
/*      */   }
/*      */   
/*      */   public void decachePreparedStatement(ServerPreparedStatement pstmt) throws SQLException {
/* 1971 */     getActiveMySQLConnection().decachePreparedStatement(pstmt);
/*      */   }
/*      */   
/*      */   public void registerQueryExecutionTime(long queryTimeMs) {
/* 1975 */     getActiveMySQLConnection().registerQueryExecutionTime(queryTimeMs);
/*      */   }
/*      */   
/*      */   public void registerStatement(Statement stmt) {
/* 1979 */     getActiveMySQLConnection().registerStatement(stmt);
/*      */   }
/*      */   
/*      */   public void releaseSavepoint(Savepoint arg0) throws SQLException {
/* 1983 */     getActiveMySQLConnection().releaseSavepoint(arg0);
/*      */   }
/*      */   
/*      */   public void reportNumberOfTablesAccessed(int numTablesAccessed) {
/* 1987 */     getActiveMySQLConnection().reportNumberOfTablesAccessed(numTablesAccessed);
/*      */   }
/*      */   
/*      */   public void reportQueryTime(long millisOrNanos) {
/* 1991 */     getActiveMySQLConnection().reportQueryTime(millisOrNanos);
/*      */   }
/*      */   
/*      */   public void resetServerState() throws SQLException {
/* 1995 */     getActiveMySQLConnection().resetServerState();
/*      */   }
/*      */   
/*      */   public void rollback() throws SQLException {
/* 1999 */     getActiveMySQLConnection().rollback();
/*      */   }
/*      */   
/*      */   public void rollback(Savepoint savepoint) throws SQLException {
/* 2003 */     getActiveMySQLConnection().rollback(savepoint);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/* 2007 */     return getActiveMySQLConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 2011 */     return getActiveMySQLConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/* 2015 */     return getActiveMySQLConnection().serverPrepareStatement(sql, autoGenKeyIndex);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/* 2019 */     return getActiveMySQLConnection().serverPrepareStatement(sql, autoGenKeyIndexes);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/* 2023 */     return getActiveMySQLConnection().serverPrepareStatement(sql, autoGenKeyColNames);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/* 2027 */     return getActiveMySQLConnection().serverPrepareStatement(sql);
/*      */   }
/*      */   
/*      */   public boolean serverSupportsConvertFn() throws SQLException {
/* 2031 */     return getActiveMySQLConnection().serverSupportsConvertFn();
/*      */   }
/*      */   
/*      */   public void setAutoCommit(boolean autoCommitFlag) throws SQLException {
/* 2035 */     getActiveMySQLConnection().setAutoCommit(autoCommitFlag);
/*      */   }
/*      */   
/*      */   public void setCatalog(String catalog) throws SQLException {
/* 2039 */     getActiveMySQLConnection().setCatalog(catalog);
/*      */   }
/*      */   
/*      */   public void setFailedOver(boolean flag) {
/* 2043 */     getActiveMySQLConnection().setFailedOver(flag);
/*      */   }
/*      */   
/*      */   public void setHoldability(int arg0) throws SQLException {
/* 2047 */     getActiveMySQLConnection().setHoldability(arg0);
/*      */   }
/*      */   
/*      */   public void setInGlobalTx(boolean flag) {
/* 2051 */     getActiveMySQLConnection().setInGlobalTx(flag);
/*      */   }
/*      */   
/*      */   public void setPreferSlaveDuringFailover(boolean flag) {
/* 2055 */     getActiveMySQLConnection().setPreferSlaveDuringFailover(flag);
/*      */   }
/*      */   
/*      */   public void setProxy(MySQLConnection proxy) {
/* 2059 */     getActiveMySQLConnection().setProxy(proxy);
/*      */   }
/*      */   
/*      */   public void setReadInfoMsgEnabled(boolean flag) {
/* 2063 */     getActiveMySQLConnection().setReadInfoMsgEnabled(flag);
/*      */   }
/*      */   
/*      */   public void setReadOnly(boolean readOnlyFlag) throws SQLException {
/* 2067 */     getActiveMySQLConnection().setReadOnly(readOnlyFlag);
/*      */   }
/*      */   
/*      */   public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException {
/* 2071 */     getActiveMySQLConnection().setReadOnlyInternal(readOnlyFlag);
/*      */   }
/*      */   
/*      */   public Savepoint setSavepoint() throws SQLException {
/* 2075 */     return getActiveMySQLConnection().setSavepoint();
/*      */   }
/*      */   
/*      */   public Savepoint setSavepoint(String name) throws SQLException {
/* 2079 */     return getActiveMySQLConnection().setSavepoint(name);
/*      */   }
/*      */   
/*      */   public void setStatementComment(String comment) {
/* 2083 */     getActiveMySQLConnection().setStatementComment(comment);
/*      */   }
/*      */   
/*      */   public void setTransactionIsolation(int level) throws SQLException {
/* 2087 */     getActiveMySQLConnection().setTransactionIsolation(level);
/*      */   }
/*      */   
/*      */   public void shutdownServer() throws SQLException {
/* 2091 */     getActiveMySQLConnection().shutdownServer();
/*      */   }
/*      */   
/*      */   public boolean storesLowerCaseTableName() {
/* 2095 */     return getActiveMySQLConnection().storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */   public boolean supportsIsolationLevel() {
/* 2099 */     return getActiveMySQLConnection().supportsIsolationLevel();
/*      */   }
/*      */   
/*      */   public boolean supportsQuotedIdentifiers() {
/* 2103 */     return getActiveMySQLConnection().supportsQuotedIdentifiers();
/*      */   }
/*      */   
/*      */   public boolean supportsTransactions() {
/* 2107 */     return getActiveMySQLConnection().supportsTransactions();
/*      */   }
/*      */   
/*      */   public void throwConnectionClosedException() throws SQLException {
/* 2111 */     getActiveMySQLConnection().throwConnectionClosedException();
/*      */   }
/*      */   
/*      */   public void transactionBegun() throws SQLException {
/* 2115 */     getActiveMySQLConnection().transactionBegun();
/*      */   }
/*      */   
/*      */   public void transactionCompleted() throws SQLException {
/* 2119 */     getActiveMySQLConnection().transactionCompleted();
/*      */   }
/*      */   
/*      */   public void unregisterStatement(Statement stmt) {
/* 2123 */     getActiveMySQLConnection().unregisterStatement(stmt);
/*      */   }
/*      */   
/*      */   public void unSafeStatementInterceptors() throws SQLException {
/* 2127 */     getActiveMySQLConnection().unSafeStatementInterceptors();
/*      */   }
/*      */   
/*      */   public boolean useAnsiQuotedIdentifiers() {
/* 2131 */     return getActiveMySQLConnection().useAnsiQuotedIdentifiers();
/*      */   }
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException {
/* 2135 */     return getActiveMySQLConnection().versionMeetsMinimum(major, minor, subminor);
/*      */   }
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/* 2139 */     return getActiveMySQLConnection().isClosed();
/*      */   }
/*      */   
/*      */   public boolean getHoldResultsOpenOverStatementClose() {
/* 2143 */     return getActiveMySQLConnection().getHoldResultsOpenOverStatementClose();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceConnectionGroup() {
/* 2147 */     return getActiveMySQLConnection().getLoadBalanceConnectionGroup();
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceEnableJMX() {
/* 2151 */     return getActiveMySQLConnection().getLoadBalanceEnableJMX();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceExceptionChecker() {
/* 2155 */     return getActiveMySQLConnection().getLoadBalanceExceptionChecker();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLExceptionSubclassFailover() {
/* 2159 */     return getActiveMySQLConnection().getLoadBalanceSQLExceptionSubclassFailover();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLStateFailover() {
/* 2163 */     return getActiveMySQLConnection().getLoadBalanceSQLStateFailover();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceConnectionGroup(String loadBalanceConnectionGroup) {
/* 2167 */     getActiveMySQLConnection().setLoadBalanceConnectionGroup(loadBalanceConnectionGroup);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceEnableJMX(boolean loadBalanceEnableJMX)
/*      */   {
/* 2172 */     getActiveMySQLConnection().setLoadBalanceEnableJMX(loadBalanceEnableJMX);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceExceptionChecker(String loadBalanceExceptionChecker)
/*      */   {
/* 2177 */     getActiveMySQLConnection().setLoadBalanceExceptionChecker(loadBalanceExceptionChecker);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLExceptionSubclassFailover(String loadBalanceSQLExceptionSubclassFailover)
/*      */   {
/* 2182 */     getActiveMySQLConnection().setLoadBalanceSQLExceptionSubclassFailover(loadBalanceSQLExceptionSubclassFailover);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLStateFailover(String loadBalanceSQLStateFailover)
/*      */   {
/* 2187 */     getActiveMySQLConnection().setLoadBalanceSQLStateFailover(loadBalanceSQLStateFailover);
/*      */   }
/*      */   
/*      */   public boolean isProxySet()
/*      */   {
/* 2192 */     return getActiveMySQLConnection().isProxySet();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceAutoCommitStatementRegex() {
/* 2196 */     return getActiveMySQLConnection().getLoadBalanceAutoCommitStatementRegex();
/*      */   }
/*      */   
/*      */   public int getLoadBalanceAutoCommitStatementThreshold() {
/* 2200 */     return getActiveMySQLConnection().getLoadBalanceAutoCommitStatementThreshold();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementRegex(String loadBalanceAutoCommitStatementRegex) {
/* 2204 */     getActiveMySQLConnection().setLoadBalanceAutoCommitStatementRegex(loadBalanceAutoCommitStatementRegex);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementThreshold(int loadBalanceAutoCommitStatementThreshold) throws SQLException
/*      */   {
/* 2209 */     getActiveMySQLConnection().setLoadBalanceAutoCommitStatementThreshold(loadBalanceAutoCommitStatementThreshold);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadDumpInDeadlockExceptions()
/*      */   {
/* 2214 */     return getActiveMySQLConnection().getIncludeThreadDumpInDeadlockExceptions();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadDumpInDeadlockExceptions(boolean flag) {
/* 2218 */     getActiveMySQLConnection().setIncludeThreadDumpInDeadlockExceptions(flag);
/*      */   }
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
/* 2222 */     getActiveMySQLConnection().setTypeMap(map);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadNamesAsStatementComment() {
/* 2226 */     return getActiveMySQLConnection().getIncludeThreadNamesAsStatementComment();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadNamesAsStatementComment(boolean flag) {
/* 2230 */     getActiveMySQLConnection().setIncludeThreadNamesAsStatementComment(flag);
/*      */   }
/*      */   
/*      */   public boolean isServerLocal() throws SQLException {
/* 2234 */     return getActiveMySQLConnection().isServerLocal();
/*      */   }
/*      */   
/*      */   public void setAuthenticationPlugins(String authenticationPlugins) {
/* 2238 */     getActiveMySQLConnection().setAuthenticationPlugins(authenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getAuthenticationPlugins() {
/* 2242 */     return getActiveMySQLConnection().getAuthenticationPlugins();
/*      */   }
/*      */   
/*      */   public void setDisabledAuthenticationPlugins(String disabledAuthenticationPlugins) {
/* 2246 */     getActiveMySQLConnection().setDisabledAuthenticationPlugins(disabledAuthenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getDisabledAuthenticationPlugins() {
/* 2250 */     return getActiveMySQLConnection().getDisabledAuthenticationPlugins();
/*      */   }
/*      */   
/*      */   public void setDefaultAuthenticationPlugin(String defaultAuthenticationPlugin) {
/* 2254 */     getActiveMySQLConnection().setDefaultAuthenticationPlugin(defaultAuthenticationPlugin);
/*      */   }
/*      */   
/*      */   public String getDefaultAuthenticationPlugin() {
/* 2258 */     return getActiveMySQLConnection().getDefaultAuthenticationPlugin();
/*      */   }
/*      */   
/*      */   public void setParseInfoCacheFactory(String factoryClassname) {
/* 2262 */     getActiveMySQLConnection().setParseInfoCacheFactory(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getParseInfoCacheFactory() {
/* 2266 */     return getActiveMySQLConnection().getParseInfoCacheFactory();
/*      */   }
/*      */   
/*      */   public void setSchema(String schema) throws SQLException {
/* 2270 */     getActiveMySQLConnection().setSchema(schema);
/*      */   }
/*      */   
/*      */   public String getSchema() throws SQLException {
/* 2274 */     return getActiveMySQLConnection().getSchema();
/*      */   }
/*      */   
/*      */   public void abort(Executor executor) throws SQLException {
/* 2278 */     getActiveMySQLConnection().abort(executor);
/*      */   }
/*      */   
/*      */   public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
/* 2282 */     getActiveMySQLConnection().setNetworkTimeout(executor, milliseconds);
/*      */   }
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/* 2286 */     return getActiveMySQLConnection().getNetworkTimeout();
/*      */   }
/*      */   
/*      */   public void setServerConfigCacheFactory(String factoryClassname) {
/* 2290 */     getActiveMySQLConnection().setServerConfigCacheFactory(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getServerConfigCacheFactory() {
/* 2294 */     return getActiveMySQLConnection().getServerConfigCacheFactory();
/*      */   }
/*      */   
/*      */   public void setDisconnectOnExpiredPasswords(boolean disconnectOnExpiredPasswords) {
/* 2298 */     getActiveMySQLConnection().setDisconnectOnExpiredPasswords(disconnectOnExpiredPasswords);
/*      */   }
/*      */   
/*      */   public boolean getDisconnectOnExpiredPasswords() {
/* 2302 */     return getActiveMySQLConnection().getDisconnectOnExpiredPasswords();
/*      */   }
/*      */   
/*      */   public void setGetProceduresReturnsFunctions(boolean getProcedureReturnsFunctions) {
/* 2306 */     getActiveMySQLConnection().setGetProceduresReturnsFunctions(getProcedureReturnsFunctions);
/*      */   }
/*      */   
/*      */   public boolean getGetProceduresReturnsFunctions() {
/* 2310 */     return getActiveMySQLConnection().getGetProceduresReturnsFunctions();
/*      */   }
/*      */   
/*      */   public Object getConnectionMutex() {
/* 2314 */     return getActiveMySQLConnection().getConnectionMutex();
/*      */   }
/*      */   
/*      */   public String getConnectionAttributes() throws SQLException {
/* 2318 */     return getActiveMySQLConnection().getConnectionAttributes();
/*      */   }
/*      */   
/*      */   public boolean getAllowMasterDownConnections() {
/* 2322 */     return false;
/*      */   }
/*      */   
/*      */   public void setAllowMasterDownConnections(boolean connectIfMasterDown) {}
/*      */   
/*      */   public boolean getReplicationEnableJMX()
/*      */   {
/* 2329 */     return false;
/*      */   }
/*      */   
/*      */   public void setReplicationEnableJMX(boolean replicationEnableJMX) {}
/*      */   
/*      */   public void setDetectCustomCollations(boolean detectCustomCollations)
/*      */   {
/* 2336 */     getActiveMySQLConnection().setDetectCustomCollations(detectCustomCollations);
/*      */   }
/*      */   
/*      */   public boolean getDetectCustomCollations() {
/* 2340 */     return getActiveMySQLConnection().getDetectCustomCollations();
/*      */   }
/*      */   
/*      */   public int getSessionMaxRows() {
/* 2344 */     return getActiveMySQLConnection().getSessionMaxRows();
/*      */   }
/*      */   
/*      */   public void setSessionMaxRows(int max) throws SQLException {
/* 2348 */     getActiveMySQLConnection().setSessionMaxRows(max);
/*      */   }
/*      */   
/*      */   public ProfilerEventHandler getProfilerEventHandlerInstance() {
/* 2352 */     return getActiveMySQLConnection().getProfilerEventHandlerInstance();
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandlerInstance(ProfilerEventHandler h) {
/* 2356 */     getActiveMySQLConnection().setProfilerEventHandlerInstance(h);
/*      */   }
/*      */   
/*      */   public String getServerRSAPublicKeyFile() {
/* 2360 */     return getActiveMySQLConnection().getServerRSAPublicKeyFile();
/*      */   }
/*      */   
/*      */   public void setServerRSAPublicKeyFile(String serverRSAPublicKeyFile) throws SQLException {
/* 2364 */     getActiveMySQLConnection().setServerRSAPublicKeyFile(serverRSAPublicKeyFile);
/*      */   }
/*      */   
/*      */   public boolean getAllowPublicKeyRetrieval() {
/* 2368 */     return getActiveMySQLConnection().getAllowPublicKeyRetrieval();
/*      */   }
/*      */   
/*      */   public void setAllowPublicKeyRetrieval(boolean allowPublicKeyRetrieval) throws SQLException {
/* 2372 */     getActiveMySQLConnection().setAllowPublicKeyRetrieval(allowPublicKeyRetrieval);
/*      */   }
/*      */   
/*      */   public void setDontCheckOnDuplicateKeyUpdateInSQL(boolean dontCheckOnDuplicateKeyUpdateInSQL) {
/* 2376 */     getActiveMySQLConnection().setDontCheckOnDuplicateKeyUpdateInSQL(dontCheckOnDuplicateKeyUpdateInSQL);
/*      */   }
/*      */   
/*      */   public boolean getDontCheckOnDuplicateKeyUpdateInSQL() {
/* 2380 */     return getActiveMySQLConnection().getDontCheckOnDuplicateKeyUpdateInSQL();
/*      */   }
/*      */   
/*      */   public void setSocksProxyHost(String socksProxyHost) {
/* 2384 */     getActiveMySQLConnection().setSocksProxyHost(socksProxyHost);
/*      */   }
/*      */   
/*      */   public String getSocksProxyHost() {
/* 2388 */     return getActiveMySQLConnection().getSocksProxyHost();
/*      */   }
/*      */   
/*      */   public void setSocksProxyPort(int socksProxyPort) throws SQLException {
/* 2392 */     getActiveMySQLConnection().setSocksProxyPort(socksProxyPort);
/*      */   }
/*      */   
/*      */   public int getSocksProxyPort() {
/* 2396 */     return getActiveMySQLConnection().getSocksProxyPort();
/*      */   }
/*      */   
/*      */   public boolean getReadOnlyPropagatesToServer() {
/* 2400 */     return getActiveMySQLConnection().getReadOnlyPropagatesToServer();
/*      */   }
/*      */   
/*      */   public void setReadOnlyPropagatesToServer(boolean flag) {
/* 2404 */     getActiveMySQLConnection().setReadOnlyPropagatesToServer(flag);
/*      */   }
/*      */   
/*      */   public String getEnabledSSLCipherSuites() {
/* 2408 */     return getActiveMySQLConnection().getEnabledSSLCipherSuites();
/*      */   }
/*      */   
/*      */   public void setEnabledSSLCipherSuites(String cipherSuites) {
/* 2412 */     getActiveMySQLConnection().setEnabledSSLCipherSuites(cipherSuites);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/MultiHostMySQLConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */