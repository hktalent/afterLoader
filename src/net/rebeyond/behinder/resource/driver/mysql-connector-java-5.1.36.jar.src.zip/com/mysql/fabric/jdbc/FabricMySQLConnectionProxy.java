/*      */ package com.mysql.fabric.jdbc;
/*      */ 
/*      */ import com.mysql.fabric.FabricCommunicationException;
/*      */ import com.mysql.fabric.FabricConnection;
/*      */ import com.mysql.fabric.Server;
/*      */ import com.mysql.fabric.ServerGroup;
/*      */ import com.mysql.fabric.ShardMapping;
/*      */ import com.mysql.fabric.proto.xmlrpc.XmlRpcClient;
/*      */ import com.mysql.jdbc.Buffer;
/*      */ import com.mysql.jdbc.CachedResultSetMetaData;
/*      */ import com.mysql.jdbc.Connection;
/*      */ import com.mysql.jdbc.ConnectionProperties;
/*      */ import com.mysql.jdbc.ConnectionPropertiesImpl;
/*      */ import com.mysql.jdbc.ExceptionInterceptor;
/*      */ import com.mysql.jdbc.Extension;
/*      */ import com.mysql.jdbc.Field;
/*      */ import com.mysql.jdbc.MySQLConnection;
/*      */ import com.mysql.jdbc.MysqlIO;
/*      */ import com.mysql.jdbc.ReplicationConnection;
/*      */ import com.mysql.jdbc.ReplicationConnectionGroup;
/*      */ import com.mysql.jdbc.ReplicationConnectionGroupManager;
/*      */ import com.mysql.jdbc.ResultSetInternalMethods;
/*      */ import com.mysql.jdbc.SQLError;
/*      */ import com.mysql.jdbc.ServerPreparedStatement;
/*      */ import com.mysql.jdbc.SingleByteCharsetConverter;
/*      */ import com.mysql.jdbc.StatementImpl;
/*      */ import com.mysql.jdbc.StatementInterceptorV2;
/*      */ import com.mysql.jdbc.exceptions.MySQLNonTransientConnectionException;
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.LogFactory;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FabricMySQLConnectionProxy
/*      */   extends ConnectionPropertiesImpl
/*      */   implements FabricMySQLConnection, FabricMySQLConnectionProperties
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private Log log;
/*      */   protected FabricConnection fabricConnection;
/*   92 */   protected boolean closed = false;
/*      */   
/*   94 */   protected boolean transactionInProgress = false;
/*      */   
/*      */ 
/*   97 */   protected Map<ServerGroup, ReplicationConnection> serverConnections = new HashMap();
/*      */   
/*      */ 
/*      */   protected ReplicationConnection currentConnection;
/*      */   
/*      */ 
/*      */   protected String shardKey;
/*      */   
/*      */   protected String shardTable;
/*      */   
/*      */   protected String serverGroupName;
/*      */   
/*  109 */   protected Set<String> queryTables = new HashSet();
/*      */   
/*      */   protected ServerGroup serverGroup;
/*      */   
/*      */   protected String host;
/*      */   
/*      */   protected String port;
/*      */   
/*      */   protected String username;
/*      */   protected String password;
/*      */   protected String database;
/*      */   protected ShardMapping shardMapping;
/*  121 */   protected boolean readOnly = false;
/*  122 */   protected boolean autoCommit = true;
/*  123 */   protected int transactionIsolation = 4;
/*      */   
/*      */   private String fabricShardKey;
/*      */   private String fabricShardTable;
/*      */   private String fabricServerGroup;
/*      */   private String fabricProtocol;
/*      */   private String fabricUsername;
/*      */   private String fabricPassword;
/*  131 */   private boolean reportErrors = false;
/*      */   
/*      */   public FabricMySQLConnectionProxy(Properties props) throws SQLException
/*      */   {
/*  135 */     this.fabricShardKey = props.getProperty("fabricShardKey");
/*  136 */     this.fabricShardTable = props.getProperty("fabricShardTable");
/*  137 */     this.fabricServerGroup = props.getProperty("fabricServerGroup");
/*  138 */     this.fabricProtocol = props.getProperty("fabricProtocol");
/*  139 */     this.fabricUsername = props.getProperty("fabricUsername");
/*  140 */     this.fabricPassword = props.getProperty("fabricPassword");
/*  141 */     this.reportErrors = Boolean.valueOf(props.getProperty("fabricReportErrors")).booleanValue();
/*  142 */     props.remove("fabricShardKey");
/*  143 */     props.remove("fabricShardTable");
/*  144 */     props.remove("fabricServerGroup");
/*  145 */     props.remove("fabricProtocol");
/*  146 */     props.remove("fabricUsername");
/*  147 */     props.remove("fabricPassword");
/*  148 */     props.remove("fabricReportErrors");
/*      */     
/*  150 */     this.host = props.getProperty("HOST");
/*  151 */     this.port = props.getProperty("PORT");
/*  152 */     this.username = props.getProperty("user");
/*  153 */     this.password = props.getProperty("password");
/*  154 */     this.database = props.getProperty("DBNAME");
/*  155 */     if (this.username == null) {
/*  156 */       this.username = "";
/*      */     }
/*  158 */     if (this.password == null) {
/*  159 */       this.password = "";
/*      */     }
/*      */     
/*      */ 
/*  163 */     String exceptionInterceptors = props.getProperty("exceptionInterceptors");
/*  164 */     if ((exceptionInterceptors == null) || ("null".equals("exceptionInterceptors"))) {
/*  165 */       exceptionInterceptors = "";
/*      */     } else {
/*  167 */       exceptionInterceptors = exceptionInterceptors + ",";
/*      */     }
/*  169 */     exceptionInterceptors = exceptionInterceptors + "com.mysql.fabric.jdbc.ErrorReportingExceptionInterceptor";
/*  170 */     props.setProperty("exceptionInterceptors", exceptionInterceptors);
/*      */     
/*  172 */     initializeProperties(props);
/*      */     
/*      */ 
/*  175 */     if ((this.fabricServerGroup != null) && (this.fabricShardTable != null)) {
/*  176 */       throw SQLError.createSQLException("Server group and shard table are mutually exclusive. Only one may be provided.", "08004", null, getExceptionInterceptor(), this);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  181 */       String url = this.fabricProtocol + "://" + this.host + ":" + this.port;
/*  182 */       this.fabricConnection = new FabricConnection(url, this.fabricUsername, this.fabricPassword);
/*      */     } catch (FabricCommunicationException ex) {
/*  184 */       throw SQLError.createSQLException("Unable to establish connection to the Fabric server", "08004", ex, getExceptionInterceptor(), this);
/*      */     }
/*      */     
/*      */ 
/*  188 */     setShardTable(this.fabricShardTable);
/*  189 */     setShardKey(this.fabricShardKey);
/*      */     
/*  191 */     setServerGroupName(this.fabricServerGroup);
/*      */     
/*  193 */     this.log = LogFactory.getLogger(getLogger(), "FabricMySQLConnectionProxy", null);
/*      */   }
/*      */   
/*  196 */   private boolean intercepting = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized SQLException interceptException(SQLException sqlEx, Connection conn, String groupName, String hostname, String port)
/*      */     throws FabricCommunicationException
/*      */   {
/*  211 */     if ((!sqlEx.getSQLState().startsWith("08")) && (!MySQLNonTransientConnectionException.class.isAssignableFrom(sqlEx.getClass()))) {
/*  212 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  216 */     Server currentServer = this.serverGroup.getServer(hostname + ":" + port);
/*      */     
/*      */ 
/*  219 */     if (currentServer == null) {
/*  220 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  224 */     if (this.reportErrors) {
/*  225 */       this.fabricConnection.getClient().reportServerError(currentServer, sqlEx.toString(), true);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  230 */       this.fabricConnection.refreshState();
/*  231 */       setCurrentServerGroup(this.serverGroup.getName());
/*      */     } catch (SQLException ex) {
/*  233 */       return SQLError.createSQLException("Unable to refresh Fabric state. Failover impossible", "08006", ex, getExceptionInterceptor(), this);
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  239 */       syncGroupServersToReplicationConnectionGroup(ReplicationConnectionGroupManager.getConnectionGroup(groupName));
/*      */     } catch (SQLException ex) {
/*  241 */       return ex;
/*      */     }
/*      */     
/*  244 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setShardKey(String shardKey)
/*      */     throws SQLException
/*      */   {
/*  251 */     ensureNoTransactionInProgress();
/*      */     
/*  253 */     this.currentConnection = null;
/*      */     
/*  255 */     if (shardKey != null) {
/*  256 */       if (this.serverGroupName != null) {
/*  257 */         throw SQLError.createSQLException("Shard key cannot be provided when server group is chosen directly.", "S1009", null, getExceptionInterceptor(), this);
/*      */       }
/*  259 */       if (this.shardTable == null) {
/*  260 */         throw SQLError.createSQLException("Shard key cannot be provided without a shard table.", "S1009", null, getExceptionInterceptor(), this);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  265 */       setCurrentServerGroup(this.shardMapping.getGroupNameForKey(shardKey));
/*  266 */     } else if (this.shardTable != null) {
/*  267 */       setCurrentServerGroup(this.shardMapping.getGlobalGroupName());
/*      */     }
/*  269 */     this.shardKey = shardKey;
/*      */   }
/*      */   
/*      */   public String getShardKey() {
/*  273 */     return this.shardKey;
/*      */   }
/*      */   
/*      */   public void setShardTable(String shardTable) throws SQLException {
/*  277 */     ensureNoTransactionInProgress();
/*      */     
/*  279 */     this.currentConnection = null;
/*      */     
/*  281 */     if (this.serverGroupName != null) {
/*  282 */       throw SQLError.createSQLException("Server group and shard table are mutually exclusive. Only one may be provided.", "S1009", null, getExceptionInterceptor(), this);
/*      */     }
/*      */     
/*      */ 
/*  286 */     this.shardKey = null;
/*  287 */     this.serverGroup = null;
/*  288 */     this.shardTable = shardTable;
/*  289 */     if (shardTable == null) {
/*  290 */       this.shardMapping = null;
/*      */     }
/*      */     else {
/*  293 */       String table = shardTable;
/*  294 */       String db = this.database;
/*  295 */       if (shardTable.contains(".")) {
/*  296 */         String[] pair = shardTable.split("\\.");
/*  297 */         table = pair[0];
/*  298 */         db = pair[1];
/*      */       }
/*      */       try {
/*  301 */         this.shardMapping = this.fabricConnection.getShardMapping(db, table);
/*  302 */         if (this.shardMapping == null) {
/*  303 */           throw SQLError.createSQLException("Shard mapping not found for table `" + shardTable + "'", "S1009", null, getExceptionInterceptor(), this);
/*      */         }
/*      */         
/*      */ 
/*  307 */         setCurrentServerGroup(this.shardMapping.getGlobalGroupName());
/*      */       }
/*      */       catch (FabricCommunicationException ex) {
/*  310 */         throw SQLError.createSQLException("Fabric communication failure.", "08S01", ex, getExceptionInterceptor(), this);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public String getShardTable()
/*      */   {
/*  317 */     return this.shardTable;
/*      */   }
/*      */   
/*      */   public void setServerGroupName(String serverGroupName) throws SQLException {
/*  321 */     ensureNoTransactionInProgress();
/*      */     
/*  323 */     this.currentConnection = null;
/*      */     
/*      */ 
/*  326 */     if (serverGroupName != null) {
/*  327 */       setCurrentServerGroup(serverGroupName);
/*      */     }
/*      */     
/*  330 */     this.serverGroupName = serverGroupName;
/*      */   }
/*      */   
/*      */   public String getServerGroupName() {
/*  334 */     return this.serverGroupName;
/*      */   }
/*      */   
/*      */   public void clearServerSelectionCriteria() throws SQLException {
/*  338 */     ensureNoTransactionInProgress();
/*  339 */     this.shardTable = null;
/*  340 */     this.shardKey = null;
/*  341 */     this.serverGroupName = null;
/*  342 */     this.serverGroup = null;
/*  343 */     this.queryTables.clear();
/*  344 */     this.currentConnection = null;
/*      */   }
/*      */   
/*      */   public ServerGroup getCurrentServerGroup() {
/*  348 */     return this.serverGroup;
/*      */   }
/*      */   
/*      */   public void clearQueryTables() throws SQLException {
/*  352 */     ensureNoTransactionInProgress();
/*      */     
/*  354 */     this.currentConnection = null;
/*      */     
/*  356 */     this.queryTables.clear();
/*  357 */     setShardTable(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addQueryTable(String tableName)
/*      */     throws SQLException
/*      */   {
/*  369 */     ensureNoTransactionInProgress();
/*      */     
/*  371 */     this.currentConnection = null;
/*      */     
/*      */     try
/*      */     {
/*  375 */       if (this.shardMapping == null) {
/*  376 */         if (this.fabricConnection.getShardMapping(this.database, tableName) != null) {
/*  377 */           setShardTable(tableName);
/*      */         }
/*      */       } else {
/*  380 */         ShardMapping mappingForTableName = this.fabricConnection.getShardMapping(this.database, tableName);
/*  381 */         if ((mappingForTableName != null) && (!mappingForTableName.equals(this.shardMapping))) {
/*  382 */           throw SQLError.createSQLException("Cross-shard query not allowed", "S1009", null, getExceptionInterceptor(), this);
/*      */         }
/*      */       }
/*      */       
/*  386 */       this.queryTables.add(tableName);
/*      */     } catch (FabricCommunicationException ex) {
/*  388 */       throw SQLError.createSQLException("Fabric communication failure.", "08S01", ex, getExceptionInterceptor(), this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getQueryTables()
/*      */   {
/*  397 */     return this.queryTables;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void setCurrentServerGroup(String serverGroupName)
/*      */     throws SQLException
/*      */   {
/*  404 */     this.serverGroup = null;
/*      */     try
/*      */     {
/*  407 */       this.serverGroup = this.fabricConnection.getServerGroup(serverGroupName);
/*      */     } catch (FabricCommunicationException ex) {
/*  409 */       throw SQLError.createSQLException("Fabric communication failure.", "08S01", ex, getExceptionInterceptor(), this);
/*      */     }
/*      */     
/*      */ 
/*  413 */     if (this.serverGroup == null) {
/*  414 */       throw SQLError.createSQLException("Cannot find server group: `" + serverGroupName + "'", "S1009", null, getExceptionInterceptor(), this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected MySQLConnection getActiveMySQLConnection()
/*      */     throws SQLException
/*      */   {
/*  433 */     ReplicationConnection c = (ReplicationConnection)getActiveConnection();
/*  434 */     MySQLConnection mc = (MySQLConnection)c.getCurrentConnection();
/*  435 */     return mc;
/*      */   }
/*      */   
/*      */   protected MySQLConnection getActiveMySQLConnectionPassive() {
/*      */     try {
/*  440 */       return getActiveMySQLConnection();
/*      */     } catch (SQLException ex) {
/*  442 */       throw new IllegalStateException("Unable to determine active connection", ex);
/*      */     }
/*      */   }
/*      */   
/*      */   protected Connection getActiveConnectionPassive() {
/*      */     try {
/*  448 */       return getActiveConnection();
/*      */     } catch (SQLException ex) {
/*  450 */       throw new IllegalStateException("Unable to determine active connection", ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void syncGroupServersToReplicationConnectionGroup(ReplicationConnectionGroup replConnGroup)
/*      */     throws SQLException
/*      */   {
/*  463 */     synchronized (replConnGroup) {
/*  464 */       String currentMasterString = null;
/*  465 */       if (replConnGroup.getMasterHosts().size() == 1) {
/*  466 */         currentMasterString = (String)replConnGroup.getMasterHosts().iterator().next();
/*      */       }
/*      */       
/*  469 */       if ((currentMasterString != null) && (!currentMasterString.equals(this.serverGroup.getMaster().getHostPortString()))) {
/*      */         try
/*      */         {
/*  472 */           replConnGroup.removeMasterHost(currentMasterString, false);
/*      */         }
/*      */         catch (SQLException ex) {
/*  475 */           getLog().logWarn("Unable to remove master: " + currentMasterString, ex);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  480 */       Server newMaster = this.serverGroup.getMaster();
/*  481 */       if ((newMaster != null) && (replConnGroup.getMasterHosts().size() == 0)) {
/*  482 */         getLog().logInfo("Changing master for group '" + replConnGroup.getGroupName() + "' to: " + newMaster);
/*      */         try {
/*  484 */           if (!replConnGroup.getSlaveHosts().contains(newMaster.getHostPortString())) {
/*  485 */             replConnGroup.addSlaveHost(newMaster.getHostPortString());
/*      */           }
/*  487 */           replConnGroup.promoteSlaveToMaster(newMaster.getHostPortString());
/*      */         } catch (SQLException ex) {
/*  489 */           throw SQLError.createSQLException("Unable to promote new master '" + newMaster.toString() + "'", ex.getSQLState(), ex, getExceptionInterceptor(), this);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  496 */       for (Server s : this.serverGroup.getServers()) {
/*  497 */         if (s.isSlave()) {
/*      */           try
/*      */           {
/*  500 */             replConnGroup.addSlaveHost(s.getHostPortString());
/*      */           }
/*      */           catch (SQLException ex) {
/*  503 */             getLog().logWarn("Unable to add slave: " + s.toString(), ex);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  508 */       for (String hostPortString : replConnGroup.getSlaveHosts()) {
/*  509 */         Server fabServer = this.serverGroup.getServer(hostPortString);
/*  510 */         if ((fabServer == null) || (!fabServer.isSlave())) {
/*      */           try {
/*  512 */             replConnGroup.removeSlaveHost(hostPortString, true);
/*      */           }
/*      */           catch (SQLException ex) {
/*  515 */             getLog().logWarn("Unable to remove slave: " + hostPortString, ex);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected Connection getActiveConnection() throws SQLException {
/*  523 */     if (this.currentConnection != null) {
/*  524 */       return this.currentConnection;
/*      */     }
/*      */     
/*  527 */     if (getCurrentServerGroup() == null) {
/*  528 */       throw SQLError.createSQLException("No server group selected.", "08004", null, getExceptionInterceptor(), this);
/*      */     }
/*      */     
/*      */ 
/*  532 */     this.currentConnection = ((ReplicationConnection)this.serverConnections.get(this.serverGroup));
/*  533 */     if (this.currentConnection != null) {
/*  534 */       return this.currentConnection;
/*      */     }
/*      */     
/*      */ 
/*  538 */     List<String> masterHost = new ArrayList();
/*  539 */     List<String> slaveHosts = new ArrayList();
/*  540 */     for (Server s : this.serverGroup.getServers()) {
/*  541 */       if (s.isMaster()) {
/*  542 */         masterHost.add(s.getHostPortString());
/*  543 */       } else if (s.isSlave()) {
/*  544 */         slaveHosts.add(s.getHostPortString());
/*      */       }
/*      */     }
/*  547 */     Properties info = exposeAsProperties(null);
/*  548 */     ReplicationConnectionGroup replConnGroup = ReplicationConnectionGroupManager.getConnectionGroup(this.serverGroup.getName());
/*  549 */     if (replConnGroup != null) {
/*  550 */       syncGroupServersToReplicationConnectionGroup(replConnGroup);
/*      */     }
/*  552 */     info.put("replicationConnectionGroup", this.serverGroup.getName());
/*  553 */     info.setProperty("user", this.username);
/*  554 */     info.setProperty("password", this.password);
/*  555 */     info.setProperty("DBNAME", getCatalog());
/*  556 */     info.setProperty("connectionAttributes", "fabricHaGroup:" + this.serverGroup.getName());
/*  557 */     info.setProperty("retriesAllDown", "1");
/*  558 */     this.currentConnection = new ReplicationConnection(info, info, masterHost, slaveHosts);
/*  559 */     this.serverConnections.put(this.serverGroup, this.currentConnection);
/*      */     
/*  561 */     this.currentConnection.setProxy(this);
/*  562 */     this.currentConnection.setAutoCommit(this.autoCommit);
/*  563 */     this.currentConnection.setReadOnly(this.readOnly);
/*  564 */     this.currentConnection.setTransactionIsolation(this.transactionIsolation);
/*  565 */     return this.currentConnection;
/*      */   }
/*      */   
/*      */   private void ensureOpen() throws SQLException {
/*  569 */     if (this.closed) {
/*  570 */       throw SQLError.createSQLException("No operations allowed after connection closed.", "08003", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   private void ensureNoTransactionInProgress() throws SQLException
/*      */   {
/*  576 */     ensureOpen();
/*  577 */     if ((this.transactionInProgress) && (!this.autoCommit)) {
/*  578 */       throw SQLError.createSQLException("Not allow while a transaction is active.", "25000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  587 */     this.closed = true;
/*  588 */     for (Connection c : this.serverConnections.values()) {
/*      */       try {
/*  590 */         c.close();
/*      */       }
/*      */       catch (SQLException ex) {}
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  597 */     return this.closed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isValid(int timeout)
/*      */     throws SQLException
/*      */   {
/*  605 */     return !this.closed;
/*      */   }
/*      */   
/*      */   public void setReadOnly(boolean readOnly) throws SQLException {
/*  609 */     this.readOnly = readOnly;
/*  610 */     for (ReplicationConnection conn : this.serverConnections.values()) {
/*  611 */       conn.setReadOnly(readOnly);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() throws SQLException {
/*  616 */     return this.readOnly;
/*      */   }
/*      */   
/*      */   public boolean isReadOnly(boolean useSessionStatus) throws SQLException {
/*  620 */     return this.readOnly;
/*      */   }
/*      */   
/*      */   public void setCatalog(String catalog) throws SQLException {
/*  624 */     this.database = catalog;
/*  625 */     for (Connection c : this.serverConnections.values()) {
/*  626 */       c.setCatalog(catalog);
/*      */     }
/*      */   }
/*      */   
/*      */   public String getCatalog() {
/*  631 */     return this.database;
/*      */   }
/*      */   
/*      */   public void rollback() throws SQLException {
/*  635 */     getActiveConnection().rollback();
/*  636 */     transactionCompleted();
/*      */   }
/*      */   
/*      */   public void rollback(Savepoint savepoint) throws SQLException {
/*  640 */     getActiveConnection().rollback();
/*  641 */     transactionCompleted();
/*      */   }
/*      */   
/*      */   public void commit() throws SQLException {
/*  645 */     getActiveConnection().commit();
/*  646 */     transactionCompleted();
/*      */   }
/*      */   
/*      */   public void setAutoCommit(boolean autoCommit) throws SQLException {
/*  650 */     this.autoCommit = autoCommit;
/*  651 */     for (Connection c : this.serverConnections.values()) {
/*  652 */       c.setAutoCommit(this.autoCommit);
/*      */     }
/*      */   }
/*      */   
/*      */   public void transactionBegun() throws SQLException {
/*  657 */     if (!this.autoCommit) {
/*  658 */       this.transactionInProgress = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public void transactionCompleted() throws SQLException {
/*  663 */     this.transactionInProgress = false;
/*      */   }
/*      */   
/*      */   public boolean getAutoCommit() {
/*  667 */     return this.autoCommit;
/*      */   }
/*      */   
/*      */   public MySQLConnection getLoadBalanceSafeProxy() {
/*  671 */     return getMultiHostSafeProxy();
/*      */   }
/*      */   
/*      */   public MySQLConnection getMultiHostSafeProxy() {
/*  675 */     return getActiveMySQLConnectionPassive();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTransactionIsolation(int level)
/*      */     throws SQLException
/*      */   {
/*  682 */     this.transactionIsolation = level;
/*  683 */     for (Connection c : this.serverConnections.values()) {
/*  684 */       c.setTransactionIsolation(level);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
/*  689 */     for (Connection c : this.serverConnections.values()) {
/*  690 */       c.setTypeMap(map);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setHoldability(int holdability) throws SQLException {
/*  695 */     for (Connection c : this.serverConnections.values()) {
/*  696 */       c.setHoldability(holdability);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setProxy(MySQLConnection proxy) {}
/*      */   
/*      */ 
/*      */   public Savepoint setSavepoint()
/*      */     throws SQLException
/*      */   {
/*  707 */     return getActiveConnection().setSavepoint();
/*      */   }
/*      */   
/*      */   public Savepoint setSavepoint(String name) throws SQLException {
/*  711 */     this.transactionInProgress = true;
/*  712 */     return getActiveConnection().setSavepoint(name);
/*      */   }
/*      */   
/*      */   public void releaseSavepoint(Savepoint savepoint) {}
/*      */   
/*      */   public CallableStatement prepareCall(String sql) throws SQLException
/*      */   {
/*  719 */     transactionBegun();
/*  720 */     return getActiveConnection().prepareCall(sql);
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  724 */     transactionBegun();
/*  725 */     return getActiveConnection().prepareCall(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  729 */     transactionBegun();
/*  730 */     return getActiveConnection().prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/*  734 */     transactionBegun();
/*  735 */     return getActiveConnection().prepareStatement(sql);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
/*  739 */     transactionBegun();
/*  740 */     return getActiveConnection().prepareStatement(sql, autoGeneratedKeys);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
/*  744 */     transactionBegun();
/*  745 */     return getActiveConnection().prepareStatement(sql, columnIndexes);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  749 */     transactionBegun();
/*  750 */     return getActiveConnection().prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  754 */     transactionBegun();
/*  755 */     return getActiveConnection().prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
/*  759 */     transactionBegun();
/*  760 */     return getActiveConnection().prepareStatement(sql, columnNames);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*  764 */     transactionBegun();
/*  765 */     return getActiveConnection().clientPrepareStatement(sql);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*  769 */     transactionBegun();
/*  770 */     return getActiveConnection().clientPrepareStatement(sql, autoGenKeyIndex);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  774 */     transactionBegun();
/*  775 */     return getActiveConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*  779 */     transactionBegun();
/*  780 */     return getActiveConnection().clientPrepareStatement(sql, autoGenKeyIndexes);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*      */   {
/*  785 */     transactionBegun();
/*  786 */     return getActiveConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*  790 */     transactionBegun();
/*  791 */     return getActiveConnection().clientPrepareStatement(sql, autoGenKeyColNames);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/*  795 */     transactionBegun();
/*  796 */     return getActiveConnection().serverPrepareStatement(sql);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*  800 */     transactionBegun();
/*  801 */     return getActiveConnection().serverPrepareStatement(sql, autoGenKeyIndex);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  805 */     transactionBegun();
/*  806 */     return getActiveConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*      */   {
/*  811 */     transactionBegun();
/*  812 */     return getActiveConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*  816 */     transactionBegun();
/*  817 */     return getActiveConnection().serverPrepareStatement(sql, autoGenKeyIndexes);
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*  821 */     transactionBegun();
/*  822 */     return getActiveConnection().serverPrepareStatement(sql, autoGenKeyColNames);
/*      */   }
/*      */   
/*      */   public java.sql.Statement createStatement() throws SQLException {
/*  826 */     transactionBegun();
/*  827 */     return getActiveConnection().createStatement();
/*      */   }
/*      */   
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/*  831 */     transactionBegun();
/*  832 */     return getActiveConnection().createStatement(resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  836 */     transactionBegun();
/*  837 */     return getActiveConnection().createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata) throws SQLException
/*      */   {
/*  842 */     return getActiveMySQLConnection().execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);
/*      */   }
/*      */   
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/*  848 */     return getActiveMySQLConnection().execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata, isBatch);
/*      */   }
/*      */   
/*      */   public String extractSqlFromPacket(String possibleSqlQuery, Buffer queryPacket, int endOfQueryPacketPosition) throws SQLException
/*      */   {
/*  853 */     return getActiveMySQLConnection().extractSqlFromPacket(possibleSqlQuery, queryPacket, endOfQueryPacketPosition);
/*      */   }
/*      */   
/*      */   public StringBuilder generateConnectionCommentBlock(StringBuilder buf) {
/*  857 */     return getActiveMySQLConnectionPassive().generateConnectionCommentBlock(buf);
/*      */   }
/*      */   
/*      */   public MysqlIO getIO() throws SQLException {
/*  861 */     return getActiveMySQLConnection().getIO();
/*      */   }
/*      */   
/*      */   public Calendar getCalendarInstanceForSessionOrNew() {
/*  865 */     return getActiveMySQLConnectionPassive().getCalendarInstanceForSessionOrNew();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getServerCharacterEncoding()
/*      */   {
/*  873 */     return getServerCharset();
/*      */   }
/*      */   
/*      */   public String getServerCharset() {
/*  877 */     return getActiveMySQLConnectionPassive().getServerCharset();
/*      */   }
/*      */   
/*      */   public TimeZone getServerTimezoneTZ() {
/*  881 */     return getActiveMySQLConnectionPassive().getServerTimezoneTZ();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor)
/*      */     throws SQLException
/*      */   {
/*  889 */     return getActiveConnection().versionMeetsMinimum(major, minor, subminor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsIsolationLevel()
/*      */   {
/*  896 */     return getActiveConnectionPassive().supportsIsolationLevel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsQuotedIdentifiers()
/*      */   {
/*  903 */     return getActiveConnectionPassive().supportsQuotedIdentifiers();
/*      */   }
/*      */   
/*      */   public DatabaseMetaData getMetaData() throws SQLException {
/*  907 */     return getActiveConnection().getMetaData();
/*      */   }
/*      */   
/*      */   public String getCharacterSetMetadata() {
/*  911 */     return getActiveMySQLConnectionPassive().getCharacterSetMetadata();
/*      */   }
/*      */   
/*      */   public java.sql.Statement getMetadataSafeStatement() throws SQLException {
/*  915 */     return getActiveMySQLConnection().getMetadataSafeStatement();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWrapperFor(Class<?> iface)
/*      */   {
/*  924 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T unwrap(Class<T> iface)
/*      */   {
/*  931 */     return null;
/*      */   }
/*      */   
/*      */   public void unSafeStatementInterceptors() throws SQLException
/*      */   {}
/*      */   
/*      */   public boolean supportsTransactions()
/*      */   {
/*  939 */     return true;
/*      */   }
/*      */   
/*      */   public boolean isRunningOnJDK13() {
/*  943 */     return false;
/*      */   }
/*      */   
/*      */   public void createNewIO(boolean isForReconnect) throws SQLException {
/*  947 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void dumpTestcaseQuery(String query) {}
/*      */   
/*      */   public void abortInternal()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public boolean isServerLocal()
/*      */     throws SQLException
/*      */   {
/*  960 */     return false;
/*      */   }
/*      */   
/*      */   public void shutdownServer() throws SQLException {
/*  964 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void clearHasTriedMaster() {}
/*      */   
/*      */   public boolean hasTriedMaster()
/*      */   {
/*  972 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx()
/*      */   {
/*  977 */     return false;
/*      */   }
/*      */   
/*      */   public void setInGlobalTx(boolean flag)
/*      */   {
/*  982 */     throw new RuntimeException("Global transactions not supported.");
/*      */   }
/*      */   
/*      */   public void changeUser(String userName, String newPassword) throws SQLException {
/*  986 */     throw SQLError.createSQLException("User change not allowed.", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFabricShardKey(String value)
/*      */   {
/*  993 */     this.fabricShardKey = value;
/*      */   }
/*      */   
/*      */   public String getFabricShardKey() {
/*  997 */     return this.fabricShardKey;
/*      */   }
/*      */   
/*      */   public void setFabricShardTable(String value) {
/* 1001 */     this.fabricShardTable = value;
/*      */   }
/*      */   
/*      */   public String getFabricShardTable() {
/* 1005 */     return this.fabricShardTable;
/*      */   }
/*      */   
/*      */   public void setFabricServerGroup(String value) {
/* 1009 */     this.fabricServerGroup = value;
/*      */   }
/*      */   
/*      */   public String getFabricServerGroup() {
/* 1013 */     return this.fabricServerGroup;
/*      */   }
/*      */   
/*      */   public void setFabricProtocol(String value) {
/* 1017 */     this.fabricProtocol = value;
/*      */   }
/*      */   
/*      */   public String getFabricProtocol() {
/* 1021 */     return this.fabricProtocol;
/*      */   }
/*      */   
/*      */   public void setFabricUsername(String value) {
/* 1025 */     this.fabricUsername = value;
/*      */   }
/*      */   
/*      */   public String getFabricUsername() {
/* 1029 */     return this.fabricUsername;
/*      */   }
/*      */   
/*      */   public void setFabricPassword(String value) {
/* 1033 */     this.fabricPassword = value;
/*      */   }
/*      */   
/*      */   public String getFabricPassword() {
/* 1037 */     return this.fabricPassword;
/*      */   }
/*      */   
/*      */   public void setFabricReportErrors(boolean value) {
/* 1041 */     this.reportErrors = value;
/*      */   }
/*      */   
/*      */   public boolean getFabricReportErrors() {
/* 1045 */     return this.reportErrors;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowLoadLocalInfile(boolean property)
/*      */   {
/* 1053 */     super.setAllowLoadLocalInfile(property);
/* 1054 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1055 */       cp.setAllowLoadLocalInfile(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAllowMultiQueries(boolean property)
/*      */   {
/* 1061 */     super.setAllowMultiQueries(property);
/* 1062 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1063 */       cp.setAllowMultiQueries(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAllowNanAndInf(boolean flag)
/*      */   {
/* 1069 */     super.setAllowNanAndInf(flag);
/* 1070 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1071 */       cp.setAllowNanAndInf(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAllowUrlInLocalInfile(boolean flag)
/*      */   {
/* 1077 */     super.setAllowUrlInLocalInfile(flag);
/* 1078 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1079 */       cp.setAllowUrlInLocalInfile(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAlwaysSendSetIsolation(boolean flag)
/*      */   {
/* 1085 */     super.setAlwaysSendSetIsolation(flag);
/* 1086 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1087 */       cp.setAlwaysSendSetIsolation(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoDeserialize(boolean flag)
/*      */   {
/* 1093 */     super.setAutoDeserialize(flag);
/* 1094 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1095 */       cp.setAutoDeserialize(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoGenerateTestcaseScript(boolean flag)
/*      */   {
/* 1101 */     super.setAutoGenerateTestcaseScript(flag);
/* 1102 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1103 */       cp.setAutoGenerateTestcaseScript(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoReconnect(boolean flag)
/*      */   {
/* 1109 */     super.setAutoReconnect(flag);
/* 1110 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1111 */       cp.setAutoReconnect(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoReconnectForConnectionPools(boolean property)
/*      */   {
/* 1117 */     super.setAutoReconnectForConnectionPools(property);
/* 1118 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1119 */       cp.setAutoReconnectForConnectionPools(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoReconnectForPools(boolean flag)
/*      */   {
/* 1125 */     super.setAutoReconnectForPools(flag);
/* 1126 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1127 */       cp.setAutoReconnectForPools(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setBlobSendChunkSize(String value) throws SQLException
/*      */   {
/* 1133 */     super.setBlobSendChunkSize(value);
/* 1134 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1135 */       cp.setBlobSendChunkSize(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCacheCallableStatements(boolean flag)
/*      */   {
/* 1141 */     super.setCacheCallableStatements(flag);
/* 1142 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1143 */       cp.setCacheCallableStatements(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCachePreparedStatements(boolean flag)
/*      */   {
/* 1149 */     super.setCachePreparedStatements(flag);
/* 1150 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1151 */       cp.setCachePreparedStatements(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCacheResultSetMetadata(boolean property)
/*      */   {
/* 1157 */     super.setCacheResultSetMetadata(property);
/* 1158 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1159 */       cp.setCacheResultSetMetadata(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCacheServerConfiguration(boolean flag)
/*      */   {
/* 1165 */     super.setCacheServerConfiguration(flag);
/* 1166 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1167 */       cp.setCacheServerConfiguration(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCallableStatementCacheSize(int size) throws SQLException
/*      */   {
/* 1173 */     super.setCallableStatementCacheSize(size);
/* 1174 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1175 */       cp.setCallableStatementCacheSize(size);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCapitalizeDBMDTypes(boolean property)
/*      */   {
/* 1181 */     super.setCapitalizeDBMDTypes(property);
/* 1182 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1183 */       cp.setCapitalizeDBMDTypes(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCapitalizeTypeNames(boolean flag)
/*      */   {
/* 1189 */     super.setCapitalizeTypeNames(flag);
/* 1190 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1191 */       cp.setCapitalizeTypeNames(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCharacterEncoding(String encoding)
/*      */   {
/* 1197 */     super.setCharacterEncoding(encoding);
/* 1198 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1199 */       cp.setCharacterEncoding(encoding);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCharacterSetResults(String characterSet)
/*      */   {
/* 1205 */     super.setCharacterSetResults(characterSet);
/* 1206 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1207 */       cp.setCharacterSetResults(characterSet);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setClobberStreamingResults(boolean flag)
/*      */   {
/* 1213 */     super.setClobberStreamingResults(flag);
/* 1214 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1215 */       cp.setClobberStreamingResults(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setClobCharacterEncoding(String encoding)
/*      */   {
/* 1221 */     super.setClobCharacterEncoding(encoding);
/* 1222 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1223 */       cp.setClobCharacterEncoding(encoding);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setConnectionCollation(String collation)
/*      */   {
/* 1229 */     super.setConnectionCollation(collation);
/* 1230 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1231 */       cp.setConnectionCollation(collation);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setConnectTimeout(int timeoutMs) throws SQLException
/*      */   {
/* 1237 */     super.setConnectTimeout(timeoutMs);
/* 1238 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1239 */       cp.setConnectTimeout(timeoutMs);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setContinueBatchOnError(boolean property)
/*      */   {
/* 1245 */     super.setContinueBatchOnError(property);
/* 1246 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1247 */       cp.setContinueBatchOnError(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCreateDatabaseIfNotExist(boolean flag)
/*      */   {
/* 1253 */     super.setCreateDatabaseIfNotExist(flag);
/* 1254 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1255 */       cp.setCreateDatabaseIfNotExist(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDefaultFetchSize(int n) throws SQLException
/*      */   {
/* 1261 */     super.setDefaultFetchSize(n);
/* 1262 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1263 */       cp.setDefaultFetchSize(n);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDetectServerPreparedStmts(boolean property)
/*      */   {
/* 1269 */     super.setDetectServerPreparedStmts(property);
/* 1270 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1271 */       cp.setDetectServerPreparedStmts(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDontTrackOpenResources(boolean flag)
/*      */   {
/* 1277 */     super.setDontTrackOpenResources(flag);
/* 1278 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1279 */       cp.setDontTrackOpenResources(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDumpQueriesOnException(boolean flag)
/*      */   {
/* 1285 */     super.setDumpQueriesOnException(flag);
/* 1286 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1287 */       cp.setDumpQueriesOnException(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDynamicCalendars(boolean flag)
/*      */   {
/* 1293 */     super.setDynamicCalendars(flag);
/* 1294 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1295 */       cp.setDynamicCalendars(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setElideSetAutoCommits(boolean flag)
/*      */   {
/* 1301 */     super.setElideSetAutoCommits(flag);
/* 1302 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1303 */       cp.setElideSetAutoCommits(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setEmptyStringsConvertToZero(boolean flag)
/*      */   {
/* 1309 */     super.setEmptyStringsConvertToZero(flag);
/* 1310 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1311 */       cp.setEmptyStringsConvertToZero(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setEmulateLocators(boolean property)
/*      */   {
/* 1317 */     super.setEmulateLocators(property);
/* 1318 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1319 */       cp.setEmulateLocators(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setEmulateUnsupportedPstmts(boolean flag)
/*      */   {
/* 1325 */     super.setEmulateUnsupportedPstmts(flag);
/* 1326 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1327 */       cp.setEmulateUnsupportedPstmts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setEnablePacketDebug(boolean flag)
/*      */   {
/* 1333 */     super.setEnablePacketDebug(flag);
/* 1334 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1335 */       cp.setEnablePacketDebug(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setEncoding(String property)
/*      */   {
/* 1341 */     super.setEncoding(property);
/* 1342 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1343 */       cp.setEncoding(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setExplainSlowQueries(boolean flag)
/*      */   {
/* 1349 */     super.setExplainSlowQueries(flag);
/* 1350 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1351 */       cp.setExplainSlowQueries(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setFailOverReadOnly(boolean flag)
/*      */   {
/* 1357 */     super.setFailOverReadOnly(flag);
/* 1358 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1359 */       cp.setFailOverReadOnly(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setGatherPerformanceMetrics(boolean flag)
/*      */   {
/* 1365 */     super.setGatherPerformanceMetrics(flag);
/* 1366 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1367 */       cp.setGatherPerformanceMetrics(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setHoldResultsOpenOverStatementClose(boolean flag)
/*      */   {
/* 1373 */     super.setHoldResultsOpenOverStatementClose(flag);
/* 1374 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1375 */       cp.setHoldResultsOpenOverStatementClose(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setIgnoreNonTxTables(boolean property)
/*      */   {
/* 1381 */     super.setIgnoreNonTxTables(property);
/* 1382 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1383 */       cp.setIgnoreNonTxTables(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setInitialTimeout(int property) throws SQLException
/*      */   {
/* 1389 */     super.setInitialTimeout(property);
/* 1390 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1391 */       cp.setInitialTimeout(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setIsInteractiveClient(boolean property)
/*      */   {
/* 1397 */     super.setIsInteractiveClient(property);
/* 1398 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1399 */       cp.setIsInteractiveClient(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setJdbcCompliantTruncation(boolean flag)
/*      */   {
/* 1405 */     super.setJdbcCompliantTruncation(flag);
/* 1406 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1407 */       cp.setJdbcCompliantTruncation(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLocatorFetchBufferSize(String value) throws SQLException
/*      */   {
/* 1413 */     super.setLocatorFetchBufferSize(value);
/* 1414 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1415 */       cp.setLocatorFetchBufferSize(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLogger(String property)
/*      */   {
/* 1421 */     super.setLogger(property);
/* 1422 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1423 */       cp.setLogger(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoggerClassName(String className)
/*      */   {
/* 1429 */     super.setLoggerClassName(className);
/* 1430 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1431 */       cp.setLoggerClassName(className);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLogSlowQueries(boolean flag)
/*      */   {
/* 1437 */     super.setLogSlowQueries(flag);
/* 1438 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1439 */       cp.setLogSlowQueries(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setMaintainTimeStats(boolean flag)
/*      */   {
/* 1445 */     super.setMaintainTimeStats(flag);
/* 1446 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1447 */       cp.setMaintainTimeStats(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setMaxQuerySizeToLog(int sizeInBytes) throws SQLException
/*      */   {
/* 1453 */     super.setMaxQuerySizeToLog(sizeInBytes);
/* 1454 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1455 */       cp.setMaxQuerySizeToLog(sizeInBytes);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setMaxReconnects(int property) throws SQLException
/*      */   {
/* 1461 */     super.setMaxReconnects(property);
/* 1462 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1463 */       cp.setMaxReconnects(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setMaxRows(int property) throws SQLException
/*      */   {
/* 1469 */     super.setMaxRows(property);
/* 1470 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1471 */       cp.setMaxRows(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setMetadataCacheSize(int value) throws SQLException
/*      */   {
/* 1477 */     super.setMetadataCacheSize(value);
/* 1478 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1479 */       cp.setMetadataCacheSize(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNoDatetimeStringSync(boolean flag)
/*      */   {
/* 1485 */     super.setNoDatetimeStringSync(flag);
/* 1486 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1487 */       cp.setNoDatetimeStringSync(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNullCatalogMeansCurrent(boolean value)
/*      */   {
/* 1493 */     super.setNullCatalogMeansCurrent(value);
/* 1494 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1495 */       cp.setNullCatalogMeansCurrent(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNullNamePatternMatchesAll(boolean value)
/*      */   {
/* 1501 */     super.setNullNamePatternMatchesAll(value);
/* 1502 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1503 */       cp.setNullNamePatternMatchesAll(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPacketDebugBufferSize(int size) throws SQLException
/*      */   {
/* 1509 */     super.setPacketDebugBufferSize(size);
/* 1510 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1511 */       cp.setPacketDebugBufferSize(size);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setParanoid(boolean property)
/*      */   {
/* 1517 */     super.setParanoid(property);
/* 1518 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1519 */       cp.setParanoid(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPedantic(boolean property)
/*      */   {
/* 1525 */     super.setPedantic(property);
/* 1526 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1527 */       cp.setPedantic(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPreparedStatementCacheSize(int cacheSize) throws SQLException
/*      */   {
/* 1533 */     super.setPreparedStatementCacheSize(cacheSize);
/* 1534 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1535 */       cp.setPreparedStatementCacheSize(cacheSize);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit) throws SQLException
/*      */   {
/* 1541 */     super.setPreparedStatementCacheSqlLimit(cacheSqlLimit);
/* 1542 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1543 */       cp.setPreparedStatementCacheSqlLimit(cacheSqlLimit);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setProfileSql(boolean property)
/*      */   {
/* 1549 */     super.setProfileSql(property);
/* 1550 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1551 */       cp.setProfileSql(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setProfileSQL(boolean flag)
/*      */   {
/* 1557 */     super.setProfileSQL(flag);
/* 1558 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1559 */       cp.setProfileSQL(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPropertiesTransform(String value)
/*      */   {
/* 1565 */     super.setPropertiesTransform(value);
/* 1566 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1567 */       cp.setPropertiesTransform(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setQueriesBeforeRetryMaster(int property) throws SQLException
/*      */   {
/* 1573 */     super.setQueriesBeforeRetryMaster(property);
/* 1574 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1575 */       cp.setQueriesBeforeRetryMaster(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setReconnectAtTxEnd(boolean property)
/*      */   {
/* 1581 */     super.setReconnectAtTxEnd(property);
/* 1582 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1583 */       cp.setReconnectAtTxEnd(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRelaxAutoCommit(boolean property)
/*      */   {
/* 1589 */     super.setRelaxAutoCommit(property);
/* 1590 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1591 */       cp.setRelaxAutoCommit(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setReportMetricsIntervalMillis(int millis) throws SQLException
/*      */   {
/* 1597 */     super.setReportMetricsIntervalMillis(millis);
/* 1598 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1599 */       cp.setReportMetricsIntervalMillis(millis);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRequireSSL(boolean property)
/*      */   {
/* 1605 */     super.setRequireSSL(property);
/* 1606 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1607 */       cp.setRequireSSL(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRetainStatementAfterResultSetClose(boolean flag)
/*      */   {
/* 1613 */     super.setRetainStatementAfterResultSetClose(flag);
/* 1614 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1615 */       cp.setRetainStatementAfterResultSetClose(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRollbackOnPooledClose(boolean flag)
/*      */   {
/* 1621 */     super.setRollbackOnPooledClose(flag);
/* 1622 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1623 */       cp.setRollbackOnPooledClose(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRoundRobinLoadBalance(boolean flag)
/*      */   {
/* 1629 */     super.setRoundRobinLoadBalance(flag);
/* 1630 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1631 */       cp.setRoundRobinLoadBalance(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRunningCTS13(boolean flag)
/*      */   {
/* 1637 */     super.setRunningCTS13(flag);
/* 1638 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1639 */       cp.setRunningCTS13(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSecondsBeforeRetryMaster(int property) throws SQLException
/*      */   {
/* 1645 */     super.setSecondsBeforeRetryMaster(property);
/* 1646 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1647 */       cp.setSecondsBeforeRetryMaster(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setServerTimezone(String property)
/*      */   {
/* 1653 */     super.setServerTimezone(property);
/* 1654 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1655 */       cp.setServerTimezone(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSessionVariables(String variables)
/*      */   {
/* 1661 */     super.setSessionVariables(variables);
/* 1662 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1663 */       cp.setSessionVariables(variables);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdMillis(int millis) throws SQLException
/*      */   {
/* 1669 */     super.setSlowQueryThresholdMillis(millis);
/* 1670 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1671 */       cp.setSlowQueryThresholdMillis(millis);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSocketFactoryClassName(String property)
/*      */   {
/* 1677 */     super.setSocketFactoryClassName(property);
/* 1678 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1679 */       cp.setSocketFactoryClassName(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSocketTimeout(int property) throws SQLException
/*      */   {
/* 1685 */     super.setSocketTimeout(property);
/* 1686 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1687 */       cp.setSocketTimeout(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setStrictFloatingPoint(boolean property)
/*      */   {
/* 1693 */     super.setStrictFloatingPoint(property);
/* 1694 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1695 */       cp.setStrictFloatingPoint(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setStrictUpdates(boolean property)
/*      */   {
/* 1701 */     super.setStrictUpdates(property);
/* 1702 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1703 */       cp.setStrictUpdates(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTinyInt1isBit(boolean flag)
/*      */   {
/* 1709 */     super.setTinyInt1isBit(flag);
/* 1710 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1711 */       cp.setTinyInt1isBit(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTraceProtocol(boolean flag)
/*      */   {
/* 1717 */     super.setTraceProtocol(flag);
/* 1718 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1719 */       cp.setTraceProtocol(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTransformedBitIsBoolean(boolean flag)
/*      */   {
/* 1725 */     super.setTransformedBitIsBoolean(flag);
/* 1726 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1727 */       cp.setTransformedBitIsBoolean(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseCompression(boolean property)
/*      */   {
/* 1733 */     super.setUseCompression(property);
/* 1734 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1735 */       cp.setUseCompression(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseFastIntParsing(boolean flag)
/*      */   {
/* 1741 */     super.setUseFastIntParsing(flag);
/* 1742 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1743 */       cp.setUseFastIntParsing(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseHostsInPrivileges(boolean property)
/*      */   {
/* 1749 */     super.setUseHostsInPrivileges(property);
/* 1750 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1751 */       cp.setUseHostsInPrivileges(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseInformationSchema(boolean flag)
/*      */   {
/* 1757 */     super.setUseInformationSchema(flag);
/* 1758 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1759 */       cp.setUseInformationSchema(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseLocalSessionState(boolean flag)
/*      */   {
/* 1765 */     super.setUseLocalSessionState(flag);
/* 1766 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1767 */       cp.setUseLocalSessionState(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseOldUTF8Behavior(boolean flag)
/*      */   {
/* 1773 */     super.setUseOldUTF8Behavior(flag);
/* 1774 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1775 */       cp.setUseOldUTF8Behavior(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseOnlyServerErrorMessages(boolean flag)
/*      */   {
/* 1781 */     super.setUseOnlyServerErrorMessages(flag);
/* 1782 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1783 */       cp.setUseOnlyServerErrorMessages(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseReadAheadInput(boolean flag)
/*      */   {
/* 1789 */     super.setUseReadAheadInput(flag);
/* 1790 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1791 */       cp.setUseReadAheadInput(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseServerPreparedStmts(boolean flag)
/*      */   {
/* 1797 */     super.setUseServerPreparedStmts(flag);
/* 1798 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1799 */       cp.setUseServerPreparedStmts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseSqlStateCodes(boolean flag)
/*      */   {
/* 1805 */     super.setUseSqlStateCodes(flag);
/* 1806 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1807 */       cp.setUseSqlStateCodes(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseSSL(boolean property)
/*      */   {
/* 1813 */     super.setUseSSL(property);
/* 1814 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1815 */       cp.setUseSSL(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseStreamLengthsInPrepStmts(boolean property)
/*      */   {
/* 1821 */     super.setUseStreamLengthsInPrepStmts(property);
/* 1822 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1823 */       cp.setUseStreamLengthsInPrepStmts(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseTimezone(boolean property)
/*      */   {
/* 1829 */     super.setUseTimezone(property);
/* 1830 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1831 */       cp.setUseTimezone(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseUltraDevWorkAround(boolean property)
/*      */   {
/* 1837 */     super.setUseUltraDevWorkAround(property);
/* 1838 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1839 */       cp.setUseUltraDevWorkAround(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseUnbufferedInput(boolean flag)
/*      */   {
/* 1845 */     super.setUseUnbufferedInput(flag);
/* 1846 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1847 */       cp.setUseUnbufferedInput(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseUnicode(boolean flag)
/*      */   {
/* 1853 */     super.setUseUnicode(flag);
/* 1854 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1855 */       cp.setUseUnicode(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag)
/*      */   {
/* 1861 */     super.setUseUsageAdvisor(useUsageAdvisorFlag);
/* 1862 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1863 */       cp.setUseUsageAdvisor(useUsageAdvisorFlag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setYearIsDateType(boolean flag)
/*      */   {
/* 1869 */     super.setYearIsDateType(flag);
/* 1870 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1871 */       cp.setYearIsDateType(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setZeroDateTimeBehavior(String behavior)
/*      */   {
/* 1877 */     super.setZeroDateTimeBehavior(behavior);
/* 1878 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1879 */       cp.setZeroDateTimeBehavior(behavior);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseCursorFetch(boolean flag)
/*      */   {
/* 1885 */     super.setUseCursorFetch(flag);
/* 1886 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1887 */       cp.setUseCursorFetch(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag)
/*      */   {
/* 1893 */     super.setOverrideSupportsIntegrityEnhancementFacility(flag);
/* 1894 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1895 */       cp.setOverrideSupportsIntegrityEnhancementFacility(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNoTimezoneConversionForTimeType(boolean flag)
/*      */   {
/* 1901 */     super.setNoTimezoneConversionForTimeType(flag);
/* 1902 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1903 */       cp.setNoTimezoneConversionForTimeType(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseJDBCCompliantTimezoneShift(boolean flag)
/*      */   {
/* 1909 */     super.setUseJDBCCompliantTimezoneShift(flag);
/* 1910 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1911 */       cp.setUseJDBCCompliantTimezoneShift(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoClosePStmtStreams(boolean flag)
/*      */   {
/* 1917 */     super.setAutoClosePStmtStreams(flag);
/* 1918 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1919 */       cp.setAutoClosePStmtStreams(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setProcessEscapeCodesForPrepStmts(boolean flag)
/*      */   {
/* 1925 */     super.setProcessEscapeCodesForPrepStmts(flag);
/* 1926 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1927 */       cp.setProcessEscapeCodesForPrepStmts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseGmtMillisForDatetimes(boolean flag)
/*      */   {
/* 1933 */     super.setUseGmtMillisForDatetimes(flag);
/* 1934 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1935 */       cp.setUseGmtMillisForDatetimes(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDumpMetadataOnColumnNotFound(boolean flag)
/*      */   {
/* 1941 */     super.setDumpMetadataOnColumnNotFound(flag);
/* 1942 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1943 */       cp.setDumpMetadataOnColumnNotFound(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setResourceId(String resourceId)
/*      */   {
/* 1949 */     super.setResourceId(resourceId);
/* 1950 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1951 */       cp.setResourceId(resourceId);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRewriteBatchedStatements(boolean flag)
/*      */   {
/* 1957 */     super.setRewriteBatchedStatements(flag);
/* 1958 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1959 */       cp.setRewriteBatchedStatements(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads)
/*      */   {
/* 1965 */     super.setJdbcCompliantTruncationForReads(jdbcCompliantTruncationForReads);
/* 1966 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1967 */       cp.setJdbcCompliantTruncationForReads(jdbcCompliantTruncationForReads);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseJvmCharsetConverters(boolean flag)
/*      */   {
/* 1973 */     super.setUseJvmCharsetConverters(flag);
/* 1974 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1975 */       cp.setUseJvmCharsetConverters(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPinGlobalTxToPhysicalConnection(boolean flag)
/*      */   {
/* 1981 */     super.setPinGlobalTxToPhysicalConnection(flag);
/* 1982 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1983 */       cp.setPinGlobalTxToPhysicalConnection(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setGatherPerfMetrics(boolean flag)
/*      */   {
/* 1989 */     super.setGatherPerfMetrics(flag);
/* 1990 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1991 */       cp.setGatherPerfMetrics(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUltraDevHack(boolean flag)
/*      */   {
/* 1997 */     super.setUltraDevHack(flag);
/* 1998 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 1999 */       cp.setUltraDevHack(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setInteractiveClient(boolean property)
/*      */   {
/* 2005 */     super.setInteractiveClient(property);
/* 2006 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2007 */       cp.setInteractiveClient(property);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSocketFactory(String name)
/*      */   {
/* 2013 */     super.setSocketFactory(name);
/* 2014 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2015 */       cp.setSocketFactory(name);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseServerPrepStmts(boolean flag)
/*      */   {
/* 2021 */     super.setUseServerPrepStmts(flag);
/* 2022 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2023 */       cp.setUseServerPrepStmts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCacheCallableStmts(boolean flag)
/*      */   {
/* 2029 */     super.setCacheCallableStmts(flag);
/* 2030 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2031 */       cp.setCacheCallableStmts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCachePrepStmts(boolean flag)
/*      */   {
/* 2037 */     super.setCachePrepStmts(flag);
/* 2038 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2039 */       cp.setCachePrepStmts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCallableStmtCacheSize(int cacheSize) throws SQLException
/*      */   {
/* 2045 */     super.setCallableStmtCacheSize(cacheSize);
/* 2046 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2047 */       cp.setCallableStmtCacheSize(cacheSize);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPrepStmtCacheSize(int cacheSize) throws SQLException
/*      */   {
/* 2053 */     super.setPrepStmtCacheSize(cacheSize);
/* 2054 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2055 */       cp.setPrepStmtCacheSize(cacheSize);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPrepStmtCacheSqlLimit(int sqlLimit) throws SQLException
/*      */   {
/* 2061 */     super.setPrepStmtCacheSqlLimit(sqlLimit);
/* 2062 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2063 */       cp.setPrepStmtCacheSqlLimit(sqlLimit);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNoAccessToProcedureBodies(boolean flag)
/*      */   {
/* 2069 */     super.setNoAccessToProcedureBodies(flag);
/* 2070 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2071 */       cp.setNoAccessToProcedureBodies(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseOldAliasMetadataBehavior(boolean flag)
/*      */   {
/* 2077 */     super.setUseOldAliasMetadataBehavior(flag);
/* 2078 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2079 */       cp.setUseOldAliasMetadataBehavior(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStorePassword(String value)
/*      */   {
/* 2085 */     super.setClientCertificateKeyStorePassword(value);
/* 2086 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2087 */       cp.setClientCertificateKeyStorePassword(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStoreType(String value)
/*      */   {
/* 2093 */     super.setClientCertificateKeyStoreType(value);
/* 2094 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2095 */       cp.setClientCertificateKeyStoreType(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStoreUrl(String value)
/*      */   {
/* 2101 */     super.setClientCertificateKeyStoreUrl(value);
/* 2102 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2103 */       cp.setClientCertificateKeyStoreUrl(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStorePassword(String value)
/*      */   {
/* 2109 */     super.setTrustCertificateKeyStorePassword(value);
/* 2110 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2111 */       cp.setTrustCertificateKeyStorePassword(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStoreType(String value)
/*      */   {
/* 2117 */     super.setTrustCertificateKeyStoreType(value);
/* 2118 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2119 */       cp.setTrustCertificateKeyStoreType(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStoreUrl(String value)
/*      */   {
/* 2125 */     super.setTrustCertificateKeyStoreUrl(value);
/* 2126 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2127 */       cp.setTrustCertificateKeyStoreUrl(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseSSPSCompatibleTimezoneShift(boolean flag)
/*      */   {
/* 2133 */     super.setUseSSPSCompatibleTimezoneShift(flag);
/* 2134 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2135 */       cp.setUseSSPSCompatibleTimezoneShift(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTreatUtilDateAsTimestamp(boolean flag)
/*      */   {
/* 2141 */     super.setTreatUtilDateAsTimestamp(flag);
/* 2142 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2143 */       cp.setTreatUtilDateAsTimestamp(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseFastDateParsing(boolean flag)
/*      */   {
/* 2149 */     super.setUseFastDateParsing(flag);
/* 2150 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2151 */       cp.setUseFastDateParsing(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLocalSocketAddress(String address)
/*      */   {
/* 2157 */     super.setLocalSocketAddress(address);
/* 2158 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2159 */       cp.setLocalSocketAddress(address);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseConfigs(String configs)
/*      */   {
/* 2165 */     super.setUseConfigs(configs);
/* 2166 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2167 */       cp.setUseConfigs(configs);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setGenerateSimpleParameterMetadata(boolean flag)
/*      */   {
/* 2173 */     super.setGenerateSimpleParameterMetadata(flag);
/* 2174 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2175 */       cp.setGenerateSimpleParameterMetadata(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLogXaCommands(boolean flag)
/*      */   {
/* 2181 */     super.setLogXaCommands(flag);
/* 2182 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2183 */       cp.setLogXaCommands(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setResultSetSizeThreshold(int threshold) throws SQLException
/*      */   {
/* 2189 */     super.setResultSetSizeThreshold(threshold);
/* 2190 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2191 */       cp.setResultSetSizeThreshold(threshold);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNetTimeoutForStreamingResults(int value) throws SQLException
/*      */   {
/* 2197 */     super.setNetTimeoutForStreamingResults(value);
/* 2198 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2199 */       cp.setNetTimeoutForStreamingResults(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setEnableQueryTimeouts(boolean flag)
/*      */   {
/* 2205 */     super.setEnableQueryTimeouts(flag);
/* 2206 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2207 */       cp.setEnableQueryTimeouts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPadCharsWithSpace(boolean flag)
/*      */   {
/* 2213 */     super.setPadCharsWithSpace(flag);
/* 2214 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2215 */       cp.setPadCharsWithSpace(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseDynamicCharsetInfo(boolean flag)
/*      */   {
/* 2221 */     super.setUseDynamicCharsetInfo(flag);
/* 2222 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2223 */       cp.setUseDynamicCharsetInfo(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setClientInfoProvider(String classname)
/*      */   {
/* 2229 */     super.setClientInfoProvider(classname);
/* 2230 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2231 */       cp.setClientInfoProvider(classname);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPopulateInsertRowWithDefaultValues(boolean flag)
/*      */   {
/* 2237 */     super.setPopulateInsertRowWithDefaultValues(flag);
/* 2238 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2239 */       cp.setPopulateInsertRowWithDefaultValues(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceStrategy(String strategy)
/*      */   {
/* 2245 */     super.setLoadBalanceStrategy(strategy);
/* 2246 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2247 */       cp.setLoadBalanceStrategy(strategy);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTcpNoDelay(boolean flag)
/*      */   {
/* 2253 */     super.setTcpNoDelay(flag);
/* 2254 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2255 */       cp.setTcpNoDelay(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTcpKeepAlive(boolean flag)
/*      */   {
/* 2261 */     super.setTcpKeepAlive(flag);
/* 2262 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2263 */       cp.setTcpKeepAlive(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTcpRcvBuf(int bufSize) throws SQLException
/*      */   {
/* 2269 */     super.setTcpRcvBuf(bufSize);
/* 2270 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2271 */       cp.setTcpRcvBuf(bufSize);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTcpSndBuf(int bufSize) throws SQLException
/*      */   {
/* 2277 */     super.setTcpSndBuf(bufSize);
/* 2278 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2279 */       cp.setTcpSndBuf(bufSize);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTcpTrafficClass(int classFlags) throws SQLException
/*      */   {
/* 2285 */     super.setTcpTrafficClass(classFlags);
/* 2286 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2287 */       cp.setTcpTrafficClass(classFlags);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseNanosForElapsedTime(boolean flag)
/*      */   {
/* 2293 */     super.setUseNanosForElapsedTime(flag);
/* 2294 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2295 */       cp.setUseNanosForElapsedTime(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdNanos(long nanos) throws SQLException
/*      */   {
/* 2301 */     super.setSlowQueryThresholdNanos(nanos);
/* 2302 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2303 */       cp.setSlowQueryThresholdNanos(nanos);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setStatementInterceptors(String value)
/*      */   {
/* 2309 */     super.setStatementInterceptors(value);
/* 2310 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2311 */       cp.setStatementInterceptors(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseDirectRowUnpack(boolean flag)
/*      */   {
/* 2317 */     super.setUseDirectRowUnpack(flag);
/* 2318 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2319 */       cp.setUseDirectRowUnpack(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLargeRowSizeThreshold(String value) throws SQLException
/*      */   {
/* 2325 */     super.setLargeRowSizeThreshold(value);
/* 2326 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2327 */       cp.setLargeRowSizeThreshold(value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag)
/*      */   {
/* 2333 */     super.setUseBlobToStoreUTF8OutsideBMP(flag);
/* 2334 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2335 */       cp.setUseBlobToStoreUTF8OutsideBMP(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern)
/*      */   {
/* 2341 */     super.setUtf8OutsideBmpExcludedColumnNamePattern(regexPattern);
/* 2342 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2343 */       cp.setUtf8OutsideBmpExcludedColumnNamePattern(regexPattern);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern)
/*      */   {
/* 2349 */     super.setUtf8OutsideBmpIncludedColumnNamePattern(regexPattern);
/* 2350 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2351 */       cp.setUtf8OutsideBmpIncludedColumnNamePattern(regexPattern);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag)
/*      */   {
/* 2357 */     super.setIncludeInnodbStatusInDeadlockExceptions(flag);
/* 2358 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2359 */       cp.setIncludeInnodbStatusInDeadlockExceptions(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setIncludeThreadDumpInDeadlockExceptions(boolean flag)
/*      */   {
/* 2365 */     super.setIncludeThreadDumpInDeadlockExceptions(flag);
/* 2366 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2367 */       cp.setIncludeThreadDumpInDeadlockExceptions(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setIncludeThreadNamesAsStatementComment(boolean flag)
/*      */   {
/* 2373 */     super.setIncludeThreadNamesAsStatementComment(flag);
/* 2374 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2375 */       cp.setIncludeThreadNamesAsStatementComment(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setBlobsAreStrings(boolean flag)
/*      */   {
/* 2381 */     super.setBlobsAreStrings(flag);
/* 2382 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2383 */       cp.setBlobsAreStrings(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setFunctionsNeverReturnBlobs(boolean flag)
/*      */   {
/* 2389 */     super.setFunctionsNeverReturnBlobs(flag);
/* 2390 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2391 */       cp.setFunctionsNeverReturnBlobs(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoSlowLog(boolean flag)
/*      */   {
/* 2397 */     super.setAutoSlowLog(flag);
/* 2398 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2399 */       cp.setAutoSlowLog(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setConnectionLifecycleInterceptors(String interceptors)
/*      */   {
/* 2405 */     super.setConnectionLifecycleInterceptors(interceptors);
/* 2406 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2407 */       cp.setConnectionLifecycleInterceptors(interceptors);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandler(String handler)
/*      */   {
/* 2413 */     super.setProfilerEventHandler(handler);
/* 2414 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2415 */       cp.setProfilerEventHandler(handler);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setVerifyServerCertificate(boolean flag)
/*      */   {
/* 2421 */     super.setVerifyServerCertificate(flag);
/* 2422 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2423 */       cp.setVerifyServerCertificate(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseLegacyDatetimeCode(boolean flag)
/*      */   {
/* 2429 */     super.setUseLegacyDatetimeCode(flag);
/* 2430 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2431 */       cp.setUseLegacyDatetimeCode(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingSecondsLifetime(int seconds) throws SQLException
/*      */   {
/* 2437 */     super.setSelfDestructOnPingSecondsLifetime(seconds);
/* 2438 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2439 */       cp.setSelfDestructOnPingSecondsLifetime(seconds);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingMaxOperations(int maxOperations) throws SQLException
/*      */   {
/* 2445 */     super.setSelfDestructOnPingMaxOperations(maxOperations);
/* 2446 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2447 */       cp.setSelfDestructOnPingMaxOperations(maxOperations);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseColumnNamesInFindColumn(boolean flag)
/*      */   {
/* 2453 */     super.setUseColumnNamesInFindColumn(flag);
/* 2454 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2455 */       cp.setUseColumnNamesInFindColumn(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseLocalTransactionState(boolean flag)
/*      */   {
/* 2461 */     super.setUseLocalTransactionState(flag);
/* 2462 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2463 */       cp.setUseLocalTransactionState(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag)
/*      */   {
/* 2469 */     super.setCompensateOnDuplicateKeyUpdateCounts(flag);
/* 2470 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2471 */       cp.setCompensateOnDuplicateKeyUpdateCounts(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setUseAffectedRows(boolean flag)
/*      */   {
/* 2477 */     super.setUseAffectedRows(flag);
/* 2478 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2479 */       cp.setUseAffectedRows(flag);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setPasswordCharacterEncoding(String characterSet)
/*      */   {
/* 2485 */     super.setPasswordCharacterEncoding(characterSet);
/* 2486 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2487 */       cp.setPasswordCharacterEncoding(characterSet);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) throws SQLException
/*      */   {
/* 2493 */     super.setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout);
/* 2494 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2495 */       cp.setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRetriesAllDown(int retriesAllDown) throws SQLException
/*      */   {
/* 2501 */     super.setRetriesAllDown(retriesAllDown);
/* 2502 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2503 */       cp.setRetriesAllDown(retriesAllDown);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setExceptionInterceptors(String exceptionInterceptors)
/*      */   {
/* 2509 */     super.setExceptionInterceptors(exceptionInterceptors);
/* 2510 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2511 */       cp.setExceptionInterceptors(exceptionInterceptors);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setQueryTimeoutKillsConnection(boolean queryTimeoutKillsConnection)
/*      */   {
/* 2517 */     super.setQueryTimeoutKillsConnection(queryTimeoutKillsConnection);
/* 2518 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2519 */       cp.setQueryTimeoutKillsConnection(queryTimeoutKillsConnection);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalancePingTimeout(int loadBalancePingTimeout) throws SQLException
/*      */   {
/* 2525 */     super.setLoadBalancePingTimeout(loadBalancePingTimeout);
/* 2526 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2527 */       cp.setLoadBalancePingTimeout(loadBalancePingTimeout);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceValidateConnectionOnSwapServer(boolean loadBalanceValidateConnectionOnSwapServer)
/*      */   {
/* 2533 */     super.setLoadBalanceValidateConnectionOnSwapServer(loadBalanceValidateConnectionOnSwapServer);
/* 2534 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2535 */       cp.setLoadBalanceValidateConnectionOnSwapServer(loadBalanceValidateConnectionOnSwapServer);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceConnectionGroup(String loadBalanceConnectionGroup)
/*      */   {
/* 2541 */     super.setLoadBalanceConnectionGroup(loadBalanceConnectionGroup);
/* 2542 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2543 */       cp.setLoadBalanceConnectionGroup(loadBalanceConnectionGroup);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceExceptionChecker(String loadBalanceExceptionChecker)
/*      */   {
/* 2549 */     super.setLoadBalanceExceptionChecker(loadBalanceExceptionChecker);
/* 2550 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2551 */       cp.setLoadBalanceExceptionChecker(loadBalanceExceptionChecker);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLStateFailover(String loadBalanceSQLStateFailover)
/*      */   {
/* 2557 */     super.setLoadBalanceSQLStateFailover(loadBalanceSQLStateFailover);
/* 2558 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2559 */       cp.setLoadBalanceSQLStateFailover(loadBalanceSQLStateFailover);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLExceptionSubclassFailover(String loadBalanceSQLExceptionSubclassFailover)
/*      */   {
/* 2565 */     super.setLoadBalanceSQLExceptionSubclassFailover(loadBalanceSQLExceptionSubclassFailover);
/* 2566 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2567 */       cp.setLoadBalanceSQLExceptionSubclassFailover(loadBalanceSQLExceptionSubclassFailover);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceEnableJMX(boolean loadBalanceEnableJMX)
/*      */   {
/* 2573 */     super.setLoadBalanceEnableJMX(loadBalanceEnableJMX);
/* 2574 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2575 */       cp.setLoadBalanceEnableJMX(loadBalanceEnableJMX);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementThreshold(int loadBalanceAutoCommitStatementThreshold) throws SQLException
/*      */   {
/* 2581 */     super.setLoadBalanceAutoCommitStatementThreshold(loadBalanceAutoCommitStatementThreshold);
/* 2582 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2583 */       cp.setLoadBalanceAutoCommitStatementThreshold(loadBalanceAutoCommitStatementThreshold);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementRegex(String loadBalanceAutoCommitStatementRegex)
/*      */   {
/* 2589 */     super.setLoadBalanceAutoCommitStatementRegex(loadBalanceAutoCommitStatementRegex);
/* 2590 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2591 */       cp.setLoadBalanceAutoCommitStatementRegex(loadBalanceAutoCommitStatementRegex);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAuthenticationPlugins(String authenticationPlugins)
/*      */   {
/* 2597 */     super.setAuthenticationPlugins(authenticationPlugins);
/* 2598 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2599 */       cp.setAuthenticationPlugins(authenticationPlugins);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDisabledAuthenticationPlugins(String disabledAuthenticationPlugins)
/*      */   {
/* 2605 */     super.setDisabledAuthenticationPlugins(disabledAuthenticationPlugins);
/* 2606 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2607 */       cp.setDisabledAuthenticationPlugins(disabledAuthenticationPlugins);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDefaultAuthenticationPlugin(String defaultAuthenticationPlugin)
/*      */   {
/* 2613 */     super.setDefaultAuthenticationPlugin(defaultAuthenticationPlugin);
/* 2614 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2615 */       cp.setDefaultAuthenticationPlugin(defaultAuthenticationPlugin);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setParseInfoCacheFactory(String factoryClassname)
/*      */   {
/* 2621 */     super.setParseInfoCacheFactory(factoryClassname);
/* 2622 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2623 */       cp.setParseInfoCacheFactory(factoryClassname);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setServerConfigCacheFactory(String factoryClassname)
/*      */   {
/* 2629 */     super.setServerConfigCacheFactory(factoryClassname);
/* 2630 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2631 */       cp.setServerConfigCacheFactory(factoryClassname);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setDisconnectOnExpiredPasswords(boolean disconnectOnExpiredPasswords)
/*      */   {
/* 2637 */     super.setDisconnectOnExpiredPasswords(disconnectOnExpiredPasswords);
/* 2638 */     for (ConnectionProperties cp : this.serverConnections.values()) {
/* 2639 */       cp.setDisconnectOnExpiredPasswords(disconnectOnExpiredPasswords);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setGetProceduresReturnsFunctions(boolean getProcedureReturnsFunctions)
/*      */   {
/* 2645 */     super.setGetProceduresReturnsFunctions(getProcedureReturnsFunctions);
/*      */   }
/*      */   
/*      */ 
/*      */   public int getActiveStatementCount()
/*      */   {
/* 2651 */     return -1;
/*      */   }
/*      */   
/*      */   public long getIdleFor() {
/* 2655 */     return -1L;
/*      */   }
/*      */   
/*      */   public Log getLog() {
/* 2659 */     return this.log;
/*      */   }
/*      */   
/*      */   public boolean isMasterConnection() {
/* 2663 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isNoBackslashEscapesSet() {
/* 2667 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSameResource(Connection c) {
/* 2671 */     return false;
/*      */   }
/*      */   
/*      */   public boolean parserKnowsUnicode() {
/* 2675 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void ping()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void resetServerState()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void setFailedOver(boolean flag) {}
/*      */   
/*      */   public void setPreferSlaveDuringFailover(boolean flag) {}
/*      */   
/*      */   public void setStatementComment(String comment) {}
/*      */   
/*      */   public void reportQueryTime(long millisOrNanos) {}
/*      */   
/*      */   public boolean isAbonormallyLongQuery(long millisOrNanos)
/*      */   {
/* 2697 */     return false;
/*      */   }
/*      */   
/*      */   public void initializeExtension(Extension ex) throws SQLException
/*      */   {}
/*      */   
/*      */   public int getAutoIncrementIncrement() {
/* 2704 */     return -1;
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(Connection c) {
/* 2708 */     return false;
/*      */   }
/*      */   
/*      */   public Properties getProperties() {
/* 2712 */     return null;
/*      */   }
/*      */   
/*      */   public void setSchema(String schema) throws SQLException
/*      */   {}
/*      */   
/*      */   public String getSchema() throws SQLException {
/* 2719 */     return null;
/*      */   }
/*      */   
/*      */   public void abort(Executor executor) throws SQLException
/*      */   {}
/*      */   
/*      */   public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException
/*      */   {}
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/* 2729 */     return -1;
/*      */   }
/*      */   
/*      */   public void checkClosed() throws SQLException
/*      */   {}
/*      */   
/*      */   public Object getConnectionMutex() {
/* 2736 */     return this;
/*      */   }
/*      */   
/*      */   public void setSessionMaxRows(int max) throws SQLException {
/* 2740 */     for (Connection c : this.serverConnections.values()) {
/* 2741 */       c.setSessionMaxRows(max);
/*      */     }
/*      */   }
/*      */   
/*      */   public int getSessionMaxRows() {
/* 2746 */     return getActiveConnectionPassive().getSessionMaxRows();
/*      */   }
/*      */   
/*      */   public boolean isProxySet()
/*      */   {
/* 2751 */     return false;
/*      */   }
/*      */   
/*      */   public Connection duplicate() throws SQLException {
/* 2755 */     return null;
/*      */   }
/*      */   
/*      */   public CachedResultSetMetaData getCachedMetaData(String sql) {
/* 2759 */     return null;
/*      */   }
/*      */   
/*      */   public Timer getCancelTimer() {
/* 2763 */     return null;
/*      */   }
/*      */   
/*      */   public SingleByteCharsetConverter getCharsetConverter(String javaEncodingName) throws SQLException {
/* 2767 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public String getCharsetNameForIndex(int charsetIndex)
/*      */     throws SQLException
/*      */   {
/* 2775 */     return getEncodingForIndex(charsetIndex);
/*      */   }
/*      */   
/*      */   public String getEncodingForIndex(int charsetIndex) throws SQLException {
/* 2779 */     return null;
/*      */   }
/*      */   
/*      */   public TimeZone getDefaultTimeZone() {
/* 2783 */     return null;
/*      */   }
/*      */   
/*      */   public String getErrorMessageEncoding() {
/* 2787 */     return null;
/*      */   }
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor()
/*      */   {
/* 2792 */     if (this.currentConnection == null) {
/* 2793 */       return null;
/*      */     }
/*      */     
/* 2796 */     return getActiveConnectionPassive().getExceptionInterceptor();
/*      */   }
/*      */   
/*      */   public String getHost() {
/* 2800 */     return null;
/*      */   }
/*      */   
/*      */   public long getId() {
/* 2804 */     return -1L;
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(String javaCharsetName) throws SQLException {
/* 2808 */     return -1;
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(Integer charsetIndex, String javaCharsetName) throws SQLException {
/* 2812 */     return -1;
/*      */   }
/*      */   
/*      */   public int getNetBufferLength() {
/* 2816 */     return -1;
/*      */   }
/*      */   
/*      */   public boolean getRequiresEscapingEncoder() {
/* 2820 */     return false;
/*      */   }
/*      */   
/*      */   public int getServerMajorVersion() {
/* 2824 */     return -1;
/*      */   }
/*      */   
/*      */   public int getServerMinorVersion() {
/* 2828 */     return -1;
/*      */   }
/*      */   
/*      */   public int getServerSubMinorVersion() {
/* 2832 */     return -1;
/*      */   }
/*      */   
/*      */   public String getServerVariable(String variableName) {
/* 2836 */     return null;
/*      */   }
/*      */   
/*      */   public String getServerVersion() {
/* 2840 */     return null;
/*      */   }
/*      */   
/*      */   public Calendar getSessionLockedCalendar() {
/* 2844 */     return null;
/*      */   }
/*      */   
/*      */   public String getStatementComment() {
/* 2848 */     return null;
/*      */   }
/*      */   
/*      */   public List<StatementInterceptorV2> getStatementInterceptorsInstances() {
/* 2852 */     return null;
/*      */   }
/*      */   
/*      */   public String getURL() {
/* 2856 */     return null;
/*      */   }
/*      */   
/*      */   public String getUser() {
/* 2860 */     return null;
/*      */   }
/*      */   
/*      */   public Calendar getUtcCalendar() {
/* 2864 */     return null;
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPreparedExecutes() {}
/*      */   
/*      */   public void incrementNumberOfPrepares() {}
/*      */   
/*      */   public void incrementNumberOfResultSetsCreated() {}
/*      */   
/*      */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void initializeSafeStatementInterceptors()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public boolean isClientTzUTC()
/*      */   {
/* 2883 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isCursorFetchEnabled() throws SQLException {
/* 2887 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isReadInfoMsgEnabled() {
/* 2891 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isServerTzUTC() {
/* 2895 */     return false;
/*      */   }
/*      */   
/*      */   public boolean lowerCaseTableNames() {
/* 2899 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void maxRowsChanged(com.mysql.jdbc.Statement stmt) {}
/*      */   
/*      */ 
/*      */   public void pingInternal(boolean checkForClosedConnection, int timeoutMillis)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void realClose(boolean calledExplicitly, boolean issueRollback, boolean skipLocalTeardown, Throwable reason)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void recachePreparedStatement(ServerPreparedStatement pstmt)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void registerQueryExecutionTime(long queryTimeMs) {}
/*      */   
/*      */   public void registerStatement(com.mysql.jdbc.Statement stmt) {}
/*      */   
/*      */   public void reportNumberOfTablesAccessed(int numTablesAccessed) {}
/*      */   
/*      */   public boolean serverSupportsConvertFn()
/*      */     throws SQLException
/*      */   {
/* 2927 */     return false;
/*      */   }
/*      */   
/*      */   public void setReadInfoMsgEnabled(boolean flag) {}
/*      */   
/*      */   public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException
/*      */   {}
/*      */   
/*      */   public boolean storesLowerCaseTableName()
/*      */   {
/* 2937 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void throwConnectionClosedException()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */   public void unregisterStatement(com.mysql.jdbc.Statement stmt) {}
/*      */   
/*      */   public void unsetMaxRows(com.mysql.jdbc.Statement stmt)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public boolean useAnsiQuotedIdentifiers()
/*      */   {
/* 2954 */     return false;
/*      */   }
/*      */   
/*      */   public boolean useMaxRows() {
/* 2958 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void clearWarnings() {}
/*      */   
/*      */   public Properties getClientInfo()
/*      */   {
/* 2966 */     return null;
/*      */   }
/*      */   
/*      */   public String getClientInfo(String name) {
/* 2970 */     return null;
/*      */   }
/*      */   
/*      */   public int getHoldability() {
/* 2974 */     return -1;
/*      */   }
/*      */   
/*      */   public int getTransactionIsolation() {
/* 2978 */     return -1;
/*      */   }
/*      */   
/*      */   public Map<String, Class<?>> getTypeMap() {
/* 2982 */     return null;
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings() {
/* 2986 */     return null;
/*      */   }
/*      */   
/*      */   public String nativeSQL(String sql) {
/* 2990 */     return null;
/*      */   }
/*      */   
/*      */   public ProfilerEventHandler getProfilerEventHandlerInstance() {
/* 2994 */     return null;
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandlerInstance(ProfilerEventHandler h) {}
/*      */   
/*      */   public void decachePreparedStatement(ServerPreparedStatement pstmt)
/*      */     throws SQLException
/*      */   {}
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/jdbc/FabricMySQLConnectionProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */