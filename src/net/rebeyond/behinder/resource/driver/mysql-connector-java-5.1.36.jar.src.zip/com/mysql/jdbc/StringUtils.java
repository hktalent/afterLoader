/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.math.BigDecimal;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.IllegalCharsetNameException;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   public static enum SearchMode
/*      */   {
/*   52 */     ALLOW_BACKSLASH_ESCAPE,  SKIP_BETWEEN_MARKERS,  SKIP_BLOCK_COMMENTS,  SKIP_LINE_COMMENTS,  SKIP_WHITE_SPACE;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private SearchMode() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*   62 */   public static final Set<SearchMode> SEARCH_MODE__ALL = Collections.unmodifiableSet(EnumSet.allOf(SearchMode.class));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   67 */   public static final Set<SearchMode> SEARCH_MODE__MRK_COM_WS = Collections.unmodifiableSet(EnumSet.of(SearchMode.SKIP_BETWEEN_MARKERS, SearchMode.SKIP_BLOCK_COMMENTS, SearchMode.SKIP_LINE_COMMENTS, SearchMode.SKIP_WHITE_SPACE));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   73 */   public static final Set<SearchMode> SEARCH_MODE__BSESC_COM_WS = Collections.unmodifiableSet(EnumSet.of(SearchMode.ALLOW_BACKSLASH_ESCAPE, SearchMode.SKIP_BLOCK_COMMENTS, SearchMode.SKIP_LINE_COMMENTS, SearchMode.SKIP_WHITE_SPACE));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   79 */   public static final Set<SearchMode> SEARCH_MODE__BSESC_MRK_WS = Collections.unmodifiableSet(EnumSet.of(SearchMode.ALLOW_BACKSLASH_ESCAPE, SearchMode.SKIP_BETWEEN_MARKERS, SearchMode.SKIP_WHITE_SPACE));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   85 */   public static final Set<SearchMode> SEARCH_MODE__COM_WS = Collections.unmodifiableSet(EnumSet.of(SearchMode.SKIP_BLOCK_COMMENTS, SearchMode.SKIP_LINE_COMMENTS, SearchMode.SKIP_WHITE_SPACE));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   91 */   public static final Set<SearchMode> SEARCH_MODE__MRK_WS = Collections.unmodifiableSet(EnumSet.of(SearchMode.SKIP_BETWEEN_MARKERS, SearchMode.SKIP_WHITE_SPACE));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   97 */   public static final Set<SearchMode> SEARCH_MODE__NONE = Collections.unmodifiableSet(EnumSet.noneOf(SearchMode.class));
/*      */   
/*      */ 
/*      */   private static final int NON_COMMENTS_MYSQL_VERSION_REF_LENGTH = 5;
/*      */   
/*      */   private static final int BYTE_RANGE = 256;
/*      */   
/*  104 */   private static byte[] allBytes = new byte['Ā'];
/*      */   
/*  106 */   private static char[] byteToChars = new char['Ā'];
/*      */   
/*      */   private static Method toPlainStringMethod;
/*      */   
/*      */   static final int WILD_COMPARE_MATCH_NO_WILD = 0;
/*      */   
/*      */   static final int WILD_COMPARE_MATCH_WITH_WILD = 1;
/*      */   
/*      */   static final int WILD_COMPARE_NO_MATCH = -1;
/*      */   
/*  116 */   private static final ConcurrentHashMap<String, Charset> charsetsByAlias = new ConcurrentHashMap();
/*      */   
/*  118 */   private static final String platformEncoding = System.getProperty("file.encoding");
/*      */   private static final String VALID_ID_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIGKLMNOPQRSTUVWXYZ0123456789$_#@";
/*      */   
/*      */   static Charset findCharset(String alias) throws UnsupportedEncodingException
/*      */   {
/*      */     try {
/*  124 */       Charset cs = (Charset)charsetsByAlias.get(alias);
/*      */       
/*  126 */       if (cs == null) {
/*  127 */         cs = Charset.forName(alias);
/*  128 */         charsetsByAlias.putIfAbsent(alias, cs);
/*      */       }
/*      */       
/*  131 */       return cs;
/*      */     }
/*      */     catch (UnsupportedCharsetException uce)
/*      */     {
/*  135 */       throw new UnsupportedEncodingException(alias);
/*      */     } catch (IllegalCharsetNameException icne) {
/*  137 */       throw new UnsupportedEncodingException(alias);
/*      */     } catch (IllegalArgumentException iae) {
/*  139 */       throw new UnsupportedEncodingException(alias);
/*      */     }
/*      */   }
/*      */   
/*      */   static {
/*  144 */     for (int i = -128; i <= 127; i++) {
/*  145 */       allBytes[(i - -128)] = ((byte)i);
/*      */     }
/*      */     
/*  148 */     String allBytesString = new String(allBytes, 0, 255);
/*      */     
/*  150 */     int allBytesStringLen = allBytesString.length();
/*      */     
/*  152 */     for (int i = 0; (i < 255) && (i < allBytesStringLen); i++) {
/*  153 */       byteToChars[i] = allBytesString.charAt(i);
/*      */     }
/*      */     try
/*      */     {
/*  157 */       toPlainStringMethod = BigDecimal.class.getMethod("toPlainString", new Class[0]);
/*      */     }
/*      */     catch (NoSuchMethodException nsme) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String consistentToString(BigDecimal decimal)
/*      */   {
/*  173 */     if (decimal == null) {
/*  174 */       return null;
/*      */     }
/*      */     
/*  177 */     if (toPlainStringMethod != null) {
/*      */       try {
/*  179 */         return (String)toPlainStringMethod.invoke(decimal, (Object[])null);
/*      */       }
/*      */       catch (InvocationTargetException invokeEx) {}catch (IllegalAccessException accessEx) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  187 */     return decimal.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String dumpAsHex(byte[] byteBuffer, int length)
/*      */   {
/*  201 */     StringBuilder outputBuilder = new StringBuilder(length * 4);
/*      */     
/*  203 */     int p = 0;
/*  204 */     int rows = length / 8;
/*      */     
/*  206 */     for (int i = 0; (i < rows) && (p < length); i++) {
/*  207 */       int ptemp = p;
/*      */       
/*  209 */       for (int j = 0; j < 8; j++) {
/*  210 */         String hexVal = Integer.toHexString(byteBuffer[ptemp] & 0xFF);
/*      */         
/*  212 */         if (hexVal.length() == 1) {
/*  213 */           hexVal = "0" + hexVal;
/*      */         }
/*      */         
/*  216 */         outputBuilder.append(hexVal + " ");
/*  217 */         ptemp++;
/*      */       }
/*      */       
/*  220 */       outputBuilder.append("    ");
/*      */       
/*  222 */       for (int j = 0; j < 8; j++) {
/*  223 */         int b = 0xFF & byteBuffer[p];
/*      */         
/*  225 */         if ((b > 32) && (b < 127)) {
/*  226 */           outputBuilder.append((char)b + " ");
/*      */         } else {
/*  228 */           outputBuilder.append(". ");
/*      */         }
/*      */         
/*  231 */         p++;
/*      */       }
/*      */       
/*  234 */       outputBuilder.append("\n");
/*      */     }
/*      */     
/*  237 */     int n = 0;
/*      */     
/*  239 */     for (int i = p; i < length; i++) {
/*  240 */       String hexVal = Integer.toHexString(byteBuffer[i] & 0xFF);
/*      */       
/*  242 */       if (hexVal.length() == 1) {
/*  243 */         hexVal = "0" + hexVal;
/*      */       }
/*      */       
/*  246 */       outputBuilder.append(hexVal + " ");
/*  247 */       n++;
/*      */     }
/*      */     
/*  250 */     for (int i = n; i < 8; i++) {
/*  251 */       outputBuilder.append("   ");
/*      */     }
/*      */     
/*  254 */     outputBuilder.append("    ");
/*      */     
/*  256 */     for (int i = p; i < length; i++) {
/*  257 */       int b = 0xFF & byteBuffer[i];
/*      */       
/*  259 */       if ((b > 32) && (b < 127)) {
/*  260 */         outputBuilder.append((char)b + " ");
/*      */       } else {
/*  262 */         outputBuilder.append(". ");
/*      */       }
/*      */     }
/*      */     
/*  266 */     outputBuilder.append("\n");
/*      */     
/*  268 */     return outputBuilder.toString();
/*      */   }
/*      */   
/*      */   private static boolean endsWith(byte[] dataFrom, String suffix) {
/*  272 */     for (int i = 1; i <= suffix.length(); i++) {
/*  273 */       int dfOffset = dataFrom.length - i;
/*  274 */       int suffixOffset = suffix.length() - i;
/*  275 */       if (dataFrom[dfOffset] != suffix.charAt(suffixOffset)) {
/*  276 */         return false;
/*      */       }
/*      */     }
/*  279 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] escapeEasternUnicodeByteStream(byte[] origBytes, String origString)
/*      */   {
/*  294 */     if (origBytes == null) {
/*  295 */       return null;
/*      */     }
/*  297 */     if (origBytes.length == 0) {
/*  298 */       return new byte[0];
/*      */     }
/*      */     
/*  301 */     int bytesLen = origBytes.length;
/*  302 */     int bufIndex = 0;
/*  303 */     int strIndex = 0;
/*      */     
/*  305 */     ByteArrayOutputStream bytesOut = new ByteArrayOutputStream(bytesLen);
/*      */     for (;;)
/*      */     {
/*  308 */       if (origString.charAt(strIndex) == '\\')
/*      */       {
/*  310 */         bytesOut.write(origBytes[(bufIndex++)]);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  315 */         int loByte = origBytes[bufIndex];
/*      */         
/*  317 */         if (loByte < 0) {
/*  318 */           loByte += 256;
/*      */         }
/*      */         
/*      */ 
/*  322 */         bytesOut.write(loByte);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  340 */         if (loByte >= 128) {
/*  341 */           if (bufIndex < bytesLen - 1) {
/*  342 */             int hiByte = origBytes[(bufIndex + 1)];
/*      */             
/*  344 */             if (hiByte < 0) {
/*  345 */               hiByte += 256;
/*      */             }
/*      */             
/*      */ 
/*  349 */             bytesOut.write(hiByte);
/*  350 */             bufIndex++;
/*      */             
/*      */ 
/*  353 */             if (hiByte == 92) {
/*  354 */               bytesOut.write(hiByte);
/*      */             }
/*      */           }
/*  357 */         } else if ((loByte == 92) && 
/*  358 */           (bufIndex < bytesLen - 1)) {
/*  359 */           int hiByte = origBytes[(bufIndex + 1)];
/*      */           
/*  361 */           if (hiByte < 0) {
/*  362 */             hiByte += 256;
/*      */           }
/*      */           
/*  365 */           if (hiByte == 98)
/*      */           {
/*  367 */             bytesOut.write(92);
/*  368 */             bytesOut.write(98);
/*  369 */             bufIndex++;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  374 */         bufIndex++;
/*      */       }
/*      */       
/*  377 */       if (bufIndex >= bytesLen) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  382 */       strIndex++;
/*      */     }
/*      */     
/*  385 */     return bytesOut.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static char firstNonWsCharUc(String searchIn)
/*      */   {
/*  397 */     return firstNonWsCharUc(searchIn, 0);
/*      */   }
/*      */   
/*      */   public static char firstNonWsCharUc(String searchIn, int startAt) {
/*  401 */     if (searchIn == null) {
/*  402 */       return '\000';
/*      */     }
/*      */     
/*  405 */     int length = searchIn.length();
/*      */     
/*  407 */     for (int i = startAt; i < length; i++) {
/*  408 */       char c = searchIn.charAt(i);
/*      */       
/*  410 */       if (!Character.isWhitespace(c)) {
/*  411 */         return Character.toUpperCase(c);
/*      */       }
/*      */     }
/*      */     
/*  415 */     return '\000';
/*      */   }
/*      */   
/*      */   public static char firstAlphaCharUc(String searchIn, int startAt) {
/*  419 */     if (searchIn == null) {
/*  420 */       return '\000';
/*      */     }
/*      */     
/*  423 */     int length = searchIn.length();
/*      */     
/*  425 */     for (int i = startAt; i < length; i++) {
/*  426 */       char c = searchIn.charAt(i);
/*      */       
/*  428 */       if (Character.isLetter(c)) {
/*  429 */         return Character.toUpperCase(c);
/*      */       }
/*      */     }
/*      */     
/*  433 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String fixDecimalExponent(String dString)
/*      */   {
/*  446 */     int ePos = dString.indexOf('E');
/*      */     
/*  448 */     if (ePos == -1) {
/*  449 */       ePos = dString.indexOf('e');
/*      */     }
/*      */     
/*  452 */     if ((ePos != -1) && 
/*  453 */       (dString.length() > ePos + 1)) {
/*  454 */       char maybeMinusChar = dString.charAt(ePos + 1);
/*      */       
/*  456 */       if ((maybeMinusChar != '-') && (maybeMinusChar != '+')) {
/*  457 */         StringBuilder strBuilder = new StringBuilder(dString.length() + 1);
/*  458 */         strBuilder.append(dString.substring(0, ePos + 1));
/*  459 */         strBuilder.append('+');
/*  460 */         strBuilder.append(dString.substring(ePos + 1, dString.length()));
/*  461 */         dString = strBuilder.toString();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  466 */     return dString;
/*      */   }
/*      */   
/*      */ 
/*      */   public static byte[] getBytes(char[] c, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       byte[] b;
/*      */       
/*      */       byte[] b;
/*  478 */       if (converter != null) {
/*  479 */         b = converter.toBytes(c); } else { byte[] b;
/*  480 */         if (encoding == null) {
/*  481 */           b = getBytes(c);
/*      */         } else {
/*  483 */           b = getBytes(c, encoding);
/*      */           
/*  485 */           if ((!parserKnowsUnicode) && (CharsetMapping.requiresEscapeEasternUnicode(encoding)))
/*      */           {
/*  487 */             if (encoding.equalsIgnoreCase(serverEncoding)) {} } } }
/*  488 */       return escapeEasternUnicodeByteStream(b, new String(c));
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  495 */       throw SQLError.createSQLException(Messages.getString("StringUtils.0") + encoding + Messages.getString("StringUtils.1"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static byte[] getBytes(char[] c, SingleByteCharsetConverter converter, String encoding, String serverEncoding, int offset, int length, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       byte[] b;
/*      */       
/*      */       byte[] b;
/*      */       
/*  509 */       if (converter != null) {
/*  510 */         b = converter.toBytes(c, offset, length); } else { byte[] b;
/*  511 */         if (encoding == null) {
/*  512 */           b = getBytes(c, offset, length);
/*      */         } else {
/*  514 */           b = getBytes(c, offset, length, encoding);
/*      */           
/*  516 */           if ((!parserKnowsUnicode) && (CharsetMapping.requiresEscapeEasternUnicode(encoding)))
/*      */           {
/*  518 */             if (encoding.equalsIgnoreCase(serverEncoding)) {} } } }
/*  519 */       return escapeEasternUnicodeByteStream(b, new String(c, offset, length));
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  526 */       throw SQLError.createSQLException(Messages.getString("StringUtils.0") + encoding + Messages.getString("StringUtils.1"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] getBytes(char[] c, String encoding, String serverEncoding, boolean parserKnowsUnicode, MySQLConnection conn, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  538 */       SingleByteCharsetConverter converter = conn != null ? conn.getCharsetConverter(encoding) : SingleByteCharsetConverter.getInstance(encoding, null);
/*      */       
/*  540 */       return getBytes(c, converter, encoding, serverEncoding, parserKnowsUnicode, exceptionInterceptor);
/*      */     } catch (UnsupportedEncodingException uee) {
/*  542 */       throw SQLError.createSQLException(Messages.getString("StringUtils.0") + encoding + Messages.getString("StringUtils.1"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static byte[] getBytes(String s, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       byte[] b;
/*      */       
/*      */       byte[] b;
/*      */       
/*  556 */       if (converter != null) {
/*  557 */         b = converter.toBytes(s); } else { byte[] b;
/*  558 */         if (encoding == null) {
/*  559 */           b = getBytes(s);
/*      */         } else {
/*  561 */           b = getBytes(s, encoding);
/*      */           
/*  563 */           if ((!parserKnowsUnicode) && (CharsetMapping.requiresEscapeEasternUnicode(encoding)))
/*      */           {
/*  565 */             if (encoding.equalsIgnoreCase(serverEncoding)) {} } } }
/*  566 */       return escapeEasternUnicodeByteStream(b, s);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  573 */       throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static byte[] getBytes(String s, SingleByteCharsetConverter converter, String encoding, String serverEncoding, int offset, int length, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       byte[] b;
/*      */       
/*      */       byte[] b;
/*      */       
/*  587 */       if (converter != null) {
/*  588 */         b = converter.toBytes(s, offset, length); } else { byte[] b;
/*  589 */         if (encoding == null) {
/*  590 */           b = getBytes(s, offset, length);
/*      */         } else {
/*  592 */           s = s.substring(offset, offset + length);
/*  593 */           b = getBytes(s, encoding);
/*      */           
/*  595 */           if ((!parserKnowsUnicode) && (CharsetMapping.requiresEscapeEasternUnicode(encoding)))
/*      */           {
/*  597 */             if (encoding.equalsIgnoreCase(serverEncoding)) {} } } }
/*  598 */       return escapeEasternUnicodeByteStream(b, s);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  605 */       throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] getBytes(String s, String encoding, String serverEncoding, boolean parserKnowsUnicode, MySQLConnection conn, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  617 */       SingleByteCharsetConverter converter = conn != null ? conn.getCharsetConverter(encoding) : SingleByteCharsetConverter.getInstance(encoding, null);
/*      */       
/*  619 */       return getBytes(s, converter, encoding, serverEncoding, parserKnowsUnicode, exceptionInterceptor);
/*      */     } catch (UnsupportedEncodingException uee) {
/*  621 */       throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte[] getBytes(String s, String encoding, String serverEncoding, int offset, int length, boolean parserKnowsUnicode, MySQLConnection conn, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  633 */       SingleByteCharsetConverter converter = conn != null ? conn.getCharsetConverter(encoding) : SingleByteCharsetConverter.getInstance(encoding, null);
/*      */       
/*  635 */       return getBytes(s, converter, encoding, serverEncoding, offset, length, parserKnowsUnicode, exceptionInterceptor);
/*      */     } catch (UnsupportedEncodingException uee) {
/*  637 */       throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static byte[] getBytesWrapped(String s, char beginWrap, char endWrap, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       byte[] b;
/*      */       
/*      */       byte[] b;
/*      */       
/*  651 */       if (converter != null) {
/*  652 */         b = converter.toBytesWrapped(s, beginWrap, endWrap); } else { byte[] b;
/*  653 */         if (encoding == null) {
/*  654 */           StringBuilder strBuilder = new StringBuilder(s.length() + 2);
/*  655 */           strBuilder.append(beginWrap);
/*  656 */           strBuilder.append(s);
/*  657 */           strBuilder.append(endWrap);
/*      */           
/*  659 */           b = getBytes(strBuilder.toString());
/*      */         } else {
/*  661 */           StringBuilder strBuilder = new StringBuilder(s.length() + 2);
/*  662 */           strBuilder.append(beginWrap);
/*  663 */           strBuilder.append(s);
/*  664 */           strBuilder.append(endWrap);
/*      */           
/*  666 */           s = strBuilder.toString();
/*  667 */           b = getBytes(s, encoding);
/*      */           
/*  669 */           if ((!parserKnowsUnicode) && (CharsetMapping.requiresEscapeEasternUnicode(encoding)))
/*      */           {
/*  671 */             if (encoding.equalsIgnoreCase(serverEncoding)) {} } } }
/*  672 */       return escapeEasternUnicodeByteStream(b, s);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  679 */       throw SQLError.createSQLException(Messages.getString("StringUtils.10") + encoding + Messages.getString("StringUtils.11"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */   public static int getInt(byte[] buf) throws NumberFormatException
/*      */   {
/*  685 */     return getInt(buf, 0, buf.length);
/*      */   }
/*      */   
/*      */   public static int getInt(byte[] buf, int offset, int endPos) throws NumberFormatException {
/*  689 */     int base = 10;
/*      */     
/*  691 */     int s = offset;
/*      */     
/*      */ 
/*  694 */     while ((s < endPos) && (Character.isWhitespace((char)buf[s]))) {
/*  695 */       s++;
/*      */     }
/*      */     
/*  698 */     if (s == endPos) {
/*  699 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  703 */     boolean negative = false;
/*      */     
/*  705 */     if ((char)buf[s] == '-') {
/*  706 */       negative = true;
/*  707 */       s++;
/*  708 */     } else if ((char)buf[s] == '+') {
/*  709 */       s++;
/*      */     }
/*      */     
/*      */ 
/*  713 */     int save = s;
/*      */     
/*  715 */     int cutoff = Integer.MAX_VALUE / base;
/*  716 */     int cutlim = Integer.MAX_VALUE % base;
/*      */     
/*  718 */     if (negative) {
/*  719 */       cutlim++;
/*      */     }
/*      */     
/*  722 */     boolean overflow = false;
/*      */     
/*  724 */     int i = 0;
/*  726 */     for (; 
/*  726 */         s < endPos; s++) {
/*  727 */       char c = (char)buf[s];
/*      */       
/*  729 */       if (Character.isDigit(c)) {
/*  730 */         c = (char)(c - '0');
/*  731 */       } else { if (!Character.isLetter(c)) break;
/*  732 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  737 */       if (c >= base) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  742 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  743 */         overflow = true;
/*      */       } else {
/*  745 */         i *= base;
/*  746 */         i += c;
/*      */       }
/*      */     }
/*      */     
/*  750 */     if (s == save) {
/*  751 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*  754 */     if (overflow) {
/*  755 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  759 */     return negative ? -i : i;
/*      */   }
/*      */   
/*      */   public static long getLong(byte[] buf) throws NumberFormatException {
/*  763 */     return getLong(buf, 0, buf.length);
/*      */   }
/*      */   
/*      */   public static long getLong(byte[] buf, int offset, int endpos) throws NumberFormatException {
/*  767 */     int base = 10;
/*      */     
/*  769 */     int s = offset;
/*      */     
/*      */ 
/*  772 */     while ((s < endpos) && (Character.isWhitespace((char)buf[s]))) {
/*  773 */       s++;
/*      */     }
/*      */     
/*  776 */     if (s == endpos) {
/*  777 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  781 */     boolean negative = false;
/*      */     
/*  783 */     if ((char)buf[s] == '-') {
/*  784 */       negative = true;
/*  785 */       s++;
/*  786 */     } else if ((char)buf[s] == '+') {
/*  787 */       s++;
/*      */     }
/*      */     
/*      */ 
/*  791 */     int save = s;
/*      */     
/*  793 */     long cutoff = Long.MAX_VALUE / base;
/*  794 */     long cutlim = (int)(Long.MAX_VALUE % base);
/*      */     
/*  796 */     if (negative) {
/*  797 */       cutlim += 1L;
/*      */     }
/*      */     
/*  800 */     boolean overflow = false;
/*  801 */     long i = 0L;
/*  803 */     for (; 
/*  803 */         s < endpos; s++) {
/*  804 */       char c = (char)buf[s];
/*      */       
/*  806 */       if (Character.isDigit(c)) {
/*  807 */         c = (char)(c - '0');
/*  808 */       } else { if (!Character.isLetter(c)) break;
/*  809 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  814 */       if (c >= base) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  819 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  820 */         overflow = true;
/*      */       } else {
/*  822 */         i *= base;
/*  823 */         i += c;
/*      */       }
/*      */     }
/*      */     
/*  827 */     if (s == save) {
/*  828 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*  831 */     if (overflow) {
/*  832 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  836 */     return negative ? -i : i;
/*      */   }
/*      */   
/*      */   public static short getShort(byte[] buf) throws NumberFormatException {
/*  840 */     return getShort(buf, 0, buf.length);
/*      */   }
/*      */   
/*      */   public static short getShort(byte[] buf, int offset, int endpos) throws NumberFormatException {
/*  844 */     short base = 10;
/*      */     
/*  846 */     int s = offset;
/*      */     
/*      */ 
/*  849 */     while ((s < endpos) && (Character.isWhitespace((char)buf[s]))) {
/*  850 */       s++;
/*      */     }
/*      */     
/*  853 */     if (s == endpos) {
/*  854 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  858 */     boolean negative = false;
/*      */     
/*  860 */     if ((char)buf[s] == '-') {
/*  861 */       negative = true;
/*  862 */       s++;
/*  863 */     } else if ((char)buf[s] == '+') {
/*  864 */       s++;
/*      */     }
/*      */     
/*      */ 
/*  868 */     int save = s;
/*      */     
/*  870 */     short cutoff = (short)(Short.MAX_VALUE / base);
/*  871 */     short cutlim = (short)(Short.MAX_VALUE % base);
/*      */     
/*  873 */     if (negative) {
/*  874 */       cutlim = (short)(cutlim + 1);
/*      */     }
/*      */     
/*  877 */     boolean overflow = false;
/*  878 */     short i = 0;
/*  880 */     for (; 
/*  880 */         s < endpos; s++) {
/*  881 */       char c = (char)buf[s];
/*      */       
/*  883 */       if (Character.isDigit(c)) {
/*  884 */         c = (char)(c - '0');
/*  885 */       } else { if (!Character.isLetter(c)) break;
/*  886 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  891 */       if (c >= base) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  896 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  897 */         overflow = true;
/*      */       } else {
/*  899 */         i = (short)(i * base);
/*  900 */         i = (short)(i + c);
/*      */       }
/*      */     }
/*      */     
/*  904 */     if (s == save) {
/*  905 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*  908 */     if (overflow) {
/*  909 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  913 */     return negative ? (short)-i : i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfIgnoreCase(String searchIn, String searchFor)
/*      */   {
/*  926 */     return indexOfIgnoreCase(0, searchIn, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfIgnoreCase(int startingPosition, String searchIn, String searchFor)
/*      */   {
/*  941 */     if ((searchIn == null) || (searchFor == null)) {
/*  942 */       return -1;
/*      */     }
/*      */     
/*  945 */     int searchInLength = searchIn.length();
/*  946 */     int searchForLength = searchFor.length();
/*  947 */     int stopSearchingAt = searchInLength - searchForLength;
/*      */     
/*  949 */     if ((startingPosition > stopSearchingAt) || (searchForLength == 0)) {
/*  950 */       return -1;
/*      */     }
/*      */     
/*      */ 
/*  954 */     char firstCharOfSearchForUc = Character.toUpperCase(searchFor.charAt(0));
/*  955 */     char firstCharOfSearchForLc = Character.toLowerCase(searchFor.charAt(0));
/*      */     
/*  957 */     for (int i = startingPosition; i <= stopSearchingAt; i++) {
/*  958 */       if (isCharAtPosNotEqualIgnoreCase(searchIn, i, firstCharOfSearchForUc, firstCharOfSearchForLc)) {
/*      */         do {
/*  960 */           i++; } while ((i <= stopSearchingAt) && (isCharAtPosNotEqualIgnoreCase(searchIn, i, firstCharOfSearchForUc, firstCharOfSearchForLc)));
/*      */       }
/*      */       
/*      */ 
/*  964 */       if ((i <= stopSearchingAt) && (startsWithIgnoreCase(searchIn, i, searchFor))) {
/*  965 */         return i;
/*      */       }
/*      */     }
/*      */     
/*  969 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfIgnoreCase(int startingPosition, String searchIn, String[] searchForSequence, String openingMarkers, String closingMarkers, Set<SearchMode> searchMode)
/*      */   {
/*  997 */     if ((searchIn == null) || (searchForSequence == null)) {
/*  998 */       return -1;
/*      */     }
/*      */     
/* 1001 */     int searchInLength = searchIn.length();
/* 1002 */     int searchForLength = 0;
/* 1003 */     for (String searchForPart : searchForSequence) {
/* 1004 */       searchForLength += searchForPart.length();
/*      */     }
/*      */     
/* 1007 */     if (searchForLength == 0) {
/* 1008 */       return -1;
/*      */     }
/*      */     
/* 1011 */     int searchForWordsCount = searchForSequence.length;
/* 1012 */     searchForLength += (searchForWordsCount > 0 ? searchForWordsCount - 1 : 0);
/* 1013 */     int stopSearchingAt = searchInLength - searchForLength;
/*      */     
/* 1015 */     if (startingPosition > stopSearchingAt) {
/* 1016 */       return -1;
/*      */     }
/*      */     
/* 1019 */     if ((searchMode.contains(SearchMode.SKIP_BETWEEN_MARKERS)) && ((openingMarkers == null) || (closingMarkers == null) || (openingMarkers.length() != closingMarkers.length())))
/*      */     {
/* 1021 */       throw new IllegalArgumentException(Messages.getString("StringUtils.15", new String[] { openingMarkers, closingMarkers }));
/*      */     }
/*      */     
/* 1024 */     if ((Character.isWhitespace(searchForSequence[0].charAt(0))) && (searchMode.contains(SearchMode.SKIP_WHITE_SPACE)))
/*      */     {
/* 1026 */       searchMode = EnumSet.copyOf(searchMode);
/* 1027 */       searchMode.remove(SearchMode.SKIP_WHITE_SPACE);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1032 */     Set<SearchMode> searchMode2 = EnumSet.of(SearchMode.SKIP_WHITE_SPACE);
/* 1033 */     searchMode2.addAll(searchMode);
/* 1034 */     searchMode2.remove(SearchMode.SKIP_BETWEEN_MARKERS);
/*      */     
/* 1036 */     for (int positionOfFirstWord = startingPosition; positionOfFirstWord <= stopSearchingAt; positionOfFirstWord++) {
/* 1037 */       positionOfFirstWord = indexOfIgnoreCase(positionOfFirstWord, searchIn, searchForSequence[0], openingMarkers, closingMarkers, searchMode);
/*      */       
/* 1039 */       if ((positionOfFirstWord == -1) || (positionOfFirstWord > stopSearchingAt)) {
/* 1040 */         return -1;
/*      */       }
/*      */       
/* 1043 */       int startingPositionForNextWord = positionOfFirstWord + searchForSequence[0].length();
/* 1044 */       int wc = 0;
/* 1045 */       boolean match = true;
/* 1046 */       for (;;) { wc++; if ((wc >= searchForWordsCount) || (!match)) break;
/* 1047 */         int positionOfNextWord = indexOfNextChar(startingPositionForNextWord, searchInLength - 1, searchIn, null, null, searchMode2);
/* 1048 */         if ((startingPositionForNextWord == positionOfNextWord) || (!startsWithIgnoreCase(searchIn, positionOfNextWord, searchForSequence[wc])))
/*      */         {
/* 1050 */           match = false;
/*      */         } else {
/* 1052 */           startingPositionForNextWord = positionOfNextWord + searchForSequence[wc].length();
/*      */         }
/*      */       }
/*      */       
/* 1056 */       if (match) {
/* 1057 */         return positionOfFirstWord;
/*      */       }
/*      */     }
/*      */     
/* 1061 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfIgnoreCase(int startingPosition, String searchIn, String searchFor, String openingMarkers, String closingMarkers, Set<SearchMode> searchMode)
/*      */   {
/* 1084 */     if ((searchIn == null) || (searchFor == null)) {
/* 1085 */       return -1;
/*      */     }
/*      */     
/* 1088 */     int searchInLength = searchIn.length();
/* 1089 */     int searchForLength = searchFor.length();
/* 1090 */     int stopSearchingAt = searchInLength - searchForLength;
/*      */     
/* 1092 */     if ((startingPosition > stopSearchingAt) || (searchForLength == 0)) {
/* 1093 */       return -1;
/*      */     }
/*      */     
/* 1096 */     if ((searchMode.contains(SearchMode.SKIP_BETWEEN_MARKERS)) && ((openingMarkers == null) || (closingMarkers == null) || (openingMarkers.length() != closingMarkers.length())))
/*      */     {
/* 1098 */       throw new IllegalArgumentException(Messages.getString("StringUtils.15", new String[] { openingMarkers, closingMarkers }));
/*      */     }
/*      */     
/*      */ 
/* 1102 */     char firstCharOfSearchForUc = Character.toUpperCase(searchFor.charAt(0));
/* 1103 */     char firstCharOfSearchForLc = Character.toLowerCase(searchFor.charAt(0));
/*      */     
/* 1105 */     if ((Character.isWhitespace(firstCharOfSearchForLc)) && (searchMode.contains(SearchMode.SKIP_WHITE_SPACE)))
/*      */     {
/* 1107 */       searchMode = EnumSet.copyOf(searchMode);
/* 1108 */       searchMode.remove(SearchMode.SKIP_WHITE_SPACE);
/*      */     }
/*      */     
/* 1111 */     for (int i = startingPosition; i <= stopSearchingAt; i++) {
/* 1112 */       i = indexOfNextChar(i, stopSearchingAt, searchIn, openingMarkers, closingMarkers, searchMode);
/*      */       
/* 1114 */       if (i == -1) {
/* 1115 */         return -1;
/*      */       }
/*      */       
/* 1118 */       char c = searchIn.charAt(i);
/*      */       
/* 1120 */       if ((isCharEqualIgnoreCase(c, firstCharOfSearchForUc, firstCharOfSearchForLc)) && (startsWithIgnoreCase(searchIn, i, searchFor))) {
/* 1121 */         return i;
/*      */       }
/*      */     }
/*      */     
/* 1125 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int indexOfNextChar(int startingPosition, int stopPosition, String searchIn, String openingMarkers, String closingMarkers, Set<SearchMode> searchMode)
/*      */   {
/* 1148 */     if (searchIn == null) {
/* 1149 */       return -1;
/*      */     }
/*      */     
/* 1152 */     int searchInLength = searchIn.length();
/*      */     
/* 1154 */     if (startingPosition >= searchInLength) {
/* 1155 */       return -1;
/*      */     }
/*      */     
/* 1158 */     char c0 = '\000';
/* 1159 */     char c1 = searchIn.charAt(startingPosition);
/* 1160 */     char c2 = startingPosition + 1 < searchInLength ? searchIn.charAt(startingPosition + 1) : '\000';
/*      */     
/* 1162 */     for (int i = startingPosition; i <= stopPosition; i++) {
/* 1163 */       c0 = c1;
/* 1164 */       c1 = c2;
/* 1165 */       c2 = i + 2 < searchInLength ? searchIn.charAt(i + 2) : '\000';
/*      */       
/* 1167 */       boolean dashDashCommentImmediateEnd = false;
/* 1168 */       int markerIndex = -1;
/*      */       
/* 1170 */       if ((searchMode.contains(SearchMode.ALLOW_BACKSLASH_ESCAPE)) && (c0 == '\\')) {
/* 1171 */         i++;
/*      */         
/* 1173 */         c1 = c2;
/* 1174 */         c2 = i + 2 < searchInLength ? searchIn.charAt(i + 2) : '\000';
/*      */       }
/* 1176 */       else if ((searchMode.contains(SearchMode.SKIP_BETWEEN_MARKERS)) && ((markerIndex = openingMarkers.indexOf(c0)) != -1))
/*      */       {
/* 1178 */         int nestedMarkersCount = 0;
/* 1179 */         char openingMarker = c0;
/* 1180 */         char closingMarker = closingMarkers.charAt(markerIndex);
/* 1181 */         for (;;) { i++; if ((i > stopPosition) || (((c0 = searchIn.charAt(i)) == closingMarker) && (nestedMarkersCount == 0))) break;
/* 1182 */           if (c0 == openingMarker) {
/* 1183 */             nestedMarkersCount++;
/* 1184 */           } else if (c0 == closingMarker) {
/* 1185 */             nestedMarkersCount--;
/* 1186 */           } else if ((searchMode.contains(SearchMode.ALLOW_BACKSLASH_ESCAPE)) && (c0 == '\\')) {
/* 1187 */             i++;
/*      */           }
/*      */         }
/*      */         
/* 1191 */         c1 = i + 1 < searchInLength ? searchIn.charAt(i + 1) : '\000';
/* 1192 */         c2 = i + 2 < searchInLength ? searchIn.charAt(i + 2) : '\000';
/*      */       }
/* 1194 */       else if ((searchMode.contains(SearchMode.SKIP_BLOCK_COMMENTS)) && (c0 == '/') && (c1 == '*')) {
/* 1195 */         if (c2 != '!')
/*      */         {
/* 1197 */           i++;
/* 1198 */           do { do { i++; if (i > stopPosition) break; } while (searchIn.charAt(i) != '*'); } while ((i + 1 < searchInLength ? searchIn.charAt(i + 1) : 0) != 47);
/*      */           
/*      */ 
/* 1201 */           i++;
/*      */         }
/*      */         else
/*      */         {
/* 1205 */           i++;
/* 1206 */           i++;
/*      */           
/* 1208 */           for (int j = 1; 
/* 1209 */               j <= 5; j++) {
/* 1210 */             if ((i + j >= searchInLength) || (!Character.isDigit(searchIn.charAt(i + j)))) {
/*      */               break;
/*      */             }
/*      */           }
/* 1214 */           if (j == 5) {
/* 1215 */             i += 5;
/*      */           }
/*      */         }
/*      */         
/* 1219 */         c1 = i + 1 < searchInLength ? searchIn.charAt(i + 1) : '\000';
/* 1220 */         c2 = i + 2 < searchInLength ? searchIn.charAt(i + 2) : '\000';
/*      */       }
/* 1222 */       else if ((searchMode.contains(SearchMode.SKIP_BLOCK_COMMENTS)) && (c0 == '*') && (c1 == '/'))
/*      */       {
/*      */ 
/* 1225 */         i++;
/*      */         
/* 1227 */         c1 = c2;
/* 1228 */         c2 = i + 2 < searchInLength ? searchIn.charAt(i + 2) : '\000';
/*      */       } else {
/* 1230 */         if (searchMode.contains(SearchMode.SKIP_LINE_COMMENTS)) { if ((c0 == '-') && (c1 == '-')) { if (!Character.isWhitespace(c2)) if (((dashDashCommentImmediateEnd = c2 == ';' ? 1 : 0) != 0) || (c2 == 0)) {} } else if (c0 != '#')
/*      */               break label827;
/* 1232 */           if (dashDashCommentImmediateEnd)
/*      */           {
/* 1234 */             i++;
/* 1235 */             i++;
/*      */             
/* 1237 */             c1 = i + 1 < searchInLength ? searchIn.charAt(i + 1) : '\000';
/* 1238 */             c2 = i + 2 < searchInLength ? searchIn.charAt(i + 2) : '\000'; continue;
/*      */           }
/*      */           do {
/* 1241 */             i++; } while ((i <= stopPosition) && ((c0 = searchIn.charAt(i)) != '\n') && (c0 != '\r'));
/*      */           
/*      */ 
/*      */ 
/* 1245 */           c1 = i + 1 < searchInLength ? searchIn.charAt(i + 1) : '\000';
/* 1246 */           if ((c0 == '\r') && (c1 == '\n'))
/*      */           {
/* 1248 */             i++;
/* 1249 */             c1 = i + 1 < searchInLength ? searchIn.charAt(i + 1) : '\000';
/*      */           }
/* 1251 */           c2 = i + 2 < searchInLength ? searchIn.charAt(i + 2) : '\000'; continue;
/*      */         }
/*      */         label827:
/* 1254 */         if ((!searchMode.contains(SearchMode.SKIP_WHITE_SPACE)) || (!Character.isWhitespace(c0))) {
/* 1255 */           return i;
/*      */         }
/*      */       }
/*      */     }
/* 1259 */     return -1;
/*      */   }
/*      */   
/*      */   private static boolean isCharAtPosNotEqualIgnoreCase(String searchIn, int pos, char firstCharOfSearchForUc, char firstCharOfSearchForLc) {
/* 1263 */     return (Character.toLowerCase(searchIn.charAt(pos)) != firstCharOfSearchForLc) && (Character.toUpperCase(searchIn.charAt(pos)) != firstCharOfSearchForUc);
/*      */   }
/*      */   
/*      */   private static boolean isCharEqualIgnoreCase(char charToCompare, char compareToCharUC, char compareToCharLC) {
/* 1267 */     return (Character.toLowerCase(charToCompare) == compareToCharLC) || (Character.toUpperCase(charToCompare) == compareToCharUC);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<String> split(String stringToSplit, String delimiter, boolean trim)
/*      */   {
/* 1285 */     if (stringToSplit == null) {
/* 1286 */       return new ArrayList();
/*      */     }
/*      */     
/* 1289 */     if (delimiter == null) {
/* 1290 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1293 */     StringTokenizer tokenizer = new StringTokenizer(stringToSplit, delimiter, false);
/*      */     
/* 1295 */     List<String> splitTokens = new ArrayList(tokenizer.countTokens());
/*      */     
/* 1297 */     while (tokenizer.hasMoreTokens()) {
/* 1298 */       String token = tokenizer.nextToken();
/*      */       
/* 1300 */       if (trim) {
/* 1301 */         token = token.trim();
/*      */       }
/*      */       
/* 1304 */       splitTokens.add(token);
/*      */     }
/*      */     
/* 1307 */     return splitTokens;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<String> split(String stringToSplit, String delimiter, String markers, String markerCloses, boolean trim)
/*      */   {
/* 1325 */     if (stringToSplit == null) {
/* 1326 */       return new ArrayList();
/*      */     }
/*      */     
/* 1329 */     if (delimiter == null) {
/* 1330 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1333 */     int delimPos = 0;
/* 1334 */     int currentPos = 0;
/*      */     
/* 1336 */     List<String> splitTokens = new ArrayList();
/*      */     
/* 1338 */     while ((delimPos = indexOfIgnoreCase(currentPos, stringToSplit, delimiter, markers, markerCloses, SEARCH_MODE__MRK_COM_WS)) != -1) {
/* 1339 */       String token = stringToSplit.substring(currentPos, delimPos);
/*      */       
/* 1341 */       if (trim) {
/* 1342 */         token = token.trim();
/*      */       }
/*      */       
/* 1345 */       splitTokens.add(token);
/* 1346 */       currentPos = delimPos + 1;
/*      */     }
/*      */     
/* 1349 */     if (currentPos < stringToSplit.length()) {
/* 1350 */       String token = stringToSplit.substring(currentPos);
/*      */       
/* 1352 */       if (trim) {
/* 1353 */         token = token.trim();
/*      */       }
/*      */       
/* 1356 */       splitTokens.add(token);
/*      */     }
/*      */     
/* 1359 */     return splitTokens;
/*      */   }
/*      */   
/*      */   private static boolean startsWith(byte[] dataFrom, String chars) {
/* 1363 */     int charsLength = chars.length();
/*      */     
/* 1365 */     if (dataFrom.length < charsLength) {
/* 1366 */       return false;
/*      */     }
/* 1368 */     for (int i = 0; i < charsLength; i++) {
/* 1369 */       if (dataFrom[i] != chars.charAt(i)) {
/* 1370 */         return false;
/*      */       }
/*      */     }
/* 1373 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String searchIn, int startAt, String searchFor)
/*      */   {
/* 1391 */     return searchIn.regionMatches(true, startAt, searchFor, 0, searchFor.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String searchIn, String searchFor)
/*      */   {
/* 1406 */     return startsWithIgnoreCase(searchIn, 0, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndNonAlphaNumeric(String searchIn, String searchFor)
/*      */   {
/* 1422 */     if (searchIn == null) {
/* 1423 */       return searchFor == null;
/*      */     }
/*      */     
/* 1426 */     int beginPos = 0;
/* 1427 */     int inLength = searchIn.length();
/* 1429 */     for (; 
/* 1429 */         beginPos < inLength; beginPos++) {
/* 1430 */       char c = searchIn.charAt(beginPos);
/* 1431 */       if (Character.isLetterOrDigit(c)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 1436 */     return startsWithIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor)
/*      */   {
/* 1451 */     return startsWithIgnoreCaseAndWs(searchIn, searchFor, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor, int beginPos)
/*      */   {
/* 1469 */     if (searchIn == null) {
/* 1470 */       return searchFor == null;
/*      */     }
/*      */     
/* 1473 */     int inLength = searchIn.length();
/* 1475 */     for (; 
/* 1475 */         beginPos < inLength; beginPos++) {
/* 1476 */       if (!Character.isWhitespace(searchIn.charAt(beginPos))) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 1481 */     return startsWithIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int startsWithIgnoreCaseAndWs(String searchIn, String[] searchFor)
/*      */   {
/* 1496 */     for (int i = 0; i < searchFor.length; i++) {
/* 1497 */       if (startsWithIgnoreCaseAndWs(searchIn, searchFor[i], 0)) {
/* 1498 */         return i;
/*      */       }
/*      */     }
/* 1501 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] stripEnclosure(byte[] source, String prefix, String suffix)
/*      */   {
/* 1510 */     if ((source.length >= prefix.length() + suffix.length()) && (startsWith(source, prefix)) && (endsWith(source, suffix)))
/*      */     {
/* 1512 */       int totalToStrip = prefix.length() + suffix.length();
/* 1513 */       int enclosedLength = source.length - totalToStrip;
/* 1514 */       byte[] enclosed = new byte[enclosedLength];
/*      */       
/* 1516 */       int startPos = prefix.length();
/* 1517 */       int numToCopy = enclosed.length;
/* 1518 */       System.arraycopy(source, startPos, enclosed, 0, numToCopy);
/*      */       
/* 1520 */       return enclosed;
/*      */     }
/* 1522 */     return source;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String toAsciiString(byte[] buffer)
/*      */   {
/* 1534 */     return toAsciiString(buffer, 0, buffer.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String toAsciiString(byte[] buffer, int startPos, int length)
/*      */   {
/* 1550 */     char[] charArray = new char[length];
/* 1551 */     int readpoint = startPos;
/*      */     
/* 1553 */     for (int i = 0; i < length; i++) {
/* 1554 */       charArray[i] = ((char)buffer[readpoint]);
/* 1555 */       readpoint++;
/*      */     }
/*      */     
/* 1558 */     return new String(charArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int wildCompare(String searchIn, String searchForWildcard)
/*      */   {
/* 1576 */     if ((searchIn == null) || (searchForWildcard == null)) {
/* 1577 */       return -1;
/*      */     }
/*      */     
/* 1580 */     if (searchForWildcard.equals("%"))
/*      */     {
/* 1582 */       return 1;
/*      */     }
/*      */     
/* 1585 */     int result = -1;
/*      */     
/* 1587 */     char wildcardMany = '%';
/* 1588 */     char wildcardOne = '_';
/* 1589 */     char wildcardEscape = '\\';
/*      */     
/* 1591 */     int searchForPos = 0;
/* 1592 */     int searchForEnd = searchForWildcard.length();
/*      */     
/* 1594 */     int searchInPos = 0;
/* 1595 */     int searchInEnd = searchIn.length();
/*      */     
/* 1597 */     while (searchForPos != searchForEnd) {
/* 1598 */       char wildstrChar = searchForWildcard.charAt(searchForPos);
/*      */       
/* 1600 */       while ((searchForWildcard.charAt(searchForPos) != wildcardMany) && (wildstrChar != wildcardOne)) {
/* 1601 */         if ((searchForWildcard.charAt(searchForPos) == wildcardEscape) && (searchForPos + 1 != searchForEnd)) {
/* 1602 */           searchForPos++;
/*      */         }
/*      */         
/* 1605 */         if ((searchInPos == searchInEnd) || (Character.toUpperCase(searchForWildcard.charAt(searchForPos++)) != Character.toUpperCase(searchIn.charAt(searchInPos++))))
/*      */         {
/* 1607 */           return 1;
/*      */         }
/*      */         
/* 1610 */         if (searchForPos == searchForEnd) {
/* 1611 */           return searchInPos != searchInEnd ? 1 : 0;
/*      */         }
/*      */         
/* 1614 */         result = 1;
/*      */       }
/*      */       
/* 1617 */       if (searchForWildcard.charAt(searchForPos) == wildcardOne) {
/*      */         do {
/* 1619 */           if (searchInPos == searchInEnd)
/*      */           {
/* 1621 */             return result;
/*      */           }
/*      */           
/* 1624 */           searchInPos++;
/* 1625 */           searchForPos++; } while ((searchForPos < searchForEnd) && (searchForWildcard.charAt(searchForPos) == wildcardOne));
/*      */         
/* 1627 */         if (searchForPos == searchForEnd) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/* 1632 */       if (searchForWildcard.charAt(searchForPos) == wildcardMany)
/*      */       {
/*      */ 
/*      */ 
/* 1636 */         searchForPos++;
/* 1639 */         for (; 
/*      */             
/* 1639 */             searchForPos != searchForEnd; searchForPos++) {
/* 1640 */           if (searchForWildcard.charAt(searchForPos) != wildcardMany)
/*      */           {
/*      */ 
/*      */ 
/* 1644 */             if (searchForWildcard.charAt(searchForPos) != wildcardOne) break;
/* 1645 */             if (searchInPos == searchInEnd) {
/* 1646 */               return -1;
/*      */             }
/*      */             
/* 1649 */             searchInPos++;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1657 */         if (searchForPos == searchForEnd) {
/* 1658 */           return 0;
/*      */         }
/*      */         
/* 1661 */         if (searchInPos == searchInEnd) {
/* 1662 */           return -1;
/*      */         }
/*      */         char cmp;
/* 1665 */         if (((cmp = searchForWildcard.charAt(searchForPos)) == wildcardEscape) && (searchForPos + 1 != searchForEnd)) {
/* 1666 */           cmp = searchForWildcard.charAt(++searchForPos);
/*      */         }
/*      */         
/* 1669 */         searchForPos++;
/*      */         do
/*      */         {
/* 1672 */           while ((searchInPos != searchInEnd) && (Character.toUpperCase(searchIn.charAt(searchInPos)) != Character.toUpperCase(cmp))) {
/* 1673 */             searchInPos++;
/*      */           }
/*      */           
/* 1676 */           if (searchInPos++ == searchInEnd) {
/* 1677 */             return -1;
/*      */           }
/*      */           
/*      */ 
/* 1681 */           int tmp = wildCompare(searchIn, searchForWildcard);
/*      */           
/* 1683 */           if (tmp <= 0) {
/* 1684 */             return tmp;
/*      */           }
/*      */           
/* 1687 */         } while ((searchInPos != searchInEnd) && (searchForWildcard.charAt(0) != wildcardMany));
/*      */         
/* 1689 */         return -1;
/*      */       }
/*      */     }
/*      */     
/* 1693 */     return searchInPos != searchInEnd ? 1 : 0;
/*      */   }
/*      */   
/*      */   static byte[] s2b(String s, MySQLConnection conn) throws SQLException {
/* 1697 */     if (s == null) {
/* 1698 */       return null;
/*      */     }
/*      */     
/* 1701 */     if ((conn != null) && (conn.getUseUnicode())) {
/*      */       try {
/* 1703 */         String encoding = conn.getEncoding();
/*      */         
/* 1705 */         if (encoding == null) {
/* 1706 */           return s.getBytes();
/*      */         }
/*      */         
/* 1709 */         SingleByteCharsetConverter converter = conn.getCharsetConverter(encoding);
/*      */         
/* 1711 */         if (converter != null) {
/* 1712 */           return converter.toBytes(s);
/*      */         }
/*      */         
/* 1715 */         return s.getBytes(encoding);
/*      */       } catch (UnsupportedEncodingException E) {
/* 1717 */         return s.getBytes();
/*      */       }
/*      */     }
/*      */     
/* 1721 */     return s.getBytes();
/*      */   }
/*      */   
/*      */   public static int lastIndexOf(byte[] s, char c) {
/* 1725 */     if (s == null) {
/* 1726 */       return -1;
/*      */     }
/*      */     
/* 1729 */     for (int i = s.length - 1; i >= 0; i--) {
/* 1730 */       if (s[i] == c) {
/* 1731 */         return i;
/*      */       }
/*      */     }
/*      */     
/* 1735 */     return -1;
/*      */   }
/*      */   
/*      */   public static int indexOf(byte[] s, char c) {
/* 1739 */     if (s == null) {
/* 1740 */       return -1;
/*      */     }
/*      */     
/* 1743 */     int length = s.length;
/*      */     
/* 1745 */     for (int i = 0; i < length; i++) {
/* 1746 */       if (s[i] == c) {
/* 1747 */         return i;
/*      */       }
/*      */     }
/*      */     
/* 1751 */     return -1;
/*      */   }
/*      */   
/*      */   public static boolean isNullOrEmpty(String toTest) {
/* 1755 */     return (toTest == null) || (toTest.length() == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripComments(String src, String stringOpens, String stringCloses, boolean slashStarComments, boolean slashSlashComments, boolean hashComments, boolean dashDashComments)
/*      */   {
/* 1780 */     if (src == null) {
/* 1781 */       return null;
/*      */     }
/*      */     
/* 1784 */     StringBuilder strBuilder = new StringBuilder(src.length());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1789 */     StringReader sourceReader = new StringReader(src);
/*      */     
/* 1791 */     int contextMarker = 0;
/* 1792 */     boolean escaped = false;
/* 1793 */     int markerTypeFound = -1;
/*      */     
/* 1795 */     int ind = 0;
/*      */     
/* 1797 */     int currentChar = 0;
/*      */     try
/*      */     {
/* 1800 */       while ((currentChar = sourceReader.read()) != -1)
/*      */       {
/*      */ 
/*      */ 
/* 1804 */         if ((markerTypeFound != -1) && (currentChar == stringCloses.charAt(markerTypeFound)) && (!escaped)) {
/* 1805 */           contextMarker = 0;
/* 1806 */           markerTypeFound = -1;
/* 1807 */         } else if (((ind = stringOpens.indexOf(currentChar)) != -1) && (!escaped) && (contextMarker == 0)) {
/* 1808 */           markerTypeFound = ind;
/* 1809 */           contextMarker = currentChar;
/*      */         }
/*      */         
/* 1812 */         if ((contextMarker == 0) && (currentChar == 47) && ((slashSlashComments) || (slashStarComments))) {
/* 1813 */           currentChar = sourceReader.read();
/* 1814 */           if ((currentChar == 42) && (slashStarComments)) {
/* 1815 */             int prevChar = 0;
/* 1816 */             while (((currentChar = sourceReader.read()) != 47) || (prevChar != 42)) {
/* 1817 */               if (currentChar == 13)
/*      */               {
/* 1819 */                 currentChar = sourceReader.read();
/* 1820 */                 if (currentChar == 10) {
/* 1821 */                   currentChar = sourceReader.read();
/*      */                 }
/*      */               }
/* 1824 */               else if (currentChar == 10)
/*      */               {
/* 1826 */                 currentChar = sourceReader.read();
/*      */               }
/*      */               
/* 1829 */               if (currentChar < 0) {
/*      */                 break;
/*      */               }
/* 1832 */               prevChar = currentChar;
/*      */             }
/*      */           }
/* 1835 */           if ((currentChar != 47) || (!slashSlashComments)) {}
/* 1836 */         } else { while (((currentChar = sourceReader.read()) != 10) && (currentChar != 13) && (currentChar >= 0))
/*      */           {
/*      */             continue;
/* 1839 */             if ((contextMarker == 0) && (currentChar == 35) && (hashComments)) {}
/*      */             for (;;) {
/* 1841 */               if (((currentChar = sourceReader.read()) != 10) && (currentChar != 13) && (currentChar >= 0)) {
/*      */                 continue;
/* 1843 */                 if ((contextMarker == 0) && (currentChar == 45) && (dashDashComments)) {
/* 1844 */                   currentChar = sourceReader.read();
/*      */                   
/* 1846 */                   if ((currentChar == -1) || (currentChar != 45)) {
/* 1847 */                     strBuilder.append('-');
/*      */                     
/* 1849 */                     if (currentChar == -1) break;
/* 1850 */                     strBuilder.append(currentChar); break;
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1858 */                   while (((currentChar = sourceReader.read()) != 10) && (currentChar != 13) && (currentChar >= 0)) {}
/*      */                 }
/*      */               }
/*      */             } } }
/* 1862 */         if (currentChar != -1) {
/* 1863 */           strBuilder.append((char)currentChar);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx) {}
/*      */     
/*      */ 
/* 1870 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String sanitizeProcOrFuncName(String src)
/*      */   {
/* 1886 */     if ((src == null) || (src.equals("%"))) {
/* 1887 */       return null;
/*      */     }
/*      */     
/* 1890 */     return src;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<String> splitDBdotName(String src, String cat, String quotId, boolean isNoBslashEscSet)
/*      */   {
/* 1909 */     if ((src == null) || (src.equals("%"))) {
/* 1910 */       return new ArrayList();
/*      */     }
/*      */     
/* 1913 */     boolean isQuoted = indexOfIgnoreCase(0, src, quotId) > -1;
/*      */     
/* 1915 */     String retval = src;
/* 1916 */     String tmpCat = cat;
/*      */     
/* 1918 */     int trueDotIndex = -1;
/* 1919 */     if (!" ".equals(quotId))
/*      */     {
/* 1921 */       if (isQuoted) {
/* 1922 */         trueDotIndex = indexOfIgnoreCase(0, retval, quotId + "." + quotId);
/*      */       }
/*      */       else
/*      */       {
/* 1926 */         trueDotIndex = indexOfIgnoreCase(0, retval, ".");
/*      */       }
/*      */     } else {
/* 1929 */       trueDotIndex = retval.indexOf(".");
/*      */     }
/*      */     
/* 1932 */     List<String> retTokens = new ArrayList(2);
/*      */     
/* 1934 */     if (trueDotIndex != -1)
/*      */     {
/* 1936 */       if (isQuoted) {
/* 1937 */         tmpCat = toString(stripEnclosure(retval.substring(0, trueDotIndex + 1).getBytes(), quotId, quotId));
/* 1938 */         if (startsWithIgnoreCaseAndWs(tmpCat, quotId)) {
/* 1939 */           tmpCat = tmpCat.substring(1, tmpCat.length() - 1);
/*      */         }
/*      */         
/* 1942 */         retval = retval.substring(trueDotIndex + 2);
/* 1943 */         retval = toString(stripEnclosure(retval.getBytes(), quotId, quotId));
/*      */       }
/*      */       else {
/* 1946 */         tmpCat = retval.substring(0, trueDotIndex);
/* 1947 */         retval = retval.substring(trueDotIndex + 1);
/*      */       }
/*      */     }
/*      */     else {
/* 1951 */       retval = toString(stripEnclosure(retval.getBytes(), quotId, quotId));
/*      */     }
/*      */     
/* 1954 */     retTokens.add(tmpCat);
/* 1955 */     retTokens.add(retval);
/* 1956 */     return retTokens;
/*      */   }
/*      */   
/*      */   public static boolean isEmptyOrWhitespaceOnly(String str) {
/* 1960 */     if ((str == null) || (str.length() == 0)) {
/* 1961 */       return true;
/*      */     }
/*      */     
/* 1964 */     int length = str.length();
/*      */     
/* 1966 */     for (int i = 0; i < length; i++) {
/* 1967 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 1968 */         return false;
/*      */       }
/*      */     }
/*      */     
/* 1972 */     return true;
/*      */   }
/*      */   
/*      */   public static String escapeQuote(String src, String quotChar) {
/* 1976 */     if (src == null) {
/* 1977 */       return null;
/*      */     }
/*      */     
/* 1980 */     src = toString(stripEnclosure(src.getBytes(), quotChar, quotChar));
/*      */     
/* 1982 */     int lastNdx = src.indexOf(quotChar);
/*      */     
/*      */ 
/*      */ 
/* 1986 */     String tmpSrc = src.substring(0, lastNdx);
/* 1987 */     tmpSrc = tmpSrc + quotChar + quotChar;
/*      */     
/* 1989 */     String tmpRest = src.substring(lastNdx + 1, src.length());
/*      */     
/* 1991 */     lastNdx = tmpRest.indexOf(quotChar);
/* 1992 */     while (lastNdx > -1)
/*      */     {
/* 1994 */       tmpSrc = tmpSrc + tmpRest.substring(0, lastNdx);
/* 1995 */       tmpSrc = tmpSrc + quotChar + quotChar;
/* 1996 */       tmpRest = tmpRest.substring(lastNdx + 1, tmpRest.length());
/*      */       
/* 1998 */       lastNdx = tmpRest.indexOf(quotChar);
/*      */     }
/*      */     
/* 2001 */     tmpSrc = tmpSrc + tmpRest;
/* 2002 */     src = tmpSrc;
/*      */     
/* 2004 */     return src;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String quoteIdentifier(String identifier, String quoteChar, boolean isPedantic)
/*      */   {
/* 2038 */     if (identifier == null) {
/* 2039 */       return null;
/*      */     }
/*      */     
/* 2042 */     identifier = identifier.trim();
/*      */     
/* 2044 */     int quoteCharLength = quoteChar.length();
/* 2045 */     if ((quoteCharLength == 0) || (" ".equals(quoteChar))) {
/* 2046 */       return identifier;
/*      */     }
/*      */     
/*      */ 
/* 2050 */     if ((!isPedantic) && (identifier.startsWith(quoteChar)) && (identifier.endsWith(quoteChar)))
/*      */     {
/* 2052 */       String identifierQuoteTrimmed = identifier.substring(quoteCharLength, identifier.length() - quoteCharLength);
/*      */       
/*      */ 
/* 2055 */       int quoteCharPos = identifierQuoteTrimmed.indexOf(quoteChar);
/* 2056 */       while (quoteCharPos >= 0) {
/* 2057 */         int quoteCharNextExpectedPos = quoteCharPos + quoteCharLength;
/* 2058 */         int quoteCharNextPosition = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextExpectedPos);
/*      */         
/* 2060 */         if (quoteCharNextPosition != quoteCharNextExpectedPos) break;
/* 2061 */         quoteCharPos = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextPosition + quoteCharLength);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2068 */       if (quoteCharPos < 0) {
/* 2069 */         return identifier;
/*      */       }
/*      */     }
/*      */     
/* 2073 */     return quoteChar + identifier.replaceAll(quoteChar, new StringBuilder().append(quoteChar).append(quoteChar).toString()) + quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String quoteIdentifier(String identifier, boolean isPedantic)
/*      */   {
/* 2096 */     return quoteIdentifier(identifier, "`", isPedantic);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String unQuoteIdentifier(String identifier, String quoteChar)
/*      */   {
/* 2121 */     if (identifier == null) {
/* 2122 */       return null;
/*      */     }
/*      */     
/* 2125 */     identifier = identifier.trim();
/*      */     
/* 2127 */     int quoteCharLength = quoteChar.length();
/* 2128 */     if ((quoteCharLength == 0) || (" ".equals(quoteChar))) {
/* 2129 */       return identifier;
/*      */     }
/*      */     
/*      */ 
/* 2133 */     if ((identifier.startsWith(quoteChar)) && (identifier.endsWith(quoteChar)))
/*      */     {
/* 2135 */       String identifierQuoteTrimmed = identifier.substring(quoteCharLength, identifier.length() - quoteCharLength);
/*      */       
/*      */ 
/* 2138 */       int quoteCharPos = identifierQuoteTrimmed.indexOf(quoteChar);
/* 2139 */       while (quoteCharPos >= 0) {
/* 2140 */         int quoteCharNextExpectedPos = quoteCharPos + quoteCharLength;
/* 2141 */         int quoteCharNextPosition = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextExpectedPos);
/*      */         
/* 2143 */         if (quoteCharNextPosition == quoteCharNextExpectedPos) {
/* 2144 */           quoteCharPos = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextPosition + quoteCharLength);
/*      */         }
/*      */         else {
/* 2147 */           return identifier;
/*      */         }
/*      */       }
/*      */       
/* 2151 */       return identifier.substring(quoteCharLength, identifier.length() - quoteCharLength).replaceAll(quoteChar + quoteChar, quoteChar);
/*      */     }
/*      */     
/* 2154 */     return identifier;
/*      */   }
/*      */   
/*      */   public static int indexOfQuoteDoubleAware(String searchIn, String quoteChar, int startFrom) {
/* 2158 */     if ((searchIn == null) || (quoteChar == null) || (quoteChar.length() == 0) || (startFrom > searchIn.length())) {
/* 2159 */       return -1;
/*      */     }
/*      */     
/* 2162 */     int lastIndex = searchIn.length() - 1;
/*      */     
/* 2164 */     int beginPos = startFrom;
/* 2165 */     int pos = -1;
/*      */     
/* 2167 */     boolean next = true;
/* 2168 */     while (next) {
/* 2169 */       pos = searchIn.indexOf(quoteChar, beginPos);
/* 2170 */       if ((pos == -1) || (pos == lastIndex) || (!searchIn.startsWith(quoteChar, pos + 1))) {
/* 2171 */         next = false;
/*      */       } else {
/* 2173 */         beginPos = pos + 2;
/*      */       }
/*      */     }
/*      */     
/* 2177 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String toString(byte[] value, int offset, int length, String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 2189 */     Charset cs = findCharset(encoding);
/*      */     
/* 2191 */     return cs.decode(ByteBuffer.wrap(value, offset, length)).toString();
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, String encoding) throws UnsupportedEncodingException {
/* 2195 */     Charset cs = findCharset(encoding);
/*      */     
/* 2197 */     return cs.decode(ByteBuffer.wrap(value)).toString();
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, int offset, int length) {
/*      */     try {
/* 2202 */       Charset cs = findCharset(platformEncoding);
/*      */       
/* 2204 */       return cs.decode(ByteBuffer.wrap(value, offset, length)).toString();
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 2209 */     return null;
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value) {
/*      */     try {
/* 2214 */       Charset cs = findCharset(platformEncoding);
/*      */       
/* 2216 */       return cs.decode(ByteBuffer.wrap(value)).toString();
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 2221 */     return null;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(char[] value) {
/*      */     try {
/* 2226 */       return getBytes(value, 0, value.length, platformEncoding);
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 2231 */     return null;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(char[] value, int offset, int length) {
/*      */     try {
/* 2236 */       return getBytes(value, offset, length, platformEncoding);
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 2241 */     return null;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(char[] value, String encoding) throws UnsupportedEncodingException {
/* 2245 */     return getBytes(value, 0, value.length, encoding);
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(char[] value, int offset, int length, String encoding) throws UnsupportedEncodingException {
/* 2249 */     Charset cs = findCharset(encoding);
/*      */     
/* 2251 */     ByteBuffer buf = cs.encode(CharBuffer.wrap(value, offset, length));
/*      */     
/*      */ 
/* 2254 */     int encodedLen = buf.limit();
/* 2255 */     byte[] asBytes = new byte[encodedLen];
/* 2256 */     buf.get(asBytes, 0, encodedLen);
/*      */     
/* 2258 */     return asBytes;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value) {
/*      */     try {
/* 2263 */       return getBytes(value, 0, value.length(), platformEncoding);
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 2268 */     return null;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value, int offset, int length) {
/*      */     try {
/* 2273 */       return getBytes(value, offset, length, platformEncoding);
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 2278 */     return null;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value, String encoding) throws UnsupportedEncodingException {
/* 2282 */     return getBytes(value, 0, value.length(), encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] getBytes(String value, int offset, int length, String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 2291 */     if (!Util.isJdbc4()) {
/* 2292 */       if ((offset != 0) || (length != value.length())) {
/* 2293 */         return value.substring(offset, offset + length).getBytes(encoding);
/*      */       }
/* 2295 */       return value.getBytes(encoding);
/*      */     }
/*      */     
/* 2298 */     Charset cs = findCharset(encoding);
/*      */     
/* 2300 */     ByteBuffer buf = cs.encode(CharBuffer.wrap(value.toCharArray(), offset, length));
/*      */     
/*      */ 
/* 2303 */     int encodedLen = buf.limit();
/* 2304 */     byte[] asBytes = new byte[encodedLen];
/* 2305 */     buf.get(asBytes, 0, encodedLen);
/*      */     
/* 2307 */     return asBytes;
/*      */   }
/*      */   
/*      */   public static final boolean isValidIdChar(char c) {
/* 2311 */     return "abcdefghijklmnopqrstuvwxyzABCDEFGHIGKLMNOPQRSTUVWXYZ0123456789$_#@".indexOf(c) != -1;
/*      */   }
/*      */   
/* 2314 */   private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*      */   
/*      */   public static void appendAsHex(StringBuilder builder, byte[] bytes) {
/* 2317 */     builder.append("0x");
/* 2318 */     for (byte b : bytes) {
/* 2319 */       builder.append(HEX_DIGITS[(b >>> 4 & 0xF)]).append(HEX_DIGITS[(b & 0xF)]);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void appendAsHex(StringBuilder builder, int value) {
/* 2324 */     if (value == 0) {
/* 2325 */       builder.append("0x0");
/* 2326 */       return;
/*      */     }
/*      */     
/* 2329 */     int shift = 32;
/*      */     
/* 2331 */     boolean nonZeroFound = false;
/*      */     
/* 2333 */     builder.append("0x");
/*      */     do {
/* 2335 */       shift -= 4;
/* 2336 */       byte nibble = (byte)(value >>> shift & 0xF);
/* 2337 */       if (nonZeroFound) {
/* 2338 */         builder.append(HEX_DIGITS[nibble]);
/* 2339 */       } else if (nibble != 0) {
/* 2340 */         builder.append(HEX_DIGITS[nibble]);
/* 2341 */         nonZeroFound = true;
/*      */       }
/* 2343 */     } while (shift != 0);
/*      */   }
/*      */   
/*      */   public static byte[] getBytesNullTerminated(String value, String encoding) throws UnsupportedEncodingException {
/* 2347 */     Charset cs = findCharset(encoding);
/*      */     
/* 2349 */     ByteBuffer buf = cs.encode(value);
/*      */     
/* 2351 */     int encodedLen = buf.limit();
/* 2352 */     byte[] asBytes = new byte[encodedLen + 1];
/* 2353 */     buf.get(asBytes, 0, encodedLen);
/* 2354 */     asBytes[encodedLen] = 0;
/*      */     
/* 2356 */     return asBytes;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/StringUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */