/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.StandardLogger;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Field;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TreeMap;
/*      */ import javax.naming.RefAddr;
/*      */ import javax.naming.Reference;
/*      */ import javax.naming.StringRefAddr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionPropertiesImpl
/*      */   implements Serializable, ConnectionProperties
/*      */ {
/*      */   private static final long serialVersionUID = 4257801713007640580L;
/*      */   
/*      */   static class BooleanConnectionProperty
/*      */     extends ConnectionPropertiesImpl.ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 2540132501709159404L;
/*      */     
/*      */     BooleanConnectionProperty(String propertyNameToSet, boolean defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*   62 */       super(Boolean.valueOf(defaultValueToSet), null, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     String[] getAllowableValues()
/*      */     {
/*   70 */       return new String[] { "true", "false", "yes", "no" };
/*      */     }
/*      */     
/*      */     boolean getValueAsBoolean() {
/*   74 */       return ((Boolean)this.valueAsObject).booleanValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean hasValueConstraints()
/*      */     {
/*   82 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void initializeFrom(String extractedValue, ExceptionInterceptor exceptionInterceptor)
/*      */       throws SQLException
/*      */     {
/*   90 */       if (extractedValue != null) {
/*   91 */         validateStringValues(extractedValue, exceptionInterceptor);
/*      */         
/*   93 */         this.valueAsObject = Boolean.valueOf((extractedValue.equalsIgnoreCase("TRUE")) || (extractedValue.equalsIgnoreCase("YES")));
/*      */       } else {
/*   95 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*   97 */       this.updateCount += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean isRangeBased()
/*      */     {
/*  105 */       return false;
/*      */     }
/*      */     
/*      */     void setValue(boolean valueFlag) {
/*  109 */       this.valueAsObject = Boolean.valueOf(valueFlag);
/*  110 */       this.updateCount += 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static abstract class ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     static final long serialVersionUID = -6644853639584478367L;
/*      */     
/*      */     String[] allowableValues;
/*      */     
/*      */     String categoryName;
/*      */     
/*      */     Object defaultValue;
/*      */     
/*      */     int lowerBound;
/*      */     
/*      */     int order;
/*      */     
/*      */     String propertyName;
/*      */     
/*      */     String sinceVersion;
/*      */     
/*      */     int upperBound;
/*      */     
/*      */     Object valueAsObject;
/*      */     
/*      */     boolean required;
/*      */     String description;
/*  140 */     int updateCount = 0;
/*      */     
/*      */ 
/*      */     public ConnectionProperty() {}
/*      */     
/*      */ 
/*      */     ConnectionProperty(String propertyNameToSet, Object defaultValueToSet, String[] allowableValuesToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  148 */       this.description = descriptionToSet;
/*  149 */       this.propertyName = propertyNameToSet;
/*  150 */       this.defaultValue = defaultValueToSet;
/*  151 */       this.valueAsObject = defaultValueToSet;
/*  152 */       this.allowableValues = allowableValuesToSet;
/*  153 */       this.lowerBound = lowerBoundToSet;
/*  154 */       this.upperBound = upperBoundToSet;
/*  155 */       this.required = false;
/*  156 */       this.sinceVersion = sinceVersionToSet;
/*  157 */       this.categoryName = category;
/*  158 */       this.order = orderInCategory;
/*      */     }
/*      */     
/*      */     String[] getAllowableValues() {
/*  162 */       return this.allowableValues;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     String getCategoryName()
/*      */     {
/*  169 */       return this.categoryName;
/*      */     }
/*      */     
/*      */     Object getDefaultValue() {
/*  173 */       return this.defaultValue;
/*      */     }
/*      */     
/*      */     int getLowerBound() {
/*  177 */       return this.lowerBound;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     int getOrder()
/*      */     {
/*  184 */       return this.order;
/*      */     }
/*      */     
/*      */     String getPropertyName() {
/*  188 */       return this.propertyName;
/*      */     }
/*      */     
/*      */     int getUpperBound() {
/*  192 */       return this.upperBound;
/*      */     }
/*      */     
/*      */     Object getValueAsObject() {
/*  196 */       return this.valueAsObject;
/*      */     }
/*      */     
/*      */     int getUpdateCount() {
/*  200 */       return this.updateCount;
/*      */     }
/*      */     
/*      */     abstract boolean hasValueConstraints();
/*      */     
/*      */     void initializeFrom(Properties extractFrom, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  206 */       String extractedValue = extractFrom.getProperty(getPropertyName());
/*  207 */       extractFrom.remove(getPropertyName());
/*  208 */       initializeFrom(extractedValue, exceptionInterceptor);
/*      */     }
/*      */     
/*      */     void initializeFrom(Reference ref, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  212 */       RefAddr refAddr = ref.get(getPropertyName());
/*      */       
/*  214 */       if (refAddr != null) {
/*  215 */         String refContentAsString = (String)refAddr.getContent();
/*      */         
/*  217 */         initializeFrom(refContentAsString, exceptionInterceptor);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     abstract void initializeFrom(String paramString, ExceptionInterceptor paramExceptionInterceptor)
/*      */       throws SQLException;
/*      */     
/*      */ 
/*      */     abstract boolean isRangeBased();
/*      */     
/*      */     void setCategoryName(String categoryName)
/*      */     {
/*  230 */       this.categoryName = categoryName;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void setOrder(int order)
/*      */     {
/*  238 */       this.order = order;
/*      */     }
/*      */     
/*      */     void setValueAsObject(Object obj) {
/*  242 */       this.valueAsObject = obj;
/*  243 */       this.updateCount += 1;
/*      */     }
/*      */     
/*      */     void storeTo(Reference ref) {
/*  247 */       if (getValueAsObject() != null) {
/*  248 */         ref.add(new StringRefAddr(getPropertyName(), getValueAsObject().toString()));
/*      */       }
/*      */     }
/*      */     
/*      */     DriverPropertyInfo getAsDriverPropertyInfo() {
/*  253 */       DriverPropertyInfo dpi = new DriverPropertyInfo(this.propertyName, null);
/*  254 */       dpi.choices = getAllowableValues();
/*  255 */       dpi.value = (this.valueAsObject != null ? this.valueAsObject.toString() : null);
/*  256 */       dpi.required = this.required;
/*  257 */       dpi.description = this.description;
/*      */       
/*  259 */       return dpi;
/*      */     }
/*      */     
/*      */     void validateStringValues(String valueToValidate, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  263 */       String[] validateAgainst = getAllowableValues();
/*      */       
/*  265 */       if (valueToValidate == null) {
/*  266 */         return;
/*      */       }
/*      */       
/*  269 */       if ((validateAgainst == null) || (validateAgainst.length == 0)) {
/*  270 */         return;
/*      */       }
/*      */       
/*  273 */       for (int i = 0; i < validateAgainst.length; i++) {
/*  274 */         if ((validateAgainst[i] != null) && (validateAgainst[i].equalsIgnoreCase(valueToValidate))) {
/*  275 */           return;
/*      */         }
/*      */       }
/*      */       
/*  279 */       StringBuilder errorMessageBuf = new StringBuilder();
/*      */       
/*  281 */       errorMessageBuf.append("The connection property '");
/*  282 */       errorMessageBuf.append(getPropertyName());
/*  283 */       errorMessageBuf.append("' only accepts values of the form: ");
/*      */       
/*  285 */       if (validateAgainst.length != 0) {
/*  286 */         errorMessageBuf.append("'");
/*  287 */         errorMessageBuf.append(validateAgainst[0]);
/*  288 */         errorMessageBuf.append("'");
/*      */         
/*  290 */         for (int i = 1; i < validateAgainst.length - 1; i++) {
/*  291 */           errorMessageBuf.append(", ");
/*  292 */           errorMessageBuf.append("'");
/*  293 */           errorMessageBuf.append(validateAgainst[i]);
/*  294 */           errorMessageBuf.append("'");
/*      */         }
/*      */         
/*  297 */         errorMessageBuf.append(" or '");
/*  298 */         errorMessageBuf.append(validateAgainst[(validateAgainst.length - 1)]);
/*  299 */         errorMessageBuf.append("'");
/*      */       }
/*      */       
/*  302 */       errorMessageBuf.append(". The value '");
/*  303 */       errorMessageBuf.append(valueToValidate);
/*  304 */       errorMessageBuf.append("' is not in this set.");
/*      */       
/*  306 */       throw SQLError.createSQLException(errorMessageBuf.toString(), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */   static class IntegerConnectionProperty
/*      */     extends ConnectionPropertiesImpl.ConnectionProperty implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -3004305481796850832L;
/*  314 */     int multiplier = 1;
/*      */     
/*      */     public IntegerConnectionProperty(String propertyNameToSet, Object defaultValueToSet, String[] allowableValuesToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  318 */       super(defaultValueToSet, allowableValuesToSet, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */     IntegerConnectionProperty(String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  324 */       super(Integer.valueOf(defaultValueToSet), null, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     IntegerConnectionProperty(String propertyNameToSet, int defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  337 */       this(propertyNameToSet, defaultValueToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     String[] getAllowableValues()
/*      */     {
/*  345 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int getLowerBound()
/*      */     {
/*  353 */       return this.lowerBound;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int getUpperBound()
/*      */     {
/*  361 */       return this.upperBound;
/*      */     }
/*      */     
/*      */     int getValueAsInt() {
/*  365 */       return ((Integer)this.valueAsObject).intValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean hasValueConstraints()
/*      */     {
/*  373 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void initializeFrom(String extractedValue, ExceptionInterceptor exceptionInterceptor)
/*      */       throws SQLException
/*      */     {
/*  381 */       if (extractedValue != null) {
/*      */         try
/*      */         {
/*  384 */           int intValue = (int)(Double.valueOf(extractedValue).doubleValue() * this.multiplier);
/*      */           
/*  386 */           setValue(intValue, extractedValue, exceptionInterceptor);
/*      */         } catch (NumberFormatException nfe) {
/*  388 */           throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts integer values. The value '" + extractedValue + "' can not be converted to an integer.", "S1009", exceptionInterceptor);
/*      */         }
/*      */         
/*      */       } else {
/*  392 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*  394 */       this.updateCount += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean isRangeBased()
/*      */     {
/*  402 */       return getUpperBound() != getLowerBound();
/*      */     }
/*      */     
/*      */     void setValue(int intValue, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  406 */       setValue(intValue, null, exceptionInterceptor);
/*      */     }
/*      */     
/*      */     void setValue(int intValue, String valueAsString, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  410 */       if ((isRangeBased()) && (
/*  411 */         (intValue < getLowerBound()) || (intValue > getUpperBound()))) {
/*  412 */         throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts integer values in the range of " + getLowerBound() + " - " + getUpperBound() + ", the value '" + (valueAsString == null ? Integer.valueOf(intValue) : valueAsString) + "' exceeds this range.", "S1009", exceptionInterceptor);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  418 */       this.valueAsObject = Integer.valueOf(intValue);
/*  419 */       this.updateCount += 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class LongConnectionProperty extends ConnectionPropertiesImpl.IntegerConnectionProperty
/*      */   {
/*      */     private static final long serialVersionUID = 6068572984340480895L;
/*      */     
/*      */     LongConnectionProperty(String propertyNameToSet, long defaultValueToSet, long lowerBoundToSet, long upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  429 */       super(Long.valueOf(defaultValueToSet), null, (int)lowerBoundToSet, (int)upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */     LongConnectionProperty(String propertyNameToSet, long defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  435 */       this(propertyNameToSet, defaultValueToSet, 0L, 0L, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */     void setValue(long longValue, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  439 */       setValue(longValue, null, exceptionInterceptor);
/*      */     }
/*      */     
/*      */     void setValue(long longValue, String valueAsString, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  443 */       if ((isRangeBased()) && (
/*  444 */         (longValue < getLowerBound()) || (longValue > getUpperBound()))) {
/*  445 */         throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts long integer values in the range of " + getLowerBound() + " - " + getUpperBound() + ", the value '" + (valueAsString == null ? Long.valueOf(longValue) : valueAsString) + "' exceeds this range.", "S1009", exceptionInterceptor);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  450 */       this.valueAsObject = Long.valueOf(longValue);
/*  451 */       this.updateCount += 1;
/*      */     }
/*      */     
/*      */     long getValueAsLong() {
/*  455 */       return ((Long)this.valueAsObject).longValue();
/*      */     }
/*      */     
/*      */     void initializeFrom(String extractedValue, ExceptionInterceptor exceptionInterceptor) throws SQLException
/*      */     {
/*  460 */       if (extractedValue != null) {
/*      */         try
/*      */         {
/*  463 */           long longValue = Double.valueOf(extractedValue).longValue();
/*      */           
/*  465 */           setValue(longValue, extractedValue, exceptionInterceptor);
/*      */         } catch (NumberFormatException nfe) {
/*  467 */           throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts long integer values. The value '" + extractedValue + "' can not be converted to a long integer.", "S1009", exceptionInterceptor);
/*      */         }
/*      */         
/*      */       } else {
/*  471 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*  473 */       this.updateCount += 1;
/*      */     }
/*      */   }
/*      */   
/*      */   static class MemorySizeConnectionProperty
/*      */     extends ConnectionPropertiesImpl.IntegerConnectionProperty implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 7351065128998572656L;
/*      */     private String valueAsString;
/*      */     
/*      */     MemorySizeConnectionProperty(String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  485 */       super(defaultValueToSet, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */     void initializeFrom(String extractedValue, ExceptionInterceptor exceptionInterceptor) throws SQLException
/*      */     {
/*  490 */       this.valueAsString = extractedValue;
/*  491 */       this.multiplier = 1;
/*      */       
/*  493 */       if (extractedValue != null) {
/*  494 */         if ((extractedValue.endsWith("k")) || (extractedValue.endsWith("K")) || (extractedValue.endsWith("kb")) || (extractedValue.endsWith("Kb")) || (extractedValue.endsWith("kB")) || (extractedValue.endsWith("KB")))
/*      */         {
/*  496 */           this.multiplier = 1024;
/*  497 */           int indexOfK = StringUtils.indexOfIgnoreCase(extractedValue, "k");
/*  498 */           extractedValue = extractedValue.substring(0, indexOfK);
/*  499 */         } else if ((extractedValue.endsWith("m")) || (extractedValue.endsWith("M")) || (extractedValue.endsWith("mb")) || (extractedValue.endsWith("Mb")) || (extractedValue.endsWith("mB")) || (extractedValue.endsWith("MB")))
/*      */         {
/*  501 */           this.multiplier = 1048576;
/*  502 */           int indexOfM = StringUtils.indexOfIgnoreCase(extractedValue, "m");
/*  503 */           extractedValue = extractedValue.substring(0, indexOfM);
/*  504 */         } else if ((extractedValue.endsWith("g")) || (extractedValue.endsWith("G")) || (extractedValue.endsWith("gb")) || (extractedValue.endsWith("Gb")) || (extractedValue.endsWith("gB")) || (extractedValue.endsWith("GB")))
/*      */         {
/*  506 */           this.multiplier = 1073741824;
/*  507 */           int indexOfG = StringUtils.indexOfIgnoreCase(extractedValue, "g");
/*  508 */           extractedValue = extractedValue.substring(0, indexOfG);
/*      */         }
/*      */       }
/*      */       
/*  512 */       super.initializeFrom(extractedValue, exceptionInterceptor);
/*      */     }
/*      */     
/*      */     void setValue(String value, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  516 */       initializeFrom(value, exceptionInterceptor);
/*      */     }
/*      */     
/*      */     String getValueAsString() {
/*  520 */       return this.valueAsString;
/*      */     }
/*      */   }
/*      */   
/*      */   static class StringConnectionProperty extends ConnectionPropertiesImpl.ConnectionProperty implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 5432127962785948272L;
/*      */     
/*      */     StringConnectionProperty(String propertyNameToSet, String defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  530 */       this(propertyNameToSet, defaultValueToSet, null, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     StringConnectionProperty(String propertyNameToSet, String defaultValueToSet, String[] allowableValuesToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  542 */       super(defaultValueToSet, allowableValuesToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */     String getValueAsString() {
/*  546 */       return (String)this.valueAsObject;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean hasValueConstraints()
/*      */     {
/*  554 */       return (this.allowableValues != null) && (this.allowableValues.length > 0);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void initializeFrom(String extractedValue, ExceptionInterceptor exceptionInterceptor)
/*      */       throws SQLException
/*      */     {
/*  562 */       if (extractedValue != null) {
/*  563 */         validateStringValues(extractedValue, exceptionInterceptor);
/*      */         
/*  565 */         this.valueAsObject = extractedValue;
/*      */       } else {
/*  567 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*  569 */       this.updateCount += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean isRangeBased()
/*      */     {
/*  577 */       return false;
/*      */     }
/*      */     
/*      */     void setValue(String valueFlag) {
/*  581 */       this.valueAsObject = valueFlag;
/*  582 */       this.updateCount += 1;
/*      */     }
/*      */   }
/*      */   
/*  586 */   private static final String CONNECTION_AND_AUTH_CATEGORY = Messages.getString("ConnectionProperties.categoryConnectionAuthentication");
/*      */   
/*  588 */   private static final String NETWORK_CATEGORY = Messages.getString("ConnectionProperties.categoryNetworking");
/*      */   
/*  590 */   private static final String DEBUGING_PROFILING_CATEGORY = Messages.getString("ConnectionProperties.categoryDebuggingProfiling");
/*      */   
/*  592 */   private static final String HA_CATEGORY = Messages.getString("ConnectionProperties.categorryHA");
/*      */   
/*  594 */   private static final String MISC_CATEGORY = Messages.getString("ConnectionProperties.categoryMisc");
/*      */   
/*  596 */   private static final String PERFORMANCE_CATEGORY = Messages.getString("ConnectionProperties.categoryPerformance");
/*      */   
/*  598 */   private static final String SECURITY_CATEGORY = Messages.getString("ConnectionProperties.categorySecurity");
/*      */   
/*  600 */   private static final String[] PROPERTY_CATEGORIES = { CONNECTION_AND_AUTH_CATEGORY, NETWORK_CATEGORY, HA_CATEGORY, SECURITY_CATEGORY, PERFORMANCE_CATEGORY, DEBUGING_PROFILING_CATEGORY, MISC_CATEGORY };
/*      */   
/*      */ 
/*  603 */   private static final ArrayList<Field> PROPERTY_LIST = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  608 */   private static final String STANDARD_LOGGER_NAME = StandardLogger.class.getName();
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_CONVERT_TO_NULL = "convertToNull";
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_EXCEPTION = "exception";
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_ROUND = "round";
/*      */   private BooleanConnectionProperty allowLoadLocalInfile;
/*      */   private BooleanConnectionProperty allowMultiQueries;
/*      */   private BooleanConnectionProperty allowNanAndInf;
/*      */   private BooleanConnectionProperty allowUrlInLocalInfile;
/*      */   private BooleanConnectionProperty alwaysSendSetIsolation;
/*      */   private BooleanConnectionProperty autoClosePStmtStreams;
/*      */   private BooleanConnectionProperty allowMasterDownConnections;
/*      */   private BooleanConnectionProperty autoDeserialize;
/*      */   private BooleanConnectionProperty autoGenerateTestcaseScript;
/*      */   private boolean autoGenerateTestcaseScriptAsBoolean;
/*      */   private BooleanConnectionProperty autoReconnect;
/*      */   private BooleanConnectionProperty autoReconnectForPools;
/*      */   private boolean autoReconnectForPoolsAsBoolean;
/*      */   private MemorySizeConnectionProperty blobSendChunkSize;
/*      */   private BooleanConnectionProperty autoSlowLog;
/*      */   private BooleanConnectionProperty blobsAreStrings;
/*      */   private BooleanConnectionProperty functionsNeverReturnBlobs;
/*      */   
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*  618 */       Field[] declaredFields = ConnectionPropertiesImpl.class.getDeclaredFields();
/*      */       
/*  620 */       for (int i = 0; i < declaredFields.length; i++) {
/*  621 */         if (ConnectionProperty.class.isAssignableFrom(declaredFields[i].getType())) {
/*  622 */           PROPERTY_LIST.add(declaredFields[i]);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  626 */       RuntimeException rtEx = new RuntimeException();
/*  627 */       rtEx.initCause(ex);
/*      */       
/*  629 */       throw rtEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private BooleanConnectionProperty cacheCallableStatements;
/*      */   private BooleanConnectionProperty cachePreparedStatements;
/*      */   private BooleanConnectionProperty cacheResultSetMetadata;
/*      */   private boolean cacheResultSetMetaDataAsBoolean;
/*      */   private StringConnectionProperty serverConfigCacheFactory;
/*      */   private BooleanConnectionProperty cacheServerConfiguration;
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor()
/*      */   {
/*  634 */     return null;
/*      */   }
/*      */   
/*      */   private IntegerConnectionProperty callableStatementCacheSize;
/*      */   private BooleanConnectionProperty capitalizeTypeNames;
/*      */   private StringConnectionProperty characterEncoding;
/*      */   private String characterEncodingAsString;
/*      */   protected boolean characterEncodingIsAliasForSjis;
/*      */   private StringConnectionProperty characterSetResults;
/*      */   private StringConnectionProperty connectionAttributes;
/*      */   private StringConnectionProperty clientInfoProvider;
/*      */   private BooleanConnectionProperty clobberStreamingResults;
/*      */   private StringConnectionProperty clobCharacterEncoding;
/*      */   private BooleanConnectionProperty compensateOnDuplicateKeyUpdateCounts;
/*      */   private StringConnectionProperty connectionCollation;
/*      */   private StringConnectionProperty connectionLifecycleInterceptors;
/*      */   private IntegerConnectionProperty connectTimeout;
/*      */   private BooleanConnectionProperty continueBatchOnError;
/*      */   private BooleanConnectionProperty createDatabaseIfNotExist;
/*      */   private IntegerConnectionProperty defaultFetchSize;
/*      */   private BooleanConnectionProperty detectServerPreparedStmts;
/*      */   
/*      */   protected static DriverPropertyInfo[] exposeAsDriverPropertyInfo(Properties info, int slotsToReserve)
/*      */     throws SQLException
/*      */   {
/*  652 */     new ConnectionPropertiesImpl() { private static final long serialVersionUID = 4257801713007640581L; }.exposeAsDriverPropertyInfoInternal(info, slotsToReserve);
/*      */   }
/*      */   
/*      */   public ConnectionPropertiesImpl()
/*      */   {
/*  657 */     this.allowLoadLocalInfile = new BooleanConnectionProperty("allowLoadLocalInfile", true, Messages.getString("ConnectionProperties.loadDataLocal"), "3.0.3", SECURITY_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/*  660 */     this.allowMultiQueries = new BooleanConnectionProperty("allowMultiQueries", false, Messages.getString("ConnectionProperties.allowMultiQueries"), "3.1.1", SECURITY_CATEGORY, 1);
/*      */     
/*      */ 
/*  663 */     this.allowNanAndInf = new BooleanConnectionProperty("allowNanAndInf", false, Messages.getString("ConnectionProperties.allowNANandINF"), "3.1.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  666 */     this.allowUrlInLocalInfile = new BooleanConnectionProperty("allowUrlInLocalInfile", false, Messages.getString("ConnectionProperties.allowUrlInLoadLocal"), "3.1.4", SECURITY_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/*  669 */     this.alwaysSendSetIsolation = new BooleanConnectionProperty("alwaysSendSetIsolation", true, Messages.getString("ConnectionProperties.alwaysSendSetIsolation"), "3.1.7", PERFORMANCE_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/*  672 */     this.autoClosePStmtStreams = new BooleanConnectionProperty("autoClosePStmtStreams", false, Messages.getString("ConnectionProperties.autoClosePstmtStreams"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  675 */     this.allowMasterDownConnections = new BooleanConnectionProperty("allowMasterDownConnections", false, Messages.getString("ConnectionProperties.allowMasterDownConnections"), "5.1.27", HA_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/*  678 */     this.autoDeserialize = new BooleanConnectionProperty("autoDeserialize", false, Messages.getString("ConnectionProperties.autoDeserialize"), "3.1.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  681 */     this.autoGenerateTestcaseScript = new BooleanConnectionProperty("autoGenerateTestcaseScript", false, Messages.getString("ConnectionProperties.autoGenerateTestcaseScript"), "3.1.9", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  684 */     this.autoGenerateTestcaseScriptAsBoolean = false;
/*      */     
/*  686 */     this.autoReconnect = new BooleanConnectionProperty("autoReconnect", false, Messages.getString("ConnectionProperties.autoReconnect"), "1.1", HA_CATEGORY, 0);
/*      */     
/*      */ 
/*  689 */     this.autoReconnectForPools = new BooleanConnectionProperty("autoReconnectForPools", false, Messages.getString("ConnectionProperties.autoReconnectForPools"), "3.1.3", HA_CATEGORY, 1);
/*      */     
/*      */ 
/*  692 */     this.autoReconnectForPoolsAsBoolean = false;
/*      */     
/*  694 */     this.blobSendChunkSize = new MemorySizeConnectionProperty("blobSendChunkSize", 1048576, 0, 0, Messages.getString("ConnectionProperties.blobSendChunkSize"), "3.1.9", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  697 */     this.autoSlowLog = new BooleanConnectionProperty("autoSlowLog", true, Messages.getString("ConnectionProperties.autoSlowLog"), "5.1.4", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  700 */     this.blobsAreStrings = new BooleanConnectionProperty("blobsAreStrings", false, "Should the driver always treat BLOBs as Strings - specifically to work around dubious metadata returned by the server for GROUP BY clauses?", "5.0.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*  704 */     this.functionsNeverReturnBlobs = new BooleanConnectionProperty("functionsNeverReturnBlobs", false, "Should the driver always treat data from functions returning BLOBs as Strings - specifically to work around dubious metadata returned by the server for GROUP BY clauses?", "5.0.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*  708 */     this.cacheCallableStatements = new BooleanConnectionProperty("cacheCallableStmts", false, Messages.getString("ConnectionProperties.cacheCallableStatements"), "3.1.2", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  711 */     this.cachePreparedStatements = new BooleanConnectionProperty("cachePrepStmts", false, Messages.getString("ConnectionProperties.cachePrepStmts"), "3.0.10", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  714 */     this.cacheResultSetMetadata = new BooleanConnectionProperty("cacheResultSetMetadata", false, Messages.getString("ConnectionProperties.cacheRSMetadata"), "3.1.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  719 */     this.serverConfigCacheFactory = new StringConnectionProperty("serverConfigCacheFactory", PerVmServerConfigCacheFactory.class.getName(), Messages.getString("ConnectionProperties.serverConfigCacheFactory"), "5.1.1", PERFORMANCE_CATEGORY, 12);
/*      */     
/*      */ 
/*      */ 
/*  723 */     this.cacheServerConfiguration = new BooleanConnectionProperty("cacheServerConfiguration", false, Messages.getString("ConnectionProperties.cacheServerConfiguration"), "3.1.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  726 */     this.callableStatementCacheSize = new IntegerConnectionProperty("callableStmtCacheSize", 100, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.callableStmtCacheSize"), "3.1.2", PERFORMANCE_CATEGORY, 5);
/*      */     
/*      */ 
/*  729 */     this.capitalizeTypeNames = new BooleanConnectionProperty("capitalizeTypeNames", true, Messages.getString("ConnectionProperties.capitalizeTypeNames"), "2.0.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  732 */     this.characterEncoding = new StringConnectionProperty("characterEncoding", null, Messages.getString("ConnectionProperties.characterEncoding"), "1.1g", MISC_CATEGORY, 5);
/*      */     
/*      */ 
/*  735 */     this.characterEncodingAsString = null;
/*      */     
/*  737 */     this.characterEncodingIsAliasForSjis = false;
/*      */     
/*  739 */     this.characterSetResults = new StringConnectionProperty("characterSetResults", null, Messages.getString("ConnectionProperties.characterSetResults"), "3.0.13", MISC_CATEGORY, 6);
/*      */     
/*      */ 
/*  742 */     this.connectionAttributes = new StringConnectionProperty("connectionAttributes", null, Messages.getString("ConnectionProperties.connectionAttributes"), "5.1.25", MISC_CATEGORY, 7);
/*      */     
/*      */ 
/*  745 */     this.clientInfoProvider = new StringConnectionProperty("clientInfoProvider", "com.mysql.jdbc.JDBC4CommentClientInfoProvider", Messages.getString("ConnectionProperties.clientInfoProvider"), "5.1.0", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  748 */     this.clobberStreamingResults = new BooleanConnectionProperty("clobberStreamingResults", false, Messages.getString("ConnectionProperties.clobberStreamingResults"), "3.0.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  751 */     this.clobCharacterEncoding = new StringConnectionProperty("clobCharacterEncoding", null, Messages.getString("ConnectionProperties.clobCharacterEncoding"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  754 */     this.compensateOnDuplicateKeyUpdateCounts = new BooleanConnectionProperty("compensateOnDuplicateKeyUpdateCounts", false, Messages.getString("ConnectionProperties.compensateOnDuplicateKeyUpdateCounts"), "5.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*  756 */     this.connectionCollation = new StringConnectionProperty("connectionCollation", null, Messages.getString("ConnectionProperties.connectionCollation"), "3.0.13", MISC_CATEGORY, 7);
/*      */     
/*      */ 
/*  759 */     this.connectionLifecycleInterceptors = new StringConnectionProperty("connectionLifecycleInterceptors", null, Messages.getString("ConnectionProperties.connectionLifecycleInterceptors"), "5.1.4", CONNECTION_AND_AUTH_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/*  762 */     this.connectTimeout = new IntegerConnectionProperty("connectTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.connectTimeout"), "3.0.1", CONNECTION_AND_AUTH_CATEGORY, 9);
/*      */     
/*      */ 
/*  765 */     this.continueBatchOnError = new BooleanConnectionProperty("continueBatchOnError", true, Messages.getString("ConnectionProperties.continueBatchOnError"), "3.0.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  768 */     this.createDatabaseIfNotExist = new BooleanConnectionProperty("createDatabaseIfNotExist", false, Messages.getString("ConnectionProperties.createDatabaseIfNotExist"), "3.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  771 */     this.defaultFetchSize = new IntegerConnectionProperty("defaultFetchSize", 0, Messages.getString("ConnectionProperties.defaultFetchSize"), "3.1.9", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  776 */     this.detectServerPreparedStmts = new BooleanConnectionProperty("useServerPrepStmts", false, Messages.getString("ConnectionProperties.useServerPrepStmts"), "3.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  779 */     this.dontTrackOpenResources = new BooleanConnectionProperty("dontTrackOpenResources", false, Messages.getString("ConnectionProperties.dontTrackOpenResources"), "3.1.7", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  782 */     this.dumpQueriesOnException = new BooleanConnectionProperty("dumpQueriesOnException", false, Messages.getString("ConnectionProperties.dumpQueriesOnException"), "3.1.3", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  785 */     this.dynamicCalendars = new BooleanConnectionProperty("dynamicCalendars", false, Messages.getString("ConnectionProperties.dynamicCalendars"), "3.1.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  788 */     this.elideSetAutoCommits = new BooleanConnectionProperty("elideSetAutoCommits", false, Messages.getString("ConnectionProperties.eliseSetAutoCommit"), "3.1.3", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  791 */     this.emptyStringsConvertToZero = new BooleanConnectionProperty("emptyStringsConvertToZero", true, Messages.getString("ConnectionProperties.emptyStringsConvertToZero"), "3.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  794 */     this.emulateLocators = new BooleanConnectionProperty("emulateLocators", false, Messages.getString("ConnectionProperties.emulateLocators"), "3.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  797 */     this.emulateUnsupportedPstmts = new BooleanConnectionProperty("emulateUnsupportedPstmts", true, Messages.getString("ConnectionProperties.emulateUnsupportedPstmts"), "3.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  800 */     this.enablePacketDebug = new BooleanConnectionProperty("enablePacketDebug", false, Messages.getString("ConnectionProperties.enablePacketDebug"), "3.1.3", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  803 */     this.enableQueryTimeouts = new BooleanConnectionProperty("enableQueryTimeouts", true, Messages.getString("ConnectionProperties.enableQueryTimeouts"), "5.0.6", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  806 */     this.explainSlowQueries = new BooleanConnectionProperty("explainSlowQueries", false, Messages.getString("ConnectionProperties.explainSlowQueries"), "3.1.2", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  809 */     this.exceptionInterceptors = new StringConnectionProperty("exceptionInterceptors", null, Messages.getString("ConnectionProperties.exceptionInterceptors"), "5.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*  813 */     this.failOverReadOnly = new BooleanConnectionProperty("failOverReadOnly", true, Messages.getString("ConnectionProperties.failoverReadOnly"), "3.0.12", HA_CATEGORY, 2);
/*      */     
/*      */ 
/*  816 */     this.gatherPerformanceMetrics = new BooleanConnectionProperty("gatherPerfMetrics", false, Messages.getString("ConnectionProperties.gatherPerfMetrics"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 1);
/*      */     
/*      */ 
/*  819 */     this.generateSimpleParameterMetadata = new BooleanConnectionProperty("generateSimpleParameterMetadata", false, Messages.getString("ConnectionProperties.generateSimpleParameterMetadata"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  822 */     this.highAvailabilityAsBoolean = false;
/*      */     
/*  824 */     this.holdResultsOpenOverStatementClose = new BooleanConnectionProperty("holdResultsOpenOverStatementClose", false, Messages.getString("ConnectionProperties.holdRSOpenOverStmtClose"), "3.1.7", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  827 */     this.includeInnodbStatusInDeadlockExceptions = new BooleanConnectionProperty("includeInnodbStatusInDeadlockExceptions", false, Messages.getString("ConnectionProperties.includeInnodbStatusInDeadlockExceptions"), "5.0.7", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  830 */     this.includeThreadDumpInDeadlockExceptions = new BooleanConnectionProperty("includeThreadDumpInDeadlockExceptions", false, Messages.getString("ConnectionProperties.includeThreadDumpInDeadlockExceptions"), "5.1.15", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  833 */     this.includeThreadNamesAsStatementComment = new BooleanConnectionProperty("includeThreadNamesAsStatementComment", false, Messages.getString("ConnectionProperties.includeThreadNamesAsStatementComment"), "5.1.15", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  836 */     this.ignoreNonTxTables = new BooleanConnectionProperty("ignoreNonTxTables", false, Messages.getString("ConnectionProperties.ignoreNonTxTables"), "3.0.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  839 */     this.initialTimeout = new IntegerConnectionProperty("initialTimeout", 2, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.initialTimeout"), "1.1", HA_CATEGORY, 5);
/*      */     
/*      */ 
/*  842 */     this.isInteractiveClient = new BooleanConnectionProperty("interactiveClient", false, Messages.getString("ConnectionProperties.interactiveClient"), "3.1.0", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  845 */     this.jdbcCompliantTruncation = new BooleanConnectionProperty("jdbcCompliantTruncation", true, Messages.getString("ConnectionProperties.jdbcCompliantTruncation"), "3.1.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  848 */     this.jdbcCompliantTruncationForReads = this.jdbcCompliantTruncation.getValueAsBoolean();
/*      */     
/*  850 */     this.largeRowSizeThreshold = new MemorySizeConnectionProperty("largeRowSizeThreshold", 2048, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.largeRowSizeThreshold"), "5.1.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  853 */     this.loadBalanceStrategy = new StringConnectionProperty("loadBalanceStrategy", "random", null, Messages.getString("ConnectionProperties.loadBalanceStrategy"), "5.0.6", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  856 */     this.loadBalanceBlacklistTimeout = new IntegerConnectionProperty("loadBalanceBlacklistTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.loadBalanceBlacklistTimeout"), "5.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  859 */     this.loadBalancePingTimeout = new IntegerConnectionProperty("loadBalancePingTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.loadBalancePingTimeout"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  862 */     this.loadBalanceValidateConnectionOnSwapServer = new BooleanConnectionProperty("loadBalanceValidateConnectionOnSwapServer", false, Messages.getString("ConnectionProperties.loadBalanceValidateConnectionOnSwapServer"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  865 */     this.loadBalanceConnectionGroup = new StringConnectionProperty("loadBalanceConnectionGroup", null, Messages.getString("ConnectionProperties.loadBalanceConnectionGroup"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  868 */     this.loadBalanceExceptionChecker = new StringConnectionProperty("loadBalanceExceptionChecker", "com.mysql.jdbc.StandardLoadBalanceExceptionChecker", null, Messages.getString("ConnectionProperties.loadBalanceExceptionChecker"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*  872 */     this.loadBalanceSQLStateFailover = new StringConnectionProperty("loadBalanceSQLStateFailover", null, Messages.getString("ConnectionProperties.loadBalanceSQLStateFailover"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  875 */     this.loadBalanceSQLExceptionSubclassFailover = new StringConnectionProperty("loadBalanceSQLExceptionSubclassFailover", null, Messages.getString("ConnectionProperties.loadBalanceSQLExceptionSubclassFailover"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  878 */     this.loadBalanceEnableJMX = new BooleanConnectionProperty("loadBalanceEnableJMX", false, Messages.getString("ConnectionProperties.loadBalanceEnableJMX"), "5.1.13", MISC_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/*  881 */     this.loadBalanceAutoCommitStatementRegex = new StringConnectionProperty("loadBalanceAutoCommitStatementRegex", null, Messages.getString("ConnectionProperties.loadBalanceAutoCommitStatementRegex"), "5.1.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  884 */     this.loadBalanceAutoCommitStatementThreshold = new IntegerConnectionProperty("loadBalanceAutoCommitStatementThreshold", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.loadBalanceAutoCommitStatementThreshold"), "5.1.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  887 */     this.localSocketAddress = new StringConnectionProperty("localSocketAddress", null, Messages.getString("ConnectionProperties.localSocketAddress"), "5.0.5", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  890 */     this.locatorFetchBufferSize = new MemorySizeConnectionProperty("locatorFetchBufferSize", 1048576, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.locatorFetchBufferSize"), "3.2.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  893 */     this.loggerClassName = new StringConnectionProperty("logger", STANDARD_LOGGER_NAME, Messages.getString("ConnectionProperties.logger", new Object[] { Log.class.getName(), STANDARD_LOGGER_NAME }), "3.1.1", DEBUGING_PROFILING_CATEGORY, 0);
/*      */     
/*      */ 
/*  896 */     this.logSlowQueries = new BooleanConnectionProperty("logSlowQueries", false, Messages.getString("ConnectionProperties.logSlowQueries"), "3.1.2", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  899 */     this.logXaCommands = new BooleanConnectionProperty("logXaCommands", false, Messages.getString("ConnectionProperties.logXaCommands"), "5.0.5", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  902 */     this.maintainTimeStats = new BooleanConnectionProperty("maintainTimeStats", true, Messages.getString("ConnectionProperties.maintainTimeStats"), "3.1.9", PERFORMANCE_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/*  905 */     this.maintainTimeStatsAsBoolean = true;
/*      */     
/*  907 */     this.maxQuerySizeToLog = new IntegerConnectionProperty("maxQuerySizeToLog", 2048, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.maxQuerySizeToLog"), "3.1.3", DEBUGING_PROFILING_CATEGORY, 4);
/*      */     
/*      */ 
/*  910 */     this.maxReconnects = new IntegerConnectionProperty("maxReconnects", 3, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.maxReconnects"), "1.1", HA_CATEGORY, 4);
/*      */     
/*      */ 
/*  913 */     this.retriesAllDown = new IntegerConnectionProperty("retriesAllDown", 120, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.retriesAllDown"), "5.1.6", HA_CATEGORY, 4);
/*      */     
/*      */ 
/*  916 */     this.maxRows = new IntegerConnectionProperty("maxRows", -1, -1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.maxRows"), Messages.getString("ConnectionProperties.allVersions"), MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  919 */     this.maxRowsAsInt = -1;
/*      */     
/*  921 */     this.metadataCacheSize = new IntegerConnectionProperty("metadataCacheSize", 50, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.metadataCacheSize"), "3.1.1", PERFORMANCE_CATEGORY, 5);
/*      */     
/*      */ 
/*  924 */     this.netTimeoutForStreamingResults = new IntegerConnectionProperty("netTimeoutForStreamingResults", 600, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.netTimeoutForStreamingResults"), "5.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  927 */     this.noAccessToProcedureBodies = new BooleanConnectionProperty("noAccessToProcedureBodies", false, "When determining procedure parameter types for CallableStatements, and the connected user  can't access procedure bodies through \"SHOW CREATE PROCEDURE\" or select on mysql.proc  should the driver instead create basic metadata (all parameters reported as IN VARCHARs, but allowing registerOutParameter() to be called on them anyway) instead of throwing an exception?", "5.0.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  934 */     this.noDatetimeStringSync = new BooleanConnectionProperty("noDatetimeStringSync", false, Messages.getString("ConnectionProperties.noDatetimeStringSync"), "3.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  937 */     this.noTimezoneConversionForTimeType = new BooleanConnectionProperty("noTimezoneConversionForTimeType", false, Messages.getString("ConnectionProperties.noTzConversionForTimeType"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  940 */     this.noTimezoneConversionForDateType = new BooleanConnectionProperty("noTimezoneConversionForDateType", true, Messages.getString("ConnectionProperties.noTzConversionForDateType"), "5.1.35", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  943 */     this.cacheDefaultTimezone = new BooleanConnectionProperty("cacheDefaultTimezone", true, Messages.getString("ConnectionProperties.cacheDefaultTimezone"), "5.1.35", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  946 */     this.nullCatalogMeansCurrent = new BooleanConnectionProperty("nullCatalogMeansCurrent", true, Messages.getString("ConnectionProperties.nullCatalogMeansCurrent"), "3.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  949 */     this.nullNamePatternMatchesAll = new BooleanConnectionProperty("nullNamePatternMatchesAll", true, Messages.getString("ConnectionProperties.nullNamePatternMatchesAll"), "3.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  952 */     this.packetDebugBufferSize = new IntegerConnectionProperty("packetDebugBufferSize", 20, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.packetDebugBufferSize"), "3.1.3", DEBUGING_PROFILING_CATEGORY, 7);
/*      */     
/*      */ 
/*  955 */     this.padCharsWithSpace = new BooleanConnectionProperty("padCharsWithSpace", false, Messages.getString("ConnectionProperties.padCharsWithSpace"), "5.0.6", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  958 */     this.paranoid = new BooleanConnectionProperty("paranoid", false, Messages.getString("ConnectionProperties.paranoid"), "3.0.1", SECURITY_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  961 */     this.pedantic = new BooleanConnectionProperty("pedantic", false, Messages.getString("ConnectionProperties.pedantic"), "3.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  964 */     this.pinGlobalTxToPhysicalConnection = new BooleanConnectionProperty("pinGlobalTxToPhysicalConnection", false, Messages.getString("ConnectionProperties.pinGlobalTxToPhysicalConnection"), "5.0.1", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  967 */     this.populateInsertRowWithDefaultValues = new BooleanConnectionProperty("populateInsertRowWithDefaultValues", false, Messages.getString("ConnectionProperties.populateInsertRowWithDefaultValues"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  970 */     this.preparedStatementCacheSize = new IntegerConnectionProperty("prepStmtCacheSize", 25, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.prepStmtCacheSize"), "3.0.10", PERFORMANCE_CATEGORY, 10);
/*      */     
/*      */ 
/*  973 */     this.preparedStatementCacheSqlLimit = new IntegerConnectionProperty("prepStmtCacheSqlLimit", 256, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.prepStmtCacheSqlLimit"), "3.0.10", PERFORMANCE_CATEGORY, 11);
/*      */     
/*      */ 
/*  976 */     this.parseInfoCacheFactory = new StringConnectionProperty("parseInfoCacheFactory", PerConnectionLRUFactory.class.getName(), Messages.getString("ConnectionProperties.parseInfoCacheFactory"), "5.1.1", PERFORMANCE_CATEGORY, 12);
/*      */     
/*      */ 
/*  979 */     this.processEscapeCodesForPrepStmts = new BooleanConnectionProperty("processEscapeCodesForPrepStmts", true, Messages.getString("ConnectionProperties.processEscapeCodesForPrepStmts"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  982 */     this.profilerEventHandler = new StringConnectionProperty("profilerEventHandler", "com.mysql.jdbc.profiler.LoggingProfilerEventHandler", Messages.getString("ConnectionProperties.profilerEventHandler"), "5.1.6", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*  986 */     this.profileSql = new StringConnectionProperty("profileSql", null, Messages.getString("ConnectionProperties.profileSqlDeprecated"), "2.0.14", DEBUGING_PROFILING_CATEGORY, 3);
/*      */     
/*      */ 
/*  989 */     this.profileSQL = new BooleanConnectionProperty("profileSQL", false, Messages.getString("ConnectionProperties.profileSQL"), "3.1.0", DEBUGING_PROFILING_CATEGORY, 1);
/*      */     
/*      */ 
/*  992 */     this.profileSQLAsBoolean = false;
/*      */     
/*  994 */     this.propertiesTransform = new StringConnectionProperty("propertiesTransform", null, Messages.getString("ConnectionProperties.connectionPropertiesTransform"), "3.1.4", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*  997 */     this.queriesBeforeRetryMaster = new IntegerConnectionProperty("queriesBeforeRetryMaster", 50, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.queriesBeforeRetryMaster"), "3.0.2", HA_CATEGORY, 7);
/*      */     
/*      */ 
/* 1000 */     this.queryTimeoutKillsConnection = new BooleanConnectionProperty("queryTimeoutKillsConnection", false, Messages.getString("ConnectionProperties.queryTimeoutKillsConnection"), "5.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1003 */     this.reconnectAtTxEnd = new BooleanConnectionProperty("reconnectAtTxEnd", false, Messages.getString("ConnectionProperties.reconnectAtTxEnd"), "3.0.10", HA_CATEGORY, 4);
/*      */     
/*      */ 
/* 1006 */     this.reconnectTxAtEndAsBoolean = false;
/*      */     
/* 1008 */     this.relaxAutoCommit = new BooleanConnectionProperty("relaxAutoCommit", false, Messages.getString("ConnectionProperties.relaxAutoCommit"), "2.0.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1011 */     this.reportMetricsIntervalMillis = new IntegerConnectionProperty("reportMetricsIntervalMillis", 30000, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.reportMetricsIntervalMillis"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 3);
/*      */     
/*      */ 
/* 1014 */     this.requireSSL = new BooleanConnectionProperty("requireSSL", false, Messages.getString("ConnectionProperties.requireSSL"), "3.1.0", SECURITY_CATEGORY, 3);
/*      */     
/*      */ 
/* 1017 */     this.resourceId = new StringConnectionProperty("resourceId", null, Messages.getString("ConnectionProperties.resourceId"), "5.0.1", HA_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1020 */     this.resultSetSizeThreshold = new IntegerConnectionProperty("resultSetSizeThreshold", 100, Messages.getString("ConnectionProperties.resultSetSizeThreshold"), "5.0.5", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1023 */     this.retainStatementAfterResultSetClose = new BooleanConnectionProperty("retainStatementAfterResultSetClose", false, Messages.getString("ConnectionProperties.retainStatementAfterResultSetClose"), "3.1.11", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1026 */     this.rewriteBatchedStatements = new BooleanConnectionProperty("rewriteBatchedStatements", false, Messages.getString("ConnectionProperties.rewriteBatchedStatements"), "3.1.13", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1029 */     this.rollbackOnPooledClose = new BooleanConnectionProperty("rollbackOnPooledClose", true, Messages.getString("ConnectionProperties.rollbackOnPooledClose"), "3.0.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1032 */     this.roundRobinLoadBalance = new BooleanConnectionProperty("roundRobinLoadBalance", false, Messages.getString("ConnectionProperties.roundRobinLoadBalance"), "3.1.2", HA_CATEGORY, 5);
/*      */     
/*      */ 
/* 1035 */     this.runningCTS13 = new BooleanConnectionProperty("runningCTS13", false, Messages.getString("ConnectionProperties.runningCTS13"), "3.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1038 */     this.secondsBeforeRetryMaster = new IntegerConnectionProperty("secondsBeforeRetryMaster", 30, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.secondsBeforeRetryMaster"), "3.0.2", HA_CATEGORY, 8);
/*      */     
/*      */ 
/* 1041 */     this.selfDestructOnPingSecondsLifetime = new IntegerConnectionProperty("selfDestructOnPingSecondsLifetime", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.selfDestructOnPingSecondsLifetime"), "5.1.6", HA_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 1044 */     this.selfDestructOnPingMaxOperations = new IntegerConnectionProperty("selfDestructOnPingMaxOperations", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.selfDestructOnPingMaxOperations"), "5.1.6", HA_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 1047 */     this.replicationEnableJMX = new BooleanConnectionProperty("replicationEnableJMX", false, Messages.getString("ConnectionProperties.loadBalanceEnableJMX"), "5.1.27", HA_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 1050 */     this.serverTimezone = new StringConnectionProperty("serverTimezone", null, Messages.getString("ConnectionProperties.serverTimezone"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1053 */     this.sessionVariables = new StringConnectionProperty("sessionVariables", null, Messages.getString("ConnectionProperties.sessionVariables"), "3.1.8", MISC_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 1056 */     this.slowQueryThresholdMillis = new IntegerConnectionProperty("slowQueryThresholdMillis", 2000, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.slowQueryThresholdMillis"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 9);
/*      */     
/*      */ 
/* 1059 */     this.slowQueryThresholdNanos = new LongConnectionProperty("slowQueryThresholdNanos", 0L, Messages.getString("ConnectionProperties.slowQueryThresholdNanos"), "5.0.7", DEBUGING_PROFILING_CATEGORY, 10);
/*      */     
/*      */ 
/* 1062 */     this.socketFactoryClassName = new StringConnectionProperty("socketFactory", StandardSocketFactory.class.getName(), Messages.getString("ConnectionProperties.socketFactory"), "3.0.3", CONNECTION_AND_AUTH_CATEGORY, 4);
/*      */     
/*      */ 
/* 1065 */     this.socksProxyHost = new StringConnectionProperty("socksProxyHost", null, Messages.getString("ConnectionProperties.socksProxyHost"), "5.1.34", NETWORK_CATEGORY, 1);
/*      */     
/*      */ 
/* 1068 */     this.socksProxyPort = new IntegerConnectionProperty("socksProxyPort", SocksProxySocketFactory.SOCKS_DEFAULT_PORT, 0, 65535, Messages.getString("ConnectionProperties.socksProxyPort"), "5.1.34", NETWORK_CATEGORY, 2);
/*      */     
/*      */ 
/* 1071 */     this.socketTimeout = new IntegerConnectionProperty("socketTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.socketTimeout"), "3.0.1", CONNECTION_AND_AUTH_CATEGORY, 10);
/*      */     
/*      */ 
/* 1074 */     this.statementInterceptors = new StringConnectionProperty("statementInterceptors", null, Messages.getString("ConnectionProperties.statementInterceptors"), "5.1.1", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1077 */     this.strictFloatingPoint = new BooleanConnectionProperty("strictFloatingPoint", false, Messages.getString("ConnectionProperties.strictFloatingPoint"), "3.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1080 */     this.strictUpdates = new BooleanConnectionProperty("strictUpdates", true, Messages.getString("ConnectionProperties.strictUpdates"), "3.0.4", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1083 */     this.overrideSupportsIntegrityEnhancementFacility = new BooleanConnectionProperty("overrideSupportsIntegrityEnhancementFacility", false, Messages.getString("ConnectionProperties.overrideSupportsIEF"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1087 */     this.tcpNoDelay = new BooleanConnectionProperty("tcpNoDelay", Boolean.valueOf("true").booleanValue(), Messages.getString("ConnectionProperties.tcpNoDelay"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1091 */     this.tcpKeepAlive = new BooleanConnectionProperty("tcpKeepAlive", Boolean.valueOf("true").booleanValue(), Messages.getString("ConnectionProperties.tcpKeepAlive"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1095 */     this.tcpRcvBuf = new IntegerConnectionProperty("tcpRcvBuf", Integer.parseInt("0"), 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.tcpSoRcvBuf"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1099 */     this.tcpSndBuf = new IntegerConnectionProperty("tcpSndBuf", Integer.parseInt("0"), 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.tcpSoSndBuf"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1103 */     this.tcpTrafficClass = new IntegerConnectionProperty("tcpTrafficClass", Integer.parseInt("0"), 0, 255, Messages.getString("ConnectionProperties.tcpTrafficClass"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1107 */     this.tinyInt1isBit = new BooleanConnectionProperty("tinyInt1isBit", true, Messages.getString("ConnectionProperties.tinyInt1isBit"), "3.0.16", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1110 */     this.traceProtocol = new BooleanConnectionProperty("traceProtocol", false, Messages.getString("ConnectionProperties.traceProtocol"), "3.1.2", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1113 */     this.treatUtilDateAsTimestamp = new BooleanConnectionProperty("treatUtilDateAsTimestamp", true, Messages.getString("ConnectionProperties.treatUtilDateAsTimestamp"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1116 */     this.transformedBitIsBoolean = new BooleanConnectionProperty("transformedBitIsBoolean", false, Messages.getString("ConnectionProperties.transformedBitIsBoolean"), "3.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1119 */     this.useBlobToStoreUTF8OutsideBMP = new BooleanConnectionProperty("useBlobToStoreUTF8OutsideBMP", false, Messages.getString("ConnectionProperties.useBlobToStoreUTF8OutsideBMP"), "5.1.3", MISC_CATEGORY, 128);
/*      */     
/*      */ 
/* 1122 */     this.utf8OutsideBmpExcludedColumnNamePattern = new StringConnectionProperty("utf8OutsideBmpExcludedColumnNamePattern", null, Messages.getString("ConnectionProperties.utf8OutsideBmpExcludedColumnNamePattern"), "5.1.3", MISC_CATEGORY, 129);
/*      */     
/*      */ 
/* 1125 */     this.utf8OutsideBmpIncludedColumnNamePattern = new StringConnectionProperty("utf8OutsideBmpIncludedColumnNamePattern", null, Messages.getString("ConnectionProperties.utf8OutsideBmpIncludedColumnNamePattern"), "5.1.3", MISC_CATEGORY, 129);
/*      */     
/*      */ 
/* 1128 */     this.useCompression = new BooleanConnectionProperty("useCompression", false, Messages.getString("ConnectionProperties.useCompression"), "3.0.17", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1131 */     this.useColumnNamesInFindColumn = new BooleanConnectionProperty("useColumnNamesInFindColumn", false, Messages.getString("ConnectionProperties.useColumnNamesInFindColumn"), "5.1.7", MISC_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 1134 */     this.useConfigs = new StringConnectionProperty("useConfigs", null, Messages.getString("ConnectionProperties.useConfigs"), "3.1.5", CONNECTION_AND_AUTH_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 1137 */     this.useCursorFetch = new BooleanConnectionProperty("useCursorFetch", false, Messages.getString("ConnectionProperties.useCursorFetch"), "5.0.0", PERFORMANCE_CATEGORY, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 1140 */     this.useDynamicCharsetInfo = new BooleanConnectionProperty("useDynamicCharsetInfo", true, Messages.getString("ConnectionProperties.useDynamicCharsetInfo"), "5.0.6", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1143 */     this.useDirectRowUnpack = new BooleanConnectionProperty("useDirectRowUnpack", true, "Use newer result set row unpacking code that skips a copy from network buffers  to a MySQL packet instance and instead reads directly into the result set row data buffers.", "5.1.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1148 */     this.useFastIntParsing = new BooleanConnectionProperty("useFastIntParsing", true, Messages.getString("ConnectionProperties.useFastIntParsing"), "3.1.4", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1151 */     this.useFastDateParsing = new BooleanConnectionProperty("useFastDateParsing", true, Messages.getString("ConnectionProperties.useFastDateParsing"), "5.0.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1154 */     this.useHostsInPrivileges = new BooleanConnectionProperty("useHostsInPrivileges", true, Messages.getString("ConnectionProperties.useHostsInPrivileges"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/* 1156 */     this.useInformationSchema = new BooleanConnectionProperty("useInformationSchema", false, Messages.getString("ConnectionProperties.useInformationSchema"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/* 1158 */     this.useJDBCCompliantTimezoneShift = new BooleanConnectionProperty("useJDBCCompliantTimezoneShift", false, Messages.getString("ConnectionProperties.useJDBCCompliantTimezoneShift"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1161 */     this.useLocalSessionState = new BooleanConnectionProperty("useLocalSessionState", false, Messages.getString("ConnectionProperties.useLocalSessionState"), "3.1.7", PERFORMANCE_CATEGORY, 5);
/*      */     
/*      */ 
/* 1164 */     this.useLocalTransactionState = new BooleanConnectionProperty("useLocalTransactionState", false, Messages.getString("ConnectionProperties.useLocalTransactionState"), "5.1.7", PERFORMANCE_CATEGORY, 6);
/*      */     
/*      */ 
/* 1167 */     this.useLegacyDatetimeCode = new BooleanConnectionProperty("useLegacyDatetimeCode", true, Messages.getString("ConnectionProperties.useLegacyDatetimeCode"), "5.1.6", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1170 */     this.useNanosForElapsedTime = new BooleanConnectionProperty("useNanosForElapsedTime", false, Messages.getString("ConnectionProperties.useNanosForElapsedTime"), "5.0.7", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1173 */     this.useOldAliasMetadataBehavior = new BooleanConnectionProperty("useOldAliasMetadataBehavior", false, Messages.getString("ConnectionProperties.useOldAliasMetadataBehavior"), "5.0.4", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1176 */     this.useOldUTF8Behavior = new BooleanConnectionProperty("useOldUTF8Behavior", false, Messages.getString("ConnectionProperties.useOldUtf8Behavior"), "3.1.6", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1179 */     this.useOldUTF8BehaviorAsBoolean = false;
/*      */     
/* 1181 */     this.useOnlyServerErrorMessages = new BooleanConnectionProperty("useOnlyServerErrorMessages", true, Messages.getString("ConnectionProperties.useOnlyServerErrorMessages"), "3.0.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1184 */     this.useReadAheadInput = new BooleanConnectionProperty("useReadAheadInput", true, Messages.getString("ConnectionProperties.useReadAheadInput"), "3.1.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1187 */     this.useSqlStateCodes = new BooleanConnectionProperty("useSqlStateCodes", true, Messages.getString("ConnectionProperties.useSqlStateCodes"), "3.1.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1190 */     this.useSSL = new BooleanConnectionProperty("useSSL", false, Messages.getString("ConnectionProperties.useSSL"), "3.0.2", SECURITY_CATEGORY, 2);
/*      */     
/*      */ 
/* 1193 */     this.useSSPSCompatibleTimezoneShift = new BooleanConnectionProperty("useSSPSCompatibleTimezoneShift", false, Messages.getString("ConnectionProperties.useSSPSCompatibleTimezoneShift"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1196 */     this.useStreamLengthsInPrepStmts = new BooleanConnectionProperty("useStreamLengthsInPrepStmts", true, Messages.getString("ConnectionProperties.useStreamLengthsInPrepStmts"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1199 */     this.useTimezone = new BooleanConnectionProperty("useTimezone", false, Messages.getString("ConnectionProperties.useTimezone"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1202 */     this.useUltraDevWorkAround = new BooleanConnectionProperty("ultraDevHack", false, Messages.getString("ConnectionProperties.ultraDevHack"), "2.0.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1205 */     this.useUnbufferedInput = new BooleanConnectionProperty("useUnbufferedInput", true, Messages.getString("ConnectionProperties.useUnbufferedInput"), "3.0.11", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1208 */     this.useUnicode = new BooleanConnectionProperty("useUnicode", true, Messages.getString("ConnectionProperties.useUnicode"), "1.1g", MISC_CATEGORY, 0);
/*      */     
/*      */ 
/*      */ 
/* 1212 */     this.useUnicodeAsBoolean = true;
/*      */     
/* 1214 */     this.useUsageAdvisor = new BooleanConnectionProperty("useUsageAdvisor", false, Messages.getString("ConnectionProperties.useUsageAdvisor"), "3.1.1", DEBUGING_PROFILING_CATEGORY, 10);
/*      */     
/*      */ 
/* 1217 */     this.useUsageAdvisorAsBoolean = false;
/*      */     
/* 1219 */     this.yearIsDateType = new BooleanConnectionProperty("yearIsDateType", true, Messages.getString("ConnectionProperties.yearIsDateType"), "3.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1222 */     this.zeroDateTimeBehavior = new StringConnectionProperty("zeroDateTimeBehavior", "exception", new String[] { "exception", "round", "convertToNull" }, Messages.getString("ConnectionProperties.zeroDateTimeBehavior", new Object[] { "exception", "round", "convertToNull" }), "3.1.4", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1227 */     this.useJvmCharsetConverters = new BooleanConnectionProperty("useJvmCharsetConverters", false, Messages.getString("ConnectionProperties.useJvmCharsetConverters"), "5.0.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1230 */     this.useGmtMillisForDatetimes = new BooleanConnectionProperty("useGmtMillisForDatetimes", false, Messages.getString("ConnectionProperties.useGmtMillisForDatetimes"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1233 */     this.dumpMetadataOnColumnNotFound = new BooleanConnectionProperty("dumpMetadataOnColumnNotFound", false, Messages.getString("ConnectionProperties.dumpMetadataOnColumnNotFound"), "3.1.13", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1238 */     this.clientCertificateKeyStoreUrl = new StringConnectionProperty("clientCertificateKeyStoreUrl", null, Messages.getString("ConnectionProperties.clientCertificateKeyStoreUrl"), "5.1.0", SECURITY_CATEGORY, 5);
/*      */     
/*      */ 
/* 1241 */     this.trustCertificateKeyStoreUrl = new StringConnectionProperty("trustCertificateKeyStoreUrl", null, Messages.getString("ConnectionProperties.trustCertificateKeyStoreUrl"), "5.1.0", SECURITY_CATEGORY, 8);
/*      */     
/*      */ 
/* 1244 */     this.clientCertificateKeyStoreType = new StringConnectionProperty("clientCertificateKeyStoreType", "JKS", Messages.getString("ConnectionProperties.clientCertificateKeyStoreType"), "5.1.0", SECURITY_CATEGORY, 6);
/*      */     
/*      */ 
/* 1247 */     this.clientCertificateKeyStorePassword = new StringConnectionProperty("clientCertificateKeyStorePassword", null, Messages.getString("ConnectionProperties.clientCertificateKeyStorePassword"), "5.1.0", SECURITY_CATEGORY, 7);
/*      */     
/*      */ 
/* 1250 */     this.trustCertificateKeyStoreType = new StringConnectionProperty("trustCertificateKeyStoreType", "JKS", Messages.getString("ConnectionProperties.trustCertificateKeyStoreType"), "5.1.0", SECURITY_CATEGORY, 9);
/*      */     
/*      */ 
/* 1253 */     this.trustCertificateKeyStorePassword = new StringConnectionProperty("trustCertificateKeyStorePassword", null, Messages.getString("ConnectionProperties.trustCertificateKeyStorePassword"), "5.1.0", SECURITY_CATEGORY, 10);
/*      */     
/*      */ 
/* 1256 */     this.verifyServerCertificate = new BooleanConnectionProperty("verifyServerCertificate", true, Messages.getString("ConnectionProperties.verifyServerCertificate"), "5.1.6", SECURITY_CATEGORY, 4);
/*      */     
/*      */ 
/* 1259 */     this.useAffectedRows = new BooleanConnectionProperty("useAffectedRows", false, Messages.getString("ConnectionProperties.useAffectedRows"), "5.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1262 */     this.passwordCharacterEncoding = new StringConnectionProperty("passwordCharacterEncoding", null, Messages.getString("ConnectionProperties.passwordCharacterEncoding"), "5.1.7", SECURITY_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1265 */     this.maxAllowedPacket = new IntegerConnectionProperty("maxAllowedPacket", -1, Messages.getString("ConnectionProperties.maxAllowedPacket"), "5.1.8", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1268 */     this.authenticationPlugins = new StringConnectionProperty("authenticationPlugins", null, Messages.getString("ConnectionProperties.authenticationPlugins"), "5.1.19", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1271 */     this.disabledAuthenticationPlugins = new StringConnectionProperty("disabledAuthenticationPlugins", null, Messages.getString("ConnectionProperties.disabledAuthenticationPlugins"), "5.1.19", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1274 */     this.defaultAuthenticationPlugin = new StringConnectionProperty("defaultAuthenticationPlugin", "com.mysql.jdbc.authentication.MysqlNativePasswordPlugin", Messages.getString("ConnectionProperties.defaultAuthenticationPlugin"), "5.1.19", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/*      */ 
/* 1278 */     this.disconnectOnExpiredPasswords = new BooleanConnectionProperty("disconnectOnExpiredPasswords", true, Messages.getString("ConnectionProperties.disconnectOnExpiredPasswords"), "5.1.23", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1281 */     this.getProceduresReturnsFunctions = new BooleanConnectionProperty("getProceduresReturnsFunctions", true, Messages.getString("ConnectionProperties.getProceduresReturnsFunctions"), "5.1.26", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1284 */     this.detectCustomCollations = new BooleanConnectionProperty("detectCustomCollations", false, Messages.getString("ConnectionProperties.detectCustomCollations"), "5.1.29", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1287 */     this.serverRSAPublicKeyFile = new StringConnectionProperty("serverRSAPublicKeyFile", null, Messages.getString("ConnectionProperties.serverRSAPublicKeyFile"), "5.1.31", SECURITY_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1290 */     this.allowPublicKeyRetrieval = new BooleanConnectionProperty("allowPublicKeyRetrieval", false, Messages.getString("ConnectionProperties.allowPublicKeyRetrieval"), "5.1.31", SECURITY_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1293 */     this.dontCheckOnDuplicateKeyUpdateInSQL = new BooleanConnectionProperty("dontCheckOnDuplicateKeyUpdateInSQL", false, Messages.getString("ConnectionProperties.dontCheckOnDuplicateKeyUpdateInSQL"), "5.1.32", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1296 */     this.readOnlyPropagatesToServer = new BooleanConnectionProperty("readOnlyPropagatesToServer", true, Messages.getString("ConnectionProperties.readOnlyPropagatesToServer"), "5.1.35", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */     
/*      */ 
/* 1299 */     this.enabledSSLCipherSuites = new StringConnectionProperty("enabledSSLCipherSuites", null, Messages.getString("ConnectionProperties.enabledSSLCipherSuites"), "5.1.35", SECURITY_CATEGORY, 11);
/*      */   }
/*      */   
/*      */   protected DriverPropertyInfo[] exposeAsDriverPropertyInfoInternal(Properties info, int slotsToReserve)
/*      */     throws SQLException
/*      */   {
/* 1303 */     initializeProperties(info);
/*      */     
/* 1305 */     int numProperties = PROPERTY_LIST.size();
/*      */     
/* 1307 */     int listSize = numProperties + slotsToReserve;
/*      */     
/* 1309 */     DriverPropertyInfo[] driverProperties = new DriverPropertyInfo[listSize];
/*      */     
/* 1311 */     for (int i = slotsToReserve; i < listSize; i++) {
/* 1312 */       Field propertyField = (Field)PROPERTY_LIST.get(i - slotsToReserve);
/*      */       try
/*      */       {
/* 1315 */         ConnectionProperty propToExpose = (ConnectionProperty)propertyField.get(this);
/*      */         
/* 1317 */         if (info != null) {
/* 1318 */           propToExpose.initializeFrom(info, getExceptionInterceptor());
/*      */         }
/*      */         
/* 1321 */         driverProperties[i] = propToExpose.getAsDriverPropertyInfo();
/*      */       } catch (IllegalAccessException iae) {
/* 1323 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.InternalPropertiesFailure"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1328 */     return driverProperties;
/*      */   }
/*      */   
/*      */   protected Properties exposeAsProperties(Properties info)
/*      */     throws SQLException
/*      */   {
/* 1332 */     if (info == null) {
/* 1333 */       info = new Properties();
/*      */     }
/*      */     
/* 1336 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 1338 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 1339 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       try
/*      */       {
/* 1342 */         ConnectionProperty propToGet = (ConnectionProperty)propertyField.get(this);
/*      */         
/* 1344 */         Object propValue = propToGet.getValueAsObject();
/*      */         
/* 1346 */         if (propValue != null) {
/* 1347 */           info.setProperty(propToGet.getPropertyName(), propValue.toString());
/*      */         }
/*      */       } catch (IllegalAccessException iae) {
/* 1350 */         throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/* 1354 */     return info;
/*      */   }
/*      */   
/*      */   class XmlMap
/*      */   {
/* 1358 */     protected Map<Integer, Map<String, ConnectionPropertiesImpl.ConnectionProperty>> ordered = new TreeMap();
/* 1359 */     protected Map<String, ConnectionPropertiesImpl.ConnectionProperty> alpha = new TreeMap();
/*      */     
/*      */     XmlMap() {}
/*      */   }
/*      */   
/*      */   public String exposeAsXml()
/*      */     throws SQLException
/*      */   {
/* 1368 */     StringBuilder xmlBuf = new StringBuilder();
/* 1369 */     xmlBuf.append("<ConnectionProperties>");
/*      */     
/* 1371 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 1373 */     int numCategories = PROPERTY_CATEGORIES.length;
/*      */     
/* 1375 */     Map<String, XmlMap> propertyListByCategory = new HashMap();
/*      */     
/* 1377 */     for (int i = 0; i < numCategories; i++) {
/* 1378 */       propertyListByCategory.put(PROPERTY_CATEGORIES[i], new XmlMap());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1385 */     StringConnectionProperty userProp = new StringConnectionProperty("user", null, Messages.getString("ConnectionProperties.Username"), Messages.getString("ConnectionProperties.allVersions"), CONNECTION_AND_AUTH_CATEGORY, -2147483647);
/*      */     
/*      */ 
/* 1388 */     StringConnectionProperty passwordProp = new StringConnectionProperty("password", null, Messages.getString("ConnectionProperties.Password"), Messages.getString("ConnectionProperties.allVersions"), CONNECTION_AND_AUTH_CATEGORY, -2147483646);
/*      */     
/*      */ 
/*      */ 
/* 1392 */     XmlMap connectionSortMaps = (XmlMap)propertyListByCategory.get(CONNECTION_AND_AUTH_CATEGORY);
/* 1393 */     TreeMap<String, ConnectionProperty> userMap = new TreeMap();
/* 1394 */     userMap.put(userProp.getPropertyName(), userProp);
/*      */     
/* 1396 */     connectionSortMaps.ordered.put(Integer.valueOf(userProp.getOrder()), userMap);
/*      */     
/* 1398 */     TreeMap<String, ConnectionProperty> passwordMap = new TreeMap();
/* 1399 */     passwordMap.put(passwordProp.getPropertyName(), passwordProp);
/*      */     
/* 1401 */     connectionSortMaps.ordered.put(new Integer(passwordProp.getOrder()), passwordMap);
/*      */     try
/*      */     {
/* 1404 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 1405 */         Field propertyField = (Field)PROPERTY_LIST.get(i);
/* 1406 */         ConnectionProperty propToGet = (ConnectionProperty)propertyField.get(this);
/* 1407 */         XmlMap sortMaps = (XmlMap)propertyListByCategory.get(propToGet.getCategoryName());
/* 1408 */         int orderInCategory = propToGet.getOrder();
/*      */         
/* 1410 */         if (orderInCategory == Integer.MIN_VALUE) {
/* 1411 */           sortMaps.alpha.put(propToGet.getPropertyName(), propToGet);
/*      */         } else {
/* 1413 */           Integer order = Integer.valueOf(orderInCategory);
/* 1414 */           Map<String, ConnectionProperty> orderMap = (Map)sortMaps.ordered.get(order);
/*      */           
/* 1416 */           if (orderMap == null) {
/* 1417 */             orderMap = new TreeMap();
/* 1418 */             sortMaps.ordered.put(order, orderMap);
/*      */           }
/*      */           
/* 1421 */           orderMap.put(propToGet.getPropertyName(), propToGet);
/*      */         }
/*      */       }
/*      */       
/* 1425 */       for (int j = 0; j < numCategories; j++) {
/* 1426 */         XmlMap sortMaps = (XmlMap)propertyListByCategory.get(PROPERTY_CATEGORIES[j]);
/*      */         
/* 1428 */         xmlBuf.append("\n <PropertyCategory name=\"");
/* 1429 */         xmlBuf.append(PROPERTY_CATEGORIES[j]);
/* 1430 */         xmlBuf.append("\">");
/*      */         
/* 1432 */         for (Map<String, ConnectionProperty> orderedEl : sortMaps.ordered.values()) {
/* 1433 */           for (ConnectionProperty propToGet : orderedEl.values()) {
/* 1434 */             xmlBuf.append("\n  <Property name=\"");
/* 1435 */             xmlBuf.append(propToGet.getPropertyName());
/* 1436 */             xmlBuf.append("\" required=\"");
/* 1437 */             xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */             
/* 1439 */             xmlBuf.append("\" default=\"");
/*      */             
/* 1441 */             if (propToGet.getDefaultValue() != null) {
/* 1442 */               xmlBuf.append(propToGet.getDefaultValue());
/*      */             }
/*      */             
/* 1445 */             xmlBuf.append("\" sortOrder=\"");
/* 1446 */             xmlBuf.append(propToGet.getOrder());
/* 1447 */             xmlBuf.append("\" since=\"");
/* 1448 */             xmlBuf.append(propToGet.sinceVersion);
/* 1449 */             xmlBuf.append("\">\n");
/* 1450 */             xmlBuf.append("    ");
/* 1451 */             String escapedDescription = propToGet.description;
/* 1452 */             escapedDescription = escapedDescription.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
/*      */             
/* 1454 */             xmlBuf.append(escapedDescription);
/* 1455 */             xmlBuf.append("\n  </Property>");
/*      */           }
/*      */         }
/*      */         
/* 1459 */         for (ConnectionProperty propToGet : sortMaps.alpha.values()) {
/* 1460 */           xmlBuf.append("\n  <Property name=\"");
/* 1461 */           xmlBuf.append(propToGet.getPropertyName());
/* 1462 */           xmlBuf.append("\" required=\"");
/* 1463 */           xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */           
/* 1465 */           xmlBuf.append("\" default=\"");
/*      */           
/* 1467 */           if (propToGet.getDefaultValue() != null) {
/* 1468 */             xmlBuf.append(propToGet.getDefaultValue());
/*      */           }
/*      */           
/* 1471 */           xmlBuf.append("\" sortOrder=\"alpha\" since=\"");
/* 1472 */           xmlBuf.append(propToGet.sinceVersion);
/* 1473 */           xmlBuf.append("\">\n");
/* 1474 */           xmlBuf.append("    ");
/* 1475 */           xmlBuf.append(propToGet.description);
/* 1476 */           xmlBuf.append("\n  </Property>");
/*      */         }
/*      */         
/* 1479 */         xmlBuf.append("\n </PropertyCategory>");
/*      */       }
/*      */     } catch (IllegalAccessException iae) {
/* 1482 */       throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/* 1485 */     xmlBuf.append("\n</ConnectionProperties>");
/*      */     
/* 1487 */     return xmlBuf.toString();
/*      */   }
/*      */   
/*      */   public boolean getAllowLoadLocalInfile()
/*      */   {
/* 1496 */     return this.allowLoadLocalInfile.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getAllowMultiQueries()
/*      */   {
/* 1505 */     return this.allowMultiQueries.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getAllowNanAndInf()
/*      */   {
/* 1514 */     return this.allowNanAndInf.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getAllowUrlInLocalInfile()
/*      */   {
/* 1523 */     return this.allowUrlInLocalInfile.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getAlwaysSendSetIsolation()
/*      */   {
/* 1532 */     return this.alwaysSendSetIsolation.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getAutoDeserialize()
/*      */   {
/* 1541 */     return this.autoDeserialize.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getAutoGenerateTestcaseScript()
/*      */   {
/* 1550 */     return this.autoGenerateTestcaseScriptAsBoolean;
/*      */   }
/*      */   
/*      */   public boolean getAutoReconnectForPools()
/*      */   {
/* 1559 */     return this.autoReconnectForPoolsAsBoolean;
/*      */   }
/*      */   
/*      */   public int getBlobSendChunkSize()
/*      */   {
/* 1568 */     return this.blobSendChunkSize.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getCacheCallableStatements()
/*      */   {
/* 1577 */     return this.cacheCallableStatements.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getCachePreparedStatements()
/*      */   {
/* 1586 */     return ((Boolean)this.cachePreparedStatements.getValueAsObject()).booleanValue();
/*      */   }
/*      */   
/*      */   public boolean getCacheResultSetMetadata()
/*      */   {
/* 1595 */     return this.cacheResultSetMetaDataAsBoolean;
/*      */   }
/*      */   
/*      */   public boolean getCacheServerConfiguration()
/*      */   {
/* 1604 */     return this.cacheServerConfiguration.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getCallableStatementCacheSize()
/*      */   {
/* 1613 */     return this.callableStatementCacheSize.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getCapitalizeTypeNames()
/*      */   {
/* 1622 */     return this.capitalizeTypeNames.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public String getCharacterSetResults()
/*      */   {
/* 1631 */     return this.characterSetResults.getValueAsString();
/*      */   }
/*      */   
/*      */   public String getConnectionAttributes()
/*      */   {
/* 1635 */     return this.connectionAttributes.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setConnectionAttributes(String val)
/*      */   {
/* 1639 */     this.connectionAttributes.setValue(val);
/*      */   }
/*      */   
/*      */   public boolean getClobberStreamingResults()
/*      */   {
/* 1648 */     return this.clobberStreamingResults.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public String getClobCharacterEncoding()
/*      */   {
/* 1657 */     return this.clobCharacterEncoding.getValueAsString();
/*      */   }
/*      */   
/*      */   public String getConnectionCollation()
/*      */   {
/* 1666 */     return this.connectionCollation.getValueAsString();
/*      */   }
/*      */   
/*      */   public int getConnectTimeout()
/*      */   {
/* 1675 */     return this.connectTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getContinueBatchOnError()
/*      */   {
/* 1684 */     return this.continueBatchOnError.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getCreateDatabaseIfNotExist()
/*      */   {
/* 1693 */     return this.createDatabaseIfNotExist.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getDefaultFetchSize()
/*      */   {
/* 1702 */     return this.defaultFetchSize.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getDontTrackOpenResources()
/*      */   {
/* 1711 */     return this.dontTrackOpenResources.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getDumpQueriesOnException()
/*      */   {
/* 1720 */     return this.dumpQueriesOnException.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getDynamicCalendars()
/*      */   {
/* 1729 */     return this.dynamicCalendars.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getElideSetAutoCommits()
/*      */   {
/* 1738 */     return this.elideSetAutoCommits.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getEmptyStringsConvertToZero()
/*      */   {
/* 1747 */     return this.emptyStringsConvertToZero.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getEmulateLocators()
/*      */   {
/* 1756 */     return this.emulateLocators.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getEmulateUnsupportedPstmts()
/*      */   {
/* 1765 */     return this.emulateUnsupportedPstmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getEnablePacketDebug()
/*      */   {
/* 1774 */     return this.enablePacketDebug.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public String getEncoding()
/*      */   {
/* 1783 */     return this.characterEncodingAsString;
/*      */   }
/*      */   
/*      */   public boolean getExplainSlowQueries()
/*      */   {
/* 1792 */     return this.explainSlowQueries.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getFailOverReadOnly()
/*      */   {
/* 1801 */     return this.failOverReadOnly.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getGatherPerformanceMetrics()
/*      */   {
/* 1810 */     return this.gatherPerformanceMetrics.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   protected boolean getHighAvailability()
/*      */   {
/* 1814 */     return this.highAvailabilityAsBoolean;
/*      */   }
/*      */   
/*      */   public boolean getHoldResultsOpenOverStatementClose()
/*      */   {
/* 1823 */     return this.holdResultsOpenOverStatementClose.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getIgnoreNonTxTables()
/*      */   {
/* 1832 */     return this.ignoreNonTxTables.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getInitialTimeout()
/*      */   {
/* 1841 */     return this.initialTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getInteractiveClient()
/*      */   {
/* 1850 */     return this.isInteractiveClient.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getIsInteractiveClient()
/*      */   {
/* 1859 */     return this.isInteractiveClient.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getJdbcCompliantTruncation()
/*      */   {
/* 1868 */     return this.jdbcCompliantTruncation.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getLocatorFetchBufferSize()
/*      */   {
/* 1877 */     return this.locatorFetchBufferSize.getValueAsInt();
/*      */   }
/*      */   
/*      */   public String getLogger()
/*      */   {
/* 1886 */     return this.loggerClassName.getValueAsString();
/*      */   }
/*      */   
/*      */   public String getLoggerClassName()
/*      */   {
/* 1895 */     return this.loggerClassName.getValueAsString();
/*      */   }
/*      */   
/*      */   public boolean getLogSlowQueries()
/*      */   {
/* 1904 */     return this.logSlowQueries.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getMaintainTimeStats()
/*      */   {
/* 1913 */     return this.maintainTimeStatsAsBoolean;
/*      */   }
/*      */   
/*      */   public int getMaxQuerySizeToLog()
/*      */   {
/* 1922 */     return this.maxQuerySizeToLog.getValueAsInt();
/*      */   }
/*      */   
/*      */   public int getMaxReconnects()
/*      */   {
/* 1931 */     return this.maxReconnects.getValueAsInt();
/*      */   }
/*      */   
/*      */   public int getMaxRows()
/*      */   {
/* 1940 */     return this.maxRowsAsInt;
/*      */   }
/*      */   
/*      */   public int getMetadataCacheSize()
/*      */   {
/* 1949 */     return this.metadataCacheSize.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getNoDatetimeStringSync()
/*      */   {
/* 1958 */     return this.noDatetimeStringSync.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getNullCatalogMeansCurrent()
/*      */   {
/* 1967 */     return this.nullCatalogMeansCurrent.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getNullNamePatternMatchesAll()
/*      */   {
/* 1976 */     return this.nullNamePatternMatchesAll.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getPacketDebugBufferSize()
/*      */   {
/* 1985 */     return this.packetDebugBufferSize.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getParanoid()
/*      */   {
/* 1994 */     return this.paranoid.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getPedantic()
/*      */   {
/* 2003 */     return this.pedantic.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSize()
/*      */   {
/* 2012 */     return ((Integer)this.preparedStatementCacheSize.getValueAsObject()).intValue();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSqlLimit()
/*      */   {
/* 2021 */     return ((Integer)this.preparedStatementCacheSqlLimit.getValueAsObject()).intValue();
/*      */   }
/*      */   
/*      */   public boolean getProfileSql()
/*      */   {
/* 2030 */     return this.profileSQLAsBoolean;
/*      */   }
/*      */   
/*      */   public boolean getProfileSQL()
/*      */   {
/* 2039 */     return this.profileSQL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public String getPropertiesTransform()
/*      */   {
/* 2048 */     return this.propertiesTransform.getValueAsString();
/*      */   }
/*      */   
/*      */   public int getQueriesBeforeRetryMaster()
/*      */   {
/* 2057 */     return this.queriesBeforeRetryMaster.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getReconnectAtTxEnd()
/*      */   {
/* 2066 */     return this.reconnectTxAtEndAsBoolean;
/*      */   }
/*      */   
/*      */   public boolean getRelaxAutoCommit()
/*      */   {
/* 2075 */     return this.relaxAutoCommit.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getReportMetricsIntervalMillis()
/*      */   {
/* 2084 */     return this.reportMetricsIntervalMillis.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getRequireSSL()
/*      */   {
/* 2093 */     return this.requireSSL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getRetainStatementAfterResultSetClose()
/*      */   {
/* 2097 */     return this.retainStatementAfterResultSetClose.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getRollbackOnPooledClose()
/*      */   {
/* 2106 */     return this.rollbackOnPooledClose.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getRoundRobinLoadBalance()
/*      */   {
/* 2115 */     return this.roundRobinLoadBalance.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getRunningCTS13()
/*      */   {
/* 2124 */     return this.runningCTS13.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public int getSecondsBeforeRetryMaster()
/*      */   {
/* 2133 */     return this.secondsBeforeRetryMaster.getValueAsInt();
/*      */   }
/*      */   
/*      */   public String getServerTimezone()
/*      */   {
/* 2142 */     return this.serverTimezone.getValueAsString();
/*      */   }
/*      */   
/*      */   public String getSessionVariables()
/*      */   {
/* 2151 */     return this.sessionVariables.getValueAsString();
/*      */   }
/*      */   
/*      */   public int getSlowQueryThresholdMillis()
/*      */   {
/* 2160 */     return this.slowQueryThresholdMillis.getValueAsInt();
/*      */   }
/*      */   
/*      */   public String getSocketFactoryClassName()
/*      */   {
/* 2169 */     return this.socketFactoryClassName.getValueAsString();
/*      */   }
/*      */   
/*      */   public int getSocketTimeout()
/*      */   {
/* 2178 */     return this.socketTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getStrictFloatingPoint()
/*      */   {
/* 2187 */     return this.strictFloatingPoint.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getStrictUpdates()
/*      */   {
/* 2196 */     return this.strictUpdates.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getTinyInt1isBit()
/*      */   {
/* 2205 */     return this.tinyInt1isBit.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getTraceProtocol()
/*      */   {
/* 2214 */     return this.traceProtocol.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getTransformedBitIsBoolean()
/*      */   {
/* 2223 */     return this.transformedBitIsBoolean.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseCompression()
/*      */   {
/* 2232 */     return this.useCompression.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseFastIntParsing()
/*      */   {
/* 2241 */     return this.useFastIntParsing.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseHostsInPrivileges()
/*      */   {
/* 2250 */     return this.useHostsInPrivileges.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseInformationSchema()
/*      */   {
/* 2259 */     return this.useInformationSchema.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseLocalSessionState()
/*      */   {
/* 2268 */     return this.useLocalSessionState.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseOldUTF8Behavior()
/*      */   {
/* 2277 */     return this.useOldUTF8BehaviorAsBoolean;
/*      */   }
/*      */   
/*      */   public boolean getUseOnlyServerErrorMessages()
/*      */   {
/* 2286 */     return this.useOnlyServerErrorMessages.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseReadAheadInput()
/*      */   {
/* 2295 */     return this.useReadAheadInput.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseServerPreparedStmts()
/*      */   {
/* 2304 */     return this.detectServerPreparedStmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseSqlStateCodes()
/*      */   {
/* 2313 */     return this.useSqlStateCodes.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseSSL()
/*      */   {
/* 2322 */     return this.useSSL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseStreamLengthsInPrepStmts()
/*      */   {
/* 2331 */     return this.useStreamLengthsInPrepStmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseTimezone()
/*      */   {
/* 2340 */     return this.useTimezone.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseUltraDevWorkAround()
/*      */   {
/* 2349 */     return this.useUltraDevWorkAround.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getUseUnbufferedInput()
/*      */   {
/* 2358 */     return this.useUnbufferedInput.getValueAsBoolean();
/*      */   }
/*      */   private BooleanConnectionProperty dontTrackOpenResources;
/*      */   private BooleanConnectionProperty dumpQueriesOnException;
/*      */   private BooleanConnectionProperty dynamicCalendars;
/*      */   private BooleanConnectionProperty elideSetAutoCommits;
/*      */   private BooleanConnectionProperty emptyStringsConvertToZero;
/*      */   private BooleanConnectionProperty emulateLocators;
/*      */   private BooleanConnectionProperty emulateUnsupportedPstmts;
/*      */   private BooleanConnectionProperty enablePacketDebug;
/*      */   private BooleanConnectionProperty enableQueryTimeouts;
/*      */   private BooleanConnectionProperty explainSlowQueries;
/*      */   private StringConnectionProperty exceptionInterceptors;
/*      */   private BooleanConnectionProperty failOverReadOnly;
/*      */   private BooleanConnectionProperty gatherPerformanceMetrics;
/*      */   private BooleanConnectionProperty generateSimpleParameterMetadata;
/*      */   private boolean highAvailabilityAsBoolean;
/*      */   private BooleanConnectionProperty holdResultsOpenOverStatementClose;
/*      */   private BooleanConnectionProperty includeInnodbStatusInDeadlockExceptions;
/*      */   private BooleanConnectionProperty includeThreadDumpInDeadlockExceptions;
/*      */   private BooleanConnectionProperty includeThreadNamesAsStatementComment;
/*      */   
/*      */   public boolean getUseUnicode()
/*      */   {
/* 2367 */     return this.useUnicodeAsBoolean;
/*      */   }
/*      */   
/*      */   private BooleanConnectionProperty ignoreNonTxTables;
/*      */   private IntegerConnectionProperty initialTimeout;
/*      */   private BooleanConnectionProperty isInteractiveClient;
/*      */   private BooleanConnectionProperty jdbcCompliantTruncation;
/*      */   private boolean jdbcCompliantTruncationForReads;
/*      */   protected MemorySizeConnectionProperty largeRowSizeThreshold;
/*      */   private StringConnectionProperty loadBalanceStrategy;
/*      */   private IntegerConnectionProperty loadBalanceBlacklistTimeout;
/*      */   private IntegerConnectionProperty loadBalancePingTimeout;
/*      */   
/*      */   public boolean getUseUsageAdvisor()
/*      */   {
/* 2376 */     return this.useUsageAdvisorAsBoolean; }
/*      */   
/*      */   private BooleanConnectionProperty loadBalanceValidateConnectionOnSwapServer;
/*      */   private StringConnectionProperty loadBalanceConnectionGroup;
/*      */   private StringConnectionProperty loadBalanceExceptionChecker;
/*      */   private StringConnectionProperty loadBalanceSQLStateFailover;
/*      */   private StringConnectionProperty loadBalanceSQLExceptionSubclassFailover;
/*      */   private BooleanConnectionProperty loadBalanceEnableJMX;
/*      */   private StringConnectionProperty loadBalanceAutoCommitStatementRegex; private IntegerConnectionProperty loadBalanceAutoCommitStatementThreshold; private StringConnectionProperty localSocketAddress;
/* 2385 */   public boolean getYearIsDateType() { return this.yearIsDateType.getValueAsBoolean(); }
/*      */   
/*      */   private MemorySizeConnectionProperty locatorFetchBufferSize;
/*      */   private StringConnectionProperty loggerClassName;
/*      */   private BooleanConnectionProperty logSlowQueries;
/*      */   private BooleanConnectionProperty logXaCommands;
/*      */   private BooleanConnectionProperty maintainTimeStats;
/*      */   private boolean maintainTimeStatsAsBoolean;
/*      */   private IntegerConnectionProperty maxQuerySizeToLog;
/* 2394 */   public String getZeroDateTimeBehavior() { return this.zeroDateTimeBehavior.getValueAsString(); }
/*      */   
/*      */   private IntegerConnectionProperty maxReconnects;
/*      */   private IntegerConnectionProperty retriesAllDown;
/*      */   private IntegerConnectionProperty maxRows;
/*      */   private int maxRowsAsInt;
/*      */   private IntegerConnectionProperty metadataCacheSize;
/*      */   private IntegerConnectionProperty netTimeoutForStreamingResults;
/*      */   private BooleanConnectionProperty noAccessToProcedureBodies;
/*      */   private BooleanConnectionProperty noDatetimeStringSync;
/*      */   private BooleanConnectionProperty noTimezoneConversionForTimeType;
/*      */   private BooleanConnectionProperty noTimezoneConversionForDateType;
/*      */   private BooleanConnectionProperty cacheDefaultTimezone; private BooleanConnectionProperty nullCatalogMeansCurrent; private BooleanConnectionProperty nullNamePatternMatchesAll; private IntegerConnectionProperty packetDebugBufferSize; private BooleanConnectionProperty padCharsWithSpace; private BooleanConnectionProperty paranoid;
/* 2407 */   protected void initializeFromRef(Reference ref) throws SQLException { int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 2409 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 2410 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       try
/*      */       {
/* 2413 */         ConnectionProperty propToSet = (ConnectionProperty)propertyField.get(this);
/*      */         
/* 2415 */         if (ref != null) {
/* 2416 */           propToSet.initializeFrom(ref, getExceptionInterceptor());
/*      */         }
/*      */       } catch (IllegalAccessException iae) {
/* 2419 */         throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/* 2423 */     postInitialization();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initializeProperties(Properties info)
/*      */     throws SQLException
/*      */   {
/* 2434 */     if (info != null)
/*      */     {
/* 2436 */       String profileSqlLc = info.getProperty("profileSql");
/*      */       
/* 2438 */       if (profileSqlLc != null) {
/* 2439 */         info.put("profileSQL", profileSqlLc);
/*      */       }
/*      */       
/* 2442 */       Properties infoCopy = (Properties)info.clone();
/*      */       
/* 2444 */       infoCopy.remove("HOST");
/* 2445 */       infoCopy.remove("user");
/* 2446 */       infoCopy.remove("password");
/* 2447 */       infoCopy.remove("DBNAME");
/* 2448 */       infoCopy.remove("PORT");
/* 2449 */       infoCopy.remove("profileSql");
/*      */       
/* 2451 */       int numPropertiesToSet = PROPERTY_LIST.size();
/*      */       
/* 2453 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 2454 */         Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */         try
/*      */         {
/* 2457 */           ConnectionProperty propToSet = (ConnectionProperty)propertyField.get(this);
/*      */           
/* 2459 */           propToSet.initializeFrom(infoCopy, getExceptionInterceptor());
/*      */         } catch (IllegalAccessException iae) {
/* 2461 */           throw SQLError.createSQLException(Messages.getString("ConnectionProperties.unableToInitDriverProperties") + iae.toString(), "S1000", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2466 */       postInitialization();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void postInitialization()
/*      */     throws SQLException
/*      */   {
/* 2473 */     if (this.profileSql.getValueAsObject() != null) {
/* 2474 */       this.profileSQL.initializeFrom(this.profileSql.getValueAsObject().toString(), getExceptionInterceptor());
/*      */     }
/*      */     
/* 2477 */     this.reconnectTxAtEndAsBoolean = ((Boolean)this.reconnectAtTxEnd.getValueAsObject()).booleanValue();
/*      */     
/*      */ 
/* 2480 */     if (getMaxRows() == 0)
/*      */     {
/* 2482 */       this.maxRows.setValueAsObject(Integer.valueOf(-1));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2488 */     String testEncoding = (String)this.characterEncoding.getValueAsObject();
/*      */     
/* 2490 */     if (testEncoding != null) {
/*      */       try
/*      */       {
/* 2493 */         String testString = "abc";
/* 2494 */         StringUtils.getBytes(testString, testEncoding);
/*      */       } catch (UnsupportedEncodingException UE) {
/* 2496 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.unsupportedCharacterEncoding", new Object[] { testEncoding }), "0S100", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2503 */     if (((Boolean)this.cacheResultSetMetadata.getValueAsObject()).booleanValue()) {
/*      */       try {
/* 2505 */         Class.forName("java.util.LinkedHashMap");
/*      */       } catch (ClassNotFoundException cnfe) {
/* 2507 */         this.cacheResultSetMetadata.setValue(false);
/*      */       }
/*      */     }
/*      */     
/* 2511 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/* 2512 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/* 2513 */     this.characterEncodingAsString = ((String)this.characterEncoding.getValueAsObject());
/* 2514 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/* 2515 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/* 2516 */     this.maxRowsAsInt = ((Integer)this.maxRows.getValueAsObject()).intValue();
/* 2517 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/* 2518 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/* 2519 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/* 2520 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/* 2521 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/* 2522 */     this.jdbcCompliantTruncationForReads = getJdbcCompliantTruncation();
/*      */     
/* 2524 */     if (getUseCursorFetch())
/*      */     {
/* 2526 */       setDetectServerPreparedStmts(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowLoadLocalInfile(boolean property)
/*      */   {
/* 2536 */     this.allowLoadLocalInfile.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowMultiQueries(boolean property)
/*      */   {
/* 2545 */     this.allowMultiQueries.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowNanAndInf(boolean flag)
/*      */   {
/* 2554 */     this.allowNanAndInf.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowUrlInLocalInfile(boolean flag)
/*      */   {
/* 2563 */     this.allowUrlInLocalInfile.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlwaysSendSetIsolation(boolean flag)
/*      */   {
/* 2572 */     this.alwaysSendSetIsolation.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoDeserialize(boolean flag)
/*      */   {
/* 2581 */     this.autoDeserialize.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoGenerateTestcaseScript(boolean flag)
/*      */   {
/* 2590 */     this.autoGenerateTestcaseScript.setValue(flag);
/* 2591 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnect(boolean flag)
/*      */   {
/* 2600 */     this.autoReconnect.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnectForConnectionPools(boolean property)
/*      */   {
/* 2609 */     this.autoReconnectForPools.setValue(property);
/* 2610 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnectForPools(boolean flag)
/*      */   {
/* 2619 */     this.autoReconnectForPools.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlobSendChunkSize(String value)
/*      */     throws SQLException
/*      */   {
/* 2628 */     this.blobSendChunkSize.setValue(value, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheCallableStatements(boolean flag)
/*      */   {
/* 2637 */     this.cacheCallableStatements.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCachePreparedStatements(boolean flag)
/*      */   {
/* 2646 */     this.cachePreparedStatements.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheResultSetMetadata(boolean property)
/*      */   {
/* 2655 */     this.cacheResultSetMetadata.setValue(property);
/* 2656 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheServerConfiguration(boolean flag)
/*      */   {
/* 2665 */     this.cacheServerConfiguration.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCallableStatementCacheSize(int size)
/*      */     throws SQLException
/*      */   {
/* 2674 */     this.callableStatementCacheSize.setValue(size, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCapitalizeDBMDTypes(boolean property)
/*      */   {
/* 2683 */     this.capitalizeTypeNames.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCapitalizeTypeNames(boolean flag)
/*      */   {
/* 2692 */     this.capitalizeTypeNames.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterEncoding(String encoding)
/*      */   {
/* 2701 */     this.characterEncoding.setValue(encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterSetResults(String characterSet)
/*      */   {
/* 2710 */     this.characterSetResults.setValue(characterSet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClobberStreamingResults(boolean flag)
/*      */   {
/* 2719 */     this.clobberStreamingResults.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClobCharacterEncoding(String encoding)
/*      */   {
/* 2728 */     this.clobCharacterEncoding.setValue(encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionCollation(String collation)
/*      */   {
/* 2737 */     this.connectionCollation.setValue(collation);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectTimeout(int timeoutMs)
/*      */     throws SQLException
/*      */   {
/* 2746 */     this.connectTimeout.setValue(timeoutMs, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContinueBatchOnError(boolean property)
/*      */   {
/* 2755 */     this.continueBatchOnError.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCreateDatabaseIfNotExist(boolean flag)
/*      */   {
/* 2764 */     this.createDatabaseIfNotExist.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultFetchSize(int n)
/*      */     throws SQLException
/*      */   {
/* 2773 */     this.defaultFetchSize.setValue(n, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDetectServerPreparedStmts(boolean property)
/*      */   {
/* 2782 */     this.detectServerPreparedStmts.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDontTrackOpenResources(boolean flag)
/*      */   {
/* 2791 */     this.dontTrackOpenResources.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDumpQueriesOnException(boolean flag)
/*      */   {
/* 2800 */     this.dumpQueriesOnException.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDynamicCalendars(boolean flag)
/*      */   {
/* 2809 */     this.dynamicCalendars.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setElideSetAutoCommits(boolean flag)
/*      */   {
/* 2818 */     this.elideSetAutoCommits.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEmptyStringsConvertToZero(boolean flag)
/*      */   {
/* 2827 */     this.emptyStringsConvertToZero.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEmulateLocators(boolean property)
/*      */   {
/* 2836 */     this.emulateLocators.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEmulateUnsupportedPstmts(boolean flag)
/*      */   {
/* 2845 */     this.emulateUnsupportedPstmts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnablePacketDebug(boolean flag)
/*      */   {
/* 2854 */     this.enablePacketDebug.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEncoding(String property)
/*      */   {
/* 2863 */     this.characterEncoding.setValue(property);
/* 2864 */     this.characterEncodingAsString = this.characterEncoding.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExplainSlowQueries(boolean flag)
/*      */   {
/* 2873 */     this.explainSlowQueries.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFailOverReadOnly(boolean flag)
/*      */   {
/* 2882 */     this.failOverReadOnly.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGatherPerformanceMetrics(boolean flag)
/*      */   {
/* 2891 */     this.gatherPerformanceMetrics.setValue(flag);
/*      */   }
/*      */   
/*      */   protected void setHighAvailability(boolean property) {
/* 2895 */     this.autoReconnect.setValue(property);
/* 2896 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHoldResultsOpenOverStatementClose(boolean flag)
/*      */   {
/* 2905 */     this.holdResultsOpenOverStatementClose.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIgnoreNonTxTables(boolean property)
/*      */   {
/* 2914 */     this.ignoreNonTxTables.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInitialTimeout(int property)
/*      */     throws SQLException
/*      */   {
/* 2923 */     this.initialTimeout.setValue(property, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIsInteractiveClient(boolean property)
/*      */   {
/* 2932 */     this.isInteractiveClient.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJdbcCompliantTruncation(boolean flag)
/*      */   {
/* 2941 */     this.jdbcCompliantTruncation.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocatorFetchBufferSize(String value)
/*      */     throws SQLException
/*      */   {
/* 2950 */     this.locatorFetchBufferSize.setValue(value, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogger(String property)
/*      */   {
/* 2959 */     this.loggerClassName.setValueAsObject(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoggerClassName(String className)
/*      */   {
/* 2968 */     this.loggerClassName.setValue(className);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogSlowQueries(boolean flag)
/*      */   {
/* 2977 */     this.logSlowQueries.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaintainTimeStats(boolean flag)
/*      */   {
/* 2986 */     this.maintainTimeStats.setValue(flag);
/* 2987 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxQuerySizeToLog(int sizeInBytes)
/*      */     throws SQLException
/*      */   {
/* 2996 */     this.maxQuerySizeToLog.setValue(sizeInBytes, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxReconnects(int property)
/*      */     throws SQLException
/*      */   {
/* 3005 */     this.maxReconnects.setValue(property, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxRows(int property)
/*      */     throws SQLException
/*      */   {
/* 3014 */     this.maxRows.setValue(property, getExceptionInterceptor());
/* 3015 */     this.maxRowsAsInt = this.maxRows.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMetadataCacheSize(int value)
/*      */     throws SQLException
/*      */   {
/* 3024 */     this.metadataCacheSize.setValue(value, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoDatetimeStringSync(boolean flag)
/*      */   {
/* 3033 */     this.noDatetimeStringSync.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNullCatalogMeansCurrent(boolean value)
/*      */   {
/* 3042 */     this.nullCatalogMeansCurrent.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNullNamePatternMatchesAll(boolean value)
/*      */   {
/* 3051 */     this.nullNamePatternMatchesAll.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPacketDebugBufferSize(int size)
/*      */     throws SQLException
/*      */   {
/* 3060 */     this.packetDebugBufferSize.setValue(size, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParanoid(boolean property)
/*      */   {
/* 3069 */     this.paranoid.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPedantic(boolean property)
/*      */   {
/* 3078 */     this.pedantic.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPreparedStatementCacheSize(int cacheSize)
/*      */     throws SQLException
/*      */   {
/* 3087 */     this.preparedStatementCacheSize.setValue(cacheSize, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit)
/*      */     throws SQLException
/*      */   {
/* 3096 */     this.preparedStatementCacheSqlLimit.setValue(cacheSqlLimit, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProfileSql(boolean property)
/*      */   {
/* 3105 */     this.profileSQL.setValue(property);
/* 3106 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProfileSQL(boolean flag)
/*      */   {
/* 3115 */     this.profileSQL.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPropertiesTransform(String value)
/*      */   {
/* 3124 */     this.propertiesTransform.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQueriesBeforeRetryMaster(int property)
/*      */     throws SQLException
/*      */   {
/* 3133 */     this.queriesBeforeRetryMaster.setValue(property, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReconnectAtTxEnd(boolean property)
/*      */   {
/* 3142 */     this.reconnectAtTxEnd.setValue(property);
/* 3143 */     this.reconnectTxAtEndAsBoolean = this.reconnectAtTxEnd.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRelaxAutoCommit(boolean property)
/*      */   {
/* 3152 */     this.relaxAutoCommit.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReportMetricsIntervalMillis(int millis)
/*      */     throws SQLException
/*      */   {
/* 3161 */     this.reportMetricsIntervalMillis.setValue(millis, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequireSSL(boolean property)
/*      */   {
/* 3170 */     this.requireSSL.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRetainStatementAfterResultSetClose(boolean flag)
/*      */   {
/* 3179 */     this.retainStatementAfterResultSetClose.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRollbackOnPooledClose(boolean flag)
/*      */   {
/* 3188 */     this.rollbackOnPooledClose.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoundRobinLoadBalance(boolean flag)
/*      */   {
/* 3197 */     this.roundRobinLoadBalance.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunningCTS13(boolean flag)
/*      */   {
/* 3206 */     this.runningCTS13.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecondsBeforeRetryMaster(int property)
/*      */     throws SQLException
/*      */   {
/* 3215 */     this.secondsBeforeRetryMaster.setValue(property, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerTimezone(String property)
/*      */   {
/* 3224 */     this.serverTimezone.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionVariables(String variables)
/*      */   {
/* 3233 */     this.sessionVariables.setValue(variables);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSlowQueryThresholdMillis(int millis)
/*      */     throws SQLException
/*      */   {
/* 3242 */     this.slowQueryThresholdMillis.setValue(millis, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketFactoryClassName(String property)
/*      */   {
/* 3251 */     this.socketFactoryClassName.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketTimeout(int property)
/*      */     throws SQLException
/*      */   {
/* 3260 */     this.socketTimeout.setValue(property, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStrictFloatingPoint(boolean property)
/*      */   {
/* 3269 */     this.strictFloatingPoint.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStrictUpdates(boolean property)
/*      */   {
/* 3278 */     this.strictUpdates.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTinyInt1isBit(boolean flag)
/*      */   {
/* 3287 */     this.tinyInt1isBit.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTraceProtocol(boolean flag)
/*      */   {
/* 3296 */     this.traceProtocol.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransformedBitIsBoolean(boolean flag)
/*      */   {
/* 3305 */     this.transformedBitIsBoolean.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseCompression(boolean property)
/*      */   {
/* 3314 */     this.useCompression.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseFastIntParsing(boolean flag)
/*      */   {
/* 3323 */     this.useFastIntParsing.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseHostsInPrivileges(boolean property)
/*      */   {
/* 3332 */     this.useHostsInPrivileges.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseInformationSchema(boolean flag)
/*      */   {
/* 3341 */     this.useInformationSchema.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseLocalSessionState(boolean flag)
/*      */   {
/* 3350 */     this.useLocalSessionState.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseOldUTF8Behavior(boolean flag)
/*      */   {
/* 3359 */     this.useOldUTF8Behavior.setValue(flag);
/* 3360 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseOnlyServerErrorMessages(boolean flag)
/*      */   {
/* 3369 */     this.useOnlyServerErrorMessages.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseReadAheadInput(boolean flag)
/*      */   {
/* 3378 */     this.useReadAheadInput.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseServerPreparedStmts(boolean flag)
/*      */   {
/* 3387 */     this.detectServerPreparedStmts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseSqlStateCodes(boolean flag)
/*      */   {
/* 3396 */     this.useSqlStateCodes.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseSSL(boolean property)
/*      */   {
/* 3405 */     this.useSSL.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseStreamLengthsInPrepStmts(boolean property)
/*      */   {
/* 3414 */     this.useStreamLengthsInPrepStmts.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseTimezone(boolean property)
/*      */   {
/* 3423 */     this.useTimezone.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseUltraDevWorkAround(boolean property)
/*      */   {
/* 3432 */     this.useUltraDevWorkAround.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseUnbufferedInput(boolean flag)
/*      */   {
/* 3441 */     this.useUnbufferedInput.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseUnicode(boolean flag)
/*      */   {
/* 3450 */     this.useUnicode.setValue(flag);
/* 3451 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag)
/*      */   {
/* 3460 */     this.useUsageAdvisor.setValue(useUsageAdvisorFlag);
/* 3461 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setYearIsDateType(boolean flag)
/*      */   {
/* 3470 */     this.yearIsDateType.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setZeroDateTimeBehavior(String behavior)
/*      */   {
/* 3479 */     this.zeroDateTimeBehavior.setValue(behavior);
/*      */   }
/*      */   
/*      */   protected void storeToRef(Reference ref) throws SQLException {
/* 3483 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 3485 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 3486 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       try
/*      */       {
/* 3489 */         ConnectionProperty propToStore = (ConnectionProperty)propertyField.get(this);
/*      */         
/* 3491 */         if (ref != null) {
/* 3492 */           propToStore.storeTo(ref);
/*      */         }
/*      */       } catch (IllegalAccessException iae) {
/* 3495 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.errorNotExpected"), getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean useUnbufferedInput()
/*      */   {
/* 3506 */     return this.useUnbufferedInput.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseCursorFetch()
/*      */   {
/* 3515 */     return this.useCursorFetch.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseCursorFetch(boolean flag)
/*      */   {
/* 3524 */     this.useCursorFetch.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getOverrideSupportsIntegrityEnhancementFacility()
/*      */   {
/* 3533 */     return this.overrideSupportsIntegrityEnhancementFacility.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag)
/*      */   {
/* 3542 */     this.overrideSupportsIntegrityEnhancementFacility.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getNoTimezoneConversionForTimeType()
/*      */   {
/* 3551 */     return this.noTimezoneConversionForTimeType.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoTimezoneConversionForTimeType(boolean flag)
/*      */   {
/* 3560 */     this.noTimezoneConversionForTimeType.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getNoTimezoneConversionForDateType()
/*      */   {
/* 3569 */     return this.noTimezoneConversionForDateType.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoTimezoneConversionForDateType(boolean flag)
/*      */   {
/* 3578 */     this.noTimezoneConversionForDateType.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCacheDefaultTimezone()
/*      */   {
/* 3587 */     return this.cacheDefaultTimezone.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheDefaultTimezone(boolean flag)
/*      */   {
/* 3596 */     this.cacheDefaultTimezone.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseJDBCCompliantTimezoneShift()
/*      */   {
/* 3605 */     return this.useJDBCCompliantTimezoneShift.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseJDBCCompliantTimezoneShift(boolean flag)
/*      */   {
/* 3614 */     this.useJDBCCompliantTimezoneShift.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAutoClosePStmtStreams()
/*      */   {
/* 3623 */     return this.autoClosePStmtStreams.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoClosePStmtStreams(boolean flag)
/*      */   {
/* 3632 */     this.autoClosePStmtStreams.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getProcessEscapeCodesForPrepStmts()
/*      */   {
/* 3641 */     return this.processEscapeCodesForPrepStmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessEscapeCodesForPrepStmts(boolean flag)
/*      */   {
/* 3650 */     this.processEscapeCodesForPrepStmts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseGmtMillisForDatetimes()
/*      */   {
/* 3659 */     return this.useGmtMillisForDatetimes.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseGmtMillisForDatetimes(boolean flag)
/*      */   {
/* 3668 */     this.useGmtMillisForDatetimes.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDumpMetadataOnColumnNotFound()
/*      */   {
/* 3677 */     return this.dumpMetadataOnColumnNotFound.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDumpMetadataOnColumnNotFound(boolean flag)
/*      */   {
/* 3686 */     this.dumpMetadataOnColumnNotFound.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getResourceId()
/*      */   {
/* 3695 */     return this.resourceId.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResourceId(String resourceId)
/*      */   {
/* 3704 */     this.resourceId.setValue(resourceId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3713 */   public boolean getRewriteBatchedStatements() { return this.rewriteBatchedStatements.getValueAsBoolean(); }
/*      */   private BooleanConnectionProperty pedantic;
/*      */   private BooleanConnectionProperty pinGlobalTxToPhysicalConnection;
/*      */   private BooleanConnectionProperty populateInsertRowWithDefaultValues;
/*      */   private IntegerConnectionProperty preparedStatementCacheSize;
/*      */   private IntegerConnectionProperty preparedStatementCacheSqlLimit;
/*      */   private StringConnectionProperty parseInfoCacheFactory;
/*      */   private BooleanConnectionProperty processEscapeCodesForPrepStmts;
/*      */   private StringConnectionProperty profilerEventHandler; private StringConnectionProperty profileSql; private BooleanConnectionProperty profileSQL; private boolean profileSQLAsBoolean; private StringConnectionProperty propertiesTransform;
/* 3722 */   public void setRewriteBatchedStatements(boolean flag) { this.rewriteBatchedStatements.setValue(flag); }
/*      */   
/*      */   private IntegerConnectionProperty queriesBeforeRetryMaster;
/*      */   private BooleanConnectionProperty queryTimeoutKillsConnection;
/*      */   private BooleanConnectionProperty reconnectAtTxEnd;
/*      */   private boolean reconnectTxAtEndAsBoolean;
/*      */   private BooleanConnectionProperty relaxAutoCommit;
/*      */   private IntegerConnectionProperty reportMetricsIntervalMillis;
/*      */   private BooleanConnectionProperty requireSSL; private StringConnectionProperty resourceId; private IntegerConnectionProperty resultSetSizeThreshold; private BooleanConnectionProperty retainStatementAfterResultSetClose; private BooleanConnectionProperty rewriteBatchedStatements; private BooleanConnectionProperty rollbackOnPooledClose;
/* 3731 */   public boolean getJdbcCompliantTruncationForReads() { return this.jdbcCompliantTruncationForReads; }
/*      */   
/*      */   private BooleanConnectionProperty roundRobinLoadBalance;
/*      */   private BooleanConnectionProperty runningCTS13;
/*      */   private IntegerConnectionProperty secondsBeforeRetryMaster;
/*      */   private IntegerConnectionProperty selfDestructOnPingSecondsLifetime;
/*      */   private IntegerConnectionProperty selfDestructOnPingMaxOperations;
/*      */   private BooleanConnectionProperty replicationEnableJMX;
/*      */   private StringConnectionProperty serverTimezone; private StringConnectionProperty sessionVariables; private IntegerConnectionProperty slowQueryThresholdMillis; private LongConnectionProperty slowQueryThresholdNanos; private StringConnectionProperty socketFactoryClassName;
/* 3740 */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads) { this.jdbcCompliantTruncationForReads = jdbcCompliantTruncationForReads; }
/*      */   
/*      */   private StringConnectionProperty socksProxyHost;
/*      */   private IntegerConnectionProperty socksProxyPort;
/*      */   private IntegerConnectionProperty socketTimeout;
/*      */   private StringConnectionProperty statementInterceptors;
/*      */   private BooleanConnectionProperty strictFloatingPoint;
/*      */   private BooleanConnectionProperty strictUpdates;
/*      */   private BooleanConnectionProperty overrideSupportsIntegrityEnhancementFacility; private BooleanConnectionProperty tcpNoDelay; private BooleanConnectionProperty tcpKeepAlive; private IntegerConnectionProperty tcpRcvBuf;
/* 3749 */   public boolean getUseJvmCharsetConverters() { return this.useJvmCharsetConverters.getValueAsBoolean(); }
/*      */   
/*      */   private IntegerConnectionProperty tcpSndBuf;
/*      */   private IntegerConnectionProperty tcpTrafficClass;
/*      */   private BooleanConnectionProperty tinyInt1isBit;
/*      */   protected BooleanConnectionProperty traceProtocol;
/*      */   private BooleanConnectionProperty treatUtilDateAsTimestamp;
/*      */   private BooleanConnectionProperty transformedBitIsBoolean;
/*      */   private BooleanConnectionProperty useBlobToStoreUTF8OutsideBMP; private StringConnectionProperty utf8OutsideBmpExcludedColumnNamePattern; private StringConnectionProperty utf8OutsideBmpIncludedColumnNamePattern;
/* 3758 */   public void setUseJvmCharsetConverters(boolean flag) { this.useJvmCharsetConverters.setValue(flag); }
/*      */   
/*      */   private BooleanConnectionProperty useCompression;
/*      */   private BooleanConnectionProperty useColumnNamesInFindColumn;
/*      */   private StringConnectionProperty useConfigs;
/*      */   private BooleanConnectionProperty useCursorFetch;
/*      */   private BooleanConnectionProperty useDynamicCharsetInfo;
/*      */   private BooleanConnectionProperty useDirectRowUnpack;
/*      */   private BooleanConnectionProperty useFastIntParsing; private BooleanConnectionProperty useFastDateParsing; private BooleanConnectionProperty useHostsInPrivileges;
/* 3767 */   public boolean getPinGlobalTxToPhysicalConnection() { return this.pinGlobalTxToPhysicalConnection.getValueAsBoolean(); }
/*      */   
/*      */   private BooleanConnectionProperty useInformationSchema;
/*      */   private BooleanConnectionProperty useJDBCCompliantTimezoneShift;
/*      */   private BooleanConnectionProperty useLocalSessionState;
/*      */   private BooleanConnectionProperty useLocalTransactionState;
/*      */   private BooleanConnectionProperty useLegacyDatetimeCode;
/*      */   private BooleanConnectionProperty useNanosForElapsedTime;
/*      */   private BooleanConnectionProperty useOldAliasMetadataBehavior; private BooleanConnectionProperty useOldUTF8Behavior;
/* 3776 */   public void setPinGlobalTxToPhysicalConnection(boolean flag) { this.pinGlobalTxToPhysicalConnection.setValue(flag); }
/*      */   
/*      */   private boolean useOldUTF8BehaviorAsBoolean;
/*      */   private BooleanConnectionProperty useOnlyServerErrorMessages;
/*      */   private BooleanConnectionProperty useReadAheadInput;
/*      */   private BooleanConnectionProperty useSqlStateCodes;
/*      */   private BooleanConnectionProperty useSSL;
/*      */   private BooleanConnectionProperty useSSPSCompatibleTimezoneShift;
/*      */   private BooleanConnectionProperty useStreamLengthsInPrepStmts;
/*      */   private BooleanConnectionProperty useTimezone;
/*      */   private BooleanConnectionProperty useUltraDevWorkAround;
/*      */   private BooleanConnectionProperty useUnbufferedInput;
/*      */   private BooleanConnectionProperty useUnicode;
/*      */   private boolean useUnicodeAsBoolean; private BooleanConnectionProperty useUsageAdvisor;
/* 3790 */   public void setGatherPerfMetrics(boolean flag) { setGatherPerformanceMetrics(flag); }
/*      */   
/*      */   private boolean useUsageAdvisorAsBoolean;
/*      */   private BooleanConnectionProperty yearIsDateType;
/*      */   private StringConnectionProperty zeroDateTimeBehavior;
/*      */   private BooleanConnectionProperty useJvmCharsetConverters;
/*      */   private BooleanConnectionProperty useGmtMillisForDatetimes;
/*      */   private BooleanConnectionProperty dumpMetadataOnColumnNotFound;
/*      */   private StringConnectionProperty clientCertificateKeyStoreUrl; private StringConnectionProperty trustCertificateKeyStoreUrl; private StringConnectionProperty clientCertificateKeyStoreType; private StringConnectionProperty clientCertificateKeyStorePassword; private StringConnectionProperty trustCertificateKeyStoreType; private StringConnectionProperty trustCertificateKeyStorePassword; private BooleanConnectionProperty verifyServerCertificate;
/* 3799 */   public boolean getGatherPerfMetrics() { return getGatherPerformanceMetrics(); }
/*      */   
/*      */   private BooleanConnectionProperty useAffectedRows;
/*      */   private StringConnectionProperty passwordCharacterEncoding;
/*      */   private IntegerConnectionProperty maxAllowedPacket;
/*      */   private StringConnectionProperty authenticationPlugins;
/*      */   private StringConnectionProperty disabledAuthenticationPlugins;
/*      */   private StringConnectionProperty defaultAuthenticationPlugin;
/*      */   private BooleanConnectionProperty disconnectOnExpiredPasswords;
/* 3808 */   private BooleanConnectionProperty getProceduresReturnsFunctions; private BooleanConnectionProperty detectCustomCollations; private StringConnectionProperty serverRSAPublicKeyFile; private BooleanConnectionProperty allowPublicKeyRetrieval; private BooleanConnectionProperty dontCheckOnDuplicateKeyUpdateInSQL; private BooleanConnectionProperty readOnlyPropagatesToServer; private StringConnectionProperty enabledSSLCipherSuites; public void setUltraDevHack(boolean flag) { setUseUltraDevWorkAround(flag); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUltraDevHack()
/*      */   {
/* 3817 */     return getUseUltraDevWorkAround();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInteractiveClient(boolean property)
/*      */   {
/* 3826 */     setIsInteractiveClient(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketFactory(String name)
/*      */   {
/* 3835 */     setSocketFactoryClassName(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSocketFactory()
/*      */   {
/* 3844 */     return getSocketFactoryClassName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseServerPrepStmts(boolean flag)
/*      */   {
/* 3853 */     setUseServerPreparedStmts(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseServerPrepStmts()
/*      */   {
/* 3862 */     return getUseServerPreparedStmts();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheCallableStmts(boolean flag)
/*      */   {
/* 3871 */     setCacheCallableStatements(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCacheCallableStmts()
/*      */   {
/* 3880 */     return getCacheCallableStatements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCachePrepStmts(boolean flag)
/*      */   {
/* 3889 */     setCachePreparedStatements(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCachePrepStmts()
/*      */   {
/* 3898 */     return getCachePreparedStatements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCallableStmtCacheSize(int cacheSize)
/*      */     throws SQLException
/*      */   {
/* 3907 */     setCallableStatementCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCallableStmtCacheSize()
/*      */   {
/* 3916 */     return getCallableStatementCacheSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrepStmtCacheSize(int cacheSize)
/*      */     throws SQLException
/*      */   {
/* 3925 */     setPreparedStatementCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPrepStmtCacheSize()
/*      */   {
/* 3934 */     return getPreparedStatementCacheSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrepStmtCacheSqlLimit(int sqlLimit)
/*      */     throws SQLException
/*      */   {
/* 3943 */     setPreparedStatementCacheSqlLimit(sqlLimit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPrepStmtCacheSqlLimit()
/*      */   {
/* 3952 */     return getPreparedStatementCacheSqlLimit();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getNoAccessToProcedureBodies()
/*      */   {
/* 3961 */     return this.noAccessToProcedureBodies.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoAccessToProcedureBodies(boolean flag)
/*      */   {
/* 3970 */     this.noAccessToProcedureBodies.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseOldAliasMetadataBehavior()
/*      */   {
/* 3979 */     return this.useOldAliasMetadataBehavior.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseOldAliasMetadataBehavior(boolean flag)
/*      */   {
/* 3988 */     this.useOldAliasMetadataBehavior.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClientCertificateKeyStorePassword()
/*      */   {
/* 3997 */     return this.clientCertificateKeyStorePassword.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStorePassword(String value)
/*      */   {
/* 4006 */     this.clientCertificateKeyStorePassword.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClientCertificateKeyStoreType()
/*      */   {
/* 4015 */     return this.clientCertificateKeyStoreType.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStoreType(String value)
/*      */   {
/* 4024 */     this.clientCertificateKeyStoreType.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClientCertificateKeyStoreUrl()
/*      */   {
/* 4033 */     return this.clientCertificateKeyStoreUrl.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStoreUrl(String value)
/*      */   {
/* 4042 */     this.clientCertificateKeyStoreUrl.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTrustCertificateKeyStorePassword()
/*      */   {
/* 4051 */     return this.trustCertificateKeyStorePassword.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStorePassword(String value)
/*      */   {
/* 4060 */     this.trustCertificateKeyStorePassword.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTrustCertificateKeyStoreType()
/*      */   {
/* 4069 */     return this.trustCertificateKeyStoreType.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStoreType(String value)
/*      */   {
/* 4078 */     this.trustCertificateKeyStoreType.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTrustCertificateKeyStoreUrl()
/*      */   {
/* 4087 */     return this.trustCertificateKeyStoreUrl.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStoreUrl(String value)
/*      */   {
/* 4096 */     this.trustCertificateKeyStoreUrl.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseSSPSCompatibleTimezoneShift()
/*      */   {
/* 4105 */     return this.useSSPSCompatibleTimezoneShift.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseSSPSCompatibleTimezoneShift(boolean flag)
/*      */   {
/* 4114 */     this.useSSPSCompatibleTimezoneShift.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getTreatUtilDateAsTimestamp()
/*      */   {
/* 4123 */     return this.treatUtilDateAsTimestamp.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTreatUtilDateAsTimestamp(boolean flag)
/*      */   {
/* 4132 */     this.treatUtilDateAsTimestamp.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseFastDateParsing()
/*      */   {
/* 4141 */     return this.useFastDateParsing.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseFastDateParsing(boolean flag)
/*      */   {
/* 4150 */     this.useFastDateParsing.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocalSocketAddress()
/*      */   {
/* 4159 */     return this.localSocketAddress.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocalSocketAddress(String address)
/*      */   {
/* 4168 */     this.localSocketAddress.setValue(address);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseConfigs(String configs)
/*      */   {
/* 4177 */     this.useConfigs.setValue(configs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUseConfigs()
/*      */   {
/* 4186 */     return this.useConfigs.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getGenerateSimpleParameterMetadata()
/*      */   {
/* 4195 */     return this.generateSimpleParameterMetadata.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGenerateSimpleParameterMetadata(boolean flag)
/*      */   {
/* 4204 */     this.generateSimpleParameterMetadata.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getLogXaCommands()
/*      */   {
/* 4213 */     return this.logXaCommands.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogXaCommands(boolean flag)
/*      */   {
/* 4222 */     this.logXaCommands.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetSizeThreshold()
/*      */   {
/* 4231 */     return this.resultSetSizeThreshold.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResultSetSizeThreshold(int threshold)
/*      */     throws SQLException
/*      */   {
/* 4240 */     this.resultSetSizeThreshold.setValue(threshold, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNetTimeoutForStreamingResults()
/*      */   {
/* 4249 */     return this.netTimeoutForStreamingResults.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNetTimeoutForStreamingResults(int value)
/*      */     throws SQLException
/*      */   {
/* 4258 */     this.netTimeoutForStreamingResults.setValue(value, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getEnableQueryTimeouts()
/*      */   {
/* 4267 */     return this.enableQueryTimeouts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnableQueryTimeouts(boolean flag)
/*      */   {
/* 4276 */     this.enableQueryTimeouts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPadCharsWithSpace()
/*      */   {
/* 4285 */     return this.padCharsWithSpace.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPadCharsWithSpace(boolean flag)
/*      */   {
/* 4294 */     this.padCharsWithSpace.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseDynamicCharsetInfo()
/*      */   {
/* 4303 */     return this.useDynamicCharsetInfo.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseDynamicCharsetInfo(boolean flag)
/*      */   {
/* 4312 */     this.useDynamicCharsetInfo.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClientInfoProvider()
/*      */   {
/* 4321 */     return this.clientInfoProvider.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientInfoProvider(String classname)
/*      */   {
/* 4330 */     this.clientInfoProvider.setValue(classname);
/*      */   }
/*      */   
/*      */   public boolean getPopulateInsertRowWithDefaultValues() {
/* 4334 */     return this.populateInsertRowWithDefaultValues.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setPopulateInsertRowWithDefaultValues(boolean flag) {
/* 4338 */     this.populateInsertRowWithDefaultValues.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceStrategy() {
/* 4342 */     return this.loadBalanceStrategy.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceStrategy(String strategy) {
/* 4346 */     this.loadBalanceStrategy.setValue(strategy);
/*      */   }
/*      */   
/*      */   public boolean getTcpNoDelay() {
/* 4350 */     return this.tcpNoDelay.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setTcpNoDelay(boolean flag) {
/* 4354 */     this.tcpNoDelay.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getTcpKeepAlive() {
/* 4358 */     return this.tcpKeepAlive.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setTcpKeepAlive(boolean flag) {
/* 4362 */     this.tcpKeepAlive.setValue(flag);
/*      */   }
/*      */   
/*      */   public int getTcpRcvBuf() {
/* 4366 */     return this.tcpRcvBuf.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setTcpRcvBuf(int bufSize) throws SQLException {
/* 4370 */     this.tcpRcvBuf.setValue(bufSize, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public int getTcpSndBuf() {
/* 4374 */     return this.tcpSndBuf.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setTcpSndBuf(int bufSize) throws SQLException {
/* 4378 */     this.tcpSndBuf.setValue(bufSize, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public int getTcpTrafficClass() {
/* 4382 */     return this.tcpTrafficClass.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setTcpTrafficClass(int classFlags) throws SQLException {
/* 4386 */     this.tcpTrafficClass.setValue(classFlags, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public boolean getUseNanosForElapsedTime() {
/* 4390 */     return this.useNanosForElapsedTime.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseNanosForElapsedTime(boolean flag) {
/* 4394 */     this.useNanosForElapsedTime.setValue(flag);
/*      */   }
/*      */   
/*      */   public long getSlowQueryThresholdNanos() {
/* 4398 */     return this.slowQueryThresholdNanos.getValueAsLong();
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdNanos(long nanos) throws SQLException {
/* 4402 */     this.slowQueryThresholdNanos.setValue(nanos, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public String getStatementInterceptors() {
/* 4406 */     return this.statementInterceptors.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setStatementInterceptors(String value) {
/* 4410 */     this.statementInterceptors.setValue(value);
/*      */   }
/*      */   
/*      */   public boolean getUseDirectRowUnpack() {
/* 4414 */     return this.useDirectRowUnpack.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseDirectRowUnpack(boolean flag) {
/* 4418 */     this.useDirectRowUnpack.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getLargeRowSizeThreshold() {
/* 4422 */     return this.largeRowSizeThreshold.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLargeRowSizeThreshold(String value) throws SQLException {
/* 4426 */     this.largeRowSizeThreshold.setValue(value, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public boolean getUseBlobToStoreUTF8OutsideBMP() {
/* 4430 */     return this.useBlobToStoreUTF8OutsideBMP.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag) {
/* 4434 */     this.useBlobToStoreUTF8OutsideBMP.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpExcludedColumnNamePattern() {
/* 4438 */     return this.utf8OutsideBmpExcludedColumnNamePattern.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) {
/* 4442 */     this.utf8OutsideBmpExcludedColumnNamePattern.setValue(regexPattern);
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpIncludedColumnNamePattern() {
/* 4446 */     return this.utf8OutsideBmpIncludedColumnNamePattern.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) {
/* 4450 */     this.utf8OutsideBmpIncludedColumnNamePattern.setValue(regexPattern);
/*      */   }
/*      */   
/*      */   public boolean getIncludeInnodbStatusInDeadlockExceptions() {
/* 4454 */     return this.includeInnodbStatusInDeadlockExceptions.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) {
/* 4458 */     this.includeInnodbStatusInDeadlockExceptions.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getBlobsAreStrings() {
/* 4462 */     return this.blobsAreStrings.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setBlobsAreStrings(boolean flag) {
/* 4466 */     this.blobsAreStrings.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getFunctionsNeverReturnBlobs() {
/* 4470 */     return this.functionsNeverReturnBlobs.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setFunctionsNeverReturnBlobs(boolean flag) {
/* 4474 */     this.functionsNeverReturnBlobs.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getAutoSlowLog() {
/* 4478 */     return this.autoSlowLog.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setAutoSlowLog(boolean flag) {
/* 4482 */     this.autoSlowLog.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getConnectionLifecycleInterceptors() {
/* 4486 */     return this.connectionLifecycleInterceptors.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setConnectionLifecycleInterceptors(String interceptors) {
/* 4490 */     this.connectionLifecycleInterceptors.setValue(interceptors);
/*      */   }
/*      */   
/*      */   public String getProfilerEventHandler() {
/* 4494 */     return this.profilerEventHandler.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandler(String handler) {
/* 4498 */     this.profilerEventHandler.setValue(handler);
/*      */   }
/*      */   
/*      */   public boolean getVerifyServerCertificate() {
/* 4502 */     return this.verifyServerCertificate.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setVerifyServerCertificate(boolean flag) {
/* 4506 */     this.verifyServerCertificate.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseLegacyDatetimeCode() {
/* 4510 */     return this.useLegacyDatetimeCode.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseLegacyDatetimeCode(boolean flag) {
/* 4514 */     this.useLegacyDatetimeCode.setValue(flag);
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingSecondsLifetime() {
/* 4518 */     return this.selfDestructOnPingSecondsLifetime.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingSecondsLifetime(int seconds) throws SQLException {
/* 4522 */     this.selfDestructOnPingSecondsLifetime.setValue(seconds, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingMaxOperations() {
/* 4526 */     return this.selfDestructOnPingMaxOperations.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingMaxOperations(int maxOperations) throws SQLException {
/* 4530 */     this.selfDestructOnPingMaxOperations.setValue(maxOperations, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public boolean getUseColumnNamesInFindColumn() {
/* 4534 */     return this.useColumnNamesInFindColumn.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseColumnNamesInFindColumn(boolean flag) {
/* 4538 */     this.useColumnNamesInFindColumn.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseLocalTransactionState() {
/* 4542 */     return this.useLocalTransactionState.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseLocalTransactionState(boolean flag) {
/* 4546 */     this.useLocalTransactionState.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getCompensateOnDuplicateKeyUpdateCounts() {
/* 4550 */     return this.compensateOnDuplicateKeyUpdateCounts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) {
/* 4554 */     this.compensateOnDuplicateKeyUpdateCounts.setValue(flag);
/*      */   }
/*      */   
/*      */   public int getLoadBalanceBlacklistTimeout() {
/* 4558 */     return this.loadBalanceBlacklistTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) throws SQLException {
/* 4562 */     this.loadBalanceBlacklistTimeout.setValue(loadBalanceBlacklistTimeout, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public int getLoadBalancePingTimeout() {
/* 4566 */     return this.loadBalancePingTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setLoadBalancePingTimeout(int loadBalancePingTimeout) throws SQLException {
/* 4570 */     this.loadBalancePingTimeout.setValue(loadBalancePingTimeout, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public void setRetriesAllDown(int retriesAllDown) throws SQLException {
/* 4574 */     this.retriesAllDown.setValue(retriesAllDown, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public int getRetriesAllDown() {
/* 4578 */     return this.retriesAllDown.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setUseAffectedRows(boolean flag) {
/* 4582 */     this.useAffectedRows.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseAffectedRows() {
/* 4586 */     return this.useAffectedRows.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setPasswordCharacterEncoding(String characterSet) {
/* 4590 */     this.passwordCharacterEncoding.setValue(characterSet);
/*      */   }
/*      */   
/*      */   public String getPasswordCharacterEncoding() {
/*      */     String encoding;
/* 4595 */     if ((encoding = this.passwordCharacterEncoding.getValueAsString()) != null) {
/* 4596 */       return encoding;
/*      */     }
/* 4598 */     if ((getUseUnicode()) && ((encoding = getEncoding()) != null)) {
/* 4599 */       return encoding;
/*      */     }
/* 4601 */     return "UTF-8";
/*      */   }
/*      */   
/*      */   public void setExceptionInterceptors(String exceptionInterceptors) {
/* 4605 */     this.exceptionInterceptors.setValue(exceptionInterceptors);
/*      */   }
/*      */   
/*      */   public String getExceptionInterceptors() {
/* 4609 */     return this.exceptionInterceptors.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setMaxAllowedPacket(int max) throws SQLException {
/* 4613 */     this.maxAllowedPacket.setValue(max, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public int getMaxAllowedPacket() {
/* 4617 */     return this.maxAllowedPacket.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getQueryTimeoutKillsConnection() {
/* 4621 */     return this.queryTimeoutKillsConnection.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setQueryTimeoutKillsConnection(boolean queryTimeoutKillsConnection) {
/* 4625 */     this.queryTimeoutKillsConnection.setValue(queryTimeoutKillsConnection);
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceValidateConnectionOnSwapServer() {
/* 4629 */     return this.loadBalanceValidateConnectionOnSwapServer.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceValidateConnectionOnSwapServer(boolean loadBalanceValidateConnectionOnSwapServer) {
/* 4633 */     this.loadBalanceValidateConnectionOnSwapServer.setValue(loadBalanceValidateConnectionOnSwapServer);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceConnectionGroup()
/*      */   {
/* 4638 */     return this.loadBalanceConnectionGroup.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceConnectionGroup(String loadBalanceConnectionGroup) {
/* 4642 */     this.loadBalanceConnectionGroup.setValue(loadBalanceConnectionGroup);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceExceptionChecker() {
/* 4646 */     return this.loadBalanceExceptionChecker.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceExceptionChecker(String loadBalanceExceptionChecker) {
/* 4650 */     this.loadBalanceExceptionChecker.setValue(loadBalanceExceptionChecker);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLStateFailover() {
/* 4654 */     return this.loadBalanceSQLStateFailover.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLStateFailover(String loadBalanceSQLStateFailover) {
/* 4658 */     this.loadBalanceSQLStateFailover.setValue(loadBalanceSQLStateFailover);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLExceptionSubclassFailover() {
/* 4662 */     return this.loadBalanceSQLExceptionSubclassFailover.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLExceptionSubclassFailover(String loadBalanceSQLExceptionSubclassFailover) {
/* 4666 */     this.loadBalanceSQLExceptionSubclassFailover.setValue(loadBalanceSQLExceptionSubclassFailover);
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceEnableJMX() {
/* 4670 */     return this.loadBalanceEnableJMX.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceEnableJMX(boolean loadBalanceEnableJMX) {
/* 4674 */     this.loadBalanceEnableJMX.setValue(loadBalanceEnableJMX);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementThreshold(int loadBalanceAutoCommitStatementThreshold) throws SQLException {
/* 4678 */     this.loadBalanceAutoCommitStatementThreshold.setValue(loadBalanceAutoCommitStatementThreshold, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public int getLoadBalanceAutoCommitStatementThreshold() {
/* 4682 */     return this.loadBalanceAutoCommitStatementThreshold.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementRegex(String loadBalanceAutoCommitStatementRegex) {
/* 4686 */     this.loadBalanceAutoCommitStatementRegex.setValue(loadBalanceAutoCommitStatementRegex);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceAutoCommitStatementRegex() {
/* 4690 */     return this.loadBalanceAutoCommitStatementRegex.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadDumpInDeadlockExceptions(boolean flag) {
/* 4694 */     this.includeThreadDumpInDeadlockExceptions.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadDumpInDeadlockExceptions() {
/* 4698 */     return this.includeThreadDumpInDeadlockExceptions.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadNamesAsStatementComment(boolean flag) {
/* 4702 */     this.includeThreadNamesAsStatementComment.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadNamesAsStatementComment() {
/* 4706 */     return this.includeThreadNamesAsStatementComment.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setAuthenticationPlugins(String authenticationPlugins) {
/* 4710 */     this.authenticationPlugins.setValue(authenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getAuthenticationPlugins() {
/* 4714 */     return this.authenticationPlugins.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setDisabledAuthenticationPlugins(String disabledAuthenticationPlugins) {
/* 4718 */     this.disabledAuthenticationPlugins.setValue(disabledAuthenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getDisabledAuthenticationPlugins() {
/* 4722 */     return this.disabledAuthenticationPlugins.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setDefaultAuthenticationPlugin(String defaultAuthenticationPlugin) {
/* 4726 */     this.defaultAuthenticationPlugin.setValue(defaultAuthenticationPlugin);
/*      */   }
/*      */   
/*      */   public String getDefaultAuthenticationPlugin()
/*      */   {
/* 4731 */     return this.defaultAuthenticationPlugin.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setParseInfoCacheFactory(String factoryClassname) {
/* 4735 */     this.parseInfoCacheFactory.setValue(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getParseInfoCacheFactory() {
/* 4739 */     return this.parseInfoCacheFactory.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setServerConfigCacheFactory(String factoryClassname) {
/* 4743 */     this.serverConfigCacheFactory.setValue(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getServerConfigCacheFactory() {
/* 4747 */     return this.serverConfigCacheFactory.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setDisconnectOnExpiredPasswords(boolean disconnectOnExpiredPasswords) {
/* 4751 */     this.disconnectOnExpiredPasswords.setValue(disconnectOnExpiredPasswords);
/*      */   }
/*      */   
/*      */   public boolean getDisconnectOnExpiredPasswords() {
/* 4755 */     return this.disconnectOnExpiredPasswords.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getAllowMasterDownConnections() {
/* 4759 */     return this.allowMasterDownConnections.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setAllowMasterDownConnections(boolean connectIfMasterDown) {
/* 4763 */     this.allowMasterDownConnections.setValue(connectIfMasterDown);
/*      */   }
/*      */   
/*      */   public boolean getReplicationEnableJMX() {
/* 4767 */     return this.replicationEnableJMX.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setReplicationEnableJMX(boolean replicationEnableJMX) {
/* 4771 */     this.replicationEnableJMX.setValue(replicationEnableJMX);
/*      */   }
/*      */   
/*      */   public void setGetProceduresReturnsFunctions(boolean getProcedureReturnsFunctions)
/*      */   {
/* 4776 */     this.getProceduresReturnsFunctions.setValue(getProcedureReturnsFunctions);
/*      */   }
/*      */   
/*      */   public boolean getGetProceduresReturnsFunctions() {
/* 4780 */     return this.getProceduresReturnsFunctions.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setDetectCustomCollations(boolean detectCustomCollations) {
/* 4784 */     this.detectCustomCollations.setValue(detectCustomCollations);
/*      */   }
/*      */   
/*      */   public boolean getDetectCustomCollations() {
/* 4788 */     return this.detectCustomCollations.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public String getServerRSAPublicKeyFile() {
/* 4792 */     return this.serverRSAPublicKeyFile.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setServerRSAPublicKeyFile(String serverRSAPublicKeyFile) throws SQLException {
/* 4796 */     if (this.serverRSAPublicKeyFile.getUpdateCount() > 0) {
/* 4797 */       throw SQLError.createSQLException(Messages.getString("ConnectionProperties.dynamicChangeIsNotAllowed", new Object[] { "'serverRSAPublicKeyFile'" }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/* 4801 */     this.serverRSAPublicKeyFile.setValue(serverRSAPublicKeyFile);
/*      */   }
/*      */   
/*      */   public boolean getAllowPublicKeyRetrieval() {
/* 4805 */     return this.allowPublicKeyRetrieval.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setAllowPublicKeyRetrieval(boolean allowPublicKeyRetrieval) throws SQLException {
/* 4809 */     if (this.allowPublicKeyRetrieval.getUpdateCount() > 0) {
/* 4810 */       throw SQLError.createSQLException(Messages.getString("ConnectionProperties.dynamicChangeIsNotAllowed", new Object[] { "'allowPublicKeyRetrieval'" }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/* 4814 */     this.allowPublicKeyRetrieval.setValue(allowPublicKeyRetrieval);
/*      */   }
/*      */   
/*      */   public void setDontCheckOnDuplicateKeyUpdateInSQL(boolean dontCheckOnDuplicateKeyUpdateInSQL) {
/* 4818 */     this.dontCheckOnDuplicateKeyUpdateInSQL.setValue(dontCheckOnDuplicateKeyUpdateInSQL);
/*      */   }
/*      */   
/*      */   public boolean getDontCheckOnDuplicateKeyUpdateInSQL() {
/* 4822 */     return this.dontCheckOnDuplicateKeyUpdateInSQL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setSocksProxyHost(String socksProxyHost) {
/* 4826 */     this.socksProxyHost.setValue(socksProxyHost);
/*      */   }
/*      */   
/*      */   public String getSocksProxyHost() {
/* 4830 */     return this.socksProxyHost.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setSocksProxyPort(int socksProxyPort) throws SQLException {
/* 4834 */     this.socksProxyPort.setValue(socksProxyPort, null);
/*      */   }
/*      */   
/*      */   public int getSocksProxyPort() {
/* 4838 */     return this.socksProxyPort.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getReadOnlyPropagatesToServer() {
/* 4842 */     return this.readOnlyPropagatesToServer.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setReadOnlyPropagatesToServer(boolean flag) {
/* 4846 */     this.readOnlyPropagatesToServer.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getEnabledSSLCipherSuites() {
/* 4850 */     return this.enabledSSLCipherSuites.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setEnabledSSLCipherSuites(String cipherSuites) {
/* 4854 */     this.enabledSSLCipherSuites.setValue(cipherSuites);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ConnectionPropertiesImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */