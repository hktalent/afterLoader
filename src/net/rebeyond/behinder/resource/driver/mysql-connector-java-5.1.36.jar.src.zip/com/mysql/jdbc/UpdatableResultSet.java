/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UpdatableResultSet
/*      */   extends ResultSetImpl
/*      */ {
/*   42 */   static final byte[] STREAM_DATA_MARKER = StringUtils.getBytes("** STREAM DATA **");
/*      */   
/*      */ 
/*      */   protected SingleByteCharsetConverter charConverter;
/*      */   
/*      */ 
/*      */   private String charEncoding;
/*      */   
/*      */   private byte[][] defaultColumnValue;
/*      */   
/*   52 */   private PreparedStatement deleter = null;
/*      */   
/*   54 */   private String deleteSQL = null;
/*      */   
/*   56 */   private boolean initializedCharConverter = false;
/*      */   
/*      */ 
/*   59 */   protected PreparedStatement inserter = null;
/*      */   
/*   61 */   private String insertSQL = null;
/*      */   
/*      */ 
/*   64 */   private boolean isUpdatable = false;
/*      */   
/*      */ 
/*   67 */   private String notUpdatableReason = null;
/*      */   
/*      */ 
/*   70 */   private List<Integer> primaryKeyIndicies = null;
/*      */   
/*      */   private String qualifiedAndQuotedTableName;
/*      */   
/*   74 */   private String quotedIdChar = null;
/*      */   
/*      */ 
/*      */   private PreparedStatement refresher;
/*      */   
/*   79 */   private String refreshSQL = null;
/*      */   
/*      */ 
/*      */   private ResultSetRow savedCurrentRow;
/*      */   
/*      */ 
/*   85 */   protected PreparedStatement updater = null;
/*      */   
/*      */ 
/*   88 */   private String updateSQL = null;
/*      */   
/*   90 */   private boolean populateInserterWithDefaultValues = false;
/*      */   
/*   92 */   private Map<String, Map<String, Map<String, Integer>>> databasesUsedToTablesUsed = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected UpdatableResultSet(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt)
/*      */     throws SQLException
/*      */   {
/*  110 */     super(catalog, fields, tuples, conn, creatorStmt);
/*  111 */     checkUpdatability();
/*  112 */     this.populateInserterWithDefaultValues = this.connection.getPopulateInsertRowWithDefaultValues();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean absolute(int row)
/*      */     throws SQLException
/*      */   {
/*  149 */     return super.absolute(row);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void afterLast()
/*      */     throws SQLException
/*      */   {
/*  165 */     super.afterLast();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  181 */     super.beforeFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/*  196 */     checkClosed();
/*      */     
/*  198 */     if (this.doingUpdates) {
/*  199 */       this.doingUpdates = false;
/*  200 */       this.updater.clearParameters();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void checkRowPos()
/*      */     throws SQLException
/*      */   {
/*  211 */     checkClosed();
/*      */     
/*  213 */     if (!this.onInsertRow) {
/*  214 */       super.checkRowPos();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void checkUpdatability()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  225 */       if (this.fields == null)
/*      */       {
/*      */ 
/*      */ 
/*  229 */         return;
/*      */       }
/*      */       
/*  232 */       String singleTableName = null;
/*  233 */       String catalogName = null;
/*      */       
/*  235 */       int primaryKeyCount = 0;
/*      */       
/*      */ 
/*      */ 
/*  239 */       if ((this.catalog == null) || (this.catalog.length() == 0)) {
/*  240 */         this.catalog = this.fields[0].getDatabaseName();
/*      */         
/*  242 */         if ((this.catalog == null) || (this.catalog.length() == 0)) {
/*  243 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.43"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  248 */       if (this.fields.length > 0) {
/*  249 */         singleTableName = this.fields[0].getOriginalTableName();
/*  250 */         catalogName = this.fields[0].getDatabaseName();
/*      */         
/*  252 */         if (singleTableName == null) {
/*  253 */           singleTableName = this.fields[0].getTableName();
/*  254 */           catalogName = this.catalog;
/*      */         }
/*      */         
/*  257 */         if ((singleTableName != null) && (singleTableName.length() == 0)) {
/*  258 */           this.isUpdatable = false;
/*  259 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */           
/*  261 */           return;
/*      */         }
/*      */         
/*  264 */         if (this.fields[0].isPrimaryKey()) {
/*  265 */           primaryKeyCount++;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  271 */         for (int i = 1; i < this.fields.length; i++) {
/*  272 */           String otherTableName = this.fields[i].getOriginalTableName();
/*  273 */           String otherCatalogName = this.fields[i].getDatabaseName();
/*      */           
/*  275 */           if (otherTableName == null) {
/*  276 */             otherTableName = this.fields[i].getTableName();
/*  277 */             otherCatalogName = this.catalog;
/*      */           }
/*      */           
/*  280 */           if ((otherTableName != null) && (otherTableName.length() == 0)) {
/*  281 */             this.isUpdatable = false;
/*  282 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */             
/*  284 */             return;
/*      */           }
/*      */           
/*  287 */           if ((singleTableName == null) || (!otherTableName.equals(singleTableName))) {
/*  288 */             this.isUpdatable = false;
/*  289 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.0");
/*      */             
/*  291 */             return;
/*      */           }
/*      */           
/*      */ 
/*  295 */           if ((catalogName == null) || (!otherCatalogName.equals(catalogName))) {
/*  296 */             this.isUpdatable = false;
/*  297 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.1");
/*      */             
/*  299 */             return;
/*      */           }
/*      */           
/*  302 */           if (this.fields[i].isPrimaryKey()) {
/*  303 */             primaryKeyCount++;
/*      */           }
/*      */         }
/*      */         
/*  307 */         if ((singleTableName == null) || (singleTableName.length() == 0)) {
/*  308 */           this.isUpdatable = false;
/*  309 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.2");
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  314 */         this.isUpdatable = false;
/*  315 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */         
/*  317 */         return;
/*      */       }
/*      */       
/*  320 */       if (this.connection.getStrictUpdates()) {
/*  321 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */         
/*  323 */         ResultSet rs = null;
/*  324 */         HashMap<String, String> primaryKeyNames = new HashMap();
/*      */         try
/*      */         {
/*  327 */           rs = dbmd.getPrimaryKeys(catalogName, null, singleTableName);
/*      */           
/*  329 */           while (rs.next()) {
/*  330 */             String keyName = rs.getString(4);
/*  331 */             keyName = keyName.toUpperCase();
/*  332 */             primaryKeyNames.put(keyName, keyName);
/*      */           }
/*      */         } finally {
/*  335 */           if (rs != null) {
/*      */             try {
/*  337 */               rs.close();
/*      */             } catch (Exception ex) {
/*  339 */               AssertionFailedException.shouldNotHappen(ex);
/*      */             }
/*      */             
/*  342 */             rs = null;
/*      */           }
/*      */         }
/*      */         
/*  346 */         int existingPrimaryKeysCount = primaryKeyNames.size();
/*      */         
/*  348 */         if (existingPrimaryKeysCount == 0) {
/*  349 */           this.isUpdatable = false;
/*  350 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.5");
/*      */           
/*  352 */           return;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  358 */         for (int i = 0; i < this.fields.length; i++) {
/*  359 */           if (this.fields[i].isPrimaryKey()) {
/*  360 */             String columnNameUC = this.fields[i].getName().toUpperCase();
/*      */             
/*  362 */             if (primaryKeyNames.remove(columnNameUC) == null)
/*      */             {
/*  364 */               String originalName = this.fields[i].getOriginalName();
/*      */               
/*  366 */               if ((originalName != null) && 
/*  367 */                 (primaryKeyNames.remove(originalName.toUpperCase()) == null))
/*      */               {
/*  369 */                 this.isUpdatable = false;
/*  370 */                 this.notUpdatableReason = Messages.getString("NotUpdatableReason.6", new Object[] { originalName });
/*      */                 
/*  372 */                 return;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  379 */         this.isUpdatable = primaryKeyNames.isEmpty();
/*      */         
/*  381 */         if (!this.isUpdatable) {
/*  382 */           if (existingPrimaryKeysCount > 1) {
/*  383 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.7");
/*      */           } else {
/*  385 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */           }
/*      */           
/*  388 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  395 */       if (primaryKeyCount == 0) {
/*  396 */         this.isUpdatable = false;
/*  397 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */         
/*  399 */         return;
/*      */       }
/*      */       
/*  402 */       this.isUpdatable = true;
/*  403 */       this.notUpdatableReason = null;
/*      */       
/*  405 */       return;
/*      */     } catch (SQLException sqlEx) {
/*  407 */       this.isUpdatable = false;
/*  408 */       this.notUpdatableReason = sqlEx.getMessage();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void deleteRow()
/*      */     throws SQLException
/*      */   {
/*  424 */     checkClosed();
/*      */     
/*  426 */     if (!this.isUpdatable) {
/*  427 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/*  430 */     if (this.onInsertRow)
/*  431 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.1"), getExceptionInterceptor());
/*  432 */     if (this.rowData.size() == 0)
/*  433 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.2"), getExceptionInterceptor());
/*  434 */     if (isBeforeFirst())
/*  435 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.3"), getExceptionInterceptor());
/*  436 */     if (isAfterLast()) {
/*  437 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.4"), getExceptionInterceptor());
/*      */     }
/*      */     
/*  440 */     if (this.deleter == null) {
/*  441 */       if (this.deleteSQL == null) {
/*  442 */         generateStatements();
/*      */       }
/*      */       
/*  445 */       this.deleter = ((PreparedStatement)this.connection.clientPrepareStatement(this.deleteSQL));
/*      */     }
/*      */     
/*  448 */     this.deleter.clearParameters();
/*      */     
/*  450 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/*  452 */     if (numKeys == 1) {
/*  453 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*  454 */       setParamValue(this.deleter, 1, this.thisRow, index, this.fields[index].getSQLType());
/*      */     } else {
/*  456 */       for (int i = 0; i < numKeys; i++) {
/*  457 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*  458 */         setParamValue(this.deleter, i + 1, this.thisRow, index, this.fields[index].getSQLType());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  463 */     this.deleter.executeUpdate();
/*  464 */     this.rowData.removeRow(this.rowData.getCurrentRowNumber());
/*      */     
/*      */ 
/*  467 */     previous();
/*      */   }
/*      */   
/*      */   private synchronized void setParamValue(PreparedStatement ps, int psIdx, ResultSetRow row, int rsIdx, int sqlType)
/*      */     throws SQLException
/*      */   {
/*  473 */     byte[] val = row.getColumnValue(rsIdx);
/*  474 */     if (val == null) {
/*  475 */       ps.setNull(psIdx, 0);
/*  476 */       return;
/*      */     }
/*  478 */     switch (sqlType) {
/*      */     case 0: 
/*  480 */       ps.setNull(psIdx, 0);
/*  481 */       break;
/*      */     case -6: 
/*      */     case 4: 
/*      */     case 5: 
/*  485 */       ps.setInt(psIdx, row.getInt(rsIdx));
/*  486 */       break;
/*      */     case -5: 
/*  488 */       ps.setLong(psIdx, row.getLong(rsIdx));
/*  489 */       break;
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 12: 
/*  495 */       ps.setString(psIdx, row.getString(rsIdx, this.charEncoding, this.connection));
/*  496 */       break;
/*      */     case 91: 
/*  498 */       ps.setDate(psIdx, row.getDateFast(rsIdx, this.connection, this, this.fastDefaultCal), this.fastDefaultCal);
/*  499 */       break;
/*      */     case 93: 
/*  501 */       ps.setTimestamp(psIdx, row.getTimestampFast(rsIdx, this.fastDefaultCal, this.connection.getDefaultTimeZone(), false, this.connection, this));
/*  502 */       break;
/*      */     case 92: 
/*  504 */       ps.setTime(psIdx, row.getTimeFast(rsIdx, this.fastDefaultCal, this.connection.getDefaultTimeZone(), false, this.connection, this));
/*  505 */       break;
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*      */     case 16: 
/*  510 */       ps.setBytesNoEscapeNoQuotes(psIdx, val);
/*  511 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     default: 
/*  518 */       ps.setBytes(psIdx, val);
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void extractDefaultValues()
/*      */     throws SQLException
/*      */   {
/*  525 */     DatabaseMetaData dbmd = this.connection.getMetaData();
/*  526 */     this.defaultColumnValue = new byte[this.fields.length][];
/*      */     
/*  528 */     ResultSet columnsResultSet = null;
/*      */     
/*  530 */     for (Map.Entry<String, Map<String, Map<String, Integer>>> dbEntry : this.databasesUsedToTablesUsed.entrySet())
/*      */     {
/*  532 */       for (Map.Entry<String, Map<String, Integer>> tableEntry : ((Map)dbEntry.getValue()).entrySet()) {
/*  533 */         String tableName = (String)tableEntry.getKey();
/*  534 */         Map<String, Integer> columnNamesToIndices = (Map)tableEntry.getValue();
/*      */         try
/*      */         {
/*  537 */           columnsResultSet = dbmd.getColumns(this.catalog, null, tableName, "%");
/*      */           
/*  539 */           while (columnsResultSet.next()) {
/*  540 */             String columnName = columnsResultSet.getString("COLUMN_NAME");
/*  541 */             byte[] defaultValue = columnsResultSet.getBytes("COLUMN_DEF");
/*      */             
/*  543 */             if (columnNamesToIndices.containsKey(columnName)) {
/*  544 */               int localColumnIndex = ((Integer)columnNamesToIndices.get(columnName)).intValue();
/*      */               
/*  546 */               this.defaultColumnValue[localColumnIndex] = defaultValue;
/*      */             }
/*      */           }
/*      */         } finally {
/*  550 */           if (columnsResultSet != null) {
/*  551 */             columnsResultSet.close();
/*      */             
/*  553 */             columnsResultSet = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean first()
/*      */     throws SQLException
/*      */   {
/*  575 */     return super.first();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void generateStatements()
/*      */     throws SQLException
/*      */   {
/*  586 */     if (!this.isUpdatable) {
/*  587 */       this.doingUpdates = false;
/*  588 */       this.onInsertRow = false;
/*      */       
/*  590 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/*  593 */     String quotedId = getQuotedIdChar();
/*      */     
/*  595 */     Map<String, String> tableNamesSoFar = null;
/*      */     
/*  597 */     if (this.connection.lowerCaseTableNames()) {
/*  598 */       tableNamesSoFar = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*  599 */       this.databasesUsedToTablesUsed = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */     } else {
/*  601 */       tableNamesSoFar = new TreeMap();
/*  602 */       this.databasesUsedToTablesUsed = new TreeMap();
/*      */     }
/*      */     
/*  605 */     this.primaryKeyIndicies = new ArrayList();
/*      */     
/*  607 */     StringBuilder fieldValues = new StringBuilder();
/*  608 */     StringBuilder keyValues = new StringBuilder();
/*  609 */     StringBuilder columnNames = new StringBuilder();
/*  610 */     StringBuilder insertPlaceHolders = new StringBuilder();
/*  611 */     StringBuilder allTablesBuf = new StringBuilder();
/*  612 */     Map<Integer, String> columnIndicesToTable = new HashMap();
/*      */     
/*  614 */     boolean firstTime = true;
/*  615 */     boolean keysFirstTime = true;
/*      */     
/*  617 */     String equalsStr = this.connection.versionMeetsMinimum(3, 23, 0) ? "<=>" : "=";
/*      */     
/*  619 */     for (int i = 0; i < this.fields.length; i++) {
/*  620 */       StringBuilder tableNameBuffer = new StringBuilder();
/*  621 */       Map<String, Integer> updColumnNameToIndex = null;
/*      */       
/*      */ 
/*  624 */       if (this.fields[i].getOriginalTableName() != null)
/*      */       {
/*  626 */         String databaseName = this.fields[i].getDatabaseName();
/*      */         
/*  628 */         if ((databaseName != null) && (databaseName.length() > 0)) {
/*  629 */           tableNameBuffer.append(quotedId);
/*  630 */           tableNameBuffer.append(databaseName);
/*  631 */           tableNameBuffer.append(quotedId);
/*  632 */           tableNameBuffer.append('.');
/*      */         }
/*      */         
/*  635 */         String tableOnlyName = this.fields[i].getOriginalTableName();
/*      */         
/*  637 */         tableNameBuffer.append(quotedId);
/*  638 */         tableNameBuffer.append(tableOnlyName);
/*  639 */         tableNameBuffer.append(quotedId);
/*      */         
/*  641 */         String fqTableName = tableNameBuffer.toString();
/*      */         
/*  643 */         if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  644 */           if (!tableNamesSoFar.isEmpty()) {
/*  645 */             allTablesBuf.append(',');
/*      */           }
/*      */           
/*  648 */           allTablesBuf.append(fqTableName);
/*  649 */           tableNamesSoFar.put(fqTableName, fqTableName);
/*      */         }
/*      */         
/*  652 */         columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */         
/*  654 */         updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(databaseName, tableOnlyName);
/*      */       } else {
/*  656 */         String tableOnlyName = this.fields[i].getTableName();
/*      */         
/*  658 */         if (tableOnlyName != null) {
/*  659 */           tableNameBuffer.append(quotedId);
/*  660 */           tableNameBuffer.append(tableOnlyName);
/*  661 */           tableNameBuffer.append(quotedId);
/*      */           
/*  663 */           String fqTableName = tableNameBuffer.toString();
/*      */           
/*  665 */           if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  666 */             if (!tableNamesSoFar.isEmpty()) {
/*  667 */               allTablesBuf.append(',');
/*      */             }
/*      */             
/*  670 */             allTablesBuf.append(fqTableName);
/*  671 */             tableNamesSoFar.put(fqTableName, fqTableName);
/*      */           }
/*      */           
/*  674 */           columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */           
/*  676 */           updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(this.catalog, tableOnlyName);
/*      */         }
/*      */       }
/*      */       
/*  680 */       String originalColumnName = this.fields[i].getOriginalName();
/*  681 */       String columnName = null;
/*      */       
/*  683 */       if ((this.connection.getIO().hasLongColumnInfo()) && (originalColumnName != null) && (originalColumnName.length() > 0)) {
/*  684 */         columnName = originalColumnName;
/*      */       } else {
/*  686 */         columnName = this.fields[i].getName();
/*      */       }
/*      */       
/*  689 */       if ((updColumnNameToIndex != null) && (columnName != null)) {
/*  690 */         updColumnNameToIndex.put(columnName, Integer.valueOf(i));
/*      */       }
/*      */       
/*  693 */       String originalTableName = this.fields[i].getOriginalTableName();
/*  694 */       String tableName = null;
/*      */       
/*  696 */       if ((this.connection.getIO().hasLongColumnInfo()) && (originalTableName != null) && (originalTableName.length() > 0)) {
/*  697 */         tableName = originalTableName;
/*      */       } else {
/*  699 */         tableName = this.fields[i].getTableName();
/*      */       }
/*      */       
/*  702 */       StringBuilder fqcnBuf = new StringBuilder();
/*  703 */       String databaseName = this.fields[i].getDatabaseName();
/*      */       
/*  705 */       if ((databaseName != null) && (databaseName.length() > 0)) {
/*  706 */         fqcnBuf.append(quotedId);
/*  707 */         fqcnBuf.append(databaseName);
/*  708 */         fqcnBuf.append(quotedId);
/*  709 */         fqcnBuf.append('.');
/*      */       }
/*      */       
/*  712 */       fqcnBuf.append(quotedId);
/*  713 */       fqcnBuf.append(tableName);
/*  714 */       fqcnBuf.append(quotedId);
/*  715 */       fqcnBuf.append('.');
/*  716 */       fqcnBuf.append(quotedId);
/*  717 */       fqcnBuf.append(columnName);
/*  718 */       fqcnBuf.append(quotedId);
/*      */       
/*  720 */       String qualifiedColumnName = fqcnBuf.toString();
/*      */       
/*  722 */       if (this.fields[i].isPrimaryKey()) {
/*  723 */         this.primaryKeyIndicies.add(Integer.valueOf(i));
/*      */         
/*  725 */         if (!keysFirstTime) {
/*  726 */           keyValues.append(" AND ");
/*      */         } else {
/*  728 */           keysFirstTime = false;
/*      */         }
/*      */         
/*  731 */         keyValues.append(qualifiedColumnName);
/*  732 */         keyValues.append(equalsStr);
/*  733 */         keyValues.append("?");
/*      */       }
/*      */       
/*  736 */       if (firstTime) {
/*  737 */         firstTime = false;
/*  738 */         fieldValues.append("SET ");
/*      */       } else {
/*  740 */         fieldValues.append(",");
/*  741 */         columnNames.append(",");
/*  742 */         insertPlaceHolders.append(",");
/*      */       }
/*      */       
/*  745 */       insertPlaceHolders.append("?");
/*      */       
/*  747 */       columnNames.append(qualifiedColumnName);
/*      */       
/*  749 */       fieldValues.append(qualifiedColumnName);
/*  750 */       fieldValues.append("=?");
/*      */     }
/*      */     
/*  753 */     this.qualifiedAndQuotedTableName = allTablesBuf.toString();
/*      */     
/*  755 */     this.updateSQL = ("UPDATE " + this.qualifiedAndQuotedTableName + " " + fieldValues.toString() + " WHERE " + keyValues.toString());
/*  756 */     this.insertSQL = ("INSERT INTO " + this.qualifiedAndQuotedTableName + " (" + columnNames.toString() + ") VALUES (" + insertPlaceHolders.toString() + ")");
/*  757 */     this.refreshSQL = ("SELECT " + columnNames.toString() + " FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
/*  758 */     this.deleteSQL = ("DELETE FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
/*      */   }
/*      */   
/*      */   private Map<String, Integer> getColumnsToIndexMapForTableAndDB(String databaseName, String tableName)
/*      */   {
/*  763 */     Map<String, Map<String, Integer>> tablesUsedToColumnsMap = (Map)this.databasesUsedToTablesUsed.get(databaseName);
/*      */     
/*  765 */     if (tablesUsedToColumnsMap == null) {
/*  766 */       if (this.connection.lowerCaseTableNames()) {
/*  767 */         tablesUsedToColumnsMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */       } else {
/*  769 */         tablesUsedToColumnsMap = new TreeMap();
/*      */       }
/*      */       
/*  772 */       this.databasesUsedToTablesUsed.put(databaseName, tablesUsedToColumnsMap);
/*      */     }
/*      */     
/*  775 */     Map<String, Integer> nameToIndex = (Map)tablesUsedToColumnsMap.get(tableName);
/*      */     
/*  777 */     if (nameToIndex == null) {
/*  778 */       nameToIndex = new HashMap();
/*  779 */       tablesUsedToColumnsMap.put(tableName, nameToIndex);
/*      */     }
/*      */     
/*  782 */     return nameToIndex;
/*      */   }
/*      */   
/*      */   private synchronized SingleByteCharsetConverter getCharConverter() throws SQLException {
/*  786 */     if (!this.initializedCharConverter) {
/*  787 */       this.initializedCharConverter = true;
/*      */       
/*  789 */       if (this.connection.getUseUnicode()) {
/*  790 */         this.charEncoding = this.connection.getEncoding();
/*  791 */         this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */       }
/*      */     }
/*      */     
/*  795 */     return this.charConverter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/*  809 */     return this.isUpdatable ? 1008 : 1007;
/*      */   }
/*      */   
/*      */   private synchronized String getQuotedIdChar() throws SQLException {
/*  813 */     if (this.quotedIdChar == null) {
/*  814 */       boolean useQuotedIdentifiers = this.connection.supportsQuotedIdentifiers();
/*      */       
/*  816 */       if (useQuotedIdentifiers) {
/*  817 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*  818 */         this.quotedIdChar = dbmd.getIdentifierQuoteString();
/*      */       } else {
/*  820 */         this.quotedIdChar = "";
/*      */       }
/*      */     }
/*      */     
/*  824 */     return this.quotedIdChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void insertRow()
/*      */     throws SQLException
/*      */   {
/*  838 */     checkClosed();
/*      */     
/*  840 */     if (!this.onInsertRow) {
/*  841 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.7"), getExceptionInterceptor());
/*      */     }
/*      */     
/*  844 */     this.inserter.executeUpdate();
/*      */     
/*  846 */     long autoIncrementId = this.inserter.getLastInsertID();
/*  847 */     int numFields = this.fields.length;
/*  848 */     byte[][] newRow = new byte[numFields][];
/*      */     
/*  850 */     for (int i = 0; i < numFields; i++) {
/*  851 */       if (this.inserter.isNull(i)) {
/*  852 */         newRow[i] = null;
/*      */       } else {
/*  854 */         newRow[i] = this.inserter.getBytesRepresentation(i);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  860 */       if ((this.fields[i].isAutoIncrement()) && (autoIncrementId > 0L)) {
/*  861 */         newRow[i] = StringUtils.getBytes(String.valueOf(autoIncrementId));
/*  862 */         this.inserter.setBytesNoEscapeNoQuotes(i + 1, newRow[i]);
/*      */       }
/*      */     }
/*      */     
/*  866 */     ResultSetRow resultSetRow = new ByteArrayRow(newRow, getExceptionInterceptor());
/*      */     
/*  868 */     refreshRow(this.inserter, resultSetRow);
/*      */     
/*  870 */     this.rowData.addRow(resultSetRow);
/*  871 */     resetInserter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  889 */     return super.isAfterLast();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  907 */     return super.isBeforeFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  924 */     return super.isFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  942 */     return super.isLast();
/*      */   }
/*      */   
/*      */   boolean isUpdatable() {
/*  946 */     return this.isUpdatable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean last()
/*      */     throws SQLException
/*      */   {
/*  964 */     return super.last();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/*  979 */     checkClosed();
/*      */     
/*  981 */     if (!this.isUpdatable) {
/*  982 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/*  985 */     if (this.onInsertRow) {
/*  986 */       this.onInsertRow = false;
/*  987 */       this.thisRow = this.savedCurrentRow;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 1009 */     checkClosed();
/*      */     
/* 1011 */     if (!this.isUpdatable) {
/* 1012 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/* 1015 */     if (this.inserter == null) {
/* 1016 */       if (this.insertSQL == null) {
/* 1017 */         generateStatements();
/*      */       }
/*      */       
/* 1020 */       this.inserter = ((PreparedStatement)this.connection.clientPrepareStatement(this.insertSQL));
/* 1021 */       if (this.populateInserterWithDefaultValues) {
/* 1022 */         extractDefaultValues();
/*      */       }
/*      */       
/* 1025 */       resetInserter();
/*      */     } else {
/* 1027 */       resetInserter();
/*      */     }
/*      */     
/* 1030 */     int numFields = this.fields.length;
/*      */     
/* 1032 */     this.onInsertRow = true;
/* 1033 */     this.doingUpdates = false;
/* 1034 */     this.savedCurrentRow = this.thisRow;
/* 1035 */     byte[][] newRowData = new byte[numFields][];
/* 1036 */     this.thisRow = new ByteArrayRow(newRowData, getExceptionInterceptor());
/*      */     
/* 1038 */     for (int i = 0; i < numFields; i++) {
/* 1039 */       if (!this.populateInserterWithDefaultValues) {
/* 1040 */         this.inserter.setBytesNoEscapeNoQuotes(i + 1, StringUtils.getBytes("DEFAULT"));
/* 1041 */         newRowData = (byte[][])null;
/*      */       }
/* 1043 */       else if (this.defaultColumnValue[i] != null) {
/* 1044 */         Field f = this.fields[i];
/*      */         
/* 1046 */         switch (f.getMysqlType())
/*      */         {
/*      */         case 7: 
/*      */         case 10: 
/*      */         case 11: 
/*      */         case 12: 
/*      */         case 14: 
/* 1053 */           if ((this.defaultColumnValue[i].length > 7) && (this.defaultColumnValue[i][0] == 67) && (this.defaultColumnValue[i][1] == 85) && (this.defaultColumnValue[i][2] == 82) && (this.defaultColumnValue[i][3] == 82) && (this.defaultColumnValue[i][4] == 69) && (this.defaultColumnValue[i][5] == 78) && (this.defaultColumnValue[i][6] == 84) && (this.defaultColumnValue[i][7] == 95))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1058 */             this.inserter.setBytesNoEscapeNoQuotes(i + 1, this.defaultColumnValue[i]);
/*      */           }
/* 1060 */           break;
/*      */         }
/*      */         
/* 1063 */         this.inserter.setBytes(i + 1, this.defaultColumnValue[i], false, false);
/*      */         
/*      */ 
/*      */ 
/* 1067 */         byte[] defaultValueCopy = new byte[this.defaultColumnValue[i].length];
/* 1068 */         System.arraycopy(this.defaultColumnValue[i], 0, defaultValueCopy, 0, defaultValueCopy.length);
/* 1069 */         newRowData[i] = defaultValueCopy;
/*      */       } else {
/* 1071 */         this.inserter.setNull(i + 1, 0);
/* 1072 */         newRowData[i] = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean next()
/*      */     throws SQLException
/*      */   {
/* 1098 */     return super.next();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean prev()
/*      */     throws SQLException
/*      */   {
/* 1117 */     return super.prev();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean previous()
/*      */     throws SQLException
/*      */   {
/* 1139 */     return super.previous();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void realClose(boolean calledExplicitly)
/*      */     throws SQLException
/*      */   {
/* 1154 */     if (this.isClosed) {
/* 1155 */       return;
/*      */     }
/*      */     
/* 1158 */     SQLException sqlEx = null;
/*      */     
/* 1160 */     if ((this.useUsageAdvisor) && 
/* 1161 */       (this.deleter == null) && (this.inserter == null) && (this.refresher == null) && (this.updater == null)) {
/* 1162 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */       
/* 1164 */       String message = Messages.getString("UpdatableResultSet.34");
/*      */       
/* 1166 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1173 */       if (this.deleter != null) {
/* 1174 */         this.deleter.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1177 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1181 */       if (this.inserter != null) {
/* 1182 */         this.inserter.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1185 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1189 */       if (this.refresher != null) {
/* 1190 */         this.refresher.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1193 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1197 */       if (this.updater != null) {
/* 1198 */         this.updater.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1201 */       sqlEx = ex;
/*      */     }
/*      */     
/* 1204 */     super.realClose(calledExplicitly);
/*      */     
/* 1206 */     if (sqlEx != null) {
/* 1207 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 1232 */     checkClosed();
/*      */     
/* 1234 */     if (!this.isUpdatable) {
/* 1235 */       throw new NotUpdatable();
/*      */     }
/*      */     
/* 1238 */     if (this.onInsertRow)
/* 1239 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.8"), getExceptionInterceptor());
/* 1240 */     if (this.rowData.size() == 0)
/* 1241 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.9"), getExceptionInterceptor());
/* 1242 */     if (isBeforeFirst())
/* 1243 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.10"), getExceptionInterceptor());
/* 1244 */     if (isAfterLast()) {
/* 1245 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.11"), getExceptionInterceptor());
/*      */     }
/*      */     
/* 1248 */     refreshRow(this.updater, this.thisRow);
/*      */   }
/*      */   
/*      */   private synchronized void refreshRow(PreparedStatement updateInsertStmt, ResultSetRow rowToRefresh) throws SQLException {
/* 1252 */     if (this.refresher == null) {
/* 1253 */       if (this.refreshSQL == null) {
/* 1254 */         generateStatements();
/*      */       }
/*      */       
/* 1257 */       this.refresher = ((PreparedStatement)this.connection.clientPrepareStatement(this.refreshSQL));
/*      */     }
/*      */     
/* 1260 */     this.refresher.clearParameters();
/*      */     
/* 1262 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/* 1264 */     if (numKeys == 1) {
/* 1265 */       byte[] dataFrom = null;
/* 1266 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */       
/* 1268 */       if ((!this.doingUpdates) && (!this.onInsertRow)) {
/* 1269 */         dataFrom = rowToRefresh.getColumnValue(index);
/*      */       } else {
/* 1271 */         dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */         
/*      */ 
/* 1274 */         if ((updateInsertStmt.isNull(index)) || (dataFrom.length == 0)) {
/* 1275 */           dataFrom = rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1277 */           dataFrom = stripBinaryPrefix(dataFrom);
/*      */         }
/*      */       }
/*      */       
/* 1281 */       if (this.fields[index].getvalueNeedsQuoting()) {
/* 1282 */         this.refresher.setBytesNoEscape(1, dataFrom);
/*      */       } else {
/* 1284 */         this.refresher.setBytesNoEscapeNoQuotes(1, dataFrom);
/*      */       }
/*      */     }
/*      */     else {
/* 1288 */       for (int i = 0; i < numKeys; i++) {
/* 1289 */         byte[] dataFrom = null;
/* 1290 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */         
/* 1292 */         if ((!this.doingUpdates) && (!this.onInsertRow)) {
/* 1293 */           dataFrom = rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1295 */           dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */           
/*      */ 
/* 1298 */           if ((updateInsertStmt.isNull(index)) || (dataFrom.length == 0)) {
/* 1299 */             dataFrom = rowToRefresh.getColumnValue(index);
/*      */           } else {
/* 1301 */             dataFrom = stripBinaryPrefix(dataFrom);
/*      */           }
/*      */         }
/*      */         
/* 1305 */         this.refresher.setBytesNoEscape(i + 1, dataFrom);
/*      */       }
/*      */     }
/*      */     
/* 1309 */     ResultSet rs = null;
/*      */     try
/*      */     {
/* 1312 */       rs = this.refresher.executeQuery();
/*      */       
/* 1314 */       int numCols = rs.getMetaData().getColumnCount();
/*      */       
/* 1316 */       if (rs.next()) {
/* 1317 */         for (int i = 0; i < numCols; i++) {
/* 1318 */           byte[] val = rs.getBytes(i + 1);
/*      */           
/* 1320 */           if ((val == null) || (rs.wasNull())) {
/* 1321 */             rowToRefresh.setColumnValue(i, null);
/*      */           } else {
/* 1323 */             rowToRefresh.setColumnValue(i, rs.getBytes(i + 1));
/*      */           }
/*      */         }
/*      */       } else {
/* 1327 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.12"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     } finally {
/* 1330 */       if (rs != null) {
/*      */         try {
/* 1332 */           rs.close();
/*      */         }
/*      */         catch (SQLException ex) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean relative(int rows)
/*      */     throws SQLException
/*      */   {
/* 1363 */     return super.relative(rows);
/*      */   }
/*      */   
/*      */   private void resetInserter() throws SQLException {
/* 1367 */     this.inserter.clearParameters();
/*      */     
/* 1369 */     for (int i = 0; i < this.fields.length; i++) {
/* 1370 */       this.inserter.setNull(i + 1, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 1390 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 1408 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 1426 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 1437 */     super.setResultSetConcurrency(concurrencyFlag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] stripBinaryPrefix(byte[] dataFrom)
/*      */   {
/* 1451 */     return StringUtils.stripEnclosure(dataFrom, "_binary'", "'");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void syncUpdate()
/*      */     throws SQLException
/*      */   {
/* 1461 */     if (this.updater == null) {
/* 1462 */       if (this.updateSQL == null) {
/* 1463 */         generateStatements();
/*      */       }
/*      */       
/* 1466 */       this.updater = ((PreparedStatement)this.connection.clientPrepareStatement(this.updateSQL));
/*      */     }
/*      */     
/* 1469 */     int numFields = this.fields.length;
/* 1470 */     this.updater.clearParameters();
/*      */     
/* 1472 */     for (int i = 0; i < numFields; i++) {
/* 1473 */       if (this.thisRow.getColumnValue(i) != null)
/*      */       {
/* 1475 */         if (this.fields[i].getvalueNeedsQuoting()) {
/* 1476 */           this.updater.setBytes(i + 1, this.thisRow.getColumnValue(i), this.fields[i].isBinary(), false);
/*      */         } else {
/* 1478 */           this.updater.setBytesNoEscapeNoQuotes(i + 1, this.thisRow.getColumnValue(i));
/*      */         }
/*      */       } else {
/* 1481 */         this.updater.setNull(i + 1, 0);
/*      */       }
/*      */     }
/*      */     
/* 1485 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/* 1487 */     if (numKeys == 1) {
/* 1488 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/* 1489 */       setParamValue(this.updater, numFields + 1, this.thisRow, index, this.fields[index].getSQLType());
/*      */     } else {
/* 1491 */       for (int i = 0; i < numKeys; i++) {
/* 1492 */         int idx = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/* 1493 */         setParamValue(this.updater, numFields + i + 1, this.thisRow, idx, this.fields[idx].getSQLType());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateAsciiStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1517 */     if (!this.onInsertRow) {
/* 1518 */       if (!this.doingUpdates) {
/* 1519 */         this.doingUpdates = true;
/* 1520 */         syncUpdate();
/*      */       }
/*      */       
/* 1523 */       this.updater.setAsciiStream(columnIndex, x, length);
/*      */     } else {
/* 1525 */       this.inserter.setAsciiStream(columnIndex, x, length);
/* 1526 */       this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateAsciiStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1549 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBigDecimal(int columnIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1568 */     if (!this.onInsertRow) {
/* 1569 */       if (!this.doingUpdates) {
/* 1570 */         this.doingUpdates = true;
/* 1571 */         syncUpdate();
/*      */       }
/*      */       
/* 1574 */       this.updater.setBigDecimal(columnIndex, x);
/*      */     } else {
/* 1576 */       this.inserter.setBigDecimal(columnIndex, x);
/*      */       
/* 1578 */       if (x == null) {
/* 1579 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1581 */         this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x.toString()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBigDecimal(String columnName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1602 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBinaryStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1624 */     if (!this.onInsertRow) {
/* 1625 */       if (!this.doingUpdates) {
/* 1626 */         this.doingUpdates = true;
/* 1627 */         syncUpdate();
/*      */       }
/*      */       
/* 1630 */       this.updater.setBinaryStream(columnIndex, x, length);
/*      */     } else {
/* 1632 */       this.inserter.setBinaryStream(columnIndex, x, length);
/*      */       
/* 1634 */       if (x == null) {
/* 1635 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1637 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBinaryStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1661 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized void updateBlob(int columnIndex, Blob blob)
/*      */     throws SQLException
/*      */   {
/* 1669 */     if (!this.onInsertRow) {
/* 1670 */       if (!this.doingUpdates) {
/* 1671 */         this.doingUpdates = true;
/* 1672 */         syncUpdate();
/*      */       }
/*      */       
/* 1675 */       this.updater.setBlob(columnIndex, blob);
/*      */     } else {
/* 1677 */       this.inserter.setBlob(columnIndex, blob);
/*      */       
/* 1679 */       if (blob == null) {
/* 1680 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1682 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized void updateBlob(String columnName, Blob blob)
/*      */     throws SQLException
/*      */   {
/* 1692 */     updateBlob(findColumn(columnName), blob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBoolean(int columnIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1711 */     if (!this.onInsertRow) {
/* 1712 */       if (!this.doingUpdates) {
/* 1713 */         this.doingUpdates = true;
/* 1714 */         syncUpdate();
/*      */       }
/*      */       
/* 1717 */       this.updater.setBoolean(columnIndex, x);
/*      */     } else {
/* 1719 */       this.inserter.setBoolean(columnIndex, x);
/*      */       
/* 1721 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBoolean(String columnName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1741 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateByte(int columnIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 1760 */     if (!this.onInsertRow) {
/* 1761 */       if (!this.doingUpdates) {
/* 1762 */         this.doingUpdates = true;
/* 1763 */         syncUpdate();
/*      */       }
/*      */       
/* 1766 */       this.updater.setByte(columnIndex, x);
/*      */     } else {
/* 1768 */       this.inserter.setByte(columnIndex, x);
/*      */       
/* 1770 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateByte(String columnName, byte x)
/*      */     throws SQLException
/*      */   {
/* 1790 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBytes(int columnIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1809 */     if (!this.onInsertRow) {
/* 1810 */       if (!this.doingUpdates) {
/* 1811 */         this.doingUpdates = true;
/* 1812 */         syncUpdate();
/*      */       }
/*      */       
/* 1815 */       this.updater.setBytes(columnIndex, x);
/*      */     } else {
/* 1817 */       this.inserter.setBytes(columnIndex, x);
/*      */       
/* 1819 */       this.thisRow.setColumnValue(columnIndex - 1, x);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBytes(String columnName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1839 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateCharacterStream(int columnIndex, Reader x, int length)
/*      */     throws SQLException
/*      */   {
/* 1861 */     if (!this.onInsertRow) {
/* 1862 */       if (!this.doingUpdates) {
/* 1863 */         this.doingUpdates = true;
/* 1864 */         syncUpdate();
/*      */       }
/*      */       
/* 1867 */       this.updater.setCharacterStream(columnIndex, x, length);
/*      */     } else {
/* 1869 */       this.inserter.setCharacterStream(columnIndex, x, length);
/*      */       
/* 1871 */       if (x == null) {
/* 1872 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1874 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateCharacterStream(String columnName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1898 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateClob(int columnIndex, Clob clob)
/*      */     throws SQLException
/*      */   {
/* 1906 */     if (clob == null) {
/* 1907 */       updateNull(columnIndex);
/*      */     } else {
/* 1909 */       updateCharacterStream(columnIndex, clob.getCharacterStream(), (int)clob.length());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDate(int columnIndex, Date x)
/*      */     throws SQLException
/*      */   {
/* 1929 */     if (!this.onInsertRow) {
/* 1930 */       if (!this.doingUpdates) {
/* 1931 */         this.doingUpdates = true;
/* 1932 */         syncUpdate();
/*      */       }
/*      */       
/* 1935 */       this.updater.setDate(columnIndex, x);
/*      */     } else {
/* 1937 */       this.inserter.setDate(columnIndex, x);
/*      */       
/* 1939 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDate(String columnName, Date x)
/*      */     throws SQLException
/*      */   {
/* 1959 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDouble(int columnIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 1978 */     if (!this.onInsertRow) {
/* 1979 */       if (!this.doingUpdates) {
/* 1980 */         this.doingUpdates = true;
/* 1981 */         syncUpdate();
/*      */       }
/*      */       
/* 1984 */       this.updater.setDouble(columnIndex, x);
/*      */     } else {
/* 1986 */       this.inserter.setDouble(columnIndex, x);
/*      */       
/* 1988 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDouble(String columnName, double x)
/*      */     throws SQLException
/*      */   {
/* 2008 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateFloat(int columnIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 2027 */     if (!this.onInsertRow) {
/* 2028 */       if (!this.doingUpdates) {
/* 2029 */         this.doingUpdates = true;
/* 2030 */         syncUpdate();
/*      */       }
/*      */       
/* 2033 */       this.updater.setFloat(columnIndex, x);
/*      */     } else {
/* 2035 */       this.inserter.setFloat(columnIndex, x);
/*      */       
/* 2037 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateFloat(String columnName, float x)
/*      */     throws SQLException
/*      */   {
/* 2057 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateInt(int columnIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 2076 */     if (!this.onInsertRow) {
/* 2077 */       if (!this.doingUpdates) {
/* 2078 */         this.doingUpdates = true;
/* 2079 */         syncUpdate();
/*      */       }
/*      */       
/* 2082 */       this.updater.setInt(columnIndex, x);
/*      */     } else {
/* 2084 */       this.inserter.setInt(columnIndex, x);
/*      */       
/* 2086 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateInt(String columnName, int x)
/*      */     throws SQLException
/*      */   {
/* 2106 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateLong(int columnIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 2125 */     if (!this.onInsertRow) {
/* 2126 */       if (!this.doingUpdates) {
/* 2127 */         this.doingUpdates = true;
/* 2128 */         syncUpdate();
/*      */       }
/*      */       
/* 2131 */       this.updater.setLong(columnIndex, x);
/*      */     } else {
/* 2133 */       this.inserter.setLong(columnIndex, x);
/*      */       
/* 2135 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateLong(String columnName, long x)
/*      */     throws SQLException
/*      */   {
/* 2155 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateNull(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2172 */     if (!this.onInsertRow) {
/* 2173 */       if (!this.doingUpdates) {
/* 2174 */         this.doingUpdates = true;
/* 2175 */         syncUpdate();
/*      */       }
/*      */       
/* 2178 */       this.updater.setNull(columnIndex, 0);
/*      */     } else {
/* 2180 */       this.inserter.setNull(columnIndex, 0);
/*      */       
/* 2182 */       this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateNull(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2200 */     updateNull(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(int columnIndex, Object x)
/*      */     throws SQLException
/*      */   {
/* 2219 */     if (!this.onInsertRow) {
/* 2220 */       if (!this.doingUpdates) {
/* 2221 */         this.doingUpdates = true;
/* 2222 */         syncUpdate();
/*      */       }
/*      */       
/* 2225 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2227 */       this.inserter.setObject(columnIndex, x);
/*      */       
/* 2229 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(int columnIndex, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 2253 */     if (!this.onInsertRow) {
/* 2254 */       if (!this.doingUpdates) {
/* 2255 */         this.doingUpdates = true;
/* 2256 */         syncUpdate();
/*      */       }
/*      */       
/* 2259 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2261 */       this.inserter.setObject(columnIndex, x);
/*      */       
/* 2263 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(String columnName, Object x)
/*      */     throws SQLException
/*      */   {
/* 2283 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(String columnName, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 2306 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateRow()
/*      */     throws SQLException
/*      */   {
/* 2320 */     if (!this.isUpdatable) {
/* 2321 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/* 2324 */     if (this.doingUpdates) {
/* 2325 */       this.updater.executeUpdate();
/* 2326 */       refreshRow();
/* 2327 */       this.doingUpdates = false;
/* 2328 */     } else if (this.onInsertRow) {
/* 2329 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.44"), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2335 */     syncUpdate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateShort(int columnIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 2354 */     if (!this.onInsertRow) {
/* 2355 */       if (!this.doingUpdates) {
/* 2356 */         this.doingUpdates = true;
/* 2357 */         syncUpdate();
/*      */       }
/*      */       
/* 2360 */       this.updater.setShort(columnIndex, x);
/*      */     } else {
/* 2362 */       this.inserter.setShort(columnIndex, x);
/*      */       
/* 2364 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateShort(String columnName, short x)
/*      */     throws SQLException
/*      */   {
/* 2384 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateString(int columnIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 2403 */     checkClosed();
/*      */     
/* 2405 */     if (!this.onInsertRow) {
/* 2406 */       if (!this.doingUpdates) {
/* 2407 */         this.doingUpdates = true;
/* 2408 */         syncUpdate();
/*      */       }
/*      */       
/* 2411 */       this.updater.setString(columnIndex, x);
/*      */     } else {
/* 2413 */       this.inserter.setString(columnIndex, x);
/*      */       
/* 2415 */       if (x == null) {
/* 2416 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       }
/* 2418 */       else if (getCharConverter() != null) {
/* 2419 */         this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 2424 */         this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateString(String columnName, String x)
/*      */     throws SQLException
/*      */   {
/* 2446 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTime(int columnIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 2465 */     if (!this.onInsertRow) {
/* 2466 */       if (!this.doingUpdates) {
/* 2467 */         this.doingUpdates = true;
/* 2468 */         syncUpdate();
/*      */       }
/*      */       
/* 2471 */       this.updater.setTime(columnIndex, x);
/*      */     } else {
/* 2473 */       this.inserter.setTime(columnIndex, x);
/*      */       
/* 2475 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTime(String columnName, Time x)
/*      */     throws SQLException
/*      */   {
/* 2495 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTimestamp(int columnIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2514 */     if (!this.onInsertRow) {
/* 2515 */       if (!this.doingUpdates) {
/* 2516 */         this.doingUpdates = true;
/* 2517 */         syncUpdate();
/*      */       }
/*      */       
/* 2520 */       this.updater.setTimestamp(columnIndex, x);
/*      */     } else {
/* 2522 */       this.inserter.setTimestamp(columnIndex, x);
/*      */       
/* 2524 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTimestamp(String columnName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2544 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/UpdatableResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */