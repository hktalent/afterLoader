/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.InputStream;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.Timer;
/*      */ import java.util.TimerTask;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StatementImpl
/*      */   implements Statement
/*      */ {
/*      */   protected static final String PING_MARKER = "/* ping */";
/*   62 */   protected static final String[] ON_DUPLICATE_KEY_UPDATE_CLAUSE = { "ON", "DUPLICATE", "KEY", "UPDATE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   class CancelTask
/*      */     extends TimerTask
/*      */   {
/*   71 */     long connectionId = 0L;
/*   72 */     String origHost = "";
/*   73 */     SQLException caughtWhileCancelling = null;
/*      */     StatementImpl toCancel;
/*   75 */     Properties origConnProps = null;
/*   76 */     String origConnURL = "";
/*      */     
/*      */     CancelTask(StatementImpl cancellee) throws SQLException {
/*   79 */       this.connectionId = cancellee.connectionId;
/*   80 */       this.origHost = StatementImpl.this.connection.getHost();
/*   81 */       this.toCancel = cancellee;
/*   82 */       this.origConnProps = new Properties();
/*      */       
/*   84 */       Properties props = StatementImpl.this.connection.getProperties();
/*      */       
/*   86 */       Enumeration<?> keys = props.propertyNames();
/*      */       
/*   88 */       while (keys.hasMoreElements()) {
/*   89 */         String key = keys.nextElement().toString();
/*   90 */         this.origConnProps.setProperty(key, props.getProperty(key));
/*      */       }
/*      */       
/*   93 */       this.origConnURL = StatementImpl.this.connection.getURL();
/*      */     }
/*      */     
/*      */ 
/*      */     public void run()
/*      */     {
/*   99 */       Thread cancelThread = new Thread()
/*      */       {
/*      */ 
/*      */         public void run()
/*      */         {
/*  104 */           Connection cancelConn = null;
/*  105 */           java.sql.Statement cancelStmt = null;
/*      */           try
/*      */           {
/*  108 */             if (StatementImpl.this.connection.getQueryTimeoutKillsConnection()) {
/*  109 */               StatementImpl.CancelTask.this.toCancel.wasCancelled = true;
/*  110 */               StatementImpl.CancelTask.this.toCancel.wasCancelledByTimeout = true;
/*  111 */               StatementImpl.this.connection.realClose(false, false, true, new MySQLStatementCancelledException(Messages.getString("Statement.ConnectionKilledDueToTimeout")));
/*      */             }
/*      */             else {
/*  114 */               synchronized (StatementImpl.this.cancelTimeoutMutex) {
/*  115 */                 if (StatementImpl.CancelTask.this.origConnURL.equals(StatementImpl.this.connection.getURL()))
/*      */                 {
/*  117 */                   cancelConn = StatementImpl.this.connection.duplicate();
/*  118 */                   cancelStmt = cancelConn.createStatement();
/*  119 */                   cancelStmt.execute("KILL QUERY " + StatementImpl.CancelTask.this.connectionId);
/*      */                 } else {
/*      */                   try {
/*  122 */                     cancelConn = (Connection)DriverManager.getConnection(StatementImpl.CancelTask.this.origConnURL, StatementImpl.CancelTask.this.origConnProps);
/*  123 */                     cancelStmt = cancelConn.createStatement();
/*  124 */                     cancelStmt.execute("KILL QUERY " + StatementImpl.CancelTask.this.connectionId);
/*      */                   }
/*      */                   catch (NullPointerException npe) {}
/*      */                 }
/*      */                 
/*  129 */                 StatementImpl.CancelTask.this.toCancel.wasCancelled = true;
/*  130 */                 StatementImpl.CancelTask.this.toCancel.wasCancelledByTimeout = true;
/*      */               }
/*      */             }
/*      */           } catch (SQLException sqlEx) {
/*  134 */             StatementImpl.CancelTask.this.caughtWhileCancelling = sqlEx;
/*      */ 
/*      */ 
/*      */           }
/*      */           catch (NullPointerException npe) {}finally
/*      */           {
/*      */ 
/*  141 */             if (cancelStmt != null) {
/*      */               try {
/*  143 */                 cancelStmt.close();
/*      */               } catch (SQLException sqlEx) {
/*  145 */                 throw new RuntimeException(sqlEx.toString());
/*      */               }
/*      */             }
/*      */             
/*  149 */             if (cancelConn != null) {
/*      */               try {
/*  151 */                 cancelConn.close();
/*      */               } catch (SQLException sqlEx) {
/*  153 */                 throw new RuntimeException(sqlEx.toString());
/*      */               }
/*      */             }
/*      */             
/*  157 */             StatementImpl.CancelTask.this.toCancel = null;
/*  158 */             StatementImpl.CancelTask.this.origConnProps = null;
/*  159 */             StatementImpl.CancelTask.this.origConnURL = null;
/*      */           }
/*      */           
/*      */         }
/*  163 */       };
/*  164 */       cancelThread.start();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  173 */   protected Object cancelTimeoutMutex = new Object();
/*      */   
/*      */ 
/*  176 */   static int statementCounter = 1;
/*      */   
/*      */   public static final byte USES_VARIABLES_FALSE = 0;
/*      */   
/*      */   public static final byte USES_VARIABLES_TRUE = 1;
/*      */   
/*      */   public static final byte USES_VARIABLES_UNKNOWN = -1;
/*      */   
/*  184 */   protected boolean wasCancelled = false;
/*  185 */   protected boolean wasCancelledByTimeout = false;
/*      */   
/*      */ 
/*      */   protected List<Object> batchedArgs;
/*      */   
/*      */ 
/*  191 */   protected SingleByteCharsetConverter charConverter = null;
/*      */   
/*      */ 
/*  194 */   protected String charEncoding = null;
/*      */   
/*      */ 
/*  197 */   protected volatile MySQLConnection connection = null;
/*      */   
/*  199 */   protected long connectionId = 0L;
/*      */   
/*      */ 
/*  202 */   protected String currentCatalog = null;
/*      */   
/*      */ 
/*  205 */   protected boolean doEscapeProcessing = true;
/*      */   
/*      */ 
/*  208 */   protected ProfilerEventHandler eventSink = null;
/*      */   
/*      */ 
/*  211 */   private int fetchSize = 0;
/*      */   
/*      */ 
/*  214 */   protected boolean isClosed = false;
/*      */   
/*      */ 
/*  217 */   protected long lastInsertId = -1L;
/*      */   
/*      */ 
/*  220 */   protected int maxFieldSize = MysqlIO.getMaxBuf();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  226 */   protected int maxRows = -1;
/*      */   
/*      */ 
/*  229 */   protected Set<ResultSetInternalMethods> openResults = new HashSet();
/*      */   
/*      */ 
/*  232 */   protected boolean pedantic = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String pointOfOrigin;
/*      */   
/*      */ 
/*      */ 
/*  241 */   protected boolean profileSQL = false;
/*      */   
/*      */ 
/*  244 */   protected ResultSetInternalMethods results = null;
/*      */   
/*  246 */   protected ResultSetInternalMethods generatedKeysResults = null;
/*      */   
/*      */ 
/*  249 */   protected int resultSetConcurrency = 0;
/*      */   
/*      */ 
/*  252 */   protected int resultSetType = 0;
/*      */   
/*      */ 
/*      */   protected int statementId;
/*      */   
/*      */ 
/*  258 */   protected int timeoutInMillis = 0;
/*      */   
/*      */ 
/*  261 */   protected long updateCount = -1L;
/*      */   
/*      */ 
/*  264 */   protected boolean useUsageAdvisor = false;
/*      */   
/*      */ 
/*  267 */   protected SQLWarning warningChain = null;
/*      */   
/*      */ 
/*  270 */   protected boolean clearWarningsCalled = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  276 */   protected boolean holdResultsOpenOverClose = false;
/*      */   
/*  278 */   protected ArrayList<ResultSetRow> batchedGeneratedKeys = null;
/*      */   
/*  280 */   protected boolean retrieveGeneratedKeys = false;
/*      */   
/*  282 */   protected boolean continueBatchOnError = false;
/*      */   
/*  284 */   protected PingTarget pingTarget = null;
/*      */   
/*      */ 
/*      */   protected boolean useLegacyDatetimeCode;
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   
/*  291 */   protected boolean lastQueryIsOnDupKeyUpdate = false;
/*      */   
/*      */ 
/*  294 */   protected final AtomicBoolean statementExecuting = new AtomicBoolean(false);
/*      */   
/*      */ 
/*  297 */   private boolean isImplicitlyClosingResults = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StatementImpl(MySQLConnection c, String catalog)
/*      */     throws SQLException
/*      */   {
/*  311 */     if ((c == null) || (c.isClosed())) {
/*  312 */       throw SQLError.createSQLException(Messages.getString("Statement.0"), "08003", null);
/*      */     }
/*      */     
/*  315 */     this.connection = c;
/*  316 */     this.connectionId = this.connection.getId();
/*  317 */     this.exceptionInterceptor = this.connection.getExceptionInterceptor();
/*      */     
/*  319 */     this.currentCatalog = catalog;
/*  320 */     this.pedantic = this.connection.getPedantic();
/*  321 */     this.continueBatchOnError = this.connection.getContinueBatchOnError();
/*  322 */     this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();
/*      */     
/*  324 */     if (!this.connection.getDontTrackOpenResources()) {
/*  325 */       this.connection.registerStatement(this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  332 */     if (this.connection != null) {
/*  333 */       this.maxFieldSize = this.connection.getMaxAllowedPacket();
/*      */       
/*  335 */       int defaultFetchSize = this.connection.getDefaultFetchSize();
/*      */       
/*  337 */       if (defaultFetchSize != 0) {
/*  338 */         setFetchSize(defaultFetchSize);
/*      */       }
/*      */       
/*  341 */       if (this.connection.getUseUnicode()) {
/*  342 */         this.charEncoding = this.connection.getEncoding();
/*      */         
/*  344 */         this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */       }
/*      */       
/*  347 */       boolean profiling = (this.connection.getProfileSql()) || (this.connection.getUseUsageAdvisor()) || (this.connection.getLogSlowQueries());
/*      */       
/*  349 */       if ((this.connection.getAutoGenerateTestcaseScript()) || (profiling)) {
/*  350 */         this.statementId = (statementCounter++);
/*      */       }
/*      */       
/*  353 */       if (profiling) {
/*  354 */         this.pointOfOrigin = LogUtils.findCallingClassAndMethod(new Throwable());
/*  355 */         this.profileSQL = this.connection.getProfileSql();
/*  356 */         this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  357 */         this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */       }
/*      */       
/*  360 */       int maxRowsConn = this.connection.getMaxRows();
/*      */       
/*  362 */       if (maxRowsConn != -1) {
/*  363 */         setMaxRows(maxRowsConn);
/*      */       }
/*      */       
/*  366 */       this.holdResultsOpenOverClose = this.connection.getHoldResultsOpenOverStatementClose();
/*      */     }
/*      */     
/*  369 */     this.version5013OrNewer = this.connection.versionMeetsMinimum(5, 0, 13);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch(String sql)
/*      */     throws SQLException
/*      */   {
/*  378 */     synchronized (checkClosed().getConnectionMutex()) {
/*  379 */       if (this.batchedArgs == null) {
/*  380 */         this.batchedArgs = new ArrayList();
/*      */       }
/*      */       
/*  383 */       if (sql != null) {
/*  384 */         this.batchedArgs.add(sql);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<Object> getBatchedArgs()
/*      */   {
/*  398 */     return this.batchedArgs == null ? null : Collections.unmodifiableList(this.batchedArgs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/*  407 */     if (!this.statementExecuting.get()) {
/*  408 */       return;
/*      */     }
/*      */     
/*  411 */     if ((!this.isClosed) && (this.connection != null) && (this.connection.versionMeetsMinimum(5, 0, 0))) {
/*  412 */       Connection cancelConn = null;
/*  413 */       java.sql.Statement cancelStmt = null;
/*      */       try
/*      */       {
/*  416 */         cancelConn = this.connection.duplicate();
/*  417 */         cancelStmt = cancelConn.createStatement();
/*  418 */         cancelStmt.execute("KILL QUERY " + this.connection.getIO().getThreadId());
/*  419 */         this.wasCancelled = true;
/*      */       } finally {
/*  421 */         if (cancelStmt != null) {
/*  422 */           cancelStmt.close();
/*      */         }
/*      */         
/*  425 */         if (cancelConn != null) {
/*  426 */           cancelConn.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected MySQLConnection checkClosed()
/*      */     throws SQLException
/*      */   {
/*  442 */     MySQLConnection c = this.connection;
/*      */     
/*  444 */     if (c == null) {
/*  445 */       throw SQLError.createSQLException(Messages.getString("Statement.49"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  448 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkForDml(String sql, char firstStatementChar)
/*      */     throws SQLException
/*      */   {
/*  464 */     if ((firstStatementChar == 'I') || (firstStatementChar == 'U') || (firstStatementChar == 'D') || (firstStatementChar == 'A') || (firstStatementChar == 'C') || (firstStatementChar == 'T') || (firstStatementChar == 'R'))
/*      */     {
/*  466 */       String noCommentSql = StringUtils.stripComments(sql, "'\"", "'\"", true, false, true, true);
/*      */       
/*  468 */       if ((StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "UPDATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DROP")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "CREATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "ALTER")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "TRUNCATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "RENAME")))
/*      */       {
/*      */ 
/*      */ 
/*  472 */         throw SQLError.createSQLException(Messages.getString("Statement.57"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkNullOrEmptyQuery(String sql)
/*      */     throws SQLException
/*      */   {
/*  487 */     if (sql == null) {
/*  488 */       throw SQLError.createSQLException(Messages.getString("Statement.59"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  491 */     if (sql.length() == 0) {
/*  492 */       throw SQLError.createSQLException(Messages.getString("Statement.61"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearBatch()
/*      */     throws SQLException
/*      */   {
/*  505 */     synchronized (checkClosed().getConnectionMutex()) {
/*  506 */       if (this.batchedArgs != null) {
/*  507 */         this.batchedArgs.clear();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  520 */     synchronized (checkClosed().getConnectionMutex()) {
/*  521 */       this.clearWarningsCalled = true;
/*  522 */       this.warningChain = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  541 */     realClose(true, true);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void closeAllOpenResults()
/*      */     throws SQLException
/*      */   {
/*  548 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/*  550 */     if (locallyScopedConn == null) {
/*  551 */       return;
/*      */     }
/*      */     
/*  554 */     synchronized (locallyScopedConn.getConnectionMutex()) {
/*  555 */       if (this.openResults != null) {
/*  556 */         for (ResultSetInternalMethods element : this.openResults) {
/*      */           try {
/*  558 */             element.realClose(false);
/*      */           } catch (SQLException sqlEx) {
/*  560 */             AssertionFailedException.shouldNotHappen(sqlEx);
/*      */           }
/*      */         }
/*      */         
/*  564 */         this.openResults.clear();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void implicitlyCloseAllOpenResults()
/*      */     throws SQLException
/*      */   {
/*  573 */     this.isImplicitlyClosingResults = true;
/*      */     try {
/*  575 */       if ((!this.connection.getHoldResultsOpenOverStatementClose()) && (!this.connection.getDontTrackOpenResources()) && (!this.holdResultsOpenOverClose)) {
/*  576 */         if (this.results != null) {
/*  577 */           this.results.realClose(false);
/*      */         }
/*  579 */         if (this.generatedKeysResults != null) {
/*  580 */           this.generatedKeysResults.realClose(false);
/*      */         }
/*  582 */         closeAllOpenResults();
/*      */       }
/*      */     } finally {
/*  585 */       this.isImplicitlyClosingResults = false;
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeOpenResultSet(ResultSetInternalMethods rs) {
/*      */     try {
/*  591 */       synchronized (checkClosed().getConnectionMutex()) {
/*  592 */         if (this.openResults != null) {
/*  593 */           this.openResults.remove(rs);
/*      */         }
/*      */         
/*  596 */         boolean hasMoreResults = rs.getNextResultSet() != null;
/*      */         
/*      */ 
/*  599 */         if ((this.results == rs) && (!hasMoreResults)) {
/*  600 */           this.results = null;
/*      */         }
/*  602 */         if (this.generatedKeysResults == rs) {
/*  603 */           this.generatedKeysResults = null;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  609 */         if ((!this.isImplicitlyClosingResults) && (!hasMoreResults)) {
/*  610 */           checkAndPerformCloseOnCompletionAction();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {}
/*      */   }
/*      */   
/*      */   public int getOpenResultSetCount()
/*      */   {
/*      */     try {
/*  620 */       synchronized (checkClosed().getConnectionMutex()) {
/*  621 */         if (this.openResults != null) {
/*  622 */           return this.openResults.size();
/*      */         }
/*      */         
/*  625 */         return 0;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  630 */       return 0;
/*      */     }
/*      */     catch (SQLException e) {}
/*      */   }
/*      */   
/*      */ 
/*      */   private void checkAndPerformCloseOnCompletionAction()
/*      */   {
/*      */     try
/*      */     {
/*  640 */       synchronized (checkClosed().getConnectionMutex()) {
/*  641 */         if ((isCloseOnCompletion()) && (!this.connection.getDontTrackOpenResources()) && (getOpenResultSetCount() == 0) && ((this.results == null) || (!this.results.reallyResult()) || (this.results.isClosed())) && ((this.generatedKeysResults == null) || (!this.generatedKeysResults.reallyResult()) || (this.generatedKeysResults.isClosed())))
/*      */         {
/*      */ 
/*  644 */           realClose(false, false);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {}
/*      */   }
/*      */   
/*      */ 
/*      */   private ResultSetInternalMethods createResultSetUsingServerFetch(String sql)
/*      */     throws SQLException
/*      */   {
/*  655 */     synchronized (checkClosed().getConnectionMutex()) {
/*  656 */       java.sql.PreparedStatement pStmt = this.connection.prepareStatement(sql, this.resultSetType, this.resultSetConcurrency);
/*      */       
/*  658 */       pStmt.setFetchSize(this.fetchSize);
/*      */       
/*  660 */       if (this.maxRows > -1) {
/*  661 */         pStmt.setMaxRows(this.maxRows);
/*      */       }
/*      */       
/*  664 */       statementBegins();
/*      */       
/*  666 */       pStmt.execute();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  671 */       ResultSetInternalMethods rs = ((StatementImpl)pStmt).getResultSetInternal();
/*      */       
/*  673 */       rs.setStatementUsedForFetchingRows((PreparedStatement)pStmt);
/*      */       
/*  675 */       this.results = rs;
/*      */       
/*  677 */       return rs;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean createStreamingResultSet()
/*      */   {
/*  689 */     return (this.resultSetType == 1003) && (this.resultSetConcurrency == 1007) && (this.fetchSize == Integer.MIN_VALUE);
/*      */   }
/*      */   
/*      */ 
/*  693 */   private int originalResultSetType = 0;
/*  694 */   private int originalFetchSize = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void enableStreamingResults()
/*      */     throws SQLException
/*      */   {
/*  702 */     synchronized (checkClosed().getConnectionMutex()) {
/*  703 */       this.originalResultSetType = this.resultSetType;
/*  704 */       this.originalFetchSize = this.fetchSize;
/*      */       
/*  706 */       setFetchSize(Integer.MIN_VALUE);
/*  707 */       setResultSetType(1003);
/*      */     }
/*      */   }
/*      */   
/*      */   public void disableStreamingResults() throws SQLException {
/*  712 */     synchronized (checkClosed().getConnectionMutex()) {
/*  713 */       if ((this.fetchSize == Integer.MIN_VALUE) && (this.resultSetType == 1003)) {
/*  714 */         setFetchSize(this.originalFetchSize);
/*  715 */         setResultSetType(this.originalResultSetType);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setupStreamingTimeout(MySQLConnection con)
/*      */     throws SQLException
/*      */   {
/*  728 */     if ((createStreamingResultSet()) && (con.getNetTimeoutForStreamingResults() > 0)) {
/*  729 */       executeSimpleNonQuery(con, "SET net_write_timeout=" + con.getNetTimeoutForStreamingResults());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String sql)
/*      */     throws SQLException
/*      */   {
/*  748 */     return execute(sql, false);
/*      */   }
/*      */   
/*      */   private boolean execute(String sql, boolean returnGeneratedKeys) throws SQLException {
/*  752 */     MySQLConnection locallyScopedConn = checkClosed();
/*      */     char firstNonWsChar;
/*  754 */     boolean maybeSelect; synchronized (locallyScopedConn.getConnectionMutex()) {
/*  755 */       checkClosed();
/*      */       
/*  757 */       checkNullOrEmptyQuery(sql);
/*      */       
/*  759 */       resetCancelledState();
/*      */       
/*  761 */       firstNonWsChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
/*  762 */       maybeSelect = firstNonWsChar == 'S';
/*      */       
/*  764 */       this.retrieveGeneratedKeys = returnGeneratedKeys;
/*      */       
/*  766 */       this.lastQueryIsOnDupKeyUpdate = false;
/*  767 */       if (returnGeneratedKeys) {
/*  768 */         this.lastQueryIsOnDupKeyUpdate = ((firstNonWsChar == 'I') && (containsOnDuplicateKeyInString(sql)));
/*      */       }
/*      */       
/*  771 */       if ((!maybeSelect) && (locallyScopedConn.isReadOnly())) {
/*  772 */         throw SQLError.createSQLException(Messages.getString("Statement.27") + Messages.getString("Statement.28"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  777 */       setupStreamingTimeout(locallyScopedConn);
/*      */       Object escapedSqlResult;
/*  779 */       if (this.doEscapeProcessing) {
/*  780 */         escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), locallyScopedConn);
/*      */         
/*  782 */         if ((escapedSqlResult instanceof String)) {
/*  783 */           sql = (String)escapedSqlResult;
/*      */         } else {
/*  785 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */       
/*  789 */       implicitlyCloseAllOpenResults();
/*      */       
/*  791 */       if ((sql.charAt(0) == '/') && 
/*  792 */         (sql.startsWith("/* ping */"))) {
/*  793 */         doPingInstead();
/*      */         
/*  795 */         escapedSqlResult = 1;jsr 493;return (boolean)escapedSqlResult;
/*      */       }
/*      */       
/*      */ 
/*  799 */       CachedResultSetMetaData cachedMetaData = null;
/*      */       
/*  801 */       ResultSetInternalMethods rs = null;
/*      */       
/*  803 */       this.batchedGeneratedKeys = null;
/*      */       
/*  805 */       if (useServerFetch()) {
/*  806 */         rs = createResultSetUsingServerFetch(sql);
/*      */       } else {
/*  808 */         timeoutTask = null;
/*      */         
/*  810 */         String oldCatalog = null;
/*      */         try
/*      */         {
/*  813 */           if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0))) {
/*  814 */             timeoutTask = new CancelTask(this);
/*  815 */             locallyScopedConn.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */           }
/*      */           
/*  818 */           if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/*  819 */             oldCatalog = locallyScopedConn.getCatalog();
/*  820 */             locallyScopedConn.setCatalog(this.currentCatalog);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  827 */           Field[] cachedFields = null;
/*      */           
/*  829 */           if (locallyScopedConn.getCacheResultSetMetadata()) {
/*  830 */             cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
/*      */             
/*  832 */             if (cachedMetaData != null) {
/*  833 */               cachedFields = cachedMetaData.fields;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  840 */           locallyScopedConn.setSessionMaxRows(maybeSelect ? this.maxRows : -1);
/*      */           
/*  842 */           statementBegins();
/*      */           
/*  844 */           rs = locallyScopedConn.execSQL(this, sql, this.maxRows, null, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet(), this.currentCatalog, cachedFields);
/*      */           
/*      */ 
/*  847 */           if (timeoutTask != null) {
/*  848 */             if (timeoutTask.caughtWhileCancelling != null) {
/*  849 */               throw timeoutTask.caughtWhileCancelling;
/*      */             }
/*      */             
/*  852 */             timeoutTask.cancel();
/*  853 */             timeoutTask = null;
/*      */           }
/*      */           
/*  856 */           synchronized (this.cancelTimeoutMutex) {
/*  857 */             if (this.wasCancelled) {
/*  858 */               SQLException cause = null;
/*      */               
/*  860 */               if (this.wasCancelledByTimeout) {
/*  861 */                 cause = new MySQLTimeoutException();
/*      */               } else {
/*  863 */                 cause = new MySQLStatementCancelledException();
/*      */               }
/*      */               
/*  866 */               resetCancelledState();
/*      */               
/*  868 */               throw cause;
/*      */             }
/*      */           }
/*      */         } finally {
/*  872 */           if (timeoutTask != null) {
/*  873 */             timeoutTask.cancel();
/*  874 */             locallyScopedConn.getCancelTimer().purge();
/*      */           }
/*      */           
/*  877 */           if (oldCatalog != null) {
/*  878 */             locallyScopedConn.setCatalog(oldCatalog);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  883 */       if (rs != null) {
/*  884 */         this.lastInsertId = rs.getUpdateID();
/*      */         
/*  886 */         this.results = rs;
/*      */         
/*  888 */         rs.setFirstCharOfQuery(firstNonWsChar);
/*      */         
/*  890 */         if (rs.reallyResult()) {
/*  891 */           if (cachedMetaData != null) {
/*  892 */             locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */           }
/*  894 */           else if (this.connection.getCacheResultSetMetadata()) {
/*  895 */             locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  901 */       CancelTask timeoutTask = (rs != null) && (rs.reallyResult()) ? 1 : 0;jsr 17;return timeoutTask;
/*      */     } finally {
/*  903 */       jsr 6; } localObject5 = returnAddress;this.statementExecuting.set(false);ret;
/*      */     
/*  905 */     localObject6 = finally;throw ((Throwable)localObject6);
/*      */   }
/*      */   
/*      */   protected void statementBegins() {
/*  909 */     this.clearWarningsCalled = false;
/*  910 */     this.statementExecuting.set(true);
/*      */   }
/*      */   
/*      */   protected void resetCancelledState() throws SQLException {
/*  914 */     synchronized (checkClosed().getConnectionMutex()) {
/*  915 */       if (this.cancelTimeoutMutex == null) {
/*  916 */         return;
/*      */       }
/*      */       
/*  919 */       synchronized (this.cancelTimeoutMutex) {
/*  920 */         this.wasCancelled = false;
/*  921 */         this.wasCancelledByTimeout = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean execute(String sql, int returnGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/*  931 */     if (returnGeneratedKeys == 1) {
/*  932 */       checkClosed();
/*      */       
/*  934 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/*  936 */       synchronized (locallyScopedConn.getConnectionMutex())
/*      */       {
/*      */ 
/*  939 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*  940 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  943 */           boolean bool1 = execute(sql, true);jsr 17;return bool1;
/*      */         } finally {
/*  945 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  950 */     return execute(sql);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean execute(String sql, int[] generatedKeyIndices)
/*      */     throws SQLException
/*      */   {
/*  957 */     MySQLConnection locallyScopedConn = checkClosed();
/*      */     
/*  959 */     synchronized (locallyScopedConn.getConnectionMutex()) {
/*  960 */       if ((generatedKeyIndices != null) && (generatedKeyIndices.length > 0))
/*      */       {
/*  962 */         this.retrieveGeneratedKeys = true;
/*      */         
/*      */ 
/*      */ 
/*  966 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*  967 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  970 */           boolean bool1 = execute(sql, true);jsr 17;return bool1;
/*      */         } finally {
/*  972 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */       
/*      */ 
/*  976 */       return execute(sql);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean execute(String sql, String[] generatedKeyNames)
/*      */     throws SQLException
/*      */   {
/*  984 */     MySQLConnection locallyScopedConn = checkClosed();
/*      */     
/*  986 */     synchronized (locallyScopedConn.getConnectionMutex()) {
/*  987 */       if ((generatedKeyNames != null) && (generatedKeyNames.length > 0))
/*      */       {
/*  989 */         this.retrieveGeneratedKeys = true;
/*      */         
/*      */ 
/*  992 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*  993 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  996 */           boolean bool1 = execute(sql, true);jsr 17;return bool1;
/*      */         } finally {
/*  998 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */       
/*      */ 
/* 1002 */       return execute(sql);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 1020 */     MySQLConnection locallyScopedConn = checkClosed();
/*      */     
/* 1022 */     synchronized (locallyScopedConn.getConnectionMutex()) {
/* 1023 */       if (locallyScopedConn.isReadOnly()) {
/* 1024 */         throw SQLError.createSQLException(Messages.getString("Statement.34") + Messages.getString("Statement.35"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1028 */       implicitlyCloseAllOpenResults();
/*      */       
/* 1030 */       if ((this.batchedArgs == null) || (this.batchedArgs.size() == 0)) {
/* 1031 */         return new int[0];
/*      */       }
/*      */       
/*      */ 
/* 1035 */       int individualStatementTimeout = this.timeoutInMillis;
/* 1036 */       this.timeoutInMillis = 0;
/*      */       
/* 1038 */       CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1041 */         resetCancelledState();
/*      */         
/* 1043 */         statementBegins();
/*      */         try
/*      */         {
/* 1046 */           this.retrieveGeneratedKeys = true;
/*      */           
/* 1048 */           int[] updateCounts = null;
/*      */           
/* 1050 */           if (this.batchedArgs != null) {
/* 1051 */             nbrCommands = this.batchedArgs.size();
/*      */             
/* 1053 */             this.batchedGeneratedKeys = new ArrayList(this.batchedArgs.size());
/*      */             
/* 1055 */             boolean multiQueriesEnabled = locallyScopedConn.getAllowMultiQueries();
/*      */             
/* 1057 */             if ((locallyScopedConn.versionMeetsMinimum(4, 1, 1)) && ((multiQueriesEnabled) || ((locallyScopedConn.getRewriteBatchedStatements()) && (nbrCommands > 4))))
/*      */             {
/* 1059 */               int[] arrayOfInt1 = executeBatchUsingMultiQueries(multiQueriesEnabled, nbrCommands, individualStatementTimeout);return arrayOfInt1;
/*      */             }
/*      */             
/* 1062 */             if ((locallyScopedConn.getEnableQueryTimeouts()) && (individualStatementTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0))) {
/* 1063 */               timeoutTask = new CancelTask(this);
/* 1064 */               locallyScopedConn.getCancelTimer().schedule(timeoutTask, individualStatementTimeout);
/*      */             }
/*      */             
/* 1067 */             updateCounts = new int[nbrCommands];
/*      */             
/* 1069 */             for (int i = 0; i < nbrCommands; i++) {
/* 1070 */               updateCounts[i] = -3;
/*      */             }
/*      */             
/* 1073 */             SQLException sqlEx = null;
/*      */             
/* 1075 */             int commandIndex = 0;
/*      */             
/* 1077 */             for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*      */               try {
/* 1079 */                 String sql = (String)this.batchedArgs.get(commandIndex);
/* 1080 */                 updateCounts[commandIndex] = executeUpdate(sql, true, true);
/*      */                 
/* 1082 */                 getBatchedGeneratedKeys((this.results.getFirstCharOfQuery() == 'I') && (containsOnDuplicateKeyInString(sql)) ? 1 : 0);
/*      */               } catch (SQLException ex) {
/* 1084 */                 updateCounts[commandIndex] = -3;
/*      */                 
/* 1086 */                 if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */                 {
/* 1088 */                   sqlEx = ex;
/*      */                 } else {
/* 1090 */                   int[] newUpdateCounts = new int[commandIndex];
/*      */                   
/* 1092 */                   if (hasDeadlockOrTimeoutRolledBackTx(ex)) {
/* 1093 */                     for (int i = 0; i < newUpdateCounts.length; i++) {
/* 1094 */                       newUpdateCounts[i] = -3;
/*      */                     }
/*      */                   } else {
/* 1097 */                     System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */                   }
/*      */                   
/* 1100 */                   throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 1105 */             if (sqlEx != null) {
/* 1106 */               throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */             }
/*      */           }
/*      */           
/* 1110 */           if (timeoutTask != null) {
/* 1111 */             if (timeoutTask.caughtWhileCancelling != null) {
/* 1112 */               throw timeoutTask.caughtWhileCancelling;
/*      */             }
/*      */             
/* 1115 */             timeoutTask.cancel();
/*      */             
/* 1117 */             locallyScopedConn.getCancelTimer().purge();
/* 1118 */             timeoutTask = null;
/*      */           }
/*      */           
/* 1121 */           int nbrCommands = updateCounts != null ? updateCounts : new int[0];return nbrCommands;
/*      */         } finally {
/* 1123 */           this.statementExecuting.set(false);
/*      */         }
/*      */         
/*      */ 
/* 1127 */         localObject4 = returnAddress; } finally { jsr 6; } if (timeoutTask != null) {
/* 1128 */         timeoutTask.cancel();
/*      */         
/* 1130 */         locallyScopedConn.getCancelTimer().purge();
/*      */       }
/*      */       
/* 1133 */       resetCancelledState();
/*      */       
/* 1135 */       this.timeoutInMillis = individualStatementTimeout;
/*      */       
/* 1137 */       clearBatch();ret;
/*      */     }
/*      */   }
/*      */   
/*      */   protected final boolean hasDeadlockOrTimeoutRolledBackTx(SQLException ex)
/*      */   {
/* 1143 */     int vendorCode = ex.getErrorCode();
/*      */     
/* 1145 */     switch (vendorCode) {
/*      */     case 1206: 
/*      */     case 1213: 
/* 1148 */       return true;
/*      */     case 1205: 
/* 1150 */       return !this.version5013OrNewer;
/*      */     }
/* 1152 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] executeBatchUsingMultiQueries(boolean multiQueriesEnabled, int nbrCommands, int individualStatementTimeout)
/*      */     throws SQLException
/*      */   {
/* 1166 */     MySQLConnection locallyScopedConn = checkClosed();
/*      */     
/* 1168 */     synchronized (locallyScopedConn.getConnectionMutex()) {
/* 1169 */       if (!multiQueriesEnabled) {
/* 1170 */         locallyScopedConn.getIO().enableMultiQueries();
/*      */       }
/*      */       
/* 1173 */       java.sql.Statement batchStmt = null;
/*      */       
/* 1175 */       CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1178 */         int[] updateCounts = new int[nbrCommands];
/*      */         
/* 1180 */         for (int i = 0; i < nbrCommands; i++) {
/* 1181 */           updateCounts[i] = -3;
/*      */         }
/*      */         
/* 1184 */         int commandIndex = 0;
/*      */         
/* 1186 */         StringBuilder queryBuf = new StringBuilder();
/*      */         
/* 1188 */         batchStmt = locallyScopedConn.createStatement();
/*      */         
/* 1190 */         if ((locallyScopedConn.getEnableQueryTimeouts()) && (individualStatementTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0))) {
/* 1191 */           timeoutTask = new CancelTask((StatementImpl)batchStmt);
/* 1192 */           locallyScopedConn.getCancelTimer().schedule(timeoutTask, individualStatementTimeout);
/*      */         }
/*      */         
/* 1195 */         int counter = 0;
/*      */         
/* 1197 */         int numberOfBytesPerChar = 1;
/*      */         
/* 1199 */         String connectionEncoding = locallyScopedConn.getEncoding();
/*      */         
/* 1201 */         if (StringUtils.startsWithIgnoreCase(connectionEncoding, "utf")) {
/* 1202 */           numberOfBytesPerChar = 3;
/* 1203 */         } else if (CharsetMapping.isMultibyteCharset(connectionEncoding)) {
/* 1204 */           numberOfBytesPerChar = 2;
/*      */         }
/*      */         
/* 1207 */         int escapeAdjust = 1;
/*      */         
/* 1209 */         batchStmt.setEscapeProcessing(this.doEscapeProcessing);
/*      */         
/* 1211 */         if (this.doEscapeProcessing) {
/* 1212 */           escapeAdjust = 2;
/*      */         }
/*      */         
/* 1215 */         SQLException sqlEx = null;
/*      */         
/* 1217 */         int argumentSetsInBatchSoFar = 0;
/*      */         
/* 1219 */         for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/* 1220 */           String nextQuery = (String)this.batchedArgs.get(commandIndex);
/*      */           
/* 1222 */           if (((queryBuf.length() + nextQuery.length()) * numberOfBytesPerChar + 1 + 4) * escapeAdjust + 32 > this.connection.getMaxAllowedPacket())
/*      */           {
/*      */             try {
/* 1225 */               batchStmt.execute(queryBuf.toString(), 1);
/*      */             } catch (SQLException ex) {
/* 1227 */               sqlEx = handleExceptionForBatch(commandIndex, argumentSetsInBatchSoFar, updateCounts, ex);
/*      */             }
/*      */             
/* 1230 */             counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
/*      */             
/* 1232 */             queryBuf = new StringBuilder();
/* 1233 */             argumentSetsInBatchSoFar = 0;
/*      */           }
/*      */           
/* 1236 */           queryBuf.append(nextQuery);
/* 1237 */           queryBuf.append(";");
/* 1238 */           argumentSetsInBatchSoFar++;
/*      */         }
/*      */         
/* 1241 */         if (queryBuf.length() > 0) {
/*      */           try {
/* 1243 */             batchStmt.execute(queryBuf.toString(), 1);
/*      */           } catch (SQLException ex) {
/* 1245 */             sqlEx = handleExceptionForBatch(commandIndex - 1, argumentSetsInBatchSoFar, updateCounts, ex);
/*      */           }
/*      */           
/* 1248 */           counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
/*      */         }
/*      */         
/* 1251 */         if (timeoutTask != null) {
/* 1252 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1253 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1256 */           timeoutTask.cancel();
/*      */           
/* 1258 */           locallyScopedConn.getCancelTimer().purge();
/*      */           
/* 1260 */           timeoutTask = null;
/*      */         }
/*      */         
/* 1263 */         if (sqlEx != null) {
/* 1264 */           throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */         }
/*      */         
/* 1267 */         ex = updateCounts != null ? updateCounts : new int[0];jsr 17;return ex;
/*      */       } finally {
/* 1269 */         jsr 6; } localObject2 = returnAddress; if (timeoutTask != null) {
/* 1270 */         timeoutTask.cancel();
/*      */         
/* 1272 */         locallyScopedConn.getCancelTimer().purge();
/*      */       }
/*      */       
/* 1275 */       resetCancelledState();
/*      */       try
/*      */       {
/* 1278 */         if (batchStmt != null) {
/* 1279 */           batchStmt.close();
/*      */         }
/*      */       } finally {
/* 1282 */         if (!multiQueriesEnabled)
/* 1283 */           locallyScopedConn.getIO().disableMultiQueries(); } } ret;
/*      */     
/*      */ 
/*      */ 
/* 1287 */     localObject5 = finally;throw ((Throwable)localObject5);
/*      */   }
/*      */   
/*      */   protected int processMultiCountsAndKeys(StatementImpl batchedStatement, int updateCountCounter, int[] updateCounts) throws SQLException {
/* 1291 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1292 */       updateCounts[(updateCountCounter++)] = batchedStatement.getUpdateCount();
/*      */       
/* 1294 */       boolean doGenKeys = this.batchedGeneratedKeys != null;
/*      */       
/* 1296 */       byte[][] row = (byte[][])null;
/*      */       
/* 1298 */       if (doGenKeys) {
/* 1299 */         long generatedKey = batchedStatement.getLastInsertID();
/*      */         
/* 1301 */         row = new byte[1][];
/* 1302 */         row[0] = StringUtils.getBytes(Long.toString(generatedKey));
/* 1303 */         this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */       }
/*      */       
/* 1306 */       while ((batchedStatement.getMoreResults()) || (batchedStatement.getUpdateCount() != -1)) {
/* 1307 */         updateCounts[(updateCountCounter++)] = batchedStatement.getUpdateCount();
/*      */         
/* 1309 */         if (doGenKeys) {
/* 1310 */           long generatedKey = batchedStatement.getLastInsertID();
/*      */           
/* 1312 */           row = new byte[1][];
/* 1313 */           row[0] = StringUtils.getBytes(Long.toString(generatedKey));
/* 1314 */           this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */         }
/*      */       }
/*      */       
/* 1318 */       return updateCountCounter;
/*      */     }
/*      */   }
/*      */   
/*      */   protected SQLException handleExceptionForBatch(int endOfBatchIndex, int numValuesPerBatch, int[] updateCounts, SQLException ex)
/*      */     throws BatchUpdateException
/*      */   {
/* 1325 */     for (int j = endOfBatchIndex; j > endOfBatchIndex - numValuesPerBatch; j--) {
/* 1326 */       updateCounts[j] = -3;
/*      */     }
/*      */     SQLException sqlEx;
/* 1329 */     if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */     {
/* 1331 */       sqlEx = ex;
/*      */     } else {
/* 1333 */       int[] newUpdateCounts = new int[endOfBatchIndex];
/* 1334 */       System.arraycopy(updateCounts, 0, newUpdateCounts, 0, endOfBatchIndex);
/*      */       
/* 1336 */       BatchUpdateException batchException = new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/* 1337 */       batchException.initCause(ex);
/* 1338 */       throw batchException;
/*      */     }
/*      */     SQLException sqlEx;
/* 1341 */     return sqlEx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet executeQuery(String sql)
/*      */     throws SQLException
/*      */   {
/* 1356 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1357 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1359 */       this.retrieveGeneratedKeys = false;
/*      */       
/* 1361 */       resetCancelledState();
/*      */       
/* 1363 */       checkNullOrEmptyQuery(sql);
/*      */       
/* 1365 */       setupStreamingTimeout(locallyScopedConn);
/*      */       
/* 1367 */       if (this.doEscapeProcessing) {
/* 1368 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), this.connection);
/*      */         
/* 1370 */         if ((escapedSqlResult instanceof String)) {
/* 1371 */           sql = (String)escapedSqlResult;
/*      */         } else {
/* 1373 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */       
/* 1377 */       char firstStatementChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
/*      */       
/* 1379 */       if ((sql.charAt(0) == '/') && 
/* 1380 */         (sql.startsWith("/* ping */"))) {
/* 1381 */         doPingInstead();
/*      */         
/* 1383 */         return this.results;
/*      */       }
/*      */       
/*      */ 
/* 1387 */       checkForDml(sql, firstStatementChar);
/*      */       
/* 1389 */       implicitlyCloseAllOpenResults();
/*      */       
/* 1391 */       CachedResultSetMetaData cachedMetaData = null;
/*      */       
/* 1393 */       if (useServerFetch()) {
/* 1394 */         this.results = createResultSetUsingServerFetch(sql);
/*      */         
/* 1396 */         return this.results;
/*      */       }
/*      */       
/* 1399 */       CancelTask timeoutTask = null;
/*      */       
/* 1401 */       String oldCatalog = null;
/*      */       try
/*      */       {
/* 1404 */         if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0))) {
/* 1405 */           timeoutTask = new CancelTask(this);
/* 1406 */           locallyScopedConn.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */         
/* 1409 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1410 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1411 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1418 */         Field[] cachedFields = null;
/*      */         
/* 1420 */         if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1421 */           cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
/*      */           
/* 1423 */           if (cachedMetaData != null) {
/* 1424 */             cachedFields = cachedMetaData.fields;
/*      */           }
/*      */         }
/*      */         
/* 1428 */         locallyScopedConn.setSessionMaxRows(this.maxRows);
/*      */         
/* 1430 */         statementBegins();
/*      */         
/* 1432 */         this.results = locallyScopedConn.execSQL(this, sql, this.maxRows, null, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet(), this.currentCatalog, cachedFields);
/*      */         
/*      */ 
/* 1435 */         if (timeoutTask != null) {
/* 1436 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1437 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1440 */           timeoutTask.cancel();
/*      */           
/* 1442 */           locallyScopedConn.getCancelTimer().purge();
/*      */           
/* 1444 */           timeoutTask = null;
/*      */         }
/*      */         
/* 1447 */         synchronized (this.cancelTimeoutMutex) {
/* 1448 */           if (this.wasCancelled) {
/* 1449 */             SQLException cause = null;
/*      */             
/* 1451 */             if (this.wasCancelledByTimeout) {
/* 1452 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 1454 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 1457 */             resetCancelledState();
/*      */             
/* 1459 */             throw cause;
/*      */           }
/*      */         }
/*      */       } finally {
/* 1463 */         this.statementExecuting.set(false);
/*      */         
/* 1465 */         if (timeoutTask != null) {
/* 1466 */           timeoutTask.cancel();
/*      */           
/* 1468 */           locallyScopedConn.getCancelTimer().purge();
/*      */         }
/*      */         
/* 1471 */         if (oldCatalog != null) {
/* 1472 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */       }
/*      */       
/* 1476 */       this.lastInsertId = this.results.getUpdateID();
/*      */       
/* 1478 */       if (cachedMetaData != null) {
/* 1479 */         locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */       }
/* 1481 */       else if (this.connection.getCacheResultSetMetadata()) {
/* 1482 */         locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);
/*      */       }
/*      */       
/*      */ 
/* 1486 */       return this.results;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void doPingInstead() throws SQLException {
/* 1491 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1492 */       if (this.pingTarget != null) {
/* 1493 */         this.pingTarget.doPing();
/*      */       } else {
/* 1495 */         this.connection.ping();
/*      */       }
/*      */       
/* 1498 */       ResultSetInternalMethods fakeSelectOneResultSet = generatePingResultSet();
/* 1499 */       this.results = fakeSelectOneResultSet;
/*      */     }
/*      */   }
/*      */   
/*      */   protected ResultSetInternalMethods generatePingResultSet() throws SQLException {
/* 1504 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1505 */       Field[] fields = { new Field(null, "1", -5, 1) };
/* 1506 */       ArrayList<ResultSetRow> rows = new ArrayList();
/* 1507 */       byte[] colVal = { 49 };
/*      */       
/* 1509 */       rows.add(new ByteArrayRow(new byte[][] { colVal }, getExceptionInterceptor()));
/*      */       
/* 1511 */       return (ResultSetInternalMethods)DatabaseMetaData.buildResultSet(fields, rows, this.connection);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void executeSimpleNonQuery(MySQLConnection c, String nonQuery) throws SQLException {
/* 1516 */     c.execSQL(this, nonQuery, -1, null, 1003, 1007, false, this.currentCatalog, null, false).close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String sql)
/*      */     throws SQLException
/*      */   {
/* 1535 */     return executeUpdate(sql, false, false);
/*      */   }
/*      */   
/*      */   protected int executeUpdate(String sql, boolean isBatch, boolean returnGeneratedKeys) throws SQLException
/*      */   {
/* 1540 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1541 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1543 */       checkNullOrEmptyQuery(sql);
/*      */       
/* 1545 */       resetCancelledState();
/*      */       
/* 1547 */       char firstStatementChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
/*      */       
/* 1549 */       this.retrieveGeneratedKeys = returnGeneratedKeys;
/*      */       
/* 1551 */       this.lastQueryIsOnDupKeyUpdate = false;
/* 1552 */       if (returnGeneratedKeys) {
/* 1553 */         this.lastQueryIsOnDupKeyUpdate = ((firstStatementChar == 'I') && (containsOnDuplicateKeyInString(sql)));
/*      */       }
/*      */       
/* 1556 */       ResultSetInternalMethods rs = null;
/*      */       
/* 1558 */       if (this.doEscapeProcessing) {
/* 1559 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.connection.serverSupportsConvertFn(), this.connection);
/*      */         
/* 1561 */         if ((escapedSqlResult instanceof String)) {
/* 1562 */           sql = (String)escapedSqlResult;
/*      */         } else {
/* 1564 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */       
/* 1568 */       if (locallyScopedConn.isReadOnly(false)) {
/* 1569 */         throw SQLError.createSQLException(Messages.getString("Statement.42") + Messages.getString("Statement.43"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1573 */       if (StringUtils.startsWithIgnoreCaseAndWs(sql, "select")) {
/* 1574 */         throw SQLError.createSQLException(Messages.getString("Statement.46"), "01S03", getExceptionInterceptor());
/*      */       }
/*      */       
/* 1577 */       implicitlyCloseAllOpenResults();
/*      */       
/*      */ 
/*      */ 
/* 1581 */       CancelTask timeoutTask = null;
/*      */       
/* 1583 */       String oldCatalog = null;
/*      */       try
/*      */       {
/* 1586 */         if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0))) {
/* 1587 */           timeoutTask = new CancelTask(this);
/* 1588 */           locallyScopedConn.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */         
/* 1591 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1592 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1593 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1599 */         locallyScopedConn.setSessionMaxRows(-1);
/*      */         
/* 1601 */         statementBegins();
/*      */         
/*      */ 
/* 1604 */         rs = locallyScopedConn.execSQL(this, sql, -1, null, 1003, 1007, false, this.currentCatalog, null, isBatch);
/*      */         
/*      */ 
/* 1607 */         if (timeoutTask != null) {
/* 1608 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1609 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1612 */           timeoutTask.cancel();
/*      */           
/* 1614 */           locallyScopedConn.getCancelTimer().purge();
/*      */           
/* 1616 */           timeoutTask = null;
/*      */         }
/*      */         
/* 1619 */         synchronized (this.cancelTimeoutMutex) {
/* 1620 */           if (this.wasCancelled) {
/* 1621 */             SQLException cause = null;
/*      */             
/* 1623 */             if (this.wasCancelledByTimeout) {
/* 1624 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 1626 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 1629 */             resetCancelledState();
/*      */             
/* 1631 */             throw cause;
/*      */           }
/*      */         }
/*      */       } finally {
/* 1635 */         if (timeoutTask != null) {
/* 1636 */           timeoutTask.cancel();
/*      */           
/* 1638 */           locallyScopedConn.getCancelTimer().purge();
/*      */         }
/*      */         
/* 1641 */         if (oldCatalog != null) {
/* 1642 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */         
/* 1645 */         if (!isBatch) {
/* 1646 */           this.statementExecuting.set(false);
/*      */         }
/*      */       }
/*      */       
/* 1650 */       this.results = rs;
/*      */       
/* 1652 */       rs.setFirstCharOfQuery(firstStatementChar);
/*      */       
/* 1654 */       this.updateCount = rs.getUpdateCount();
/*      */       
/* 1656 */       int truncatedUpdateCount = 0;
/*      */       
/* 1658 */       if (this.updateCount > 2147483647L) {
/* 1659 */         truncatedUpdateCount = Integer.MAX_VALUE;
/*      */       } else {
/* 1661 */         truncatedUpdateCount = (int)this.updateCount;
/*      */       }
/*      */       
/* 1664 */       this.lastInsertId = rs.getUpdateID();
/*      */       
/* 1666 */       return truncatedUpdateCount;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int executeUpdate(String sql, int returnGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/* 1674 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1675 */       if (returnGeneratedKeys == 1) {
/* 1676 */         MySQLConnection locallyScopedConn = this.connection;
/*      */         
/*      */ 
/*      */ 
/* 1680 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 1681 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1684 */           int i = executeUpdate(sql, false, true);jsr 16;return i;
/*      */         } finally {
/* 1686 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */       
/*      */ 
/* 1690 */       return executeUpdate(sql);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int executeUpdate(String sql, int[] generatedKeyIndices)
/*      */     throws SQLException
/*      */   {
/* 1698 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1699 */       if ((generatedKeyIndices != null) && (generatedKeyIndices.length > 0)) {
/* 1700 */         checkClosed();
/*      */         
/* 1702 */         MySQLConnection locallyScopedConn = this.connection;
/*      */         
/*      */ 
/*      */ 
/* 1706 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 1707 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1710 */           int i = executeUpdate(sql, false, true);jsr 16;return i;
/*      */         } finally {
/* 1712 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */       
/*      */ 
/* 1716 */       return executeUpdate(sql);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int executeUpdate(String sql, String[] generatedKeyNames)
/*      */     throws SQLException
/*      */   {
/* 1724 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1725 */       if ((generatedKeyNames != null) && (generatedKeyNames.length > 0)) {
/* 1726 */         MySQLConnection locallyScopedConn = this.connection;
/*      */         
/*      */ 
/* 1729 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/* 1730 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1733 */           int i = executeUpdate(sql, false, true);jsr 16;return i;
/*      */         } finally {
/* 1735 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */       
/*      */ 
/* 1739 */       return executeUpdate(sql);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Calendar getCalendarInstanceForSessionOrNew()
/*      */     throws SQLException
/*      */   {
/* 1748 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1749 */       if (this.connection != null) {
/* 1750 */         return this.connection.getCalendarInstanceForSessionOrNew();
/*      */       }
/*      */       
/* 1753 */       return new GregorianCalendar();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Connection getConnection()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: areturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1766	-> byte code offset #0
/*      */     //   Java source line #1767	-> byte code offset #12
/*      */     //   Java source line #1768	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 1780 */     return 1000;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 13	com/mysql/jdbc/StatementImpl:fetchSize	I
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1792	-> byte code offset #0
/*      */     //   Java source line #1793	-> byte code offset #12
/*      */     //   Java source line #1794	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   public ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/* 1801 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1802 */       if (!this.retrieveGeneratedKeys) {
/* 1803 */         throw SQLError.createSQLException(Messages.getString("Statement.GeneratedKeysNotRequested"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1807 */       if (this.batchedGeneratedKeys == null) {
/* 1808 */         if (this.lastQueryIsOnDupKeyUpdate) {
/* 1809 */           return this.generatedKeysResults = getGeneratedKeysInternal(1);
/*      */         }
/* 1811 */         return this.generatedKeysResults = getGeneratedKeysInternal();
/*      */       }
/*      */       
/* 1814 */       Field[] fields = new Field[1];
/* 1815 */       fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 1816 */       fields[0].setConnection(this.connection);
/*      */       
/* 1818 */       this.generatedKeysResults = ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(this.batchedGeneratedKeys), this.connection, this, false);
/*      */       
/*      */ 
/* 1821 */       return this.generatedKeysResults;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSetInternalMethods getGeneratedKeysInternal()
/*      */     throws SQLException
/*      */   {
/* 1831 */     int numKeys = getUpdateCount();
/* 1832 */     return getGeneratedKeysInternal(numKeys);
/*      */   }
/*      */   
/*      */   protected ResultSetInternalMethods getGeneratedKeysInternal(int numKeys) throws SQLException {
/* 1836 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1837 */       Field[] fields = new Field[1];
/* 1838 */       fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 1839 */       fields[0].setConnection(this.connection);
/* 1840 */       fields[0].setUseOldNameMetadata(true);
/*      */       
/* 1842 */       ArrayList<ResultSetRow> rowSet = new ArrayList();
/*      */       
/* 1844 */       long beginAt = getLastInsertID();
/*      */       
/* 1846 */       if (beginAt < 0L) {
/* 1847 */         fields[0].setUnsigned();
/*      */       }
/*      */       
/* 1850 */       if (this.results != null) {
/* 1851 */         String serverInfo = this.results.getServerInfo();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1856 */         if ((numKeys > 0) && (this.results.getFirstCharOfQuery() == 'R') && (serverInfo != null) && (serverInfo.length() > 0)) {
/* 1857 */           numKeys = getRecordCountFromInfo(serverInfo);
/*      */         }
/*      */         
/* 1860 */         if ((beginAt != 0L) && (numKeys > 0)) {
/* 1861 */           for (int i = 0; i < numKeys; i++) {
/* 1862 */             byte[][] row = new byte[1][];
/* 1863 */             if (beginAt > 0L) {
/* 1864 */               row[0] = StringUtils.getBytes(Long.toString(beginAt));
/*      */             } else {
/* 1866 */               byte[] asBytes = new byte[8];
/* 1867 */               asBytes[7] = ((byte)(int)(beginAt & 0xFF));
/* 1868 */               asBytes[6] = ((byte)(int)(beginAt >>> 8));
/* 1869 */               asBytes[5] = ((byte)(int)(beginAt >>> 16));
/* 1870 */               asBytes[4] = ((byte)(int)(beginAt >>> 24));
/* 1871 */               asBytes[3] = ((byte)(int)(beginAt >>> 32));
/* 1872 */               asBytes[2] = ((byte)(int)(beginAt >>> 40));
/* 1873 */               asBytes[1] = ((byte)(int)(beginAt >>> 48));
/* 1874 */               asBytes[0] = ((byte)(int)(beginAt >>> 56));
/*      */               
/* 1876 */               BigInteger val = new BigInteger(1, asBytes);
/*      */               
/* 1878 */               row[0] = val.toString().getBytes();
/*      */             }
/* 1880 */             rowSet.add(new ByteArrayRow(row, getExceptionInterceptor()));
/* 1881 */             beginAt += this.connection.getAutoIncrementIncrement();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1886 */       ResultSetImpl gkRs = ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(rowSet), this.connection, this, false);
/*      */       
/*      */ 
/* 1889 */       return gkRs;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getId()
/*      */   {
/* 1899 */     return this.statementId;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public long getLastInsertID()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 17	com/mysql/jdbc/StatementImpl:lastInsertId	J
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: lreturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     //   24: astore_1
/*      */     //   25: new 294	java/lang/RuntimeException
/*      */     //   28: dup
/*      */     //   29: aload_1
/*      */     //   30: invokespecial 295	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   33: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1915	-> byte code offset #0
/*      */     //   Java source line #1916	-> byte code offset #12
/*      */     //   Java source line #1917	-> byte code offset #19
/*      */     //   Java source line #1918	-> byte code offset #24
/*      */     //   Java source line #1919	-> byte code offset #25
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	34	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   24	6	1	e	SQLException
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */     //   0	18	24	java/sql/SQLException
/*      */     //   19	24	24	java/sql/SQLException
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public long getLongUpdateCount()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 26	com/mysql/jdbc/StatementImpl:results	Lcom/mysql/jdbc/ResultSetInternalMethods;
/*      */     //   16: ifnonnull +9 -> 25
/*      */     //   19: ldc2_w 15
/*      */     //   22: aload_1
/*      */     //   23: monitorexit
/*      */     //   24: lreturn
/*      */     //   25: aload_0
/*      */     //   26: getfield 26	com/mysql/jdbc/StatementImpl:results	Lcom/mysql/jdbc/ResultSetInternalMethods;
/*      */     //   29: invokeinterface 141 1 0
/*      */     //   34: ifeq +9 -> 43
/*      */     //   37: ldc2_w 15
/*      */     //   40: aload_1
/*      */     //   41: monitorexit
/*      */     //   42: lreturn
/*      */     //   43: aload_0
/*      */     //   44: getfield 31	com/mysql/jdbc/StatementImpl:updateCount	J
/*      */     //   47: aload_1
/*      */     //   48: monitorexit
/*      */     //   49: lreturn
/*      */     //   50: astore_2
/*      */     //   51: aload_1
/*      */     //   52: monitorexit
/*      */     //   53: aload_2
/*      */     //   54: athrow
/*      */     //   55: astore_1
/*      */     //   56: new 294	java/lang/RuntimeException
/*      */     //   59: dup
/*      */     //   60: aload_1
/*      */     //   61: invokespecial 295	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   64: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1936	-> byte code offset #0
/*      */     //   Java source line #1937	-> byte code offset #12
/*      */     //   Java source line #1938	-> byte code offset #19
/*      */     //   Java source line #1941	-> byte code offset #25
/*      */     //   Java source line #1942	-> byte code offset #37
/*      */     //   Java source line #1945	-> byte code offset #43
/*      */     //   Java source line #1946	-> byte code offset #50
/*      */     //   Java source line #1947	-> byte code offset #55
/*      */     //   Java source line #1948	-> byte code offset #56
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	65	0	this	StatementImpl
/*      */     //   55	6	1	e	SQLException
/*      */     //   50	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	24	50	finally
/*      */     //   25	42	50	finally
/*      */     //   43	49	50	finally
/*      */     //   50	53	50	finally
/*      */     //   0	24	55	java/sql/SQLException
/*      */     //   25	42	55	java/sql/SQLException
/*      */     //   43	49	55	java/sql/SQLException
/*      */     //   50	55	55	java/sql/SQLException
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getMaxFieldSize()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 19	com/mysql/jdbc/StatementImpl:maxFieldSize	I
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1964	-> byte code offset #0
/*      */     //   Java source line #1965	-> byte code offset #12
/*      */     //   Java source line #1966	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   public int getMaxRows()
/*      */     throws SQLException
/*      */   {
/* 1980 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1981 */       if (this.maxRows <= 0) {
/* 1982 */         return 0;
/*      */       }
/*      */       
/* 1985 */       return this.maxRows;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/* 1999 */     return getMoreResults(1);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getMoreResults(int current)
/*      */     throws SQLException
/*      */   {
/* 2006 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2007 */       if (this.results == null) {
/* 2008 */         return false;
/*      */       }
/*      */       
/* 2011 */       boolean streamingMode = createStreamingResultSet();
/*      */       
/* 2013 */       while ((streamingMode) && 
/* 2014 */         (this.results.reallyResult()) && 
/* 2015 */         (this.results.next())) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2021 */       ResultSetInternalMethods nextResultSet = this.results.getNextResultSet();
/*      */       
/* 2023 */       switch (current)
/*      */       {
/*      */       case 1: 
/* 2026 */         if (this.results != null) {
/* 2027 */           if ((!streamingMode) && (!this.connection.getDontTrackOpenResources())) {
/* 2028 */             this.results.realClose(false);
/*      */           }
/*      */           
/* 2031 */           this.results.clearNextResult();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 3: 
/* 2038 */         if (this.results != null) {
/* 2039 */           if ((!streamingMode) && (!this.connection.getDontTrackOpenResources())) {
/* 2040 */             this.results.realClose(false);
/*      */           }
/*      */           
/* 2043 */           this.results.clearNextResult();
/*      */         }
/*      */         
/* 2046 */         closeAllOpenResults();
/*      */         
/* 2048 */         break;
/*      */       
/*      */       case 2: 
/* 2051 */         if (!this.connection.getDontTrackOpenResources()) {
/* 2052 */           this.openResults.add(this.results);
/*      */         }
/*      */         
/* 2055 */         this.results.clearNextResult();
/*      */         
/* 2057 */         break;
/*      */       
/*      */       default: 
/* 2060 */         throw SQLError.createSQLException(Messages.getString("Statement.19"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 2063 */       this.results = nextResultSet;
/*      */       
/* 2065 */       if (this.results == null) {
/* 2066 */         this.updateCount = -1L;
/* 2067 */         this.lastInsertId = -1L;
/* 2068 */       } else if (this.results.reallyResult()) {
/* 2069 */         this.updateCount = -1L;
/* 2070 */         this.lastInsertId = -1L;
/*      */       } else {
/* 2072 */         this.updateCount = this.results.getUpdateCount();
/* 2073 */         this.lastInsertId = this.results.getUpdateID();
/*      */       }
/*      */       
/* 2076 */       boolean moreResults = (this.results != null) && (this.results.reallyResult());
/* 2077 */       if (!moreResults) {
/* 2078 */         checkAndPerformCloseOnCompletionAction();
/*      */       }
/* 2080 */       return moreResults;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 30	com/mysql/jdbc/StatementImpl:timeoutInMillis	I
/*      */     //   16: sipush 1000
/*      */     //   19: idiv
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: ireturn
/*      */     //   23: astore_2
/*      */     //   24: aload_1
/*      */     //   25: monitorexit
/*      */     //   26: aload_2
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2095	-> byte code offset #0
/*      */     //   Java source line #2096	-> byte code offset #12
/*      */     //   Java source line #2097	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	StatementImpl
/*      */     //   10	15	1	Ljava/lang/Object;	Object
/*      */     //   23	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   private int getRecordCountFromInfo(String serverInfo)
/*      */   {
/* 2106 */     StringBuilder recordsBuf = new StringBuilder();
/* 2107 */     int recordsCount = 0;
/* 2108 */     int duplicatesCount = 0;
/*      */     
/* 2110 */     char c = '\000';
/*      */     
/* 2112 */     int length = serverInfo.length();
/* 2113 */     for (int i = 0; 
/*      */         
/* 2115 */         i < length; i++) {
/* 2116 */       c = serverInfo.charAt(i);
/*      */       
/* 2118 */       if (Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 2123 */     recordsBuf.append(c);
/* 2124 */     i++;
/* 2126 */     for (; 
/* 2126 */         i < length; i++) {
/* 2127 */       c = serverInfo.charAt(i);
/*      */       
/* 2129 */       if (!Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */       
/* 2133 */       recordsBuf.append(c);
/*      */     }
/*      */     
/* 2136 */     recordsCount = Integer.parseInt(recordsBuf.toString());
/*      */     
/* 2138 */     StringBuilder duplicatesBuf = new StringBuilder();
/* 2140 */     for (; 
/* 2140 */         i < length; i++) {
/* 2141 */       c = serverInfo.charAt(i);
/*      */       
/* 2143 */       if (Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 2148 */     duplicatesBuf.append(c);
/* 2149 */     i++;
/* 2151 */     for (; 
/* 2151 */         i < length; i++) {
/* 2152 */       c = serverInfo.charAt(i);
/*      */       
/* 2154 */       if (!Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */       
/* 2158 */       duplicatesBuf.append(c);
/*      */     }
/*      */     
/* 2161 */     duplicatesCount = Integer.parseInt(duplicatesBuf.toString());
/*      */     
/* 2163 */     return recordsCount - duplicatesCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/* 2176 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2177 */       return (this.results != null) && (this.results.reallyResult()) ? this.results : null;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 28	com/mysql/jdbc/StatementImpl:resultSetConcurrency	I
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2190	-> byte code offset #0
/*      */     //   Java source line #2191	-> byte code offset #12
/*      */     //   Java source line #2192	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 2199 */     return 1;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected ResultSetInternalMethods getResultSetInternal()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 26	com/mysql/jdbc/StatementImpl:results	Lcom/mysql/jdbc/ResultSetInternalMethods;
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: areturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     //   24: astore_1
/*      */     //   25: aload_0
/*      */     //   26: getfield 26	com/mysql/jdbc/StatementImpl:results	Lcom/mysql/jdbc/ResultSetInternalMethods;
/*      */     //   29: areturn
/*      */     // Line number table:
/*      */     //   Java source line #2204	-> byte code offset #0
/*      */     //   Java source line #2205	-> byte code offset #12
/*      */     //   Java source line #2206	-> byte code offset #19
/*      */     //   Java source line #2207	-> byte code offset #24
/*      */     //   Java source line #2208	-> byte code offset #25
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   24	2	1	e	SQLException
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */     //   0	18	24	java/sql/SQLException
/*      */     //   19	24	24	java/sql/SQLException
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getResultSetType()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 29	com/mysql/jdbc/StatementImpl:resultSetType	I
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2221	-> byte code offset #0
/*      */     //   Java source line #2222	-> byte code offset #12
/*      */     //   Java source line #2223	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   public int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/* 2237 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2238 */       if (this.results == null) {
/* 2239 */         return -1;
/*      */       }
/*      */       
/* 2242 */       if (this.results.reallyResult()) {
/* 2243 */         return -1;
/*      */       }
/*      */       
/* 2246 */       int truncatedUpdateCount = 0;
/*      */       
/* 2248 */       if (this.results.getUpdateCount() > 2147483647L) {
/* 2249 */         truncatedUpdateCount = Integer.MAX_VALUE;
/*      */       } else {
/* 2251 */         truncatedUpdateCount = (int)this.results.getUpdateCount();
/*      */       }
/*      */       
/* 2254 */       return truncatedUpdateCount;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 2278 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 2280 */       if (this.clearWarningsCalled) {
/* 2281 */         return null;
/*      */       }
/*      */       
/* 2284 */       if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 2285 */         SQLWarning pendingWarningsFromServer = SQLError.convertShowWarningsToSQLWarnings(this.connection);
/*      */         
/* 2287 */         if (this.warningChain != null) {
/* 2288 */           this.warningChain.setNextWarning(pendingWarningsFromServer);
/*      */         } else {
/* 2290 */           this.warningChain = pendingWarningsFromServer;
/*      */         }
/*      */         
/* 2293 */         return this.warningChain;
/*      */       }
/*      */       
/* 2296 */       return this.warningChain;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/* 2310 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 2312 */     if (locallyScopedConn == null) {
/* 2313 */       return;
/*      */     }
/*      */     
/* 2316 */     synchronized (locallyScopedConn.getConnectionMutex())
/*      */     {
/*      */ 
/* 2319 */       if (this.isClosed) {
/* 2320 */         return;
/*      */       }
/*      */       
/* 2323 */       if ((this.useUsageAdvisor) && 
/* 2324 */         (!calledExplicitly)) {
/* 2325 */         String message = Messages.getString("Statement.63") + Messages.getString("Statement.64");
/*      */         
/* 2327 */         this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2332 */       if (closeOpenResults) {
/* 2333 */         closeOpenResults = (!this.holdResultsOpenOverClose) && (!this.connection.getDontTrackOpenResources());
/*      */       }
/*      */       
/* 2336 */       if (closeOpenResults) {
/* 2337 */         if (this.results != null) {
/*      */           try
/*      */           {
/* 2340 */             this.results.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */         }
/*      */         
/* 2345 */         if (this.generatedKeysResults != null) {
/*      */           try
/*      */           {
/* 2348 */             this.generatedKeysResults.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */         }
/*      */         
/* 2353 */         closeAllOpenResults();
/*      */       }
/*      */       
/* 2356 */       if ((this.connection != null) && 
/* 2357 */         (!this.connection.getDontTrackOpenResources())) {
/* 2358 */         this.connection.unregisterStatement(this);
/*      */       }
/*      */       
/*      */ 
/* 2362 */       this.isClosed = true;
/*      */       
/* 2364 */       this.results = null;
/* 2365 */       this.generatedKeysResults = null;
/* 2366 */       this.connection = null;
/* 2367 */       this.warningChain = null;
/* 2368 */       this.openResults = null;
/* 2369 */       this.batchedGeneratedKeys = null;
/* 2370 */       this.localInfileInputStream = null;
/* 2371 */       this.pingTarget = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursorName(String name)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEscapeProcessing(boolean enable)
/*      */     throws SQLException
/*      */   {
/* 2407 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2408 */       this.doEscapeProcessing = enable;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/* 2426 */     switch (direction)
/*      */     {
/*      */     case 1000: 
/*      */     case 1001: 
/*      */     case 1002: 
/*      */       break;
/*      */     default: 
/* 2433 */       throw SQLError.createSQLException(Messages.getString("Statement.5"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/* 2452 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2453 */       if (((rows < 0) && (rows != Integer.MIN_VALUE)) || ((this.maxRows > 0) && (rows > getMaxRows()))) {
/* 2454 */         throw SQLError.createSQLException(Messages.getString("Statement.7"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 2457 */       this.fetchSize = rows;
/*      */     }
/*      */   }
/*      */   
/*      */   public void setHoldResultsOpenOverClose(boolean holdResultsOpenOverClose) {
/*      */     try {
/* 2463 */       synchronized (checkClosed().getConnectionMutex()) {
/* 2464 */         this.holdResultsOpenOverClose = holdResultsOpenOverClose;
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxFieldSize(int max)
/*      */     throws SQLException
/*      */   {
/* 2481 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2482 */       if (max < 0) {
/* 2483 */         throw SQLError.createSQLException(Messages.getString("Statement.11"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 2486 */       int maxBuf = this.connection != null ? this.connection.getMaxAllowedPacket() : MysqlIO.getMaxBuf();
/*      */       
/* 2488 */       if (max > maxBuf) {
/* 2489 */         throw SQLError.createSQLException(Messages.getString("Statement.13", new Object[] { Long.valueOf(maxBuf) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 2493 */       this.maxFieldSize = max;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxRows(int max)
/*      */     throws SQLException
/*      */   {
/* 2509 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2510 */       if ((max > 50000000) || (max < 0)) {
/* 2511 */         throw SQLError.createSQLException(Messages.getString("Statement.15") + max + " > " + 50000000 + ".", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 2515 */       if (max == 0) {
/* 2516 */         max = -1;
/*      */       }
/*      */       
/* 2519 */       this.maxRows = max;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQueryTimeout(int seconds)
/*      */     throws SQLException
/*      */   {
/* 2534 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2535 */       if (seconds < 0) {
/* 2536 */         throw SQLError.createSQLException(Messages.getString("Statement.21"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 2539 */       this.timeoutInMillis = (seconds * 1000);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/*      */     try
/*      */     {
/* 2550 */       synchronized (checkClosed().getConnectionMutex()) {
/* 2551 */         this.resultSetConcurrency = concurrencyFlag;
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setResultSetType(int typeFlag)
/*      */   {
/*      */     try
/*      */     {
/* 2565 */       synchronized (checkClosed().getConnectionMutex()) {
/* 2566 */         this.resultSetType = typeFlag;
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {}
/*      */   }
/*      */   
/*      */   protected void getBatchedGeneratedKeys(java.sql.Statement batchedStatement) throws SQLException
/*      */   {
/* 2574 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2575 */       if (this.retrieveGeneratedKeys) {
/* 2576 */         ResultSet rs = null;
/*      */         try
/*      */         {
/* 2579 */           rs = batchedStatement.getGeneratedKeys();
/*      */           
/* 2581 */           while (rs.next()) {
/* 2582 */             this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */           }
/*      */         } finally {
/* 2585 */           if (rs != null) {
/* 2586 */             rs.close();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void getBatchedGeneratedKeys(int maxKeys) throws SQLException {
/* 2594 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2595 */       if (this.retrieveGeneratedKeys) {
/* 2596 */         ResultSet rs = null;
/*      */         try
/*      */         {
/* 2599 */           if (maxKeys == 0) {
/* 2600 */             rs = getGeneratedKeysInternal();
/*      */           } else {
/* 2602 */             rs = getGeneratedKeysInternal(maxKeys);
/*      */           }
/*      */           
/* 2605 */           while (rs.next()) {
/* 2606 */             this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */           }
/*      */         } finally {
/* 2609 */           this.isImplicitlyClosingResults = true;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2615 */         ret;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean useServerFetch()
/*      */     throws SQLException
/*      */   {
/* 2623 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2624 */       return (this.connection.isCursorFetchEnabled()) && (this.fetchSize > 0) && (this.resultSetConcurrency == 1007) && (this.resultSetType == 1003);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2639 */   private boolean isPoolable = true;
/*      */   private InputStream localInfileInputStream;
/*      */   protected final boolean version5013OrNewer;
/*      */   
/*      */   /* Error */
/*      */   public boolean isClosed()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 8	com/mysql/jdbc/StatementImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: astore_1
/*      */     //   5: aload_1
/*      */     //   6: ifnonnull +5 -> 11
/*      */     //   9: iconst_1
/*      */     //   10: ireturn
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 86 1 0
/*      */     //   17: dup
/*      */     //   18: astore_2
/*      */     //   19: monitorenter
/*      */     //   20: aload_0
/*      */     //   21: getfield 14	com/mysql/jdbc/StatementImpl:isClosed	Z
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: ireturn
/*      */     //   27: astore_3
/*      */     //   28: aload_2
/*      */     //   29: monitorexit
/*      */     //   30: aload_3
/*      */     //   31: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2630	-> byte code offset #0
/*      */     //   Java source line #2631	-> byte code offset #5
/*      */     //   Java source line #2632	-> byte code offset #9
/*      */     //   Java source line #2634	-> byte code offset #11
/*      */     //   Java source line #2635	-> byte code offset #20
/*      */     //   Java source line #2636	-> byte code offset #27
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	32	0	this	StatementImpl
/*      */     //   4	8	1	locallyScopedConn	MySQLConnection
/*      */     //   18	11	2	Ljava/lang/Object;	Object
/*      */     //   27	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   20	26	27	finally
/*      */     //   27	30	27	finally
/*      */   }
/*      */   
/*      */   public boolean isPoolable()
/*      */     throws SQLException
/*      */   {
/* 2642 */     return this.isPoolable;
/*      */   }
/*      */   
/*      */   public void setPoolable(boolean poolable) throws SQLException {
/* 2646 */     this.isPoolable = poolable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWrapperFor(Class<?> iface)
/*      */     throws SQLException
/*      */   {
/* 2667 */     checkClosed();
/*      */     
/*      */ 
/* 2670 */     return iface.isInstance(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object unwrap(Class<?> iface)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2692 */       return Util.cast(iface, this);
/*      */     } catch (ClassCastException cce) {
/* 2694 */       throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   protected static int findStartOfStatement(String sql) {
/* 2699 */     int statementStartPos = 0;
/*      */     
/* 2701 */     if (StringUtils.startsWithIgnoreCaseAndWs(sql, "/*")) {
/* 2702 */       statementStartPos = sql.indexOf("*/");
/*      */       
/* 2704 */       if (statementStartPos == -1) {
/* 2705 */         statementStartPos = 0;
/*      */       } else {
/* 2707 */         statementStartPos += 2;
/*      */       }
/* 2709 */     } else if ((StringUtils.startsWithIgnoreCaseAndWs(sql, "--")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "#"))) {
/* 2710 */       statementStartPos = sql.indexOf('\n');
/*      */       
/* 2712 */       if (statementStartPos == -1) {
/* 2713 */         statementStartPos = sql.indexOf('\r');
/*      */         
/* 2715 */         if (statementStartPos == -1) {
/* 2716 */           statementStartPos = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2721 */     return statementStartPos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getLocalInfileInputStream()
/*      */   {
/* 2729 */     return this.localInfileInputStream;
/*      */   }
/*      */   
/*      */   public void setLocalInfileInputStream(InputStream stream) {
/* 2733 */     this.localInfileInputStream = stream;
/*      */   }
/*      */   
/*      */   public void setPingTarget(PingTarget pingTarget) {
/* 2737 */     this.pingTarget = pingTarget;
/*      */   }
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/* 2741 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   protected boolean containsOnDuplicateKeyInString(String sql) {
/* 2745 */     return getOnDuplicateKeyLocation(sql, this.connection.getDontCheckOnDuplicateKeyUpdateInSQL(), this.connection.getRewriteBatchedStatements(), this.connection.isNoBackslashEscapesSet()) != -1;
/*      */   }
/*      */   
/*      */ 
/*      */   protected static int getOnDuplicateKeyLocation(String sql, boolean dontCheckOnDuplicateKeyUpdateInSQL, boolean rewriteBatchedStatements, boolean noBackslashEscapes)
/*      */   {
/* 2751 */     return (dontCheckOnDuplicateKeyUpdateInSQL) && (!rewriteBatchedStatements) ? -1 : StringUtils.indexOfIgnoreCase(0, sql, ON_DUPLICATE_KEY_UPDATE_CLAUSE, "\"'`", "\"'`", noBackslashEscapes ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */   }
/*      */   
/*      */ 
/* 2755 */   private boolean closeOnCompletion = false;
/*      */   
/*      */   public void closeOnCompletion() throws SQLException {
/* 2758 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2759 */       this.closeOnCompletion = true;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean isCloseOnCompletion()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/StatementImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 48	com/mysql/jdbc/StatementImpl:closeOnCompletion	Z
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2764	-> byte code offset #0
/*      */     //   Java source line #2765	-> byte code offset #12
/*      */     //   Java source line #2766	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	StatementImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/StatementImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */