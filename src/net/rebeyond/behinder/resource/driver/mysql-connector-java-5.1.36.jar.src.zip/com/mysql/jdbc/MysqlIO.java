/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.authentication.MysqlClearPasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.MysqlNativePasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.MysqlOldPasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.Sha256PasswordPlugin;
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.util.ReadAheadInputStream;
/*      */ import com.mysql.jdbc.util.ResultSetUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.ThreadInfo;
/*      */ import java.lang.management.ThreadMXBean;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import java.net.URL;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.zip.Deflater;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MysqlIO
/*      */ {
/*      */   private static final String CODE_PAGE_1252 = "Cp1252";
/*      */   protected static final int NULL_LENGTH = -1;
/*      */   protected static final int COMP_HEADER_LENGTH = 3;
/*      */   protected static final int MIN_COMPRESS_LEN = 50;
/*      */   protected static final int HEADER_LENGTH = 4;
/*      */   protected static final int AUTH_411_OVERHEAD = 33;
/*      */   public static final int SEED_LENGTH = 20;
/*   80 */   private static int maxBufferSize = 65535;
/*      */   
/*      */   private static final String NONE = "none";
/*      */   
/*      */   private static final int CLIENT_LONG_PASSWORD = 1;
/*      */   
/*      */   private static final int CLIENT_FOUND_ROWS = 2;
/*      */   
/*      */   private static final int CLIENT_LONG_FLAG = 4;
/*      */   
/*      */   protected static final int CLIENT_CONNECT_WITH_DB = 8;
/*      */   
/*      */   private static final int CLIENT_COMPRESS = 32;
/*      */   private static final int CLIENT_LOCAL_FILES = 128;
/*      */   private static final int CLIENT_PROTOCOL_41 = 512;
/*      */   private static final int CLIENT_INTERACTIVE = 1024;
/*      */   protected static final int CLIENT_SSL = 2048;
/*      */   private static final int CLIENT_TRANSACTIONS = 8192;
/*      */   protected static final int CLIENT_RESERVED = 16384;
/*      */   protected static final int CLIENT_SECURE_CONNECTION = 32768;
/*      */   private static final int CLIENT_MULTI_STATEMENTS = 65536;
/*      */   private static final int CLIENT_MULTI_RESULTS = 131072;
/*      */   private static final int CLIENT_PLUGIN_AUTH = 524288;
/*      */   private static final int CLIENT_CONNECT_ATTRS = 1048576;
/*      */   private static final int CLIENT_PLUGIN_AUTH_LENENC_CLIENT_DATA = 2097152;
/*      */   private static final int CLIENT_CAN_HANDLE_EXPIRED_PASSWORD = 4194304;
/*      */   private static final int SERVER_STATUS_IN_TRANS = 1;
/*      */   private static final int SERVER_STATUS_AUTOCOMMIT = 2;
/*      */   static final int SERVER_MORE_RESULTS_EXISTS = 8;
/*      */   private static final int SERVER_QUERY_NO_GOOD_INDEX_USED = 16;
/*      */   private static final int SERVER_QUERY_NO_INDEX_USED = 32;
/*      */   private static final int SERVER_QUERY_WAS_SLOW = 2048;
/*      */   private static final int SERVER_STATUS_CURSOR_EXISTS = 64;
/*      */   private static final String FALSE_SCRAMBLE = "xxxxxxxx";
/*      */   protected static final int MAX_QUERY_SIZE_TO_LOG = 1024;
/*      */   protected static final int MAX_QUERY_SIZE_TO_EXPLAIN = 1048576;
/*      */   protected static final int INITIAL_PACKET_SIZE = 1024;
/*  117 */   private static String jvmPlatformCharset = null;
/*      */   
/*      */ 
/*      */   protected static final String ZERO_DATE_VALUE_MARKER = "0000-00-00";
/*      */   
/*      */   protected static final String ZERO_DATETIME_VALUE_MARKER = "0000-00-00 00:00:00";
/*      */   
/*      */   private static final String EXPLAINABLE_STATEMENT = "SELECT";
/*      */   
/*  126 */   private static final String[] EXPLAINABLE_STATEMENT_EXTENSION = { "INSERT", "UPDATE", "REPLACE", "DELETE" };
/*      */   private static final int MAX_PACKET_DUMP_LENGTH = 1024;
/*      */   
/*  129 */   static { OutputStreamWriter outWriter = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  136 */       outWriter = new OutputStreamWriter(new ByteArrayOutputStream());
/*  137 */       jvmPlatformCharset = outWriter.getEncoding();
/*      */     } finally {
/*      */       try {
/*  140 */         if (outWriter != null) {
/*  141 */           outWriter.close();
/*      */         }
/*      */       }
/*      */       catch (IOException ioEx) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  151 */   private boolean packetSequenceReset = false;
/*      */   
/*      */ 
/*      */   protected int serverCharsetIndex;
/*      */   
/*      */ 
/*  157 */   private Buffer reusablePacket = null;
/*  158 */   private Buffer sendPacket = null;
/*  159 */   private Buffer sharedSendPacket = null;
/*      */   
/*      */ 
/*  162 */   protected BufferedOutputStream mysqlOutput = null;
/*      */   protected MySQLConnection connection;
/*  164 */   private Deflater deflater = null;
/*  165 */   protected InputStream mysqlInput = null;
/*  166 */   private LinkedList<StringBuilder> packetDebugRingBuffer = null;
/*  167 */   private RowData streamingData = null;
/*      */   
/*      */ 
/*  170 */   public Socket mysqlConnection = null;
/*  171 */   protected SocketFactory socketFactory = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private SoftReference<Buffer> loadFileBufRef;
/*      */   
/*      */ 
/*      */ 
/*      */   private SoftReference<Buffer> splitBufRef;
/*      */   
/*      */ 
/*      */ 
/*      */   private SoftReference<Buffer> compressBufRef;
/*      */   
/*      */ 
/*  186 */   protected String host = null;
/*      */   protected String seed;
/*  188 */   private String serverVersion = null;
/*  189 */   private String socketFactoryClassName = null;
/*  190 */   private byte[] packetHeaderBuf = new byte[4];
/*  191 */   private boolean colDecimalNeedsBump = false;
/*  192 */   private boolean hadWarnings = false;
/*  193 */   private boolean has41NewNewProt = false;
/*      */   
/*      */ 
/*  196 */   private boolean hasLongColumnInfo = false;
/*  197 */   private boolean isInteractiveClient = false;
/*  198 */   private boolean logSlowQueries = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  204 */   private boolean platformDbCharsetMatches = true;
/*  205 */   private boolean profileSql = false;
/*  206 */   private boolean queryBadIndexUsed = false;
/*  207 */   private boolean queryNoIndexUsed = false;
/*  208 */   private boolean serverQueryWasSlow = false;
/*      */   
/*      */ 
/*  211 */   private boolean use41Extensions = false;
/*  212 */   private boolean useCompression = false;
/*  213 */   private boolean useNewLargePackets = false;
/*  214 */   private boolean useNewUpdateCounts = false;
/*  215 */   private byte packetSequence = 0;
/*  216 */   private byte compressedPacketSequence = 0;
/*  217 */   private byte readPacketSequence = -1;
/*  218 */   private boolean checkPacketSequence = false;
/*  219 */   private byte protocolVersion = 0;
/*  220 */   private int maxAllowedPacket = 1048576;
/*  221 */   protected int maxThreeBytes = 16581375;
/*  222 */   protected int port = 3306;
/*      */   protected int serverCapabilities;
/*  224 */   private int serverMajorVersion = 0;
/*  225 */   private int serverMinorVersion = 0;
/*  226 */   private int oldServerStatus = 0;
/*  227 */   private int serverStatus = 0;
/*  228 */   private int serverSubMinorVersion = 0;
/*  229 */   private int warningCount = 0;
/*  230 */   protected long clientParam = 0L;
/*  231 */   protected long lastPacketSentTimeMs = 0L;
/*  232 */   protected long lastPacketReceivedTimeMs = 0L;
/*  233 */   private boolean traceProtocol = false;
/*  234 */   private boolean enablePacketDebug = false;
/*      */   private boolean useConnectWithDb;
/*      */   private boolean needToGrabQueryFromPacket;
/*      */   private boolean autoGenerateTestcaseScript;
/*      */   private long threadId;
/*      */   private boolean useNanosForElapsedTime;
/*      */   private long slowQueryThreshold;
/*      */   private String queryTimingUnits;
/*  242 */   private boolean useDirectRowUnpack = true;
/*      */   private int useBufferRowSizeThreshold;
/*  244 */   private int commandCount = 0;
/*      */   private List<StatementInterceptorV2> statementInterceptors;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*  247 */   private int authPluginDataLength = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MysqlIO(String host, int port, Properties props, String socketFactoryClassName, MySQLConnection conn, int socketTimeout, int useBufferRowSizeThreshold)
/*      */     throws IOException, SQLException
/*      */   {
/*  273 */     this.connection = conn;
/*      */     
/*  275 */     if (this.connection.getEnablePacketDebug()) {
/*  276 */       this.packetDebugRingBuffer = new LinkedList();
/*      */     }
/*  278 */     this.traceProtocol = this.connection.getTraceProtocol();
/*      */     
/*  280 */     this.useAutoSlowLog = this.connection.getAutoSlowLog();
/*      */     
/*  282 */     this.useBufferRowSizeThreshold = useBufferRowSizeThreshold;
/*  283 */     this.useDirectRowUnpack = this.connection.getUseDirectRowUnpack();
/*      */     
/*  285 */     this.logSlowQueries = this.connection.getLogSlowQueries();
/*      */     
/*  287 */     this.reusablePacket = new Buffer(1024);
/*  288 */     this.sendPacket = new Buffer(1024);
/*      */     
/*  290 */     this.port = port;
/*  291 */     this.host = host;
/*      */     
/*  293 */     this.socketFactoryClassName = socketFactoryClassName;
/*  294 */     this.socketFactory = createSocketFactory();
/*  295 */     this.exceptionInterceptor = this.connection.getExceptionInterceptor();
/*      */     try
/*      */     {
/*  298 */       this.mysqlConnection = this.socketFactory.connect(this.host, this.port, props);
/*      */       
/*  300 */       if (socketTimeout != 0) {
/*      */         try {
/*  302 */           this.mysqlConnection.setSoTimeout(socketTimeout);
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */       
/*      */ 
/*  308 */       this.mysqlConnection = this.socketFactory.beforeHandshake();
/*      */       
/*  310 */       if (this.connection.getUseReadAheadInput()) {
/*  311 */         this.mysqlInput = new ReadAheadInputStream(this.mysqlConnection.getInputStream(), 16384, this.connection.getTraceProtocol(), this.connection.getLog());
/*      */       }
/*  313 */       else if (this.connection.useUnbufferedInput()) {
/*  314 */         this.mysqlInput = this.mysqlConnection.getInputStream();
/*      */       } else {
/*  316 */         this.mysqlInput = new BufferedInputStream(this.mysqlConnection.getInputStream(), 16384);
/*      */       }
/*      */       
/*  319 */       this.mysqlOutput = new BufferedOutputStream(this.mysqlConnection.getOutputStream(), 16384);
/*      */       
/*  321 */       this.isInteractiveClient = this.connection.getInteractiveClient();
/*  322 */       this.profileSql = this.connection.getProfileSql();
/*  323 */       this.autoGenerateTestcaseScript = this.connection.getAutoGenerateTestcaseScript();
/*      */       
/*  325 */       this.needToGrabQueryFromPacket = ((this.profileSql) || (this.logSlowQueries) || (this.autoGenerateTestcaseScript));
/*      */       
/*  327 */       if ((this.connection.getUseNanosForElapsedTime()) && (TimeUtil.nanoTimeAvailable())) {
/*  328 */         this.useNanosForElapsedTime = true;
/*      */         
/*  330 */         this.queryTimingUnits = Messages.getString("Nanoseconds");
/*      */       } else {
/*  332 */         this.queryTimingUnits = Messages.getString("Milliseconds");
/*      */       }
/*      */       
/*  335 */       if (this.connection.getLogSlowQueries()) {
/*  336 */         calculateSlowQueryThreshold();
/*      */       }
/*      */     } catch (IOException ioEx) {
/*  339 */       throw SQLError.createCommunicationsException(this.connection, 0L, 0L, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasLongColumnInfo()
/*      */   {
/*  349 */     return this.hasLongColumnInfo;
/*      */   }
/*      */   
/*      */   protected boolean isDataAvailable() throws SQLException {
/*      */     try {
/*  354 */       return this.mysqlInput.available() > 0;
/*      */     } catch (IOException ioEx) {
/*  356 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long getLastPacketSentTimeMs()
/*      */   {
/*  365 */     return this.lastPacketSentTimeMs;
/*      */   }
/*      */   
/*      */   protected long getLastPacketReceivedTimeMs() {
/*  369 */     return this.lastPacketReceivedTimeMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSetImpl getResultSet(StatementImpl callingStatement, long columnCount, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean isBinaryEncoded, Field[] metadataFromCache)
/*      */     throws SQLException
/*      */   {
/*  405 */     Field[] fields = null;
/*      */     
/*      */ 
/*      */ 
/*  409 */     if (metadataFromCache == null) {
/*  410 */       fields = new Field[(int)columnCount];
/*      */       
/*  412 */       for (int i = 0; i < columnCount; i++) {
/*  413 */         Buffer fieldPacket = null;
/*      */         
/*  415 */         fieldPacket = readPacket();
/*  416 */         fields[i] = unpackField(fieldPacket, false);
/*      */       }
/*      */     } else {
/*  419 */       for (int i = 0; i < columnCount; i++) {
/*  420 */         skipPacket();
/*      */       }
/*      */     }
/*      */     
/*  424 */     Buffer packet = reuseAndReadPacket(this.reusablePacket);
/*      */     
/*  426 */     readServerStatusForResultSets(packet);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  432 */     if ((this.connection.versionMeetsMinimum(5, 0, 2)) && (this.connection.getUseCursorFetch()) && (isBinaryEncoded) && (callingStatement != null) && (callingStatement.getFetchSize() != 0) && (callingStatement.getResultSetType() == 1003))
/*      */     {
/*  434 */       ServerPreparedStatement prepStmt = (ServerPreparedStatement)callingStatement;
/*      */       
/*  436 */       boolean usingCursor = true;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */       if (this.connection.versionMeetsMinimum(5, 0, 5)) {
/*  444 */         usingCursor = (this.serverStatus & 0x40) != 0;
/*      */       }
/*      */       
/*  447 */       if (usingCursor) {
/*  448 */         RowData rows = new RowDataCursor(this, prepStmt, fields);
/*      */         
/*  450 */         ResultSetImpl rs = buildResultSetWithRows(callingStatement, catalog, fields, rows, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */         
/*  452 */         if (usingCursor) {
/*  453 */           rs.setFetchSize(callingStatement.getFetchSize());
/*      */         }
/*      */         
/*  456 */         return rs;
/*      */       }
/*      */     }
/*      */     
/*  460 */     RowData rowData = null;
/*      */     
/*  462 */     if (!streamResults) {
/*  463 */       rowData = readSingleRowSet(columnCount, maxRows, resultSetConcurrency, isBinaryEncoded, metadataFromCache == null ? fields : metadataFromCache);
/*      */     } else {
/*  465 */       rowData = new RowDataDynamic(this, (int)columnCount, metadataFromCache == null ? fields : metadataFromCache, isBinaryEncoded);
/*  466 */       this.streamingData = rowData;
/*      */     }
/*      */     
/*  469 */     ResultSetImpl rs = buildResultSetWithRows(callingStatement, catalog, metadataFromCache == null ? fields : metadataFromCache, rowData, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */     
/*      */ 
/*  472 */     return rs;
/*      */   }
/*      */   
/*      */ 
/*      */   protected NetworkResources getNetworkResources()
/*      */   {
/*  478 */     return new NetworkResources(this.mysqlConnection, this.mysqlInput, this.mysqlOutput);
/*      */   }
/*      */   
/*      */ 
/*      */   protected final void forceClose()
/*      */   {
/*      */     try
/*      */     {
/*  486 */       getNetworkResources().forceClose();
/*      */     } finally {
/*  488 */       this.mysqlConnection = null;
/*  489 */       this.mysqlInput = null;
/*  490 */       this.mysqlOutput = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void skipPacket()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  504 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/*  506 */       if (lengthRead < 4) {
/*  507 */         forceClose();
/*  508 */         throw new IOException(Messages.getString("MysqlIO.1"));
/*      */       }
/*      */       
/*  511 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*  513 */       if (this.traceProtocol) {
/*  514 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/*  516 */         traceMessageBuf.append(Messages.getString("MysqlIO.2"));
/*  517 */         traceMessageBuf.append(packetLength);
/*  518 */         traceMessageBuf.append(Messages.getString("MysqlIO.3"));
/*  519 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/*  521 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/*  524 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/*  526 */       if (!this.packetSequenceReset) {
/*  527 */         if ((this.enablePacketDebug) && (this.checkPacketSequence)) {
/*  528 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/*  531 */         this.packetSequenceReset = false;
/*      */       }
/*      */       
/*  534 */       this.readPacketSequence = multiPacketSeq;
/*      */       
/*  536 */       skipFully(this.mysqlInput, packetLength);
/*      */     } catch (IOException ioEx) {
/*  538 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     catch (OutOfMemoryError oom) {
/*      */       try {
/*  542 */         this.connection.realClose(false, false, true, oom);
/*      */       }
/*      */       catch (Exception ex) {}
/*  545 */       throw oom;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Buffer readPacket()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  560 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/*  562 */       if (lengthRead < 4) {
/*  563 */         forceClose();
/*  564 */         throw new IOException(Messages.getString("MysqlIO.1"));
/*      */       }
/*      */       
/*  567 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*  569 */       if (packetLength > this.maxAllowedPacket) {
/*  570 */         throw new PacketTooBigException(packetLength, this.maxAllowedPacket);
/*      */       }
/*      */       
/*  573 */       if (this.traceProtocol) {
/*  574 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/*  576 */         traceMessageBuf.append(Messages.getString("MysqlIO.2"));
/*  577 */         traceMessageBuf.append(packetLength);
/*  578 */         traceMessageBuf.append(Messages.getString("MysqlIO.3"));
/*  579 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/*  581 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/*  584 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/*  586 */       if (!this.packetSequenceReset) {
/*  587 */         if ((this.enablePacketDebug) && (this.checkPacketSequence)) {
/*  588 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/*  591 */         this.packetSequenceReset = false;
/*      */       }
/*      */       
/*  594 */       this.readPacketSequence = multiPacketSeq;
/*      */       
/*      */ 
/*  597 */       byte[] buffer = new byte[packetLength + 1];
/*  598 */       int numBytesRead = readFully(this.mysqlInput, buffer, 0, packetLength);
/*      */       
/*  600 */       if (numBytesRead != packetLength) {
/*  601 */         throw new IOException("Short read, expected " + packetLength + " bytes, only read " + numBytesRead);
/*      */       }
/*      */       
/*  604 */       buffer[packetLength] = 0;
/*      */       
/*  606 */       Buffer packet = new Buffer(buffer);
/*  607 */       packet.setBufLength(packetLength + 1);
/*      */       
/*  609 */       if (this.traceProtocol) {
/*  610 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/*  612 */         traceMessageBuf.append(Messages.getString("MysqlIO.4"));
/*  613 */         traceMessageBuf.append(getPacketDumpToLog(packet, packetLength));
/*      */         
/*  615 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/*  618 */       if (this.enablePacketDebug) {
/*  619 */         enqueuePacketForDebugging(false, false, 0, this.packetHeaderBuf, packet);
/*      */       }
/*      */       
/*  622 */       if (this.connection.getMaintainTimeStats()) {
/*  623 */         this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/*      */       }
/*      */       
/*  626 */       return packet;
/*      */     } catch (IOException ioEx) {
/*  628 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     catch (OutOfMemoryError oom) {
/*      */       try {
/*  632 */         this.connection.realClose(false, false, true, oom);
/*      */       }
/*      */       catch (Exception ex) {}
/*  635 */       throw oom;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Field unpackField(Buffer packet, boolean extractDefaultValues)
/*      */     throws SQLException
/*      */   {
/*  653 */     if (this.use41Extensions)
/*      */     {
/*      */ 
/*  656 */       if (this.has41NewNewProt)
/*      */       {
/*  658 */         int catalogNameStart = packet.getPosition() + 1;
/*  659 */         int catalogNameLength = packet.fastSkipLenString();
/*  660 */         catalogNameStart = adjustStartForFieldLength(catalogNameStart, catalogNameLength);
/*      */       }
/*      */       
/*  663 */       int databaseNameStart = packet.getPosition() + 1;
/*  664 */       int databaseNameLength = packet.fastSkipLenString();
/*  665 */       databaseNameStart = adjustStartForFieldLength(databaseNameStart, databaseNameLength);
/*      */       
/*  667 */       int tableNameStart = packet.getPosition() + 1;
/*  668 */       int tableNameLength = packet.fastSkipLenString();
/*  669 */       tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength);
/*      */       
/*      */ 
/*  672 */       int originalTableNameStart = packet.getPosition() + 1;
/*  673 */       int originalTableNameLength = packet.fastSkipLenString();
/*  674 */       originalTableNameStart = adjustStartForFieldLength(originalTableNameStart, originalTableNameLength);
/*      */       
/*      */ 
/*  677 */       int nameStart = packet.getPosition() + 1;
/*  678 */       int nameLength = packet.fastSkipLenString();
/*      */       
/*  680 */       nameStart = adjustStartForFieldLength(nameStart, nameLength);
/*      */       
/*      */ 
/*  683 */       int originalColumnNameStart = packet.getPosition() + 1;
/*  684 */       int originalColumnNameLength = packet.fastSkipLenString();
/*  685 */       originalColumnNameStart = adjustStartForFieldLength(originalColumnNameStart, originalColumnNameLength);
/*      */       
/*  687 */       packet.readByte();
/*      */       
/*  689 */       short charSetNumber = (short)packet.readInt();
/*      */       
/*  691 */       long colLength = 0L;
/*      */       
/*  693 */       if (this.has41NewNewProt) {
/*  694 */         colLength = packet.readLong();
/*      */       } else {
/*  696 */         colLength = packet.readLongInt();
/*      */       }
/*      */       
/*  699 */       int colType = packet.readByte() & 0xFF;
/*      */       
/*  701 */       short colFlag = 0;
/*      */       
/*  703 */       if (this.hasLongColumnInfo) {
/*  704 */         colFlag = (short)packet.readInt();
/*      */       } else {
/*  706 */         colFlag = (short)(packet.readByte() & 0xFF);
/*      */       }
/*      */       
/*  709 */       int colDecimals = packet.readByte() & 0xFF;
/*      */       
/*  711 */       int defaultValueStart = -1;
/*  712 */       int defaultValueLength = -1;
/*      */       
/*  714 */       if (extractDefaultValues) {
/*  715 */         defaultValueStart = packet.getPosition() + 1;
/*  716 */         defaultValueLength = packet.fastSkipLenString();
/*      */       }
/*      */       
/*  719 */       Field field = new Field(this.connection, packet.getByteBuffer(), databaseNameStart, databaseNameLength, tableNameStart, tableNameLength, originalTableNameStart, originalTableNameLength, nameStart, nameLength, originalColumnNameStart, originalColumnNameLength, colLength, colType, colFlag, colDecimals, defaultValueStart, defaultValueLength, charSetNumber);
/*      */       
/*      */ 
/*      */ 
/*  723 */       return field;
/*      */     }
/*      */     
/*  726 */     int tableNameStart = packet.getPosition() + 1;
/*  727 */     int tableNameLength = packet.fastSkipLenString();
/*  728 */     tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength);
/*      */     
/*  730 */     int nameStart = packet.getPosition() + 1;
/*  731 */     int nameLength = packet.fastSkipLenString();
/*  732 */     nameStart = adjustStartForFieldLength(nameStart, nameLength);
/*      */     
/*  734 */     int colLength = packet.readnBytes();
/*  735 */     int colType = packet.readnBytes();
/*  736 */     packet.readByte();
/*      */     
/*  738 */     short colFlag = 0;
/*      */     
/*  740 */     if (this.hasLongColumnInfo) {
/*  741 */       colFlag = (short)packet.readInt();
/*      */     } else {
/*  743 */       colFlag = (short)(packet.readByte() & 0xFF);
/*      */     }
/*      */     
/*  746 */     int colDecimals = packet.readByte() & 0xFF;
/*      */     
/*  748 */     if (this.colDecimalNeedsBump) {
/*  749 */       colDecimals++;
/*      */     }
/*      */     
/*  752 */     Field field = new Field(this.connection, packet.getByteBuffer(), nameStart, nameLength, tableNameStart, tableNameLength, colLength, colType, colFlag, colDecimals);
/*      */     
/*      */ 
/*  755 */     return field;
/*      */   }
/*      */   
/*      */   private int adjustStartForFieldLength(int nameStart, int nameLength) {
/*  759 */     if (nameLength < 251) {
/*  760 */       return nameStart;
/*      */     }
/*      */     
/*  763 */     if ((nameLength >= 251) && (nameLength < 65536)) {
/*  764 */       return nameStart + 2;
/*      */     }
/*      */     
/*  767 */     if ((nameLength >= 65536) && (nameLength < 16777216)) {
/*  768 */       return nameStart + 3;
/*      */     }
/*      */     
/*  771 */     return nameStart + 8;
/*      */   }
/*      */   
/*      */   protected boolean isSetNeededForAutoCommitMode(boolean autoCommitFlag) {
/*  775 */     if ((this.use41Extensions) && (this.connection.getElideSetAutoCommits())) {
/*  776 */       boolean autoCommitModeOnServer = (this.serverStatus & 0x2) != 0;
/*      */       
/*  778 */       if ((!autoCommitFlag) && (versionMeetsMinimum(5, 0, 0)))
/*      */       {
/*      */ 
/*      */ 
/*  782 */         boolean inTransactionOnServer = (this.serverStatus & 0x1) != 0;
/*      */         
/*  784 */         return !inTransactionOnServer;
/*      */       }
/*      */       
/*  787 */       return autoCommitModeOnServer != autoCommitFlag;
/*      */     }
/*      */     
/*  790 */     return true;
/*      */   }
/*      */   
/*      */   protected boolean inTransactionOnServer() {
/*  794 */     return (this.serverStatus & 0x1) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void changeUser(String userName, String password, String database)
/*      */     throws SQLException
/*      */   {
/*  807 */     this.packetSequence = -1;
/*  808 */     this.compressedPacketSequence = -1;
/*      */     
/*  810 */     int passwordLength = 16;
/*  811 */     int userLength = userName != null ? userName.length() : 0;
/*  812 */     int databaseLength = database != null ? database.length() : 0;
/*      */     
/*  814 */     int packLength = (userLength + passwordLength + databaseLength) * 3 + 7 + 4 + 33;
/*      */     
/*  816 */     if ((this.serverCapabilities & 0x80000) != 0)
/*      */     {
/*  818 */       proceedHandshakeWithPluggableAuthentication(userName, password, database, null);
/*      */     }
/*  820 */     else if ((this.serverCapabilities & 0x8000) != 0) {
/*  821 */       Buffer changeUserPacket = new Buffer(packLength + 1);
/*  822 */       changeUserPacket.writeByte((byte)17);
/*      */       
/*  824 */       if (versionMeetsMinimum(4, 1, 1)) {
/*  825 */         secureAuth411(changeUserPacket, packLength, userName, password, database, false);
/*      */       } else {
/*  827 */         secureAuth(changeUserPacket, packLength, userName, password, database, false);
/*      */       }
/*      */     }
/*      */     else {
/*  831 */       Buffer packet = new Buffer(packLength);
/*  832 */       packet.writeByte((byte)17);
/*      */       
/*      */ 
/*  835 */       packet.writeString(userName);
/*      */       
/*  837 */       if (this.protocolVersion > 9) {
/*  838 */         packet.writeString(Util.newCrypt(password, this.seed, this.connection.getPasswordCharacterEncoding()));
/*      */       } else {
/*  840 */         packet.writeString(Util.oldCrypt(password, this.seed));
/*      */       }
/*      */       
/*  843 */       boolean localUseConnectWithDb = (this.useConnectWithDb) && (database != null) && (database.length() > 0);
/*      */       
/*  845 */       if (localUseConnectWithDb) {
/*  846 */         packet.writeString(database);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  852 */       send(packet, packet.getPosition());
/*  853 */       checkErrorPacket();
/*      */       
/*  855 */       if (!localUseConnectWithDb) {
/*  856 */         changeDatabaseTo(database);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Buffer checkErrorPacket()
/*      */     throws SQLException
/*      */   {
/*  871 */     return checkErrorPacket(-1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void checkForCharsetMismatch()
/*      */   {
/*  878 */     if ((this.connection.getUseUnicode()) && (this.connection.getEncoding() != null)) {
/*  879 */       String encodingToCheck = jvmPlatformCharset;
/*      */       
/*  881 */       if (encodingToCheck == null) {
/*  882 */         encodingToCheck = System.getProperty("file.encoding");
/*      */       }
/*      */       
/*  885 */       if (encodingToCheck == null) {
/*  886 */         this.platformDbCharsetMatches = false;
/*      */       } else {
/*  888 */         this.platformDbCharsetMatches = encodingToCheck.equals(this.connection.getEncoding());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void clearInputStream()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       int len;
/*  899 */       while (((len = this.mysqlInput.available()) > 0) && (this.mysqlInput.skip(len) > 0L)) {}
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/*  903 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   protected void resetReadPacketSequence()
/*      */   {
/*  909 */     this.readPacketSequence = 0;
/*      */   }
/*      */   
/*      */   protected void dumpPacketRingBuffer() throws SQLException {
/*  913 */     if ((this.packetDebugRingBuffer != null) && (this.connection.getEnablePacketDebug())) {
/*  914 */       StringBuilder dumpBuffer = new StringBuilder();
/*      */       
/*  916 */       dumpBuffer.append("Last " + this.packetDebugRingBuffer.size() + " packets received from server, from oldest->newest:\n");
/*  917 */       dumpBuffer.append("\n");
/*      */       
/*  919 */       for (Iterator<StringBuilder> ringBufIter = this.packetDebugRingBuffer.iterator(); ringBufIter.hasNext();) {
/*  920 */         dumpBuffer.append((CharSequence)ringBufIter.next());
/*  921 */         dumpBuffer.append("\n");
/*      */       }
/*      */       
/*  924 */       this.connection.getLog().logTrace(dumpBuffer.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void explainSlowQuery(byte[] querySQL, String truncatedQuery)
/*      */     throws SQLException
/*      */   {
/*  937 */     if ((StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, "SELECT")) || ((versionMeetsMinimum(5, 6, 3)) && (StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, EXPLAINABLE_STATEMENT_EXTENSION) != -1)))
/*      */     {
/*      */ 
/*  940 */       PreparedStatement stmt = null;
/*  941 */       ResultSet rs = null;
/*      */       try
/*      */       {
/*  944 */         stmt = (PreparedStatement)this.connection.clientPrepareStatement("EXPLAIN ?");
/*  945 */         stmt.setBytesNoEscapeNoQuotes(1, querySQL);
/*  946 */         rs = stmt.executeQuery();
/*      */         
/*  948 */         StringBuilder explainResults = new StringBuilder(Messages.getString("MysqlIO.8") + truncatedQuery + Messages.getString("MysqlIO.9"));
/*      */         
/*  950 */         ResultSetUtil.appendResultSetSlashGStyle(explainResults, rs);
/*      */         
/*  952 */         this.connection.getLog().logWarn(explainResults.toString());
/*      */       }
/*      */       catch (SQLException sqlEx) {}finally {
/*  955 */         if (rs != null) {
/*  956 */           rs.close();
/*      */         }
/*      */         
/*  959 */         if (stmt != null) {
/*  960 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static int getMaxBuf() {
/*  967 */     return maxBufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final int getServerMajorVersion()
/*      */   {
/*  974 */     return this.serverMajorVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final int getServerMinorVersion()
/*      */   {
/*  981 */     return this.serverMinorVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final int getServerSubMinorVersion()
/*      */   {
/*  988 */     return this.serverSubMinorVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   String getServerVersion()
/*      */   {
/*  995 */     return this.serverVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doHandshake(String user, String password, String database)
/*      */     throws SQLException
/*      */   {
/* 1011 */     this.checkPacketSequence = false;
/* 1012 */     this.readPacketSequence = 0;
/*      */     
/* 1014 */     Buffer buf = readPacket();
/*      */     
/*      */ 
/* 1017 */     this.protocolVersion = buf.readByte();
/*      */     
/* 1019 */     if (this.protocolVersion == -1) {
/*      */       try {
/* 1021 */         this.mysqlConnection.close();
/*      */       }
/*      */       catch (Exception e) {}
/*      */       
/*      */ 
/* 1026 */       int errno = 2000;
/*      */       
/* 1028 */       errno = buf.readInt();
/*      */       
/* 1030 */       String serverErrorMessage = buf.readString("ASCII", getExceptionInterceptor());
/*      */       
/* 1032 */       StringBuilder errorBuf = new StringBuilder(Messages.getString("MysqlIO.10"));
/* 1033 */       errorBuf.append(serverErrorMessage);
/* 1034 */       errorBuf.append("\"");
/*      */       
/* 1036 */       String xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */       
/* 1038 */       throw SQLError.createSQLException(SQLError.get(xOpen) + ", " + errorBuf.toString(), xOpen, errno, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1041 */     this.serverVersion = buf.readString("ASCII", getExceptionInterceptor());
/*      */     
/*      */ 
/* 1044 */     int point = this.serverVersion.indexOf('.');
/*      */     
/* 1046 */     if (point != -1) {
/*      */       try {
/* 1048 */         int n = Integer.parseInt(this.serverVersion.substring(0, point));
/* 1049 */         this.serverMajorVersion = n;
/*      */       }
/*      */       catch (NumberFormatException NFE1) {}
/*      */       
/*      */ 
/* 1054 */       String remaining = this.serverVersion.substring(point + 1, this.serverVersion.length());
/* 1055 */       point = remaining.indexOf('.');
/*      */       
/* 1057 */       if (point != -1) {
/*      */         try {
/* 1059 */           int n = Integer.parseInt(remaining.substring(0, point));
/* 1060 */           this.serverMinorVersion = n;
/*      */         }
/*      */         catch (NumberFormatException nfe) {}
/*      */         
/*      */ 
/* 1065 */         remaining = remaining.substring(point + 1, remaining.length());
/*      */         
/* 1067 */         int pos = 0;
/*      */         
/* 1069 */         while ((pos < remaining.length()) && 
/* 1070 */           (remaining.charAt(pos) >= '0') && (remaining.charAt(pos) <= '9'))
/*      */         {
/*      */ 
/*      */ 
/* 1074 */           pos++;
/*      */         }
/*      */         try
/*      */         {
/* 1078 */           int n = Integer.parseInt(remaining.substring(0, pos));
/* 1079 */           this.serverSubMinorVersion = n;
/*      */         }
/*      */         catch (NumberFormatException nfe) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1086 */     if (versionMeetsMinimum(4, 0, 8)) {
/* 1087 */       this.maxThreeBytes = 16777215;
/* 1088 */       this.useNewLargePackets = true;
/*      */     } else {
/* 1090 */       this.maxThreeBytes = 16581375;
/* 1091 */       this.useNewLargePackets = false;
/*      */     }
/*      */     
/* 1094 */     this.colDecimalNeedsBump = versionMeetsMinimum(3, 23, 0);
/* 1095 */     this.colDecimalNeedsBump = (!versionMeetsMinimum(3, 23, 15));
/* 1096 */     this.useNewUpdateCounts = versionMeetsMinimum(3, 22, 5);
/*      */     
/*      */ 
/* 1099 */     this.threadId = buf.readLong();
/*      */     
/* 1101 */     if (this.protocolVersion > 9)
/*      */     {
/* 1103 */       this.seed = buf.readString("ASCII", getExceptionInterceptor(), 8);
/*      */       
/* 1105 */       buf.readByte();
/*      */     }
/*      */     else {
/* 1108 */       this.seed = buf.readString("ASCII", getExceptionInterceptor());
/*      */     }
/*      */     
/* 1111 */     this.serverCapabilities = 0;
/*      */     
/*      */ 
/* 1114 */     if (buf.getPosition() < buf.getBufLength()) {
/* 1115 */       this.serverCapabilities = buf.readInt();
/*      */     }
/*      */     
/* 1118 */     if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0)))
/*      */     {
/*      */ 
/*      */ 
/* 1122 */       this.serverCharsetIndex = (buf.readByte() & 0xFF);
/*      */       
/* 1124 */       this.serverStatus = buf.readInt();
/* 1125 */       checkTransactionState(0);
/*      */       
/*      */ 
/* 1128 */       this.serverCapabilities |= buf.readInt() << 16;
/*      */       
/* 1130 */       if ((this.serverCapabilities & 0x80000) != 0)
/*      */       {
/* 1132 */         this.authPluginDataLength = (buf.readByte() & 0xFF);
/*      */       }
/*      */       else {
/* 1135 */         buf.readByte();
/*      */       }
/*      */       
/* 1138 */       buf.setPosition(buf.getPosition() + 10);
/*      */       
/* 1140 */       if ((this.serverCapabilities & 0x8000) != 0) {
/*      */         StringBuilder newSeed;
/*      */         String seedPart2;
/*      */         StringBuilder newSeed;
/* 1144 */         if (this.authPluginDataLength > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1151 */           String seedPart2 = buf.readString("ASCII", getExceptionInterceptor(), this.authPluginDataLength - 8);
/* 1152 */           newSeed = new StringBuilder(this.authPluginDataLength);
/*      */         } else {
/* 1154 */           seedPart2 = buf.readString("ASCII", getExceptionInterceptor());
/* 1155 */           newSeed = new StringBuilder(20);
/*      */         }
/* 1157 */         newSeed.append(this.seed);
/* 1158 */         newSeed.append(seedPart2);
/* 1159 */         this.seed = newSeed.toString();
/*      */       }
/*      */     }
/*      */     
/* 1163 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression())) {
/* 1164 */       this.clientParam |= 0x20;
/*      */     }
/*      */     
/* 1167 */     this.useConnectWithDb = ((database != null) && (database.length() > 0) && (!this.connection.getCreateDatabaseIfNotExist()));
/*      */     
/* 1169 */     if (this.useConnectWithDb) {
/* 1170 */       this.clientParam |= 0x8;
/*      */     }
/*      */     
/* 1173 */     if (((this.serverCapabilities & 0x800) == 0) && (this.connection.getUseSSL())) {
/* 1174 */       if (this.connection.getRequireSSL()) {
/* 1175 */         this.connection.close();
/* 1176 */         forceClose();
/* 1177 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.15"), "08001", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1181 */       this.connection.setUseSSL(false);
/*      */     }
/*      */     
/* 1184 */     if ((this.serverCapabilities & 0x4) != 0)
/*      */     {
/* 1186 */       this.clientParam |= 0x4;
/* 1187 */       this.hasLongColumnInfo = true;
/*      */     }
/*      */     
/*      */ 
/* 1191 */     if (!this.connection.getUseAffectedRows()) {
/* 1192 */       this.clientParam |= 0x2;
/*      */     }
/*      */     
/* 1195 */     if (this.connection.getAllowLoadLocalInfile()) {
/* 1196 */       this.clientParam |= 0x80;
/*      */     }
/*      */     
/* 1199 */     if (this.isInteractiveClient) {
/* 1200 */       this.clientParam |= 0x400;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1206 */     if ((this.serverCapabilities & 0x80000) != 0) {
/* 1207 */       proceedHandshakeWithPluggableAuthentication(user, password, database, buf);
/* 1208 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1212 */     if (this.protocolVersion > 9) {
/* 1213 */       this.clientParam |= 1L;
/*      */     } else {
/* 1215 */       this.clientParam &= 0xFFFFFFFFFFFFFFFE;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1221 */     if ((versionMeetsMinimum(4, 1, 0)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x4000) != 0))) {
/* 1222 */       if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0))) {
/* 1223 */         this.clientParam |= 0x200;
/* 1224 */         this.has41NewNewProt = true;
/*      */         
/*      */ 
/* 1227 */         this.clientParam |= 0x2000;
/*      */         
/*      */ 
/* 1230 */         this.clientParam |= 0x20000;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1235 */         if (this.connection.getAllowMultiQueries()) {
/* 1236 */           this.clientParam |= 0x10000;
/*      */         }
/*      */       } else {
/* 1239 */         this.clientParam |= 0x4000;
/* 1240 */         this.has41NewNewProt = false;
/*      */       }
/*      */       
/* 1243 */       this.use41Extensions = true;
/*      */     }
/*      */     
/* 1246 */     int passwordLength = 16;
/* 1247 */     int userLength = user != null ? user.length() : 0;
/* 1248 */     int databaseLength = database != null ? database.length() : 0;
/*      */     
/* 1250 */     int packLength = (userLength + passwordLength + databaseLength) * 3 + 7 + 4 + 33;
/*      */     
/* 1252 */     Buffer packet = null;
/*      */     
/* 1254 */     if (!this.connection.getUseSSL()) {
/* 1255 */       if ((this.serverCapabilities & 0x8000) != 0) {
/* 1256 */         this.clientParam |= 0x8000;
/*      */         
/* 1258 */         if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0))) {
/* 1259 */           secureAuth411(null, packLength, user, password, database, true);
/*      */         } else {
/* 1261 */           secureAuth(null, packLength, user, password, database, true);
/*      */         }
/*      */       }
/*      */       else {
/* 1265 */         packet = new Buffer(packLength);
/*      */         
/* 1267 */         if ((this.clientParam & 0x4000) != 0L) {
/* 1268 */           if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0))) {
/* 1269 */             packet.writeLong(this.clientParam);
/* 1270 */             packet.writeLong(this.maxThreeBytes);
/*      */             
/*      */ 
/* 1273 */             packet.writeByte((byte)8);
/*      */             
/*      */ 
/* 1276 */             packet.writeBytesNoNull(new byte[23]);
/*      */           } else {
/* 1278 */             packet.writeLong(this.clientParam);
/* 1279 */             packet.writeLong(this.maxThreeBytes);
/*      */           }
/*      */         } else {
/* 1282 */           packet.writeInt((int)this.clientParam);
/* 1283 */           packet.writeLongInt(this.maxThreeBytes);
/*      */         }
/*      */         
/*      */ 
/* 1287 */         packet.writeString(user, "Cp1252", this.connection);
/*      */         
/* 1289 */         if (this.protocolVersion > 9) {
/* 1290 */           packet.writeString(Util.newCrypt(password, this.seed, this.connection.getPasswordCharacterEncoding()), "Cp1252", this.connection);
/*      */         } else {
/* 1292 */           packet.writeString(Util.oldCrypt(password, this.seed), "Cp1252", this.connection);
/*      */         }
/*      */         
/* 1295 */         if (this.useConnectWithDb) {
/* 1296 */           packet.writeString(database, "Cp1252", this.connection);
/*      */         }
/*      */         
/* 1299 */         send(packet, packet.getPosition());
/*      */       }
/*      */     } else {
/* 1302 */       negotiateSSLConnection(user, password, database, packLength);
/*      */       
/* 1304 */       if ((this.serverCapabilities & 0x8000) != 0) {
/* 1305 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 1306 */           secureAuth411(null, packLength, user, password, database, true);
/*      */         } else {
/* 1308 */           secureAuth411(null, packLength, user, password, database, true);
/*      */         }
/*      */       }
/*      */       else {
/* 1312 */         packet = new Buffer(packLength);
/*      */         
/* 1314 */         if (this.use41Extensions) {
/* 1315 */           packet.writeLong(this.clientParam);
/* 1316 */           packet.writeLong(this.maxThreeBytes);
/*      */         } else {
/* 1318 */           packet.writeInt((int)this.clientParam);
/* 1319 */           packet.writeLongInt(this.maxThreeBytes);
/*      */         }
/*      */         
/*      */ 
/* 1323 */         packet.writeString(user);
/*      */         
/* 1325 */         if (this.protocolVersion > 9) {
/* 1326 */           packet.writeString(Util.newCrypt(password, this.seed, this.connection.getPasswordCharacterEncoding()));
/*      */         } else {
/* 1328 */           packet.writeString(Util.oldCrypt(password, this.seed));
/*      */         }
/*      */         
/* 1331 */         if (((this.serverCapabilities & 0x8) != 0) && (database != null) && (database.length() > 0)) {
/* 1332 */           packet.writeString(database);
/*      */         }
/*      */         
/* 1335 */         send(packet, packet.getPosition());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1341 */     if ((!versionMeetsMinimum(4, 1, 1)) && (this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0)) {
/* 1342 */       checkErrorPacket();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1348 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression()) && (!(this.mysqlInput instanceof CompressedInputStream)))
/*      */     {
/* 1350 */       this.deflater = new Deflater();
/* 1351 */       this.useCompression = true;
/* 1352 */       this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput);
/*      */     }
/*      */     
/* 1355 */     if (!this.useConnectWithDb) {
/* 1356 */       changeDatabaseTo(database);
/*      */     }
/*      */     try
/*      */     {
/* 1360 */       this.mysqlConnection = this.socketFactory.afterHandshake();
/*      */     } catch (IOException ioEx) {
/* 1362 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1372 */   private Map<String, AuthenticationPlugin> authenticationPlugins = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1377 */   private List<String> disabledAuthenticationPlugins = null;
/*      */   
/*      */ 
/*      */ 
/* 1381 */   private String defaultAuthenticationPlugin = null;
/*      */   
/*      */ 
/*      */ 
/* 1385 */   private String defaultAuthenticationPluginProtocolName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void loadAuthenticationPlugins()
/*      */     throws SQLException
/*      */   {
/* 1406 */     this.defaultAuthenticationPlugin = this.connection.getDefaultAuthenticationPlugin();
/* 1407 */     if ((this.defaultAuthenticationPlugin == null) || ("".equals(this.defaultAuthenticationPlugin.trim()))) {
/* 1408 */       throw SQLError.createSQLException(Messages.getString("Connection.BadDefaultAuthenticationPlugin", new Object[] { this.defaultAuthenticationPlugin }), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1414 */     String disabledPlugins = this.connection.getDisabledAuthenticationPlugins();
/* 1415 */     if ((disabledPlugins != null) && (!"".equals(disabledPlugins))) {
/* 1416 */       this.disabledAuthenticationPlugins = new ArrayList();
/* 1417 */       List<String> pluginsToDisable = StringUtils.split(disabledPlugins, ",", true);
/* 1418 */       Iterator<String> iter = pluginsToDisable.iterator();
/* 1419 */       while (iter.hasNext()) {
/* 1420 */         this.disabledAuthenticationPlugins.add(iter.next());
/*      */       }
/*      */     }
/*      */     
/* 1424 */     this.authenticationPlugins = new HashMap();
/*      */     
/*      */ 
/* 1427 */     AuthenticationPlugin plugin = new MysqlOldPasswordPlugin();
/* 1428 */     plugin.init(this.connection, this.connection.getProperties());
/* 1429 */     boolean defaultIsFound = addAuthenticationPlugin(plugin);
/*      */     
/* 1431 */     plugin = new MysqlNativePasswordPlugin();
/* 1432 */     plugin.init(this.connection, this.connection.getProperties());
/* 1433 */     if (addAuthenticationPlugin(plugin)) {
/* 1434 */       defaultIsFound = true;
/*      */     }
/*      */     
/* 1437 */     plugin = new MysqlClearPasswordPlugin();
/* 1438 */     plugin.init(this.connection, this.connection.getProperties());
/* 1439 */     if (addAuthenticationPlugin(plugin)) {
/* 1440 */       defaultIsFound = true;
/*      */     }
/*      */     
/* 1443 */     plugin = new Sha256PasswordPlugin();
/* 1444 */     plugin.init(this.connection, this.connection.getProperties());
/* 1445 */     if (addAuthenticationPlugin(plugin)) {
/* 1446 */       defaultIsFound = true;
/*      */     }
/*      */     
/*      */ 
/* 1450 */     String authenticationPluginClasses = this.connection.getAuthenticationPlugins();
/* 1451 */     if ((authenticationPluginClasses != null) && (!"".equals(authenticationPluginClasses)))
/*      */     {
/* 1453 */       List<Extension> plugins = Util.loadExtensions(this.connection, this.connection.getProperties(), authenticationPluginClasses, "Connection.BadAuthenticationPlugin", getExceptionInterceptor());
/*      */       
/*      */ 
/* 1456 */       for (Extension object : plugins) {
/* 1457 */         plugin = (AuthenticationPlugin)object;
/* 1458 */         if (addAuthenticationPlugin(plugin)) {
/* 1459 */           defaultIsFound = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1465 */     if (!defaultIsFound) {
/* 1466 */       throw SQLError.createSQLException(Messages.getString("Connection.DefaultAuthenticationPluginIsNotListed", new Object[] { this.defaultAuthenticationPlugin }), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean addAuthenticationPlugin(AuthenticationPlugin plugin)
/*      */     throws SQLException
/*      */   {
/* 1484 */     boolean isDefault = false;
/* 1485 */     String pluginClassName = plugin.getClass().getName();
/* 1486 */     String pluginProtocolName = plugin.getProtocolPluginName();
/* 1487 */     boolean disabledByClassName = (this.disabledAuthenticationPlugins != null) && (this.disabledAuthenticationPlugins.contains(pluginClassName));
/* 1488 */     boolean disabledByMechanism = (this.disabledAuthenticationPlugins != null) && (this.disabledAuthenticationPlugins.contains(pluginProtocolName));
/*      */     
/* 1490 */     if ((disabledByClassName) || (disabledByMechanism))
/*      */     {
/* 1492 */       if (this.defaultAuthenticationPlugin.equals(pluginClassName)) {
/* 1493 */         throw SQLError.createSQLException(Messages.getString("Connection.BadDisabledAuthenticationPlugin", new Object[] { disabledByClassName ? pluginClassName : pluginProtocolName }), getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     else {
/* 1497 */       this.authenticationPlugins.put(pluginProtocolName, plugin);
/* 1498 */       if (this.defaultAuthenticationPlugin.equals(pluginClassName)) {
/* 1499 */         this.defaultAuthenticationPluginProtocolName = pluginProtocolName;
/* 1500 */         isDefault = true;
/*      */       }
/*      */     }
/* 1503 */     return isDefault;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AuthenticationPlugin getAuthenticationPlugin(String pluginName)
/*      */     throws SQLException
/*      */   {
/* 1524 */     AuthenticationPlugin plugin = (AuthenticationPlugin)this.authenticationPlugins.get(pluginName);
/*      */     
/* 1526 */     if ((plugin != null) && (!plugin.isReusable())) {
/*      */       try {
/* 1528 */         plugin = (AuthenticationPlugin)plugin.getClass().newInstance();
/* 1529 */         plugin.init(this.connection, this.connection.getProperties());
/*      */       } catch (Throwable t) {
/* 1531 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.BadAuthenticationPlugin", new Object[] { plugin.getClass().getName() }), getExceptionInterceptor());
/*      */         
/* 1533 */         sqlEx.initCause(t);
/* 1534 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */     
/* 1538 */     return plugin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkConfidentiality(AuthenticationPlugin plugin)
/*      */     throws SQLException
/*      */   {
/* 1548 */     if ((plugin.requiresConfidentiality()) && (!isSSLEstablished())) {
/* 1549 */       throw SQLError.createSQLException(Messages.getString("Connection.AuthenticationPluginRequiresSSL", new Object[] { plugin.getProtocolPluginName() }), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void proceedHandshakeWithPluggableAuthentication(String user, String password, String database, Buffer challenge)
/*      */     throws SQLException
/*      */   {
/* 1580 */     if (this.authenticationPlugins == null) {
/* 1581 */       loadAuthenticationPlugins();
/*      */     }
/*      */     
/* 1584 */     int passwordLength = 16;
/* 1585 */     int userLength = user != null ? user.length() : 0;
/* 1586 */     int databaseLength = database != null ? database.length() : 0;
/*      */     
/* 1588 */     int packLength = (userLength + passwordLength + databaseLength) * 3 + 7 + 4 + 33;
/*      */     
/* 1590 */     AuthenticationPlugin plugin = null;
/* 1591 */     Buffer fromServer = null;
/* 1592 */     ArrayList<Buffer> toServer = new ArrayList();
/* 1593 */     Boolean done = null;
/* 1594 */     Buffer last_sent = null;
/*      */     
/* 1596 */     boolean old_raw_challenge = false;
/*      */     
/* 1598 */     int counter = 100;
/*      */     
/* 1600 */     while (0 < counter--)
/*      */     {
/* 1602 */       if (done == null)
/*      */       {
/* 1604 */         if (challenge != null)
/*      */         {
/*      */ 
/* 1607 */           this.clientParam |= 0xAA201;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1612 */           if (this.connection.getAllowMultiQueries()) {
/* 1613 */             this.clientParam |= 0x10000;
/*      */           }
/*      */           
/* 1616 */           if (((this.serverCapabilities & 0x400000) != 0) && (!this.connection.getDisconnectOnExpiredPasswords())) {
/* 1617 */             this.clientParam |= 0x400000;
/*      */           }
/* 1619 */           if (((this.serverCapabilities & 0x100000) != 0) && (!"none".equals(this.connection.getConnectionAttributes()))) {
/* 1620 */             this.clientParam |= 0x100000;
/*      */           }
/* 1622 */           if ((this.serverCapabilities & 0x200000) != 0) {
/* 1623 */             this.clientParam |= 0x200000;
/*      */           }
/*      */           
/* 1626 */           this.has41NewNewProt = true;
/* 1627 */           this.use41Extensions = true;
/*      */           
/* 1629 */           if (this.connection.getUseSSL()) {
/* 1630 */             negotiateSSLConnection(user, password, database, packLength);
/*      */           }
/*      */           
/* 1633 */           String pluginName = null;
/*      */           
/* 1635 */           if ((this.serverCapabilities & 0x80000) != 0) {
/* 1636 */             if ((!versionMeetsMinimum(5, 5, 10)) || ((versionMeetsMinimum(5, 6, 0)) && (!versionMeetsMinimum(5, 6, 2)))) {
/* 1637 */               pluginName = challenge.readString("ASCII", getExceptionInterceptor(), this.authPluginDataLength);
/*      */             } else {
/* 1639 */               pluginName = challenge.readString("ASCII", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           
/* 1643 */           plugin = getAuthenticationPlugin(pluginName);
/*      */           
/* 1645 */           if (plugin == null) {
/* 1646 */             plugin = getAuthenticationPlugin(this.defaultAuthenticationPluginProtocolName);
/*      */           }
/*      */           
/* 1649 */           checkConfidentiality(plugin);
/* 1650 */           fromServer = new Buffer(StringUtils.getBytes(this.seed));
/*      */         }
/*      */         else {
/* 1653 */           plugin = getAuthenticationPlugin(this.defaultAuthenticationPluginProtocolName);
/* 1654 */           checkConfidentiality(plugin);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1659 */           fromServer = new Buffer(StringUtils.getBytes(this.seed));
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1665 */         challenge = checkErrorPacket();
/* 1666 */         old_raw_challenge = false;
/* 1667 */         this.packetSequence = ((byte)(this.packetSequence + 1));
/* 1668 */         this.compressedPacketSequence = ((byte)(this.compressedPacketSequence + 1));
/*      */         
/* 1670 */         if (challenge.isOKPacket())
/*      */         {
/* 1672 */           if (!done.booleanValue()) {
/* 1673 */             throw SQLError.createSQLException(Messages.getString("Connection.UnexpectedAuthenticationApproval", new Object[] { plugin.getProtocolPluginName() }), getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 1677 */           plugin.destroy();
/* 1678 */           break;
/*      */         }
/* 1680 */         if (challenge.isAuthMethodSwitchRequestPacket())
/*      */         {
/* 1682 */           String pluginName = challenge.readString("ASCII", getExceptionInterceptor());
/*      */           
/*      */ 
/* 1685 */           if ((plugin != null) && (!plugin.getProtocolPluginName().equals(pluginName))) {
/* 1686 */             plugin.destroy();
/* 1687 */             plugin = getAuthenticationPlugin(pluginName);
/*      */             
/* 1689 */             if (plugin == null) {
/* 1690 */               throw SQLError.createSQLException(Messages.getString("Connection.BadAuthenticationPlugin", new Object[] { pluginName }), getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1695 */           checkConfidentiality(plugin);
/* 1696 */           fromServer = new Buffer(StringUtils.getBytes(challenge.readString("ASCII", getExceptionInterceptor())));
/*      */ 
/*      */ 
/*      */         }
/* 1700 */         else if (versionMeetsMinimum(5, 5, 16)) {
/* 1701 */           fromServer = new Buffer(challenge.getBytes(challenge.getPosition(), challenge.getBufLength() - challenge.getPosition()));
/*      */         } else {
/* 1703 */           old_raw_challenge = true;
/* 1704 */           fromServer = new Buffer(challenge.getBytes(challenge.getPosition() - 1, challenge.getBufLength() - challenge.getPosition() + 1));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1712 */         plugin.setAuthenticationParameters(user, password);
/* 1713 */         done = Boolean.valueOf(plugin.nextAuthenticationStep(fromServer, toServer));
/*      */       } catch (SQLException e) {
/* 1715 */         throw SQLError.createSQLException(e.getMessage(), e.getSQLState(), e, getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1719 */       if (toServer.size() > 0) {
/* 1720 */         if (challenge == null) {
/* 1721 */           String enc = getEncodingForHandshake();
/*      */           
/*      */ 
/* 1724 */           last_sent = new Buffer(packLength + 1);
/* 1725 */           last_sent.writeByte((byte)17);
/*      */           
/*      */ 
/* 1728 */           last_sent.writeString(user, enc, this.connection);
/*      */           
/*      */ 
/* 1731 */           if (((Buffer)toServer.get(0)).getBufLength() < 256)
/*      */           {
/* 1733 */             last_sent.writeByte((byte)((Buffer)toServer.get(0)).getBufLength());
/* 1734 */             last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength());
/*      */           } else {
/* 1736 */             last_sent.writeByte((byte)0);
/*      */           }
/*      */           
/* 1739 */           if (this.useConnectWithDb) {
/* 1740 */             last_sent.writeString(database, enc, this.connection);
/*      */           }
/*      */           else {
/* 1743 */             last_sent.writeByte((byte)0);
/*      */           }
/*      */           
/* 1746 */           appendCharsetByteForHandshake(last_sent, enc);
/*      */           
/* 1748 */           last_sent.writeByte((byte)0);
/*      */           
/*      */ 
/* 1751 */           if ((this.serverCapabilities & 0x80000) != 0) {
/* 1752 */             last_sent.writeString(plugin.getProtocolPluginName(), enc, this.connection);
/*      */           }
/*      */           
/*      */ 
/* 1756 */           if ((this.clientParam & 0x100000) != 0L) {
/* 1757 */             sendConnectionAttributes(last_sent, enc, this.connection);
/* 1758 */             last_sent.writeByte((byte)0);
/*      */           }
/*      */           
/* 1761 */           send(last_sent, last_sent.getPosition());
/*      */         }
/* 1763 */         else if (challenge.isAuthMethodSwitchRequestPacket())
/*      */         {
/* 1765 */           last_sent = new Buffer(((Buffer)toServer.get(0)).getBufLength() + 4);
/* 1766 */           last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength());
/* 1767 */           send(last_sent, last_sent.getPosition());
/*      */         }
/* 1769 */         else if ((challenge.isRawPacket()) || (old_raw_challenge))
/*      */         {
/* 1771 */           for (Buffer buffer : toServer) {
/* 1772 */             last_sent = new Buffer(buffer.getBufLength() + 4);
/* 1773 */             last_sent.writeBytesNoNull(buffer.getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength());
/* 1774 */             send(last_sent, last_sent.getPosition());
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1779 */           String enc = getEncodingForHandshake();
/*      */           
/* 1781 */           last_sent = new Buffer(packLength);
/* 1782 */           last_sent.writeLong(this.clientParam);
/* 1783 */           last_sent.writeLong(this.maxThreeBytes);
/*      */           
/* 1785 */           appendCharsetByteForHandshake(last_sent, enc);
/*      */           
/* 1787 */           last_sent.writeBytesNoNull(new byte[23]);
/*      */           
/*      */ 
/* 1790 */           last_sent.writeString(user, enc, this.connection);
/*      */           
/* 1792 */           if ((this.serverCapabilities & 0x200000) != 0)
/*      */           {
/* 1794 */             last_sent.writeLenBytes(((Buffer)toServer.get(0)).getBytes(((Buffer)toServer.get(0)).getBufLength()));
/*      */           }
/*      */           else {
/* 1797 */             last_sent.writeByte((byte)((Buffer)toServer.get(0)).getBufLength());
/* 1798 */             last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer(), 0, ((Buffer)toServer.get(0)).getBufLength());
/*      */           }
/*      */           
/* 1801 */           if (this.useConnectWithDb) {
/* 1802 */             last_sent.writeString(database, enc, this.connection);
/*      */           }
/*      */           else {
/* 1805 */             last_sent.writeByte((byte)0);
/*      */           }
/*      */           
/* 1808 */           if ((this.serverCapabilities & 0x80000) != 0) {
/* 1809 */             last_sent.writeString(plugin.getProtocolPluginName(), enc, this.connection);
/*      */           }
/*      */           
/*      */ 
/* 1813 */           if ((this.clientParam & 0x100000) != 0L) {
/* 1814 */             sendConnectionAttributes(last_sent, enc, this.connection);
/*      */           }
/*      */           
/* 1817 */           send(last_sent, last_sent.getPosition());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1824 */     if (counter == 0) {
/* 1825 */       throw SQLError.createSQLException(Messages.getString("CommunicationsException.TooManyAuthenticationPluginNegotiations"), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1831 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression()) && (!(this.mysqlInput instanceof CompressedInputStream)))
/*      */     {
/* 1833 */       this.deflater = new Deflater();
/* 1834 */       this.useCompression = true;
/* 1835 */       this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput);
/*      */     }
/*      */     
/* 1838 */     if (!this.useConnectWithDb) {
/* 1839 */       changeDatabaseTo(database);
/*      */     }
/*      */     try
/*      */     {
/* 1843 */       this.mysqlConnection = this.socketFactory.afterHandshake();
/*      */     } catch (IOException ioEx) {
/* 1845 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   private Properties getConnectionAttributesAsProperties(String atts)
/*      */     throws SQLException
/*      */   {
/* 1852 */     Properties props = new Properties();
/*      */     
/* 1854 */     if (atts != null) {
/* 1855 */       String[] pairs = atts.split(",");
/* 1856 */       for (String pair : pairs) {
/* 1857 */         int keyEnd = pair.indexOf(":");
/* 1858 */         if ((keyEnd > 0) && (keyEnd + 1 < pair.length())) {
/* 1859 */           props.setProperty(pair.substring(0, keyEnd), pair.substring(keyEnd + 1));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1867 */     props.setProperty("_client_name", "MySQL Connector Java");
/* 1868 */     props.setProperty("_client_version", "5.1.36");
/* 1869 */     props.setProperty("_runtime_vendor", NonRegisteringDriver.RUNTIME_VENDOR);
/* 1870 */     props.setProperty("_runtime_version", NonRegisteringDriver.RUNTIME_VERSION);
/* 1871 */     props.setProperty("_client_license", "GPL");
/*      */     
/* 1873 */     return props;
/*      */   }
/*      */   
/*      */   private void sendConnectionAttributes(Buffer buf, String enc, MySQLConnection conn) throws SQLException {
/* 1877 */     String atts = conn.getConnectionAttributes();
/*      */     
/* 1879 */     Buffer lb = new Buffer(100);
/*      */     Properties props;
/*      */     try {
/* 1882 */       props = getConnectionAttributesAsProperties(atts);
/*      */       
/* 1884 */       for (Object key : props.keySet()) {
/* 1885 */         lb.writeLenString((String)key, enc, conn.getServerCharset(), null, conn.parserKnowsUnicode(), conn);
/* 1886 */         lb.writeLenString(props.getProperty((String)key), enc, conn.getServerCharset(), null, conn.parserKnowsUnicode(), conn);
/*      */       }
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/*      */ 
/* 1893 */     buf.writeByte((byte)(lb.getPosition() - 4));
/* 1894 */     buf.writeBytesNoNull(lb.getByteBuffer(), 4, lb.getBufLength() - 4);
/*      */   }
/*      */   
/*      */   private void changeDatabaseTo(String database) throws SQLException
/*      */   {
/* 1899 */     if ((database == null) || (database.length() == 0)) {
/* 1900 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 1904 */       sendCommand(2, database, null, false, null, 0);
/*      */     } catch (Exception ex) {
/* 1906 */       if (this.connection.getCreateDatabaseIfNotExist()) {
/* 1907 */         sendCommand(3, "CREATE DATABASE IF NOT EXISTS " + database, null, false, null, 0);
/* 1908 */         sendCommand(2, database, null, false, null, 0);
/*      */       } else {
/* 1910 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ResultSetRow nextRow(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacketForBufferRow, Buffer existingRowPacket)
/*      */     throws SQLException
/*      */   {
/* 1932 */     if ((this.useDirectRowUnpack) && (existingRowPacket == null) && (!isBinaryEncoded) && (!useBufferRowIfPossible) && (!useBufferRowExplicit)) {
/* 1933 */       return nextRowFast(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacketForBufferRow);
/*      */     }
/*      */     
/*      */ 
/* 1937 */     Buffer rowPacket = null;
/*      */     
/* 1939 */     if (existingRowPacket == null) {
/* 1940 */       rowPacket = checkErrorPacket();
/*      */       
/* 1942 */       if ((!useBufferRowExplicit) && (useBufferRowIfPossible) && 
/* 1943 */         (rowPacket.getBufLength() > this.useBufferRowSizeThreshold)) {
/* 1944 */         useBufferRowExplicit = true;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1949 */       rowPacket = existingRowPacket;
/* 1950 */       checkErrorPacket(existingRowPacket);
/*      */     }
/*      */     
/* 1953 */     if (!isBinaryEncoded)
/*      */     {
/*      */ 
/*      */ 
/* 1957 */       rowPacket.setPosition(rowPacket.getPosition() - 1);
/*      */       
/* 1959 */       if (!rowPacket.isLastDataPacket()) {
/* 1960 */         if ((resultSetConcurrency == 1008) || ((!useBufferRowIfPossible) && (!useBufferRowExplicit)))
/*      */         {
/* 1962 */           byte[][] rowData = new byte[columnCount][];
/*      */           
/* 1964 */           for (int i = 0; i < columnCount; i++) {
/* 1965 */             rowData[i] = rowPacket.readLenByteArray(0);
/*      */           }
/*      */           
/* 1968 */           return new ByteArrayRow(rowData, getExceptionInterceptor());
/*      */         }
/*      */         
/* 1971 */         if (!canReuseRowPacketForBufferRow) {
/* 1972 */           this.reusablePacket = new Buffer(rowPacket.getBufLength());
/*      */         }
/*      */         
/* 1975 */         return new BufferRow(rowPacket, fields, false, getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1979 */       readServerStatusForResultSets(rowPacket);
/*      */       
/* 1981 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1987 */     if (!rowPacket.isLastDataPacket()) {
/* 1988 */       if ((resultSetConcurrency == 1008) || ((!useBufferRowIfPossible) && (!useBufferRowExplicit))) {
/* 1989 */         return unpackBinaryResultSetRow(fields, rowPacket, resultSetConcurrency);
/*      */       }
/*      */       
/* 1992 */       if (!canReuseRowPacketForBufferRow) {
/* 1993 */         this.reusablePacket = new Buffer(rowPacket.getBufLength());
/*      */       }
/*      */       
/* 1996 */       return new BufferRow(rowPacket, fields, true, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1999 */     rowPacket.setPosition(rowPacket.getPosition() - 1);
/* 2000 */     readServerStatusForResultSets(rowPacket);
/*      */     
/* 2002 */     return null;
/*      */   }
/*      */   
/*      */   final ResultSetRow nextRowFast(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacket) throws SQLException
/*      */   {
/*      */     try {
/* 2008 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/* 2010 */       if (lengthRead < 4) {
/* 2011 */         forceClose();
/* 2012 */         throw new RuntimeException(Messages.getString("MysqlIO.43"));
/*      */       }
/*      */       
/* 2015 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*      */ 
/* 2018 */       if (packetLength == this.maxThreeBytes) {
/* 2019 */         reuseAndReadPacket(this.reusablePacket, packetLength);
/*      */         
/*      */ 
/* 2022 */         return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacket, this.reusablePacket);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2028 */       if (packetLength > this.useBufferRowSizeThreshold) {
/* 2029 */         reuseAndReadPacket(this.reusablePacket, packetLength);
/*      */         
/*      */ 
/* 2032 */         return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, true, true, false, this.reusablePacket);
/*      */       }
/*      */       
/* 2035 */       int remaining = packetLength;
/*      */       
/* 2037 */       boolean firstTime = true;
/*      */       
/* 2039 */       byte[][] rowData = (byte[][])null;
/*      */       
/* 2041 */       for (int i = 0; i < columnCount; i++)
/*      */       {
/* 2043 */         int sw = this.mysqlInput.read() & 0xFF;
/* 2044 */         remaining--;
/*      */         
/* 2046 */         if (firstTime) {
/* 2047 */           if (sw == 255)
/*      */           {
/*      */ 
/* 2050 */             Buffer errorPacket = new Buffer(packetLength + 4);
/* 2051 */             errorPacket.setPosition(0);
/* 2052 */             errorPacket.writeByte(this.packetHeaderBuf[0]);
/* 2053 */             errorPacket.writeByte(this.packetHeaderBuf[1]);
/* 2054 */             errorPacket.writeByte(this.packetHeaderBuf[2]);
/* 2055 */             errorPacket.writeByte((byte)1);
/* 2056 */             errorPacket.writeByte((byte)sw);
/* 2057 */             readFully(this.mysqlInput, errorPacket.getByteBuffer(), 5, packetLength - 1);
/* 2058 */             errorPacket.setPosition(4);
/* 2059 */             checkErrorPacket(errorPacket);
/*      */           }
/*      */           
/* 2062 */           if ((sw == 254) && (packetLength < 9)) {
/* 2063 */             if (this.use41Extensions) {
/* 2064 */               this.warningCount = (this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8);
/* 2065 */               remaining -= 2;
/*      */               
/* 2067 */               if (this.warningCount > 0) {
/* 2068 */                 this.hadWarnings = true;
/*      */               }
/*      */               
/* 2071 */               this.oldServerStatus = this.serverStatus;
/*      */               
/* 2073 */               this.serverStatus = (this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8);
/* 2074 */               checkTransactionState(this.oldServerStatus);
/*      */               
/* 2076 */               remaining -= 2;
/*      */               
/* 2078 */               if (remaining > 0) {
/* 2079 */                 skipFully(this.mysqlInput, remaining);
/*      */               }
/*      */             }
/*      */             
/* 2083 */             return null;
/*      */           }
/*      */           
/* 2086 */           rowData = new byte[columnCount][];
/*      */           
/* 2088 */           firstTime = false;
/*      */         }
/*      */         
/* 2091 */         int len = 0;
/*      */         
/* 2093 */         switch (sw) {
/*      */         case 251: 
/* 2095 */           len = -1;
/* 2096 */           break;
/*      */         
/*      */         case 252: 
/* 2099 */           len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8;
/* 2100 */           remaining -= 2;
/* 2101 */           break;
/*      */         
/*      */         case 253: 
/* 2104 */           len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8 | (this.mysqlInput.read() & 0xFF) << 16;
/*      */           
/* 2106 */           remaining -= 3;
/* 2107 */           break;
/*      */         
/*      */         case 254: 
/* 2110 */           len = (int)(this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8 | (this.mysqlInput.read() & 0xFF) << 16 | (this.mysqlInput.read() & 0xFF) << 24 | (this.mysqlInput.read() & 0xFF) << 32 | (this.mysqlInput.read() & 0xFF) << 40 | (this.mysqlInput.read() & 0xFF) << 48 | (this.mysqlInput.read() & 0xFF) << 56);
/*      */           
/*      */ 
/*      */ 
/* 2114 */           remaining -= 8;
/* 2115 */           break;
/*      */         
/*      */         default: 
/* 2118 */           len = sw;
/*      */         }
/*      */         
/* 2121 */         if (len == -1) {
/* 2122 */           rowData[i] = null;
/* 2123 */         } else if (len == 0) {
/* 2124 */           rowData[i] = Constants.EMPTY_BYTE_ARRAY;
/*      */         } else {
/* 2126 */           rowData[i] = new byte[len];
/*      */           
/* 2128 */           int bytesRead = readFully(this.mysqlInput, rowData[i], 0, len);
/*      */           
/* 2130 */           if (bytesRead != len) {
/* 2131 */             throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException(Messages.getString("MysqlIO.43")), getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 2135 */           remaining -= bytesRead;
/*      */         }
/*      */       }
/*      */       
/* 2139 */       if (remaining > 0) {
/* 2140 */         skipFully(this.mysqlInput, remaining);
/*      */       }
/*      */       
/* 2143 */       return new ByteArrayRow(rowData, getExceptionInterceptor());
/*      */     } catch (IOException ioEx) {
/* 2145 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void quit()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 2160 */         if (!this.mysqlConnection.isClosed()) {
/*      */           try {
/* 2162 */             this.mysqlConnection.shutdownInput();
/*      */           }
/*      */           catch (UnsupportedOperationException ex) {}
/*      */         }
/*      */       }
/*      */       catch (IOException ioEx) {
/* 2168 */         this.connection.getLog().logWarn("Caught while disconnecting...", ioEx);
/*      */       }
/*      */       
/* 2171 */       Buffer packet = new Buffer(6);
/* 2172 */       this.packetSequence = -1;
/* 2173 */       this.compressedPacketSequence = -1;
/* 2174 */       packet.writeByte((byte)1);
/* 2175 */       send(packet, packet.getPosition());
/*      */     } finally {
/* 2177 */       forceClose();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Buffer getSharedSendPacket()
/*      */   {
/* 2188 */     if (this.sharedSendPacket == null) {
/* 2189 */       this.sharedSendPacket = new Buffer(1024);
/*      */     }
/*      */     
/* 2192 */     return this.sharedSendPacket;
/*      */   }
/*      */   
/*      */   void closeStreamer(RowData streamer) throws SQLException {
/* 2196 */     if (this.streamingData == null) {
/* 2197 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.17") + streamer + Messages.getString("MysqlIO.18"), getExceptionInterceptor());
/*      */     }
/*      */     
/* 2200 */     if (streamer != this.streamingData) {
/* 2201 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.19") + streamer + Messages.getString("MysqlIO.20") + Messages.getString("MysqlIO.21") + Messages.getString("MysqlIO.22"), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 2205 */     this.streamingData = null;
/*      */   }
/*      */   
/*      */   boolean tackOnMoreStreamingResults(ResultSetImpl addingTo) throws SQLException {
/* 2209 */     if ((this.serverStatus & 0x8) != 0)
/*      */     {
/* 2211 */       boolean moreRowSetsExist = true;
/* 2212 */       ResultSetImpl currentResultSet = addingTo;
/* 2213 */       boolean firstTime = true;
/*      */       
/* 2215 */       while ((moreRowSetsExist) && (
/* 2216 */         (firstTime) || (!currentResultSet.reallyResult())))
/*      */       {
/*      */ 
/*      */ 
/* 2220 */         firstTime = false;
/*      */         
/* 2222 */         Buffer fieldPacket = checkErrorPacket();
/* 2223 */         fieldPacket.setPosition(0);
/*      */         
/* 2225 */         java.sql.Statement owningStatement = addingTo.getStatement();
/*      */         
/* 2227 */         int maxRows = owningStatement.getMaxRows();
/*      */         
/*      */ 
/*      */ 
/* 2231 */         ResultSetImpl newResultSet = readResultsForQueryOrUpdate((StatementImpl)owningStatement, maxRows, owningStatement.getResultSetType(), owningStatement.getResultSetConcurrency(), true, owningStatement.getConnection().getCatalog(), fieldPacket, addingTo.isBinaryEncoded, -1L, null);
/*      */         
/*      */ 
/*      */ 
/* 2235 */         currentResultSet.setNextResultSet(newResultSet);
/*      */         
/* 2237 */         currentResultSet = newResultSet;
/*      */         
/* 2239 */         moreRowSetsExist = (this.serverStatus & 0x8) != 0;
/*      */         
/* 2241 */         if ((!currentResultSet.reallyResult()) && (!moreRowSetsExist))
/*      */         {
/* 2243 */           return false;
/*      */         }
/*      */       }
/*      */       
/* 2247 */       return true;
/*      */     }
/*      */     
/* 2250 */     return false;
/*      */   }
/*      */   
/*      */   ResultSetImpl readAllResults(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache) throws SQLException
/*      */   {
/* 2255 */     resultPacket.setPosition(resultPacket.getPosition() - 1);
/*      */     
/* 2257 */     ResultSetImpl topLevelResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache);
/*      */     
/*      */ 
/* 2260 */     ResultSetImpl currentResultSet = topLevelResultSet;
/*      */     
/* 2262 */     boolean checkForMoreResults = (this.clientParam & 0x20000) != 0L;
/*      */     
/* 2264 */     boolean serverHasMoreResults = (this.serverStatus & 0x8) != 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2269 */     if ((serverHasMoreResults) && (streamResults))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2274 */       if (topLevelResultSet.getUpdateCount() != -1L) {
/* 2275 */         tackOnMoreStreamingResults(topLevelResultSet);
/*      */       }
/*      */       
/* 2278 */       reclaimLargeReusablePacket();
/*      */       
/* 2280 */       return topLevelResultSet;
/*      */     }
/*      */     
/* 2283 */     boolean moreRowSetsExist = checkForMoreResults & serverHasMoreResults;
/*      */     
/* 2285 */     while (moreRowSetsExist) {
/* 2286 */       Buffer fieldPacket = checkErrorPacket();
/* 2287 */       fieldPacket.setPosition(0);
/*      */       
/* 2289 */       ResultSetImpl newResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, fieldPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache);
/*      */       
/*      */ 
/* 2292 */       currentResultSet.setNextResultSet(newResultSet);
/*      */       
/* 2294 */       currentResultSet = newResultSet;
/*      */       
/* 2296 */       moreRowSetsExist = (this.serverStatus & 0x8) != 0;
/*      */     }
/*      */     
/* 2299 */     if (!streamResults) {
/* 2300 */       clearInputStream();
/*      */     }
/*      */     
/* 2303 */     reclaimLargeReusablePacket();
/*      */     
/* 2305 */     return topLevelResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void resetMaxBuf()
/*      */   {
/* 2312 */     this.maxAllowedPacket = this.connection.getMaxAllowedPacket();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Buffer sendCommand(int command, String extraData, Buffer queryPacket, boolean skipCheck, String extraDataCharEncoding, int timeoutMillis)
/*      */     throws SQLException
/*      */   {
/* 2343 */     this.commandCount += 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2349 */     this.enablePacketDebug = this.connection.getEnablePacketDebug();
/* 2350 */     this.readPacketSequence = 0;
/*      */     
/* 2352 */     int oldTimeout = 0;
/*      */     
/* 2354 */     if (timeoutMillis != 0) {
/*      */       try {
/* 2356 */         oldTimeout = this.mysqlConnection.getSoTimeout();
/* 2357 */         this.mysqlConnection.setSoTimeout(timeoutMillis);
/*      */       } catch (SocketException e) {
/* 2359 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2366 */       checkForOutstandingStreamingData();
/*      */       
/*      */ 
/* 2369 */       this.oldServerStatus = this.serverStatus;
/* 2370 */       this.serverStatus = 0;
/* 2371 */       this.hadWarnings = false;
/* 2372 */       this.warningCount = 0;
/*      */       
/* 2374 */       this.queryNoIndexUsed = false;
/* 2375 */       this.queryBadIndexUsed = false;
/* 2376 */       this.serverQueryWasSlow = false;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2381 */       if (this.useCompression) {
/* 2382 */         int bytesLeft = this.mysqlInput.available();
/*      */         
/* 2384 */         if (bytesLeft > 0) {
/* 2385 */           this.mysqlInput.skip(bytesLeft);
/*      */         }
/*      */       }
/*      */       long id;
/*      */       try {
/* 2390 */         clearInputStream();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2397 */         if (queryPacket == null) {
/* 2398 */           int packLength = 8 + (extraData != null ? extraData.length() : 0) + 2;
/*      */           
/* 2400 */           if (this.sendPacket == null) {
/* 2401 */             this.sendPacket = new Buffer(packLength);
/*      */           }
/*      */           
/* 2404 */           this.packetSequence = -1;
/* 2405 */           this.compressedPacketSequence = -1;
/* 2406 */           this.readPacketSequence = 0;
/* 2407 */           this.checkPacketSequence = true;
/* 2408 */           this.sendPacket.clear();
/*      */           
/* 2410 */           this.sendPacket.writeByte((byte)command);
/*      */           
/* 2412 */           if ((command == 2) || (command == 5) || (command == 6) || (command == 3) || (command == 22))
/*      */           {
/* 2414 */             if (extraDataCharEncoding == null) {
/* 2415 */               this.sendPacket.writeStringNoNull(extraData);
/*      */             } else {
/* 2417 */               this.sendPacket.writeStringNoNull(extraData, extraDataCharEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection);
/*      */             }
/*      */           }
/* 2420 */           else if (command == 12) {
/* 2421 */             id = Long.parseLong(extraData);
/* 2422 */             this.sendPacket.writeLong(id);
/*      */           }
/*      */           
/* 2425 */           send(this.sendPacket, this.sendPacket.getPosition());
/*      */         } else {
/* 2427 */           this.packetSequence = -1;
/* 2428 */           this.compressedPacketSequence = -1;
/* 2429 */           send(queryPacket, queryPacket.getPosition());
/*      */         }
/*      */       }
/*      */       catch (SQLException sqlEx) {
/* 2433 */         throw sqlEx;
/*      */       } catch (Exception ex) {
/* 2435 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 2439 */       Buffer returnPacket = null;
/*      */       
/* 2441 */       if (!skipCheck) {
/* 2442 */         if ((command == 23) || (command == 26)) {
/* 2443 */           this.readPacketSequence = 0;
/* 2444 */           this.packetSequenceReset = true;
/*      */         }
/*      */         
/* 2447 */         returnPacket = checkErrorPacket(command);
/*      */       }
/*      */       
/* 2450 */       return returnPacket;
/*      */     } catch (IOException ioEx) {
/* 2452 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     finally {
/* 2455 */       if (timeoutMillis != 0) {
/*      */         try {
/* 2457 */           this.mysqlConnection.setSoTimeout(oldTimeout);
/*      */         } catch (SocketException e) {
/* 2459 */           throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 2466 */   private int statementExecutionDepth = 0;
/*      */   private boolean useAutoSlowLog;
/*      */   
/*      */   protected boolean shouldIntercept() {
/* 2470 */     return this.statementInterceptors != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ResultSetInternalMethods sqlQueryDirect(StatementImpl callingStatement, String query, String characterEncoding, Buffer queryPacket, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata)
/*      */     throws Exception
/*      */   {
/* 2493 */     this.statementExecutionDepth += 1;
/*      */     try
/*      */     {
/* 2496 */       if (this.statementInterceptors != null) {
/* 2497 */         ResultSetInternalMethods interceptedResults = invokeStatementInterceptorsPre(query, callingStatement, false);
/*      */         
/* 2499 */         if (interceptedResults != null) {
/* 2500 */           return interceptedResults;
/*      */         }
/*      */       }
/*      */       
/* 2504 */       long queryStartTime = 0L;
/* 2505 */       long queryEndTime = 0L;
/*      */       
/* 2507 */       String statementComment = this.connection.getStatementComment();
/*      */       
/* 2509 */       if (this.connection.getIncludeThreadNamesAsStatementComment()) {
/* 2510 */         statementComment = (statementComment != null ? statementComment + ", " : "") + "java thread: " + Thread.currentThread().getName();
/*      */       }
/*      */       
/* 2513 */       if (query != null)
/*      */       {
/*      */ 
/* 2516 */         int packLength = 5 + query.length() * 3 + 2;
/*      */         
/* 2518 */         byte[] commentAsBytes = null;
/*      */         
/* 2520 */         if (statementComment != null) {
/* 2521 */           commentAsBytes = StringUtils.getBytes(statementComment, null, characterEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           
/*      */ 
/* 2524 */           packLength += commentAsBytes.length;
/* 2525 */           packLength += 6;
/*      */         }
/*      */         
/* 2528 */         if (this.sendPacket == null) {
/* 2529 */           this.sendPacket = new Buffer(packLength);
/*      */         } else {
/* 2531 */           this.sendPacket.clear();
/*      */         }
/*      */         
/* 2534 */         this.sendPacket.writeByte((byte)3);
/*      */         
/* 2536 */         if (commentAsBytes != null) {
/* 2537 */           this.sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 2538 */           this.sendPacket.writeBytesNoNull(commentAsBytes);
/* 2539 */           this.sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*      */         }
/*      */         
/* 2542 */         if (characterEncoding != null) {
/* 2543 */           if (this.platformDbCharsetMatches) {
/* 2544 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection);
/*      */ 
/*      */           }
/* 2547 */           else if (StringUtils.startsWithIgnoreCaseAndWs(query, "LOAD DATA")) {
/* 2548 */             this.sendPacket.writeBytesNoNull(StringUtils.getBytes(query));
/*      */           } else {
/* 2550 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection);
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/* 2555 */           this.sendPacket.writeStringNoNull(query);
/*      */         }
/*      */         
/* 2558 */         queryPacket = this.sendPacket;
/*      */       }
/*      */       
/* 2561 */       byte[] queryBuf = null;
/* 2562 */       int oldPacketPosition = 0;
/*      */       
/* 2564 */       if (this.needToGrabQueryFromPacket) {
/* 2565 */         queryBuf = queryPacket.getByteBuffer();
/*      */         
/*      */ 
/* 2568 */         oldPacketPosition = queryPacket.getPosition();
/*      */         
/* 2570 */         queryStartTime = getCurrentTimeNanosOrMillis();
/*      */       }
/*      */       
/* 2573 */       if (this.autoGenerateTestcaseScript) {
/* 2574 */         String testcaseQuery = null;
/*      */         
/* 2576 */         if (query != null) {
/* 2577 */           if (statementComment != null) {
/* 2578 */             testcaseQuery = "/* " + statementComment + " */ " + query;
/*      */           } else {
/* 2580 */             testcaseQuery = query;
/*      */           }
/*      */         } else {
/* 2583 */           testcaseQuery = StringUtils.toString(queryBuf, 5, oldPacketPosition - 5);
/*      */         }
/*      */         
/* 2586 */         StringBuilder debugBuf = new StringBuilder(testcaseQuery.length() + 32);
/* 2587 */         this.connection.generateConnectionCommentBlock(debugBuf);
/* 2588 */         debugBuf.append(testcaseQuery);
/* 2589 */         debugBuf.append(';');
/* 2590 */         this.connection.dumpTestcaseQuery(debugBuf.toString());
/*      */       }
/*      */       
/*      */ 
/* 2594 */       Buffer resultPacket = sendCommand(3, null, queryPacket, false, null, 0);
/*      */       
/* 2596 */       long fetchBeginTime = 0L;
/* 2597 */       long fetchEndTime = 0L;
/*      */       
/* 2599 */       String profileQueryToLog = null;
/*      */       
/* 2601 */       boolean queryWasSlow = false;
/*      */       
/* 2603 */       if ((this.profileSql) || (this.logSlowQueries)) {
/* 2604 */         queryEndTime = getCurrentTimeNanosOrMillis();
/*      */         
/* 2606 */         boolean shouldExtractQuery = false;
/*      */         
/* 2608 */         if (this.profileSql) {
/* 2609 */           shouldExtractQuery = true;
/* 2610 */         } else if (this.logSlowQueries) {
/* 2611 */           long queryTime = queryEndTime - queryStartTime;
/*      */           
/* 2613 */           boolean logSlow = false;
/*      */           
/* 2615 */           if (!this.useAutoSlowLog) {
/* 2616 */             logSlow = queryTime > this.connection.getSlowQueryThresholdMillis();
/*      */           } else {
/* 2618 */             logSlow = this.connection.isAbonormallyLongQuery(queryTime);
/*      */             
/* 2620 */             this.connection.reportQueryTime(queryTime);
/*      */           }
/*      */           
/* 2623 */           if (logSlow) {
/* 2624 */             shouldExtractQuery = true;
/* 2625 */             queryWasSlow = true;
/*      */           }
/*      */         }
/*      */         
/* 2629 */         if (shouldExtractQuery)
/*      */         {
/* 2631 */           boolean truncated = false;
/*      */           
/* 2633 */           int extractPosition = oldPacketPosition;
/*      */           
/* 2635 */           if (oldPacketPosition > this.connection.getMaxQuerySizeToLog()) {
/* 2636 */             extractPosition = this.connection.getMaxQuerySizeToLog() + 5;
/* 2637 */             truncated = true;
/*      */           }
/*      */           
/* 2640 */           profileQueryToLog = StringUtils.toString(queryBuf, 5, extractPosition - 5);
/*      */           
/* 2642 */           if (truncated) {
/* 2643 */             profileQueryToLog = profileQueryToLog + Messages.getString("MysqlIO.25");
/*      */           }
/*      */         }
/*      */         
/* 2647 */         fetchBeginTime = queryEndTime;
/*      */       }
/*      */       
/* 2650 */       ResultSetInternalMethods rs = readAllResults(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, false, -1L, cachedMetadata);
/*      */       
/*      */ 
/* 2653 */       if ((queryWasSlow) && (!this.serverQueryWasSlow)) {
/* 2654 */         StringBuilder mesgBuf = new StringBuilder(48 + profileQueryToLog.length());
/*      */         
/* 2656 */         mesgBuf.append(Messages.getString("MysqlIO.SlowQuery", new Object[] { String.valueOf(this.useAutoSlowLog ? " 95% of all queries " : Long.valueOf(this.slowQueryThreshold)), this.queryTimingUnits, Long.valueOf(queryEndTime - queryStartTime) }));
/*      */         
/*      */ 
/*      */ 
/* 2660 */         mesgBuf.append(profileQueryToLog);
/*      */         
/* 2662 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2664 */         eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), mesgBuf.toString()));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2669 */         if (this.connection.getExplainSlowQueries()) {
/* 2670 */           if (oldPacketPosition < 1048576) {
/* 2671 */             explainSlowQuery(queryPacket.getBytes(5, oldPacketPosition - 5), profileQueryToLog);
/*      */           } else {
/* 2673 */             this.connection.getLog().logWarn(Messages.getString("MysqlIO.28") + 1048576 + Messages.getString("MysqlIO.29"));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2678 */       if (this.logSlowQueries)
/*      */       {
/* 2680 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2682 */         if ((this.queryBadIndexUsed) && (this.profileSql)) {
/* 2683 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), Messages.getString("MysqlIO.33") + profileQueryToLog));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2689 */         if ((this.queryNoIndexUsed) && (this.profileSql)) {
/* 2690 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), Messages.getString("MysqlIO.35") + profileQueryToLog));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2696 */         if ((this.serverQueryWasSlow) && (this.profileSql)) {
/* 2697 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), Messages.getString("MysqlIO.ServerSlowQuery") + profileQueryToLog));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2704 */       if (this.profileSql) {
/* 2705 */         fetchEndTime = getCurrentTimeNanosOrMillis();
/*      */         
/* 2707 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2709 */         eventSink.consumeEvent(new ProfilerEvent((byte)3, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), profileQueryToLog));
/*      */         
/*      */ 
/*      */ 
/* 2713 */         eventSink.consumeEvent(new ProfilerEvent((byte)5, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), fetchEndTime - fetchBeginTime, this.queryTimingUnits, null, LogUtils.findCallingClassAndMethod(new Throwable()), null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2718 */       if (this.hadWarnings) {
/* 2719 */         scanForAndThrowDataTruncation();
/*      */       }
/*      */       ResultSetInternalMethods interceptedResults;
/* 2722 */       if (this.statementInterceptors != null) {
/* 2723 */         interceptedResults = invokeStatementInterceptorsPost(query, callingStatement, rs, false, null);
/*      */         
/* 2725 */         if (interceptedResults != null) {
/* 2726 */           rs = interceptedResults;
/*      */         }
/*      */       }
/*      */       
/* 2730 */       return rs;
/*      */     } catch (SQLException sqlEx) {
/* 2732 */       if (this.statementInterceptors != null) {
/* 2733 */         invokeStatementInterceptorsPost(query, callingStatement, null, false, sqlEx);
/*      */       }
/*      */       
/* 2736 */       if (callingStatement != null) {
/* 2737 */         synchronized (callingStatement.cancelTimeoutMutex) {
/* 2738 */           if (callingStatement.wasCancelled) {
/* 2739 */             SQLException cause = null;
/*      */             
/* 2741 */             if (callingStatement.wasCancelledByTimeout) {
/* 2742 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 2744 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 2747 */             callingStatement.resetCancelledState();
/*      */             
/* 2749 */             throw cause;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2754 */       throw sqlEx;
/*      */     } finally {
/* 2756 */       this.statementExecutionDepth -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */   ResultSetInternalMethods invokeStatementInterceptorsPre(String sql, Statement interceptedStatement, boolean forceExecute) throws SQLException {
/* 2761 */     ResultSetInternalMethods previousResultSet = null;
/*      */     
/* 2763 */     int i = 0; for (int s = this.statementInterceptors.size(); i < s; i++) {
/* 2764 */       StatementInterceptorV2 interceptor = (StatementInterceptorV2)this.statementInterceptors.get(i);
/*      */       
/* 2766 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2767 */       boolean shouldExecute = ((executeTopLevelOnly) && ((this.statementExecutionDepth == 1) || (forceExecute))) || (!executeTopLevelOnly);
/*      */       
/* 2769 */       if (shouldExecute) {
/* 2770 */         String sqlToInterceptor = sql;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2777 */         ResultSetInternalMethods interceptedResultSet = interceptor.preProcess(sqlToInterceptor, interceptedStatement, this.connection);
/*      */         
/* 2779 */         if (interceptedResultSet != null) {
/* 2780 */           previousResultSet = interceptedResultSet;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2785 */     return previousResultSet;
/*      */   }
/*      */   
/*      */   ResultSetInternalMethods invokeStatementInterceptorsPost(String sql, Statement interceptedStatement, ResultSetInternalMethods originalResultSet, boolean forceExecute, SQLException statementException)
/*      */     throws SQLException
/*      */   {
/* 2791 */     int i = 0; for (int s = this.statementInterceptors.size(); i < s; i++) {
/* 2792 */       StatementInterceptorV2 interceptor = (StatementInterceptorV2)this.statementInterceptors.get(i);
/*      */       
/* 2794 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2795 */       boolean shouldExecute = ((executeTopLevelOnly) && ((this.statementExecutionDepth == 1) || (forceExecute))) || (!executeTopLevelOnly);
/*      */       
/* 2797 */       if (shouldExecute) {
/* 2798 */         String sqlToInterceptor = sql;
/*      */         
/* 2800 */         ResultSetInternalMethods interceptedResultSet = interceptor.postProcess(sqlToInterceptor, interceptedStatement, originalResultSet, this.connection, this.warningCount, this.queryNoIndexUsed, this.queryBadIndexUsed, statementException);
/*      */         
/*      */ 
/* 2803 */         if (interceptedResultSet != null) {
/* 2804 */           originalResultSet = interceptedResultSet;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2809 */     return originalResultSet;
/*      */   }
/*      */   
/*      */   private void calculateSlowQueryThreshold() {
/* 2813 */     this.slowQueryThreshold = this.connection.getSlowQueryThresholdMillis();
/*      */     
/* 2815 */     if (this.connection.getUseNanosForElapsedTime()) {
/* 2816 */       long nanosThreshold = this.connection.getSlowQueryThresholdNanos();
/*      */       
/* 2818 */       if (nanosThreshold != 0L) {
/* 2819 */         this.slowQueryThreshold = nanosThreshold;
/*      */       } else {
/* 2821 */         this.slowQueryThreshold *= 1000000L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected long getCurrentTimeNanosOrMillis() {
/* 2827 */     if (this.useNanosForElapsedTime) {
/* 2828 */       return TimeUtil.getCurrentTimeNanosOrMillis();
/*      */     }
/*      */     
/* 2831 */     return System.currentTimeMillis();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   String getHost()
/*      */   {
/* 2838 */     return this.host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isVersion(int major, int minor, int subminor)
/*      */   {
/* 2856 */     return (major == getServerMajorVersion()) && (minor == getServerMinorVersion()) && (subminor == getServerSubMinorVersion());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean versionMeetsMinimum(int major, int minor, int subminor)
/*      */   {
/* 2868 */     if (getServerMajorVersion() >= major) {
/* 2869 */       if (getServerMajorVersion() == major) {
/* 2870 */         if (getServerMinorVersion() >= minor) {
/* 2871 */           if (getServerMinorVersion() == minor) {
/* 2872 */             return getServerSubMinorVersion() >= subminor;
/*      */           }
/*      */           
/*      */ 
/* 2876 */           return true;
/*      */         }
/*      */         
/*      */ 
/* 2880 */         return false;
/*      */       }
/*      */       
/*      */ 
/* 2884 */       return true;
/*      */     }
/*      */     
/* 2887 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String getPacketDumpToLog(Buffer packetToDump, int packetLength)
/*      */   {
/* 2902 */     if (packetLength < 1024) {
/* 2903 */       return packetToDump.dump(packetLength);
/*      */     }
/*      */     
/* 2906 */     StringBuilder packetDumpBuf = new StringBuilder(4096);
/* 2907 */     packetDumpBuf.append(packetToDump.dump(1024));
/* 2908 */     packetDumpBuf.append(Messages.getString("MysqlIO.36"));
/* 2909 */     packetDumpBuf.append(1024);
/* 2910 */     packetDumpBuf.append(Messages.getString("MysqlIO.37"));
/*      */     
/* 2912 */     return packetDumpBuf.toString();
/*      */   }
/*      */   
/*      */   private final int readFully(InputStream in, byte[] b, int off, int len) throws IOException {
/* 2916 */     if (len < 0) {
/* 2917 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/* 2920 */     int n = 0;
/*      */     
/* 2922 */     while (n < len) {
/* 2923 */       int count = in.read(b, off + n, len - n);
/*      */       
/* 2925 */       if (count < 0) {
/* 2926 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Integer.valueOf(len), Integer.valueOf(n) }));
/*      */       }
/*      */       
/* 2929 */       n += count;
/*      */     }
/*      */     
/* 2932 */     return n;
/*      */   }
/*      */   
/*      */   private final long skipFully(InputStream in, long len) throws IOException {
/* 2936 */     if (len < 0L) {
/* 2937 */       throw new IOException("Negative skip length not allowed");
/*      */     }
/*      */     
/* 2940 */     long n = 0L;
/*      */     
/* 2942 */     while (n < len) {
/* 2943 */       long count = in.skip(len - n);
/*      */       
/* 2945 */       if (count < 0L) {
/* 2946 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Long.valueOf(len), Long.valueOf(n) }));
/*      */       }
/*      */       
/* 2949 */       n += count;
/*      */     }
/*      */     
/* 2952 */     return n;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ResultSetImpl readResultsForQueryOrUpdate(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache)
/*      */     throws SQLException
/*      */   {
/* 2988 */     long columnCount = resultPacket.readFieldLength();
/*      */     
/* 2990 */     if (columnCount == 0L)
/* 2991 */       return buildResultSetWithUpdates(callingStatement, resultPacket);
/* 2992 */     if (columnCount == -1L) {
/* 2993 */       String charEncoding = null;
/*      */       
/* 2995 */       if (this.connection.getUseUnicode()) {
/* 2996 */         charEncoding = this.connection.getEncoding();
/*      */       }
/*      */       
/* 2999 */       String fileName = null;
/*      */       
/* 3001 */       if (this.platformDbCharsetMatches) {
/* 3002 */         fileName = charEncoding != null ? resultPacket.readString(charEncoding, getExceptionInterceptor()) : resultPacket.readString();
/*      */       } else {
/* 3004 */         fileName = resultPacket.readString();
/*      */       }
/*      */       
/* 3007 */       return sendFileToServer(callingStatement, fileName);
/*      */     }
/* 3009 */     ResultSetImpl results = getResultSet(callingStatement, columnCount, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, isBinaryEncoded, metadataFromCache);
/*      */     
/*      */ 
/* 3012 */     return results;
/*      */   }
/*      */   
/*      */   private int alignPacketSize(int a, int l)
/*      */   {
/* 3017 */     return a + l - 1 & (l - 1 ^ 0xFFFFFFFF);
/*      */   }
/*      */   
/*      */   private ResultSetImpl buildResultSetWithRows(StatementImpl callingStatement, String catalog, Field[] fields, RowData rows, int resultSetType, int resultSetConcurrency, boolean isBinaryEncoded) throws SQLException
/*      */   {
/* 3022 */     ResultSetImpl rs = null;
/*      */     
/* 3024 */     switch (resultSetConcurrency) {
/*      */     case 1007: 
/* 3026 */       rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */       
/* 3028 */       if (isBinaryEncoded) {
/* 3029 */         rs.setBinaryEncoded();
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 1008: 
/* 3035 */       rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, true);
/*      */       
/* 3037 */       break;
/*      */     
/*      */     default: 
/* 3040 */       return ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */     }
/*      */     
/* 3043 */     rs.setResultSetType(resultSetType);
/* 3044 */     rs.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 3046 */     return rs;
/*      */   }
/*      */   
/*      */   private ResultSetImpl buildResultSetWithUpdates(StatementImpl callingStatement, Buffer resultPacket) throws SQLException {
/* 3050 */     long updateCount = -1L;
/* 3051 */     long updateID = -1L;
/* 3052 */     String info = null;
/*      */     try
/*      */     {
/* 3055 */       if (this.useNewUpdateCounts) {
/* 3056 */         updateCount = resultPacket.newReadLength();
/* 3057 */         updateID = resultPacket.newReadLength();
/*      */       } else {
/* 3059 */         updateCount = resultPacket.readLength();
/* 3060 */         updateID = resultPacket.readLength();
/*      */       }
/*      */       
/* 3063 */       if (this.use41Extensions)
/*      */       {
/* 3065 */         this.serverStatus = resultPacket.readInt();
/*      */         
/* 3067 */         checkTransactionState(this.oldServerStatus);
/*      */         
/* 3069 */         this.warningCount = resultPacket.readInt();
/*      */         
/* 3071 */         if (this.warningCount > 0) {
/* 3072 */           this.hadWarnings = true;
/*      */         }
/*      */         
/* 3075 */         resultPacket.readByte();
/*      */         
/* 3077 */         setServerSlowQueryFlags();
/*      */       }
/*      */       
/* 3080 */       if (this.connection.isReadInfoMsgEnabled()) {
/* 3081 */         info = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */       }
/*      */     } catch (Exception ex) {
/* 3084 */       SQLException sqlEx = SQLError.createSQLException(SQLError.get("S1000"), "S1000", -1, getExceptionInterceptor());
/*      */       
/* 3086 */       sqlEx.initCause(ex);
/*      */       
/* 3088 */       throw sqlEx;
/*      */     }
/*      */     
/* 3091 */     ResultSetInternalMethods updateRs = ResultSetImpl.getInstance(updateCount, updateID, this.connection, callingStatement);
/*      */     
/* 3093 */     if (info != null) {
/* 3094 */       ((ResultSetImpl)updateRs).setServerInfo(info);
/*      */     }
/*      */     
/* 3097 */     return (ResultSetImpl)updateRs;
/*      */   }
/*      */   
/*      */   private void setServerSlowQueryFlags() {
/* 3101 */     this.queryBadIndexUsed = ((this.serverStatus & 0x10) != 0);
/* 3102 */     this.queryNoIndexUsed = ((this.serverStatus & 0x20) != 0);
/* 3103 */     this.serverQueryWasSlow = ((this.serverStatus & 0x800) != 0);
/*      */   }
/*      */   
/*      */   private void checkForOutstandingStreamingData() throws SQLException {
/* 3107 */     if (this.streamingData != null) {
/* 3108 */       boolean shouldClobber = this.connection.getClobberStreamingResults();
/*      */       
/* 3110 */       if (!shouldClobber) {
/* 3111 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.39") + this.streamingData + Messages.getString("MysqlIO.40") + Messages.getString("MysqlIO.41") + Messages.getString("MysqlIO.42"), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3117 */       this.streamingData.getOwner().realClose(false);
/*      */       
/*      */ 
/* 3120 */       clearInputStream();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Buffer compressPacket(Buffer packet, int offset, int packetLen)
/*      */     throws SQLException
/*      */   {
/* 3137 */     int compressedLength = packetLen;
/* 3138 */     int uncompressedLength = 0;
/* 3139 */     byte[] compressedBytes = null;
/* 3140 */     int offsetWrite = offset;
/*      */     
/* 3142 */     if (packetLen < 50) {
/* 3143 */       compressedBytes = packet.getByteBuffer();
/*      */     }
/*      */     else {
/* 3146 */       byte[] bytesToCompress = packet.getByteBuffer();
/* 3147 */       compressedBytes = new byte[bytesToCompress.length * 2];
/*      */       
/* 3149 */       if (this.deflater == null) {
/* 3150 */         this.deflater = new Deflater();
/*      */       }
/* 3152 */       this.deflater.reset();
/* 3153 */       this.deflater.setInput(bytesToCompress, offset, packetLen);
/* 3154 */       this.deflater.finish();
/*      */       
/* 3156 */       compressedLength = this.deflater.deflate(compressedBytes);
/*      */       
/* 3158 */       if (compressedLength > packetLen)
/*      */       {
/* 3160 */         compressedBytes = packet.getByteBuffer();
/* 3161 */         compressedLength = packetLen;
/*      */       } else {
/* 3163 */         uncompressedLength = packetLen;
/* 3164 */         offsetWrite = 0;
/*      */       }
/*      */     }
/*      */     
/* 3168 */     Buffer compressedPacket = new Buffer(7 + compressedLength);
/*      */     
/* 3170 */     compressedPacket.setPosition(0);
/* 3171 */     compressedPacket.writeLongInt(compressedLength);
/* 3172 */     compressedPacket.writeByte(this.compressedPacketSequence);
/* 3173 */     compressedPacket.writeLongInt(uncompressedLength);
/* 3174 */     compressedPacket.writeBytesNoNull(compressedBytes, offsetWrite, compressedLength);
/*      */     
/* 3176 */     return compressedPacket;
/*      */   }
/*      */   
/*      */   private final void readServerStatusForResultSets(Buffer rowPacket) throws SQLException {
/* 3180 */     if (this.use41Extensions) {
/* 3181 */       rowPacket.readByte();
/*      */       
/* 3183 */       this.warningCount = rowPacket.readInt();
/*      */       
/* 3185 */       if (this.warningCount > 0) {
/* 3186 */         this.hadWarnings = true;
/*      */       }
/*      */       
/* 3189 */       this.oldServerStatus = this.serverStatus;
/* 3190 */       this.serverStatus = rowPacket.readInt();
/* 3191 */       checkTransactionState(this.oldServerStatus);
/*      */       
/* 3193 */       setServerSlowQueryFlags();
/*      */     }
/*      */   }
/*      */   
/*      */   private SocketFactory createSocketFactory() throws SQLException {
/*      */     try {
/* 3199 */       if (this.socketFactoryClassName == null) {
/* 3200 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.75"), "08001", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 3204 */       return (SocketFactory)Class.forName(this.socketFactoryClassName).newInstance();
/*      */     } catch (Exception ex) {
/* 3206 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.76") + this.socketFactoryClassName + Messages.getString("MysqlIO.77"), "08001", getExceptionInterceptor());
/*      */       
/*      */ 
/* 3209 */       sqlEx.initCause(ex);
/*      */       
/* 3211 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private void enqueuePacketForDebugging(boolean isPacketBeingSent, boolean isPacketReused, int sendLength, byte[] header, Buffer packet) throws SQLException {
/* 3216 */     if (this.packetDebugRingBuffer.size() + 1 > this.connection.getPacketDebugBufferSize()) {
/* 3217 */       this.packetDebugRingBuffer.removeFirst();
/*      */     }
/*      */     
/* 3220 */     StringBuilder packetDump = null;
/*      */     
/* 3222 */     if (!isPacketBeingSent) {
/* 3223 */       int bytesToDump = Math.min(1024, packet.getBufLength());
/*      */       
/* 3225 */       Buffer packetToDump = new Buffer(4 + bytesToDump);
/*      */       
/* 3227 */       packetToDump.setPosition(0);
/* 3228 */       packetToDump.writeBytesNoNull(header);
/* 3229 */       packetToDump.writeBytesNoNull(packet.getBytes(0, bytesToDump));
/*      */       
/* 3231 */       String packetPayload = packetToDump.dump(bytesToDump);
/*      */       
/* 3233 */       packetDump = new StringBuilder(96 + packetPayload.length());
/*      */       
/* 3235 */       packetDump.append("Server ");
/*      */       
/* 3237 */       packetDump.append(isPacketReused ? "(re-used) " : "(new) ");
/*      */       
/* 3239 */       packetDump.append(packet.toSuperString());
/* 3240 */       packetDump.append(" --------------------> Client\n");
/* 3241 */       packetDump.append("\nPacket payload:\n\n");
/* 3242 */       packetDump.append(packetPayload);
/*      */       
/* 3244 */       if (bytesToDump == 1024) {
/* 3245 */         packetDump.append("\nNote: Packet of " + packet.getBufLength() + " bytes truncated to " + 1024 + " bytes.\n");
/*      */       }
/*      */     } else {
/* 3248 */       int bytesToDump = Math.min(1024, sendLength);
/*      */       
/* 3250 */       String packetPayload = packet.dump(bytesToDump);
/*      */       
/* 3252 */       packetDump = new StringBuilder(68 + packetPayload.length());
/*      */       
/* 3254 */       packetDump.append("Client ");
/* 3255 */       packetDump.append(packet.toSuperString());
/* 3256 */       packetDump.append("--------------------> Server\n");
/* 3257 */       packetDump.append("\nPacket payload:\n\n");
/* 3258 */       packetDump.append(packetPayload);
/*      */       
/* 3260 */       if (bytesToDump == 1024) {
/* 3261 */         packetDump.append("\nNote: Packet of " + sendLength + " bytes truncated to " + 1024 + " bytes.\n");
/*      */       }
/*      */     }
/*      */     
/* 3265 */     this.packetDebugRingBuffer.addLast(packetDump);
/*      */   }
/*      */   
/*      */   private RowData readSingleRowSet(long columnCount, int maxRows, int resultSetConcurrency, boolean isBinaryEncoded, Field[] fields) throws SQLException
/*      */   {
/* 3270 */     ArrayList<ResultSetRow> rows = new ArrayList();
/*      */     
/* 3272 */     boolean useBufferRowExplicit = useBufferRowExplicit(fields);
/*      */     
/*      */ 
/* 3275 */     ResultSetRow row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */     
/* 3277 */     int rowCount = 0;
/*      */     
/* 3279 */     if (row != null) {
/* 3280 */       rows.add(row);
/* 3281 */       rowCount = 1;
/*      */     }
/*      */     
/* 3284 */     while (row != null) {
/* 3285 */       row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */       
/* 3287 */       if ((row != null) && (
/* 3288 */         (maxRows == -1) || (rowCount < maxRows))) {
/* 3289 */         rows.add(row);
/* 3290 */         rowCount++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3295 */     RowData rowData = new RowDataStatic(rows);
/*      */     
/* 3297 */     return rowData;
/*      */   }
/*      */   
/*      */   public static boolean useBufferRowExplicit(Field[] fields) {
/* 3301 */     if (fields == null) {
/* 3302 */       return false;
/*      */     }
/*      */     
/* 3305 */     for (int i = 0; i < fields.length; i++) {
/* 3306 */       switch (fields[i].getSQLType()) {
/*      */       case -4: 
/*      */       case -1: 
/*      */       case 2004: 
/*      */       case 2005: 
/* 3311 */         return true;
/*      */       }
/*      */       
/*      */     }
/* 3315 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void reclaimLargeReusablePacket()
/*      */   {
/* 3322 */     if ((this.reusablePacket != null) && (this.reusablePacket.getCapacity() > 1048576)) {
/* 3323 */       this.reusablePacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse)
/*      */     throws SQLException
/*      */   {
/* 3334 */     return reuseAndReadPacket(reuse, -1);
/*      */   }
/*      */   
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse, int existingPacketLength) throws SQLException
/*      */   {
/*      */     try {
/* 3340 */       reuse.setWasMultiPacket(false);
/* 3341 */       int packetLength = 0;
/*      */       
/* 3343 */       if (existingPacketLength == -1) {
/* 3344 */         int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */         
/* 3346 */         if (lengthRead < 4) {
/* 3347 */           forceClose();
/* 3348 */           throw new IOException(Messages.getString("MysqlIO.43"));
/*      */         }
/*      */         
/* 3351 */         packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       } else {
/* 3353 */         packetLength = existingPacketLength;
/*      */       }
/*      */       
/* 3356 */       if (this.traceProtocol) {
/* 3357 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/* 3359 */         traceMessageBuf.append(Messages.getString("MysqlIO.44"));
/* 3360 */         traceMessageBuf.append(packetLength);
/* 3361 */         traceMessageBuf.append(Messages.getString("MysqlIO.45"));
/* 3362 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/* 3364 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/* 3367 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/* 3369 */       if (!this.packetSequenceReset) {
/* 3370 */         if ((this.enablePacketDebug) && (this.checkPacketSequence)) {
/* 3371 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/* 3374 */         this.packetSequenceReset = false;
/*      */       }
/*      */       
/* 3377 */       this.readPacketSequence = multiPacketSeq;
/*      */       
/*      */ 
/* 3380 */       reuse.setPosition(0);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3386 */       if (reuse.getByteBuffer().length <= packetLength) {
/* 3387 */         reuse.setByteBuffer(new byte[packetLength + 1]);
/*      */       }
/*      */       
/*      */ 
/* 3391 */       reuse.setBufLength(packetLength);
/*      */       
/*      */ 
/* 3394 */       int numBytesRead = readFully(this.mysqlInput, reuse.getByteBuffer(), 0, packetLength);
/*      */       
/* 3396 */       if (numBytesRead != packetLength) {
/* 3397 */         throw new IOException("Short read, expected " + packetLength + " bytes, only read " + numBytesRead);
/*      */       }
/*      */       
/* 3400 */       if (this.traceProtocol) {
/* 3401 */         StringBuilder traceMessageBuf = new StringBuilder();
/*      */         
/* 3403 */         traceMessageBuf.append(Messages.getString("MysqlIO.46"));
/* 3404 */         traceMessageBuf.append(getPacketDumpToLog(reuse, packetLength));
/*      */         
/* 3406 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/* 3409 */       if (this.enablePacketDebug) {
/* 3410 */         enqueuePacketForDebugging(false, true, 0, this.packetHeaderBuf, reuse);
/*      */       }
/*      */       
/* 3413 */       boolean isMultiPacket = false;
/*      */       
/* 3415 */       if (packetLength == this.maxThreeBytes) {
/* 3416 */         reuse.setPosition(this.maxThreeBytes);
/*      */         
/*      */ 
/* 3419 */         isMultiPacket = true;
/*      */         
/* 3421 */         packetLength = readRemainingMultiPackets(reuse, multiPacketSeq);
/*      */       }
/*      */       
/* 3424 */       if (!isMultiPacket) {
/* 3425 */         reuse.getByteBuffer()[packetLength] = 0;
/*      */       }
/*      */       
/* 3428 */       if (this.connection.getMaintainTimeStats()) {
/* 3429 */         this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/*      */       }
/*      */       
/* 3432 */       return reuse;
/*      */     } catch (IOException ioEx) {
/* 3434 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     catch (OutOfMemoryError oom)
/*      */     {
/*      */       try {
/* 3439 */         clearInputStream();
/*      */       }
/*      */       catch (Exception ex) {}
/*      */       try {
/* 3443 */         this.connection.realClose(false, false, true, oom);
/*      */       }
/*      */       catch (Exception ex) {}
/* 3446 */       throw oom;
/*      */     }
/*      */   }
/*      */   
/*      */   private int readRemainingMultiPackets(Buffer reuse, byte multiPacketSeq) throws IOException, SQLException
/*      */   {
/* 3452 */     int packetLength = -1;
/* 3453 */     Buffer multiPacket = null;
/*      */     do
/*      */     {
/* 3456 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/* 3457 */       if (lengthRead < 4) {
/* 3458 */         forceClose();
/* 3459 */         throw new IOException(Messages.getString("MysqlIO.47"));
/*      */       }
/*      */       
/* 3462 */       packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/* 3463 */       if (multiPacket == null) {
/* 3464 */         multiPacket = new Buffer(packetLength);
/*      */       }
/*      */       
/* 3467 */       if ((!this.useNewLargePackets) && (packetLength == 1)) {
/* 3468 */         clearInputStream();
/* 3469 */         break;
/*      */       }
/*      */       
/* 3472 */       multiPacketSeq = (byte)(multiPacketSeq + 1);
/* 3473 */       if (multiPacketSeq != this.packetHeaderBuf[3]) {
/* 3474 */         throw new IOException(Messages.getString("MysqlIO.49"));
/*      */       }
/*      */       
/*      */ 
/* 3478 */       multiPacket.setPosition(0);
/*      */       
/*      */ 
/* 3481 */       multiPacket.setBufLength(packetLength);
/*      */       
/*      */ 
/* 3484 */       byte[] byteBuf = multiPacket.getByteBuffer();
/* 3485 */       int lengthToWrite = packetLength;
/*      */       
/* 3487 */       int bytesRead = readFully(this.mysqlInput, byteBuf, 0, packetLength);
/*      */       
/* 3489 */       if (bytesRead != lengthToWrite) {
/* 3490 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, SQLError.createSQLException(Messages.getString("MysqlIO.50") + lengthToWrite + Messages.getString("MysqlIO.51") + bytesRead + ".", getExceptionInterceptor()), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3495 */       reuse.writeBytesNoNull(byteBuf, 0, lengthToWrite);
/* 3496 */     } while (packetLength == this.maxThreeBytes);
/*      */     
/* 3498 */     reuse.setPosition(0);
/* 3499 */     reuse.setWasMultiPacket(true);
/* 3500 */     return packetLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void checkPacketSequencing(byte multiPacketSeq)
/*      */     throws SQLException
/*      */   {
/* 3508 */     if ((multiPacketSeq == Byte.MIN_VALUE) && (this.readPacketSequence != Byte.MAX_VALUE)) {
/* 3509 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -128, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3513 */     if ((this.readPacketSequence == -1) && (multiPacketSeq != 0)) {
/* 3514 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -1, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3518 */     if ((multiPacketSeq != Byte.MIN_VALUE) && (this.readPacketSequence != -1) && (multiPacketSeq != this.readPacketSequence + 1)) {
/* 3519 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # " + (this.readPacketSequence + 1) + ", but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   void enableMultiQueries()
/*      */     throws SQLException
/*      */   {
/* 3526 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3528 */     buf.clear();
/* 3529 */     buf.writeByte((byte)27);
/* 3530 */     buf.writeInt(0);
/* 3531 */     sendCommand(27, null, buf, false, null, 0);
/*      */   }
/*      */   
/*      */   void disableMultiQueries() throws SQLException {
/* 3535 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3537 */     buf.clear();
/* 3538 */     buf.writeByte((byte)27);
/* 3539 */     buf.writeInt(1);
/* 3540 */     sendCommand(27, null, buf, false, null, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void send(Buffer packet, int packetLen)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3551 */       if ((this.maxAllowedPacket > 0) && (packetLen > this.maxAllowedPacket)) {
/* 3552 */         throw new PacketTooBigException(packetLen, this.maxAllowedPacket);
/*      */       }
/*      */       
/* 3555 */       if ((this.serverMajorVersion >= 4) && ((packetLen - 4 >= this.maxThreeBytes) || ((this.useCompression) && (packetLen - 4 >= this.maxThreeBytes - 3))))
/*      */       {
/*      */ 
/* 3558 */         sendSplitPackets(packet, packetLen);
/*      */       }
/*      */       else {
/* 3561 */         this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */         
/* 3563 */         Buffer packetToSend = packet;
/* 3564 */         packetToSend.setPosition(0);
/* 3565 */         packetToSend.writeLongInt(packetLen - 4);
/* 3566 */         packetToSend.writeByte(this.packetSequence);
/*      */         
/* 3568 */         if (this.useCompression) {
/* 3569 */           this.compressedPacketSequence = ((byte)(this.compressedPacketSequence + 1));
/* 3570 */           int originalPacketLen = packetLen;
/*      */           
/* 3572 */           packetToSend = compressPacket(packetToSend, 0, packetLen);
/* 3573 */           packetLen = packetToSend.getPosition();
/*      */           
/* 3575 */           if (this.traceProtocol) {
/* 3576 */             StringBuilder traceMessageBuf = new StringBuilder();
/*      */             
/* 3578 */             traceMessageBuf.append(Messages.getString("MysqlIO.57"));
/* 3579 */             traceMessageBuf.append(getPacketDumpToLog(packetToSend, packetLen));
/* 3580 */             traceMessageBuf.append(Messages.getString("MysqlIO.58"));
/* 3581 */             traceMessageBuf.append(getPacketDumpToLog(packet, originalPacketLen));
/*      */             
/* 3583 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           }
/*      */           
/*      */         }
/* 3587 */         else if (this.traceProtocol) {
/* 3588 */           StringBuilder traceMessageBuf = new StringBuilder();
/*      */           
/* 3590 */           traceMessageBuf.append(Messages.getString("MysqlIO.59"));
/* 3591 */           traceMessageBuf.append("host: '");
/* 3592 */           traceMessageBuf.append(this.host);
/* 3593 */           traceMessageBuf.append("' threadId: '");
/* 3594 */           traceMessageBuf.append(this.threadId);
/* 3595 */           traceMessageBuf.append("'\n");
/* 3596 */           traceMessageBuf.append(packetToSend.dump(packetLen));
/*      */           
/* 3598 */           this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */         }
/*      */         
/*      */ 
/* 3602 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/* 3603 */         this.mysqlOutput.flush();
/*      */       }
/*      */       
/* 3606 */       if (this.enablePacketDebug) {
/* 3607 */         enqueuePacketForDebugging(true, false, packetLen + 5, this.packetHeaderBuf, packet);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3613 */       if (packet == this.sharedSendPacket) {
/* 3614 */         reclaimLargeSharedSendPacket();
/*      */       }
/*      */       
/* 3617 */       if (this.connection.getMaintainTimeStats()) {
/* 3618 */         this.lastPacketSentTimeMs = System.currentTimeMillis();
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 3621 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ResultSetImpl sendFileToServer(StatementImpl callingStatement, String fileName)
/*      */     throws SQLException
/*      */   {
/* 3637 */     if (this.useCompression) {
/* 3638 */       this.compressedPacketSequence = ((byte)(this.compressedPacketSequence + 1));
/*      */     }
/*      */     
/* 3641 */     Buffer filePacket = this.loadFileBufRef == null ? null : (Buffer)this.loadFileBufRef.get();
/*      */     
/* 3643 */     int bigPacketLength = Math.min(this.connection.getMaxAllowedPacket() - 12, alignPacketSize(this.connection.getMaxAllowedPacket() - 16, 4096) - 12);
/*      */     
/*      */ 
/* 3646 */     int oneMeg = 1048576;
/*      */     
/* 3648 */     int smallerPacketSizeAligned = Math.min(oneMeg - 12, alignPacketSize(oneMeg - 16, 4096) - 12);
/*      */     
/* 3650 */     int packetLength = Math.min(smallerPacketSizeAligned, bigPacketLength);
/*      */     
/* 3652 */     if (filePacket == null) {
/*      */       try {
/* 3654 */         filePacket = new Buffer(packetLength + 4);
/* 3655 */         this.loadFileBufRef = new SoftReference(filePacket);
/*      */       } catch (OutOfMemoryError oom) {
/* 3657 */         throw SQLError.createSQLException("Could not allocate packet of " + packetLength + " bytes required for LOAD DATA LOCAL INFILE operation." + " Try increasing max heap allocation for JVM or decreasing server variable 'max_allowed_packet'", "S1001", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3664 */     filePacket.clear();
/* 3665 */     send(filePacket, 0);
/*      */     
/* 3667 */     byte[] fileBuf = new byte[packetLength];
/*      */     
/* 3669 */     BufferedInputStream fileIn = null;
/*      */     try
/*      */     {
/* 3672 */       if (!this.connection.getAllowLoadLocalInfile()) {
/* 3673 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.LoadDataLocalNotAllowed"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 3677 */       InputStream hookedStream = null;
/*      */       
/* 3679 */       if (callingStatement != null) {
/* 3680 */         hookedStream = callingStatement.getLocalInfileInputStream();
/*      */       }
/*      */       
/* 3683 */       if (hookedStream != null) {
/* 3684 */         fileIn = new BufferedInputStream(hookedStream);
/* 3685 */       } else if (!this.connection.getAllowUrlInLocalInfile()) {
/* 3686 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */ 
/*      */       }
/* 3689 */       else if (fileName.indexOf(':') != -1) {
/*      */         try {
/* 3691 */           URL urlFromFileName = new URL(fileName);
/* 3692 */           fileIn = new BufferedInputStream(urlFromFileName.openStream());
/*      */         }
/*      */         catch (MalformedURLException badUrlEx) {
/* 3695 */           fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */         }
/*      */       } else {
/* 3698 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       }
/*      */       
/*      */ 
/* 3702 */       int bytesRead = 0;
/*      */       
/* 3704 */       while ((bytesRead = fileIn.read(fileBuf)) != -1) {
/* 3705 */         filePacket.clear();
/* 3706 */         filePacket.writeBytesNoNull(fileBuf, 0, bytesRead);
/* 3707 */         send(filePacket, filePacket.getPosition());
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 3710 */       StringBuilder messageBuf = new StringBuilder(Messages.getString("MysqlIO.60"));
/*      */       
/* 3712 */       if ((fileName != null) && (!this.connection.getParanoid())) {
/* 3713 */         messageBuf.append("'");
/* 3714 */         messageBuf.append(fileName);
/* 3715 */         messageBuf.append("'");
/*      */       }
/*      */       
/* 3718 */       messageBuf.append(Messages.getString("MysqlIO.63"));
/*      */       
/* 3720 */       if (!this.connection.getParanoid()) {
/* 3721 */         messageBuf.append(Messages.getString("MysqlIO.64"));
/* 3722 */         messageBuf.append(Util.stackTraceToString(ioEx));
/*      */       }
/*      */       
/* 3725 */       throw SQLError.createSQLException(messageBuf.toString(), "S1009", getExceptionInterceptor());
/*      */     } finally {
/* 3727 */       if (fileIn != null) {
/*      */         try {
/* 3729 */           fileIn.close();
/*      */         } catch (Exception ex) {
/* 3731 */           SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.65"), "S1000", ex, getExceptionInterceptor());
/*      */           
/*      */ 
/* 3734 */           throw sqlEx;
/*      */         }
/*      */         
/* 3737 */         fileIn = null;
/*      */       }
/*      */       else {
/* 3740 */         filePacket.clear();
/* 3741 */         send(filePacket, filePacket.getPosition());
/* 3742 */         checkErrorPacket();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3747 */     filePacket.clear();
/* 3748 */     send(filePacket, filePacket.getPosition());
/*      */     
/* 3750 */     Buffer resultPacket = checkErrorPacket();
/*      */     
/* 3752 */     return buildResultSetWithUpdates(callingStatement, resultPacket);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Buffer checkErrorPacket(int command)
/*      */     throws SQLException
/*      */   {
/* 3768 */     Buffer resultPacket = null;
/* 3769 */     this.serverStatus = 0;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 3774 */       resultPacket = reuseAndReadPacket(this.reusablePacket);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 3777 */       throw sqlEx;
/*      */     } catch (Exception fallThru) {
/* 3779 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, fallThru, getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3783 */     checkErrorPacket(resultPacket);
/*      */     
/* 3785 */     return resultPacket;
/*      */   }
/*      */   
/*      */   private void checkErrorPacket(Buffer resultPacket) throws SQLException
/*      */   {
/* 3790 */     int statusCode = resultPacket.readByte();
/*      */     
/*      */ 
/* 3793 */     if (statusCode == -1)
/*      */     {
/* 3795 */       int errno = 2000;
/*      */       
/* 3797 */       if (this.protocolVersion > 9) {
/* 3798 */         errno = resultPacket.readInt();
/*      */         
/* 3800 */         String xOpen = null;
/*      */         
/* 3802 */         String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */         
/* 3804 */         if (serverErrorMessage.charAt(0) == '#')
/*      */         {
/*      */ 
/* 3807 */           if (serverErrorMessage.length() > 6) {
/* 3808 */             xOpen = serverErrorMessage.substring(1, 6);
/* 3809 */             serverErrorMessage = serverErrorMessage.substring(6);
/*      */             
/* 3811 */             if (xOpen.equals("HY000")) {
/* 3812 */               xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */             }
/*      */           } else {
/* 3815 */             xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */           }
/*      */         } else {
/* 3818 */           xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */         }
/*      */         
/* 3821 */         clearInputStream();
/*      */         
/* 3823 */         StringBuilder errorBuf = new StringBuilder();
/*      */         
/* 3825 */         String xOpenErrorMessage = SQLError.get(xOpen);
/*      */         
/* 3827 */         if ((!this.connection.getUseOnlyServerErrorMessages()) && 
/* 3828 */           (xOpenErrorMessage != null)) {
/* 3829 */           errorBuf.append(xOpenErrorMessage);
/* 3830 */           errorBuf.append(Messages.getString("MysqlIO.68"));
/*      */         }
/*      */         
/*      */ 
/* 3834 */         errorBuf.append(serverErrorMessage);
/*      */         
/* 3836 */         if ((!this.connection.getUseOnlyServerErrorMessages()) && 
/* 3837 */           (xOpenErrorMessage != null)) {
/* 3838 */           errorBuf.append("\"");
/*      */         }
/*      */         
/*      */ 
/* 3842 */         appendDeadlockStatusInformation(xOpen, errorBuf);
/*      */         
/* 3844 */         if ((xOpen != null) && (xOpen.startsWith("22"))) {
/* 3845 */           throw new MysqlDataTruncation(errorBuf.toString(), 0, true, false, 0, 0, errno);
/*      */         }
/* 3847 */         throw SQLError.createSQLException(errorBuf.toString(), xOpen, errno, false, getExceptionInterceptor(), this.connection);
/*      */       }
/*      */       
/*      */ 
/* 3851 */       String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/* 3852 */       clearInputStream();
/*      */       
/* 3854 */       if (serverErrorMessage.indexOf(Messages.getString("MysqlIO.70")) != -1) {
/* 3855 */         throw SQLError.createSQLException(SQLError.get("S0022") + ", " + serverErrorMessage, "S0022", -1, false, getExceptionInterceptor(), this.connection);
/*      */       }
/*      */       
/*      */ 
/* 3859 */       StringBuilder errorBuf = new StringBuilder(Messages.getString("MysqlIO.72"));
/* 3860 */       errorBuf.append(serverErrorMessage);
/* 3861 */       errorBuf.append("\"");
/*      */       
/* 3863 */       throw SQLError.createSQLException(SQLError.get("S1000") + ", " + errorBuf.toString(), "S1000", -1, false, getExceptionInterceptor(), this.connection);
/*      */     }
/*      */   }
/*      */   
/*      */   private void appendDeadlockStatusInformation(String xOpen, StringBuilder errorBuf) throws SQLException
/*      */   {
/* 3869 */     if ((this.connection.getIncludeInnodbStatusInDeadlockExceptions()) && (xOpen != null) && ((xOpen.startsWith("40")) || (xOpen.startsWith("41"))) && (this.streamingData == null))
/*      */     {
/* 3871 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 3874 */         rs = sqlQueryDirect(null, "SHOW ENGINE INNODB STATUS", this.connection.getEncoding(), null, -1, 1003, 1007, false, this.connection.getCatalog(), null);
/*      */         
/*      */ 
/* 3877 */         if (rs.next()) {
/* 3878 */           errorBuf.append("\n\n");
/* 3879 */           errorBuf.append(rs.getString("Status"));
/*      */         } else {
/* 3881 */           errorBuf.append("\n\n");
/* 3882 */           errorBuf.append(Messages.getString("MysqlIO.NoInnoDBStatusFound"));
/*      */         }
/*      */       } catch (Exception ex) {
/* 3885 */         errorBuf.append("\n\n");
/* 3886 */         errorBuf.append(Messages.getString("MysqlIO.InnoDBStatusFailed"));
/* 3887 */         errorBuf.append("\n\n");
/* 3888 */         errorBuf.append(Util.stackTraceToString(ex));
/*      */       } finally {
/* 3890 */         if (rs != null) {
/* 3891 */           rs.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3896 */     if (this.connection.getIncludeThreadDumpInDeadlockExceptions()) {
/* 3897 */       errorBuf.append("\n\n*** Java threads running at time of deadlock ***\n\n");
/*      */       
/* 3899 */       ThreadMXBean threadMBean = ManagementFactory.getThreadMXBean();
/* 3900 */       long[] threadIds = threadMBean.getAllThreadIds();
/*      */       
/* 3902 */       ThreadInfo[] threads = threadMBean.getThreadInfo(threadIds, Integer.MAX_VALUE);
/* 3903 */       Object activeThreads = new ArrayList();
/*      */       
/* 3905 */       for (ThreadInfo info : threads) {
/* 3906 */         if (info != null) {
/* 3907 */           ((List)activeThreads).add(info);
/*      */         }
/*      */       }
/*      */       
/* 3911 */       for (ThreadInfo threadInfo : (List)activeThreads)
/*      */       {
/*      */ 
/* 3914 */         errorBuf.append('"');
/* 3915 */         errorBuf.append(threadInfo.getThreadName());
/* 3916 */         errorBuf.append("\" tid=");
/* 3917 */         errorBuf.append(threadInfo.getThreadId());
/* 3918 */         errorBuf.append(" ");
/* 3919 */         errorBuf.append(threadInfo.getThreadState());
/*      */         
/* 3921 */         if (threadInfo.getLockName() != null) {
/* 3922 */           errorBuf.append(" on lock=" + threadInfo.getLockName());
/*      */         }
/* 3924 */         if (threadInfo.isSuspended()) {
/* 3925 */           errorBuf.append(" (suspended)");
/*      */         }
/* 3927 */         if (threadInfo.isInNative()) {
/* 3928 */           errorBuf.append(" (running in native)");
/*      */         }
/*      */         
/* 3931 */         StackTraceElement[] stackTrace = threadInfo.getStackTrace();
/*      */         
/* 3933 */         if (stackTrace.length > 0) {
/* 3934 */           errorBuf.append(" in ");
/* 3935 */           errorBuf.append(stackTrace[0].getClassName());
/* 3936 */           errorBuf.append(".");
/* 3937 */           errorBuf.append(stackTrace[0].getMethodName());
/* 3938 */           errorBuf.append("()");
/*      */         }
/*      */         
/* 3941 */         errorBuf.append("\n");
/*      */         
/* 3943 */         if (threadInfo.getLockOwnerName() != null) {
/* 3944 */           errorBuf.append("\t owned by " + threadInfo.getLockOwnerName() + " Id=" + threadInfo.getLockOwnerId());
/* 3945 */           errorBuf.append("\n");
/*      */         }
/*      */         
/* 3948 */         for (int j = 0; j < stackTrace.length; j++) {
/* 3949 */           StackTraceElement ste = stackTrace[j];
/* 3950 */           errorBuf.append("\tat " + ste.toString());
/* 3951 */           errorBuf.append("\n");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void sendSplitPackets(Buffer packet, int packetLen)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3967 */       Buffer packetToSend = this.splitBufRef == null ? null : (Buffer)this.splitBufRef.get();
/* 3968 */       Buffer toCompress = (!this.useCompression) || (this.compressBufRef == null) ? null : (Buffer)this.compressBufRef.get();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3974 */       if (packetToSend == null) {
/* 3975 */         packetToSend = new Buffer(this.maxThreeBytes + 4);
/* 3976 */         this.splitBufRef = new SoftReference(packetToSend);
/*      */       }
/* 3978 */       if (this.useCompression) {
/* 3979 */         int cbuflen = packetLen + (packetLen / this.maxThreeBytes + 1) * 4;
/* 3980 */         if (toCompress == null) {
/* 3981 */           toCompress = new Buffer(cbuflen);
/* 3982 */         } else if (toCompress.getBufLength() < cbuflen) {
/* 3983 */           toCompress.setPosition(toCompress.getBufLength());
/* 3984 */           toCompress.ensureCapacity(cbuflen - toCompress.getBufLength());
/*      */         }
/*      */       }
/*      */       
/* 3988 */       int len = packetLen - 4;
/* 3989 */       int splitSize = this.maxThreeBytes;
/* 3990 */       int originalPacketPos = 4;
/* 3991 */       byte[] origPacketBytes = packet.getByteBuffer();
/*      */       
/* 3993 */       int toCompressPosition = 0;
/*      */       
/*      */ 
/* 3996 */       while (len >= 0) {
/* 3997 */         this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */         
/* 3999 */         if (len < splitSize) {
/* 4000 */           splitSize = len;
/*      */         }
/*      */         
/* 4003 */         packetToSend.setPosition(0);
/* 4004 */         packetToSend.writeLongInt(splitSize);
/* 4005 */         packetToSend.writeByte(this.packetSequence);
/* 4006 */         if (len > 0) {
/* 4007 */           System.arraycopy(origPacketBytes, originalPacketPos, packetToSend.getByteBuffer(), 4, splitSize);
/*      */         }
/*      */         
/* 4010 */         if (this.useCompression) {
/* 4011 */           System.arraycopy(packetToSend.getByteBuffer(), 0, toCompress.getByteBuffer(), toCompressPosition, 4 + splitSize);
/* 4012 */           toCompressPosition += 4 + splitSize;
/*      */         } else {
/* 4014 */           this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, 4 + splitSize);
/* 4015 */           this.mysqlOutput.flush();
/*      */         }
/*      */         
/* 4018 */         originalPacketPos += splitSize;
/* 4019 */         len -= this.maxThreeBytes;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4024 */       if (this.useCompression) {
/* 4025 */         len = toCompressPosition;
/* 4026 */         toCompressPosition = 0;
/* 4027 */         splitSize = this.maxThreeBytes - 3;
/* 4028 */         while (len >= 0) {
/* 4029 */           this.compressedPacketSequence = ((byte)(this.compressedPacketSequence + 1));
/*      */           
/* 4031 */           if (len < splitSize) {
/* 4032 */             splitSize = len;
/*      */           }
/*      */           
/* 4035 */           Buffer compressedPacketToSend = compressPacket(toCompress, toCompressPosition, splitSize);
/* 4036 */           packetLen = compressedPacketToSend.getPosition();
/* 4037 */           this.mysqlOutput.write(compressedPacketToSend.getByteBuffer(), 0, packetLen);
/* 4038 */           this.mysqlOutput.flush();
/*      */           
/* 4040 */           toCompressPosition += splitSize;
/* 4041 */           len -= this.maxThreeBytes - 3;
/*      */         }
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 4045 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   private void reclaimLargeSharedSendPacket()
/*      */   {
/* 4051 */     if ((this.sharedSendPacket != null) && (this.sharedSendPacket.getCapacity() > 1048576)) {
/* 4052 */       this.sharedSendPacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean hadWarnings() {
/* 4057 */     return this.hadWarnings;
/*      */   }
/*      */   
/*      */   void scanForAndThrowDataTruncation() throws SQLException {
/* 4061 */     if ((this.streamingData == null) && (versionMeetsMinimum(4, 1, 0)) && (this.connection.getJdbcCompliantTruncation()) && (this.warningCount > 0)) {
/* 4062 */       SQLError.convertShowWarningsToSQLWarnings(this.connection, this.warningCount, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void secureAuth(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams)
/*      */     throws SQLException
/*      */   {
/* 4080 */     if (packet == null) {
/* 4081 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 4084 */     if (writeClientParams) {
/* 4085 */       if (this.use41Extensions) {
/* 4086 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 4087 */           packet.writeLong(this.clientParam);
/* 4088 */           packet.writeLong(this.maxThreeBytes);
/*      */           
/*      */ 
/* 4091 */           packet.writeByte((byte)8);
/*      */           
/*      */ 
/* 4094 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 4096 */           packet.writeLong(this.clientParam);
/* 4097 */           packet.writeLong(this.maxThreeBytes);
/*      */         }
/*      */       } else {
/* 4100 */         packet.writeInt((int)this.clientParam);
/* 4101 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4106 */     packet.writeString(user, "Cp1252", this.connection);
/*      */     
/* 4108 */     if (password.length() != 0)
/*      */     {
/* 4110 */       packet.writeString("xxxxxxxx", "Cp1252", this.connection);
/*      */     }
/*      */     else {
/* 4113 */       packet.writeString("", "Cp1252", this.connection);
/*      */     }
/*      */     
/* 4116 */     if (this.useConnectWithDb) {
/* 4117 */       packet.writeString(database, "Cp1252", this.connection);
/*      */     }
/*      */     
/* 4120 */     send(packet, packet.getPosition());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4125 */     if (password.length() > 0) {
/* 4126 */       Buffer b = readPacket();
/*      */       
/* 4128 */       b.setPosition(0);
/*      */       
/* 4130 */       byte[] replyAsBytes = b.getByteBuffer();
/*      */       
/* 4132 */       if ((replyAsBytes.length == 25) && (replyAsBytes[0] != 0))
/*      */       {
/* 4134 */         if (replyAsBytes[0] != 42) {
/*      */           try
/*      */           {
/* 4137 */             byte[] buff = Security.passwordHashStage1(password);
/*      */             
/*      */ 
/* 4140 */             byte[] passwordHash = new byte[buff.length];
/* 4141 */             System.arraycopy(buff, 0, passwordHash, 0, buff.length);
/*      */             
/*      */ 
/* 4144 */             passwordHash = Security.passwordHashStage2(passwordHash, replyAsBytes);
/*      */             
/* 4146 */             byte[] packetDataAfterSalt = new byte[replyAsBytes.length - 5];
/*      */             
/* 4148 */             System.arraycopy(replyAsBytes, 4, packetDataAfterSalt, 0, replyAsBytes.length - 5);
/*      */             
/* 4150 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */             
/*      */ 
/* 4153 */             Security.xorString(packetDataAfterSalt, mysqlScrambleBuff, passwordHash, 20);
/*      */             
/*      */ 
/* 4156 */             Security.xorString(mysqlScrambleBuff, buff, buff, 20);
/*      */             
/* 4158 */             Buffer packet2 = new Buffer(25);
/* 4159 */             packet2.writeBytesNoNull(buff);
/*      */             
/* 4161 */             this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */             
/* 4163 */             send(packet2, 24);
/*      */           } catch (NoSuchAlgorithmException nse) {
/* 4165 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */         } else {
/*      */           try
/*      */           {
/* 4171 */             byte[] passwordHash = Security.createKeyFromOldPassword(password);
/*      */             
/*      */ 
/* 4174 */             byte[] netReadPos4 = new byte[replyAsBytes.length - 5];
/*      */             
/* 4176 */             System.arraycopy(replyAsBytes, 4, netReadPos4, 0, replyAsBytes.length - 5);
/*      */             
/* 4178 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */             
/*      */ 
/* 4181 */             Security.xorString(netReadPos4, mysqlScrambleBuff, passwordHash, 20);
/*      */             
/*      */ 
/* 4184 */             String scrambledPassword = Util.scramble(StringUtils.toString(mysqlScrambleBuff), password);
/*      */             
/* 4186 */             Buffer packet2 = new Buffer(packLength);
/* 4187 */             packet2.writeString(scrambledPassword, "Cp1252", this.connection);
/* 4188 */             this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */             
/* 4190 */             send(packet2, 24);
/*      */           } catch (NoSuchAlgorithmException nse) {
/* 4192 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void secureAuth411(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams)
/*      */     throws SQLException
/*      */   {
/* 4213 */     String enc = getEncodingForHandshake();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4232 */     if (packet == null) {
/* 4233 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 4236 */     if (writeClientParams) {
/* 4237 */       if (this.use41Extensions) {
/* 4238 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 4239 */           packet.writeLong(this.clientParam);
/* 4240 */           packet.writeLong(this.maxThreeBytes);
/*      */           
/* 4242 */           appendCharsetByteForHandshake(packet, enc);
/*      */           
/*      */ 
/* 4245 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 4247 */           packet.writeLong(this.clientParam);
/* 4248 */           packet.writeLong(this.maxThreeBytes);
/*      */         }
/*      */       } else {
/* 4251 */         packet.writeInt((int)this.clientParam);
/* 4252 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4257 */     packet.writeString(user, enc, this.connection);
/*      */     
/* 4259 */     if (password.length() != 0) {
/* 4260 */       packet.writeByte((byte)20);
/*      */       try
/*      */       {
/* 4263 */         packet.writeBytesNoNull(Security.scramble411(password, this.seed, this.connection.getPasswordCharacterEncoding()));
/*      */       } catch (NoSuchAlgorithmException nse) {
/* 4265 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */       catch (UnsupportedEncodingException e) {
/* 4268 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 4273 */       packet.writeByte((byte)0);
/*      */     }
/*      */     
/* 4276 */     if (this.useConnectWithDb) {
/* 4277 */       packet.writeString(database, enc, this.connection);
/*      */     }
/*      */     else {
/* 4280 */       packet.writeByte((byte)0);
/*      */     }
/*      */     
/*      */ 
/* 4284 */     if ((this.serverCapabilities & 0x100000) != 0) {
/* 4285 */       sendConnectionAttributes(packet, enc, this.connection);
/*      */     }
/*      */     
/* 4288 */     send(packet, packet.getPosition());
/*      */     
/* 4290 */     byte savePacketSequence = this.packetSequence++;
/*      */     
/* 4292 */     Buffer reply = checkErrorPacket();
/*      */     
/* 4294 */     if (reply.isLastDataPacket())
/*      */     {
/*      */ 
/*      */ 
/* 4298 */       savePacketSequence = (byte)(savePacketSequence + 1);this.packetSequence = savePacketSequence;
/* 4299 */       packet.clear();
/*      */       
/* 4301 */       String seed323 = this.seed.substring(0, 8);
/* 4302 */       packet.writeString(Util.newCrypt(password, seed323, this.connection.getPasswordCharacterEncoding()));
/* 4303 */       send(packet, packet.getPosition());
/*      */       
/*      */ 
/* 4306 */       checkErrorPacket();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ResultSetRow unpackBinaryResultSetRow(Field[] fields, Buffer binaryData, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4322 */     int numFields = fields.length;
/*      */     
/* 4324 */     byte[][] unpackedRowData = new byte[numFields][];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4330 */     int nullCount = (numFields + 9) / 8;
/* 4331 */     int nullMaskPos = binaryData.getPosition();
/* 4332 */     binaryData.setPosition(nullMaskPos + nullCount);
/* 4333 */     int bit = 4;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4339 */     for (int i = 0; i < numFields; i++) {
/* 4340 */       if ((binaryData.readByte(nullMaskPos) & bit) != 0) {
/* 4341 */         unpackedRowData[i] = null;
/*      */       }
/* 4343 */       else if (resultSetConcurrency != 1008) {
/* 4344 */         extractNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       } else {
/* 4346 */         unpackNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       }
/*      */       
/*      */ 
/* 4350 */       if ((bit <<= 1 & 0xFF) == 0) {
/* 4351 */         bit = 1;
/*      */         
/* 4353 */         nullMaskPos++;
/*      */       }
/*      */     }
/*      */     
/* 4357 */     return new ByteArrayRow(unpackedRowData, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   private final void extractNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData) throws SQLException {
/* 4361 */     Field curField = fields[columnIndex];
/*      */     int length;
/* 4363 */     switch (curField.getMysqlType())
/*      */     {
/*      */     case 6: 
/*      */       break;
/*      */     
/*      */     case 1: 
/* 4369 */       unpackedRowData[columnIndex] = { binaryData.readByte() };
/* 4370 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 13: 
/* 4375 */       unpackedRowData[columnIndex] = binaryData.getBytes(2);
/* 4376 */       break;
/*      */     
/*      */     case 3: 
/*      */     case 9: 
/* 4380 */       unpackedRowData[columnIndex] = binaryData.getBytes(4);
/* 4381 */       break;
/*      */     
/*      */     case 8: 
/* 4384 */       unpackedRowData[columnIndex] = binaryData.getBytes(8);
/* 4385 */       break;
/*      */     
/*      */     case 4: 
/* 4388 */       unpackedRowData[columnIndex] = binaryData.getBytes(4);
/* 4389 */       break;
/*      */     
/*      */     case 5: 
/* 4392 */       unpackedRowData[columnIndex] = binaryData.getBytes(8);
/* 4393 */       break;
/*      */     
/*      */     case 11: 
/* 4396 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4398 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */       
/* 4400 */       break;
/*      */     
/*      */     case 10: 
/* 4403 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4405 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */       
/* 4407 */       break;
/*      */     case 7: 
/*      */     case 12: 
/* 4410 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4412 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/* 4413 */       break;
/*      */     case 0: 
/*      */     case 15: 
/*      */     case 246: 
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/*      */     case 253: 
/*      */     case 254: 
/*      */     case 255: 
/* 4424 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */       
/* 4426 */       break;
/*      */     case 16: 
/* 4428 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */       
/* 4430 */       break;
/*      */     default: 
/* 4432 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   private final void unpackNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData)
/*      */     throws SQLException
/*      */   {
/* 4439 */     Field curField = fields[columnIndex];
/*      */     int length;
/* 4441 */     int hour; int minute; int seconds; int year; int month; int day; int after1000; int after100; switch (curField.getMysqlType())
/*      */     {
/*      */     case 6: 
/*      */       break;
/*      */     
/*      */     case 1: 
/* 4447 */       byte tinyVal = binaryData.readByte();
/*      */       
/* 4449 */       if (!curField.isUnsigned()) {
/* 4450 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(tinyVal));
/*      */       } else {
/* 4452 */         short unsignedTinyVal = (short)(tinyVal & 0xFF);
/*      */         
/* 4454 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(unsignedTinyVal));
/*      */       }
/*      */       
/* 4457 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 13: 
/* 4462 */       short shortVal = (short)binaryData.readInt();
/*      */       
/* 4464 */       if (!curField.isUnsigned()) {
/* 4465 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(shortVal));
/*      */       } else {
/* 4467 */         int unsignedShortVal = shortVal & 0xFFFF;
/*      */         
/* 4469 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(unsignedShortVal));
/*      */       }
/*      */       
/* 4472 */       break;
/*      */     
/*      */ 
/*      */     case 3: 
/*      */     case 9: 
/* 4477 */       int intVal = (int)binaryData.readLong();
/*      */       
/* 4479 */       if (!curField.isUnsigned()) {
/* 4480 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(intVal));
/*      */       } else {
/* 4482 */         long longVal = intVal & 0xFFFFFFFF;
/*      */         
/* 4484 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(longVal));
/*      */       }
/*      */       
/* 4487 */       break;
/*      */     
/*      */ 
/*      */     case 8: 
/* 4491 */       long longVal = binaryData.readLongLong();
/*      */       
/* 4493 */       if (!curField.isUnsigned()) {
/* 4494 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(longVal));
/*      */       } else {
/* 4496 */         BigInteger asBigInteger = ResultSetImpl.convertLongToUlong(longVal);
/*      */         
/* 4498 */         unpackedRowData[columnIndex] = StringUtils.getBytes(asBigInteger.toString());
/*      */       }
/*      */       
/* 4501 */       break;
/*      */     
/*      */ 
/*      */     case 4: 
/* 4505 */       float floatVal = Float.intBitsToFloat(binaryData.readIntAsLong());
/*      */       
/* 4507 */       unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(floatVal));
/*      */       
/* 4509 */       break;
/*      */     
/*      */ 
/*      */     case 5: 
/* 4513 */       double doubleVal = Double.longBitsToDouble(binaryData.readLongLong());
/*      */       
/* 4515 */       unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(doubleVal));
/*      */       
/* 4517 */       break;
/*      */     
/*      */ 
/*      */     case 11: 
/* 4521 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4523 */       hour = 0;
/* 4524 */       minute = 0;
/* 4525 */       seconds = 0;
/*      */       
/* 4527 */       if (length != 0) {
/* 4528 */         binaryData.readByte();
/* 4529 */         binaryData.readLong();
/* 4530 */         hour = binaryData.readByte();
/* 4531 */         minute = binaryData.readByte();
/* 4532 */         seconds = binaryData.readByte();
/*      */         
/* 4534 */         if (length > 8) {
/* 4535 */           binaryData.readLong();
/*      */         }
/*      */       }
/*      */       
/* 4539 */       byte[] timeAsBytes = new byte[8];
/*      */       
/* 4541 */       timeAsBytes[0] = ((byte)Character.forDigit(hour / 10, 10));
/* 4542 */       timeAsBytes[1] = ((byte)Character.forDigit(hour % 10, 10));
/*      */       
/* 4544 */       timeAsBytes[2] = 58;
/*      */       
/* 4546 */       timeAsBytes[3] = ((byte)Character.forDigit(minute / 10, 10));
/* 4547 */       timeAsBytes[4] = ((byte)Character.forDigit(minute % 10, 10));
/*      */       
/* 4549 */       timeAsBytes[5] = 58;
/*      */       
/* 4551 */       timeAsBytes[6] = ((byte)Character.forDigit(seconds / 10, 10));
/* 4552 */       timeAsBytes[7] = ((byte)Character.forDigit(seconds % 10, 10));
/*      */       
/* 4554 */       unpackedRowData[columnIndex] = timeAsBytes;
/*      */       
/* 4556 */       break;
/*      */     
/*      */     case 10: 
/* 4559 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4561 */       year = 0;
/* 4562 */       month = 0;
/* 4563 */       day = 0;
/*      */       
/* 4565 */       hour = 0;
/* 4566 */       minute = 0;
/* 4567 */       seconds = 0;
/*      */       
/* 4569 */       if (length != 0) {
/* 4570 */         year = binaryData.readInt();
/* 4571 */         month = binaryData.readByte();
/* 4572 */         day = binaryData.readByte();
/*      */       }
/*      */       
/* 4575 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 4576 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 4577 */           unpackedRowData[columnIndex] = null;
/*      */         }
/*      */         else {
/* 4580 */           if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 4581 */             throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 4585 */           year = 1;
/* 4586 */           month = 1;
/* 4587 */           day = 1;
/*      */         }
/*      */       } else {
/* 4590 */         byte[] dateAsBytes = new byte[10];
/*      */         
/* 4592 */         dateAsBytes[0] = ((byte)Character.forDigit(year / 1000, 10));
/*      */         
/* 4594 */         after1000 = year % 1000;
/*      */         
/* 4596 */         dateAsBytes[1] = ((byte)Character.forDigit(after1000 / 100, 10));
/*      */         
/* 4598 */         after100 = after1000 % 100;
/*      */         
/* 4600 */         dateAsBytes[2] = ((byte)Character.forDigit(after100 / 10, 10));
/* 4601 */         dateAsBytes[3] = ((byte)Character.forDigit(after100 % 10, 10));
/*      */         
/* 4603 */         dateAsBytes[4] = 45;
/*      */         
/* 4605 */         dateAsBytes[5] = ((byte)Character.forDigit(month / 10, 10));
/* 4606 */         dateAsBytes[6] = ((byte)Character.forDigit(month % 10, 10));
/*      */         
/* 4608 */         dateAsBytes[7] = 45;
/*      */         
/* 4610 */         dateAsBytes[8] = ((byte)Character.forDigit(day / 10, 10));
/* 4611 */         dateAsBytes[9] = ((byte)Character.forDigit(day % 10, 10));
/*      */         
/* 4613 */         unpackedRowData[columnIndex] = dateAsBytes;
/*      */       }
/* 4615 */       break;
/*      */     
/*      */     case 7: 
/*      */     case 12: 
/* 4619 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4621 */       year = 0;
/* 4622 */       month = 0;
/* 4623 */       day = 0;
/*      */       
/* 4625 */       hour = 0;
/* 4626 */       minute = 0;
/* 4627 */       seconds = 0;
/*      */       
/* 4629 */       int nanos = 0;
/*      */       
/* 4631 */       if (length != 0) {
/* 4632 */         year = binaryData.readInt();
/* 4633 */         month = binaryData.readByte();
/* 4634 */         day = binaryData.readByte();
/*      */         
/* 4636 */         if (length > 4) {
/* 4637 */           hour = binaryData.readByte();
/* 4638 */           minute = binaryData.readByte();
/* 4639 */           seconds = binaryData.readByte();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4647 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 4648 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 4649 */           unpackedRowData[columnIndex] = null;
/*      */         }
/*      */         else {
/* 4652 */           if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 4653 */             throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 4657 */           year = 1;
/* 4658 */           month = 1;
/* 4659 */           day = 1;
/*      */         }
/*      */       } else {
/* 4662 */         int stringLength = 19;
/*      */         
/* 4664 */         byte[] nanosAsBytes = StringUtils.getBytes(Integer.toString(nanos));
/*      */         
/* 4666 */         stringLength += 1 + nanosAsBytes.length;
/*      */         
/* 4668 */         byte[] datetimeAsBytes = new byte[stringLength];
/*      */         
/* 4670 */         datetimeAsBytes[0] = ((byte)Character.forDigit(year / 1000, 10));
/*      */         
/* 4672 */         after1000 = year % 1000;
/*      */         
/* 4674 */         datetimeAsBytes[1] = ((byte)Character.forDigit(after1000 / 100, 10));
/*      */         
/* 4676 */         after100 = after1000 % 100;
/*      */         
/* 4678 */         datetimeAsBytes[2] = ((byte)Character.forDigit(after100 / 10, 10));
/* 4679 */         datetimeAsBytes[3] = ((byte)Character.forDigit(after100 % 10, 10));
/*      */         
/* 4681 */         datetimeAsBytes[4] = 45;
/*      */         
/* 4683 */         datetimeAsBytes[5] = ((byte)Character.forDigit(month / 10, 10));
/* 4684 */         datetimeAsBytes[6] = ((byte)Character.forDigit(month % 10, 10));
/*      */         
/* 4686 */         datetimeAsBytes[7] = 45;
/*      */         
/* 4688 */         datetimeAsBytes[8] = ((byte)Character.forDigit(day / 10, 10));
/* 4689 */         datetimeAsBytes[9] = ((byte)Character.forDigit(day % 10, 10));
/*      */         
/* 4691 */         datetimeAsBytes[10] = 32;
/*      */         
/* 4693 */         datetimeAsBytes[11] = ((byte)Character.forDigit(hour / 10, 10));
/* 4694 */         datetimeAsBytes[12] = ((byte)Character.forDigit(hour % 10, 10));
/*      */         
/* 4696 */         datetimeAsBytes[13] = 58;
/*      */         
/* 4698 */         datetimeAsBytes[14] = ((byte)Character.forDigit(minute / 10, 10));
/* 4699 */         datetimeAsBytes[15] = ((byte)Character.forDigit(minute % 10, 10));
/*      */         
/* 4701 */         datetimeAsBytes[16] = 58;
/*      */         
/* 4703 */         datetimeAsBytes[17] = ((byte)Character.forDigit(seconds / 10, 10));
/* 4704 */         datetimeAsBytes[18] = ((byte)Character.forDigit(seconds % 10, 10));
/*      */         
/* 4706 */         datetimeAsBytes[19] = 46;
/*      */         
/* 4708 */         int nanosOffset = 20;
/*      */         
/* 4710 */         System.arraycopy(nanosAsBytes, 0, datetimeAsBytes, 20, nanosAsBytes.length);
/*      */         
/* 4712 */         unpackedRowData[columnIndex] = datetimeAsBytes;
/*      */       }
/* 4714 */       break;
/*      */     
/*      */     case 0: 
/*      */     case 15: 
/*      */     case 16: 
/*      */     case 246: 
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/*      */     case 253: 
/*      */     case 254: 
/* 4726 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */       
/* 4728 */       break;
/*      */     
/*      */     default: 
/* 4731 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void negotiateSSLConnection(String user, String password, String database, int packLength)
/*      */     throws SQLException
/*      */   {
/* 4749 */     if (!ExportControlled.enabled()) {
/* 4750 */       throw new ConnectionFeatureNotAvailableException(this.connection, this.lastPacketSentTimeMs, null);
/*      */     }
/*      */     
/* 4753 */     if ((this.serverCapabilities & 0x8000) != 0) {
/* 4754 */       this.clientParam |= 0x8000;
/*      */     }
/*      */     
/* 4757 */     this.clientParam |= 0x800;
/*      */     
/* 4759 */     Buffer packet = new Buffer(packLength);
/*      */     
/* 4761 */     if (this.use41Extensions) {
/* 4762 */       packet.writeLong(this.clientParam);
/* 4763 */       packet.writeLong(this.maxThreeBytes);
/* 4764 */       appendCharsetByteForHandshake(packet, getEncodingForHandshake());
/* 4765 */       packet.writeBytesNoNull(new byte[23]);
/*      */     } else {
/* 4767 */       packet.writeInt((int)this.clientParam);
/*      */     }
/*      */     
/* 4770 */     send(packet, packet.getPosition());
/*      */     
/* 4772 */     ExportControlled.transformSocketToSSLSocket(this);
/*      */   }
/*      */   
/*      */   public boolean isSSLEstablished() {
/* 4776 */     return (ExportControlled.enabled()) && (ExportControlled.isSSLEstablished(this));
/*      */   }
/*      */   
/*      */   protected int getServerStatus() {
/* 4780 */     return this.serverStatus;
/*      */   }
/*      */   
/*      */   protected List<ResultSetRow> fetchRowsViaCursor(List<ResultSetRow> fetchedRows, long statementId, Field[] columnTypes, int fetchSize, boolean useBufferRowExplicit)
/*      */     throws SQLException
/*      */   {
/* 4786 */     if (fetchedRows == null) {
/* 4787 */       fetchedRows = new ArrayList(fetchSize);
/*      */     } else {
/* 4789 */       fetchedRows.clear();
/*      */     }
/*      */     
/* 4792 */     this.sharedSendPacket.clear();
/*      */     
/* 4794 */     this.sharedSendPacket.writeByte((byte)28);
/* 4795 */     this.sharedSendPacket.writeLong(statementId);
/* 4796 */     this.sharedSendPacket.writeLong(fetchSize);
/*      */     
/* 4798 */     sendCommand(28, null, this.sharedSendPacket, true, null, 0);
/*      */     
/* 4800 */     ResultSetRow row = null;
/*      */     
/* 4802 */     while ((row = nextRow(columnTypes, columnTypes.length, true, 1007, false, useBufferRowExplicit, false, null)) != null) {
/* 4803 */       fetchedRows.add(row);
/*      */     }
/*      */     
/* 4806 */     return fetchedRows;
/*      */   }
/*      */   
/*      */   protected long getThreadId() {
/* 4810 */     return this.threadId;
/*      */   }
/*      */   
/*      */   protected boolean useNanosForElapsedTime() {
/* 4814 */     return this.useNanosForElapsedTime;
/*      */   }
/*      */   
/*      */   protected long getSlowQueryThreshold() {
/* 4818 */     return this.slowQueryThreshold;
/*      */   }
/*      */   
/*      */   protected String getQueryTimingUnits() {
/* 4822 */     return this.queryTimingUnits;
/*      */   }
/*      */   
/*      */   protected int getCommandCount() {
/* 4826 */     return this.commandCount;
/*      */   }
/*      */   
/*      */   private void checkTransactionState(int oldStatus) throws SQLException {
/* 4830 */     boolean previouslyInTrans = (oldStatus & 0x1) != 0;
/* 4831 */     boolean currentlyInTrans = (this.serverStatus & 0x1) != 0;
/*      */     
/* 4833 */     if ((previouslyInTrans) && (!currentlyInTrans)) {
/* 4834 */       this.connection.transactionCompleted();
/* 4835 */     } else if ((!previouslyInTrans) && (currentlyInTrans)) {
/* 4836 */       this.connection.transactionBegun();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setStatementInterceptors(List<StatementInterceptorV2> statementInterceptors) {
/* 4841 */     this.statementInterceptors = (statementInterceptors.isEmpty() ? null : statementInterceptors);
/*      */   }
/*      */   
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 4845 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   protected void setSocketTimeout(int milliseconds) throws SQLException {
/*      */     try {
/* 4850 */       this.mysqlConnection.setSoTimeout(milliseconds);
/*      */     } catch (SocketException e) {
/* 4852 */       SQLException sqlEx = SQLError.createSQLException("Invalid socket timeout value or state", "S1009", getExceptionInterceptor());
/*      */       
/* 4854 */       sqlEx.initCause(e);
/*      */       
/* 4856 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void releaseResources() {
/* 4861 */     if (this.deflater != null) {
/* 4862 */       this.deflater.end();
/* 4863 */       this.deflater = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   String getEncodingForHandshake()
/*      */   {
/* 4872 */     String enc = this.connection.getEncoding();
/* 4873 */     if (enc == null) {
/* 4874 */       enc = "UTF-8";
/*      */     }
/* 4876 */     return enc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void appendCharsetByteForHandshake(Buffer packet, String enc)
/*      */     throws SQLException
/*      */   {
/* 4896 */     int charsetIndex = 0;
/* 4897 */     if (enc != null) {
/* 4898 */       charsetIndex = CharsetMapping.getCollationIndexForJavaEncoding(enc, this.connection);
/*      */     }
/* 4900 */     if (charsetIndex == 0) {
/* 4901 */       charsetIndex = 33;
/*      */     }
/* 4903 */     if (charsetIndex > 255) {
/* 4904 */       throw SQLError.createSQLException("Invalid character set index for encoding: " + enc, "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 4907 */     packet.writeByte((byte)charsetIndex);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/MysqlIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */