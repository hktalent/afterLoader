/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadBalancedMySQLConnection
/*    */   extends MultiHostMySQLConnection
/*    */   implements LoadBalancedConnection
/*    */ {
/*    */   public LoadBalancedMySQLConnection(LoadBalancingConnectionProxy proxy)
/*    */   {
/* 31 */     super(proxy);
/*    */   }
/*    */   
/*    */   public LoadBalancingConnectionProxy getProxy()
/*    */   {
/* 36 */     return (LoadBalancingConnectionProxy)super.getProxy();
/*    */   }
/*    */   
/*    */   public void ping() throws SQLException
/*    */   {
/* 41 */     ping(true);
/*    */   }
/*    */   
/*    */   public void ping(boolean allConnections) throws SQLException {
/* 45 */     if (allConnections) {
/* 46 */       getProxy().doPing();
/*    */     } else {
/* 48 */       getActiveMySQLConnection().ping();
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean addHost(String host) throws SQLException {
/* 53 */     return getProxy().addHost(host);
/*    */   }
/*    */   
/*    */   public void removeHost(String host) throws SQLException {
/* 57 */     getProxy().removeHost(host);
/*    */   }
/*    */   
/*    */   public void removeHostWhenNotInUse(String host) throws SQLException {
/* 61 */     getProxy().removeHostWhenNotInUse(host);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/LoadBalancedMySQLConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */