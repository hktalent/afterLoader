/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.log.Log;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FailoverConnectionProxy
/*     */   extends MultiHostConnectionProxy
/*     */ {
/*     */   private static final String METHOD_SET_READ_ONLY = "setReadOnly";
/*     */   private static final String METHOD_SET_AUTO_COMMIT = "setAutoCommit";
/*     */   private static final String METHOD_COMMIT = "commit";
/*     */   private static final String METHOD_ROLLBACK = "rollback";
/*     */   private static final int NO_CONNECTION_INDEX = -1;
/*     */   private static final int DEFAULT_PRIMARY_HOST_INDEX = 0;
/*     */   private int secondsBeforeRetryPrimaryHost;
/*     */   private long queriesBeforeRetryPrimaryHost;
/*     */   private boolean failoverReadOnly;
/*     */   private int retriesAllDown;
/*  52 */   private int currentHostIndex = -1;
/*  53 */   private int primaryHostIndex = 0;
/*  54 */   private Boolean explicitlyReadOnly = null;
/*  55 */   private boolean explicitlyAutoCommit = true;
/*     */   
/*  57 */   private boolean enableFallBackToPrimaryHost = true;
/*  58 */   private long primaryHostFailTimeMillis = 0L;
/*  59 */   private long queriesIssuedSinceFailover = 0L;
/*     */   
/*     */ 
/*     */   class FailoverJdbcInterfaceProxy
/*     */     extends MultiHostConnectionProxy.JdbcInterfaceProxy
/*     */   {
/*     */     FailoverJdbcInterfaceProxy(Object toInvokeOn)
/*     */     {
/*  67 */       super(toInvokeOn);
/*     */     }
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws Throwable
/*     */     {
/*  73 */       String methodName = method.getName();
/*     */       
/*  75 */       boolean isExecute = methodName.startsWith("execute");
/*     */       
/*  77 */       if ((FailoverConnectionProxy.this.connectedToSecondaryHost()) && (isExecute)) {
/*  78 */         FailoverConnectionProxy.this.incrementQueriesIssuedSinceFailover();
/*     */       }
/*     */       
/*  81 */       Object result = super.invoke(proxy, method, args);
/*     */       
/*  83 */       if ((FailoverConnectionProxy.this.explicitlyAutoCommit) && (isExecute) && (FailoverConnectionProxy.this.readyToFallBackToPrimaryHost()))
/*     */       {
/*  85 */         FailoverConnectionProxy.this.fallBackToPrimaryIfAvailable();
/*     */       }
/*     */       
/*  88 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FailoverConnectionProxy(List<String> hosts, Properties props)
/*     */     throws SQLException
/*     */   {
/* 101 */     super(hosts, props);
/*     */     
/* 103 */     ConnectionPropertiesImpl connProps = new ConnectionPropertiesImpl();
/* 104 */     connProps.initializeProperties(props);
/*     */     
/* 106 */     this.secondsBeforeRetryPrimaryHost = connProps.getSecondsBeforeRetryMaster();
/* 107 */     this.queriesBeforeRetryPrimaryHost = connProps.getQueriesBeforeRetryMaster();
/* 108 */     this.failoverReadOnly = connProps.getFailOverReadOnly();
/* 109 */     this.retriesAllDown = connProps.getRetriesAllDown();
/*     */     
/* 111 */     this.enableFallBackToPrimaryHost = ((this.secondsBeforeRetryPrimaryHost > 0) || (this.queriesBeforeRetryPrimaryHost > 0L));
/*     */     
/* 113 */     pickNewConnection();
/*     */     
/* 115 */     this.explicitlyAutoCommit = this.currentConnection.getAutoCommit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MultiHostConnectionProxy.JdbcInterfaceProxy getNewJdbcInterfaceProxy(Object toProxy)
/*     */   {
/* 125 */     return new FailoverJdbcInterfaceProxy(toProxy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean shouldExceptionTriggerConnectionSwitch(Throwable t)
/*     */   {
/* 135 */     if (!(t instanceof SQLException)) {
/* 136 */       return false;
/*     */     }
/*     */     
/* 139 */     String sqlState = ((SQLException)t).getSQLState();
/* 140 */     if ((sqlState != null) && 
/* 141 */       (sqlState.startsWith("08")))
/*     */     {
/* 143 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 148 */     if ((t instanceof CommunicationsException)) {
/* 149 */       return true;
/*     */     }
/*     */     
/* 152 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void pickNewConnection()
/*     */     throws SQLException
/*     */   {
/* 162 */     if ((this.isClosed) && (this.closedExplicitly)) {
/* 163 */       return;
/*     */     }
/*     */     
/* 166 */     if ((!isConnected()) || (readyToFallBackToPrimaryHost())) {
/*     */       try {
/* 168 */         connectTo(this.primaryHostIndex);
/*     */       } catch (SQLException e) {
/* 170 */         resetAutoFallBackCounters();
/* 171 */         failOver(this.primaryHostIndex);
/*     */       }
/*     */     } else {
/* 174 */       failOver();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized ConnectionImpl createConnectionForHostIndex(int hostIndex)
/*     */     throws SQLException
/*     */   {
/* 187 */     return createConnectionForHost((String)this.hostList.get(hostIndex));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void connectTo(int hostIndex)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 198 */       switchCurrentConnectionTo(hostIndex, createConnectionForHostIndex(hostIndex));
/*     */     } catch (SQLException e) {
/* 200 */       if (this.currentConnection != null) {
/* 201 */         StringBuilder msg = new StringBuilder("Connection to ").append(isPrimaryHostIndex(hostIndex) ? "primary" : "secondary").append(" host '").append((String)this.hostList.get(hostIndex)).append("' failed");
/*     */         
/* 203 */         this.currentConnection.getLog().logWarn(msg.toString(), e);
/*     */       }
/* 205 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void switchCurrentConnectionTo(int hostIndex, MySQLConnection connection)
/*     */     throws SQLException
/*     */   {
/* 218 */     invalidateCurrentConnection();
/*     */     boolean readOnly;
/*     */     boolean readOnly;
/* 221 */     if (isPrimaryHostIndex(hostIndex)) {
/* 222 */       readOnly = this.explicitlyReadOnly == null ? false : this.explicitlyReadOnly.booleanValue(); } else { boolean readOnly;
/* 223 */       if (this.failoverReadOnly) {
/* 224 */         readOnly = true; } else { boolean readOnly;
/* 225 */         if (this.explicitlyReadOnly != null) {
/* 226 */           readOnly = this.explicitlyReadOnly.booleanValue(); } else { boolean readOnly;
/* 227 */           if (this.currentConnection != null) {
/* 228 */             readOnly = this.currentConnection.isReadOnly();
/*     */           } else
/* 230 */             readOnly = false;
/*     */         } } }
/* 232 */     syncSessionState(this.currentConnection, connection, readOnly);
/* 233 */     this.currentConnection = connection;
/* 234 */     this.currentHostIndex = hostIndex;
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized void failOver()
/*     */     throws SQLException
/*     */   {
/* 241 */     failOver(this.currentHostIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void failOver(int failedHostIdx)
/*     */     throws SQLException
/*     */   {
/* 252 */     int prevHostIndex = this.currentHostIndex;
/* 253 */     int nextHostIndex = nextHost(failedHostIdx, false);
/* 254 */     int firstHostIndexTried = nextHostIndex;
/*     */     
/* 256 */     SQLException lastExceptionCaught = null;
/* 257 */     int attempts = 0;
/* 258 */     boolean gotConnection = false;
/* 259 */     boolean firstConnOrPassedByPrimaryHost = (prevHostIndex == -1) || (isPrimaryHostIndex(prevHostIndex));
/*     */     do {
/*     */       try {
/* 262 */         firstConnOrPassedByPrimaryHost = (firstConnOrPassedByPrimaryHost) || (isPrimaryHostIndex(nextHostIndex));
/*     */         
/* 264 */         connectTo(nextHostIndex);
/*     */         
/* 266 */         if ((firstConnOrPassedByPrimaryHost) && (connectedToSecondaryHost())) {
/* 267 */           resetAutoFallBackCounters();
/*     */         }
/* 269 */         gotConnection = true;
/*     */       }
/*     */       catch (SQLException e) {
/* 272 */         lastExceptionCaught = e;
/*     */         
/* 274 */         if (shouldExceptionTriggerConnectionSwitch(e)) {
/* 275 */           int newNextHostIndex = nextHost(nextHostIndex, attempts > 0);
/*     */           
/* 277 */           if ((newNextHostIndex == firstHostIndexTried) && (newNextHostIndex == (newNextHostIndex = nextHost(nextHostIndex, true)))) {
/* 278 */             attempts++;
/*     */             try
/*     */             {
/* 281 */               Thread.sleep(250L);
/*     */             }
/*     */             catch (InterruptedException ie) {}
/*     */           }
/*     */           
/* 286 */           nextHostIndex = newNextHostIndex;
/*     */         }
/*     */         else {
/* 289 */           throw e;
/*     */         }
/*     */       }
/* 292 */     } while ((attempts < this.retriesAllDown) && (!gotConnection));
/*     */     
/* 294 */     if (!gotConnection) {
/* 295 */       throw lastExceptionCaught;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized void fallBackToPrimaryIfAvailable()
/*     */   {
/* 303 */     MySQLConnection connection = null;
/*     */     try {
/* 305 */       connection = createConnectionForHostIndex(this.primaryHostIndex);
/* 306 */       switchCurrentConnectionTo(this.primaryHostIndex, connection);
/*     */     } catch (SQLException e1) {
/* 308 */       if (connection != null) {
/*     */         try {
/* 310 */           connection.close();
/*     */         }
/*     */         catch (SQLException e2) {}
/*     */       }
/*     */       
/* 315 */       resetAutoFallBackCounters();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int nextHost(int currHostIdx, boolean vouchForPrimaryHost)
/*     */   {
/* 332 */     int nextHostIdx = (currHostIdx + 1) % this.hostList.size();
/* 333 */     if ((isPrimaryHostIndex(nextHostIdx)) && (isConnected()) && (!vouchForPrimaryHost) && (this.enableFallBackToPrimaryHost) && (!readyToFallBackToPrimaryHost()))
/*     */     {
/* 335 */       nextHostIdx = nextHost(nextHostIdx, vouchForPrimaryHost);
/*     */     }
/* 337 */     return nextHostIdx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized void incrementQueriesIssuedSinceFailover()
/*     */   {
/* 344 */     this.queriesIssuedSinceFailover += 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized boolean readyToFallBackToPrimaryHost()
/*     */   {
/* 352 */     return (this.enableFallBackToPrimaryHost) && (connectedToSecondaryHost()) && ((secondsBeforeRetryPrimaryHostIsMet()) || (queriesBeforeRetryPrimaryHostIsMet()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized boolean isConnected()
/*     */   {
/* 359 */     return this.currentHostIndex != -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized boolean isPrimaryHostIndex(int hostIndex)
/*     */   {
/* 369 */     return hostIndex == this.primaryHostIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized boolean connectedToPrimaryHost()
/*     */   {
/* 376 */     return isPrimaryHostIndex(this.currentHostIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized boolean connectedToSecondaryHost()
/*     */   {
/* 383 */     return (this.currentHostIndex >= 0) && (!isPrimaryHostIndex(this.currentHostIndex));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized boolean secondsBeforeRetryPrimaryHostIsMet()
/*     */   {
/* 390 */     return (this.secondsBeforeRetryPrimaryHost > 0) && (Util.secondsSinceMillis(this.primaryHostFailTimeMillis) >= this.secondsBeforeRetryPrimaryHost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized boolean queriesBeforeRetryPrimaryHostIsMet()
/*     */   {
/* 397 */     return (this.queriesBeforeRetryPrimaryHost > 0L) && (this.queriesIssuedSinceFailover >= this.queriesBeforeRetryPrimaryHost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized void resetAutoFallBackCounters()
/*     */   {
/* 404 */     this.primaryHostFailTimeMillis = System.currentTimeMillis();
/* 405 */     this.queriesIssuedSinceFailover = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized void doClose()
/*     */     throws SQLException
/*     */   {
/* 413 */     this.currentConnection.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized void doAbortInternal()
/*     */     throws SQLException
/*     */   {
/* 421 */     this.currentConnection.abortInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   synchronized void doAbort(Executor executor)
/*     */     throws SQLException
/*     */   {
/* 429 */     this.currentConnection.abort(executor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Object invokeMore(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/* 438 */     String methodName = method.getName();
/*     */     
/* 440 */     if ("setReadOnly".equals(methodName)) {
/* 441 */       this.explicitlyReadOnly = ((Boolean)args[0]);
/* 442 */       if ((this.failoverReadOnly) && (connectedToSecondaryHost())) {
/* 443 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 447 */     if (this.isClosed) {
/* 448 */       if ((this.autoReconnect) && (!this.closedExplicitly)) {
/* 449 */         this.currentHostIndex = -1;
/* 450 */         pickNewConnection();
/* 451 */         this.isClosed = false;
/* 452 */         this.closedReason = null;
/*     */       } else {
/* 454 */         String reason = "No operations allowed after connection closed.";
/* 455 */         if (this.closedReason != null) {
/* 456 */           reason = reason + "  " + this.closedReason;
/*     */         }
/* 458 */         throw SQLError.createSQLException(reason, "08003", null);
/*     */       }
/*     */     }
/*     */     
/* 462 */     Object result = null;
/*     */     try
/*     */     {
/* 465 */       result = method.invoke(this.thisAsConnection, args);
/* 466 */       result = proxyIfIsJdbcInterface(result);
/*     */     } catch (InvocationTargetException e) {
/* 468 */       dealWithInvocationException(e);
/*     */     }
/*     */     
/* 471 */     if ("setAutoCommit".equals(methodName)) {
/* 472 */       this.explicitlyAutoCommit = ((Boolean)args[0]).booleanValue();
/*     */     }
/*     */     
/* 475 */     if (((this.explicitlyAutoCommit) || ("commit".equals(methodName)) || ("rollback".equals(methodName))) && (readyToFallBackToPrimaryHost()))
/*     */     {
/* 477 */       fallBackToPrimaryIfAvailable();
/*     */     }
/*     */     
/* 480 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/FailoverConnectionProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */