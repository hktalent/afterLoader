/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationConnectionGroup
/*     */ {
/*     */   private String groupName;
/*  40 */   private long connections = 0L;
/*  41 */   private long slavesAdded = 0L;
/*  42 */   private long slavesRemoved = 0L;
/*  43 */   private long slavesPromoted = 0L;
/*  44 */   private long activeConnections = 0L;
/*  45 */   private HashMap<Long, ReplicationConnection> replicationConnections = new HashMap();
/*  46 */   private Set<String> slaveHostList = new HashSet();
/*  47 */   private boolean isInitialized = false;
/*  48 */   private Set<String> masterHostList = new HashSet();
/*     */   
/*     */   ReplicationConnectionGroup(String groupName) {
/*  51 */     this.groupName = groupName;
/*     */   }
/*     */   
/*     */   public long getConnectionCount() {
/*  55 */     return this.connections;
/*     */   }
/*     */   
/*     */   public long registerReplicationConnection(ReplicationConnection conn, List<String> localMasterList, List<String> localSlaveList)
/*     */   {
/*     */     long currentConnectionId;
/*  61 */     synchronized (this) {
/*  62 */       if (!this.isInitialized) {
/*  63 */         if (localMasterList != null) {
/*  64 */           this.masterHostList.addAll(localMasterList);
/*     */         }
/*  66 */         if (localSlaveList != null) {
/*  67 */           this.slaveHostList.addAll(localSlaveList);
/*     */         }
/*  69 */         this.isInitialized = true;
/*     */       }
/*  71 */       currentConnectionId = ++this.connections;
/*  72 */       this.replicationConnections.put(Long.valueOf(currentConnectionId), conn);
/*     */     }
/*  74 */     this.activeConnections += 1L;
/*     */     
/*  76 */     return currentConnectionId;
/*     */   }
/*     */   
/*     */   public String getGroupName()
/*     */   {
/*  81 */     return this.groupName;
/*     */   }
/*     */   
/*     */   public Collection<String> getMasterHosts() {
/*  85 */     return this.masterHostList;
/*     */   }
/*     */   
/*     */   public Collection<String> getSlaveHosts() {
/*  89 */     return this.slaveHostList;
/*     */   }
/*     */   
/*     */   public void addSlaveHost(String host) throws SQLException
/*     */   {
/*  94 */     if (this.slaveHostList.add(host)) {
/*  95 */       this.slavesAdded += 1L;
/*     */     }
/*     */     
/*  98 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/*  99 */       c.addSlaveHost(host);
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleCloseConnection(ReplicationConnection conn)
/*     */   {
/* 105 */     this.replicationConnections.remove(Long.valueOf(conn.getConnectionGroupId()));
/* 106 */     this.activeConnections -= 1L;
/*     */   }
/*     */   
/*     */   public void removeSlaveHost(String host, boolean closeGently) throws SQLException {
/* 110 */     if (this.slaveHostList.remove(host)) {
/* 111 */       this.slavesRemoved += 1L;
/*     */     }
/* 113 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/* 114 */       c.removeSlave(host, closeGently);
/*     */     }
/*     */   }
/*     */   
/*     */   public void promoteSlaveToMaster(String host) throws SQLException {
/* 119 */     this.slaveHostList.remove(host);
/* 120 */     this.masterHostList.add(host);
/* 121 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/* 122 */       c.promoteSlaveToMaster(host);
/*     */     }
/*     */     
/* 125 */     this.slavesPromoted += 1L;
/*     */   }
/*     */   
/*     */   public void removeMasterHost(String host) throws SQLException {
/* 129 */     removeMasterHost(host, true);
/*     */   }
/*     */   
/*     */   public void removeMasterHost(String host, boolean closeGently) throws SQLException {
/* 133 */     if (this.masterHostList.remove(host)) {}
/*     */     
/*     */ 
/* 136 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/* 137 */       c.removeMasterHost(host, closeGently);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getConnectionCountWithHostAsSlave(String host)
/*     */   {
/* 143 */     int matched = 0;
/*     */     
/* 145 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/* 146 */       if (c.isHostSlave(host)) {
/* 147 */         matched++;
/*     */       }
/*     */     }
/* 150 */     return matched;
/*     */   }
/*     */   
/*     */   public int getConnectionCountWithHostAsMaster(String host) {
/* 154 */     int matched = 0;
/*     */     
/* 156 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/* 157 */       if (c.isHostMaster(host)) {
/* 158 */         matched++;
/*     */       }
/*     */     }
/* 161 */     return matched;
/*     */   }
/*     */   
/*     */   public long getNumberOfSlavesAdded() {
/* 165 */     return this.slavesAdded;
/*     */   }
/*     */   
/*     */   public long getNumberOfSlavesRemoved() {
/* 169 */     return this.slavesRemoved;
/*     */   }
/*     */   
/*     */   public long getNumberOfSlavePromotions() {
/* 173 */     return this.slavesPromoted;
/*     */   }
/*     */   
/*     */   public long getTotalConnectionCount() {
/* 177 */     return this.connections;
/*     */   }
/*     */   
/*     */   public long getActiveConnectionCount() {
/* 181 */     return this.activeConnections;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 185 */     return "ReplicationConnectionGroup[groupName=" + this.groupName + ",masterHostList=" + this.masterHostList + ",slaveHostList=" + this.slaveHostList + "]";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ReplicationConnectionGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */