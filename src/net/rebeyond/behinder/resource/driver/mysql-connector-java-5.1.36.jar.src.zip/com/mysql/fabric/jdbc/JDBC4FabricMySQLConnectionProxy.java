/*     */ package com.mysql.fabric.jdbc;
/*     */ 
/*     */ import com.mysql.fabric.FabricConnection;
/*     */ import com.mysql.jdbc.Connection;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.NClob;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Struct;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBC4FabricMySQLConnectionProxy
/*     */   extends FabricMySQLConnectionProxy
/*     */   implements JDBC4FabricMySQLConnection, FabricMySQLConnectionProperties
/*     */ {
/*     */   private FabricConnection fabricConnection;
/*     */   
/*     */   public JDBC4FabricMySQLConnectionProxy(Properties props)
/*     */     throws SQLException
/*     */   {
/*  90 */     super(props);
/*     */   }
/*     */   
/*     */   public Blob createBlob() {
/*     */     try {
/*  95 */       transactionBegun();
/*  96 */       return getActiveConnection().createBlob();
/*     */     } catch (SQLException ex) {
/*  98 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Clob createClob() {
/*     */     try {
/* 104 */       transactionBegun();
/* 105 */       return getActiveConnection().createClob();
/*     */     } catch (SQLException ex) {
/* 107 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public NClob createNClob() {
/*     */     try {
/* 113 */       transactionBegun();
/* 114 */       return getActiveConnection().createNClob();
/*     */     } catch (SQLException ex) {
/* 116 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public SQLXML createSQLXML() throws SQLException {
/* 121 */     transactionBegun();
/* 122 */     return getActiveConnection().createSQLXML();
/*     */   }
/*     */   
/*     */   public void setClientInfo(Properties properties) throws SQLClientInfoException {
/* 126 */     for (Connection c : this.serverConnections.values())
/* 127 */       c.setClientInfo(properties);
/*     */   }
/*     */   
/*     */   public void setClientInfo(String name, String value) throws SQLClientInfoException {
/* 131 */     for (Connection c : this.serverConnections.values())
/* 132 */       c.setClientInfo(name, value);
/*     */   }
/*     */   
/*     */   public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
/* 136 */     return getActiveConnection().createArrayOf(typeName, elements);
/*     */   }
/*     */   
/*     */   public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
/* 140 */     transactionBegun();
/* 141 */     return getActiveConnection().createStruct(typeName, attributes);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/jdbc/JDBC4FabricMySQLConnectionProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */