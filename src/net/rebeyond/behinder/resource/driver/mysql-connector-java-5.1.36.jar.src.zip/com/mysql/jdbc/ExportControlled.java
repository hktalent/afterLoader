/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.util.Base64Decoder;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.URL;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportControlled
/*     */ {
/*     */   private static final String SQL_STATE_BAD_SSL_PARAMS = "08000";
/*     */   
/*     */   protected static boolean enabled()
/*     */   {
/*  65 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void transformSocketToSSLSocket(MysqlIO mysqlIO)
/*     */     throws SQLException
/*     */   {
/*  82 */     SocketFactory sslFact = new StandardSSLSocketFactory(getSSLSocketFactoryDefaultOrConfigured(mysqlIO), mysqlIO.socketFactory, mysqlIO.mysqlConnection);
/*     */     try
/*     */     {
/*  85 */       mysqlIO.mysqlConnection = sslFact.connect(mysqlIO.host, mysqlIO.port, null);
/*     */       
/*     */ 
/*  88 */       ((SSLSocket)mysqlIO.mysqlConnection).setEnabledProtocols(new String[] { "TLSv1" });
/*     */       
/*  90 */       String enabledSSLCipherSuites = mysqlIO.connection.getEnabledSSLCipherSuites();
/*  91 */       if ((enabledSSLCipherSuites != null) && (enabledSSLCipherSuites.length() > 0)) {
/*  92 */         ((SSLSocket)mysqlIO.mysqlConnection).setEnabledCipherSuites(enabledSSLCipherSuites.split("\\s*,\\s*"));
/*     */       }
/*     */       
/*  95 */       ((SSLSocket)mysqlIO.mysqlConnection).startHandshake();
/*     */       
/*  97 */       if (mysqlIO.connection.getUseUnbufferedInput()) {
/*  98 */         mysqlIO.mysqlInput = mysqlIO.mysqlConnection.getInputStream();
/*     */       } else {
/* 100 */         mysqlIO.mysqlInput = new BufferedInputStream(mysqlIO.mysqlConnection.getInputStream(), 16384);
/*     */       }
/*     */       
/* 103 */       mysqlIO.mysqlOutput = new BufferedOutputStream(mysqlIO.mysqlConnection.getOutputStream(), 16384);
/*     */       
/* 105 */       mysqlIO.mysqlOutput.flush();
/*     */       
/* 107 */       mysqlIO.socketFactory = sslFact;
/*     */     }
/*     */     catch (IOException ioEx) {
/* 110 */       throw SQLError.createCommunicationsException(mysqlIO.connection, mysqlIO.getLastPacketSentTimeMs(), mysqlIO.getLastPacketReceivedTimeMs(), ioEx, mysqlIO.getExceptionInterceptor());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class StandardSSLSocketFactory
/*     */     implements SocketFactory
/*     */   {
/* 119 */     private SSLSocket rawSocket = null;
/*     */     private final SSLSocketFactory sslFact;
/*     */     private final SocketFactory existingSocketFactory;
/*     */     private final Socket existingSocket;
/*     */     
/*     */     public StandardSSLSocketFactory(SSLSocketFactory sslFact, SocketFactory existingSocketFactory, Socket existingSocket) {
/* 125 */       this.sslFact = sslFact;
/* 126 */       this.existingSocketFactory = existingSocketFactory;
/* 127 */       this.existingSocket = existingSocket;
/*     */     }
/*     */     
/*     */     public Socket afterHandshake() throws SocketException, IOException {
/* 131 */       this.existingSocketFactory.afterHandshake();
/* 132 */       return this.rawSocket;
/*     */     }
/*     */     
/*     */     public Socket beforeHandshake() throws SocketException, IOException {
/* 136 */       return this.rawSocket;
/*     */     }
/*     */     
/*     */     public Socket connect(String host, int portNumber, Properties props) throws SocketException, IOException {
/* 140 */       this.rawSocket = ((SSLSocket)this.sslFact.createSocket(this.existingSocket, host, portNumber, true));
/* 141 */       return this.rawSocket;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static SSLSocketFactory getSSLSocketFactoryDefaultOrConfigured(MysqlIO mysqlIO)
/*     */     throws SQLException
/*     */   {
/* 150 */     String clientCertificateKeyStoreUrl = mysqlIO.connection.getClientCertificateKeyStoreUrl();
/* 151 */     String trustCertificateKeyStoreUrl = mysqlIO.connection.getTrustCertificateKeyStoreUrl();
/* 152 */     String clientCertificateKeyStoreType = mysqlIO.connection.getClientCertificateKeyStoreType();
/* 153 */     String clientCertificateKeyStorePassword = mysqlIO.connection.getClientCertificateKeyStorePassword();
/* 154 */     String trustCertificateKeyStoreType = mysqlIO.connection.getTrustCertificateKeyStoreType();
/* 155 */     String trustCertificateKeyStorePassword = mysqlIO.connection.getTrustCertificateKeyStorePassword();
/*     */     
/* 157 */     if ((StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) && (StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl)) && 
/* 158 */       (mysqlIO.connection.getVerifyServerCertificate())) {
/* 159 */       return (SSLSocketFactory)SSLSocketFactory.getDefault();
/*     */     }
/*     */     
/*     */ 
/* 163 */     TrustManagerFactory tmf = null;
/* 164 */     KeyManagerFactory kmf = null;
/*     */     try
/*     */     {
/* 167 */       tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/* 168 */       kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/*     */     } catch (NoSuchAlgorithmException nsae) {
/* 170 */       throw SQLError.createSQLException("Default algorithm definitions for TrustManager and/or KeyManager are invalid.  Check java security properties file.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 175 */     if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl)) {
/* 176 */       InputStream ksIS = null;
/*     */       try {
/* 178 */         if (!StringUtils.isNullOrEmpty(clientCertificateKeyStoreType)) {
/* 179 */           KeyStore clientKeyStore = KeyStore.getInstance(clientCertificateKeyStoreType);
/* 180 */           URL ksURL = new URL(clientCertificateKeyStoreUrl);
/* 181 */           char[] password = clientCertificateKeyStorePassword == null ? new char[0] : clientCertificateKeyStorePassword.toCharArray();
/* 182 */           ksIS = ksURL.openStream();
/* 183 */           clientKeyStore.load(ksIS, password);
/* 184 */           kmf.init(clientKeyStore, password);
/*     */         }
/*     */       } catch (UnrecoverableKeyException uke) {
/* 187 */         throw SQLError.createSQLException("Could not recover keys from client keystore.  Check password?", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (NoSuchAlgorithmException nsae) {
/* 190 */         throw SQLError.createSQLException("Unsupported keystore algorithm [" + nsae.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (KeyStoreException kse) {
/* 193 */         throw SQLError.createSQLException("Could not create KeyStore instance [" + kse.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (CertificateException nsae) {
/* 196 */         throw SQLError.createSQLException("Could not load client" + clientCertificateKeyStoreType + " keystore from " + clientCertificateKeyStoreUrl, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (MalformedURLException mue) {
/* 199 */         throw SQLError.createSQLException(clientCertificateKeyStoreUrl + " does not appear to be a valid URL.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (IOException ioe) {
/* 202 */         SQLException sqlEx = SQLError.createSQLException("Cannot open " + clientCertificateKeyStoreUrl + " [" + ioe.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */         
/* 204 */         sqlEx.initCause(ioe);
/*     */         
/* 206 */         throw sqlEx;
/*     */       } finally {
/* 208 */         if (ksIS != null) {
/*     */           try {
/* 210 */             ksIS.close();
/*     */           }
/*     */           catch (IOException e) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 218 */     if (!StringUtils.isNullOrEmpty(trustCertificateKeyStoreUrl))
/*     */     {
/* 220 */       InputStream ksIS = null;
/*     */       try {
/* 222 */         if (!StringUtils.isNullOrEmpty(trustCertificateKeyStoreType)) {
/* 223 */           KeyStore trustKeyStore = KeyStore.getInstance(trustCertificateKeyStoreType);
/* 224 */           URL ksURL = new URL(trustCertificateKeyStoreUrl);
/*     */           
/* 226 */           char[] password = trustCertificateKeyStorePassword == null ? new char[0] : trustCertificateKeyStorePassword.toCharArray();
/* 227 */           ksIS = ksURL.openStream();
/* 228 */           trustKeyStore.load(ksIS, password);
/* 229 */           tmf.init(trustKeyStore);
/*     */         }
/*     */       } catch (NoSuchAlgorithmException nsae) {
/* 232 */         throw SQLError.createSQLException("Unsupported keystore algorithm [" + nsae.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (KeyStoreException kse) {
/* 235 */         throw SQLError.createSQLException("Could not create KeyStore instance [" + kse.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (CertificateException nsae) {
/* 238 */         throw SQLError.createSQLException("Could not load trust" + trustCertificateKeyStoreType + " keystore from " + trustCertificateKeyStoreUrl, "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (MalformedURLException mue) {
/* 241 */         throw SQLError.createSQLException(trustCertificateKeyStoreUrl + " does not appear to be a valid URL.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */       }
/*     */       catch (IOException ioe) {
/* 244 */         SQLException sqlEx = SQLError.createSQLException("Cannot open " + trustCertificateKeyStoreUrl + " [" + ioe.getMessage() + "]", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */         
/*     */ 
/* 247 */         sqlEx.initCause(ioe);
/*     */         
/* 249 */         throw sqlEx;
/*     */       } finally {
/* 251 */         if (ksIS != null) {
/*     */           try {
/* 253 */             ksIS.close();
/*     */           }
/*     */           catch (IOException e) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 261 */     SSLContext sslContext = null;
/*     */     try
/*     */     {
/* 264 */       sslContext = SSLContext.getInstance("TLS");
/* 265 */       sslContext.init(StringUtils.isNullOrEmpty(clientCertificateKeyStoreUrl) ? null : kmf.getKeyManagers(), new X509TrustManager[] { mysqlIO.connection.getVerifyServerCertificate() ? tmf.getTrustManagers() : new X509TrustManager()
/*     */       {
/*     */         public void checkClientTrusted(X509Certificate[] chain, String authType) {}
/*     */         
/*     */ 
/*     */ 
/*     */         public void checkServerTrusted(X509Certificate[] chain, String authType)
/*     */           throws CertificateException
/*     */         {}
/*     */         
/*     */ 
/* 276 */         public X509Certificate[] getAcceptedIssuers() { return null; } } }, null);
/*     */       
/*     */ 
/*     */ 
/* 280 */       return sslContext.getSocketFactory();
/*     */     } catch (NoSuchAlgorithmException nsae) {
/* 282 */       throw SQLError.createSQLException("TLS is not a valid SSL protocol.", "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     } catch (KeyManagementException kme) {
/* 284 */       throw SQLError.createSQLException("KeyManagementException: " + kme.getMessage(), "08000", 0, false, mysqlIO.getExceptionInterceptor());
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isSSLEstablished(MysqlIO mysqlIO)
/*     */   {
/* 290 */     return SSLSocket.class.isAssignableFrom(mysqlIO.mysqlConnection.getClass());
/*     */   }
/*     */   
/*     */   public static RSAPublicKey decodeRSAPublicKey(String key, ExceptionInterceptor interceptor) throws SQLException
/*     */   {
/*     */     try {
/* 296 */       if (key == null) {
/* 297 */         throw new SQLException("key parameter is null");
/*     */       }
/*     */       
/* 300 */       int offset = key.indexOf("\n") + 1;
/* 301 */       int len = key.indexOf("-----END PUBLIC KEY-----") - offset;
/*     */       
/*     */ 
/* 304 */       byte[] certificateData = Base64Decoder.decode(key.getBytes(), offset, len);
/*     */       
/* 306 */       X509EncodedKeySpec spec = new X509EncodedKeySpec(certificateData);
/* 307 */       KeyFactory kf = KeyFactory.getInstance("RSA");
/* 308 */       return (RSAPublicKey)kf.generatePublic(spec);
/*     */     } catch (Exception ex) {
/* 310 */       throw SQLError.createSQLException("Unable to decode public key", "S1009", ex, interceptor);
/*     */     }
/*     */   }
/*     */   
/*     */   public static byte[] encryptWithRSAPublicKey(byte[] source, RSAPublicKey key, ExceptionInterceptor interceptor) throws SQLException {
/*     */     try {
/* 316 */       Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/* 317 */       cipher.init(1, key);
/* 318 */       return cipher.doFinal(source);
/*     */     } catch (Exception ex) {
/* 320 */       throw SQLError.createSQLException(ex.getMessage(), "S1009", ex, interceptor);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ExportControlled.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */