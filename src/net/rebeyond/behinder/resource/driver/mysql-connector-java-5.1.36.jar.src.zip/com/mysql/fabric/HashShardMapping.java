/*    */ package com.mysql.fabric;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.util.Comparator;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HashShardMapping
/*    */   extends ShardMapping
/*    */ {
/*    */   private static final MessageDigest md5Hasher;
/*    */   
/*    */   private static class ReverseShardIndexSorter
/*    */     implements Comparator<ShardIndex>
/*    */   {
/*    */     public int compare(ShardIndex i1, ShardIndex i2)
/*    */     {
/* 39 */       return i2.getBound().compareTo(i1.getBound());
/*    */     }
/*    */     
/*    */ 
/* 43 */     public static final ReverseShardIndexSorter instance = new ReverseShardIndexSorter();
/*    */   }
/*    */   
/*    */   static
/*    */   {
/*    */     try {
/* 49 */       md5Hasher = MessageDigest.getInstance("MD5");
/*    */     } catch (NoSuchAlgorithmException ex) {
/* 51 */       throw new ExceptionInInitializerError(ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public HashShardMapping(int mappingId, ShardingType shardingType, String globalGroupName, Set<ShardTable> shardTables, Set<ShardIndex> shardIndices) {
/* 56 */     super(mappingId, shardingType, globalGroupName, shardTables, new TreeSet(ReverseShardIndexSorter.instance));
/* 57 */     this.shardIndices.addAll(shardIndices);
/*    */   }
/*    */   
/*    */   protected ShardIndex getShardIndexForKey(String stringKey)
/*    */   {
/* 62 */     String hashedKey = new BigInteger(1, md5Hasher.digest(stringKey.getBytes())).toString(16).toUpperCase();
/*    */     
/*    */ 
/* 65 */     for (int i = 0; i < 32 - hashedKey.length(); i++) {
/* 66 */       hashedKey = "0" + hashedKey;
/*    */     }
/*    */     
/* 69 */     for (ShardIndex i : this.shardIndices) {
/* 70 */       if (i.getBound().compareTo(hashedKey) <= 0) {
/* 71 */         return i;
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 77 */     return (ShardIndex)this.shardIndices.iterator().next();
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/HashShardMapping.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */