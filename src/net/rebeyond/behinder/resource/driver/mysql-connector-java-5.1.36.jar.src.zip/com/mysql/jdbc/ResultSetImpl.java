/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.LogUtils;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ResultSetImpl
/*      */   implements ResultSetInternalMethods
/*      */ {
/*      */   private static final Constructor<?> JDBC_4_RS_4_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_RS_6_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_UPD_RS_6_ARG_CTOR;
/*      */   protected static final double MIN_DIFF_PREC;
/*      */   protected static final double MAX_DIFF_PREC;
/*      */   static int resultCounter;
/*      */   
/*      */   protected static BigInteger convertLongToUlong(long longVal)
/*      */   {
/*  145 */     byte[] asBytes = new byte[8];
/*  146 */     asBytes[7] = ((byte)(int)(longVal & 0xFF));
/*  147 */     asBytes[6] = ((byte)(int)(longVal >>> 8));
/*  148 */     asBytes[5] = ((byte)(int)(longVal >>> 16));
/*  149 */     asBytes[4] = ((byte)(int)(longVal >>> 24));
/*  150 */     asBytes[3] = ((byte)(int)(longVal >>> 32));
/*  151 */     asBytes[2] = ((byte)(int)(longVal >>> 40));
/*  152 */     asBytes[1] = ((byte)(int)(longVal >>> 48));
/*  153 */     asBytes[0] = ((byte)(int)(longVal >>> 56));
/*      */     
/*  155 */     return new BigInteger(1, asBytes);
/*      */   }
/*      */   
/*      */ 
/*  159 */   protected String catalog = null;
/*      */   
/*      */ 
/*  162 */   protected Map<String, Integer> columnLabelToIndex = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   protected Map<String, Integer> columnToIndexCache = null;
/*      */   
/*      */ 
/*  171 */   protected boolean[] columnUsed = null;
/*      */   
/*      */ 
/*      */   protected volatile MySQLConnection connection;
/*      */   
/*  176 */   protected long connectionId = 0L;
/*      */   
/*      */ 
/*  179 */   protected int currentRow = -1;
/*      */   
/*      */ 
/*  182 */   protected boolean doingUpdates = false;
/*      */   
/*  184 */   protected ProfilerEventHandler eventSink = null;
/*      */   
/*  186 */   Calendar fastDefaultCal = null;
/*  187 */   Calendar fastClientCal = null;
/*      */   
/*      */ 
/*  190 */   protected int fetchDirection = 1000;
/*      */   
/*      */ 
/*  193 */   protected int fetchSize = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   protected Field[] fields;
/*      */   
/*      */ 
/*      */ 
/*      */   protected char firstCharOfQuery;
/*      */   
/*      */ 
/*      */ 
/*  205 */   protected Map<String, Integer> fullColumnNameToIndex = null;
/*      */   
/*  207 */   protected Map<String, Integer> columnNameToIndex = null;
/*      */   
/*  209 */   protected boolean hasBuiltIndexMapping = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  214 */   protected boolean isBinaryEncoded = false;
/*      */   
/*      */ 
/*  217 */   protected boolean isClosed = false;
/*      */   
/*  219 */   protected ResultSetInternalMethods nextResultSet = null;
/*      */   
/*      */ 
/*  222 */   protected boolean onInsertRow = false;
/*      */   
/*      */ 
/*      */ 
/*      */   protected StatementImpl owningStatement;
/*      */   
/*      */ 
/*      */ 
/*      */   protected String pointOfOrigin;
/*      */   
/*      */ 
/*  233 */   protected boolean profileSql = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  238 */   protected boolean reallyResult = false;
/*      */   
/*      */ 
/*      */   protected int resultId;
/*      */   
/*      */ 
/*  244 */   protected int resultSetConcurrency = 0;
/*      */   
/*      */ 
/*  247 */   protected int resultSetType = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   protected RowData rowData;
/*      */   
/*      */ 
/*      */ 
/*  255 */   protected String serverInfo = null;
/*      */   
/*      */ 
/*      */   PreparedStatement statementUsedForFetchingRows;
/*      */   
/*  260 */   protected ResultSetRow thisRow = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long updateCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  274 */   protected long updateId = -1L;
/*      */   
/*  276 */   private boolean useStrictFloatingPoint = false;
/*      */   
/*  278 */   protected boolean useUsageAdvisor = false;
/*      */   
/*      */ 
/*  281 */   protected SQLWarning warningChain = null;
/*      */   
/*      */ 
/*  284 */   protected boolean wasNullFlag = false;
/*      */   
/*      */   protected Statement wrapperStatement;
/*      */   
/*      */   protected boolean retainOwningStatement;
/*      */   
/*  290 */   protected Calendar gmtCalendar = null;
/*      */   
/*  292 */   protected boolean useFastDateParsing = false;
/*      */   
/*  294 */   private boolean padCharsWithSpace = false;
/*      */   
/*      */   private boolean jdbcCompliantTruncationForReads;
/*      */   
/*  298 */   private boolean useFastIntParsing = true;
/*      */   private boolean useColumnNamesInFindColumn;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   static final char[] EMPTY_SPACE;
/*      */   
/*      */   static
/*      */   {
/*  106 */     if (Util.isJdbc4()) {
/*      */       try {
/*  108 */         JDBC_4_RS_4_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4ResultSet").getConstructor(new Class[] { Long.TYPE, Long.TYPE, MySQLConnection.class, StatementImpl.class });
/*      */         
/*  110 */         JDBC_4_RS_6_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4ResultSet").getConstructor(new Class[] { String.class, Field[].class, RowData.class, MySQLConnection.class, StatementImpl.class });
/*      */         
/*  112 */         JDBC_4_UPD_RS_6_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4UpdatableResultSet").getConstructor(new Class[] { String.class, Field[].class, RowData.class, MySQLConnection.class, StatementImpl.class });
/*      */       }
/*      */       catch (SecurityException e) {
/*  115 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  117 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  119 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  122 */       JDBC_4_RS_4_ARG_CTOR = null;
/*  123 */       JDBC_4_RS_6_ARG_CTOR = null;
/*  124 */       JDBC_4_UPD_RS_6_ARG_CTOR = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */     MIN_DIFF_PREC = Float.parseFloat(Float.toString(Float.MIN_VALUE)) - Double.parseDouble(Float.toString(Float.MIN_VALUE));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  136 */     MAX_DIFF_PREC = Float.parseFloat(Float.toString(Float.MAX_VALUE)) - Double.parseDouble(Float.toString(Float.MAX_VALUE));
/*      */     
/*      */ 
/*  139 */     resultCounter = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  303 */     EMPTY_SPACE = new char['ÿ'];
/*      */     
/*      */ 
/*  306 */     for (int i = 0; i < EMPTY_SPACE.length; i++) {
/*  307 */       EMPTY_SPACE[i] = ' ';
/*      */     }
/*      */   }
/*      */   
/*      */   protected static ResultSetImpl getInstance(long updateCount, long updateID, MySQLConnection conn, StatementImpl creatorStmt) throws SQLException {
/*  312 */     if (!Util.isJdbc4()) {
/*  313 */       return new ResultSetImpl(updateCount, updateID, conn, creatorStmt);
/*      */     }
/*      */     
/*  316 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_4_ARG_CTOR, new Object[] { Long.valueOf(updateCount), Long.valueOf(updateID), conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static ResultSetImpl getInstance(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt, boolean isUpdatable)
/*      */     throws SQLException
/*      */   {
/*  330 */     if (!Util.isJdbc4()) {
/*  331 */       if (!isUpdatable) {
/*  332 */         return new ResultSetImpl(catalog, fields, tuples, conn, creatorStmt);
/*      */       }
/*      */       
/*  335 */       return new UpdatableResultSet(catalog, fields, tuples, conn, creatorStmt);
/*      */     }
/*      */     
/*  338 */     if (!isUpdatable) {
/*  339 */       return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_6_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*  343 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_UPD_RS_6_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetImpl(long updateCount, long updateID, MySQLConnection conn, StatementImpl creatorStmt)
/*      */   {
/*  358 */     this.updateCount = updateCount;
/*  359 */     this.updateId = updateID;
/*  360 */     this.reallyResult = false;
/*  361 */     this.fields = new Field[0];
/*      */     
/*  363 */     this.connection = conn;
/*  364 */     this.owningStatement = creatorStmt;
/*      */     
/*  366 */     this.retainOwningStatement = false;
/*      */     
/*  368 */     if (this.connection != null) {
/*  369 */       this.exceptionInterceptor = this.connection.getExceptionInterceptor();
/*      */       
/*  371 */       this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose();
/*      */       
/*  373 */       this.connectionId = this.connection.getId();
/*  374 */       this.serverTimeZoneTz = this.connection.getServerTimezoneTZ();
/*  375 */       this.padCharsWithSpace = this.connection.getPadCharsWithSpace();
/*      */       
/*  377 */       this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetImpl(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt)
/*      */     throws SQLException
/*      */   {
/*  398 */     this.connection = conn;
/*      */     
/*  400 */     this.retainOwningStatement = false;
/*      */     
/*  402 */     if (this.connection != null) {
/*  403 */       this.exceptionInterceptor = this.connection.getExceptionInterceptor();
/*  404 */       this.useStrictFloatingPoint = this.connection.getStrictFloatingPoint();
/*  405 */       this.connectionId = this.connection.getId();
/*  406 */       this.useFastDateParsing = this.connection.getUseFastDateParsing();
/*  407 */       this.profileSql = this.connection.getProfileSql();
/*  408 */       this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose();
/*  409 */       this.jdbcCompliantTruncationForReads = this.connection.getJdbcCompliantTruncationForReads();
/*  410 */       this.useFastIntParsing = this.connection.getUseFastIntParsing();
/*  411 */       this.serverTimeZoneTz = this.connection.getServerTimezoneTZ();
/*  412 */       this.padCharsWithSpace = this.connection.getPadCharsWithSpace();
/*      */     }
/*      */     
/*  415 */     this.owningStatement = creatorStmt;
/*      */     
/*  417 */     this.catalog = catalog;
/*      */     
/*  419 */     this.fields = fields;
/*  420 */     this.rowData = tuples;
/*  421 */     this.updateCount = this.rowData.size();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  427 */     this.reallyResult = true;
/*      */     
/*      */ 
/*  430 */     if (this.rowData.size() > 0) {
/*  431 */       if ((this.updateCount == 1L) && 
/*  432 */         (this.thisRow == null)) {
/*  433 */         this.rowData.close();
/*  434 */         this.updateCount = -1L;
/*      */       }
/*      */     }
/*      */     else {
/*  438 */       this.thisRow = null;
/*      */     }
/*      */     
/*  441 */     this.rowData.setOwner(this);
/*      */     
/*  443 */     if (this.fields != null) {
/*  444 */       initializeWithMetadata();
/*      */     }
/*  446 */     this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();
/*      */     
/*  448 */     this.useColumnNamesInFindColumn = this.connection.getUseColumnNamesInFindColumn();
/*      */     
/*  450 */     setRowPositionValidity();
/*      */   }
/*      */   
/*      */   public void initializeWithMetadata() throws SQLException {
/*  454 */     synchronized (checkClosed().getConnectionMutex()) {
/*  455 */       this.rowData.setMetadata(this.fields);
/*      */       
/*  457 */       this.columnToIndexCache = new HashMap();
/*      */       
/*  459 */       if ((this.profileSql) || (this.connection.getUseUsageAdvisor())) {
/*  460 */         this.columnUsed = new boolean[this.fields.length];
/*  461 */         this.pointOfOrigin = LogUtils.findCallingClassAndMethod(new Throwable());
/*  462 */         this.resultId = (resultCounter++);
/*  463 */         this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  464 */         this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */       }
/*      */       
/*  467 */       if (this.connection.getGatherPerformanceMetrics()) {
/*  468 */         this.connection.incrementNumberOfResultSetsCreated();
/*      */         
/*  470 */         Set<String> tableNamesSet = new HashSet();
/*      */         
/*  472 */         for (int i = 0; i < this.fields.length; i++) {
/*  473 */           Field f = this.fields[i];
/*      */           
/*  475 */           String tableName = f.getOriginalTableName();
/*      */           
/*  477 */           if (tableName == null) {
/*  478 */             tableName = f.getTableName();
/*      */           }
/*      */           
/*  481 */           if (tableName != null) {
/*  482 */             if (this.connection.lowerCaseTableNames()) {
/*  483 */               tableName = tableName.toLowerCase();
/*      */             }
/*      */             
/*      */ 
/*  487 */             tableNamesSet.add(tableName);
/*      */           }
/*      */         }
/*      */         
/*  491 */         this.connection.reportNumberOfTablesAccessed(tableNamesSet.size());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized Calendar getFastDefaultCalendar() {
/*  497 */     if (this.fastDefaultCal == null) {
/*  498 */       this.fastDefaultCal = new GregorianCalendar(Locale.US);
/*  499 */       this.fastDefaultCal.setTimeZone(getDefaultTimeZone());
/*      */     }
/*  501 */     return this.fastDefaultCal;
/*      */   }
/*      */   
/*      */   private synchronized Calendar getFastClientCalendar() {
/*  505 */     if (this.fastClientCal == null) {
/*  506 */       this.fastClientCal = new GregorianCalendar(Locale.US);
/*      */     }
/*  508 */     return this.fastClientCal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean absolute(int row)
/*      */     throws SQLException
/*      */   {
/*  545 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*      */       boolean b;
/*      */       boolean b;
/*  549 */       if (this.rowData.size() == 0) {
/*  550 */         b = false;
/*      */       } else {
/*  552 */         if (this.onInsertRow) {
/*  553 */           this.onInsertRow = false;
/*      */         }
/*      */         
/*  556 */         if (this.doingUpdates) {
/*  557 */           this.doingUpdates = false;
/*      */         }
/*      */         
/*  560 */         if (this.thisRow != null) {
/*  561 */           this.thisRow.closeOpenStreams();
/*      */         }
/*      */         boolean b;
/*  564 */         if (row == 0) {
/*  565 */           beforeFirst();
/*  566 */           b = false; } else { boolean b;
/*  567 */           if (row == 1) {
/*  568 */             b = first(); } else { boolean b;
/*  569 */             if (row == -1) {
/*  570 */               b = last(); } else { boolean b;
/*  571 */               if (row > this.rowData.size()) {
/*  572 */                 afterLast();
/*  573 */                 b = false;
/*      */               } else { boolean b;
/*  575 */                 if (row < 0)
/*      */                 {
/*  577 */                   int newRowPosition = this.rowData.size() + row + 1;
/*      */                   boolean b;
/*  579 */                   if (newRowPosition <= 0) {
/*  580 */                     beforeFirst();
/*  581 */                     b = false;
/*      */                   } else {
/*  583 */                     b = absolute(newRowPosition);
/*      */                   }
/*      */                 } else {
/*  586 */                   row--;
/*  587 */                   this.rowData.setCurrentRow(row);
/*  588 */                   this.thisRow = this.rowData.getAt(row);
/*  589 */                   b = true;
/*      */                 }
/*      */               }
/*      */             }
/*      */           } } }
/*  594 */       setRowPositionValidity();
/*      */       
/*  596 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void afterLast()
/*      */     throws SQLException
/*      */   {
/*  612 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  614 */       if (this.onInsertRow) {
/*  615 */         this.onInsertRow = false;
/*      */       }
/*      */       
/*  618 */       if (this.doingUpdates) {
/*  619 */         this.doingUpdates = false;
/*      */       }
/*      */       
/*  622 */       if (this.thisRow != null) {
/*  623 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/*  626 */       if (this.rowData.size() != 0) {
/*  627 */         this.rowData.afterLast();
/*  628 */         this.thisRow = null;
/*      */       }
/*      */       
/*  631 */       setRowPositionValidity();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  647 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  649 */       if (this.onInsertRow) {
/*  650 */         this.onInsertRow = false;
/*      */       }
/*      */       
/*  653 */       if (this.doingUpdates) {
/*  654 */         this.doingUpdates = false;
/*      */       }
/*      */       
/*  657 */       if (this.rowData.size() == 0) {
/*  658 */         return;
/*      */       }
/*      */       
/*  661 */       if (this.thisRow != null) {
/*  662 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/*  665 */       this.rowData.beforeFirst();
/*  666 */       this.thisRow = null;
/*      */       
/*  668 */       setRowPositionValidity();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void buildIndexMapping()
/*      */     throws SQLException
/*      */   {
/*  680 */     int numFields = this.fields.length;
/*  681 */     this.columnLabelToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*  682 */     this.fullColumnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*  683 */     this.columnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  692 */     for (int i = numFields - 1; i >= 0; i--) {
/*  693 */       Integer index = Integer.valueOf(i);
/*  694 */       String columnName = this.fields[i].getOriginalName();
/*  695 */       String columnLabel = this.fields[i].getName();
/*  696 */       String fullColumnName = this.fields[i].getFullName();
/*      */       
/*  698 */       if (columnLabel != null) {
/*  699 */         this.columnLabelToIndex.put(columnLabel, index);
/*      */       }
/*      */       
/*  702 */       if (fullColumnName != null) {
/*  703 */         this.fullColumnNameToIndex.put(fullColumnName, index);
/*      */       }
/*      */       
/*  706 */       if (columnName != null) {
/*  707 */         this.columnNameToIndex.put(columnName, index);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  712 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/*  727 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final MySQLConnection checkClosed()
/*      */     throws SQLException
/*      */   {
/*  737 */     MySQLConnection c = this.connection;
/*      */     
/*  739 */     if (c == null) {
/*  740 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*  744 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void checkColumnBounds(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  757 */     synchronized (checkClosed().getConnectionMutex()) {
/*  758 */       if (columnIndex < 1) {
/*  759 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_low", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf(this.fields.length) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*  763 */       if (columnIndex > this.fields.length) {
/*  764 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_high", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf(this.fields.length) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  770 */       if ((this.profileSql) || (this.useUsageAdvisor)) {
/*  771 */         this.columnUsed[(columnIndex - 1)] = true;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkRowPos()
/*      */     throws SQLException
/*      */   {
/*  784 */     checkClosed();
/*      */     
/*  786 */     if (!this.onValidRow) {
/*  787 */       throw SQLError.createSQLException(this.invalidRowReason, "S1000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*  791 */   private boolean onValidRow = false;
/*  792 */   private String invalidRowReason = null;
/*      */   protected boolean useLegacyDatetimeCode;
/*      */   private TimeZone serverTimeZoneTz;
/*      */   
/*      */   private void setRowPositionValidity() throws SQLException {
/*  797 */     if ((!this.rowData.isDynamic()) && (this.rowData.size() == 0)) {
/*  798 */       this.invalidRowReason = Messages.getString("ResultSet.Illegal_operation_on_empty_result_set");
/*  799 */       this.onValidRow = false;
/*  800 */     } else if (this.rowData.isBeforeFirst()) {
/*  801 */       this.invalidRowReason = Messages.getString("ResultSet.Before_start_of_result_set_146");
/*  802 */       this.onValidRow = false;
/*  803 */     } else if (this.rowData.isAfterLast()) {
/*  804 */       this.invalidRowReason = Messages.getString("ResultSet.After_end_of_result_set_148");
/*  805 */       this.onValidRow = false;
/*      */     } else {
/*  807 */       this.onValidRow = true;
/*  808 */       this.invalidRowReason = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearNextResult()
/*      */   {
/*  817 */     this.nextResultSet = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  828 */     synchronized (checkClosed().getConnectionMutex()) {
/*  829 */       this.warningChain = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  848 */     realClose(true);
/*      */   }
/*      */   
/*      */   private int convertToZeroWithEmptyCheck() throws SQLException {
/*  852 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  853 */       return 0;
/*      */     }
/*      */     
/*  856 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   private String convertToZeroLiteralStringWithEmptyCheck()
/*      */     throws SQLException
/*      */   {
/*  862 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  863 */       return "0";
/*      */     }
/*      */     
/*  866 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ResultSetInternalMethods copy()
/*      */     throws SQLException
/*      */   {
/*  874 */     synchronized (checkClosed().getConnectionMutex()) {
/*  875 */       ResultSetInternalMethods rs = getInstance(this.catalog, this.fields, this.rowData, this.connection, this.owningStatement, false);
/*      */       
/*  877 */       return rs;
/*      */     }
/*      */   }
/*      */   
/*      */   public void redefineFieldsForDBMD(Field[] f) {
/*  882 */     this.fields = f;
/*      */     
/*  884 */     for (int i = 0; i < this.fields.length; i++) {
/*  885 */       this.fields[i].setUseOldNameMetadata(true);
/*  886 */       this.fields[i].setConnection(this.connection);
/*      */     }
/*      */   }
/*      */   
/*      */   public void populateCachedMetaData(CachedResultSetMetaData cachedMetaData) throws SQLException {
/*  891 */     cachedMetaData.fields = this.fields;
/*  892 */     cachedMetaData.columnNameToIndex = this.columnLabelToIndex;
/*  893 */     cachedMetaData.fullColumnNameToIndex = this.fullColumnNameToIndex;
/*  894 */     cachedMetaData.metadata = getMetaData();
/*      */   }
/*      */   
/*      */   public void initializeFromCachedMetaData(CachedResultSetMetaData cachedMetaData) {
/*  898 */     this.fields = cachedMetaData.fields;
/*  899 */     this.columnLabelToIndex = cachedMetaData.columnNameToIndex;
/*  900 */     this.fullColumnNameToIndex = cachedMetaData.fullColumnNameToIndex;
/*  901 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/*  914 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String extractStringFromNativeColumn(int columnIndex, int mysqlType)
/*      */     throws SQLException
/*      */   {
/*  924 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/*  926 */     this.wasNullFlag = false;
/*      */     
/*  928 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/*  929 */       this.wasNullFlag = true;
/*      */       
/*  931 */       return null;
/*      */     }
/*      */     
/*  934 */     this.wasNullFlag = false;
/*      */     
/*  936 */     String encoding = this.fields[columnIndexMinusOne].getEncoding();
/*      */     
/*  938 */     return this.thisRow.getString(columnIndex - 1, encoding, this.connection);
/*      */   }
/*      */   
/*      */   protected Date fastDateCreate(Calendar cal, int year, int month, int day) throws SQLException {
/*  942 */     synchronized (checkClosed().getConnectionMutex()) {
/*  943 */       Calendar targetCalendar = cal;
/*      */       
/*  945 */       if (cal == null) {
/*  946 */         if (this.connection.getNoTimezoneConversionForDateType()) {
/*  947 */           targetCalendar = getFastClientCalendar();
/*      */         } else {
/*  949 */           targetCalendar = getFastDefaultCalendar();
/*      */         }
/*      */       }
/*      */       
/*  953 */       if (!this.useLegacyDatetimeCode) {
/*  954 */         return TimeUtil.fastDateCreate(year, month, day, targetCalendar);
/*      */       }
/*      */       
/*  957 */       boolean useGmtMillis = (cal == null) && (!this.connection.getNoTimezoneConversionForDateType()) && (this.connection.getUseGmtMillisForDatetimes());
/*      */       
/*  959 */       return TimeUtil.fastDateCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : targetCalendar, targetCalendar, year, month, day);
/*      */     }
/*      */   }
/*      */   
/*      */   protected Time fastTimeCreate(Calendar cal, int hour, int minute, int second) throws SQLException {
/*  964 */     synchronized (checkClosed().getConnectionMutex()) {
/*  965 */       if (!this.useLegacyDatetimeCode) {
/*  966 */         return TimeUtil.fastTimeCreate(hour, minute, second, cal, getExceptionInterceptor());
/*      */       }
/*      */       
/*  969 */       if (cal == null) {
/*  970 */         cal = getFastDefaultCalendar();
/*      */       }
/*      */       
/*  973 */       return TimeUtil.fastTimeCreate(cal, hour, minute, second, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   protected Timestamp fastTimestampCreate(Calendar cal, int year, int month, int day, int hour, int minute, int seconds, int secondsPart) throws SQLException {
/*  978 */     synchronized (checkClosed().getConnectionMutex()) {
/*  979 */       if (!this.useLegacyDatetimeCode) {
/*  980 */         return TimeUtil.fastTimestampCreate(cal.getTimeZone(), year, month, day, hour, minute, seconds, secondsPart);
/*      */       }
/*      */       
/*  983 */       if (cal == null) {
/*  984 */         cal = getFastDefaultCalendar();
/*      */       }
/*      */       
/*  987 */       boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */       
/*  989 */       return TimeUtil.fastTimestampCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : null, cal, year, month, day, hour, minute, seconds, secondsPart);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int findColumn(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1034 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*      */ 
/* 1037 */       if (!this.hasBuiltIndexMapping) {
/* 1038 */         buildIndexMapping();
/*      */       }
/*      */       
/* 1041 */       Integer index = (Integer)this.columnToIndexCache.get(columnName);
/*      */       
/* 1043 */       if (index != null) {
/* 1044 */         return index.intValue() + 1;
/*      */       }
/*      */       
/* 1047 */       index = (Integer)this.columnLabelToIndex.get(columnName);
/*      */       
/* 1049 */       if ((index == null) && (this.useColumnNamesInFindColumn)) {
/* 1050 */         index = (Integer)this.columnNameToIndex.get(columnName);
/*      */       }
/*      */       
/* 1053 */       if (index == null) {
/* 1054 */         index = (Integer)this.fullColumnNameToIndex.get(columnName);
/*      */       }
/*      */       
/* 1057 */       if (index != null) {
/* 1058 */         this.columnToIndexCache.put(columnName, index);
/*      */         
/* 1060 */         return index.intValue() + 1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1065 */       for (int i = 0; i < this.fields.length; i++) {
/* 1066 */         if (this.fields[i].getName().equalsIgnoreCase(columnName))
/* 1067 */           return i + 1;
/* 1068 */         if (this.fields[i].getFullName().equalsIgnoreCase(columnName)) {
/* 1069 */           return i + 1;
/*      */         }
/*      */       }
/*      */       
/* 1073 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Column____112") + columnName + Messages.getString("ResultSet.___not_found._113"), "S0022", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean first()
/*      */     throws SQLException
/*      */   {
/* 1092 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1094 */       boolean b = true;
/*      */       
/* 1096 */       if (this.rowData.isEmpty()) {
/* 1097 */         b = false;
/*      */       }
/*      */       else {
/* 1100 */         if (this.onInsertRow) {
/* 1101 */           this.onInsertRow = false;
/*      */         }
/*      */         
/* 1104 */         if (this.doingUpdates) {
/* 1105 */           this.doingUpdates = false;
/*      */         }
/*      */         
/* 1108 */         this.rowData.beforeFirst();
/* 1109 */         this.thisRow = this.rowData.next();
/*      */       }
/*      */       
/* 1112 */       setRowPositionValidity();
/*      */       
/* 1114 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(int i)
/*      */     throws SQLException
/*      */   {
/* 1131 */     checkColumnBounds(i);
/*      */     
/* 1133 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(String colName)
/*      */     throws SQLException
/*      */   {
/* 1149 */     return getArray(findColumn(colName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1176 */     checkRowPos();
/*      */     
/* 1178 */     if (!this.isBinaryEncoded) {
/* 1179 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */     
/* 1182 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1191 */     return getAsciiStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1208 */     if (!this.isBinaryEncoded) {
/* 1209 */       String stringVal = getString(columnIndex);
/*      */       
/*      */ 
/* 1212 */       if (stringVal != null) {
/* 1213 */         if (stringVal.length() == 0)
/*      */         {
/* 1215 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */           
/* 1217 */           return val;
/*      */         }
/*      */         try
/*      */         {
/* 1221 */           return new BigDecimal(stringVal);
/*      */         }
/*      */         catch (NumberFormatException ex)
/*      */         {
/* 1225 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1231 */       return null;
/*      */     }
/*      */     
/* 1234 */     return getNativeBigDecimal(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1255 */     if (!this.isBinaryEncoded) {
/* 1256 */       String stringVal = getString(columnIndex);
/*      */       
/*      */ 
/* 1259 */       if (stringVal != null) {
/* 1260 */         if (stringVal.length() == 0) {
/* 1261 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */           try
/*      */           {
/* 1264 */             return val.setScale(scale);
/*      */           } catch (ArithmeticException ex) {
/*      */             try {
/* 1267 */               return val.setScale(scale, 4);
/*      */             } catch (ArithmeticException arEx) {
/* 1269 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */         try
/*      */         {
/* 1277 */           val = new BigDecimal(stringVal);
/*      */         } catch (NumberFormatException ex) { BigDecimal val;
/* 1279 */           if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 1280 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 1282 */             val = new BigDecimal(valueAsLong);
/*      */           } else {
/* 1284 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */         try
/*      */         {
/* 1291 */           return val.setScale(scale);
/*      */         } catch (ArithmeticException ex) {
/*      */           try { BigDecimal val;
/* 1294 */             return val.setScale(scale, 4);
/*      */           } catch (ArithmeticException arithEx) {
/* 1296 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1303 */       return null;
/*      */     }
/*      */     
/* 1306 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1322 */     return getBigDecimal(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String columnName, int scale)
/*      */     throws SQLException
/*      */   {
/* 1335 */     return getBigDecimal(findColumn(columnName), scale);
/*      */   }
/*      */   
/*      */   private final BigDecimal getBigDecimalFromString(String stringVal, int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1341 */     if (stringVal != null) {
/* 1342 */       if (stringVal.length() == 0) {
/* 1343 */         BigDecimal bdVal = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */         try
/*      */         {
/* 1346 */           return bdVal.setScale(scale);
/*      */         } catch (ArithmeticException ex) {
/*      */           try {
/* 1349 */             return bdVal.setScale(scale, 4);
/*      */           } catch (ArithmeticException arEx) {
/* 1351 */             throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 1359 */         return new BigDecimal(stringVal).setScale(scale);
/*      */       } catch (ArithmeticException ex) {
/*      */         try {
/* 1362 */           return new BigDecimal(stringVal).setScale(scale, 4);
/*      */         } catch (ArithmeticException arEx) {
/* 1364 */           throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException ex)
/*      */       {
/* 1369 */         if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 1370 */           long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */           try
/*      */           {
/* 1373 */             return new BigDecimal(valueAsLong).setScale(scale);
/*      */           } catch (ArithmeticException arEx1) {
/*      */             try {
/* 1376 */               return new BigDecimal(valueAsLong).setScale(scale, 4);
/*      */             } catch (ArithmeticException arEx2) {
/* 1378 */               throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1384 */         if ((this.fields[(columnIndex - 1)].getMysqlType() == 1) && (this.connection.getTinyInt1isBit()) && (this.fields[(columnIndex - 1)].getLength() == 1L))
/*      */         {
/* 1386 */           return new BigDecimal(stringVal.equalsIgnoreCase("true") ? 1 : 0).setScale(scale);
/*      */         }
/*      */         
/* 1389 */         throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1394 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1415 */     checkRowPos();
/*      */     
/* 1417 */     if (!this.isBinaryEncoded) {
/* 1418 */       checkColumnBounds(columnIndex);
/*      */       
/* 1420 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1422 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1423 */         this.wasNullFlag = true;
/*      */         
/* 1425 */         return null;
/*      */       }
/*      */       
/* 1428 */       this.wasNullFlag = false;
/*      */       
/* 1430 */       return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1433 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1442 */     return getBinaryStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Blob getBlob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1457 */     if (!this.isBinaryEncoded) {
/* 1458 */       checkRowPos();
/*      */       
/* 1460 */       checkColumnBounds(columnIndex);
/*      */       
/* 1462 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1464 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1465 */         this.wasNullFlag = true;
/*      */       } else {
/* 1467 */         this.wasNullFlag = false;
/*      */       }
/*      */       
/* 1470 */       if (this.wasNullFlag) {
/* 1471 */         return null;
/*      */       }
/*      */       
/* 1474 */       if (!this.connection.getEmulateLocators()) {
/* 1475 */         return new Blob(this.thisRow.getColumnValue(columnIndexMinusOne), getExceptionInterceptor());
/*      */       }
/*      */       
/* 1478 */       return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1481 */     return getNativeBlob(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Blob getBlob(String colName)
/*      */     throws SQLException
/*      */   {
/* 1496 */     return getBlob(findColumn(colName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1512 */     checkColumnBounds(columnIndex);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1518 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 1520 */     Field field = this.fields[columnIndexMinusOne];
/*      */     
/* 1522 */     if (field.getMysqlType() == 16) {
/* 1523 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1526 */     this.wasNullFlag = false;
/*      */     
/* 1528 */     int sqlType = field.getSQLType();
/*      */     long boolVal;
/* 1530 */     switch (sqlType) {
/*      */     case 16: 
/* 1532 */       if (field.getMysqlType() == -1) {
/* 1533 */         String stringVal = getString(columnIndex);
/*      */         
/* 1535 */         return getBooleanFromString(stringVal);
/*      */       }
/*      */       
/* 1538 */       boolVal = getLong(columnIndex, false);
/*      */       
/* 1540 */       return (boolVal == -1L) || (boolVal > 0L);
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 1551 */       boolVal = getLong(columnIndex, false);
/*      */       
/* 1553 */       return (boolVal == -1L) || (boolVal > 0L);
/*      */     }
/* 1555 */     if (this.connection.getPedantic())
/*      */     {
/* 1557 */       switch (sqlType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case 70: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 2000: 
/*      */       case 2002: 
/*      */       case 2003: 
/*      */       case 2004: 
/*      */       case 2005: 
/*      */       case 2006: 
/* 1571 */         throw SQLError.createSQLException("Required type conversion not allowed", "22018", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 1576 */     if ((sqlType == -2) || (sqlType == -3) || (sqlType == -4) || (sqlType == 2004)) {
/* 1577 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1580 */     if (this.useUsageAdvisor) {
/* 1581 */       issueConversionViaParsingWarning("getBoolean()", columnIndex, this.thisRow.getColumnValue(columnIndexMinusOne), this.fields[columnIndex], new int[] { 16, 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1586 */     String stringVal = getString(columnIndex);
/*      */     
/* 1588 */     return getBooleanFromString(stringVal);
/*      */   }
/*      */   
/*      */   private boolean byteArrayToBoolean(int columnIndexMinusOne) throws SQLException
/*      */   {
/* 1593 */     Object value = this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     
/* 1595 */     if (value == null) {
/* 1596 */       this.wasNullFlag = true;
/*      */       
/* 1598 */       return false;
/*      */     }
/*      */     
/* 1601 */     this.wasNullFlag = false;
/*      */     
/* 1603 */     if (((byte[])value).length == 0) {
/* 1604 */       return false;
/*      */     }
/*      */     
/* 1607 */     byte boolVal = ((byte[])(byte[])value)[0];
/*      */     
/* 1609 */     if (boolVal == 49)
/* 1610 */       return true;
/* 1611 */     if (boolVal == 48) {
/* 1612 */       return false;
/*      */     }
/*      */     
/* 1615 */     return (boolVal == -1) || (boolVal > 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1624 */     return getBoolean(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final boolean getBooleanFromString(String stringVal) throws SQLException {
/* 1628 */     if ((stringVal != null) && (stringVal.length() > 0)) {
/* 1629 */       int c = Character.toLowerCase(stringVal.charAt(0));
/*      */       
/* 1631 */       return (c == 116) || (c == 121) || (c == 49) || (stringVal.equals("-1"));
/*      */     }
/*      */     
/* 1634 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1649 */     if (!this.isBinaryEncoded) {
/* 1650 */       String stringVal = getString(columnIndex);
/*      */       
/* 1652 */       if ((this.wasNullFlag) || (stringVal == null)) {
/* 1653 */         return 0;
/*      */       }
/*      */       
/* 1656 */       return getByteFromString(stringVal, columnIndex);
/*      */     }
/*      */     
/* 1659 */     return getNativeByte(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1668 */     return getByte(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final byte getByteFromString(String stringVal, int columnIndex) throws SQLException
/*      */   {
/* 1673 */     if ((stringVal != null) && (stringVal.length() == 0)) {
/* 1674 */       return (byte)convertToZeroWithEmptyCheck();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1684 */     if (stringVal == null) {
/* 1685 */       return 0;
/*      */     }
/*      */     
/* 1688 */     stringVal = stringVal.trim();
/*      */     try
/*      */     {
/* 1691 */       int decimalIndex = stringVal.indexOf(".");
/*      */       
/* 1693 */       if (decimalIndex != -1) {
/* 1694 */         double valueAsDouble = Double.parseDouble(stringVal);
/*      */         
/* 1696 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 1697 */           (valueAsDouble < -128.0D) || (valueAsDouble > 127.0D))) {
/* 1698 */           throwRangeException(stringVal, columnIndex, -6);
/*      */         }
/*      */         
/*      */ 
/* 1702 */         return (byte)(int)valueAsDouble;
/*      */       }
/*      */       
/* 1705 */       long valueAsLong = Long.parseLong(stringVal);
/*      */       
/* 1707 */       if ((this.jdbcCompliantTruncationForReads) && (
/* 1708 */         (valueAsLong < -128L) || (valueAsLong > 127L))) {
/* 1709 */         throwRangeException(String.valueOf(valueAsLong), columnIndex, -6);
/*      */       }
/*      */       
/*      */ 
/* 1713 */       return (byte)(int)valueAsLong;
/*      */     } catch (NumberFormatException NFE) {
/* 1715 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Value____173") + stringVal + Messages.getString("ResultSet.___is_out_of_range_[-127,127]_174"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1737 */     return getBytes(columnIndex, false);
/*      */   }
/*      */   
/*      */   protected byte[] getBytes(int columnIndex, boolean noConversion) throws SQLException {
/* 1741 */     if (!this.isBinaryEncoded) {
/* 1742 */       checkRowPos();
/*      */       
/* 1744 */       checkColumnBounds(columnIndex);
/*      */       
/* 1746 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1748 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1749 */         this.wasNullFlag = true;
/*      */       } else {
/* 1751 */         this.wasNullFlag = false;
/*      */       }
/*      */       
/* 1754 */       if (this.wasNullFlag) {
/* 1755 */         return null;
/*      */       }
/*      */       
/* 1758 */       return this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1761 */     return getNativeBytes(columnIndex, noConversion);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1770 */     return getBytes(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final byte[] getBytesFromString(String stringVal) throws SQLException {
/* 1774 */     if (stringVal != null) {
/* 1775 */       return StringUtils.getBytes(stringVal, this.connection.getEncoding(), this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), this.connection, getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 1779 */     return null;
/*      */   }
/*      */   
/*      */   public int getBytesSize() throws SQLException {
/* 1783 */     RowData localRowData = this.rowData;
/*      */     
/* 1785 */     checkClosed();
/*      */     
/* 1787 */     if ((localRowData instanceof RowDataStatic)) {
/* 1788 */       int bytesSize = 0;
/*      */       
/* 1790 */       int numRows = localRowData.size();
/*      */       
/* 1792 */       for (int i = 0; i < numRows; i++) {
/* 1793 */         bytesSize += localRowData.getAt(i).getBytesSize();
/*      */       }
/*      */       
/* 1796 */       return bytesSize;
/*      */     }
/*      */     
/* 1799 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Calendar getCalendarInstanceForSessionOrNew()
/*      */     throws SQLException
/*      */   {
/* 1807 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1808 */       if (this.connection != null) {
/* 1809 */         return this.connection.getCalendarInstanceForSessionOrNew();
/*      */       }
/*      */       
/*      */ 
/* 1813 */       return new GregorianCalendar();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1833 */     if (!this.isBinaryEncoded) {
/* 1834 */       checkColumnBounds(columnIndex);
/*      */       
/* 1836 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1838 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1839 */         this.wasNullFlag = true;
/*      */         
/* 1841 */         return null;
/*      */       }
/*      */       
/* 1844 */       this.wasNullFlag = false;
/*      */       
/* 1846 */       return this.thisRow.getReader(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1849 */     return getNativeCharacterStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1868 */     return getCharacterStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final Reader getCharacterStreamFromString(String stringVal) throws SQLException {
/* 1872 */     if (stringVal != null) {
/* 1873 */       return new StringReader(stringVal);
/*      */     }
/*      */     
/* 1876 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Clob getClob(int i)
/*      */     throws SQLException
/*      */   {
/* 1891 */     if (!this.isBinaryEncoded) {
/* 1892 */       String asString = getStringForClob(i);
/*      */       
/* 1894 */       if (asString == null) {
/* 1895 */         return null;
/*      */       }
/*      */       
/* 1898 */       return new Clob(asString, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1901 */     return getNativeClob(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Clob getClob(String colName)
/*      */     throws SQLException
/*      */   {
/* 1916 */     return getClob(findColumn(colName));
/*      */   }
/*      */   
/*      */   private final java.sql.Clob getClobFromString(String stringVal) throws SQLException {
/* 1920 */     return new Clob(stringVal, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/* 1933 */     return 1007;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/* 1959 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Positioned_Update_not_supported"), "S1C00", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1975 */     return getDate(columnIndex, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1995 */     if (this.isBinaryEncoded) {
/* 1996 */       return getNativeDate(columnIndex, cal);
/*      */     }
/*      */     
/* 1999 */     if (!this.useFastDateParsing) {
/* 2000 */       String stringVal = getStringInternal(columnIndex, false);
/*      */       
/* 2002 */       if (stringVal == null) {
/* 2003 */         return null;
/*      */       }
/*      */       
/* 2006 */       return getDateFromString(stringVal, columnIndex, cal);
/*      */     }
/*      */     
/* 2009 */     checkColumnBounds(columnIndex);
/*      */     
/* 2011 */     int columnIndexMinusOne = columnIndex - 1;
/* 2012 */     Date tmpDate = this.thisRow.getDateFast(columnIndexMinusOne, this.connection, this, cal);
/* 2013 */     if ((this.thisRow.isNull(columnIndexMinusOne)) || (tmpDate == null))
/*      */     {
/* 2015 */       this.wasNullFlag = true;
/*      */       
/* 2017 */       return null;
/*      */     }
/*      */     
/* 2020 */     this.wasNullFlag = false;
/*      */     
/* 2022 */     return tmpDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2031 */     return getDate(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2050 */     return getDate(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */   private final Date getDateFromString(String stringVal, int columnIndex, Calendar targetCalendar) throws SQLException {
/* 2054 */     int year = 0;
/* 2055 */     int month = 0;
/* 2056 */     int day = 0;
/*      */     try
/*      */     {
/* 2059 */       this.wasNullFlag = false;
/*      */       
/* 2061 */       if (stringVal == null) {
/* 2062 */         this.wasNullFlag = true;
/*      */         
/* 2064 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2074 */       stringVal = stringVal.trim();
/*      */       
/*      */ 
/* 2077 */       int dec = stringVal.indexOf(".");
/* 2078 */       if (dec > -1) {
/* 2079 */         stringVal = stringVal.substring(0, dec);
/*      */       }
/*      */       
/* 2082 */       if ((stringVal.equals("0")) || (stringVal.equals("0000-00-00")) || (stringVal.equals("0000-00-00 00:00:00")) || (stringVal.equals("00000000000000")) || (stringVal.equals("0")))
/*      */       {
/*      */ 
/* 2085 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 2086 */           this.wasNullFlag = true;
/*      */           
/* 2088 */           return null; }
/* 2089 */         if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 2090 */           throw SQLError.createSQLException("Value '" + stringVal + "' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2095 */         return fastDateCreate(targetCalendar, 1, 1, 1);
/*      */       }
/* 2097 */       if (this.fields[(columnIndex - 1)].getMysqlType() == 7)
/*      */       {
/* 2099 */         switch (stringVal.length()) {
/*      */         case 19: 
/*      */         case 21: 
/* 2102 */           year = Integer.parseInt(stringVal.substring(0, 4));
/* 2103 */           month = Integer.parseInt(stringVal.substring(5, 7));
/* 2104 */           day = Integer.parseInt(stringVal.substring(8, 10));
/*      */           
/* 2106 */           return fastDateCreate(targetCalendar, year, month, day);
/*      */         
/*      */ 
/*      */         case 8: 
/*      */         case 14: 
/* 2111 */           year = Integer.parseInt(stringVal.substring(0, 4));
/* 2112 */           month = Integer.parseInt(stringVal.substring(4, 6));
/* 2113 */           day = Integer.parseInt(stringVal.substring(6, 8));
/*      */           
/* 2115 */           return fastDateCreate(targetCalendar, year, month, day);
/*      */         
/*      */ 
/*      */         case 6: 
/*      */         case 10: 
/*      */         case 12: 
/* 2121 */           year = Integer.parseInt(stringVal.substring(0, 2));
/*      */           
/* 2123 */           if (year <= 69) {
/* 2124 */             year += 100;
/*      */           }
/*      */           
/* 2127 */           month = Integer.parseInt(stringVal.substring(2, 4));
/* 2128 */           day = Integer.parseInt(stringVal.substring(4, 6));
/*      */           
/* 2130 */           return fastDateCreate(targetCalendar, year + 1900, month, day);
/*      */         
/*      */ 
/*      */         case 4: 
/* 2134 */           year = Integer.parseInt(stringVal.substring(0, 4));
/*      */           
/* 2136 */           if (year <= 69) {
/* 2137 */             year += 100;
/*      */           }
/*      */           
/* 2140 */           month = Integer.parseInt(stringVal.substring(2, 4));
/*      */           
/* 2142 */           return fastDateCreate(targetCalendar, year + 1900, month, 1);
/*      */         
/*      */ 
/*      */         case 2: 
/* 2146 */           year = Integer.parseInt(stringVal.substring(0, 2));
/*      */           
/* 2148 */           if (year <= 69) {
/* 2149 */             year += 100;
/*      */           }
/*      */           
/* 2152 */           return fastDateCreate(targetCalendar, year + 1900, 1, 1);
/*      */         }
/*      */         
/*      */         
/* 2156 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 2160 */       if (this.fields[(columnIndex - 1)].getMysqlType() == 13)
/*      */       {
/* 2162 */         if ((stringVal.length() == 2) || (stringVal.length() == 1)) {
/* 2163 */           year = Integer.parseInt(stringVal);
/*      */           
/* 2165 */           if (year <= 69) {
/* 2166 */             year += 100;
/*      */           }
/*      */           
/* 2169 */           year += 1900;
/*      */         } else {
/* 2171 */           year = Integer.parseInt(stringVal.substring(0, 4));
/*      */         }
/*      */         
/* 2174 */         return fastDateCreate(targetCalendar, year, 1, 1); }
/* 2175 */       if (this.fields[(columnIndex - 1)].getMysqlType() == 11) {
/* 2176 */         return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */       }
/* 2178 */       if (stringVal.length() < 10) {
/* 2179 */         if (stringVal.length() == 8) {
/* 2180 */           return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */         }
/*      */         
/* 2183 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2188 */       if (stringVal.length() != 18) {
/* 2189 */         year = Integer.parseInt(stringVal.substring(0, 4));
/* 2190 */         month = Integer.parseInt(stringVal.substring(5, 7));
/* 2191 */         day = Integer.parseInt(stringVal.substring(8, 10));
/*      */       }
/*      */       else {
/* 2194 */         StringTokenizer st = new StringTokenizer(stringVal, "- ");
/*      */         
/* 2196 */         year = Integer.parseInt(st.nextToken());
/* 2197 */         month = Integer.parseInt(st.nextToken());
/* 2198 */         day = Integer.parseInt(st.nextToken());
/*      */       }
/*      */       
/*      */ 
/* 2202 */       return fastDateCreate(targetCalendar, year, month, day);
/*      */     } catch (SQLException sqlEx) {
/* 2204 */       throw sqlEx;
/*      */     } catch (Exception e) {
/* 2206 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       
/*      */ 
/*      */ 
/* 2210 */       sqlEx.initCause(e);
/*      */       
/* 2212 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private TimeZone getDefaultTimeZone() {
/* 2217 */     return this.useLegacyDatetimeCode ? this.connection.getDefaultTimeZone() : this.serverTimeZoneTz;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2232 */     if (!this.isBinaryEncoded) {
/* 2233 */       return getDoubleInternal(columnIndex);
/*      */     }
/*      */     
/* 2236 */     return getNativeDouble(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2245 */     return getDouble(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final double getDoubleFromString(String stringVal, int columnIndex) throws SQLException {
/* 2249 */     return getDoubleInternal(stringVal, columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double getDoubleInternal(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 2265 */     return getDoubleInternal(getString(colIndex), colIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double getDoubleInternal(String stringVal, int colIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2284 */       if (stringVal == null) {
/* 2285 */         return 0.0D;
/*      */       }
/*      */       
/* 2288 */       if (stringVal.length() == 0) {
/* 2289 */         return convertToZeroWithEmptyCheck();
/*      */       }
/*      */       
/* 2292 */       double d = Double.parseDouble(stringVal);
/*      */       
/* 2294 */       if (this.useStrictFloatingPoint)
/*      */       {
/* 2296 */         if (d == 2.147483648E9D)
/*      */         {
/* 2298 */           d = 2.147483647E9D;
/* 2299 */         } else if (d == 1.0000000036275E-15D)
/*      */         {
/* 2301 */           d = 1.0E-15D;
/* 2302 */         } else if (d == 9.999999869911E14D) {
/* 2303 */           d = 9.99999999999999E14D;
/* 2304 */         } else if (d == 1.4012984643248E-45D) {
/* 2305 */           d = 1.4E-45D;
/* 2306 */         } else if (d == 1.4013E-45D) {
/* 2307 */           d = 1.4E-45D;
/* 2308 */         } else if (d == 3.4028234663853E37D) {
/* 2309 */           d = 3.4028235E37D;
/* 2310 */         } else if (d == -2.14748E9D) {
/* 2311 */           d = -2.147483648E9D;
/* 2312 */         } else if (d != 3.40282E37D) {} }
/* 2313 */       return 3.4028235E37D;
/*      */ 
/*      */     }
/*      */     catch (NumberFormatException e)
/*      */     {
/*      */ 
/* 2319 */       if (this.fields[(colIndex - 1)].getMysqlType() == 16) {
/* 2320 */         long valueAsLong = getNumericRepresentationOfSQLBitType(colIndex);
/*      */         
/* 2322 */         return valueAsLong;
/*      */       }
/*      */       
/* 2325 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_number", new Object[] { stringVal, Integer.valueOf(colIndex) }), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2386 */     if (!this.isBinaryEncoded) {
/* 2387 */       String val = null;
/*      */       
/* 2389 */       val = getString(columnIndex);
/*      */       
/* 2391 */       return getFloatFromString(val, columnIndex);
/*      */     }
/*      */     
/* 2394 */     return getNativeFloat(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2403 */     return getFloat(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final float getFloatFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 2408 */       if (val != null) {
/* 2409 */         if (val.length() == 0) {
/* 2410 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2413 */         float f = Float.parseFloat(val);
/*      */         
/* 2415 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 2416 */           (f == Float.MIN_VALUE) || (f == Float.MAX_VALUE))) {
/* 2417 */           double valAsDouble = Double.parseDouble(val);
/*      */           
/*      */ 
/*      */ 
/* 2421 */           if ((valAsDouble < 1.401298464324817E-45D - MIN_DIFF_PREC) || (valAsDouble > 3.4028234663852886E38D - MAX_DIFF_PREC)) {
/* 2422 */             throwRangeException(String.valueOf(valAsDouble), columnIndex, 6);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 2427 */         return f;
/*      */       }
/*      */       
/* 2430 */       return 0.0F;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2433 */         Double valueAsDouble = new Double(val);
/* 2434 */         float valueAsFloat = valueAsDouble.floatValue();
/*      */         
/* 2436 */         if (this.jdbcCompliantTruncationForReads)
/*      */         {
/* 2438 */           if (((this.jdbcCompliantTruncationForReads) && (valueAsFloat == Float.NEGATIVE_INFINITY)) || (valueAsFloat == Float.POSITIVE_INFINITY)) {
/* 2439 */             throwRangeException(valueAsDouble.toString(), columnIndex, 6);
/*      */           }
/*      */         }
/*      */         
/* 2443 */         return valueAsFloat;
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 2448 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getFloat()_-____200") + val + Messages.getString("ResultSet.___in_column__201") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2466 */     checkRowPos();
/*      */     
/* 2468 */     if (!this.isBinaryEncoded) {
/* 2469 */       int columnIndexMinusOne = columnIndex - 1;
/* 2470 */       if (this.useFastIntParsing) {
/* 2471 */         checkColumnBounds(columnIndex);
/*      */         
/* 2473 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2474 */           this.wasNullFlag = true;
/*      */         } else {
/* 2476 */           this.wasNullFlag = false;
/*      */         }
/*      */         
/* 2479 */         if (this.wasNullFlag) {
/* 2480 */           return 0;
/*      */         }
/*      */         
/* 2483 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2484 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2487 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */         
/* 2489 */         if (!needsFullParse) {
/*      */           try {
/* 2491 */             return getIntWithOverflowCheck(columnIndexMinusOne);
/*      */           }
/*      */           catch (NumberFormatException nfe) {
/*      */             try {
/* 2495 */               return parseIntAsDouble(columnIndex, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection));
/*      */ 
/*      */             }
/*      */             catch (NumberFormatException newNfe)
/*      */             {
/*      */ 
/* 2501 */               if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2502 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */                 
/* 2504 */                 if ((this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))) {
/* 2505 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */                 }
/*      */                 
/* 2508 */                 return (int)valueAsLong;
/*      */               }
/*      */               
/* 2511 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2519 */       String val = null;
/*      */       try
/*      */       {
/* 2522 */         val = getString(columnIndex);
/*      */         
/* 2524 */         if (val != null) {
/* 2525 */           if (val.length() == 0) {
/* 2526 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 2529 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1)) {
/* 2530 */             int intVal = Integer.parseInt(val);
/*      */             
/* 2532 */             checkForIntegerTruncation(columnIndexMinusOne, null, intVal);
/*      */             
/* 2534 */             return intVal;
/*      */           }
/*      */           
/*      */ 
/* 2538 */           int intVal = parseIntAsDouble(columnIndex, val);
/*      */           
/* 2540 */           checkForIntegerTruncation(columnIndex, null, intVal);
/*      */           
/* 2542 */           return intVal;
/*      */         }
/*      */         
/* 2545 */         return 0;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2548 */           return parseIntAsDouble(columnIndex, val);
/*      */ 
/*      */         }
/*      */         catch (NumberFormatException newNfe)
/*      */         {
/* 2553 */           if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2554 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 2556 */             if ((this.jdbcCompliantTruncationForReads) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))) {
/* 2557 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */             
/* 2560 */             return (int)valueAsLong;
/*      */           }
/*      */           
/* 2563 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + val + "'", "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2568 */     return getNativeInt(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2577 */     return getInt(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final int getIntFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 2582 */       if (val != null)
/*      */       {
/* 2584 */         if (val.length() == 0) {
/* 2585 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2588 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2596 */           val = val.trim();
/*      */           
/* 2598 */           int valueAsInt = Integer.parseInt(val);
/*      */           
/* 2600 */           if ((this.jdbcCompliantTruncationForReads) && (
/* 2601 */             (valueAsInt == Integer.MIN_VALUE) || (valueAsInt == Integer.MAX_VALUE))) {
/* 2602 */             long valueAsLong = Long.parseLong(val);
/*      */             
/* 2604 */             if ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)) {
/* 2605 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2610 */           return valueAsInt;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2615 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2617 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 2618 */           (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D))) {
/* 2619 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */         
/*      */ 
/* 2623 */         return (int)valueAsDouble;
/*      */       }
/*      */       
/* 2626 */       return 0;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2629 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2631 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 2632 */           (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D))) {
/* 2633 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */         
/*      */ 
/* 2637 */         return (int)valueAsDouble;
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 2642 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____206") + val + Messages.getString("ResultSet.___in_column__207") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2661 */     return getLong(columnIndex, true);
/*      */   }
/*      */   
/*      */   private long getLong(int columnIndex, boolean overflowCheck) throws SQLException {
/* 2665 */     if (!this.isBinaryEncoded) {
/* 2666 */       checkRowPos();
/*      */       
/* 2668 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 2670 */       if (this.useFastIntParsing)
/*      */       {
/* 2672 */         checkColumnBounds(columnIndex);
/*      */         
/* 2674 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2675 */           this.wasNullFlag = true;
/*      */         } else {
/* 2677 */           this.wasNullFlag = false;
/*      */         }
/*      */         
/* 2680 */         if (this.wasNullFlag) {
/* 2681 */           return 0L;
/*      */         }
/*      */         
/* 2684 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2685 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2688 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */         
/* 2690 */         if (!needsFullParse) {
/*      */           try {
/* 2692 */             return getLongWithOverflowCheck(columnIndexMinusOne, overflowCheck);
/*      */           }
/*      */           catch (NumberFormatException nfe) {
/*      */             try {
/* 2696 */               return parseLongAsDouble(columnIndexMinusOne, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection));
/*      */ 
/*      */             }
/*      */             catch (NumberFormatException newNfe)
/*      */             {
/*      */ 
/* 2702 */               if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2703 */                 return getNumericRepresentationOfSQLBitType(columnIndex);
/*      */               }
/*      */               
/* 2706 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getEncoding(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2714 */       String val = null;
/*      */       try
/*      */       {
/* 2717 */         val = getString(columnIndex);
/*      */         
/* 2719 */         if (val != null) {
/* 2720 */           if (val.length() == 0) {
/* 2721 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 2724 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1)) {
/* 2725 */             return parseLongWithOverflowCheck(columnIndexMinusOne, null, val, overflowCheck);
/*      */           }
/*      */           
/*      */ 
/* 2729 */           return parseLongAsDouble(columnIndexMinusOne, val);
/*      */         }
/*      */         
/* 2732 */         return 0L;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2735 */           return parseLongAsDouble(columnIndexMinusOne, val);
/*      */ 
/*      */         }
/*      */         catch (NumberFormatException newNfe)
/*      */         {
/* 2740 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + val + "'", "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2745 */     return getNativeLong(columnIndex, overflowCheck, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2754 */     return getLong(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final long getLongFromString(String val, int columnIndexZeroBased) throws SQLException {
/*      */     try {
/* 2759 */       if (val != null)
/*      */       {
/* 2761 */         if (val.length() == 0) {
/* 2762 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2765 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1)) {
/* 2766 */           return parseLongWithOverflowCheck(columnIndexZeroBased, null, val, true);
/*      */         }
/*      */         
/*      */ 
/* 2770 */         return parseLongAsDouble(columnIndexZeroBased, val);
/*      */       }
/*      */       
/* 2773 */       return 0L;
/*      */     }
/*      */     catch (NumberFormatException nfe) {
/*      */       try {
/* 2777 */         return parseLongAsDouble(columnIndexZeroBased, val);
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 2782 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____211") + val + Messages.getString("ResultSet.___in_column__212") + (columnIndexZeroBased + 1), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 2798 */     checkClosed();
/*      */     
/* 2800 */     return new ResultSetMetaData(this.fields, this.connection.getUseOldAliasMetadataBehavior(), this.connection.getYearIsDateType(), getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Array getNativeArray(int i)
/*      */     throws SQLException
/*      */   {
/* 2817 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getNativeAsciiStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2844 */     checkRowPos();
/*      */     
/* 2846 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2864 */     checkColumnBounds(columnIndex);
/*      */     
/* 2866 */     int scale = this.fields[(columnIndex - 1)].getDecimals();
/*      */     
/* 2868 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 2886 */     checkColumnBounds(columnIndex);
/*      */     
/* 2888 */     String stringVal = null;
/*      */     
/* 2890 */     Field f = this.fields[(columnIndex - 1)];
/*      */     
/* 2892 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 2894 */     if (value == null) {
/* 2895 */       this.wasNullFlag = true;
/*      */       
/* 2897 */       return null;
/*      */     }
/*      */     
/* 2900 */     this.wasNullFlag = false;
/*      */     
/* 2902 */     switch (f.getSQLType()) {
/*      */     case 2: 
/*      */     case 3: 
/* 2905 */       stringVal = StringUtils.toAsciiString((byte[])value);
/* 2906 */       break;
/*      */     default: 
/* 2908 */       stringVal = getNativeString(columnIndex);
/*      */     }
/*      */     
/* 2911 */     return getBigDecimalFromString(stringVal, columnIndex, scale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getNativeBinaryStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2932 */     checkRowPos();
/*      */     
/* 2934 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 2936 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2937 */       this.wasNullFlag = true;
/*      */       
/* 2939 */       return null;
/*      */     }
/*      */     
/* 2942 */     this.wasNullFlag = false;
/*      */     
/* 2944 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */     case -7: 
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/*      */     case 2004: 
/* 2950 */       return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     }
/*      */     
/* 2953 */     byte[] b = getNativeBytes(columnIndex, false);
/*      */     
/* 2955 */     if (b != null) {
/* 2956 */       return new ByteArrayInputStream(b);
/*      */     }
/*      */     
/* 2959 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected java.sql.Blob getNativeBlob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2974 */     checkRowPos();
/*      */     
/* 2976 */     checkColumnBounds(columnIndex);
/*      */     
/* 2978 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 2980 */     if (value == null) {
/* 2981 */       this.wasNullFlag = true;
/*      */     } else {
/* 2983 */       this.wasNullFlag = false;
/*      */     }
/*      */     
/* 2986 */     if (this.wasNullFlag) {
/* 2987 */       return null;
/*      */     }
/*      */     
/* 2990 */     int mysqlType = this.fields[(columnIndex - 1)].getMysqlType();
/*      */     
/* 2992 */     byte[] dataAsBytes = null;
/*      */     
/* 2994 */     switch (mysqlType) {
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/* 2999 */       dataAsBytes = (byte[])value;
/* 3000 */       break;
/*      */     
/*      */     default: 
/* 3003 */       dataAsBytes = getNativeBytes(columnIndex, false);
/*      */     }
/*      */     
/* 3006 */     if (!this.connection.getEmulateLocators()) {
/* 3007 */       return new Blob(dataAsBytes, getExceptionInterceptor());
/*      */     }
/*      */     
/* 3010 */     return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public static boolean arraysEqual(byte[] left, byte[] right) {
/* 3014 */     if (left == null) {
/* 3015 */       return right == null;
/*      */     }
/* 3017 */     if (right == null) {
/* 3018 */       return false;
/*      */     }
/* 3020 */     if (left.length != right.length) {
/* 3021 */       return false;
/*      */     }
/* 3023 */     for (int i = 0; i < left.length; i++) {
/* 3024 */       if (left[i] != right[i]) {
/* 3025 */         return false;
/*      */       }
/*      */     }
/* 3028 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte getNativeByte(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3043 */     return getNativeByte(columnIndex, true);
/*      */   }
/*      */   
/*      */   protected byte getNativeByte(int columnIndex, boolean overflowCheck) throws SQLException {
/* 3047 */     checkRowPos();
/*      */     
/* 3049 */     checkColumnBounds(columnIndex);
/*      */     
/* 3051 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3053 */     if (value == null) {
/* 3054 */       this.wasNullFlag = true;
/*      */       
/* 3056 */       return 0;
/*      */     }
/*      */     
/* 3059 */     this.wasNullFlag = false;
/*      */     
/* 3061 */     columnIndex--;
/*      */     
/* 3063 */     Field field = this.fields[columnIndex];
/*      */     long valueAsLong;
/* 3065 */     short valueAsShort; switch (field.getMysqlType()) {
/*      */     case 16: 
/* 3067 */       valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       
/* 3069 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((valueAsLong < -128L) || (valueAsLong > 127L))) {
/* 3070 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */       }
/*      */       
/* 3073 */       return (byte)(int)valueAsLong;
/*      */     case 1: 
/* 3075 */       byte valueAsByte = ((byte[])(byte[])value)[0];
/*      */       
/* 3077 */       if (!field.isUnsigned()) {
/* 3078 */         return valueAsByte;
/*      */       }
/*      */       
/* 3081 */       valueAsShort = valueAsByte >= 0 ? (short)valueAsByte : (short)(valueAsByte + 256);
/*      */       
/* 3083 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && 
/* 3084 */         (valueAsShort > 127)) {
/* 3085 */         throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/* 3089 */       return (byte)valueAsShort;
/*      */     
/*      */     case 2: 
/*      */     case 13: 
/* 3093 */       valueAsShort = getNativeShort(columnIndex + 1);
/*      */       
/* 3095 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3096 */         (valueAsShort < -128) || (valueAsShort > 127))) {
/* 3097 */         throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/* 3101 */       return (byte)valueAsShort;
/*      */     case 3: 
/*      */     case 9: 
/* 3104 */       int valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */       
/* 3106 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3107 */         (valueAsInt < -128) || (valueAsInt > 127))) {
/* 3108 */         throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/* 3112 */       return (byte)valueAsInt;
/*      */     
/*      */     case 4: 
/* 3115 */       float valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */       
/* 3117 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3118 */         (valueAsFloat < -128.0F) || (valueAsFloat > 127.0F)))
/*      */       {
/* 3120 */         throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/* 3124 */       return (byte)(int)valueAsFloat;
/*      */     
/*      */     case 5: 
/* 3127 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 3129 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3130 */         (valueAsDouble < -128.0D) || (valueAsDouble > 127.0D))) {
/* 3131 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/* 3135 */       return (byte)(int)valueAsDouble;
/*      */     
/*      */     case 8: 
/* 3138 */       valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */       
/* 3140 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3141 */         (valueAsLong < -128L) || (valueAsLong > 127L))) {
/* 3142 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/* 3146 */       return (byte)(int)valueAsLong;
/*      */     }
/*      */     
/* 3149 */     if (this.useUsageAdvisor) {
/* 3150 */       issueConversionViaParsingWarning("getByte()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3155 */     return getByteFromString(getNativeString(columnIndex + 1), columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] getNativeBytes(int columnIndex, boolean noConversion)
/*      */     throws SQLException
/*      */   {
/* 3175 */     checkRowPos();
/*      */     
/* 3177 */     checkColumnBounds(columnIndex);
/*      */     
/* 3179 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3181 */     if (value == null) {
/* 3182 */       this.wasNullFlag = true;
/*      */     } else {
/* 3184 */       this.wasNullFlag = false;
/*      */     }
/*      */     
/* 3187 */     if (this.wasNullFlag) {
/* 3188 */       return null;
/*      */     }
/*      */     
/* 3191 */     Field field = this.fields[(columnIndex - 1)];
/*      */     
/* 3193 */     int mysqlType = field.getMysqlType();
/*      */     
/*      */ 
/* 3196 */     if (noConversion) {
/* 3197 */       mysqlType = 252;
/*      */     }
/*      */     
/* 3200 */     switch (mysqlType) {
/*      */     case 16: 
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/* 3206 */       return (byte[])value;
/*      */     
/*      */     case 15: 
/*      */     case 253: 
/*      */     case 254: 
/* 3211 */       if ((value instanceof byte[])) {
/* 3212 */         return (byte[])value;
/*      */       }
/*      */       break;
/*      */     }
/* 3216 */     int sqlType = field.getSQLType();
/*      */     
/* 3218 */     if ((sqlType == -3) || (sqlType == -2)) {
/* 3219 */       return (byte[])value;
/*      */     }
/*      */     
/* 3222 */     return getBytesFromString(getNativeString(columnIndex));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Reader getNativeCharacterStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3242 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3244 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 12: 
/*      */     case 2005: 
/* 3249 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 3250 */         this.wasNullFlag = true;
/*      */         
/* 3252 */         return null;
/*      */       }
/*      */       
/* 3255 */       this.wasNullFlag = false;
/*      */       
/* 3257 */       return this.thisRow.getReader(columnIndexMinusOne);
/*      */     }
/*      */     
/* 3260 */     String asString = getStringForClob(columnIndex);
/*      */     
/* 3262 */     if (asString == null) {
/* 3263 */       return null;
/*      */     }
/*      */     
/* 3266 */     return getCharacterStreamFromString(asString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected java.sql.Clob getNativeClob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3281 */     String stringVal = getStringForClob(columnIndex);
/*      */     
/* 3283 */     if (stringVal == null) {
/* 3284 */       return null;
/*      */     }
/*      */     
/* 3287 */     return getClobFromString(stringVal);
/*      */   }
/*      */   
/*      */   private String getNativeConvertToString(int columnIndex, Field field) throws SQLException {
/* 3291 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 3293 */       int sqlType = field.getSQLType();
/* 3294 */       int mysqlType = field.getMysqlType();
/*      */       int intVal;
/* 3296 */       long longVal; switch (sqlType) {
/*      */       case -7: 
/* 3298 */         return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */       case 16: 
/* 3300 */         boolean booleanVal = getBoolean(columnIndex);
/*      */         
/* 3302 */         if (this.wasNullFlag) {
/* 3303 */           return null;
/*      */         }
/*      */         
/* 3306 */         return String.valueOf(booleanVal);
/*      */       
/*      */       case -6: 
/* 3309 */         byte tinyintVal = getNativeByte(columnIndex, false);
/*      */         
/* 3311 */         if (this.wasNullFlag) {
/* 3312 */           return null;
/*      */         }
/*      */         
/* 3315 */         if ((!field.isUnsigned()) || (tinyintVal >= 0)) {
/* 3316 */           return String.valueOf(tinyintVal);
/*      */         }
/*      */         
/* 3319 */         short unsignedTinyVal = (short)(tinyintVal & 0xFF);
/*      */         
/* 3321 */         return String.valueOf(unsignedTinyVal);
/*      */       
/*      */ 
/*      */       case 5: 
/* 3325 */         intVal = getNativeInt(columnIndex, false);
/*      */         
/* 3327 */         if (this.wasNullFlag) {
/* 3328 */           return null;
/*      */         }
/*      */         
/* 3331 */         if ((!field.isUnsigned()) || (intVal >= 0)) {
/* 3332 */           return String.valueOf(intVal);
/*      */         }
/*      */         
/* 3335 */         intVal &= 0xFFFF;
/*      */         
/* 3337 */         return String.valueOf(intVal);
/*      */       
/*      */       case 4: 
/* 3340 */         intVal = getNativeInt(columnIndex, false);
/*      */         
/* 3342 */         if (this.wasNullFlag) {
/* 3343 */           return null;
/*      */         }
/*      */         
/* 3346 */         if ((!field.isUnsigned()) || (intVal >= 0) || (field.getMysqlType() == 9))
/*      */         {
/* 3348 */           return String.valueOf(intVal);
/*      */         }
/*      */         
/* 3351 */         longVal = intVal & 0xFFFFFFFF;
/*      */         
/* 3353 */         return String.valueOf(longVal);
/*      */       
/*      */ 
/*      */       case -5: 
/* 3357 */         if (!field.isUnsigned()) {
/* 3358 */           longVal = getNativeLong(columnIndex, false, true);
/*      */           
/* 3360 */           if (this.wasNullFlag) {
/* 3361 */             return null;
/*      */           }
/*      */           
/* 3364 */           return String.valueOf(longVal);
/*      */         }
/*      */         
/* 3367 */         long longVal = getNativeLong(columnIndex, false, false);
/*      */         
/* 3369 */         if (this.wasNullFlag) {
/* 3370 */           return null;
/*      */         }
/*      */         
/* 3373 */         return String.valueOf(convertLongToUlong(longVal));
/*      */       case 7: 
/* 3375 */         float floatVal = getNativeFloat(columnIndex);
/*      */         
/* 3377 */         if (this.wasNullFlag) {
/* 3378 */           return null;
/*      */         }
/*      */         
/* 3381 */         return String.valueOf(floatVal);
/*      */       
/*      */       case 6: 
/*      */       case 8: 
/* 3385 */         double doubleVal = getNativeDouble(columnIndex);
/*      */         
/* 3387 */         if (this.wasNullFlag) {
/* 3388 */           return null;
/*      */         }
/*      */         
/* 3391 */         return String.valueOf(doubleVal);
/*      */       
/*      */       case 2: 
/*      */       case 3: 
/* 3395 */         String stringVal = StringUtils.toAsciiString(this.thisRow.getColumnValue(columnIndex - 1));
/*      */         
/*      */ 
/*      */ 
/* 3399 */         if (stringVal != null) {
/* 3400 */           this.wasNullFlag = false;
/*      */           
/* 3402 */           if (stringVal.length() == 0) {
/* 3403 */             BigDecimal val = new BigDecimal(0);
/*      */             
/* 3405 */             return val.toString();
/*      */           }
/*      */           BigDecimal val;
/*      */           try {
/* 3409 */             val = new BigDecimal(stringVal);
/*      */           } catch (NumberFormatException ex) {
/* 3411 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3416 */           return val.toString();
/*      */         }
/*      */         
/* 3419 */         this.wasNullFlag = true;
/*      */         
/* 3421 */         return null;
/*      */       
/*      */ 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 3427 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */       
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/* 3432 */         if (!field.isBlob())
/* 3433 */           return extractStringFromNativeColumn(columnIndex, mysqlType);
/* 3434 */         if (!field.isBinary()) {
/* 3435 */           return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */         }
/* 3437 */         byte[] data = getBytes(columnIndex);
/* 3438 */         Object obj = data;
/*      */         
/* 3440 */         if ((data != null) && (data.length >= 2)) {
/* 3441 */           if ((data[0] == -84) && (data[1] == -19)) {
/*      */             try
/*      */             {
/* 3444 */               ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/* 3445 */               ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/* 3446 */               obj = objIn.readObject();
/* 3447 */               objIn.close();
/* 3448 */               bytesIn.close();
/*      */             } catch (ClassNotFoundException cnfe) {
/* 3450 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */             }
/*      */             catch (IOException ex)
/*      */             {
/* 3454 */               obj = data;
/*      */             }
/*      */           }
/*      */           
/* 3458 */           return obj.toString();
/*      */         }
/*      */         
/* 3461 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 91: 
/* 3467 */         if (mysqlType == 13) {
/* 3468 */           short shortVal = getNativeShort(columnIndex);
/*      */           
/* 3470 */           if (!this.connection.getYearIsDateType())
/*      */           {
/* 3472 */             if (this.wasNullFlag) {
/* 3473 */               return null;
/*      */             }
/*      */             
/* 3476 */             return String.valueOf(shortVal);
/*      */           }
/*      */           
/* 3479 */           if (field.getLength() == 2L)
/*      */           {
/* 3481 */             if (shortVal <= 69) {
/* 3482 */               shortVal = (short)(shortVal + 100);
/*      */             }
/*      */             
/* 3485 */             shortVal = (short)(shortVal + 1900);
/*      */           }
/*      */           
/* 3488 */           return fastDateCreate(null, shortVal, 1, 1).toString();
/*      */         }
/*      */         
/*      */ 
/* 3492 */         if (this.connection.getNoDatetimeStringSync()) {
/* 3493 */           byte[] asBytes = getNativeBytes(columnIndex, true);
/*      */           
/* 3495 */           if (asBytes == null) {
/* 3496 */             return null;
/*      */           }
/*      */           
/* 3499 */           if (asBytes.length == 0)
/*      */           {
/*      */ 
/*      */ 
/* 3503 */             return "0000-00-00";
/*      */           }
/*      */           
/* 3506 */           int year = asBytes[0] & 0xFF | (asBytes[1] & 0xFF) << 8;
/* 3507 */           int month = asBytes[2];
/* 3508 */           int day = asBytes[3];
/*      */           
/* 3510 */           if ((year == 0) && (month == 0) && (day == 0)) {
/* 3511 */             return "0000-00-00";
/*      */           }
/*      */         }
/*      */         
/* 3515 */         Date dt = getNativeDate(columnIndex);
/*      */         
/* 3517 */         if (dt == null) {
/* 3518 */           return null;
/*      */         }
/*      */         
/* 3521 */         return String.valueOf(dt);
/*      */       
/*      */       case 92: 
/* 3524 */         Time tm = getNativeTime(columnIndex, null, this.connection.getDefaultTimeZone(), false);
/*      */         
/* 3526 */         if (tm == null) {
/* 3527 */           return null;
/*      */         }
/*      */         
/* 3530 */         return String.valueOf(tm);
/*      */       
/*      */       case 93: 
/* 3533 */         if (this.connection.getNoDatetimeStringSync()) {
/* 3534 */           byte[] asBytes = getNativeBytes(columnIndex, true);
/*      */           
/* 3536 */           if (asBytes == null) {
/* 3537 */             return null;
/*      */           }
/*      */           
/* 3540 */           if (asBytes.length == 0)
/*      */           {
/*      */ 
/*      */ 
/* 3544 */             return "0000-00-00 00:00:00";
/*      */           }
/*      */           
/* 3547 */           int year = asBytes[0] & 0xFF | (asBytes[1] & 0xFF) << 8;
/* 3548 */           int month = asBytes[2];
/* 3549 */           int day = asBytes[3];
/*      */           
/* 3551 */           if ((year == 0) && (month == 0) && (day == 0)) {
/* 3552 */             return "0000-00-00 00:00:00";
/*      */           }
/*      */         }
/*      */         
/* 3556 */         Timestamp tstamp = getNativeTimestamp(columnIndex, null, this.connection.getDefaultTimeZone(), false);
/*      */         
/* 3558 */         if (tstamp == null) {
/* 3559 */           return null;
/*      */         }
/*      */         
/* 3562 */         String result = String.valueOf(tstamp);
/*      */         
/* 3564 */         if (!this.connection.getNoDatetimeStringSync()) {
/* 3565 */           return result;
/*      */         }
/*      */         
/* 3568 */         if (result.endsWith(".0")) {
/* 3569 */           return result.substring(0, result.length() - 2);
/*      */         }
/*      */         break;
/*      */       }
/* 3573 */       return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getNativeDate(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3590 */     return getNativeDate(columnIndex, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getNativeDate(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 3610 */     checkRowPos();
/* 3611 */     checkColumnBounds(columnIndex);
/*      */     
/* 3613 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3615 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 3617 */     Date dateToReturn = null;
/*      */     
/* 3619 */     if (mysqlType == 10)
/*      */     {
/* 3621 */       dateToReturn = this.thisRow.getNativeDate(columnIndexMinusOne, this.connection, this, cal);
/*      */     } else {
/* 3623 */       TimeZone tz = cal != null ? cal.getTimeZone() : getDefaultTimeZone();
/*      */       
/* 3625 */       boolean rollForward = (tz != null) && (!tz.equals(getDefaultTimeZone()));
/*      */       
/* 3627 */       dateToReturn = (Date)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 91, mysqlType, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3635 */     if (dateToReturn == null)
/*      */     {
/* 3637 */       this.wasNullFlag = true;
/*      */       
/* 3639 */       return null;
/*      */     }
/*      */     
/* 3642 */     this.wasNullFlag = false;
/*      */     
/* 3644 */     return dateToReturn;
/*      */   }
/*      */   
/*      */   Date getNativeDateViaParseConversion(int columnIndex) throws SQLException {
/* 3648 */     if (this.useUsageAdvisor) {
/* 3649 */       issueConversionViaParsingWarning("getDate()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[(columnIndex - 1)], new int[] { 10 });
/*      */     }
/*      */     
/*      */ 
/* 3653 */     String stringVal = getNativeString(columnIndex);
/*      */     
/* 3655 */     return getDateFromString(stringVal, columnIndex, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double getNativeDouble(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3670 */     checkRowPos();
/* 3671 */     checkColumnBounds(columnIndex);
/*      */     
/* 3673 */     columnIndex--;
/*      */     
/* 3675 */     if (this.thisRow.isNull(columnIndex)) {
/* 3676 */       this.wasNullFlag = true;
/*      */       
/* 3678 */       return 0.0D;
/*      */     }
/*      */     
/* 3681 */     this.wasNullFlag = false;
/*      */     
/* 3683 */     Field f = this.fields[columnIndex];
/*      */     
/* 3685 */     switch (f.getMysqlType()) {
/*      */     case 5: 
/* 3687 */       return this.thisRow.getNativeDouble(columnIndex);
/*      */     case 1: 
/* 3689 */       if (!f.isUnsigned()) {
/* 3690 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */       
/* 3693 */       return getNativeShort(columnIndex + 1);
/*      */     case 2: 
/*      */     case 13: 
/* 3696 */       if (!f.isUnsigned()) {
/* 3697 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */       
/* 3700 */       return getNativeInt(columnIndex + 1);
/*      */     case 3: 
/*      */     case 9: 
/* 3703 */       if (!f.isUnsigned()) {
/* 3704 */         return getNativeInt(columnIndex + 1);
/*      */       }
/*      */       
/* 3707 */       return getNativeLong(columnIndex + 1);
/*      */     case 8: 
/* 3709 */       long valueAsLong = getNativeLong(columnIndex + 1);
/*      */       
/* 3711 */       if (!f.isUnsigned()) {
/* 3712 */         return valueAsLong;
/*      */       }
/*      */       
/* 3715 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/*      */ 
/*      */ 
/* 3719 */       return asBigInt.doubleValue();
/*      */     case 4: 
/* 3721 */       return getNativeFloat(columnIndex + 1);
/*      */     case 16: 
/* 3723 */       return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     }
/* 3725 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 3727 */     if (this.useUsageAdvisor) {
/* 3728 */       issueConversionViaParsingWarning("getDouble()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3733 */     return getDoubleFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float getNativeFloat(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3749 */     checkRowPos();
/* 3750 */     checkColumnBounds(columnIndex);
/*      */     
/* 3752 */     columnIndex--;
/*      */     
/* 3754 */     if (this.thisRow.isNull(columnIndex)) {
/* 3755 */       this.wasNullFlag = true;
/*      */       
/* 3757 */       return 0.0F;
/*      */     }
/*      */     
/* 3760 */     this.wasNullFlag = false;
/*      */     
/* 3762 */     Field f = this.fields[columnIndex];
/*      */     long valueAsLong;
/* 3764 */     switch (f.getMysqlType()) {
/*      */     case 16: 
/* 3766 */       valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       
/* 3768 */       return (float)valueAsLong;
/*      */     
/*      */ 
/*      */ 
/*      */     case 5: 
/* 3773 */       Double valueAsDouble = new Double(getNativeDouble(columnIndex + 1));
/*      */       
/* 3775 */       float valueAsFloat = valueAsDouble.floatValue();
/*      */       
/* 3777 */       if (((this.jdbcCompliantTruncationForReads) && (valueAsFloat == Float.NEGATIVE_INFINITY)) || (valueAsFloat == Float.POSITIVE_INFINITY)) {
/* 3778 */         throwRangeException(valueAsDouble.toString(), columnIndex + 1, 6);
/*      */       }
/*      */       
/* 3781 */       return (float)getNativeDouble(columnIndex + 1);
/*      */     case 1: 
/* 3783 */       if (!f.isUnsigned()) {
/* 3784 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */       
/* 3787 */       return getNativeShort(columnIndex + 1);
/*      */     case 2: 
/*      */     case 13: 
/* 3790 */       if (!f.isUnsigned()) {
/* 3791 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */       
/* 3794 */       return getNativeInt(columnIndex + 1);
/*      */     case 3: 
/*      */     case 9: 
/* 3797 */       if (!f.isUnsigned()) {
/* 3798 */         return getNativeInt(columnIndex + 1);
/*      */       }
/*      */       
/* 3801 */       return (float)getNativeLong(columnIndex + 1);
/*      */     case 8: 
/* 3803 */       valueAsLong = getNativeLong(columnIndex + 1);
/*      */       
/* 3805 */       if (!f.isUnsigned()) {
/* 3806 */         return (float)valueAsLong;
/*      */       }
/*      */       
/* 3809 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/*      */ 
/*      */ 
/* 3813 */       return asBigInt.floatValue();
/*      */     
/*      */     case 4: 
/* 3816 */       return this.thisRow.getNativeFloat(columnIndex);
/*      */     }
/*      */     
/* 3819 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 3821 */     if (this.useUsageAdvisor) {
/* 3822 */       issueConversionViaParsingWarning("getFloat()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3827 */     return getFloatFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getNativeInt(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3843 */     return getNativeInt(columnIndex, true);
/*      */   }
/*      */   
/*      */   protected int getNativeInt(int columnIndex, boolean overflowCheck) throws SQLException {
/* 3847 */     checkRowPos();
/* 3848 */     checkColumnBounds(columnIndex);
/*      */     
/* 3850 */     columnIndex--;
/*      */     
/* 3852 */     if (this.thisRow.isNull(columnIndex)) {
/* 3853 */       this.wasNullFlag = true;
/*      */       
/* 3855 */       return 0;
/*      */     }
/*      */     
/* 3858 */     this.wasNullFlag = false;
/*      */     
/* 3860 */     Field f = this.fields[columnIndex];
/*      */     long valueAsLong;
/* 3862 */     double valueAsDouble; switch (f.getMysqlType()) {
/*      */     case 16: 
/* 3864 */       valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       
/* 3866 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))) {
/* 3867 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */       
/* 3870 */       return (short)(int)valueAsLong;
/*      */     case 1: 
/* 3872 */       byte tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */       
/* 3874 */       if ((!f.isUnsigned()) || (tinyintVal >= 0)) {
/* 3875 */         return tinyintVal;
/*      */       }
/*      */       
/* 3878 */       return tinyintVal + 256;
/*      */     case 2: 
/*      */     case 13: 
/* 3881 */       short asShort = getNativeShort(columnIndex + 1, false);
/*      */       
/* 3883 */       if ((!f.isUnsigned()) || (asShort >= 0)) {
/* 3884 */         return asShort;
/*      */       }
/*      */       
/* 3887 */       return asShort + 65536;
/*      */     
/*      */     case 3: 
/*      */     case 9: 
/* 3891 */       int valueAsInt = this.thisRow.getNativeInt(columnIndex);
/*      */       
/* 3893 */       if (!f.isUnsigned()) {
/* 3894 */         return valueAsInt;
/*      */       }
/*      */       
/* 3897 */       valueAsLong = valueAsInt >= 0 ? valueAsInt : valueAsInt + 4294967296L;
/*      */       
/* 3899 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsLong > 2147483647L)) {
/* 3900 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */       
/* 3903 */       return (int)valueAsLong;
/*      */     case 8: 
/* 3905 */       valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */       
/* 3907 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3908 */         (valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))) {
/* 3909 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/* 3913 */       return (int)valueAsLong;
/*      */     case 5: 
/* 3915 */       valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 3917 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3918 */         (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D))) {
/* 3919 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/* 3923 */       return (int)valueAsDouble;
/*      */     case 4: 
/* 3925 */       valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */       
/* 3927 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3928 */         (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D))) {
/* 3929 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/* 3933 */       return (int)valueAsDouble;
/*      */     }
/*      */     
/* 3936 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 3938 */     if (this.useUsageAdvisor) {
/* 3939 */       issueConversionViaParsingWarning("getInt()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3944 */     return getIntFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long getNativeLong(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3960 */     return getNativeLong(columnIndex, true, true);
/*      */   }
/*      */   
/*      */   protected long getNativeLong(int columnIndex, boolean overflowCheck, boolean expandUnsignedLong) throws SQLException {
/* 3964 */     checkRowPos();
/* 3965 */     checkColumnBounds(columnIndex);
/*      */     
/* 3967 */     columnIndex--;
/*      */     
/* 3969 */     if (this.thisRow.isNull(columnIndex)) {
/* 3970 */       this.wasNullFlag = true;
/*      */       
/* 3972 */       return 0L;
/*      */     }
/*      */     
/* 3975 */     this.wasNullFlag = false;
/*      */     
/* 3977 */     Field f = this.fields[columnIndex];
/*      */     double valueAsDouble;
/* 3979 */     switch (f.getMysqlType()) {
/*      */     case 16: 
/* 3981 */       return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     case 1: 
/* 3983 */       if (!f.isUnsigned()) {
/* 3984 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */       
/* 3987 */       return getNativeInt(columnIndex + 1);
/*      */     case 2: 
/* 3989 */       if (!f.isUnsigned()) {
/* 3990 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */       
/* 3993 */       return getNativeInt(columnIndex + 1, false);
/*      */     
/*      */     case 13: 
/* 3996 */       return getNativeShort(columnIndex + 1);
/*      */     case 3: 
/*      */     case 9: 
/* 3999 */       int asInt = getNativeInt(columnIndex + 1, false);
/*      */       
/* 4001 */       if ((!f.isUnsigned()) || (asInt >= 0)) {
/* 4002 */         return asInt;
/*      */       }
/*      */       
/* 4005 */       return asInt + 4294967296L;
/*      */     case 8: 
/* 4007 */       long valueAsLong = this.thisRow.getNativeLong(columnIndex);
/*      */       
/* 4009 */       if ((!f.isUnsigned()) || (!expandUnsignedLong)) {
/* 4010 */         return valueAsLong;
/*      */       }
/*      */       
/* 4013 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/* 4015 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((asBigInt.compareTo(new BigInteger(String.valueOf(Long.MAX_VALUE))) > 0) || (asBigInt.compareTo(new BigInteger(String.valueOf(Long.MIN_VALUE))) < 0)))
/*      */       {
/*      */ 
/*      */ 
/* 4019 */         throwRangeException(asBigInt.toString(), columnIndex + 1, -5);
/*      */       }
/*      */       
/* 4022 */       return getLongFromString(asBigInt.toString(), columnIndex);
/*      */     
/*      */     case 5: 
/* 4025 */       valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 4027 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4028 */         (valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D))) {
/* 4029 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */       }
/*      */       
/*      */ 
/* 4033 */       return valueAsDouble;
/*      */     case 4: 
/* 4035 */       valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */       
/* 4037 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4038 */         (valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D))) {
/* 4039 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */       }
/*      */       
/*      */ 
/* 4043 */       return valueAsDouble;
/*      */     }
/* 4045 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4047 */     if (this.useUsageAdvisor) {
/* 4048 */       issueConversionViaParsingWarning("getLong()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4053 */     return getLongFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Ref getNativeRef(int i)
/*      */     throws SQLException
/*      */   {
/* 4070 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected short getNativeShort(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4085 */     return getNativeShort(columnIndex, true);
/*      */   }
/*      */   
/*      */   protected short getNativeShort(int columnIndex, boolean overflowCheck) throws SQLException {
/* 4089 */     checkRowPos();
/* 4090 */     checkColumnBounds(columnIndex);
/*      */     
/* 4092 */     columnIndex--;
/*      */     
/* 4094 */     if (this.thisRow.isNull(columnIndex)) {
/* 4095 */       this.wasNullFlag = true;
/*      */       
/* 4097 */       return 0;
/*      */     }
/*      */     
/* 4100 */     this.wasNullFlag = false;
/*      */     
/* 4102 */     Field f = this.fields[columnIndex];
/*      */     int valueAsInt;
/* 4104 */     long valueAsLong; switch (f.getMysqlType())
/*      */     {
/*      */     case 1: 
/* 4107 */       byte tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */       
/* 4109 */       if ((!f.isUnsigned()) || (tinyintVal >= 0)) {
/* 4110 */         return (short)tinyintVal;
/*      */       }
/*      */       
/* 4113 */       return (short)(tinyintVal + 256);
/*      */     
/*      */     case 2: 
/*      */     case 13: 
/* 4117 */       short asShort = this.thisRow.getNativeShort(columnIndex);
/*      */       
/* 4119 */       if (!f.isUnsigned()) {
/* 4120 */         return asShort;
/*      */       }
/*      */       
/* 4123 */       valueAsInt = asShort & 0xFFFF;
/*      */       
/* 4125 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsInt > 32767)) {
/* 4126 */         throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */       }
/*      */       
/* 4129 */       return (short)valueAsInt;
/*      */     case 3: 
/*      */     case 9: 
/* 4132 */       if (!f.isUnsigned()) {
/* 4133 */         valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */         
/* 4135 */         if (((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsInt > 32767)) || (valueAsInt < 32768)) {
/* 4136 */           throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */         }
/*      */         
/* 4139 */         return (short)valueAsInt;
/*      */       }
/*      */       
/* 4142 */       valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */       
/* 4144 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsLong > 32767L)) {
/* 4145 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */       }
/*      */       
/* 4148 */       return (short)(int)valueAsLong;
/*      */     
/*      */     case 8: 
/* 4151 */       valueAsLong = getNativeLong(columnIndex + 1, false, false);
/*      */       
/* 4153 */       if (!f.isUnsigned()) {
/* 4154 */         if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4155 */           (valueAsLong < -32768L) || (valueAsLong > 32767L))) {
/* 4156 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */         }
/*      */         
/*      */ 
/* 4160 */         return (short)(int)valueAsLong;
/*      */       }
/*      */       
/* 4163 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/* 4165 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((asBigInt.compareTo(new BigInteger(String.valueOf(32767))) > 0) || (asBigInt.compareTo(new BigInteger(String.valueOf(32768))) < 0)))
/*      */       {
/*      */ 
/*      */ 
/* 4169 */         throwRangeException(asBigInt.toString(), columnIndex + 1, 5);
/*      */       }
/*      */       
/* 4172 */       return (short)getIntFromString(asBigInt.toString(), columnIndex + 1);
/*      */     
/*      */     case 5: 
/* 4175 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 4177 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4178 */         (valueAsDouble < -32768.0D) || (valueAsDouble > 32767.0D))) {
/* 4179 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 5);
/*      */       }
/*      */       
/*      */ 
/* 4183 */       return (short)(int)valueAsDouble;
/*      */     case 4: 
/* 4185 */       float valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */       
/* 4187 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4188 */         (valueAsFloat < -32768.0F) || (valueAsFloat > 32767.0F))) {
/* 4189 */         throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, 5);
/*      */       }
/*      */       
/*      */ 
/* 4193 */       return (short)(int)valueAsFloat;
/*      */     }
/* 4195 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4197 */     if (this.useUsageAdvisor) {
/* 4198 */       issueConversionViaParsingWarning("getShort()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4203 */     return getShortFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getNativeString(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4219 */     checkRowPos();
/* 4220 */     checkColumnBounds(columnIndex);
/*      */     
/* 4222 */     if (this.fields == null) {
/* 4223 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_133"), "S1002", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 4227 */     if (this.thisRow.isNull(columnIndex - 1)) {
/* 4228 */       this.wasNullFlag = true;
/*      */       
/* 4230 */       return null;
/*      */     }
/*      */     
/* 4233 */     this.wasNullFlag = false;
/*      */     
/* 4235 */     String stringVal = null;
/*      */     
/* 4237 */     Field field = this.fields[(columnIndex - 1)];
/*      */     
/*      */ 
/* 4240 */     stringVal = getNativeConvertToString(columnIndex, field);
/* 4241 */     int mysqlType = field.getMysqlType();
/*      */     
/* 4243 */     if ((mysqlType != 7) && (mysqlType != 10) && (field.isZeroFill()) && (stringVal != null)) {
/* 4244 */       int origLength = stringVal.length();
/*      */       
/* 4246 */       StringBuilder zeroFillBuf = new StringBuilder(origLength);
/*      */       
/* 4248 */       long numZeros = field.getLength() - origLength;
/*      */       
/* 4250 */       for (long i = 0L; i < numZeros; i += 1L) {
/* 4251 */         zeroFillBuf.append('0');
/*      */       }
/*      */       
/* 4254 */       zeroFillBuf.append(stringVal);
/*      */       
/* 4256 */       stringVal = zeroFillBuf.toString();
/*      */     }
/*      */     
/* 4259 */     return stringVal;
/*      */   }
/*      */   
/*      */   private Time getNativeTime(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4263 */     checkRowPos();
/* 4264 */     checkColumnBounds(columnIndex);
/*      */     
/* 4266 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4268 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4270 */     Time timeVal = null;
/*      */     
/* 4272 */     if (mysqlType == 11) {
/* 4273 */       timeVal = this.thisRow.getNativeTime(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */     }
/*      */     else {
/* 4276 */       timeVal = (Time)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 92, mysqlType, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4284 */     if (timeVal == null)
/*      */     {
/* 4286 */       this.wasNullFlag = true;
/*      */       
/* 4288 */       return null;
/*      */     }
/*      */     
/* 4291 */     this.wasNullFlag = false;
/*      */     
/* 4293 */     return timeVal;
/*      */   }
/*      */   
/*      */   Time getNativeTimeViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4297 */     if (this.useUsageAdvisor) {
/* 4298 */       issueConversionViaParsingWarning("getTime()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[(columnIndex - 1)], new int[] { 11 });
/*      */     }
/*      */     
/*      */ 
/* 4302 */     String strTime = getNativeString(columnIndex);
/*      */     
/* 4304 */     return getTimeFromString(strTime, targetCalendar, columnIndex, tz, rollForward);
/*      */   }
/*      */   
/*      */   private Timestamp getNativeTimestamp(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4308 */     checkRowPos();
/* 4309 */     checkColumnBounds(columnIndex);
/*      */     
/* 4311 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4313 */     Timestamp tsVal = null;
/*      */     
/* 4315 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4317 */     switch (mysqlType) {
/*      */     case 7: 
/*      */     case 12: 
/* 4320 */       tsVal = this.thisRow.getNativeTimestamp(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/* 4321 */       break;
/*      */     
/*      */ 
/*      */     default: 
/* 4325 */       tsVal = (Timestamp)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 93, mysqlType, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4334 */     if (tsVal == null)
/*      */     {
/* 4336 */       this.wasNullFlag = true;
/*      */       
/* 4338 */       return null;
/*      */     }
/*      */     
/* 4341 */     this.wasNullFlag = false;
/*      */     
/* 4343 */     return tsVal;
/*      */   }
/*      */   
/*      */   Timestamp getNativeTimestampViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4347 */     if (this.useUsageAdvisor) {
/* 4348 */       issueConversionViaParsingWarning("getTimestamp()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[(columnIndex - 1)], new int[] { 7, 12 });
/*      */     }
/*      */     
/*      */ 
/* 4352 */     String strTimestamp = getNativeString(columnIndex);
/*      */     
/* 4354 */     return getTimestampFromString(columnIndex, targetCalendar, strTimestamp, tz, rollForward);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getNativeUnicodeStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4379 */     checkRowPos();
/*      */     
/* 4381 */     return getBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */   protected URL getNativeURL(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 4388 */     String val = getString(colIndex);
/*      */     
/* 4390 */     if (val == null) {
/* 4391 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 4395 */       return new URL(val);
/*      */     } catch (MalformedURLException mfe) {
/* 4397 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____141") + val + "'", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSetInternalMethods getNextResultSet()
/*      */   {
/* 4406 */     return this.nextResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4430 */     checkRowPos();
/* 4431 */     checkColumnBounds(columnIndex);
/*      */     
/* 4433 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4435 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 4436 */       this.wasNullFlag = true;
/*      */       
/* 4438 */       return null;
/*      */     }
/*      */     
/* 4441 */     this.wasNullFlag = false;
/*      */     
/*      */ 
/* 4444 */     Field field = this.fields[columnIndexMinusOne];
/*      */     String stringVal;
/* 4446 */     switch (field.getSQLType()) {
/*      */     case -7: 
/*      */     case 16: 
/* 4449 */       if ((field.getMysqlType() == 16) && (!field.isSingleBit())) {
/* 4450 */         return getBytes(columnIndex);
/*      */       }
/*      */       
/*      */ 
/* 4454 */       return Boolean.valueOf(getBoolean(columnIndex));
/*      */     
/*      */     case -6: 
/* 4457 */       if (!field.isUnsigned()) {
/* 4458 */         return Integer.valueOf(getByte(columnIndex));
/*      */       }
/*      */       
/* 4461 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */ 
/*      */     case 5: 
/* 4465 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */ 
/*      */     case 4: 
/* 4469 */       if ((!field.isUnsigned()) || (field.getMysqlType() == 9)) {
/* 4470 */         return Integer.valueOf(getInt(columnIndex));
/*      */       }
/*      */       
/* 4473 */       return Long.valueOf(getLong(columnIndex));
/*      */     
/*      */ 
/*      */     case -5: 
/* 4477 */       if (!field.isUnsigned()) {
/* 4478 */         return Long.valueOf(getLong(columnIndex));
/*      */       }
/*      */       
/* 4481 */       stringVal = getString(columnIndex);
/*      */       
/* 4483 */       if (stringVal == null) {
/* 4484 */         return null;
/*      */       }
/*      */       try
/*      */       {
/* 4488 */         return new BigInteger(stringVal);
/*      */       } catch (NumberFormatException nfe) {
/* 4490 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigInteger", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */     case 2: 
/*      */     case 3: 
/* 4497 */       stringVal = getString(columnIndex);
/*      */       
/*      */ 
/*      */ 
/* 4501 */       if (stringVal != null) {
/* 4502 */         if (stringVal.length() == 0) {
/* 4503 */           BigDecimal val = new BigDecimal(0);
/*      */           
/* 4505 */           return val;
/*      */         }
/*      */         BigDecimal val;
/*      */         try {
/* 4509 */           val = new BigDecimal(stringVal);
/*      */         } catch (NumberFormatException ex) {
/* 4511 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4516 */         return val;
/*      */       }
/*      */       
/* 4519 */       return null;
/*      */     
/*      */     case 7: 
/* 4522 */       return new Float(getFloat(columnIndex));
/*      */     
/*      */     case 6: 
/*      */     case 8: 
/* 4526 */       return new Double(getDouble(columnIndex));
/*      */     
/*      */     case 1: 
/*      */     case 12: 
/* 4530 */       if (!field.isOpaqueBinary()) {
/* 4531 */         return getString(columnIndex);
/*      */       }
/*      */       
/* 4534 */       return getBytes(columnIndex);
/*      */     case -1: 
/* 4536 */       if (!field.isOpaqueBinary()) {
/* 4537 */         return getStringForClob(columnIndex);
/*      */       }
/*      */       
/* 4540 */       return getBytes(columnIndex);
/*      */     
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/* 4545 */       if (field.getMysqlType() == 255)
/* 4546 */         return getBytes(columnIndex);
/* 4547 */       if ((field.isBinary()) || (field.isBlob())) {
/* 4548 */         byte[] data = getBytes(columnIndex);
/*      */         
/* 4550 */         if (this.connection.getAutoDeserialize()) {
/* 4551 */           Object obj = data;
/*      */           
/* 4553 */           if ((data != null) && (data.length >= 2)) {
/* 4554 */             if ((data[0] == -84) && (data[1] == -19)) {
/*      */               try
/*      */               {
/* 4557 */                 ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/* 4558 */                 ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/* 4559 */                 obj = objIn.readObject();
/* 4560 */                 objIn.close();
/* 4561 */                 bytesIn.close();
/*      */               } catch (ClassNotFoundException cnfe) {
/* 4563 */                 throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */               }
/*      */               catch (IOException ex)
/*      */               {
/* 4567 */                 obj = data;
/*      */               }
/*      */             } else {
/* 4570 */               return getString(columnIndex);
/*      */             }
/*      */           }
/*      */           
/* 4574 */           return obj;
/*      */         }
/*      */         
/* 4577 */         return data;
/*      */       }
/*      */       
/* 4580 */       return getBytes(columnIndex);
/*      */     
/*      */     case 91: 
/* 4583 */       if ((field.getMysqlType() == 13) && (!this.connection.getYearIsDateType())) {
/* 4584 */         return Short.valueOf(getShort(columnIndex));
/*      */       }
/*      */       
/* 4587 */       return getDate(columnIndex);
/*      */     
/*      */     case 92: 
/* 4590 */       return getTime(columnIndex);
/*      */     
/*      */     case 93: 
/* 4593 */       return getTimestamp(columnIndex);
/*      */     }
/*      */     
/* 4596 */     return getString(columnIndex);
/*      */   }
/*      */   
/*      */   public <T> T getObject(int columnIndex, Class<T> type)
/*      */     throws SQLException
/*      */   {
/* 4602 */     if (type == null) {
/* 4603 */       throw SQLError.createSQLException("Type parameter can not be null", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 4606 */     if (type.equals(String.class))
/* 4607 */       return getString(columnIndex);
/* 4608 */     if (type.equals(BigDecimal.class))
/* 4609 */       return getBigDecimal(columnIndex);
/* 4610 */     if ((type.equals(Boolean.class)) || (type.equals(Boolean.TYPE)))
/* 4611 */       return Boolean.valueOf(getBoolean(columnIndex));
/* 4612 */     if ((type.equals(Integer.class)) || (type.equals(Integer.TYPE)))
/* 4613 */       return Integer.valueOf(getInt(columnIndex));
/* 4614 */     if ((type.equals(Long.class)) || (type.equals(Long.TYPE)))
/* 4615 */       return Long.valueOf(getLong(columnIndex));
/* 4616 */     if ((type.equals(Float.class)) || (type.equals(Float.TYPE)))
/* 4617 */       return Float.valueOf(getFloat(columnIndex));
/* 4618 */     if ((type.equals(Double.class)) || (type.equals(Double.TYPE)))
/* 4619 */       return Double.valueOf(getDouble(columnIndex));
/* 4620 */     if (type.equals(byte[].class))
/* 4621 */       return getBytes(columnIndex);
/* 4622 */     if (type.equals(Date.class))
/* 4623 */       return getDate(columnIndex);
/* 4624 */     if (type.equals(Time.class))
/* 4625 */       return getTime(columnIndex);
/* 4626 */     if (type.equals(Timestamp.class))
/* 4627 */       return getTimestamp(columnIndex);
/* 4628 */     if (type.equals(Clob.class))
/* 4629 */       return getClob(columnIndex);
/* 4630 */     if (type.equals(Blob.class))
/* 4631 */       return getBlob(columnIndex);
/* 4632 */     if (type.equals(Array.class))
/* 4633 */       return getArray(columnIndex);
/* 4634 */     if (type.equals(Ref.class))
/* 4635 */       return getRef(columnIndex);
/* 4636 */     if (type.equals(URL.class)) {
/* 4637 */       return getURL(columnIndex);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4648 */     if (this.connection.getAutoDeserialize()) {
/*      */       try {
/* 4650 */         return (T)getObject(columnIndex);
/*      */       } catch (ClassCastException cce) {
/* 4652 */         SQLException sqlEx = SQLError.createSQLException("Conversion not supported for type " + type.getName(), "S1009", getExceptionInterceptor());
/*      */         
/* 4654 */         sqlEx.initCause(cce);
/*      */         
/* 4656 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */     
/* 4660 */     throw SQLError.createSQLException("Conversion not supported for type " + type.getName(), "S1009", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T getObject(String columnLabel, Class<T> type)
/*      */     throws SQLException
/*      */   {
/* 4667 */     return (T)getObject(findColumn(columnLabel), type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int i, Map<String, Class<?>> map)
/*      */     throws SQLException
/*      */   {
/* 4686 */     return getObject(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String columnName)
/*      */     throws SQLException
/*      */   {
/* 4710 */     return getObject(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String colName, Map<String, Class<?>> map)
/*      */     throws SQLException
/*      */   {
/* 4729 */     return getObject(findColumn(colName), map);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(int columnIndex, int desiredSqlType) throws SQLException {
/* 4733 */     checkRowPos();
/* 4734 */     checkColumnBounds(columnIndex);
/*      */     
/* 4736 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 4738 */     if (value == null) {
/* 4739 */       this.wasNullFlag = true;
/*      */       
/* 4741 */       return null;
/*      */     }
/*      */     
/* 4744 */     this.wasNullFlag = false;
/*      */     
/*      */ 
/* 4747 */     Field field = this.fields[(columnIndex - 1)];
/*      */     
/* 4749 */     switch (desiredSqlType)
/*      */     {
/*      */     case -7: 
/*      */     case 16: 
/* 4753 */       return Boolean.valueOf(getBoolean(columnIndex));
/*      */     
/*      */     case -6: 
/* 4756 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */     case 5: 
/* 4759 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */ 
/*      */     case 4: 
/* 4763 */       if ((!field.isUnsigned()) || (field.getMysqlType() == 9)) {
/* 4764 */         return Integer.valueOf(getInt(columnIndex));
/*      */       }
/*      */       
/* 4767 */       return Long.valueOf(getLong(columnIndex));
/*      */     
/*      */ 
/*      */     case -5: 
/* 4771 */       if (field.isUnsigned()) {
/* 4772 */         return getBigDecimal(columnIndex);
/*      */       }
/*      */       
/* 4775 */       return Long.valueOf(getLong(columnIndex));
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 3: 
/* 4780 */       String stringVal = getString(columnIndex);
/*      */       
/*      */ 
/* 4783 */       if (stringVal != null) {
/* 4784 */         if (stringVal.length() == 0) {
/* 4785 */           BigDecimal val = new BigDecimal(0);
/*      */           
/* 4787 */           return val;
/*      */         }
/*      */         BigDecimal val;
/*      */         try {
/* 4791 */           val = new BigDecimal(stringVal);
/*      */         } catch (NumberFormatException ex) {
/* 4793 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4798 */         return val;
/*      */       }
/*      */       
/* 4801 */       return null;
/*      */     
/*      */     case 7: 
/* 4804 */       return new Float(getFloat(columnIndex));
/*      */     
/*      */ 
/*      */     case 6: 
/* 4808 */       if (!this.connection.getRunningCTS13()) {
/* 4809 */         return new Double(getFloat(columnIndex));
/*      */       }
/* 4811 */       return new Float(getFloat(columnIndex));
/*      */     
/*      */ 
/*      */     case 8: 
/* 4815 */       return new Double(getDouble(columnIndex));
/*      */     
/*      */     case 1: 
/*      */     case 12: 
/* 4819 */       return getString(columnIndex);
/*      */     case -1: 
/* 4821 */       return getStringForClob(columnIndex);
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/* 4825 */       return getBytes(columnIndex);
/*      */     
/*      */     case 91: 
/* 4828 */       if ((field.getMysqlType() == 13) && (!this.connection.getYearIsDateType())) {
/* 4829 */         return Short.valueOf(getShort(columnIndex));
/*      */       }
/*      */       
/* 4832 */       return getDate(columnIndex);
/*      */     
/*      */     case 92: 
/* 4835 */       return getTime(columnIndex);
/*      */     
/*      */     case 93: 
/* 4838 */       return getTimestamp(columnIndex);
/*      */     }
/*      */     
/* 4841 */     return getString(columnIndex);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(int i, Map<Object, Object> map, int desiredSqlType) throws SQLException
/*      */   {
/* 4846 */     return getObjectStoredProc(i, desiredSqlType);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(String columnName, int desiredSqlType) throws SQLException {
/* 4850 */     return getObjectStoredProc(findColumn(columnName), desiredSqlType);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(String colName, Map<Object, Object> map, int desiredSqlType) throws SQLException {
/* 4854 */     return getObjectStoredProc(findColumn(colName), map, desiredSqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(int i)
/*      */     throws SQLException
/*      */   {
/* 4870 */     checkColumnBounds(i);
/* 4871 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(String colName)
/*      */     throws SQLException
/*      */   {
/* 4887 */     return getRef(findColumn(colName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/* 4903 */     checkClosed();
/*      */     
/* 4905 */     int currentRowNumber = this.rowData.getCurrentRowNumber();
/* 4906 */     int row = 0;
/*      */     
/*      */ 
/* 4909 */     if (!this.rowData.isDynamic()) {
/* 4910 */       if ((currentRowNumber < 0) || (this.rowData.isAfterLast()) || (this.rowData.isEmpty())) {
/* 4911 */         row = 0;
/*      */       } else {
/* 4913 */         row = currentRowNumber + 1;
/*      */       }
/*      */     }
/*      */     else {
/* 4917 */       row = currentRowNumber + 1;
/*      */     }
/*      */     
/* 4920 */     return row;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long getNumericRepresentationOfSQLBitType(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4940 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 4942 */     if ((this.fields[(columnIndex - 1)].isSingleBit()) || (((byte[])value).length == 1)) {
/* 4943 */       return ((byte[])(byte[])value)[0];
/*      */     }
/*      */     
/* 4946 */     byte[] asBytes = (byte[])value;
/*      */     
/* 4948 */     int shift = 0;
/*      */     
/* 4950 */     long[] steps = new long[asBytes.length];
/*      */     
/* 4952 */     for (int i = asBytes.length - 1; i >= 0; i--) {
/* 4953 */       steps[i] = ((asBytes[i] & 0xFF) << shift);
/* 4954 */       shift += 8;
/*      */     }
/*      */     
/* 4957 */     long valueAsLong = 0L;
/*      */     
/* 4959 */     for (int i = 0; i < asBytes.length; i++) {
/* 4960 */       valueAsLong |= steps[i];
/*      */     }
/*      */     
/* 4963 */     return valueAsLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4978 */     if (!this.isBinaryEncoded) {
/* 4979 */       checkRowPos();
/*      */       
/* 4981 */       if (this.useFastIntParsing)
/*      */       {
/* 4983 */         checkColumnBounds(columnIndex);
/*      */         
/* 4985 */         Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */         
/* 4987 */         if (value == null) {
/* 4988 */           this.wasNullFlag = true;
/*      */         } else {
/* 4990 */           this.wasNullFlag = false;
/*      */         }
/*      */         
/* 4993 */         if (this.wasNullFlag) {
/* 4994 */           return 0;
/*      */         }
/*      */         
/* 4997 */         byte[] shortAsBytes = (byte[])value;
/*      */         
/* 4999 */         if (shortAsBytes.length == 0) {
/* 5000 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5003 */         boolean needsFullParse = false;
/*      */         
/* 5005 */         for (int i = 0; i < shortAsBytes.length; i++) {
/* 5006 */           if (((char)shortAsBytes[i] == 'e') || ((char)shortAsBytes[i] == 'E')) {
/* 5007 */             needsFullParse = true;
/*      */             
/* 5009 */             break;
/*      */           }
/*      */         }
/*      */         
/* 5013 */         if (!needsFullParse) {
/*      */           try {
/* 5015 */             return parseShortWithOverflowCheck(columnIndex, shortAsBytes, null);
/*      */           }
/*      */           catch (NumberFormatException nfe) {
/*      */             try {
/* 5019 */               return parseShortAsDouble(columnIndex, StringUtils.toString(shortAsBytes));
/*      */ 
/*      */             }
/*      */             catch (NumberFormatException newNfe)
/*      */             {
/* 5024 */               if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 5025 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */                 
/* 5027 */                 if ((this.jdbcCompliantTruncationForReads) && ((valueAsLong < -32768L) || (valueAsLong > 32767L))) {
/* 5028 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */                 }
/*      */                 
/* 5031 */                 return (short)(int)valueAsLong;
/*      */               }
/*      */               
/* 5034 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + StringUtils.toString(shortAsBytes) + "'", "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 5041 */       String val = null;
/*      */       try
/*      */       {
/* 5044 */         val = getString(columnIndex);
/*      */         
/* 5046 */         if (val != null)
/*      */         {
/* 5048 */           if (val.length() == 0) {
/* 5049 */             return (short)convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 5052 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1)) {
/* 5053 */             return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */           }
/*      */           
/*      */ 
/* 5057 */           return parseShortAsDouble(columnIndex, val);
/*      */         }
/*      */         
/* 5060 */         return 0;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 5063 */           return parseShortAsDouble(columnIndex, val);
/*      */ 
/*      */         }
/*      */         catch (NumberFormatException newNfe)
/*      */         {
/* 5068 */           if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 5069 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 5071 */             if ((this.jdbcCompliantTruncationForReads) && ((valueAsLong < -32768L) || (valueAsLong > 32767L))) {
/* 5072 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */             }
/*      */             
/* 5075 */             return (short)(int)valueAsLong;
/*      */           }
/*      */           
/* 5078 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + val + "'", "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 5083 */     return getNativeShort(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5092 */     return getShort(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final short getShortFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 5097 */       if (val != null)
/*      */       {
/* 5099 */         if (val.length() == 0) {
/* 5100 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5103 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1)) {
/* 5104 */           return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */         }
/*      */         
/*      */ 
/* 5108 */         return parseShortAsDouble(columnIndex, val);
/*      */       }
/*      */       
/* 5111 */       return 0;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 5114 */         return parseShortAsDouble(columnIndex, val);
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 5119 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____217") + val + Messages.getString("ResultSet.___in_column__218") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Statement getStatement()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 5136 */       synchronized (checkClosed().getConnectionMutex()) {
/* 5137 */         if (this.wrapperStatement != null) {
/* 5138 */           return this.wrapperStatement;
/*      */         }
/*      */         
/* 5141 */         return this.owningStatement;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5156 */       return this.owningStatement;
/*      */     }
/*      */     catch (SQLException sqlEx)
/*      */     {
/* 5145 */       if (!this.retainOwningStatement) {
/* 5146 */         throw SQLError.createSQLException("Operation not allowed on closed ResultSet. Statements can be retained over result set closure by setting the connection property \"retainStatementAfterResultSetClose\" to \"true\".", "S1000", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5152 */       if (this.wrapperStatement != null) {
/* 5153 */         return this.wrapperStatement;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5173 */     String stringVal = getStringInternal(columnIndex, true);
/*      */     
/* 5175 */     if ((this.padCharsWithSpace) && (stringVal != null)) {
/* 5176 */       Field f = this.fields[(columnIndex - 1)];
/*      */       
/* 5178 */       if (f.getMysqlType() == 254) {
/* 5179 */         int fieldLength = (int)f.getLength() / f.getMaxBytesPerCharacter();
/*      */         
/* 5181 */         int currentLength = stringVal.length();
/*      */         
/* 5183 */         if (currentLength < fieldLength) {
/* 5184 */           StringBuilder paddedBuf = new StringBuilder(fieldLength);
/* 5185 */           paddedBuf.append(stringVal);
/*      */           
/* 5187 */           int difference = fieldLength - currentLength;
/*      */           
/* 5189 */           paddedBuf.append(EMPTY_SPACE, 0, difference);
/*      */           
/* 5191 */           stringVal = paddedBuf.toString();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 5196 */     return stringVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5212 */     return getString(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private String getStringForClob(int columnIndex) throws SQLException {
/* 5216 */     String asString = null;
/*      */     
/* 5218 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */     
/* 5220 */     if (forcedEncoding == null) {
/* 5221 */       if (!this.isBinaryEncoded) {
/* 5222 */         asString = getString(columnIndex);
/*      */       } else {
/* 5224 */         asString = getNativeString(columnIndex);
/*      */       }
/*      */     } else {
/*      */       try {
/* 5228 */         byte[] asBytes = null;
/*      */         
/* 5230 */         if (!this.isBinaryEncoded) {
/* 5231 */           asBytes = getBytes(columnIndex);
/*      */         } else {
/* 5233 */           asBytes = getNativeBytes(columnIndex, true);
/*      */         }
/*      */         
/* 5236 */         if (asBytes != null) {
/* 5237 */           asString = StringUtils.toString(asBytes, forcedEncoding);
/*      */         }
/*      */       } catch (UnsupportedEncodingException uee) {
/* 5240 */         throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5245 */     return asString;
/*      */   }
/*      */   
/*      */   protected String getStringInternal(int columnIndex, boolean checkDateTypes) throws SQLException {
/* 5249 */     if (!this.isBinaryEncoded) {
/* 5250 */       checkRowPos();
/* 5251 */       checkColumnBounds(columnIndex);
/*      */       
/* 5253 */       if (this.fields == null) {
/* 5254 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_99"), "S1002", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5260 */       int internalColumnIndex = columnIndex - 1;
/*      */       
/* 5262 */       if (this.thisRow.isNull(internalColumnIndex)) {
/* 5263 */         this.wasNullFlag = true;
/*      */         
/* 5265 */         return null;
/*      */       }
/*      */       
/* 5268 */       this.wasNullFlag = false;
/*      */       
/* 5270 */       Field metadata = this.fields[internalColumnIndex];
/*      */       
/* 5272 */       String stringVal = null;
/*      */       
/* 5274 */       if (metadata.getMysqlType() == 16) {
/* 5275 */         if (metadata.isSingleBit()) {
/* 5276 */           byte[] value = this.thisRow.getColumnValue(internalColumnIndex);
/*      */           
/* 5278 */           if (value.length == 0) {
/* 5279 */             return String.valueOf(convertToZeroWithEmptyCheck());
/*      */           }
/*      */           
/* 5282 */           return String.valueOf(value[0]);
/*      */         }
/*      */         
/* 5285 */         return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */       }
/*      */       
/* 5288 */       String encoding = metadata.getEncoding();
/*      */       
/* 5290 */       stringVal = this.thisRow.getString(internalColumnIndex, encoding, this.connection);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5296 */       if (metadata.getMysqlType() == 13) {
/* 5297 */         if (!this.connection.getYearIsDateType()) {
/* 5298 */           return stringVal;
/*      */         }
/*      */         
/* 5301 */         Date dt = getDateFromString(stringVal, columnIndex, null);
/*      */         
/* 5303 */         if (dt == null) {
/* 5304 */           this.wasNullFlag = true;
/*      */           
/* 5306 */           return null;
/*      */         }
/*      */         
/* 5309 */         this.wasNullFlag = false;
/*      */         
/* 5311 */         return dt.toString();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5316 */       if ((checkDateTypes) && (!this.connection.getNoDatetimeStringSync())) {
/* 5317 */         switch (metadata.getSQLType()) {
/*      */         case 92: 
/* 5319 */           Time tm = getTimeFromString(stringVal, null, columnIndex, getDefaultTimeZone(), false);
/*      */           
/* 5321 */           if (tm == null) {
/* 5322 */             this.wasNullFlag = true;
/*      */             
/* 5324 */             return null;
/*      */           }
/*      */           
/* 5327 */           this.wasNullFlag = false;
/*      */           
/* 5329 */           return tm.toString();
/*      */         
/*      */         case 91: 
/* 5332 */           Date dt = getDateFromString(stringVal, columnIndex, null);
/*      */           
/* 5334 */           if (dt == null) {
/* 5335 */             this.wasNullFlag = true;
/*      */             
/* 5337 */             return null;
/*      */           }
/*      */           
/* 5340 */           this.wasNullFlag = false;
/*      */           
/* 5342 */           return dt.toString();
/*      */         case 93: 
/* 5344 */           Timestamp ts = getTimestampFromString(columnIndex, null, stringVal, getDefaultTimeZone(), false);
/*      */           
/* 5346 */           if (ts == null) {
/* 5347 */             this.wasNullFlag = true;
/*      */             
/* 5349 */             return null;
/*      */           }
/*      */           
/* 5352 */           this.wasNullFlag = false;
/*      */           
/* 5354 */           return ts.toString();
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/* 5360 */       return stringVal;
/*      */     }
/*      */     
/* 5363 */     return getNativeString(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5378 */     return getTimeInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5397 */     return getTimeInternal(columnIndex, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5412 */     return getTime(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5431 */     return getTime(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */   private Time getTimeFromString(String timeAsString, Calendar targetCalendar, int columnIndex, TimeZone tz, boolean rollForward) throws SQLException {
/* 5435 */     synchronized (checkClosed().getConnectionMutex()) {
/* 5436 */       int hr = 0;
/* 5437 */       int min = 0;
/* 5438 */       int sec = 0;
/*      */       
/*      */       try
/*      */       {
/* 5442 */         if (timeAsString == null) {
/* 5443 */           this.wasNullFlag = true;
/*      */           
/* 5445 */           return null;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5455 */         timeAsString = timeAsString.trim();
/*      */         
/*      */ 
/* 5458 */         int dec = timeAsString.indexOf(".");
/* 5459 */         if (dec > -1) {
/* 5460 */           timeAsString = timeAsString.substring(0, dec);
/*      */         }
/*      */         
/* 5463 */         if ((timeAsString.equals("0")) || (timeAsString.equals("0000-00-00")) || (timeAsString.equals("0000-00-00 00:00:00")) || (timeAsString.equals("00000000000000")))
/*      */         {
/* 5465 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5466 */             this.wasNullFlag = true;
/*      */             
/* 5468 */             return null; }
/* 5469 */           if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5470 */             throw SQLError.createSQLException("Value '" + timeAsString + "' can not be represented as java.sql.Time", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 5475 */           return fastTimeCreate(targetCalendar, 0, 0, 0);
/*      */         }
/*      */         
/* 5478 */         this.wasNullFlag = false;
/*      */         
/* 5480 */         Field timeColField = this.fields[(columnIndex - 1)];
/*      */         
/* 5482 */         if (timeColField.getMysqlType() == 7)
/*      */         {
/* 5484 */           int length = timeAsString.length();
/*      */           
/* 5486 */           switch (length)
/*      */           {
/*      */           case 19: 
/* 5489 */             hr = Integer.parseInt(timeAsString.substring(length - 8, length - 6));
/* 5490 */             min = Integer.parseInt(timeAsString.substring(length - 5, length - 3));
/* 5491 */             sec = Integer.parseInt(timeAsString.substring(length - 2, length));
/*      */             
/*      */ 
/* 5494 */             break;
/*      */           case 12: 
/*      */           case 14: 
/* 5497 */             hr = Integer.parseInt(timeAsString.substring(length - 6, length - 4));
/* 5498 */             min = Integer.parseInt(timeAsString.substring(length - 4, length - 2));
/* 5499 */             sec = Integer.parseInt(timeAsString.substring(length - 2, length));
/*      */             
/*      */ 
/* 5502 */             break;
/*      */           
/*      */           case 10: 
/* 5505 */             hr = Integer.parseInt(timeAsString.substring(6, 8));
/* 5506 */             min = Integer.parseInt(timeAsString.substring(8, 10));
/* 5507 */             sec = 0;
/*      */             
/*      */ 
/* 5510 */             break;
/*      */           case 11: case 13: case 15: case 16: 
/*      */           case 17: case 18: default: 
/* 5513 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Timestamp_too_small_to_convert_to_Time_value_in_column__257") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */           
/* 5517 */           SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_TIMESTAMP_to_Time_with_getTime()_on_column__261") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").");
/*      */           
/*      */ 
/*      */ 
/* 5521 */           if (this.warningChain == null) {
/* 5522 */             this.warningChain = precisionLost;
/*      */           } else {
/* 5524 */             this.warningChain.setNextWarning(precisionLost);
/*      */           }
/* 5526 */         } else if (timeColField.getMysqlType() == 12) {
/* 5527 */           hr = Integer.parseInt(timeAsString.substring(11, 13));
/* 5528 */           min = Integer.parseInt(timeAsString.substring(14, 16));
/* 5529 */           sec = Integer.parseInt(timeAsString.substring(17, 19));
/*      */           
/* 5531 */           SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_DATETIME_to_Time_with_getTime()_on_column__264") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").");
/*      */           
/*      */ 
/*      */ 
/* 5535 */           if (this.warningChain == null) {
/* 5536 */             this.warningChain = precisionLost;
/*      */           } else
/* 5538 */             this.warningChain.setNextWarning(precisionLost);
/*      */         } else {
/* 5540 */           if (timeColField.getMysqlType() == 10) {
/* 5541 */             return fastTimeCreate(targetCalendar, 0, 0, 0);
/*      */           }
/*      */           
/*      */ 
/* 5545 */           if ((timeAsString.length() != 5) && (timeAsString.length() != 8)) {
/* 5546 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Time____267") + timeAsString + Messages.getString("ResultSet.___in_column__268") + columnIndex, "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 5551 */           hr = Integer.parseInt(timeAsString.substring(0, 2));
/* 5552 */           min = Integer.parseInt(timeAsString.substring(3, 5));
/* 5553 */           sec = timeAsString.length() == 5 ? 0 : Integer.parseInt(timeAsString.substring(6));
/*      */         }
/*      */         
/* 5556 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 5558 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimeCreate(sessionCalendar, hr, min, sec), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */       }
/*      */       catch (RuntimeException ex) {
/* 5561 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", getExceptionInterceptor());
/* 5562 */         sqlEx.initCause(ex);
/*      */         
/* 5564 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Time getTimeInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 5584 */     checkRowPos();
/*      */     
/* 5586 */     if (this.isBinaryEncoded) {
/* 5587 */       return getNativeTime(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 5590 */     if (!this.useFastDateParsing) {
/* 5591 */       String timeAsString = getStringInternal(columnIndex, false);
/*      */       
/* 5593 */       return getTimeFromString(timeAsString, targetCalendar, columnIndex, tz, rollForward);
/*      */     }
/*      */     
/* 5596 */     checkColumnBounds(columnIndex);
/*      */     
/* 5598 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 5600 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 5601 */       this.wasNullFlag = true;
/*      */       
/* 5603 */       return null;
/*      */     }
/*      */     
/* 5606 */     this.wasNullFlag = false;
/*      */     
/* 5608 */     return this.thisRow.getTimeFast(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5624 */     return getTimestampInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5644 */     return getTimestampInternal(columnIndex, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5653 */     return getTimestamp(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5673 */     return getTimestamp(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */   private Timestamp getTimestampFromString(int columnIndex, Calendar targetCalendar, String timestampValue, TimeZone tz, boolean rollForward) throws SQLException
/*      */   {
/*      */     try {
/* 5679 */       this.wasNullFlag = false;
/*      */       
/* 5681 */       if (timestampValue == null) {
/* 5682 */         this.wasNullFlag = true;
/*      */         
/* 5684 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5694 */       timestampValue = timestampValue.trim();
/*      */       
/* 5696 */       int length = timestampValue.length();
/*      */       
/* 5698 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */       
/*      */ 
/* 5701 */       if ((length > 0) && (timestampValue.charAt(0) == '0') && ((timestampValue.equals("0000-00-00")) || (timestampValue.equals("0000-00-00 00:00:00")) || (timestampValue.equals("00000000000000")) || (timestampValue.equals("0"))))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 5706 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5707 */           this.wasNullFlag = true;
/*      */           
/* 5709 */           return null; }
/* 5710 */         if ("exception".equals(this.connection.getZeroDateTimeBehavior())) {
/* 5711 */           throw SQLError.createSQLException("Value '" + timestampValue + "' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5716 */         return fastTimestampCreate(null, 1, 1, 1, 0, 0, 0, 0);
/*      */       }
/* 5718 */       if (this.fields[(columnIndex - 1)].getMysqlType() == 13)
/*      */       {
/* 5720 */         if (!this.useLegacyDatetimeCode) {
/* 5721 */           return TimeUtil.fastTimestampCreate(tz, Integer.parseInt(timestampValue.substring(0, 4)), 1, 1, 0, 0, 0, 0);
/*      */         }
/*      */         
/* 5724 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, Integer.parseInt(timestampValue.substring(0, 4)), 1, 1, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5731 */       int year = 0;
/* 5732 */       int month = 0;
/* 5733 */       int day = 0;
/* 5734 */       int hour = 0;
/* 5735 */       int minutes = 0;
/* 5736 */       int seconds = 0;
/* 5737 */       int nanos = 0;
/*      */       
/*      */ 
/* 5740 */       int decimalIndex = timestampValue.indexOf(".");
/*      */       
/* 5742 */       if (decimalIndex == length - 1)
/*      */       {
/* 5744 */         length--;
/*      */       }
/* 5746 */       else if (decimalIndex != -1)
/*      */       {
/* 5748 */         if (decimalIndex + 2 <= length) {
/* 5749 */           nanos = Integer.parseInt(timestampValue.substring(decimalIndex + 1));
/*      */           
/* 5751 */           int numDigits = length - (decimalIndex + 1);
/*      */           
/* 5753 */           if (numDigits < 9) {
/* 5754 */             int factor = (int)Math.pow(10.0D, 9 - numDigits);
/* 5755 */             nanos *= factor;
/*      */           }
/*      */           
/* 5758 */           length = decimalIndex;
/*      */         } else {
/* 5760 */           throw new IllegalArgumentException();
/*      */         }
/*      */       }
/*      */       
/* 5764 */       switch (length) {
/*      */       case 19: 
/*      */       case 20: 
/*      */       case 21: 
/*      */       case 22: 
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 25: 
/*      */       case 26: 
/* 5773 */         year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5774 */         month = Integer.parseInt(timestampValue.substring(5, 7));
/* 5775 */         day = Integer.parseInt(timestampValue.substring(8, 10));
/* 5776 */         hour = Integer.parseInt(timestampValue.substring(11, 13));
/* 5777 */         minutes = Integer.parseInt(timestampValue.substring(14, 16));
/* 5778 */         seconds = Integer.parseInt(timestampValue.substring(17, 19));
/*      */         
/* 5780 */         break;
/*      */       
/*      */ 
/*      */       case 14: 
/* 5784 */         year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5785 */         month = Integer.parseInt(timestampValue.substring(4, 6));
/* 5786 */         day = Integer.parseInt(timestampValue.substring(6, 8));
/* 5787 */         hour = Integer.parseInt(timestampValue.substring(8, 10));
/* 5788 */         minutes = Integer.parseInt(timestampValue.substring(10, 12));
/* 5789 */         seconds = Integer.parseInt(timestampValue.substring(12, 14));
/*      */         
/* 5791 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/* 5795 */         year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */         
/* 5797 */         if (year <= 69) {
/* 5798 */           year += 100;
/*      */         }
/*      */         
/* 5801 */         year += 1900;
/*      */         
/* 5803 */         month = Integer.parseInt(timestampValue.substring(2, 4));
/* 5804 */         day = Integer.parseInt(timestampValue.substring(4, 6));
/* 5805 */         hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 5806 */         minutes = Integer.parseInt(timestampValue.substring(8, 10));
/* 5807 */         seconds = Integer.parseInt(timestampValue.substring(10, 12));
/*      */         
/* 5809 */         break;
/*      */       
/*      */ 
/*      */       case 10: 
/* 5813 */         if ((this.fields[(columnIndex - 1)].getMysqlType() == 10) || (timestampValue.indexOf("-") != -1)) {
/* 5814 */           year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5815 */           month = Integer.parseInt(timestampValue.substring(5, 7));
/* 5816 */           day = Integer.parseInt(timestampValue.substring(8, 10));
/* 5817 */           hour = 0;
/* 5818 */           minutes = 0;
/*      */         } else {
/* 5820 */           year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */           
/* 5822 */           if (year <= 69) {
/* 5823 */             year += 100;
/*      */           }
/*      */           
/* 5826 */           month = Integer.parseInt(timestampValue.substring(2, 4));
/* 5827 */           day = Integer.parseInt(timestampValue.substring(4, 6));
/* 5828 */           hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 5829 */           minutes = Integer.parseInt(timestampValue.substring(8, 10));
/*      */           
/* 5831 */           year += 1900;
/*      */         }
/*      */         
/* 5834 */         break;
/*      */       
/*      */ 
/*      */       case 8: 
/* 5838 */         if (timestampValue.indexOf(":") != -1) {
/* 5839 */           hour = Integer.parseInt(timestampValue.substring(0, 2));
/* 5840 */           minutes = Integer.parseInt(timestampValue.substring(3, 5));
/* 5841 */           seconds = Integer.parseInt(timestampValue.substring(6, 8));
/* 5842 */           year = 1970;
/* 5843 */           month = 1;
/* 5844 */           day = 1;
/*      */         }
/*      */         else
/*      */         {
/* 5848 */           year = Integer.parseInt(timestampValue.substring(0, 4));
/* 5849 */           month = Integer.parseInt(timestampValue.substring(4, 6));
/* 5850 */           day = Integer.parseInt(timestampValue.substring(6, 8));
/*      */           
/* 5852 */           year -= 1900;
/* 5853 */           month--;
/*      */         }
/* 5855 */         break;
/*      */       
/*      */ 
/*      */       case 6: 
/* 5859 */         year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */         
/* 5861 */         if (year <= 69) {
/* 5862 */           year += 100;
/*      */         }
/*      */         
/* 5865 */         year += 1900;
/*      */         
/* 5867 */         month = Integer.parseInt(timestampValue.substring(2, 4));
/* 5868 */         day = Integer.parseInt(timestampValue.substring(4, 6));
/*      */         
/* 5870 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/* 5874 */         year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */         
/* 5876 */         if (year <= 69) {
/* 5877 */           year += 100;
/*      */         }
/*      */         
/* 5880 */         year += 1900;
/*      */         
/* 5882 */         month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */         
/* 5884 */         day = 1;
/*      */         
/* 5886 */         break;
/*      */       
/*      */ 
/*      */       case 2: 
/* 5890 */         year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */         
/* 5892 */         if (year <= 69) {
/* 5893 */           year += 100;
/*      */         }
/*      */         
/* 5896 */         year += 1900;
/* 5897 */         month = 1;
/* 5898 */         day = 1;
/*      */         
/* 5900 */         break;
/*      */       case 3: case 5: case 7: case 9: 
/*      */       case 11: case 13: case 15: case 16: 
/*      */       case 17: case 18: default: 
/* 5904 */         throw new SQLException("Bad format for Timestamp '" + timestampValue + "' in column " + columnIndex + ".", "S1009");
/*      */       }
/*      */       
/*      */       
/* 5908 */       if (!this.useLegacyDatetimeCode) {
/* 5909 */         return TimeUtil.fastTimestampCreate(tz, year, month, day, hour, minutes, seconds, nanos);
/*      */       }
/*      */       
/* 5912 */       return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year, month, day, hour, minutes, seconds, nanos), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/* 5917 */       SQLException sqlEx = SQLError.createSQLException("Cannot convert value '" + timestampValue + "' from column " + columnIndex + " to TIMESTAMP.", "S1009", getExceptionInterceptor());
/*      */       
/* 5919 */       sqlEx.initCause(e);
/*      */       
/* 5921 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Timestamp getTimestampInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 5941 */     if (this.isBinaryEncoded) {
/* 5942 */       return getNativeTimestamp(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 5945 */     Timestamp tsVal = null;
/*      */     
/* 5947 */     if (!this.useFastDateParsing) {
/* 5948 */       String timestampValue = getStringInternal(columnIndex, false);
/*      */       
/* 5950 */       tsVal = getTimestampFromString(columnIndex, targetCalendar, timestampValue, tz, rollForward);
/*      */     } else {
/* 5952 */       checkClosed();
/* 5953 */       checkRowPos();
/* 5954 */       checkColumnBounds(columnIndex);
/*      */       
/* 5956 */       tsVal = this.thisRow.getTimestampFast(columnIndex - 1, targetCalendar, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/* 5959 */     if (tsVal == null) {
/* 5960 */       this.wasNullFlag = true;
/*      */     } else {
/* 5962 */       this.wasNullFlag = false;
/*      */     }
/*      */     
/* 5965 */     return tsVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getType()
/*      */     throws SQLException
/*      */   {
/* 5979 */     return this.resultSetType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 6002 */     if (!this.isBinaryEncoded) {
/* 6003 */       checkRowPos();
/*      */       
/* 6005 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */     
/* 6008 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 6020 */     return getUnicodeStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */   public long getUpdateCount() {
/* 6024 */     return this.updateCount;
/*      */   }
/*      */   
/*      */   public long getUpdateID() {
/* 6028 */     return this.updateId;
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 6035 */     String val = getString(colIndex);
/*      */     
/* 6037 */     if (val == null) {
/* 6038 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 6042 */       return new URL(val);
/*      */     } catch (MalformedURLException mfe) {
/* 6044 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____104") + val + "'", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public URL getURL(String colName)
/*      */     throws SQLException
/*      */   {
/* 6053 */     String val = getString(colName);
/*      */     
/* 6055 */     if (val == null) {
/* 6056 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 6060 */       return new URL(val);
/*      */     } catch (MalformedURLException mfe) {
/* 6062 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____107") + val + "'", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/* 6103 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/* 6120 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6121 */       boolean b = this.rowData.isAfterLast();
/*      */       
/* 6123 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void issueConversionViaParsingWarning(String methodName, int columnIndex, Object value, Field fieldInfo, int[] typesWithNoParseConversion)
/*      */     throws SQLException
/*      */   {
/* 6190 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6191 */       StringBuilder originalQueryBuf = new StringBuilder();
/*      */       
/* 6193 */       if ((this.owningStatement != null) && ((this.owningStatement instanceof PreparedStatement))) {
/* 6194 */         originalQueryBuf.append(Messages.getString("ResultSet.CostlyConversionCreatedFromQuery"));
/* 6195 */         originalQueryBuf.append(((PreparedStatement)this.owningStatement).originalSql);
/* 6196 */         originalQueryBuf.append("\n\n");
/*      */       } else {
/* 6198 */         originalQueryBuf.append(".");
/*      */       }
/*      */       
/* 6201 */       StringBuilder convertibleTypesBuf = new StringBuilder();
/*      */       
/* 6203 */       for (int i = 0; i < typesWithNoParseConversion.length; i++) {
/* 6204 */         convertibleTypesBuf.append(MysqlDefs.typeToName(typesWithNoParseConversion[i]));
/* 6205 */         convertibleTypesBuf.append("\n");
/*      */       }
/*      */       
/* 6208 */       String message = Messages.getString("ResultSet.CostlyConversion", new Object[] { methodName, Integer.valueOf(columnIndex + 1), fieldInfo.getOriginalName(), fieldInfo.getOriginalTableName(), originalQueryBuf.toString(), value != null ? value.getClass().getName() : ResultSetMetaData.getClassNameForJavaType(fieldInfo.getSQLType(), fieldInfo.isUnsigned(), fieldInfo.getMysqlType(), (fieldInfo.isBinary()) || (fieldInfo.isBlob()) ? 1 : false, fieldInfo.isOpaqueBinary(), this.connection.getYearIsDateType()), MysqlDefs.typeToName(fieldInfo.getMysqlType()), convertibleTypesBuf.toString() });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6220 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/* 6240 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 6242 */       boolean b = true;
/*      */       
/* 6244 */       if (this.rowData.size() == 0) {
/* 6245 */         b = false;
/*      */       }
/*      */       else {
/* 6248 */         if (this.onInsertRow) {
/* 6249 */           this.onInsertRow = false;
/*      */         }
/*      */         
/* 6252 */         if (this.doingUpdates) {
/* 6253 */           this.doingUpdates = false;
/*      */         }
/*      */         
/* 6256 */         if (this.thisRow != null) {
/* 6257 */           this.thisRow.closeOpenStreams();
/*      */         }
/*      */         
/* 6260 */         this.rowData.beforeLast();
/* 6261 */         this.thisRow = this.rowData.next();
/*      */       }
/*      */       
/* 6264 */       setRowPositionValidity();
/*      */       
/* 6266 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 6288 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 6308 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/* 6326 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 6328 */       if (this.onInsertRow) {
/* 6329 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 6332 */       if (this.doingUpdates) {
/* 6333 */         this.doingUpdates = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 6338 */       if (!reallyResult()) {
/* 6339 */         throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 6343 */       if (this.thisRow != null)
/* 6344 */         this.thisRow.closeOpenStreams();
/*      */       boolean b;
/*      */       boolean b;
/* 6347 */       if (this.rowData.size() == 0) {
/* 6348 */         b = false;
/*      */       } else {
/* 6350 */         this.thisRow = this.rowData.next();
/*      */         boolean b;
/* 6352 */         if (this.thisRow == null) {
/* 6353 */           b = false;
/*      */         } else {
/* 6355 */           clearWarnings();
/*      */           
/* 6357 */           b = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 6362 */       setRowPositionValidity();
/*      */       
/* 6364 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */   private int parseIntAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException {
/* 6369 */     if (val == null) {
/* 6370 */       return 0;
/*      */     }
/*      */     
/* 6373 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6375 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6376 */       (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D))) {
/* 6377 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */     }
/*      */     
/*      */ 
/* 6381 */     return (int)valueAsDouble;
/*      */   }
/*      */   
/*      */   private int getIntWithOverflowCheck(int columnIndex) throws SQLException {
/* 6385 */     int intValue = this.thisRow.getInt(columnIndex);
/*      */     
/* 6387 */     checkForIntegerTruncation(columnIndex, null, intValue);
/*      */     
/* 6389 */     return intValue;
/*      */   }
/*      */   
/*      */   private void checkForIntegerTruncation(int columnIndex, byte[] valueAsBytes, int intValue) throws SQLException {
/* 6393 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6394 */       (intValue == Integer.MIN_VALUE) || (intValue == Integer.MAX_VALUE))) {
/* 6395 */       String valueAsString = null;
/*      */       
/* 6397 */       if (valueAsBytes == null) {
/* 6398 */         valueAsString = this.thisRow.getString(columnIndex, this.fields[columnIndex].getEncoding(), this.connection);
/*      */       }
/*      */       
/* 6401 */       long valueAsLong = Long.parseLong(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/* 6403 */       if ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)) {
/* 6404 */         throwRangeException(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndex + 1, 4);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private long parseLongAsDouble(int columnIndexZeroBased, String val) throws NumberFormatException, SQLException
/*      */   {
/* 6411 */     if (val == null) {
/* 6412 */       return 0L;
/*      */     }
/*      */     
/* 6415 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6417 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6418 */       (valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D))) {
/* 6419 */       throwRangeException(val, columnIndexZeroBased + 1, -5);
/*      */     }
/*      */     
/*      */ 
/* 6423 */     return valueAsDouble;
/*      */   }
/*      */   
/*      */   private long getLongWithOverflowCheck(int columnIndexZeroBased, boolean doOverflowCheck) throws SQLException {
/* 6427 */     long longValue = this.thisRow.getLong(columnIndexZeroBased);
/*      */     
/* 6429 */     if (doOverflowCheck) {
/* 6430 */       checkForLongTruncation(columnIndexZeroBased, null, longValue);
/*      */     }
/*      */     
/* 6433 */     return longValue;
/*      */   }
/*      */   
/*      */   private long parseLongWithOverflowCheck(int columnIndexZeroBased, byte[] valueAsBytes, String valueAsString, boolean doCheck)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 6439 */     long longValue = 0L;
/*      */     
/* 6441 */     if ((valueAsBytes == null) && (valueAsString == null)) {
/* 6442 */       return 0L;
/*      */     }
/*      */     
/* 6445 */     if (valueAsBytes != null) {
/* 6446 */       longValue = StringUtils.getLong(valueAsBytes);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/* 6455 */       valueAsString = valueAsString.trim();
/*      */       
/* 6457 */       longValue = Long.parseLong(valueAsString);
/*      */     }
/*      */     
/* 6460 */     if ((doCheck) && (this.jdbcCompliantTruncationForReads)) {
/* 6461 */       checkForLongTruncation(columnIndexZeroBased, valueAsBytes, longValue);
/*      */     }
/*      */     
/* 6464 */     return longValue;
/*      */   }
/*      */   
/*      */   private void checkForLongTruncation(int columnIndexZeroBased, byte[] valueAsBytes, long longValue) throws SQLException {
/* 6468 */     if ((longValue == Long.MIN_VALUE) || (longValue == Long.MAX_VALUE)) {
/* 6469 */       String valueAsString = null;
/*      */       
/* 6471 */       if (valueAsBytes == null) {
/* 6472 */         valueAsString = this.thisRow.getString(columnIndexZeroBased, this.fields[columnIndexZeroBased].getEncoding(), this.connection);
/*      */       }
/*      */       
/* 6475 */       double valueAsDouble = Double.parseDouble(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/* 6477 */       if ((valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D)) {
/* 6478 */         throwRangeException(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndexZeroBased + 1, -5);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private short parseShortAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException {
/* 6484 */     if (val == null) {
/* 6485 */       return 0;
/*      */     }
/*      */     
/* 6488 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6490 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6491 */       (valueAsDouble < -32768.0D) || (valueAsDouble > 32767.0D))) {
/* 6492 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 5);
/*      */     }
/*      */     
/*      */ 
/* 6496 */     return (short)(int)valueAsDouble;
/*      */   }
/*      */   
/*      */   private short parseShortWithOverflowCheck(int columnIndex, byte[] valueAsBytes, String valueAsString) throws NumberFormatException, SQLException
/*      */   {
/* 6501 */     short shortValue = 0;
/*      */     
/* 6503 */     if ((valueAsBytes == null) && (valueAsString == null)) {
/* 6504 */       return 0;
/*      */     }
/*      */     
/* 6507 */     if (valueAsBytes != null) {
/* 6508 */       shortValue = StringUtils.getShort(valueAsBytes);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/* 6517 */       valueAsString = valueAsString.trim();
/*      */       
/* 6519 */       shortValue = Short.parseShort(valueAsString);
/*      */     }
/*      */     
/* 6522 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6523 */       (shortValue == Short.MIN_VALUE) || (shortValue == Short.MAX_VALUE))) {
/* 6524 */       long valueAsLong = Long.parseLong(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/* 6526 */       if ((valueAsLong < -32768L) || (valueAsLong > 32767L)) {
/* 6527 */         throwRangeException(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndex, 5);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 6532 */     return shortValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean prev()
/*      */     throws SQLException
/*      */   {
/* 6555 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 6557 */       int rowIndex = this.rowData.getCurrentRowNumber();
/*      */       
/* 6559 */       if (this.thisRow != null) {
/* 6560 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/* 6563 */       boolean b = true;
/*      */       
/* 6565 */       if (rowIndex - 1 >= 0) {
/* 6566 */         rowIndex--;
/* 6567 */         this.rowData.setCurrentRow(rowIndex);
/* 6568 */         this.thisRow = this.rowData.getAt(rowIndex);
/*      */         
/* 6570 */         b = true;
/* 6571 */       } else if (rowIndex - 1 == -1) {
/* 6572 */         rowIndex--;
/* 6573 */         this.rowData.setCurrentRow(rowIndex);
/* 6574 */         this.thisRow = null;
/*      */         
/* 6576 */         b = false;
/*      */       } else {
/* 6578 */         b = false;
/*      */       }
/*      */       
/* 6581 */       setRowPositionValidity();
/*      */       
/* 6583 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/* 6605 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6606 */       if (this.onInsertRow) {
/* 6607 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 6610 */       if (this.doingUpdates) {
/* 6611 */         this.doingUpdates = false;
/*      */       }
/*      */       
/* 6614 */       return prev();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void realClose(boolean calledExplicitly)
/*      */     throws SQLException
/*      */   {
/* 6629 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 6631 */     if (locallyScopedConn == null) {
/* 6632 */       return;
/*      */     }
/*      */     
/* 6635 */     synchronized (locallyScopedConn.getConnectionMutex())
/*      */     {
/*      */ 
/*      */ 
/* 6639 */       if (this.isClosed) {
/* 6640 */         return;
/*      */       }
/*      */       try
/*      */       {
/* 6644 */         if (this.useUsageAdvisor)
/*      */         {
/*      */ 
/*      */ 
/* 6648 */           if (!calledExplicitly) {
/* 6649 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.ResultSet_implicitly_closed_by_driver")));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 6655 */           if ((this.rowData instanceof RowDataStatic))
/*      */           {
/*      */ 
/*      */ 
/* 6659 */             if (this.rowData.size() > this.connection.getResultSetSizeThreshold()) {
/* 6660 */               this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Too_Large_Result_Set", new Object[] { Integer.valueOf(this.rowData.size()), Integer.valueOf(this.connection.getResultSetSizeThreshold()) })));
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6667 */             if ((!isLast()) && (!isAfterLast()) && (this.rowData.size() != 0))
/*      */             {
/* 6669 */               this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Possible_incomplete_traversal_of_result_set", new Object[] { Integer.valueOf(getRow()), Integer.valueOf(this.rowData.size()) })));
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6682 */           if ((this.columnUsed.length > 0) && (!this.rowData.wasEmpty())) {
/* 6683 */             StringBuilder buf = new StringBuilder(Messages.getString("ResultSet.The_following_columns_were_never_referenced"));
/*      */             
/* 6685 */             boolean issueWarn = false;
/*      */             
/* 6687 */             for (int i = 0; i < this.columnUsed.length; i++) {
/* 6688 */               if (this.columnUsed[i] == 0) {
/* 6689 */                 if (!issueWarn) {
/* 6690 */                   issueWarn = true;
/*      */                 } else {
/* 6692 */                   buf.append(", ");
/*      */                 }
/*      */                 
/* 6695 */                 buf.append(this.fields[i].getFullName());
/*      */               }
/*      */             }
/*      */             
/* 6699 */             if (issueWarn) {
/* 6700 */               this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), 0, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, buf.toString()));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 6707 */         if ((this.owningStatement != null) && (calledExplicitly)) {
/* 6708 */           this.owningStatement.removeOpenResultSet(this);
/*      */         }
/*      */         
/* 6711 */         SQLException exceptionDuringClose = null;
/*      */         
/* 6713 */         if (this.rowData != null) {
/*      */           try {
/* 6715 */             this.rowData.close();
/*      */           } catch (SQLException sqlEx) {
/* 6717 */             exceptionDuringClose = sqlEx;
/*      */           }
/*      */         }
/*      */         
/* 6721 */         if (this.statementUsedForFetchingRows != null) {
/*      */           try {
/* 6723 */             this.statementUsedForFetchingRows.realClose(true, false);
/*      */           } catch (SQLException sqlEx) {
/* 6725 */             if (exceptionDuringClose != null) {
/* 6726 */               exceptionDuringClose.setNextException(sqlEx);
/*      */             } else {
/* 6728 */               exceptionDuringClose = sqlEx;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 6733 */         this.rowData = null;
/* 6734 */         this.fields = null;
/* 6735 */         this.columnLabelToIndex = null;
/* 6736 */         this.fullColumnNameToIndex = null;
/* 6737 */         this.columnToIndexCache = null;
/* 6738 */         this.eventSink = null;
/* 6739 */         this.warningChain = null;
/*      */         
/* 6741 */         if (!this.retainOwningStatement) {
/* 6742 */           this.owningStatement = null;
/*      */         }
/*      */         
/* 6745 */         this.catalog = null;
/* 6746 */         this.serverInfo = null;
/* 6747 */         this.thisRow = null;
/* 6748 */         this.fastDefaultCal = null;
/* 6749 */         this.fastClientCal = null;
/* 6750 */         this.connection = null;
/*      */         
/* 6752 */         this.isClosed = true;
/*      */         
/* 6754 */         if (exceptionDuringClose != null) {
/* 6755 */           throw exceptionDuringClose;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isClosed()
/*      */     throws SQLException
/*      */   {
/* 6765 */     return this.isClosed;
/*      */   }
/*      */   
/*      */   public boolean reallyResult() {
/* 6769 */     if (this.rowData != null) {
/* 6770 */       return true;
/*      */     }
/*      */     
/* 6773 */     return this.reallyResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 6796 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean relative(int rows)
/*      */     throws SQLException
/*      */   {
/* 6822 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 6824 */       if (this.rowData.size() == 0) {
/* 6825 */         setRowPositionValidity();
/*      */         
/* 6827 */         return false;
/*      */       }
/*      */       
/* 6830 */       if (this.thisRow != null) {
/* 6831 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/* 6834 */       this.rowData.moveRowRelative(rows);
/* 6835 */       this.thisRow = this.rowData.getAt(this.rowData.getCurrentRowNumber());
/*      */       
/* 6837 */       setRowPositionValidity();
/*      */       
/* 6839 */       return (!this.rowData.isAfterLast()) && (!this.rowData.isBeforeFirst());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 6858 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 6875 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 6892 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setBinaryEncoded()
/*      */   {
/* 6900 */     this.isBinaryEncoded = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/* 6919 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6920 */       if ((direction != 1000) && (direction != 1001) && (direction != 1002)) {
/* 6921 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_value_for_fetch_direction_64"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 6925 */       this.fetchDirection = direction;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/* 6946 */     synchronized (checkClosed().getConnectionMutex()) {
/* 6947 */       if (rows < 0) {
/* 6948 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Value_must_be_between_0_and_getMaxRows()_66"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 6952 */       this.fetchSize = rows;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFirstCharOfQuery(char c)
/*      */   {
/*      */     try
/*      */     {
/* 6965 */       synchronized (checkClosed().getConnectionMutex()) {
/* 6966 */         this.firstCharOfQuery = c;
/*      */       }
/*      */     } catch (SQLException e) {
/* 6969 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setNextResultSet(ResultSetInternalMethods nextResultSet)
/*      */   {
/* 6979 */     this.nextResultSet = nextResultSet;
/*      */   }
/*      */   
/*      */   public void setOwningStatement(StatementImpl owningStatement) {
/*      */     try {
/* 6984 */       synchronized (checkClosed().getConnectionMutex()) {
/* 6985 */         this.owningStatement = owningStatement;
/*      */       }
/*      */     } catch (SQLException e) {
/* 6988 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/*      */     try
/*      */     {
/* 7000 */       synchronized (checkClosed().getConnectionMutex()) {
/* 7001 */         this.resultSetConcurrency = concurrencyFlag;
/*      */       }
/*      */     } catch (SQLException e) {
/* 7004 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setResultSetType(int typeFlag)
/*      */   {
/*      */     try
/*      */     {
/* 7017 */       synchronized (checkClosed().getConnectionMutex()) {
/* 7018 */         this.resultSetType = typeFlag;
/*      */       }
/*      */     } catch (SQLException e) {
/* 7021 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setServerInfo(String info)
/*      */   {
/*      */     try
/*      */     {
/* 7033 */       synchronized (checkClosed().getConnectionMutex()) {
/* 7034 */         this.serverInfo = info;
/*      */       }
/*      */     } catch (SQLException e) {
/* 7037 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void setStatementUsedForFetchingRows(PreparedStatement stmt) {
/*      */     try {
/* 7043 */       synchronized (checkClosed().getConnectionMutex()) {
/* 7044 */         this.statementUsedForFetchingRows = stmt;
/*      */       }
/*      */     } catch (SQLException e) {
/* 7047 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized void setWrapperStatement(Statement wrapperStatement)
/*      */   {
/*      */     try
/*      */     {
/* 7057 */       synchronized (checkClosed().getConnectionMutex()) {
/* 7058 */         this.wrapperStatement = wrapperStatement;
/*      */       }
/*      */     } catch (SQLException e) {
/* 7061 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void throwRangeException(String valueAsString, int columnIndex, int jdbcType) throws SQLException {
/* 7066 */     String datatype = null;
/*      */     
/* 7068 */     switch (jdbcType) {
/*      */     case -6: 
/* 7070 */       datatype = "TINYINT";
/* 7071 */       break;
/*      */     case 5: 
/* 7073 */       datatype = "SMALLINT";
/* 7074 */       break;
/*      */     case 4: 
/* 7076 */       datatype = "INTEGER";
/* 7077 */       break;
/*      */     case -5: 
/* 7079 */       datatype = "BIGINT";
/* 7080 */       break;
/*      */     case 7: 
/* 7082 */       datatype = "REAL";
/* 7083 */       break;
/*      */     case 6: 
/* 7085 */       datatype = "FLOAT";
/* 7086 */       break;
/*      */     case 8: 
/* 7088 */       datatype = "DOUBLE";
/* 7089 */       break;
/*      */     case 3: 
/* 7091 */       datatype = "DECIMAL";
/* 7092 */       break;
/*      */     case -4: case -3: case -2: case -1: case 0: case 1: case 2: default: 
/* 7094 */       datatype = " (JDBC type '" + jdbcType + "')";
/*      */     }
/*      */     
/* 7097 */     throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */   public String toString()
/*      */   {
/* 7103 */     if (this.reallyResult) {
/* 7104 */       return super.toString();
/*      */     }
/*      */     
/* 7107 */     return "Result set representing update count of " + this.updateCount;
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateArray(int arg0, Array arg1)
/*      */     throws SQLException
/*      */   {
/* 7114 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateArray(String arg0, Array arg1)
/*      */     throws SQLException
/*      */   {
/* 7121 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7143 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7164 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 7183 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(String columnName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 7201 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7223 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7244 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBlob(int arg0, java.sql.Blob arg1)
/*      */     throws SQLException
/*      */   {
/* 7251 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBlob(String arg0, java.sql.Blob arg1)
/*      */     throws SQLException
/*      */   {
/* 7258 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(int columnIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 7277 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(String columnName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 7295 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(int columnIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 7314 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(String columnName, byte x)
/*      */     throws SQLException
/*      */   {
/* 7332 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(int columnIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 7351 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(String columnName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 7369 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length)
/*      */     throws SQLException
/*      */   {
/* 7391 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateCharacterStream(String columnName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 7412 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateClob(int arg0, java.sql.Clob arg1)
/*      */     throws SQLException
/*      */   {
/* 7419 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateClob(String columnName, java.sql.Clob clob)
/*      */     throws SQLException
/*      */   {
/* 7426 */     updateClob(findColumn(columnName), clob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(int columnIndex, Date x)
/*      */     throws SQLException
/*      */   {
/* 7445 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(String columnName, Date x)
/*      */     throws SQLException
/*      */   {
/* 7463 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(int columnIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 7482 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(String columnName, double x)
/*      */     throws SQLException
/*      */   {
/* 7500 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(int columnIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 7519 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(String columnName, float x)
/*      */     throws SQLException
/*      */   {
/* 7537 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(int columnIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 7556 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(String columnName, int x)
/*      */     throws SQLException
/*      */   {
/* 7574 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(int columnIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 7593 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(String columnName, long x)
/*      */     throws SQLException
/*      */   {
/* 7611 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 7628 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(String columnName)
/*      */     throws SQLException
/*      */   {
/* 7644 */     updateNull(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x)
/*      */     throws SQLException
/*      */   {
/* 7663 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 7686 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String columnName, Object x)
/*      */     throws SQLException
/*      */   {
/* 7704 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String columnName, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 7726 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRef(int arg0, Ref arg1)
/*      */     throws SQLException
/*      */   {
/* 7733 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRef(String arg0, Ref arg1)
/*      */     throws SQLException
/*      */   {
/* 7740 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/* 7753 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(int columnIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 7772 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(String columnName, short x)
/*      */     throws SQLException
/*      */   {
/* 7790 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(int columnIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 7809 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(String columnName, String x)
/*      */     throws SQLException
/*      */   {
/* 7827 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(int columnIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 7846 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(String columnName, Time x)
/*      */     throws SQLException
/*      */   {
/* 7864 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(int columnIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 7883 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(String columnName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 7901 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/* 7916 */     return this.wasNullFlag;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Calendar getGmtCalendar()
/*      */   {
/* 7922 */     if (this.gmtCalendar == null) {
/* 7923 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*      */     }
/*      */     
/* 7926 */     return this.gmtCalendar;
/*      */   }
/*      */   
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 7930 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 29	com/mysql/jdbc/ResultSetImpl:fetchDirection	I
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2339	-> byte code offset #0
/*      */     //   Java source line #2340	-> byte code offset #12
/*      */     //   Java source line #2341	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	ResultSetImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 30	com/mysql/jdbc/ResultSetImpl:fetchSize	I
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2353	-> byte code offset #0
/*      */     //   Java source line #2354	-> byte code offset #12
/*      */     //   Java source line #2355	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	ResultSetImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public char getFirstCharOfQuery()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 347	com/mysql/jdbc/ResultSetImpl:firstCharOfQuery	C
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     //   24: astore_1
/*      */     //   25: new 348	java/lang/RuntimeException
/*      */     //   28: dup
/*      */     //   29: aload_1
/*      */     //   30: invokespecial 349	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   33: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2366	-> byte code offset #0
/*      */     //   Java source line #2367	-> byte code offset #12
/*      */     //   Java source line #2368	-> byte code offset #19
/*      */     //   Java source line #2369	-> byte code offset #24
/*      */     //   Java source line #2370	-> byte code offset #25
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	34	0	this	ResultSetImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   24	6	1	e	SQLException
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */     //   0	18	24	java/sql/SQLException
/*      */     //   19	24	24	java/sql/SQLException
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String getServerInfo()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 42	com/mysql/jdbc/ResultSetImpl:serverInfo	Ljava/lang/String;
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: areturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     //   24: astore_1
/*      */     //   25: new 348	java/lang/RuntimeException
/*      */     //   28: dup
/*      */     //   29: aload_1
/*      */     //   30: invokespecial 349	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   33: athrow
/*      */     // Line number table:
/*      */     //   Java source line #4930	-> byte code offset #0
/*      */     //   Java source line #4931	-> byte code offset #12
/*      */     //   Java source line #4932	-> byte code offset #19
/*      */     //   Java source line #4933	-> byte code offset #24
/*      */     //   Java source line #4934	-> byte code offset #25
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	34	0	this	ResultSetImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   24	6	1	e	SQLException
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */     //   0	18	24	java/sql/SQLException
/*      */     //   19	24	24	java/sql/SQLException
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 49	com/mysql/jdbc/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: areturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #6087	-> byte code offset #0
/*      */     //   Java source line #6088	-> byte code offset #12
/*      */     //   Java source line #6089	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	ResultSetImpl
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 77	com/mysql/jdbc/ResultSetImpl:rowData	Lcom/mysql/jdbc/RowData;
/*      */     //   16: invokeinterface 145 1 0
/*      */     //   21: aload_1
/*      */     //   22: monitorexit
/*      */     //   23: ireturn
/*      */     //   24: astore_2
/*      */     //   25: aload_1
/*      */     //   26: monitorexit
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     // Line number table:
/*      */     //   Java source line #6141	-> byte code offset #0
/*      */     //   Java source line #6142	-> byte code offset #12
/*      */     //   Java source line #6143	-> byte code offset #24
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	29	0	this	ResultSetImpl
/*      */     //   10	16	1	Ljava/lang/Object;	Object
/*      */     //   24	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	23	24	finally
/*      */     //   24	27	24	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 77	com/mysql/jdbc/ResultSetImpl:rowData	Lcom/mysql/jdbc/RowData;
/*      */     //   16: invokeinterface 616 1 0
/*      */     //   21: aload_1
/*      */     //   22: monitorexit
/*      */     //   23: ireturn
/*      */     //   24: astore_2
/*      */     //   25: aload_1
/*      */     //   26: monitorexit
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     // Line number table:
/*      */     //   Java source line #6159	-> byte code offset #0
/*      */     //   Java source line #6160	-> byte code offset #12
/*      */     //   Java source line #6161	-> byte code offset #24
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	29	0	this	ResultSetImpl
/*      */     //   10	16	1	Ljava/lang/Object;	Object
/*      */     //   24	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	23	24	finally
/*      */     //   24	27	24	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 85	com/mysql/jdbc/ResultSetImpl:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 86 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 77	com/mysql/jdbc/ResultSetImpl:rowData	Lcom/mysql/jdbc/RowData;
/*      */     //   16: invokeinterface 617 1 0
/*      */     //   21: aload_1
/*      */     //   22: monitorexit
/*      */     //   23: ireturn
/*      */     //   24: astore_2
/*      */     //   25: aload_1
/*      */     //   26: monitorexit
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     // Line number table:
/*      */     //   Java source line #6178	-> byte code offset #0
/*      */     //   Java source line #6179	-> byte code offset #12
/*      */     //   Java source line #6180	-> byte code offset #24
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	29	0	this	ResultSetImpl
/*      */     //   10	16	1	Ljava/lang/Object;	Object
/*      */     //   24	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	23	24	finally
/*      */     //   24	27	24	finally
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ResultSetImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */