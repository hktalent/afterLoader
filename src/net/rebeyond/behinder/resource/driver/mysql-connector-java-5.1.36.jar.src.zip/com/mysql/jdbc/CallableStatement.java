/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CallableStatement
/*      */   extends PreparedStatement
/*      */   implements java.sql.CallableStatement
/*      */ {
/*      */   protected static final Constructor<?> JDBC_4_CSTMT_2_ARGS_CTOR;
/*      */   protected static final Constructor<?> JDBC_4_CSTMT_4_ARGS_CTOR;
/*      */   private static final int NOT_OUTPUT_PARAMETER_INDICATOR = Integer.MIN_VALUE;
/*      */   private static final String PARAMETER_NAMESPACE_PREFIX = "@com_mysql_jdbc_outparam_";
/*      */   
/*      */   static
/*      */   {
/*   59 */     if (Util.isJdbc4()) {
/*      */       try {
/*   61 */         JDBC_4_CSTMT_2_ARGS_CTOR = Class.forName("com.mysql.jdbc.JDBC4CallableStatement").getConstructor(new Class[] { MySQLConnection.class, CallableStatementParamInfo.class });
/*      */         
/*   63 */         JDBC_4_CSTMT_4_ARGS_CTOR = Class.forName("com.mysql.jdbc.JDBC4CallableStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, Boolean.TYPE });
/*      */       }
/*      */       catch (SecurityException e) {
/*   66 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*   68 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*   70 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*   73 */       JDBC_4_CSTMT_4_ARGS_CTOR = null;
/*   74 */       JDBC_4_CSTMT_2_ARGS_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class CallableStatementParam
/*      */   {
/*      */     int desiredJdbcType;
/*      */     
/*      */     int index;
/*      */     
/*      */     int inOutModifier;
/*      */     
/*      */     boolean isIn;
/*      */     
/*      */     boolean isOut;
/*      */     
/*      */     int jdbcType;
/*      */     
/*      */     short nullability;
/*      */     
/*      */     String paramName;
/*      */     
/*      */     int precision;
/*      */     int scale;
/*      */     String typeName;
/*      */     
/*      */     CallableStatementParam(String name, int idx, boolean in, boolean out, int jdbcType, String typeName, int precision, int scale, short nullability, int inOutModifier)
/*      */     {
/*  103 */       this.paramName = name;
/*  104 */       this.isIn = in;
/*  105 */       this.isOut = out;
/*  106 */       this.index = idx;
/*      */       
/*  108 */       this.jdbcType = jdbcType;
/*  109 */       this.typeName = typeName;
/*  110 */       this.precision = precision;
/*  111 */       this.scale = scale;
/*  112 */       this.nullability = nullability;
/*  113 */       this.inOutModifier = inOutModifier;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object clone()
/*      */       throws CloneNotSupportedException
/*      */     {
/*  123 */       return super.clone();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected class CallableStatementParamInfo
/*      */   {
/*      */     String catalogInUse;
/*      */     
/*      */     boolean isFunctionCall;
/*      */     
/*      */     String nativeSql;
/*      */     
/*      */     int numParameters;
/*      */     
/*      */     List<CallableStatement.CallableStatementParam> parameterList;
/*      */     
/*      */     Map<String, CallableStatement.CallableStatementParam> parameterMap;
/*      */     
/*  143 */     boolean isReadOnlySafeProcedure = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  148 */     boolean isReadOnlySafeChecked = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CallableStatementParamInfo(CallableStatementParamInfo fullParamInfo)
/*      */     {
/*  159 */       this.nativeSql = CallableStatement.this.originalSql;
/*  160 */       this.catalogInUse = CallableStatement.this.currentCatalog;
/*  161 */       this.isFunctionCall = fullParamInfo.isFunctionCall;
/*      */       
/*  163 */       int[] localParameterMap = CallableStatement.this.placeholderToParameterIndexMap;
/*  164 */       int parameterMapLength = localParameterMap.length;
/*      */       
/*  166 */       this.isReadOnlySafeProcedure = fullParamInfo.isReadOnlySafeProcedure;
/*  167 */       this.isReadOnlySafeChecked = fullParamInfo.isReadOnlySafeChecked;
/*  168 */       this.parameterList = new ArrayList(fullParamInfo.numParameters);
/*  169 */       this.parameterMap = new HashMap(fullParamInfo.numParameters);
/*      */       
/*  171 */       if (this.isFunctionCall)
/*      */       {
/*  173 */         this.parameterList.add(fullParamInfo.parameterList.get(0));
/*      */       }
/*      */       
/*  176 */       int offset = this.isFunctionCall ? 1 : 0;
/*      */       
/*  178 */       for (int i = 0; i < parameterMapLength; i++) {
/*  179 */         if (localParameterMap[i] != 0) {
/*  180 */           CallableStatement.CallableStatementParam param = (CallableStatement.CallableStatementParam)fullParamInfo.parameterList.get(localParameterMap[i] + offset);
/*      */           
/*  182 */           this.parameterList.add(param);
/*  183 */           this.parameterMap.put(param.paramName, param);
/*      */         }
/*      */       }
/*      */       
/*  187 */       this.numParameters = this.parameterList.size();
/*      */     }
/*      */     
/*      */     CallableStatementParamInfo(ResultSet paramTypesRs) throws SQLException
/*      */     {
/*  192 */       boolean hadRows = paramTypesRs.last();
/*      */       
/*  194 */       this.nativeSql = CallableStatement.this.originalSql;
/*  195 */       this.catalogInUse = CallableStatement.this.currentCatalog;
/*  196 */       this.isFunctionCall = CallableStatement.this.callingStoredFunction;
/*      */       
/*  198 */       if (hadRows) {
/*  199 */         this.numParameters = paramTypesRs.getRow();
/*      */         
/*  201 */         this.parameterList = new ArrayList(this.numParameters);
/*  202 */         this.parameterMap = new HashMap(this.numParameters);
/*      */         
/*  204 */         paramTypesRs.beforeFirst();
/*      */         
/*  206 */         addParametersFromDBMD(paramTypesRs);
/*      */       } else {
/*  208 */         this.numParameters = 0;
/*      */       }
/*      */       
/*  211 */       if (this.isFunctionCall) {
/*  212 */         this.numParameters += 1;
/*      */       }
/*      */     }
/*      */     
/*      */     private void addParametersFromDBMD(ResultSet paramTypesRs) throws SQLException {
/*  217 */       int i = 0;
/*      */       
/*  219 */       while (paramTypesRs.next()) {
/*  220 */         String paramName = paramTypesRs.getString(4);
/*  221 */         int inOutModifier = paramTypesRs.getInt(5);
/*      */         
/*  223 */         boolean isOutParameter = false;
/*  224 */         boolean isInParameter = false;
/*      */         
/*  226 */         if ((i == 0) && (this.isFunctionCall)) {
/*  227 */           isOutParameter = true;
/*  228 */           isInParameter = false;
/*  229 */         } else if (inOutModifier == 2) {
/*  230 */           isOutParameter = true;
/*  231 */           isInParameter = true;
/*  232 */         } else if (inOutModifier == 1) {
/*  233 */           isOutParameter = false;
/*  234 */           isInParameter = true;
/*  235 */         } else if (inOutModifier == 4) {
/*  236 */           isOutParameter = true;
/*  237 */           isInParameter = false;
/*      */         }
/*      */         
/*  240 */         int jdbcType = paramTypesRs.getInt(6);
/*  241 */         String typeName = paramTypesRs.getString(7);
/*  242 */         int precision = paramTypesRs.getInt(8);
/*  243 */         int scale = paramTypesRs.getInt(10);
/*  244 */         short nullability = paramTypesRs.getShort(12);
/*      */         
/*  246 */         CallableStatement.CallableStatementParam paramInfoToAdd = new CallableStatement.CallableStatementParam(paramName, i++, isInParameter, isOutParameter, jdbcType, typeName, precision, scale, nullability, inOutModifier);
/*      */         
/*      */ 
/*  249 */         this.parameterList.add(paramInfoToAdd);
/*  250 */         this.parameterMap.put(paramName, paramInfoToAdd);
/*      */       }
/*      */     }
/*      */     
/*      */     protected void checkBounds(int paramIndex) throws SQLException {
/*  255 */       int localParamIndex = paramIndex - 1;
/*      */       
/*  257 */       if ((paramIndex < 0) || (localParamIndex >= this.numParameters)) {
/*  258 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.11") + paramIndex + Messages.getString("CallableStatement.12") + this.numParameters + Messages.getString("CallableStatement.13"), "S1009", CallableStatement.this.getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object clone()
/*      */       throws CloneNotSupportedException
/*      */     {
/*  270 */       return super.clone();
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(int index) {
/*  274 */       return (CallableStatement.CallableStatementParam)this.parameterList.get(index);
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(String name) {
/*  278 */       return (CallableStatement.CallableStatementParam)this.parameterMap.get(name);
/*      */     }
/*      */     
/*      */     public String getParameterClassName(int arg0) throws SQLException {
/*  282 */       String mysqlTypeName = getParameterTypeName(arg0);
/*      */       
/*  284 */       boolean isBinaryOrBlob = (StringUtils.indexOfIgnoreCase(mysqlTypeName, "BLOB") != -1) || (StringUtils.indexOfIgnoreCase(mysqlTypeName, "BINARY") != -1);
/*      */       
/*  286 */       boolean isUnsigned = StringUtils.indexOfIgnoreCase(mysqlTypeName, "UNSIGNED") != -1;
/*      */       
/*  288 */       int mysqlTypeIfKnown = 0;
/*      */       
/*  290 */       if (StringUtils.startsWithIgnoreCase(mysqlTypeName, "MEDIUMINT")) {
/*  291 */         mysqlTypeIfKnown = 9;
/*      */       }
/*      */       
/*  294 */       return ResultSetMetaData.getClassNameForJavaType(getParameterType(arg0), isUnsigned, mysqlTypeIfKnown, isBinaryOrBlob, false, CallableStatement.this.connection.getYearIsDateType());
/*      */     }
/*      */     
/*      */     public int getParameterCount() throws SQLException
/*      */     {
/*  299 */       if (this.parameterList == null) {
/*  300 */         return 0;
/*      */       }
/*      */       
/*  303 */       return this.parameterList.size();
/*      */     }
/*      */     
/*      */     public int getParameterMode(int arg0) throws SQLException {
/*  307 */       checkBounds(arg0);
/*      */       
/*  309 */       return getParameter(arg0 - 1).inOutModifier;
/*      */     }
/*      */     
/*      */     public int getParameterType(int arg0) throws SQLException {
/*  313 */       checkBounds(arg0);
/*      */       
/*  315 */       return getParameter(arg0 - 1).jdbcType;
/*      */     }
/*      */     
/*      */     public String getParameterTypeName(int arg0) throws SQLException {
/*  319 */       checkBounds(arg0);
/*      */       
/*  321 */       return getParameter(arg0 - 1).typeName;
/*      */     }
/*      */     
/*      */     public int getPrecision(int arg0) throws SQLException {
/*  325 */       checkBounds(arg0);
/*      */       
/*  327 */       return getParameter(arg0 - 1).precision;
/*      */     }
/*      */     
/*      */     public int getScale(int arg0) throws SQLException {
/*  331 */       checkBounds(arg0);
/*      */       
/*  333 */       return getParameter(arg0 - 1).scale;
/*      */     }
/*      */     
/*      */     public int isNullable(int arg0) throws SQLException {
/*  337 */       checkBounds(arg0);
/*      */       
/*  339 */       return getParameter(arg0 - 1).nullability;
/*      */     }
/*      */     
/*      */     public boolean isSigned(int arg0) throws SQLException {
/*  343 */       checkBounds(arg0);
/*      */       
/*  345 */       return false;
/*      */     }
/*      */     
/*      */     Iterator<CallableStatement.CallableStatementParam> iterator() {
/*  349 */       return this.parameterList.iterator();
/*      */     }
/*      */     
/*      */     int numberOfParameters() {
/*  353 */       return this.numParameters;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected class CallableStatementParamInfoJDBC3
/*      */     extends CallableStatement.CallableStatementParamInfo
/*      */     implements ParameterMetaData
/*      */   {
/*      */     CallableStatementParamInfoJDBC3(ResultSet paramTypesRs)
/*      */       throws SQLException
/*      */     {
/*  366 */       super(paramTypesRs);
/*      */     }
/*      */     
/*      */     public CallableStatementParamInfoJDBC3(CallableStatement.CallableStatementParamInfo paramInfo) {
/*  370 */       super(paramInfo);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isWrapperFor(Class<?> iface)
/*      */       throws SQLException
/*      */     {
/*  391 */       CallableStatement.this.checkClosed();
/*      */       
/*      */ 
/*  394 */       return iface.isInstance(this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object unwrap(Class<?> iface)
/*      */       throws SQLException
/*      */     {
/*      */       try
/*      */       {
/*  416 */         return Util.cast(iface, this);
/*      */       } catch (ClassCastException cce) {
/*  418 */         throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", CallableStatement.this.getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String mangleParameterName(String origParameterName)
/*      */   {
/*  429 */     if (origParameterName == null) {
/*  430 */       return null;
/*      */     }
/*      */     
/*  433 */     int offset = 0;
/*      */     
/*  435 */     if ((origParameterName.length() > 0) && (origParameterName.charAt(0) == '@')) {
/*  436 */       offset = 1;
/*      */     }
/*      */     
/*  439 */     StringBuilder paramNameBuf = new StringBuilder("@com_mysql_jdbc_outparam_".length() + origParameterName.length());
/*  440 */     paramNameBuf.append("@com_mysql_jdbc_outparam_");
/*  441 */     paramNameBuf.append(origParameterName.substring(offset));
/*      */     
/*  443 */     return paramNameBuf.toString();
/*      */   }
/*      */   
/*  446 */   private boolean callingStoredFunction = false;
/*      */   
/*      */   private ResultSetInternalMethods functionReturnValueResults;
/*      */   
/*  450 */   private boolean hasOutputParams = false;
/*      */   
/*      */ 
/*      */   private ResultSetInternalMethods outputParameterResults;
/*      */   
/*      */ 
/*  456 */   protected boolean outputParamWasNull = false;
/*      */   
/*      */ 
/*      */ 
/*      */   private int[] parameterIndexToRsIndex;
/*      */   
/*      */ 
/*      */   protected CallableStatementParamInfo paramInfo;
/*      */   
/*      */ 
/*      */   private CallableStatementParam returnValueParam;
/*      */   
/*      */ 
/*      */   private int[] placeholderToParameterIndexMap;
/*      */   
/*      */ 
/*      */ 
/*      */   public CallableStatement(MySQLConnection conn, CallableStatementParamInfo paramInfo)
/*      */     throws SQLException
/*      */   {
/*  476 */     super(conn, paramInfo.nativeSql, paramInfo.catalogInUse);
/*      */     
/*  478 */     this.paramInfo = paramInfo;
/*  479 */     this.callingStoredFunction = this.paramInfo.isFunctionCall;
/*      */     
/*  481 */     if (this.callingStoredFunction) {
/*  482 */       this.parameterCount += 1;
/*      */     }
/*      */     
/*  485 */     this.retrieveGeneratedKeys = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static CallableStatement getInstance(MySQLConnection conn, String sql, String catalog, boolean isFunctionCall)
/*      */     throws SQLException
/*      */   {
/*  496 */     if (!Util.isJdbc4()) {
/*  497 */       return new CallableStatement(conn, sql, catalog, isFunctionCall);
/*      */     }
/*      */     
/*  500 */     return (CallableStatement)Util.handleNewInstance(JDBC_4_CSTMT_4_ARGS_CTOR, new Object[] { conn, sql, catalog, Boolean.valueOf(isFunctionCall) }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static CallableStatement getInstance(MySQLConnection conn, CallableStatementParamInfo paramInfo)
/*      */     throws SQLException
/*      */   {
/*  512 */     if (!Util.isJdbc4()) {
/*  513 */       return new CallableStatement(conn, paramInfo);
/*      */     }
/*      */     
/*  516 */     return (CallableStatement)Util.handleNewInstance(JDBC_4_CSTMT_2_ARGS_CTOR, new Object[] { conn, paramInfo }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */   private void generateParameterMap()
/*      */     throws SQLException
/*      */   {
/*  523 */     synchronized (checkClosed().getConnectionMutex()) {
/*  524 */       if (this.paramInfo == null) {
/*  525 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  530 */       int parameterCountFromMetaData = this.paramInfo.getParameterCount();
/*      */       
/*      */ 
/*      */ 
/*  534 */       if (this.callingStoredFunction) {
/*  535 */         parameterCountFromMetaData--;
/*      */       }
/*      */       
/*  538 */       if ((this.paramInfo != null) && (this.parameterCount != parameterCountFromMetaData)) {
/*  539 */         this.placeholderToParameterIndexMap = new int[this.parameterCount];
/*      */         
/*  541 */         int startPos = this.callingStoredFunction ? StringUtils.indexOfIgnoreCase(this.originalSql, "SELECT") : StringUtils.indexOfIgnoreCase(this.originalSql, "CALL");
/*      */         
/*      */ 
/*  544 */         if (startPos != -1) {
/*  545 */           int parenOpenPos = this.originalSql.indexOf('(', startPos + 4);
/*      */           
/*  547 */           if (parenOpenPos != -1) {
/*  548 */             int parenClosePos = StringUtils.indexOfIgnoreCase(parenOpenPos, this.originalSql, ")", "'", "'", StringUtils.SEARCH_MODE__ALL);
/*      */             
/*  550 */             if (parenClosePos != -1) {
/*  551 */               List<?> parsedParameters = StringUtils.split(this.originalSql.substring(parenOpenPos + 1, parenClosePos), ",", "'\"", "'\"", true);
/*      */               
/*  553 */               int numParsedParameters = parsedParameters.size();
/*      */               
/*      */ 
/*      */ 
/*  557 */               if (numParsedParameters != this.parameterCount) {}
/*      */               
/*      */ 
/*      */ 
/*  561 */               int placeholderCount = 0;
/*      */               
/*  563 */               for (int i = 0; i < numParsedParameters; i++) {
/*  564 */                 if (((String)parsedParameters.get(i)).equals("?")) {
/*  565 */                   this.placeholderToParameterIndexMap[(placeholderCount++)] = i;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatement(MySQLConnection conn, String sql, String catalog, boolean isFunctionCall)
/*      */     throws SQLException
/*      */   {
/*  589 */     super(conn, sql, catalog);
/*      */     
/*  591 */     this.callingStoredFunction = isFunctionCall;
/*      */     
/*  593 */     if (!this.callingStoredFunction) {
/*  594 */       if (!StringUtils.startsWithIgnoreCaseAndWs(sql, "CALL"))
/*      */       {
/*  596 */         fakeParameterTypes(false);
/*      */       } else {
/*  598 */         determineParameterTypes();
/*      */       }
/*      */       
/*  601 */       generateParameterMap();
/*      */     } else {
/*  603 */       determineParameterTypes();
/*  604 */       generateParameterMap();
/*      */       
/*  606 */       this.parameterCount += 1;
/*      */     }
/*      */     
/*  609 */     this.retrieveGeneratedKeys = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  619 */     setOutParams();
/*      */     
/*  621 */     super.addBatch();
/*      */   }
/*      */   
/*      */   private CallableStatementParam checkIsOutputParam(int paramIndex) throws SQLException
/*      */   {
/*  626 */     synchronized (checkClosed().getConnectionMutex()) {
/*  627 */       if (this.callingStoredFunction) {
/*  628 */         if (paramIndex == 1)
/*      */         {
/*  630 */           if (this.returnValueParam == null) {
/*  631 */             this.returnValueParam = new CallableStatementParam("", 0, false, true, 12, "VARCHAR", 0, 0, (short)2, 5);
/*      */           }
/*      */           
/*      */ 
/*  635 */           return this.returnValueParam;
/*      */         }
/*      */         
/*      */ 
/*  639 */         paramIndex--;
/*      */       }
/*      */       
/*  642 */       checkParameterIndexBounds(paramIndex);
/*      */       
/*  644 */       int localParamIndex = paramIndex - 1;
/*      */       
/*  646 */       if (this.placeholderToParameterIndexMap != null) {
/*  647 */         localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */       }
/*      */       
/*  650 */       CallableStatementParam paramDescriptor = this.paramInfo.getParameter(localParamIndex);
/*      */       
/*      */ 
/*      */ 
/*  654 */       if (this.connection.getNoAccessToProcedureBodies()) {
/*  655 */         paramDescriptor.isOut = true;
/*  656 */         paramDescriptor.isIn = true;
/*  657 */         paramDescriptor.inOutModifier = 2;
/*  658 */       } else if (!paramDescriptor.isOut) {
/*  659 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.9") + paramIndex + Messages.getString("CallableStatement.10"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*  663 */       this.hasOutputParams = true;
/*      */       
/*  665 */       return paramDescriptor;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkParameterIndexBounds(int paramIndex)
/*      */     throws SQLException
/*      */   {
/*  675 */     synchronized (checkClosed().getConnectionMutex()) {
/*  676 */       this.paramInfo.checkBounds(paramIndex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkStreamability()
/*      */     throws SQLException
/*      */   {
/*  688 */     if ((this.hasOutputParams) && (createStreamingResultSet())) {
/*  689 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.14"), "S1C00", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearParameters() throws SQLException
/*      */   {
/*  695 */     synchronized (checkClosed().getConnectionMutex()) {
/*  696 */       super.clearParameters();
/*      */       try
/*      */       {
/*  699 */         if (this.outputParameterResults != null) {
/*  700 */           this.outputParameterResults.close();
/*      */         }
/*      */       } finally {
/*  703 */         this.outputParameterResults = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fakeParameterTypes(boolean isReallyProcedure)
/*      */     throws SQLException
/*      */   {
/*  716 */     synchronized (checkClosed().getConnectionMutex()) {
/*  717 */       Field[] fields = new Field[13];
/*      */       
/*  719 */       fields[0] = new Field("", "PROCEDURE_CAT", 1, 0);
/*  720 */       fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 0);
/*  721 */       fields[2] = new Field("", "PROCEDURE_NAME", 1, 0);
/*  722 */       fields[3] = new Field("", "COLUMN_NAME", 1, 0);
/*  723 */       fields[4] = new Field("", "COLUMN_TYPE", 1, 0);
/*  724 */       fields[5] = new Field("", "DATA_TYPE", 5, 0);
/*  725 */       fields[6] = new Field("", "TYPE_NAME", 1, 0);
/*  726 */       fields[7] = new Field("", "PRECISION", 4, 0);
/*  727 */       fields[8] = new Field("", "LENGTH", 4, 0);
/*  728 */       fields[9] = new Field("", "SCALE", 5, 0);
/*  729 */       fields[10] = new Field("", "RADIX", 5, 0);
/*  730 */       fields[11] = new Field("", "NULLABLE", 5, 0);
/*  731 */       fields[12] = new Field("", "REMARKS", 1, 0);
/*      */       
/*  733 */       String procName = isReallyProcedure ? extractProcedureName() : null;
/*      */       
/*  735 */       byte[] procNameAsBytes = null;
/*      */       try
/*      */       {
/*  738 */         procNameAsBytes = procName == null ? null : StringUtils.getBytes(procName, "UTF-8");
/*      */       } catch (UnsupportedEncodingException ueEx) {
/*  740 */         procNameAsBytes = StringUtils.s2b(procName, this.connection);
/*      */       }
/*      */       
/*  743 */       ArrayList<ResultSetRow> resultRows = new ArrayList();
/*      */       
/*  745 */       for (int i = 0; i < this.parameterCount; i++) {
/*  746 */         byte[][] row = new byte[13][];
/*  747 */         row[0] = null;
/*  748 */         row[1] = null;
/*  749 */         row[2] = procNameAsBytes;
/*  750 */         row[3] = StringUtils.s2b(String.valueOf(i), this.connection);
/*      */         
/*  752 */         row[4] = StringUtils.s2b(String.valueOf(1), this.connection);
/*      */         
/*  754 */         row[5] = StringUtils.s2b(String.valueOf(12), this.connection);
/*  755 */         row[6] = StringUtils.s2b("VARCHAR", this.connection);
/*  756 */         row[7] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  757 */         row[8] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  758 */         row[9] = StringUtils.s2b(Integer.toString(0), this.connection);
/*  759 */         row[10] = StringUtils.s2b(Integer.toString(10), this.connection);
/*      */         
/*  761 */         row[11] = StringUtils.s2b(Integer.toString(2), this.connection);
/*      */         
/*  763 */         row[12] = null;
/*      */         
/*  765 */         resultRows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */       }
/*      */       
/*  768 */       ResultSet paramTypesRs = DatabaseMetaData.buildResultSet(fields, resultRows, this.connection);
/*      */       
/*  770 */       convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */     }
/*      */   }
/*      */   
/*      */   private void determineParameterTypes() throws SQLException {
/*  775 */     synchronized (checkClosed().getConnectionMutex()) {
/*  776 */       ResultSet paramTypesRs = null;
/*      */       
/*      */       try
/*      */       {
/*  780 */         String procName = extractProcedureName();
/*  781 */         String quotedId = "";
/*      */         try {
/*  783 */           quotedId = this.connection.supportsQuotedIdentifiers() ? this.connection.getMetaData().getIdentifierQuoteString() : "";
/*      */         }
/*      */         catch (SQLException sqlEx)
/*      */         {
/*  787 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */         
/*  790 */         List<?> parseList = StringUtils.splitDBdotName(procName, "", quotedId, this.connection.isNoBackslashEscapesSet());
/*  791 */         String tmpCatalog = "";
/*      */         
/*  793 */         if (parseList.size() == 2) {
/*  794 */           tmpCatalog = (String)parseList.get(0);
/*  795 */           procName = (String)parseList.get(1);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  800 */         java.sql.DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */         
/*  802 */         boolean useCatalog = false;
/*      */         
/*  804 */         if (tmpCatalog.length() <= 0) {
/*  805 */           useCatalog = true;
/*      */         }
/*      */         
/*  808 */         paramTypesRs = dbmd.getProcedureColumns((this.connection.versionMeetsMinimum(5, 0, 2)) && (useCatalog) ? this.currentCatalog : tmpCatalog, null, procName, "%");
/*      */         
/*      */ 
/*  811 */         boolean hasResults = false;
/*      */         try {
/*  813 */           if (paramTypesRs.next()) {
/*  814 */             paramTypesRs.previous();
/*  815 */             hasResults = true;
/*      */           }
/*      */         }
/*      */         catch (Exception e) {}
/*      */         
/*  820 */         if (hasResults) {
/*  821 */           convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */         } else {
/*  823 */           fakeParameterTypes(true);
/*      */         }
/*      */       } finally {
/*  826 */         SQLException sqlExRethrow = null;
/*      */         
/*  828 */         if (paramTypesRs != null) {
/*      */           try {
/*  830 */             paramTypesRs.close();
/*      */           } catch (SQLException sqlEx) {
/*  832 */             sqlExRethrow = sqlEx;
/*      */           }
/*      */           
/*  835 */           paramTypesRs = null;
/*      */         }
/*      */         
/*  838 */         if (sqlExRethrow != null) {
/*  839 */           throw sqlExRethrow;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void convertGetProcedureColumnsToInternalDescriptors(ResultSet paramTypesRs) throws SQLException {
/*  846 */     synchronized (checkClosed().getConnectionMutex()) {
/*  847 */       if (!this.connection.isRunningOnJDK13()) {
/*  848 */         this.paramInfo = new CallableStatementParamInfoJDBC3(paramTypesRs);
/*      */       } else {
/*  850 */         this.paramInfo = new CallableStatementParamInfo(paramTypesRs);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/*  862 */     synchronized (checkClosed().getConnectionMutex()) {
/*  863 */       boolean returnVal = false;
/*      */       
/*  865 */       checkStreamability();
/*      */       
/*  867 */       setInOutParamsOnServer();
/*  868 */       setOutParams();
/*      */       
/*  870 */       returnVal = super.execute();
/*      */       
/*  872 */       if (this.callingStoredFunction) {
/*  873 */         this.functionReturnValueResults = this.results;
/*  874 */         this.functionReturnValueResults.next();
/*  875 */         this.results = null;
/*      */       }
/*      */       
/*  878 */       retrieveOutParams();
/*      */       
/*  880 */       if (!this.callingStoredFunction) {
/*  881 */         return returnVal;
/*      */       }
/*      */       
/*      */ 
/*  885 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/*  896 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  898 */       checkStreamability();
/*      */       
/*  900 */       ResultSet execResults = null;
/*      */       
/*  902 */       setInOutParamsOnServer();
/*  903 */       setOutParams();
/*      */       
/*  905 */       execResults = super.executeQuery();
/*      */       
/*  907 */       retrieveOutParams();
/*      */       
/*  909 */       return execResults;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/*  920 */     synchronized (checkClosed().getConnectionMutex()) {
/*  921 */       int returnVal = -1;
/*      */       
/*  923 */       checkStreamability();
/*      */       
/*  925 */       if (this.callingStoredFunction) {
/*  926 */         execute();
/*      */         
/*  928 */         return -1;
/*      */       }
/*      */       
/*  931 */       setInOutParamsOnServer();
/*  932 */       setOutParams();
/*      */       
/*  934 */       returnVal = super.executeUpdate();
/*      */       
/*  936 */       retrieveOutParams();
/*      */       
/*  938 */       return returnVal;
/*      */     }
/*      */   }
/*      */   
/*      */   private String extractProcedureName() throws SQLException {
/*  943 */     String sanitizedSql = StringUtils.stripComments(this.originalSql, "`\"'", "`\"'", true, false, true, true);
/*      */     
/*      */ 
/*  946 */     int endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "CALL ");
/*  947 */     int offset = 5;
/*      */     
/*  949 */     if (endCallIndex == -1) {
/*  950 */       endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "SELECT ");
/*  951 */       offset = 7;
/*      */     }
/*      */     
/*  954 */     if (endCallIndex != -1) {
/*  955 */       StringBuilder nameBuf = new StringBuilder();
/*      */       
/*  957 */       String trimmedStatement = sanitizedSql.substring(endCallIndex + offset).trim();
/*      */       
/*  959 */       int statementLength = trimmedStatement.length();
/*      */       
/*  961 */       for (int i = 0; i < statementLength; i++) {
/*  962 */         char c = trimmedStatement.charAt(i);
/*      */         
/*  964 */         if ((Character.isWhitespace(c)) || (c == '(') || (c == '?')) {
/*      */           break;
/*      */         }
/*  967 */         nameBuf.append(c);
/*      */       }
/*      */       
/*      */ 
/*  971 */       return nameBuf.toString();
/*      */     }
/*      */     
/*  974 */     throw SQLError.createSQLException(Messages.getString("CallableStatement.1"), "S1000", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String fixParameterName(String paramNameIn)
/*      */     throws SQLException
/*      */   {
/*  989 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  991 */       if (((paramNameIn == null) || (paramNameIn.length() == 0)) && (!hasParametersView())) {
/*  992 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.0") + paramNameIn == null ? Messages.getString("CallableStatement.15") : Messages.getString("CallableStatement.16"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  997 */       if ((paramNameIn == null) && (hasParametersView())) {
/*  998 */         paramNameIn = "nullpn";
/*      */       }
/*      */       
/* 1001 */       if (this.connection.getNoAccessToProcedureBodies()) {
/* 1002 */         throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1006 */       return mangleParameterName(paramNameIn);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Array getArray(int i)
/*      */     throws SQLException
/*      */   {
/* 1014 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1015 */       ResultSetInternalMethods rs = getOutputParameters(i);
/*      */       
/* 1017 */       Array retValue = rs.getArray(mapOutputParameterIndexToRsIndex(i));
/*      */       
/* 1019 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1021 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Array getArray(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1029 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1030 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1032 */       Array retValue = rs.getArray(fixParameterName(parameterName));
/*      */       
/* 1034 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1036 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BigDecimal getBigDecimal(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1044 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1045 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1047 */       BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1049 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1051 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int parameterIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1066 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1067 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1069 */       BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex), scale);
/*      */       
/* 1071 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1073 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BigDecimal getBigDecimal(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1081 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1082 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1084 */       BigDecimal retValue = rs.getBigDecimal(fixParameterName(parameterName));
/*      */       
/* 1086 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1088 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Blob getBlob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1096 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1097 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1099 */       Blob retValue = rs.getBlob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1101 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1103 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Blob getBlob(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1111 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1112 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1114 */       Blob retValue = rs.getBlob(fixParameterName(parameterName));
/*      */       
/* 1116 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1118 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getBoolean(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1126 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1127 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1129 */       boolean retValue = rs.getBoolean(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1131 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1133 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getBoolean(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1141 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1142 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1144 */       boolean retValue = rs.getBoolean(fixParameterName(parameterName));
/*      */       
/* 1146 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1148 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public byte getByte(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1156 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1157 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1159 */       byte retValue = rs.getByte(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1161 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1163 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public byte getByte(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1171 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1172 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1174 */       byte retValue = rs.getByte(fixParameterName(parameterName));
/*      */       
/* 1176 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1178 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public byte[] getBytes(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1186 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1187 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1189 */       byte[] retValue = rs.getBytes(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1191 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1193 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public byte[] getBytes(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1201 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1202 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1204 */       byte[] retValue = rs.getBytes(fixParameterName(parameterName));
/*      */       
/* 1206 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1208 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Clob getClob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1216 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1217 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1219 */       Clob retValue = rs.getClob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1221 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1223 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Clob getClob(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1231 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1232 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1234 */       Clob retValue = rs.getClob(fixParameterName(parameterName));
/*      */       
/* 1236 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1238 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Date getDate(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1246 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1247 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1249 */       Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1251 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1253 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Date getDate(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1261 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1262 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1264 */       Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */       
/* 1266 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1268 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Date getDate(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1276 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1277 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1279 */       Date retValue = rs.getDate(fixParameterName(parameterName));
/*      */       
/* 1281 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1283 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Date getDate(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1291 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1292 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1294 */       Date retValue = rs.getDate(fixParameterName(parameterName), cal);
/*      */       
/* 1296 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1298 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public double getDouble(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1306 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1307 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1309 */       double retValue = rs.getDouble(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1311 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1313 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public double getDouble(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1321 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1322 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1324 */       double retValue = rs.getDouble(fixParameterName(parameterName));
/*      */       
/* 1326 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1328 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public float getFloat(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1336 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1337 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1339 */       float retValue = rs.getFloat(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1341 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1343 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public float getFloat(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1351 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1352 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1354 */       float retValue = rs.getFloat(fixParameterName(parameterName));
/*      */       
/* 1356 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1358 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getInt(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1366 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1367 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1369 */       int retValue = rs.getInt(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1371 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1373 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getInt(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1381 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1382 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1384 */       int retValue = rs.getInt(fixParameterName(parameterName));
/*      */       
/* 1386 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1388 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public long getLong(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1396 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1397 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1399 */       long retValue = rs.getLong(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1401 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1403 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public long getLong(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1411 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1412 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1414 */       long retValue = rs.getLong(fixParameterName(parameterName));
/*      */       
/* 1416 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1418 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */   protected int getNamedParamIndex(String paramName, boolean forOut) throws SQLException {
/* 1423 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1424 */       if (this.connection.getNoAccessToProcedureBodies()) {
/* 1425 */         throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1430 */       if ((paramName == null) || (paramName.length() == 0)) {
/* 1431 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.2"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 1434 */       if (this.paramInfo == null) {
/* 1435 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.3") + paramName + Messages.getString("CallableStatement.4"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1439 */       CallableStatementParam namedParamInfo = this.paramInfo.getParameter(paramName);
/*      */       
/* 1441 */       if ((forOut) && (!namedParamInfo.isOut)) {
/* 1442 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.5") + paramName + Messages.getString("CallableStatement.6"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1446 */       if (this.placeholderToParameterIndexMap == null) {
/* 1447 */         return namedParamInfo.index + 1;
/*      */       }
/*      */       
/* 1450 */       for (int i = 0; i < this.placeholderToParameterIndexMap.length; i++) {
/* 1451 */         if (this.placeholderToParameterIndexMap[i] == namedParamInfo.index) {
/* 1452 */           return i + 1;
/*      */         }
/*      */       }
/*      */       
/* 1456 */       throw SQLError.createSQLException("Can't find local placeholder mapping for parameter named \"" + paramName + "\".", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1465 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1466 */       CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/*      */       
/* 1468 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1470 */       Object retVal = rs.getObjectStoredProc(mapOutputParameterIndexToRsIndex(parameterIndex), paramDescriptor.desiredJdbcType);
/*      */       
/* 1472 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1474 */       return retVal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getObject(int parameterIndex, Map<String, Class<?>> map)
/*      */     throws SQLException
/*      */   {
/* 1482 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1483 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1485 */       Object retVal = rs.getObject(mapOutputParameterIndexToRsIndex(parameterIndex), map);
/*      */       
/* 1487 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1489 */       return retVal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getObject(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1497 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1498 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1500 */       Object retValue = rs.getObject(fixParameterName(parameterName));
/*      */       
/* 1502 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1504 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getObject(String parameterName, Map<String, Class<?>> map)
/*      */     throws SQLException
/*      */   {
/* 1512 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1513 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1515 */       Object retValue = rs.getObject(fixParameterName(parameterName), map);
/*      */       
/* 1517 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1519 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */   public <T> T getObject(int parameterIndex, Class<T> type) throws SQLException
/*      */   {
/* 1525 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1526 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/*      */ 
/* 1529 */       T retVal = ((ResultSetImpl)rs).getObject(mapOutputParameterIndexToRsIndex(parameterIndex), type);
/*      */       
/* 1531 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1533 */       return retVal;
/*      */     }
/*      */   }
/*      */   
/*      */   public <T> T getObject(String parameterName, Class<T> type) throws SQLException {
/* 1538 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1539 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1541 */       T retValue = ((ResultSetImpl)rs).getObject(fixParameterName(parameterName), type);
/*      */       
/* 1543 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1545 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSetInternalMethods getOutputParameters(int paramIndex)
/*      */     throws SQLException
/*      */   {
/* 1560 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1561 */       this.outputParamWasNull = false;
/*      */       
/* 1563 */       if ((paramIndex == 1) && (this.callingStoredFunction) && (this.returnValueParam != null)) {
/* 1564 */         return this.functionReturnValueResults;
/*      */       }
/*      */       
/* 1567 */       if (this.outputParameterResults == null) {
/* 1568 */         if (this.paramInfo.numberOfParameters() == 0) {
/* 1569 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.7"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/* 1572 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.8"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */       
/* 1575 */       return this.outputParameterResults;
/*      */     }
/*      */   }
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException
/*      */   {
/* 1581 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1582 */       if (this.placeholderToParameterIndexMap == null) {
/* 1583 */         return (CallableStatementParamInfoJDBC3)this.paramInfo;
/*      */       }
/*      */       
/* 1586 */       return new CallableStatementParamInfoJDBC3(this.paramInfo);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Ref getRef(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1594 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1595 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1597 */       Ref retValue = rs.getRef(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1599 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1601 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Ref getRef(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1609 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1610 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1612 */       Ref retValue = rs.getRef(fixParameterName(parameterName));
/*      */       
/* 1614 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1616 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public short getShort(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1624 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1625 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1627 */       short retValue = rs.getShort(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1629 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1631 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public short getShort(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1639 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1640 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1642 */       short retValue = rs.getShort(fixParameterName(parameterName));
/*      */       
/* 1644 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1646 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String getString(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1654 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1655 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1657 */       String retValue = rs.getString(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1659 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1661 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String getString(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1669 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1670 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1672 */       String retValue = rs.getString(fixParameterName(parameterName));
/*      */       
/* 1674 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1676 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Time getTime(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1684 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1685 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1687 */       Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1689 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1691 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Time getTime(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1699 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1700 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1702 */       Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */       
/* 1704 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1706 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Time getTime(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1714 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1715 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1717 */       Time retValue = rs.getTime(fixParameterName(parameterName));
/*      */       
/* 1719 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1721 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Time getTime(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1729 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1730 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1732 */       Time retValue = rs.getTime(fixParameterName(parameterName), cal);
/*      */       
/* 1734 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1736 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1744 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1745 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1747 */       Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1749 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1751 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1759 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1760 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1762 */       Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */       
/* 1764 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1766 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1774 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1775 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1777 */       Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName));
/*      */       
/* 1779 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1781 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1789 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1790 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1792 */       Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName), cal);
/*      */       
/* 1794 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1796 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1804 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1805 */       ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 1807 */       URL retValue = rs.getURL(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 1809 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1811 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1819 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1820 */       ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 1822 */       URL retValue = rs.getURL(fixParameterName(parameterName));
/*      */       
/* 1824 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 1826 */       return retValue;
/*      */     }
/*      */   }
/*      */   
/*      */   protected int mapOutputParameterIndexToRsIndex(int paramIndex) throws SQLException
/*      */   {
/* 1832 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1833 */       if ((this.returnValueParam != null) && (paramIndex == 1)) {
/* 1834 */         return 1;
/*      */       }
/*      */       
/* 1837 */       checkParameterIndexBounds(paramIndex);
/*      */       
/* 1839 */       int localParamIndex = paramIndex - 1;
/*      */       
/* 1841 */       if (this.placeholderToParameterIndexMap != null) {
/* 1842 */         localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */       }
/*      */       
/* 1845 */       int rsIndex = this.parameterIndexToRsIndex[localParamIndex];
/*      */       
/* 1847 */       if (rsIndex == Integer.MIN_VALUE) {
/* 1848 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.21") + paramIndex + Messages.getString("CallableStatement.22"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1852 */       return rsIndex + 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1860 */     CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/* 1861 */     paramDescriptor.desiredJdbcType = sqlType;
/*      */   }
/*      */   
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 1868 */     registerOutParameter(parameterIndex, sqlType);
/*      */   }
/*      */   
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1875 */     checkIsOutputParam(parameterIndex);
/*      */   }
/*      */   
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1882 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1883 */       registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 1891 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */   }
/*      */   
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1898 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, typeName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void retrieveOutParams()
/*      */     throws SQLException
/*      */   {
/* 1908 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1909 */       int numParameters = this.paramInfo.numberOfParameters();
/*      */       
/* 1911 */       this.parameterIndexToRsIndex = new int[numParameters];
/*      */       
/* 1913 */       for (int i = 0; i < numParameters; i++) {
/* 1914 */         this.parameterIndexToRsIndex[i] = Integer.MIN_VALUE;
/*      */       }
/*      */       
/* 1917 */       int localParamIndex = 0;
/*      */       
/* 1919 */       if (numParameters > 0) {
/* 1920 */         StringBuilder outParameterQuery = new StringBuilder("SELECT ");
/*      */         
/* 1922 */         boolean firstParam = true;
/* 1923 */         boolean hadOutputParams = false;
/*      */         
/* 1925 */         for (Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator(); paramIter.hasNext();) {
/* 1926 */           CallableStatementParam retrParamInfo = (CallableStatementParam)paramIter.next();
/*      */           
/* 1928 */           if (retrParamInfo.isOut) {
/* 1929 */             hadOutputParams = true;
/*      */             
/* 1931 */             this.parameterIndexToRsIndex[retrParamInfo.index] = (localParamIndex++);
/*      */             
/* 1933 */             if ((retrParamInfo.paramName == null) && (hasParametersView())) {
/* 1934 */               retrParamInfo.paramName = ("nullnp" + retrParamInfo.index);
/*      */             }
/*      */             
/* 1937 */             String outParameterName = mangleParameterName(retrParamInfo.paramName);
/*      */             
/* 1939 */             if (!firstParam) {
/* 1940 */               outParameterQuery.append(",");
/*      */             } else {
/* 1942 */               firstParam = false;
/*      */             }
/*      */             
/* 1945 */             if (!outParameterName.startsWith("@")) {
/* 1946 */               outParameterQuery.append('@');
/*      */             }
/*      */             
/* 1949 */             outParameterQuery.append(outParameterName);
/*      */           }
/*      */         }
/*      */         
/* 1953 */         if (hadOutputParams)
/*      */         {
/* 1955 */           Statement outParameterStmt = null;
/* 1956 */           ResultSet outParamRs = null;
/*      */           try
/*      */           {
/* 1959 */             outParameterStmt = this.connection.createStatement();
/* 1960 */             outParamRs = outParameterStmt.executeQuery(outParameterQuery.toString());
/* 1961 */             this.outputParameterResults = ((ResultSetInternalMethods)outParamRs).copy();
/*      */             
/* 1963 */             if (!this.outputParameterResults.next()) {
/* 1964 */               this.outputParameterResults.close();
/* 1965 */               this.outputParameterResults = null;
/*      */             }
/*      */           } finally {
/* 1968 */             if (outParameterStmt != null) {
/* 1969 */               outParameterStmt.close();
/*      */             }
/*      */           }
/*      */         } else {
/* 1973 */           this.outputParameterResults = null;
/*      */         }
/*      */       } else {
/* 1976 */         this.outputParameterResults = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAsciiStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1985 */     setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBigDecimal(String parameterName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1992 */     setBigDecimal(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1999 */     setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBoolean(String parameterName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 2006 */     setBoolean(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setByte(String parameterName, byte x)
/*      */     throws SQLException
/*      */   {
/* 2013 */     setByte(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(String parameterName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 2020 */     setBytes(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCharacterStream(String parameterName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 2027 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDate(String parameterName, Date x)
/*      */     throws SQLException
/*      */   {
/* 2034 */     setDate(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDate(String parameterName, Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2041 */     setDate(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDouble(String parameterName, double x)
/*      */     throws SQLException
/*      */   {
/* 2048 */     setDouble(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2055 */   public void setFloat(String parameterName, float x)
/* 2055 */     throws SQLException { setFloat(getNamedParamIndex(parameterName, false), x); }
/*      */   
/*      */   private void setInOutParamsOnServer() throws SQLException {
/*      */     Iterator<CallableStatementParam> paramIter;
/* 2059 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2060 */       if (this.paramInfo.numParameters > 0) {
/* 2061 */         for (paramIter = this.paramInfo.iterator(); paramIter.hasNext();)
/*      */         {
/* 2063 */           CallableStatementParam inParamInfo = (CallableStatementParam)paramIter.next();
/*      */           
/*      */ 
/* 2066 */           if ((inParamInfo.isOut) && (inParamInfo.isIn)) {
/* 2067 */             if ((inParamInfo.paramName == null) && (hasParametersView())) {
/* 2068 */               inParamInfo.paramName = ("nullnp" + inParamInfo.index);
/*      */             }
/*      */             
/* 2071 */             String inOutParameterName = mangleParameterName(inParamInfo.paramName);
/* 2072 */             StringBuilder queryBuf = new StringBuilder(4 + inOutParameterName.length() + 1 + 1);
/* 2073 */             queryBuf.append("SET ");
/* 2074 */             queryBuf.append(inOutParameterName);
/* 2075 */             queryBuf.append("=?");
/*      */             
/* 2077 */             PreparedStatement setPstmt = null;
/*      */             try
/*      */             {
/* 2080 */               setPstmt = (PreparedStatement)this.connection.clientPrepareStatement(queryBuf.toString());
/*      */               
/* 2082 */               if (this.isNull[inParamInfo.index] != 0) {
/* 2083 */                 setPstmt.setBytesNoEscapeNoQuotes(1, "NULL".getBytes());
/*      */               }
/*      */               else {
/* 2086 */                 byte[] parameterAsBytes = getBytesRepresentation(inParamInfo.index);
/*      */                 
/* 2088 */                 if (parameterAsBytes != null) {
/* 2089 */                   if ((parameterAsBytes.length > 8) && (parameterAsBytes[0] == 95) && (parameterAsBytes[1] == 98) && (parameterAsBytes[2] == 105) && (parameterAsBytes[3] == 110) && (parameterAsBytes[4] == 97) && (parameterAsBytes[5] == 114) && (parameterAsBytes[6] == 121) && (parameterAsBytes[7] == 39))
/*      */                   {
/*      */ 
/* 2092 */                     setPstmt.setBytesNoEscapeNoQuotes(1, parameterAsBytes);
/*      */                   } else {
/* 2094 */                     int sqlType = inParamInfo.desiredJdbcType;
/*      */                     
/* 2096 */                     switch (sqlType) {
/*      */                     case -7: 
/*      */                     case -4: 
/*      */                     case -3: 
/*      */                     case -2: 
/*      */                     case 2000: 
/*      */                     case 2004: 
/* 2103 */                       setPstmt.setBytes(1, parameterAsBytes);
/* 2104 */                       break;
/*      */                     
/*      */                     default: 
/* 2107 */                       setPstmt.setBytesNoEscape(1, parameterAsBytes);
/*      */                     }
/*      */                   }
/*      */                 } else {
/* 2111 */                   setPstmt.setNull(1, 0);
/*      */                 }
/*      */               }
/*      */               
/* 2115 */               setPstmt.executeUpdate();
/*      */             } finally {
/* 2117 */               if (setPstmt != null) {
/* 2118 */                 setPstmt.close();
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInt(String parameterName, int x)
/*      */     throws SQLException
/*      */   {
/* 2131 */     setInt(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLong(String parameterName, long x)
/*      */     throws SQLException
/*      */   {
/* 2138 */     setLong(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 2145 */     setNull(getNamedParamIndex(parameterName, false), sqlType);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 2152 */     setNull(getNamedParamIndex(parameterName, false), sqlType, typeName);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setObject(String parameterName, Object x)
/*      */     throws SQLException
/*      */   {
/* 2159 */     setObject(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setObject(String parameterName, Object x, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/* 2166 */     setObject(getNamedParamIndex(parameterName, false), x, targetSqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void setOutParams()
/*      */     throws SQLException
/*      */   {
/*      */     Iterator<CallableStatementParam> paramIter;
/*      */     
/* 2176 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2177 */       if (this.paramInfo.numParameters > 0) {
/* 2178 */         for (paramIter = this.paramInfo.iterator(); paramIter.hasNext();) {
/* 2179 */           CallableStatementParam outParamInfo = (CallableStatementParam)paramIter.next();
/*      */           
/* 2181 */           if ((!this.callingStoredFunction) && (outParamInfo.isOut))
/*      */           {
/* 2183 */             if ((outParamInfo.paramName == null) && (hasParametersView())) {
/* 2184 */               outParamInfo.paramName = ("nullnp" + outParamInfo.index);
/*      */             }
/*      */             
/* 2187 */             String outParameterName = mangleParameterName(outParamInfo.paramName);
/*      */             
/* 2189 */             int outParamIndex = 0;
/*      */             
/* 2191 */             if (this.placeholderToParameterIndexMap == null) {
/* 2192 */               outParamIndex = outParamInfo.index + 1;
/*      */             }
/*      */             else {
/* 2195 */               boolean found = false;
/*      */               
/* 2197 */               for (int i = 0; i < this.placeholderToParameterIndexMap.length; i++) {
/* 2198 */                 if (this.placeholderToParameterIndexMap[i] == outParamInfo.index) {
/* 2199 */                   outParamIndex = i + 1;
/* 2200 */                   found = true;
/* 2201 */                   break;
/*      */                 }
/*      */               }
/*      */               
/* 2205 */               if (!found) {
/* 2206 */                 throw SQLError.createSQLException("boo!", "S1000", this.connection.getExceptionInterceptor());
/*      */               }
/*      */             }
/*      */             
/* 2210 */             setBytesNoEscapeNoQuotes(outParamIndex, StringUtils.getBytes(outParameterName, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setShort(String parameterName, short x)
/*      */     throws SQLException
/*      */   {
/* 2222 */     setShort(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setString(String parameterName, String x)
/*      */     throws SQLException
/*      */   {
/* 2229 */     setString(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTime(String parameterName, Time x)
/*      */     throws SQLException
/*      */   {
/* 2236 */     setTime(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTime(String parameterName, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2243 */     setTime(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2250 */     setTimestamp(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2257 */     setTimestamp(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setURL(String parameterName, URL val)
/*      */     throws SQLException
/*      */   {
/* 2264 */     setURL(getNamedParamIndex(parameterName, false), val);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 2278 */     if (this.hasOutputParams) {
/* 2279 */       throw SQLError.createSQLException("Can't call executeBatch() on CallableStatement with OUTPUT parameters", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 2283 */     return super.executeBatch();
/*      */   }
/*      */   
/*      */   protected int getParameterIndexOffset()
/*      */   {
/* 2288 */     if (this.callingStoredFunction) {
/* 2289 */       return -1;
/*      */     }
/*      */     
/* 2292 */     return super.getParameterIndexOffset();
/*      */   }
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
/* 2296 */     setAsciiStream(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException
/*      */   {
/* 2301 */     setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x) throws SQLException
/*      */   {
/* 2306 */     setBinaryStream(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException
/*      */   {
/* 2311 */     setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */   public void setBlob(String parameterName, Blob x) throws SQLException
/*      */   {
/* 2316 */     setBlob(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setBlob(String parameterName, InputStream inputStream) throws SQLException
/*      */   {
/* 2321 */     setBlob(getNamedParamIndex(parameterName, false), inputStream);
/*      */   }
/*      */   
/*      */   public void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException
/*      */   {
/* 2326 */     setBlob(getNamedParamIndex(parameterName, false), inputStream, length);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader) throws SQLException
/*      */   {
/* 2331 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException
/*      */   {
/* 2336 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */   
/*      */   public void setClob(String parameterName, Clob x) throws SQLException
/*      */   {
/* 2341 */     setClob(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setClob(String parameterName, Reader reader) throws SQLException
/*      */   {
/* 2346 */     setClob(getNamedParamIndex(parameterName, false), reader);
/*      */   }
/*      */   
/*      */   public void setClob(String parameterName, Reader reader, long length) throws SQLException
/*      */   {
/* 2351 */     setClob(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader value) throws SQLException
/*      */   {
/* 2356 */     setNCharacterStream(getNamedParamIndex(parameterName, false), value);
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException
/*      */   {
/* 2361 */     setNCharacterStream(getNamedParamIndex(parameterName, false), value, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkReadOnlyProcedure()
/*      */     throws SQLException
/*      */   {
/* 2372 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2373 */       if (this.connection.getNoAccessToProcedureBodies()) {
/* 2374 */         return false;
/*      */       }
/*      */       
/* 2377 */       if (this.paramInfo.isReadOnlySafeChecked) {
/* 2378 */         return this.paramInfo.isReadOnlySafeProcedure;
/*      */       }
/*      */       
/* 2381 */       ResultSet rs = null;
/* 2382 */       java.sql.PreparedStatement ps = null;
/*      */       try
/*      */       {
/* 2385 */         String procName = extractProcedureName();
/*      */         
/* 2387 */         String catalog = this.currentCatalog;
/*      */         
/* 2389 */         if (procName.indexOf(".") != -1) {
/* 2390 */           catalog = procName.substring(0, procName.indexOf("."));
/*      */           
/* 2392 */           if ((StringUtils.startsWithIgnoreCaseAndWs(catalog, "`")) && (catalog.trim().endsWith("`"))) {
/* 2393 */             catalog = catalog.substring(1, catalog.length() - 1);
/*      */           }
/*      */           
/* 2396 */           procName = procName.substring(procName.indexOf(".") + 1);
/* 2397 */           procName = StringUtils.toString(StringUtils.stripEnclosure(StringUtils.getBytes(procName), "`", "`"));
/*      */         }
/* 2399 */         ps = this.connection.prepareStatement("SELECT SQL_DATA_ACCESS FROM information_schema.routines WHERE routine_schema = ? AND routine_name = ?");
/* 2400 */         ps.setMaxRows(0);
/* 2401 */         ps.setFetchSize(0);
/*      */         
/* 2403 */         ps.setString(1, catalog);
/* 2404 */         ps.setString(2, procName);
/* 2405 */         rs = ps.executeQuery();
/* 2406 */         if (rs.next()) {
/* 2407 */           String sqlDataAccess = rs.getString(1);
/* 2408 */           if (("READS SQL DATA".equalsIgnoreCase(sqlDataAccess)) || ("NO SQL".equalsIgnoreCase(sqlDataAccess))) {
/* 2409 */             synchronized (this.paramInfo) {
/* 2410 */               this.paramInfo.isReadOnlySafeChecked = true;
/* 2411 */               this.paramInfo.isReadOnlySafeProcedure = true;
/*      */             }
/* 2413 */             ??? = 1;jsr 30;return ???;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (SQLException e) {}finally
/*      */       {
/* 2419 */         jsr 6; } localObject3 = returnAddress; if (rs != null) {
/* 2420 */         rs.close();
/*      */       }
/* 2422 */       if (ps != null)
/* 2423 */         ps.close(); ret;
/*      */       
/*      */ 
/*      */ 
/* 2427 */       this.paramInfo.isReadOnlySafeChecked = false;
/* 2428 */       this.paramInfo.isReadOnlySafeProcedure = false;
/*      */     }
/* 2430 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean checkReadOnlySafeStatement()
/*      */     throws SQLException
/*      */   {
/* 2436 */     return (super.checkReadOnlySafeStatement()) || (checkReadOnlyProcedure());
/*      */   }
/*      */   
/*      */   private boolean hasParametersView() throws SQLException {
/* 2440 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 2442 */         if (this.connection.versionMeetsMinimum(5, 5, 0)) {
/* 2443 */           java.sql.DatabaseMetaData dbmd1 = new DatabaseMetaDataUsingInfoSchema(this.connection, this.connection.getCatalog());
/* 2444 */           return ((DatabaseMetaDataUsingInfoSchema)dbmd1).gethasParametersView();
/*      */         }
/*      */         
/* 2447 */         return false;
/*      */       } catch (SQLException e) {
/* 2449 */         return false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setObject(String parameterName, Object x, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   /* Error */
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 30	com/mysql/jdbc/CallableStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 31 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 15	com/mysql/jdbc/CallableStatement:outputParamWasNull	Z
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: ireturn
/*      */     //   19: astore_2
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: aload_2
/*      */     //   23: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2271	-> byte code offset #0
/*      */     //   Java source line #2272	-> byte code offset #12
/*      */     //   Java source line #2273	-> byte code offset #19
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	24	0	this	CallableStatement
/*      */     //   10	11	1	Ljava/lang/Object;	Object
/*      */     //   19	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	18	19	finally
/*      */     //   19	22	19	finally
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/CallableStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */