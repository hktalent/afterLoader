/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.jmx.LoadBalanceConnectionGroupManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionGroupManager
/*     */ {
/*  37 */   private static HashMap<String, ConnectionGroup> GROUP_MAP = new HashMap();
/*     */   
/*  39 */   private static LoadBalanceConnectionGroupManager mbean = new LoadBalanceConnectionGroupManager();
/*     */   
/*  41 */   private static boolean hasRegisteredJmx = false;
/*     */   
/*     */   public static synchronized ConnectionGroup getConnectionGroupInstance(String groupName) {
/*  44 */     if (GROUP_MAP.containsKey(groupName)) {
/*  45 */       return (ConnectionGroup)GROUP_MAP.get(groupName);
/*     */     }
/*  47 */     ConnectionGroup group = new ConnectionGroup(groupName);
/*  48 */     GROUP_MAP.put(groupName, group);
/*  49 */     return group;
/*     */   }
/*     */   
/*     */   public static void registerJmx() throws SQLException {
/*  53 */     if (hasRegisteredJmx) {
/*  54 */       return;
/*     */     }
/*     */     
/*  57 */     mbean.registerJmx();
/*  58 */     hasRegisteredJmx = true;
/*     */   }
/*     */   
/*     */   public static ConnectionGroup getConnectionGroup(String groupName) {
/*  62 */     return (ConnectionGroup)GROUP_MAP.get(groupName);
/*     */   }
/*     */   
/*     */   private static Collection<ConnectionGroup> getGroupsMatching(String group) {
/*  66 */     if ((group == null) || (group.equals(""))) {
/*  67 */       Set<ConnectionGroup> s = new HashSet();
/*     */       
/*  69 */       s.addAll(GROUP_MAP.values());
/*  70 */       return s;
/*     */     }
/*  72 */     Set<ConnectionGroup> s = new HashSet();
/*  73 */     ConnectionGroup o = (ConnectionGroup)GROUP_MAP.get(group);
/*  74 */     if (o != null) {
/*  75 */       s.add(o);
/*     */     }
/*  77 */     return s;
/*     */   }
/*     */   
/*     */   public static void addHost(String group, String host, boolean forExisting)
/*     */   {
/*  82 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/*  83 */     for (ConnectionGroup cg : s) {
/*  84 */       cg.addHost(host, forExisting);
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getActiveHostCount(String group)
/*     */   {
/*  90 */     Set<String> active = new HashSet();
/*  91 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/*  92 */     for (ConnectionGroup cg : s) {
/*  93 */       active.addAll(cg.getInitialHosts());
/*     */     }
/*  95 */     return active.size();
/*     */   }
/*     */   
/*     */   public static long getActiveLogicalConnectionCount(String group) {
/*  99 */     int count = 0;
/* 100 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 101 */     for (ConnectionGroup cg : s) {
/* 102 */       count = (int)(count + cg.getActiveLogicalConnectionCount());
/*     */     }
/* 104 */     return count;
/*     */   }
/*     */   
/*     */   public static long getActivePhysicalConnectionCount(String group) {
/* 108 */     int count = 0;
/* 109 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 110 */     for (ConnectionGroup cg : s) {
/* 111 */       count = (int)(count + cg.getActivePhysicalConnectionCount());
/*     */     }
/* 113 */     return count;
/*     */   }
/*     */   
/*     */   public static int getTotalHostCount(String group) {
/* 117 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 118 */     Set<String> hosts = new HashSet();
/* 119 */     for (ConnectionGroup cg : s) {
/* 120 */       hosts.addAll(cg.getInitialHosts());
/* 121 */       hosts.addAll(cg.getClosedHosts());
/*     */     }
/* 123 */     return hosts.size();
/*     */   }
/*     */   
/*     */   public static long getTotalLogicalConnectionCount(String group) {
/* 127 */     long count = 0L;
/* 128 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 129 */     for (ConnectionGroup cg : s) {
/* 130 */       count += cg.getTotalLogicalConnectionCount();
/*     */     }
/* 132 */     return count;
/*     */   }
/*     */   
/*     */   public static long getTotalPhysicalConnectionCount(String group) {
/* 136 */     long count = 0L;
/* 137 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 138 */     for (ConnectionGroup cg : s) {
/* 139 */       count += cg.getTotalPhysicalConnectionCount();
/*     */     }
/* 141 */     return count;
/*     */   }
/*     */   
/*     */   public static long getTotalTransactionCount(String group) {
/* 145 */     long count = 0L;
/* 146 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 147 */     for (ConnectionGroup cg : s) {
/* 148 */       count += cg.getTotalTransactionCount();
/*     */     }
/* 150 */     return count;
/*     */   }
/*     */   
/*     */   public static void removeHost(String group, String host) throws SQLException {
/* 154 */     removeHost(group, host, false);
/*     */   }
/*     */   
/*     */   public static void removeHost(String group, String host, boolean removeExisting) throws SQLException {
/* 158 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 159 */     for (ConnectionGroup cg : s) {
/* 160 */       cg.removeHost(host, removeExisting);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getActiveHostLists(String group) {
/* 165 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 166 */     Map<String, Integer> hosts = new HashMap();
/* 167 */     for (ConnectionGroup cg : s)
/*     */     {
/* 169 */       Collection<String> l = cg.getInitialHosts();
/* 170 */       for (String host : l) {
/* 171 */         Integer o = (Integer)hosts.get(host);
/* 172 */         if (o == null) {
/* 173 */           o = Integer.valueOf(1);
/*     */         } else {
/* 175 */           o = Integer.valueOf(o.intValue() + 1);
/*     */         }
/* 177 */         hosts.put(host, o);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 182 */     StringBuilder sb = new StringBuilder();
/* 183 */     String sep = "";
/* 184 */     for (String host : hosts.keySet()) {
/* 185 */       sb.append(sep);
/* 186 */       sb.append(host);
/* 187 */       sb.append('(');
/* 188 */       sb.append(hosts.get(host));
/* 189 */       sb.append(')');
/* 190 */       sep = ",";
/*     */     }
/* 192 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getRegisteredConnectionGroups() {
/* 196 */     Collection<ConnectionGroup> s = getGroupsMatching(null);
/* 197 */     StringBuilder sb = new StringBuilder();
/* 198 */     String sep = "";
/* 199 */     for (ConnectionGroup cg : s) {
/* 200 */       String group = cg.getGroupName();
/* 201 */       sb.append(sep);
/* 202 */       sb.append(group);
/* 203 */       sep = ",";
/*     */     }
/* 205 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ConnectionGroupManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */