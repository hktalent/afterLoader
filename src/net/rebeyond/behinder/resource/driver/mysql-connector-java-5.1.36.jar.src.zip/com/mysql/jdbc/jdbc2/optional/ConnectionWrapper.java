/*      */ package com.mysql.jdbc.jdbc2.optional;
/*      */ 
/*      */ import com.mysql.jdbc.Connection;
/*      */ import com.mysql.jdbc.ExceptionInterceptor;
/*      */ import com.mysql.jdbc.Extension;
/*      */ import com.mysql.jdbc.MySQLConnection;
/*      */ import com.mysql.jdbc.SQLError;
/*      */ import com.mysql.jdbc.Util;
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionWrapper
/*      */   extends WrapperBase
/*      */   implements Connection
/*      */ {
/*   54 */   protected Connection mc = null;
/*      */   
/*   56 */   private String invalidHandleStr = "Logical handle no longer valid";
/*      */   
/*      */   private boolean closed;
/*      */   
/*      */   private boolean isForXa;
/*      */   private static final Constructor<?> JDBC_4_CONNECTION_WRAPPER_CTOR;
/*      */   
/*      */   static
/*      */   {
/*   65 */     if (Util.isJdbc4()) {
/*      */       try {
/*   67 */         JDBC_4_CONNECTION_WRAPPER_CTOR = Class.forName("com.mysql.jdbc.jdbc2.optional.JDBC4ConnectionWrapper").getConstructor(new Class[] { MysqlPooledConnection.class, Connection.class, Boolean.TYPE });
/*      */       }
/*      */       catch (SecurityException e) {
/*   70 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*   72 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*   74 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*   77 */       JDBC_4_CONNECTION_WRAPPER_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static ConnectionWrapper getInstance(MysqlPooledConnection mysqlPooledConnection, Connection mysqlConnection, boolean forXa) throws SQLException {
/*   82 */     if (!Util.isJdbc4()) {
/*   83 */       return new ConnectionWrapper(mysqlPooledConnection, mysqlConnection, forXa);
/*      */     }
/*      */     
/*   86 */     return (ConnectionWrapper)Util.handleNewInstance(JDBC_4_CONNECTION_WRAPPER_CTOR, new Object[] { mysqlPooledConnection, mysqlConnection, Boolean.valueOf(forXa) }, mysqlPooledConnection.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConnectionWrapper(MysqlPooledConnection mysqlPooledConnection, Connection mysqlConnection, boolean forXa)
/*      */     throws SQLException
/*      */   {
/*  102 */     super(mysqlPooledConnection);
/*      */     
/*  104 */     this.mc = mysqlConnection;
/*  105 */     this.closed = false;
/*  106 */     this.isForXa = forXa;
/*      */     
/*  108 */     if (this.isForXa) {
/*  109 */       setInGlobalTx(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoCommit(boolean autoCommit)
/*      */     throws SQLException
/*      */   {
/*  120 */     checkClosed();
/*      */     
/*  122 */     if ((autoCommit) && (isInGlobalTx())) {
/*  123 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  128 */       this.mc.setAutoCommit(autoCommit);
/*      */     } catch (SQLException sqlException) {
/*  130 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAutoCommit()
/*      */     throws SQLException
/*      */   {
/*  141 */     checkClosed();
/*      */     try
/*      */     {
/*  144 */       return this.mc.getAutoCommit();
/*      */     } catch (SQLException sqlException) {
/*  146 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  149 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCatalog(String catalog)
/*      */     throws SQLException
/*      */   {
/*  159 */     checkClosed();
/*      */     try
/*      */     {
/*  162 */       this.mc.setCatalog(catalog);
/*      */     } catch (SQLException sqlException) {
/*  164 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCatalog()
/*      */     throws SQLException
/*      */   {
/*  178 */     checkClosed();
/*      */     try
/*      */     {
/*  181 */       return this.mc.getCatalog();
/*      */     } catch (SQLException sqlException) {
/*  183 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  186 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isClosed()
/*      */     throws SQLException
/*      */   {
/*  196 */     return (this.closed) || (this.mc.isClosed());
/*      */   }
/*      */   
/*      */   public boolean isMasterConnection() {
/*  200 */     return this.mc.isMasterConnection();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setHoldability(int arg0)
/*      */     throws SQLException
/*      */   {
/*  207 */     checkClosed();
/*      */     try
/*      */     {
/*  210 */       this.mc.setHoldability(arg0);
/*      */     } catch (SQLException sqlException) {
/*  212 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getHoldability()
/*      */     throws SQLException
/*      */   {
/*  220 */     checkClosed();
/*      */     try
/*      */     {
/*  223 */       return this.mc.getHoldability();
/*      */     } catch (SQLException sqlException) {
/*  225 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  228 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getIdleFor()
/*      */   {
/*  238 */     return this.mc.getIdleFor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DatabaseMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  251 */     checkClosed();
/*      */     try
/*      */     {
/*  254 */       return this.mc.getMetaData();
/*      */     } catch (SQLException sqlException) {
/*  256 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  259 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadOnly(boolean readOnly)
/*      */     throws SQLException
/*      */   {
/*  269 */     checkClosed();
/*      */     try
/*      */     {
/*  272 */       this.mc.setReadOnly(readOnly);
/*      */     } catch (SQLException sqlException) {
/*  274 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/*  285 */     checkClosed();
/*      */     try
/*      */     {
/*  288 */       return this.mc.isReadOnly();
/*      */     } catch (SQLException sqlException) {
/*  290 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  293 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public Savepoint setSavepoint()
/*      */     throws SQLException
/*      */   {
/*  300 */     checkClosed();
/*      */     
/*  302 */     if (isInGlobalTx()) {
/*  303 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  308 */       return this.mc.setSavepoint();
/*      */     } catch (SQLException sqlException) {
/*  310 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  313 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Savepoint setSavepoint(String arg0)
/*      */     throws SQLException
/*      */   {
/*  320 */     checkClosed();
/*      */     
/*  322 */     if (isInGlobalTx()) {
/*  323 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  328 */       return this.mc.setSavepoint(arg0);
/*      */     } catch (SQLException sqlException) {
/*  330 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  333 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransactionIsolation(int level)
/*      */     throws SQLException
/*      */   {
/*  343 */     checkClosed();
/*      */     try
/*      */     {
/*  346 */       this.mc.setTransactionIsolation(level);
/*      */     } catch (SQLException sqlException) {
/*  348 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/*  359 */     checkClosed();
/*      */     try
/*      */     {
/*  362 */       return this.mc.getTransactionIsolation();
/*      */     } catch (SQLException sqlException) {
/*  364 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  367 */     return 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, Class<?>> getTypeMap()
/*      */     throws SQLException
/*      */   {
/*  378 */     checkClosed();
/*      */     try
/*      */     {
/*  381 */       return this.mc.getTypeMap();
/*      */     } catch (SQLException sqlException) {
/*  383 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  386 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  396 */     checkClosed();
/*      */     try
/*      */     {
/*  399 */       return this.mc.getWarnings();
/*      */     } catch (SQLException sqlException) {
/*  401 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  404 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  415 */     checkClosed();
/*      */     try
/*      */     {
/*  418 */       this.mc.clearWarnings();
/*      */     } catch (SQLException sqlException) {
/*  420 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  435 */     close(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void commit()
/*      */     throws SQLException
/*      */   {
/*  446 */     checkClosed();
/*      */     
/*  448 */     if (isInGlobalTx()) {
/*  449 */       throw SQLError.createSQLException("Can't call commit() on an XAConnection associated with a global transaction", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  454 */       this.mc.commit();
/*      */     } catch (SQLException sqlException) {
/*  456 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Statement createStatement()
/*      */     throws SQLException
/*      */   {
/*  467 */     checkClosed();
/*      */     try
/*      */     {
/*  470 */       return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement());
/*      */     } catch (SQLException sqlException) {
/*  472 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  475 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Statement createStatement(int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  485 */     checkClosed();
/*      */     try
/*      */     {
/*  488 */       return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement(resultSetType, resultSetConcurrency));
/*      */     } catch (SQLException sqlException) {
/*  490 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  493 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Statement createStatement(int arg0, int arg1, int arg2)
/*      */     throws SQLException
/*      */   {
/*  500 */     checkClosed();
/*      */     try
/*      */     {
/*  503 */       return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement(arg0, arg1, arg2));
/*      */     } catch (SQLException sqlException) {
/*  505 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  508 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String nativeSQL(String sql)
/*      */     throws SQLException
/*      */   {
/*  518 */     checkClosed();
/*      */     try
/*      */     {
/*  521 */       return this.mc.nativeSQL(sql);
/*      */     } catch (SQLException sqlException) {
/*  523 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  526 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatement prepareCall(String sql)
/*      */     throws SQLException
/*      */   {
/*  536 */     checkClosed();
/*      */     try
/*      */     {
/*  539 */       return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(sql));
/*      */     } catch (SQLException sqlException) {
/*  541 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  544 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  554 */     checkClosed();
/*      */     try
/*      */     {
/*  557 */       return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(sql, resultSetType, resultSetConcurrency));
/*      */     } catch (SQLException sqlException) {
/*  559 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  562 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public CallableStatement prepareCall(String arg0, int arg1, int arg2, int arg3)
/*      */     throws SQLException
/*      */   {
/*  569 */     checkClosed();
/*      */     try
/*      */     {
/*  572 */       return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(arg0, arg1, arg2, arg3));
/*      */     } catch (SQLException sqlException) {
/*  574 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  577 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepare(String sql) throws SQLException {
/*  581 */     checkClosed();
/*      */     try
/*      */     {
/*  584 */       return new PreparedStatementWrapper(this, this.pooledConnection, this.mc.clientPrepareStatement(sql));
/*      */     } catch (SQLException sqlException) {
/*  586 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  589 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepare(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  593 */     checkClosed();
/*      */     try
/*      */     {
/*  596 */       return new PreparedStatementWrapper(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     } catch (SQLException sqlException) {
/*  598 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  601 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/*  611 */     checkClosed();
/*      */     try
/*      */     {
/*  614 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(sql));
/*      */     } catch (SQLException sqlException) {
/*  616 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  619 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  629 */     checkClosed();
/*      */     try
/*      */     {
/*  632 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     } catch (SQLException sqlException) {
/*  634 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  637 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public PreparedStatement prepareStatement(String arg0, int arg1, int arg2, int arg3)
/*      */     throws SQLException
/*      */   {
/*  644 */     checkClosed();
/*      */     try
/*      */     {
/*  647 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1, arg2, arg3));
/*      */     } catch (SQLException sqlException) {
/*  649 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  652 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public PreparedStatement prepareStatement(String arg0, int arg1)
/*      */     throws SQLException
/*      */   {
/*  659 */     checkClosed();
/*      */     try
/*      */     {
/*  662 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1));
/*      */     } catch (SQLException sqlException) {
/*  664 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  667 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public PreparedStatement prepareStatement(String arg0, int[] arg1)
/*      */     throws SQLException
/*      */   {
/*  674 */     checkClosed();
/*      */     try
/*      */     {
/*  677 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1));
/*      */     } catch (SQLException sqlException) {
/*  679 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  682 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public PreparedStatement prepareStatement(String arg0, String[] arg1)
/*      */     throws SQLException
/*      */   {
/*  689 */     checkClosed();
/*      */     try
/*      */     {
/*  692 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1));
/*      */     } catch (SQLException sqlException) {
/*  694 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  697 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public void releaseSavepoint(Savepoint arg0)
/*      */     throws SQLException
/*      */   {
/*  704 */     checkClosed();
/*      */     try
/*      */     {
/*  707 */       this.mc.releaseSavepoint(arg0);
/*      */     } catch (SQLException sqlException) {
/*  709 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLException
/*      */   {
/*  720 */     checkClosed();
/*      */     
/*  722 */     if (isInGlobalTx()) {
/*  723 */       throw SQLError.createSQLException("Can't call rollback() on an XAConnection associated with a global transaction", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  728 */       this.mc.rollback();
/*      */     } catch (SQLException sqlException) {
/*  730 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void rollback(Savepoint arg0)
/*      */     throws SQLException
/*      */   {
/*  738 */     checkClosed();
/*      */     
/*  740 */     if (isInGlobalTx()) {
/*  741 */       throw SQLError.createSQLException("Can't call rollback() on an XAConnection associated with a global transaction", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  746 */       this.mc.rollback(arg0);
/*      */     } catch (SQLException sqlException) {
/*  748 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isSameResource(Connection c) {
/*  753 */     if ((c instanceof ConnectionWrapper)) {
/*  754 */       return this.mc.isSameResource(((ConnectionWrapper)c).mc);
/*      */     }
/*  756 */     return this.mc.isSameResource(c);
/*      */   }
/*      */   
/*      */   protected void close(boolean fireClosedEvent) throws SQLException {
/*  760 */     synchronized (this.pooledConnection) {
/*  761 */       if (this.closed) {
/*  762 */         return;
/*      */       }
/*      */       
/*  765 */       if ((!isInGlobalTx()) && (this.mc.getRollbackOnPooledClose()) && (!getAutoCommit())) {
/*  766 */         rollback();
/*      */       }
/*      */       
/*  769 */       if (fireClosedEvent) {
/*  770 */         this.pooledConnection.callConnectionEventListeners(2, null);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  775 */       this.closed = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public void checkClosed() throws SQLException {
/*  780 */     if (this.closed) {
/*  781 */       throw SQLError.createSQLException(this.invalidHandleStr, this.exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx() {
/*  786 */     return this.mc.isInGlobalTx();
/*      */   }
/*      */   
/*      */   public void setInGlobalTx(boolean flag) {
/*  790 */     this.mc.setInGlobalTx(flag);
/*      */   }
/*      */   
/*      */   public void ping() throws SQLException {
/*  794 */     if (this.mc != null) {
/*  795 */       this.mc.ping();
/*      */     }
/*      */   }
/*      */   
/*      */   public void changeUser(String userName, String newPassword) throws SQLException {
/*  800 */     checkClosed();
/*      */     try
/*      */     {
/*  803 */       this.mc.changeUser(userName, newPassword);
/*      */     } catch (SQLException sqlException) {
/*  805 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearHasTriedMaster() {
/*  810 */     this.mc.clearHasTriedMaster();
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*  814 */     checkClosed();
/*      */     try
/*      */     {
/*  817 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql));
/*      */     } catch (SQLException sqlException) {
/*  819 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  822 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     try {
/*  827 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyIndex));
/*      */     } catch (SQLException sqlException) {
/*  829 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  832 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     try {
/*  837 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     } catch (SQLException sqlException) {
/*  839 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  842 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*      */   {
/*      */     try {
/*  848 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
/*      */     }
/*      */     catch (SQLException sqlException) {
/*  851 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  854 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     try {
/*  859 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyIndexes));
/*      */     } catch (SQLException sqlException) {
/*  861 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  864 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     try {
/*  869 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyColNames));
/*      */     } catch (SQLException sqlException) {
/*  871 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  874 */     return null;
/*      */   }
/*      */   
/*      */   public int getActiveStatementCount() {
/*  878 */     return this.mc.getActiveStatementCount();
/*      */   }
/*      */   
/*      */   public Log getLog() throws SQLException {
/*  882 */     return this.mc.getLog();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getServerCharacterEncoding()
/*      */   {
/*  890 */     return getServerCharset();
/*      */   }
/*      */   
/*      */   public String getServerCharset() {
/*  894 */     return this.mc.getServerCharset();
/*      */   }
/*      */   
/*      */   public TimeZone getServerTimezoneTZ() {
/*  898 */     return this.mc.getServerTimezoneTZ();
/*      */   }
/*      */   
/*      */   public String getStatementComment() {
/*  902 */     return this.mc.getStatementComment();
/*      */   }
/*      */   
/*      */   public boolean hasTriedMaster() {
/*  906 */     return this.mc.hasTriedMaster();
/*      */   }
/*      */   
/*      */   public boolean isAbonormallyLongQuery(long millisOrNanos) {
/*  910 */     return this.mc.isAbonormallyLongQuery(millisOrNanos);
/*      */   }
/*      */   
/*      */   public boolean isNoBackslashEscapesSet() {
/*  914 */     return this.mc.isNoBackslashEscapesSet();
/*      */   }
/*      */   
/*      */   public boolean lowerCaseTableNames() {
/*  918 */     return this.mc.lowerCaseTableNames();
/*      */   }
/*      */   
/*      */   public boolean parserKnowsUnicode() {
/*  922 */     return this.mc.parserKnowsUnicode();
/*      */   }
/*      */   
/*      */   public void reportQueryTime(long millisOrNanos) {
/*  926 */     this.mc.reportQueryTime(millisOrNanos);
/*      */   }
/*      */   
/*      */   public void resetServerState() throws SQLException {
/*  930 */     checkClosed();
/*      */     try
/*      */     {
/*  933 */       this.mc.resetServerState();
/*      */     } catch (SQLException sqlException) {
/*  935 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/*  940 */     checkClosed();
/*      */     try
/*      */     {
/*  943 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql));
/*      */     } catch (SQLException sqlException) {
/*  945 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  948 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     try {
/*  953 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyIndex));
/*      */     } catch (SQLException sqlException) {
/*  955 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  958 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     try {
/*  963 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     } catch (SQLException sqlException) {
/*  965 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  968 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException
/*      */   {
/*      */     try {
/*  974 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
/*      */     }
/*      */     catch (SQLException sqlException) {
/*  977 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  980 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     try {
/*  985 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyIndexes));
/*      */     } catch (SQLException sqlException) {
/*  987 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/*  990 */     return null;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     try {
/*  995 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyColNames));
/*      */     } catch (SQLException sqlException) {
/*  997 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/* 1000 */     return null;
/*      */   }
/*      */   
/*      */   public void setFailedOver(boolean flag) {
/* 1004 */     this.mc.setFailedOver(flag);
/*      */   }
/*      */   
/*      */   public void setPreferSlaveDuringFailover(boolean flag)
/*      */   {
/* 1009 */     this.mc.setPreferSlaveDuringFailover(flag);
/*      */   }
/*      */   
/*      */   public void setStatementComment(String comment) {
/* 1013 */     this.mc.setStatementComment(comment);
/*      */   }
/*      */   
/*      */   public void shutdownServer() throws SQLException
/*      */   {
/* 1018 */     checkClosed();
/*      */     try
/*      */     {
/* 1021 */       this.mc.shutdownServer();
/*      */     } catch (SQLException sqlException) {
/* 1023 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean supportsIsolationLevel()
/*      */   {
/* 1029 */     return this.mc.supportsIsolationLevel();
/*      */   }
/*      */   
/*      */   public boolean supportsQuotedIdentifiers() {
/* 1033 */     return this.mc.supportsQuotedIdentifiers();
/*      */   }
/*      */   
/*      */   public boolean supportsTransactions() {
/* 1037 */     return this.mc.supportsTransactions();
/*      */   }
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException {
/* 1041 */     checkClosed();
/*      */     try
/*      */     {
/* 1044 */       return this.mc.versionMeetsMinimum(major, minor, subminor);
/*      */     } catch (SQLException sqlException) {
/* 1046 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/* 1049 */     return false;
/*      */   }
/*      */   
/*      */   public String exposeAsXml() throws SQLException {
/* 1053 */     checkClosed();
/*      */     try
/*      */     {
/* 1056 */       return this.mc.exposeAsXml();
/*      */     } catch (SQLException sqlException) {
/* 1058 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */     
/* 1061 */     return null;
/*      */   }
/*      */   
/*      */   public boolean getAllowLoadLocalInfile() {
/* 1065 */     return this.mc.getAllowLoadLocalInfile();
/*      */   }
/*      */   
/*      */   public boolean getAllowMultiQueries() {
/* 1069 */     return this.mc.getAllowMultiQueries();
/*      */   }
/*      */   
/*      */   public boolean getAllowNanAndInf() {
/* 1073 */     return this.mc.getAllowNanAndInf();
/*      */   }
/*      */   
/*      */   public boolean getAllowUrlInLocalInfile() {
/* 1077 */     return this.mc.getAllowUrlInLocalInfile();
/*      */   }
/*      */   
/*      */   public boolean getAlwaysSendSetIsolation() {
/* 1081 */     return this.mc.getAlwaysSendSetIsolation();
/*      */   }
/*      */   
/*      */   public boolean getAutoClosePStmtStreams() {
/* 1085 */     return this.mc.getAutoClosePStmtStreams();
/*      */   }
/*      */   
/*      */   public boolean getAutoDeserialize() {
/* 1089 */     return this.mc.getAutoDeserialize();
/*      */   }
/*      */   
/*      */   public boolean getAutoGenerateTestcaseScript() {
/* 1093 */     return this.mc.getAutoGenerateTestcaseScript();
/*      */   }
/*      */   
/*      */   public boolean getAutoReconnectForPools() {
/* 1097 */     return this.mc.getAutoReconnectForPools();
/*      */   }
/*      */   
/*      */   public boolean getAutoSlowLog() {
/* 1101 */     return this.mc.getAutoSlowLog();
/*      */   }
/*      */   
/*      */   public int getBlobSendChunkSize() {
/* 1105 */     return this.mc.getBlobSendChunkSize();
/*      */   }
/*      */   
/*      */   public boolean getBlobsAreStrings() {
/* 1109 */     return this.mc.getBlobsAreStrings();
/*      */   }
/*      */   
/*      */   public boolean getCacheCallableStatements() {
/* 1113 */     return this.mc.getCacheCallableStatements();
/*      */   }
/*      */   
/*      */   public boolean getCacheCallableStmts() {
/* 1117 */     return this.mc.getCacheCallableStmts();
/*      */   }
/*      */   
/*      */   public boolean getCachePrepStmts() {
/* 1121 */     return this.mc.getCachePrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getCachePreparedStatements() {
/* 1125 */     return this.mc.getCachePreparedStatements();
/*      */   }
/*      */   
/*      */   public boolean getCacheResultSetMetadata() {
/* 1129 */     return this.mc.getCacheResultSetMetadata();
/*      */   }
/*      */   
/*      */   public boolean getCacheServerConfiguration() {
/* 1133 */     return this.mc.getCacheServerConfiguration();
/*      */   }
/*      */   
/*      */   public int getCallableStatementCacheSize() {
/* 1137 */     return this.mc.getCallableStatementCacheSize();
/*      */   }
/*      */   
/*      */   public int getCallableStmtCacheSize() {
/* 1141 */     return this.mc.getCallableStmtCacheSize();
/*      */   }
/*      */   
/*      */   public boolean getCapitalizeTypeNames() {
/* 1145 */     return this.mc.getCapitalizeTypeNames();
/*      */   }
/*      */   
/*      */   public String getCharacterSetResults() {
/* 1149 */     return this.mc.getCharacterSetResults();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStorePassword() {
/* 1153 */     return this.mc.getClientCertificateKeyStorePassword();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStoreType() {
/* 1157 */     return this.mc.getClientCertificateKeyStoreType();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStoreUrl() {
/* 1161 */     return this.mc.getClientCertificateKeyStoreUrl();
/*      */   }
/*      */   
/*      */   public String getClientInfoProvider() {
/* 1165 */     return this.mc.getClientInfoProvider();
/*      */   }
/*      */   
/*      */   public String getClobCharacterEncoding() {
/* 1169 */     return this.mc.getClobCharacterEncoding();
/*      */   }
/*      */   
/*      */   public boolean getClobberStreamingResults() {
/* 1173 */     return this.mc.getClobberStreamingResults();
/*      */   }
/*      */   
/*      */   public int getConnectTimeout() {
/* 1177 */     return this.mc.getConnectTimeout();
/*      */   }
/*      */   
/*      */   public String getConnectionCollation() {
/* 1181 */     return this.mc.getConnectionCollation();
/*      */   }
/*      */   
/*      */   public String getConnectionLifecycleInterceptors() {
/* 1185 */     return this.mc.getConnectionLifecycleInterceptors();
/*      */   }
/*      */   
/*      */   public boolean getContinueBatchOnError() {
/* 1189 */     return this.mc.getContinueBatchOnError();
/*      */   }
/*      */   
/*      */   public boolean getCreateDatabaseIfNotExist() {
/* 1193 */     return this.mc.getCreateDatabaseIfNotExist();
/*      */   }
/*      */   
/*      */   public int getDefaultFetchSize() {
/* 1197 */     return this.mc.getDefaultFetchSize();
/*      */   }
/*      */   
/*      */   public boolean getDontTrackOpenResources() {
/* 1201 */     return this.mc.getDontTrackOpenResources();
/*      */   }
/*      */   
/*      */   public boolean getDumpMetadataOnColumnNotFound() {
/* 1205 */     return this.mc.getDumpMetadataOnColumnNotFound();
/*      */   }
/*      */   
/*      */   public boolean getDumpQueriesOnException() {
/* 1209 */     return this.mc.getDumpQueriesOnException();
/*      */   }
/*      */   
/*      */   public boolean getDynamicCalendars() {
/* 1213 */     return this.mc.getDynamicCalendars();
/*      */   }
/*      */   
/*      */   public boolean getElideSetAutoCommits() {
/* 1217 */     return this.mc.getElideSetAutoCommits();
/*      */   }
/*      */   
/*      */   public boolean getEmptyStringsConvertToZero() {
/* 1221 */     return this.mc.getEmptyStringsConvertToZero();
/*      */   }
/*      */   
/*      */   public boolean getEmulateLocators() {
/* 1225 */     return this.mc.getEmulateLocators();
/*      */   }
/*      */   
/*      */   public boolean getEmulateUnsupportedPstmts() {
/* 1229 */     return this.mc.getEmulateUnsupportedPstmts();
/*      */   }
/*      */   
/*      */   public boolean getEnablePacketDebug() {
/* 1233 */     return this.mc.getEnablePacketDebug();
/*      */   }
/*      */   
/*      */   public boolean getEnableQueryTimeouts() {
/* 1237 */     return this.mc.getEnableQueryTimeouts();
/*      */   }
/*      */   
/*      */   public String getEncoding() {
/* 1241 */     return this.mc.getEncoding();
/*      */   }
/*      */   
/*      */   public boolean getExplainSlowQueries() {
/* 1245 */     return this.mc.getExplainSlowQueries();
/*      */   }
/*      */   
/*      */   public boolean getFailOverReadOnly() {
/* 1249 */     return this.mc.getFailOverReadOnly();
/*      */   }
/*      */   
/*      */   public boolean getFunctionsNeverReturnBlobs() {
/* 1253 */     return this.mc.getFunctionsNeverReturnBlobs();
/*      */   }
/*      */   
/*      */   public boolean getGatherPerfMetrics() {
/* 1257 */     return this.mc.getGatherPerfMetrics();
/*      */   }
/*      */   
/*      */   public boolean getGatherPerformanceMetrics() {
/* 1261 */     return this.mc.getGatherPerformanceMetrics();
/*      */   }
/*      */   
/*      */   public boolean getGenerateSimpleParameterMetadata() {
/* 1265 */     return this.mc.getGenerateSimpleParameterMetadata();
/*      */   }
/*      */   
/*      */   public boolean getHoldResultsOpenOverStatementClose() {
/* 1269 */     return this.mc.getHoldResultsOpenOverStatementClose();
/*      */   }
/*      */   
/*      */   public boolean getIgnoreNonTxTables() {
/* 1273 */     return this.mc.getIgnoreNonTxTables();
/*      */   }
/*      */   
/*      */   public boolean getIncludeInnodbStatusInDeadlockExceptions() {
/* 1277 */     return this.mc.getIncludeInnodbStatusInDeadlockExceptions();
/*      */   }
/*      */   
/*      */   public int getInitialTimeout() {
/* 1281 */     return this.mc.getInitialTimeout();
/*      */   }
/*      */   
/*      */   public boolean getInteractiveClient() {
/* 1285 */     return this.mc.getInteractiveClient();
/*      */   }
/*      */   
/*      */   public boolean getIsInteractiveClient() {
/* 1289 */     return this.mc.getIsInteractiveClient();
/*      */   }
/*      */   
/*      */   public boolean getJdbcCompliantTruncation() {
/* 1293 */     return this.mc.getJdbcCompliantTruncation();
/*      */   }
/*      */   
/*      */   public boolean getJdbcCompliantTruncationForReads() {
/* 1297 */     return this.mc.getJdbcCompliantTruncationForReads();
/*      */   }
/*      */   
/*      */   public String getLargeRowSizeThreshold() {
/* 1301 */     return this.mc.getLargeRowSizeThreshold();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceStrategy() {
/* 1305 */     return this.mc.getLoadBalanceStrategy();
/*      */   }
/*      */   
/*      */   public String getLocalSocketAddress() {
/* 1309 */     return this.mc.getLocalSocketAddress();
/*      */   }
/*      */   
/*      */   public int getLocatorFetchBufferSize() {
/* 1313 */     return this.mc.getLocatorFetchBufferSize();
/*      */   }
/*      */   
/*      */   public boolean getLogSlowQueries() {
/* 1317 */     return this.mc.getLogSlowQueries();
/*      */   }
/*      */   
/*      */   public boolean getLogXaCommands() {
/* 1321 */     return this.mc.getLogXaCommands();
/*      */   }
/*      */   
/*      */   public String getLogger() {
/* 1325 */     return this.mc.getLogger();
/*      */   }
/*      */   
/*      */   public String getLoggerClassName() {
/* 1329 */     return this.mc.getLoggerClassName();
/*      */   }
/*      */   
/*      */   public boolean getMaintainTimeStats() {
/* 1333 */     return this.mc.getMaintainTimeStats();
/*      */   }
/*      */   
/*      */   public int getMaxQuerySizeToLog() {
/* 1337 */     return this.mc.getMaxQuerySizeToLog();
/*      */   }
/*      */   
/*      */   public int getMaxReconnects() {
/* 1341 */     return this.mc.getMaxReconnects();
/*      */   }
/*      */   
/*      */   public int getMaxRows() {
/* 1345 */     return this.mc.getMaxRows();
/*      */   }
/*      */   
/*      */   public int getMetadataCacheSize() {
/* 1349 */     return this.mc.getMetadataCacheSize();
/*      */   }
/*      */   
/*      */   public int getNetTimeoutForStreamingResults() {
/* 1353 */     return this.mc.getNetTimeoutForStreamingResults();
/*      */   }
/*      */   
/*      */   public boolean getNoAccessToProcedureBodies() {
/* 1357 */     return this.mc.getNoAccessToProcedureBodies();
/*      */   }
/*      */   
/*      */   public boolean getNoDatetimeStringSync() {
/* 1361 */     return this.mc.getNoDatetimeStringSync();
/*      */   }
/*      */   
/*      */   public boolean getNoTimezoneConversionForTimeType() {
/* 1365 */     return this.mc.getNoTimezoneConversionForTimeType();
/*      */   }
/*      */   
/*      */   public boolean getNoTimezoneConversionForDateType() {
/* 1369 */     return this.mc.getNoTimezoneConversionForDateType();
/*      */   }
/*      */   
/*      */   public boolean getCacheDefaultTimezone() {
/* 1373 */     return this.mc.getCacheDefaultTimezone();
/*      */   }
/*      */   
/*      */   public boolean getNullCatalogMeansCurrent() {
/* 1377 */     return this.mc.getNullCatalogMeansCurrent();
/*      */   }
/*      */   
/*      */   public boolean getNullNamePatternMatchesAll() {
/* 1381 */     return this.mc.getNullNamePatternMatchesAll();
/*      */   }
/*      */   
/*      */   public boolean getOverrideSupportsIntegrityEnhancementFacility() {
/* 1385 */     return this.mc.getOverrideSupportsIntegrityEnhancementFacility();
/*      */   }
/*      */   
/*      */   public int getPacketDebugBufferSize() {
/* 1389 */     return this.mc.getPacketDebugBufferSize();
/*      */   }
/*      */   
/*      */   public boolean getPadCharsWithSpace() {
/* 1393 */     return this.mc.getPadCharsWithSpace();
/*      */   }
/*      */   
/*      */   public boolean getParanoid() {
/* 1397 */     return this.mc.getParanoid();
/*      */   }
/*      */   
/*      */   public boolean getPedantic() {
/* 1401 */     return this.mc.getPedantic();
/*      */   }
/*      */   
/*      */   public boolean getPinGlobalTxToPhysicalConnection() {
/* 1405 */     return this.mc.getPinGlobalTxToPhysicalConnection();
/*      */   }
/*      */   
/*      */   public boolean getPopulateInsertRowWithDefaultValues() {
/* 1409 */     return this.mc.getPopulateInsertRowWithDefaultValues();
/*      */   }
/*      */   
/*      */   public int getPrepStmtCacheSize() {
/* 1413 */     return this.mc.getPrepStmtCacheSize();
/*      */   }
/*      */   
/*      */   public int getPrepStmtCacheSqlLimit() {
/* 1417 */     return this.mc.getPrepStmtCacheSqlLimit();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSize() {
/* 1421 */     return this.mc.getPreparedStatementCacheSize();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSqlLimit() {
/* 1425 */     return this.mc.getPreparedStatementCacheSqlLimit();
/*      */   }
/*      */   
/*      */   public boolean getProcessEscapeCodesForPrepStmts() {
/* 1429 */     return this.mc.getProcessEscapeCodesForPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getProfileSQL() {
/* 1433 */     return this.mc.getProfileSQL();
/*      */   }
/*      */   
/*      */   public boolean getProfileSql() {
/* 1437 */     return this.mc.getProfileSql();
/*      */   }
/*      */   
/*      */   public String getPropertiesTransform() {
/* 1441 */     return this.mc.getPropertiesTransform();
/*      */   }
/*      */   
/*      */   public int getQueriesBeforeRetryMaster() {
/* 1445 */     return this.mc.getQueriesBeforeRetryMaster();
/*      */   }
/*      */   
/*      */   public boolean getReconnectAtTxEnd() {
/* 1449 */     return this.mc.getReconnectAtTxEnd();
/*      */   }
/*      */   
/*      */   public boolean getRelaxAutoCommit() {
/* 1453 */     return this.mc.getRelaxAutoCommit();
/*      */   }
/*      */   
/*      */   public int getReportMetricsIntervalMillis() {
/* 1457 */     return this.mc.getReportMetricsIntervalMillis();
/*      */   }
/*      */   
/*      */   public boolean getRequireSSL() {
/* 1461 */     return this.mc.getRequireSSL();
/*      */   }
/*      */   
/*      */   public String getResourceId() {
/* 1465 */     return this.mc.getResourceId();
/*      */   }
/*      */   
/*      */   public int getResultSetSizeThreshold() {
/* 1469 */     return this.mc.getResultSetSizeThreshold();
/*      */   }
/*      */   
/*      */   public boolean getRewriteBatchedStatements() {
/* 1473 */     return this.mc.getRewriteBatchedStatements();
/*      */   }
/*      */   
/*      */   public boolean getRollbackOnPooledClose() {
/* 1477 */     return this.mc.getRollbackOnPooledClose();
/*      */   }
/*      */   
/*      */   public boolean getRoundRobinLoadBalance() {
/* 1481 */     return this.mc.getRoundRobinLoadBalance();
/*      */   }
/*      */   
/*      */   public boolean getRunningCTS13() {
/* 1485 */     return this.mc.getRunningCTS13();
/*      */   }
/*      */   
/*      */   public int getSecondsBeforeRetryMaster() {
/* 1489 */     return this.mc.getSecondsBeforeRetryMaster();
/*      */   }
/*      */   
/*      */   public String getServerTimezone() {
/* 1493 */     return this.mc.getServerTimezone();
/*      */   }
/*      */   
/*      */   public String getSessionVariables() {
/* 1497 */     return this.mc.getSessionVariables();
/*      */   }
/*      */   
/*      */   public int getSlowQueryThresholdMillis() {
/* 1501 */     return this.mc.getSlowQueryThresholdMillis();
/*      */   }
/*      */   
/*      */   public long getSlowQueryThresholdNanos() {
/* 1505 */     return this.mc.getSlowQueryThresholdNanos();
/*      */   }
/*      */   
/*      */   public String getSocketFactory() {
/* 1509 */     return this.mc.getSocketFactory();
/*      */   }
/*      */   
/*      */   public String getSocketFactoryClassName() {
/* 1513 */     return this.mc.getSocketFactoryClassName();
/*      */   }
/*      */   
/*      */   public int getSocketTimeout() {
/* 1517 */     return this.mc.getSocketTimeout();
/*      */   }
/*      */   
/*      */   public String getStatementInterceptors() {
/* 1521 */     return this.mc.getStatementInterceptors();
/*      */   }
/*      */   
/*      */   public boolean getStrictFloatingPoint() {
/* 1525 */     return this.mc.getStrictFloatingPoint();
/*      */   }
/*      */   
/*      */   public boolean getStrictUpdates() {
/* 1529 */     return this.mc.getStrictUpdates();
/*      */   }
/*      */   
/*      */   public boolean getTcpKeepAlive() {
/* 1533 */     return this.mc.getTcpKeepAlive();
/*      */   }
/*      */   
/*      */   public boolean getTcpNoDelay() {
/* 1537 */     return this.mc.getTcpNoDelay();
/*      */   }
/*      */   
/*      */   public int getTcpRcvBuf() {
/* 1541 */     return this.mc.getTcpRcvBuf();
/*      */   }
/*      */   
/*      */   public int getTcpSndBuf() {
/* 1545 */     return this.mc.getTcpSndBuf();
/*      */   }
/*      */   
/*      */   public int getTcpTrafficClass() {
/* 1549 */     return this.mc.getTcpTrafficClass();
/*      */   }
/*      */   
/*      */   public boolean getTinyInt1isBit() {
/* 1553 */     return this.mc.getTinyInt1isBit();
/*      */   }
/*      */   
/*      */   public boolean getTraceProtocol() {
/* 1557 */     return this.mc.getTraceProtocol();
/*      */   }
/*      */   
/*      */   public boolean getTransformedBitIsBoolean() {
/* 1561 */     return this.mc.getTransformedBitIsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getTreatUtilDateAsTimestamp() {
/* 1565 */     return this.mc.getTreatUtilDateAsTimestamp();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStorePassword() {
/* 1569 */     return this.mc.getTrustCertificateKeyStorePassword();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStoreType() {
/* 1573 */     return this.mc.getTrustCertificateKeyStoreType();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStoreUrl() {
/* 1577 */     return this.mc.getTrustCertificateKeyStoreUrl();
/*      */   }
/*      */   
/*      */   public boolean getUltraDevHack() {
/* 1581 */     return this.mc.getUltraDevHack();
/*      */   }
/*      */   
/*      */   public boolean getUseBlobToStoreUTF8OutsideBMP() {
/* 1585 */     return this.mc.getUseBlobToStoreUTF8OutsideBMP();
/*      */   }
/*      */   
/*      */   public boolean getUseCompression() {
/* 1589 */     return this.mc.getUseCompression();
/*      */   }
/*      */   
/*      */   public String getUseConfigs() {
/* 1593 */     return this.mc.getUseConfigs();
/*      */   }
/*      */   
/*      */   public boolean getUseCursorFetch() {
/* 1597 */     return this.mc.getUseCursorFetch();
/*      */   }
/*      */   
/*      */   public boolean getUseDirectRowUnpack() {
/* 1601 */     return this.mc.getUseDirectRowUnpack();
/*      */   }
/*      */   
/*      */   public boolean getUseDynamicCharsetInfo() {
/* 1605 */     return this.mc.getUseDynamicCharsetInfo();
/*      */   }
/*      */   
/*      */   public boolean getUseFastDateParsing() {
/* 1609 */     return this.mc.getUseFastDateParsing();
/*      */   }
/*      */   
/*      */   public boolean getUseFastIntParsing() {
/* 1613 */     return this.mc.getUseFastIntParsing();
/*      */   }
/*      */   
/*      */   public boolean getUseGmtMillisForDatetimes() {
/* 1617 */     return this.mc.getUseGmtMillisForDatetimes();
/*      */   }
/*      */   
/*      */   public boolean getUseHostsInPrivileges() {
/* 1621 */     return this.mc.getUseHostsInPrivileges();
/*      */   }
/*      */   
/*      */   public boolean getUseInformationSchema() {
/* 1625 */     return this.mc.getUseInformationSchema();
/*      */   }
/*      */   
/*      */   public boolean getUseJDBCCompliantTimezoneShift() {
/* 1629 */     return this.mc.getUseJDBCCompliantTimezoneShift();
/*      */   }
/*      */   
/*      */   public boolean getUseJvmCharsetConverters() {
/* 1633 */     return this.mc.getUseJvmCharsetConverters();
/*      */   }
/*      */   
/*      */   public boolean getUseLocalSessionState() {
/* 1637 */     return this.mc.getUseLocalSessionState();
/*      */   }
/*      */   
/*      */   public boolean getUseNanosForElapsedTime() {
/* 1641 */     return this.mc.getUseNanosForElapsedTime();
/*      */   }
/*      */   
/*      */   public boolean getUseOldAliasMetadataBehavior() {
/* 1645 */     return this.mc.getUseOldAliasMetadataBehavior();
/*      */   }
/*      */   
/*      */   public boolean getUseOldUTF8Behavior() {
/* 1649 */     return this.mc.getUseOldUTF8Behavior();
/*      */   }
/*      */   
/*      */   public boolean getUseOnlyServerErrorMessages() {
/* 1653 */     return this.mc.getUseOnlyServerErrorMessages();
/*      */   }
/*      */   
/*      */   public boolean getUseReadAheadInput() {
/* 1657 */     return this.mc.getUseReadAheadInput();
/*      */   }
/*      */   
/*      */   public boolean getUseSSL() {
/* 1661 */     return this.mc.getUseSSL();
/*      */   }
/*      */   
/*      */   public boolean getUseSSPSCompatibleTimezoneShift() {
/* 1665 */     return this.mc.getUseSSPSCompatibleTimezoneShift();
/*      */   }
/*      */   
/*      */   public boolean getUseServerPrepStmts() {
/* 1669 */     return this.mc.getUseServerPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseServerPreparedStmts() {
/* 1673 */     return this.mc.getUseServerPreparedStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseSqlStateCodes() {
/* 1677 */     return this.mc.getUseSqlStateCodes();
/*      */   }
/*      */   
/*      */   public boolean getUseStreamLengthsInPrepStmts() {
/* 1681 */     return this.mc.getUseStreamLengthsInPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseTimezone() {
/* 1685 */     return this.mc.getUseTimezone();
/*      */   }
/*      */   
/*      */   public boolean getUseUltraDevWorkAround() {
/* 1689 */     return this.mc.getUseUltraDevWorkAround();
/*      */   }
/*      */   
/*      */   public boolean getUseUnbufferedInput() {
/* 1693 */     return this.mc.getUseUnbufferedInput();
/*      */   }
/*      */   
/*      */   public boolean getUseUnicode() {
/* 1697 */     return this.mc.getUseUnicode();
/*      */   }
/*      */   
/*      */   public boolean getUseUsageAdvisor() {
/* 1701 */     return this.mc.getUseUsageAdvisor();
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpExcludedColumnNamePattern() {
/* 1705 */     return this.mc.getUtf8OutsideBmpExcludedColumnNamePattern();
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpIncludedColumnNamePattern() {
/* 1709 */     return this.mc.getUtf8OutsideBmpIncludedColumnNamePattern();
/*      */   }
/*      */   
/*      */   public boolean getYearIsDateType() {
/* 1713 */     return this.mc.getYearIsDateType();
/*      */   }
/*      */   
/*      */   public String getZeroDateTimeBehavior() {
/* 1717 */     return this.mc.getZeroDateTimeBehavior();
/*      */   }
/*      */   
/*      */   public void setAllowLoadLocalInfile(boolean property) {
/* 1721 */     this.mc.setAllowLoadLocalInfile(property);
/*      */   }
/*      */   
/*      */   public void setAllowMultiQueries(boolean property) {
/* 1725 */     this.mc.setAllowMultiQueries(property);
/*      */   }
/*      */   
/*      */   public void setAllowNanAndInf(boolean flag) {
/* 1729 */     this.mc.setAllowNanAndInf(flag);
/*      */   }
/*      */   
/*      */   public void setAllowUrlInLocalInfile(boolean flag) {
/* 1733 */     this.mc.setAllowUrlInLocalInfile(flag);
/*      */   }
/*      */   
/*      */   public void setAlwaysSendSetIsolation(boolean flag) {
/* 1737 */     this.mc.setAlwaysSendSetIsolation(flag);
/*      */   }
/*      */   
/*      */   public void setAutoClosePStmtStreams(boolean flag) {
/* 1741 */     this.mc.setAutoClosePStmtStreams(flag);
/*      */   }
/*      */   
/*      */   public void setAutoDeserialize(boolean flag) {
/* 1745 */     this.mc.setAutoDeserialize(flag);
/*      */   }
/*      */   
/*      */   public void setAutoGenerateTestcaseScript(boolean flag) {
/* 1749 */     this.mc.setAutoGenerateTestcaseScript(flag);
/*      */   }
/*      */   
/*      */   public void setAutoReconnect(boolean flag) {
/* 1753 */     this.mc.setAutoReconnect(flag);
/*      */   }
/*      */   
/*      */   public void setAutoReconnectForConnectionPools(boolean property) {
/* 1757 */     this.mc.setAutoReconnectForConnectionPools(property);
/*      */   }
/*      */   
/*      */   public void setAutoReconnectForPools(boolean flag) {
/* 1761 */     this.mc.setAutoReconnectForPools(flag);
/*      */   }
/*      */   
/*      */   public void setAutoSlowLog(boolean flag) {
/* 1765 */     this.mc.setAutoSlowLog(flag);
/*      */   }
/*      */   
/*      */   public void setBlobSendChunkSize(String value) throws SQLException {
/* 1769 */     this.mc.setBlobSendChunkSize(value);
/*      */   }
/*      */   
/*      */   public void setBlobsAreStrings(boolean flag) {
/* 1773 */     this.mc.setBlobsAreStrings(flag);
/*      */   }
/*      */   
/*      */   public void setCacheCallableStatements(boolean flag) {
/* 1777 */     this.mc.setCacheCallableStatements(flag);
/*      */   }
/*      */   
/*      */   public void setCacheCallableStmts(boolean flag) {
/* 1781 */     this.mc.setCacheCallableStmts(flag);
/*      */   }
/*      */   
/*      */   public void setCachePrepStmts(boolean flag) {
/* 1785 */     this.mc.setCachePrepStmts(flag);
/*      */   }
/*      */   
/*      */   public void setCachePreparedStatements(boolean flag) {
/* 1789 */     this.mc.setCachePreparedStatements(flag);
/*      */   }
/*      */   
/*      */   public void setCacheResultSetMetadata(boolean property) {
/* 1793 */     this.mc.setCacheResultSetMetadata(property);
/*      */   }
/*      */   
/*      */   public void setCacheServerConfiguration(boolean flag) {
/* 1797 */     this.mc.setCacheServerConfiguration(flag);
/*      */   }
/*      */   
/*      */   public void setCallableStatementCacheSize(int size) throws SQLException {
/* 1801 */     this.mc.setCallableStatementCacheSize(size);
/*      */   }
/*      */   
/*      */   public void setCallableStmtCacheSize(int cacheSize) throws SQLException {
/* 1805 */     this.mc.setCallableStmtCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */   public void setCapitalizeDBMDTypes(boolean property) {
/* 1809 */     this.mc.setCapitalizeDBMDTypes(property);
/*      */   }
/*      */   
/*      */   public void setCapitalizeTypeNames(boolean flag) {
/* 1813 */     this.mc.setCapitalizeTypeNames(flag);
/*      */   }
/*      */   
/*      */   public void setCharacterEncoding(String encoding) {
/* 1817 */     this.mc.setCharacterEncoding(encoding);
/*      */   }
/*      */   
/*      */   public void setCharacterSetResults(String characterSet) {
/* 1821 */     this.mc.setCharacterSetResults(characterSet);
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStorePassword(String value) {
/* 1825 */     this.mc.setClientCertificateKeyStorePassword(value);
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStoreType(String value) {
/* 1829 */     this.mc.setClientCertificateKeyStoreType(value);
/*      */   }
/*      */   
/*      */   public void setClientCertificateKeyStoreUrl(String value) {
/* 1833 */     this.mc.setClientCertificateKeyStoreUrl(value);
/*      */   }
/*      */   
/*      */   public void setClientInfoProvider(String classname) {
/* 1837 */     this.mc.setClientInfoProvider(classname);
/*      */   }
/*      */   
/*      */   public void setClobCharacterEncoding(String encoding) {
/* 1841 */     this.mc.setClobCharacterEncoding(encoding);
/*      */   }
/*      */   
/*      */   public void setClobberStreamingResults(boolean flag) {
/* 1845 */     this.mc.setClobberStreamingResults(flag);
/*      */   }
/*      */   
/*      */   public void setConnectTimeout(int timeoutMs) throws SQLException {
/* 1849 */     this.mc.setConnectTimeout(timeoutMs);
/*      */   }
/*      */   
/*      */   public void setConnectionCollation(String collation) {
/* 1853 */     this.mc.setConnectionCollation(collation);
/*      */   }
/*      */   
/*      */   public void setConnectionLifecycleInterceptors(String interceptors) {
/* 1857 */     this.mc.setConnectionLifecycleInterceptors(interceptors);
/*      */   }
/*      */   
/*      */   public void setContinueBatchOnError(boolean property) {
/* 1861 */     this.mc.setContinueBatchOnError(property);
/*      */   }
/*      */   
/*      */   public void setCreateDatabaseIfNotExist(boolean flag) {
/* 1865 */     this.mc.setCreateDatabaseIfNotExist(flag);
/*      */   }
/*      */   
/*      */   public void setDefaultFetchSize(int n) throws SQLException {
/* 1869 */     this.mc.setDefaultFetchSize(n);
/*      */   }
/*      */   
/*      */   public void setDetectServerPreparedStmts(boolean property) {
/* 1873 */     this.mc.setDetectServerPreparedStmts(property);
/*      */   }
/*      */   
/*      */   public void setDontTrackOpenResources(boolean flag) {
/* 1877 */     this.mc.setDontTrackOpenResources(flag);
/*      */   }
/*      */   
/*      */   public void setDumpMetadataOnColumnNotFound(boolean flag) {
/* 1881 */     this.mc.setDumpMetadataOnColumnNotFound(flag);
/*      */   }
/*      */   
/*      */   public void setDumpQueriesOnException(boolean flag) {
/* 1885 */     this.mc.setDumpQueriesOnException(flag);
/*      */   }
/*      */   
/*      */   public void setDynamicCalendars(boolean flag) {
/* 1889 */     this.mc.setDynamicCalendars(flag);
/*      */   }
/*      */   
/*      */   public void setElideSetAutoCommits(boolean flag) {
/* 1893 */     this.mc.setElideSetAutoCommits(flag);
/*      */   }
/*      */   
/*      */   public void setEmptyStringsConvertToZero(boolean flag) {
/* 1897 */     this.mc.setEmptyStringsConvertToZero(flag);
/*      */   }
/*      */   
/*      */   public void setEmulateLocators(boolean property) {
/* 1901 */     this.mc.setEmulateLocators(property);
/*      */   }
/*      */   
/*      */   public void setEmulateUnsupportedPstmts(boolean flag) {
/* 1905 */     this.mc.setEmulateUnsupportedPstmts(flag);
/*      */   }
/*      */   
/*      */   public void setEnablePacketDebug(boolean flag) {
/* 1909 */     this.mc.setEnablePacketDebug(flag);
/*      */   }
/*      */   
/*      */   public void setEnableQueryTimeouts(boolean flag) {
/* 1913 */     this.mc.setEnableQueryTimeouts(flag);
/*      */   }
/*      */   
/*      */   public void setEncoding(String property) {
/* 1917 */     this.mc.setEncoding(property);
/*      */   }
/*      */   
/*      */   public void setExplainSlowQueries(boolean flag) {
/* 1921 */     this.mc.setExplainSlowQueries(flag);
/*      */   }
/*      */   
/*      */   public void setFailOverReadOnly(boolean flag) {
/* 1925 */     this.mc.setFailOverReadOnly(flag);
/*      */   }
/*      */   
/*      */   public void setFunctionsNeverReturnBlobs(boolean flag) {
/* 1929 */     this.mc.setFunctionsNeverReturnBlobs(flag);
/*      */   }
/*      */   
/*      */   public void setGatherPerfMetrics(boolean flag) {
/* 1933 */     this.mc.setGatherPerfMetrics(flag);
/*      */   }
/*      */   
/*      */   public void setGatherPerformanceMetrics(boolean flag) {
/* 1937 */     this.mc.setGatherPerformanceMetrics(flag);
/*      */   }
/*      */   
/*      */   public void setGenerateSimpleParameterMetadata(boolean flag) {
/* 1941 */     this.mc.setGenerateSimpleParameterMetadata(flag);
/*      */   }
/*      */   
/*      */   public void setHoldResultsOpenOverStatementClose(boolean flag) {
/* 1945 */     this.mc.setHoldResultsOpenOverStatementClose(flag);
/*      */   }
/*      */   
/*      */   public void setIgnoreNonTxTables(boolean property) {
/* 1949 */     this.mc.setIgnoreNonTxTables(property);
/*      */   }
/*      */   
/*      */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) {
/* 1953 */     this.mc.setIncludeInnodbStatusInDeadlockExceptions(flag);
/*      */   }
/*      */   
/*      */   public void setInitialTimeout(int property) throws SQLException {
/* 1957 */     this.mc.setInitialTimeout(property);
/*      */   }
/*      */   
/*      */   public void setInteractiveClient(boolean property) {
/* 1961 */     this.mc.setInteractiveClient(property);
/*      */   }
/*      */   
/*      */   public void setIsInteractiveClient(boolean property) {
/* 1965 */     this.mc.setIsInteractiveClient(property);
/*      */   }
/*      */   
/*      */   public void setJdbcCompliantTruncation(boolean flag) {
/* 1969 */     this.mc.setJdbcCompliantTruncation(flag);
/*      */   }
/*      */   
/*      */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads) {
/* 1973 */     this.mc.setJdbcCompliantTruncationForReads(jdbcCompliantTruncationForReads);
/*      */   }
/*      */   
/*      */   public void setLargeRowSizeThreshold(String value) throws SQLException {
/* 1977 */     this.mc.setLargeRowSizeThreshold(value);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceStrategy(String strategy) {
/* 1981 */     this.mc.setLoadBalanceStrategy(strategy);
/*      */   }
/*      */   
/*      */   public void setLocalSocketAddress(String address) {
/* 1985 */     this.mc.setLocalSocketAddress(address);
/*      */   }
/*      */   
/*      */   public void setLocatorFetchBufferSize(String value) throws SQLException {
/* 1989 */     this.mc.setLocatorFetchBufferSize(value);
/*      */   }
/*      */   
/*      */   public void setLogSlowQueries(boolean flag) {
/* 1993 */     this.mc.setLogSlowQueries(flag);
/*      */   }
/*      */   
/*      */   public void setLogXaCommands(boolean flag) {
/* 1997 */     this.mc.setLogXaCommands(flag);
/*      */   }
/*      */   
/*      */   public void setLogger(String property) {
/* 2001 */     this.mc.setLogger(property);
/*      */   }
/*      */   
/*      */   public void setLoggerClassName(String className) {
/* 2005 */     this.mc.setLoggerClassName(className);
/*      */   }
/*      */   
/*      */   public void setMaintainTimeStats(boolean flag) {
/* 2009 */     this.mc.setMaintainTimeStats(flag);
/*      */   }
/*      */   
/*      */   public void setMaxQuerySizeToLog(int sizeInBytes) throws SQLException {
/* 2013 */     this.mc.setMaxQuerySizeToLog(sizeInBytes);
/*      */   }
/*      */   
/*      */   public void setMaxReconnects(int property) throws SQLException {
/* 2017 */     this.mc.setMaxReconnects(property);
/*      */   }
/*      */   
/*      */   public void setMaxRows(int property) throws SQLException {
/* 2021 */     this.mc.setMaxRows(property);
/*      */   }
/*      */   
/*      */   public void setMetadataCacheSize(int value) throws SQLException {
/* 2025 */     this.mc.setMetadataCacheSize(value);
/*      */   }
/*      */   
/*      */   public void setNetTimeoutForStreamingResults(int value) throws SQLException {
/* 2029 */     this.mc.setNetTimeoutForStreamingResults(value);
/*      */   }
/*      */   
/*      */   public void setNoAccessToProcedureBodies(boolean flag) {
/* 2033 */     this.mc.setNoAccessToProcedureBodies(flag);
/*      */   }
/*      */   
/*      */   public void setNoDatetimeStringSync(boolean flag) {
/* 2037 */     this.mc.setNoDatetimeStringSync(flag);
/*      */   }
/*      */   
/*      */   public void setNoTimezoneConversionForTimeType(boolean flag) {
/* 2041 */     this.mc.setNoTimezoneConversionForTimeType(flag);
/*      */   }
/*      */   
/*      */   public void setNoTimezoneConversionForDateType(boolean flag) {
/* 2045 */     this.mc.setNoTimezoneConversionForDateType(flag);
/*      */   }
/*      */   
/*      */   public void setCacheDefaultTimezone(boolean flag) {
/* 2049 */     this.mc.setCacheDefaultTimezone(flag);
/*      */   }
/*      */   
/*      */   public void setNullCatalogMeansCurrent(boolean value) {
/* 2053 */     this.mc.setNullCatalogMeansCurrent(value);
/*      */   }
/*      */   
/*      */   public void setNullNamePatternMatchesAll(boolean value) {
/* 2057 */     this.mc.setNullNamePatternMatchesAll(value);
/*      */   }
/*      */   
/*      */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag) {
/* 2061 */     this.mc.setOverrideSupportsIntegrityEnhancementFacility(flag);
/*      */   }
/*      */   
/*      */   public void setPacketDebugBufferSize(int size) throws SQLException {
/* 2065 */     this.mc.setPacketDebugBufferSize(size);
/*      */   }
/*      */   
/*      */   public void setPadCharsWithSpace(boolean flag) {
/* 2069 */     this.mc.setPadCharsWithSpace(flag);
/*      */   }
/*      */   
/*      */   public void setParanoid(boolean property) {
/* 2073 */     this.mc.setParanoid(property);
/*      */   }
/*      */   
/*      */   public void setPedantic(boolean property) {
/* 2077 */     this.mc.setPedantic(property);
/*      */   }
/*      */   
/*      */   public void setPinGlobalTxToPhysicalConnection(boolean flag) {
/* 2081 */     this.mc.setPinGlobalTxToPhysicalConnection(flag);
/*      */   }
/*      */   
/*      */   public void setPopulateInsertRowWithDefaultValues(boolean flag) {
/* 2085 */     this.mc.setPopulateInsertRowWithDefaultValues(flag);
/*      */   }
/*      */   
/*      */   public void setPrepStmtCacheSize(int cacheSize) throws SQLException {
/* 2089 */     this.mc.setPrepStmtCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */   public void setPrepStmtCacheSqlLimit(int sqlLimit) throws SQLException {
/* 2093 */     this.mc.setPrepStmtCacheSqlLimit(sqlLimit);
/*      */   }
/*      */   
/*      */   public void setPreparedStatementCacheSize(int cacheSize) throws SQLException {
/* 2097 */     this.mc.setPreparedStatementCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit) throws SQLException {
/* 2101 */     this.mc.setPreparedStatementCacheSqlLimit(cacheSqlLimit);
/*      */   }
/*      */   
/*      */   public void setProcessEscapeCodesForPrepStmts(boolean flag) {
/* 2105 */     this.mc.setProcessEscapeCodesForPrepStmts(flag);
/*      */   }
/*      */   
/*      */   public void setProfileSQL(boolean flag) {
/* 2109 */     this.mc.setProfileSQL(flag);
/*      */   }
/*      */   
/*      */   public void setProfileSql(boolean property) {
/* 2113 */     this.mc.setProfileSql(property);
/*      */   }
/*      */   
/*      */   public void setPropertiesTransform(String value) {
/* 2117 */     this.mc.setPropertiesTransform(value);
/*      */   }
/*      */   
/*      */   public void setQueriesBeforeRetryMaster(int property) throws SQLException {
/* 2121 */     this.mc.setQueriesBeforeRetryMaster(property);
/*      */   }
/*      */   
/*      */   public void setReconnectAtTxEnd(boolean property) {
/* 2125 */     this.mc.setReconnectAtTxEnd(property);
/*      */   }
/*      */   
/*      */   public void setRelaxAutoCommit(boolean property) {
/* 2129 */     this.mc.setRelaxAutoCommit(property);
/*      */   }
/*      */   
/*      */   public void setReportMetricsIntervalMillis(int millis) throws SQLException {
/* 2133 */     this.mc.setReportMetricsIntervalMillis(millis);
/*      */   }
/*      */   
/*      */   public void setRequireSSL(boolean property) {
/* 2137 */     this.mc.setRequireSSL(property);
/*      */   }
/*      */   
/*      */   public void setResourceId(String resourceId) {
/* 2141 */     this.mc.setResourceId(resourceId);
/*      */   }
/*      */   
/*      */   public void setResultSetSizeThreshold(int threshold) throws SQLException {
/* 2145 */     this.mc.setResultSetSizeThreshold(threshold);
/*      */   }
/*      */   
/*      */   public void setRetainStatementAfterResultSetClose(boolean flag) {
/* 2149 */     this.mc.setRetainStatementAfterResultSetClose(flag);
/*      */   }
/*      */   
/*      */   public void setRewriteBatchedStatements(boolean flag) {
/* 2153 */     this.mc.setRewriteBatchedStatements(flag);
/*      */   }
/*      */   
/*      */   public void setRollbackOnPooledClose(boolean flag) {
/* 2157 */     this.mc.setRollbackOnPooledClose(flag);
/*      */   }
/*      */   
/*      */   public void setRoundRobinLoadBalance(boolean flag) {
/* 2161 */     this.mc.setRoundRobinLoadBalance(flag);
/*      */   }
/*      */   
/*      */   public void setRunningCTS13(boolean flag) {
/* 2165 */     this.mc.setRunningCTS13(flag);
/*      */   }
/*      */   
/*      */   public void setSecondsBeforeRetryMaster(int property) throws SQLException {
/* 2169 */     this.mc.setSecondsBeforeRetryMaster(property);
/*      */   }
/*      */   
/*      */   public void setServerTimezone(String property) {
/* 2173 */     this.mc.setServerTimezone(property);
/*      */   }
/*      */   
/*      */   public void setSessionVariables(String variables) {
/* 2177 */     this.mc.setSessionVariables(variables);
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdMillis(int millis) throws SQLException {
/* 2181 */     this.mc.setSlowQueryThresholdMillis(millis);
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdNanos(long nanos) throws SQLException {
/* 2185 */     this.mc.setSlowQueryThresholdNanos(nanos);
/*      */   }
/*      */   
/*      */   public void setSocketFactory(String name) {
/* 2189 */     this.mc.setSocketFactory(name);
/*      */   }
/*      */   
/*      */   public void setSocketFactoryClassName(String property) {
/* 2193 */     this.mc.setSocketFactoryClassName(property);
/*      */   }
/*      */   
/*      */   public void setSocketTimeout(int property) throws SQLException {
/* 2197 */     this.mc.setSocketTimeout(property);
/*      */   }
/*      */   
/*      */   public void setStatementInterceptors(String value) {
/* 2201 */     this.mc.setStatementInterceptors(value);
/*      */   }
/*      */   
/*      */   public void setStrictFloatingPoint(boolean property) {
/* 2205 */     this.mc.setStrictFloatingPoint(property);
/*      */   }
/*      */   
/*      */   public void setStrictUpdates(boolean property) {
/* 2209 */     this.mc.setStrictUpdates(property);
/*      */   }
/*      */   
/*      */   public void setTcpKeepAlive(boolean flag) {
/* 2213 */     this.mc.setTcpKeepAlive(flag);
/*      */   }
/*      */   
/*      */   public void setTcpNoDelay(boolean flag) {
/* 2217 */     this.mc.setTcpNoDelay(flag);
/*      */   }
/*      */   
/*      */   public void setTcpRcvBuf(int bufSize) throws SQLException {
/* 2221 */     this.mc.setTcpRcvBuf(bufSize);
/*      */   }
/*      */   
/*      */   public void setTcpSndBuf(int bufSize) throws SQLException {
/* 2225 */     this.mc.setTcpSndBuf(bufSize);
/*      */   }
/*      */   
/*      */   public void setTcpTrafficClass(int classFlags) throws SQLException {
/* 2229 */     this.mc.setTcpTrafficClass(classFlags);
/*      */   }
/*      */   
/*      */   public void setTinyInt1isBit(boolean flag) {
/* 2233 */     this.mc.setTinyInt1isBit(flag);
/*      */   }
/*      */   
/*      */   public void setTraceProtocol(boolean flag) {
/* 2237 */     this.mc.setTraceProtocol(flag);
/*      */   }
/*      */   
/*      */   public void setTransformedBitIsBoolean(boolean flag) {
/* 2241 */     this.mc.setTransformedBitIsBoolean(flag);
/*      */   }
/*      */   
/*      */   public void setTreatUtilDateAsTimestamp(boolean flag) {
/* 2245 */     this.mc.setTreatUtilDateAsTimestamp(flag);
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStorePassword(String value) {
/* 2249 */     this.mc.setTrustCertificateKeyStorePassword(value);
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStoreType(String value) {
/* 2253 */     this.mc.setTrustCertificateKeyStoreType(value);
/*      */   }
/*      */   
/*      */   public void setTrustCertificateKeyStoreUrl(String value) {
/* 2257 */     this.mc.setTrustCertificateKeyStoreUrl(value);
/*      */   }
/*      */   
/*      */   public void setUltraDevHack(boolean flag) {
/* 2261 */     this.mc.setUltraDevHack(flag);
/*      */   }
/*      */   
/*      */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag) {
/* 2265 */     this.mc.setUseBlobToStoreUTF8OutsideBMP(flag);
/*      */   }
/*      */   
/*      */   public void setUseCompression(boolean property) {
/* 2269 */     this.mc.setUseCompression(property);
/*      */   }
/*      */   
/*      */   public void setUseConfigs(String configs) {
/* 2273 */     this.mc.setUseConfigs(configs);
/*      */   }
/*      */   
/*      */   public void setUseCursorFetch(boolean flag) {
/* 2277 */     this.mc.setUseCursorFetch(flag);
/*      */   }
/*      */   
/*      */   public void setUseDirectRowUnpack(boolean flag) {
/* 2281 */     this.mc.setUseDirectRowUnpack(flag);
/*      */   }
/*      */   
/*      */   public void setUseDynamicCharsetInfo(boolean flag) {
/* 2285 */     this.mc.setUseDynamicCharsetInfo(flag);
/*      */   }
/*      */   
/*      */   public void setUseFastDateParsing(boolean flag) {
/* 2289 */     this.mc.setUseFastDateParsing(flag);
/*      */   }
/*      */   
/*      */   public void setUseFastIntParsing(boolean flag) {
/* 2293 */     this.mc.setUseFastIntParsing(flag);
/*      */   }
/*      */   
/*      */   public void setUseGmtMillisForDatetimes(boolean flag) {
/* 2297 */     this.mc.setUseGmtMillisForDatetimes(flag);
/*      */   }
/*      */   
/*      */   public void setUseHostsInPrivileges(boolean property) {
/* 2301 */     this.mc.setUseHostsInPrivileges(property);
/*      */   }
/*      */   
/*      */   public void setUseInformationSchema(boolean flag) {
/* 2305 */     this.mc.setUseInformationSchema(flag);
/*      */   }
/*      */   
/*      */   public void setUseJDBCCompliantTimezoneShift(boolean flag) {
/* 2309 */     this.mc.setUseJDBCCompliantTimezoneShift(flag);
/*      */   }
/*      */   
/*      */   public void setUseJvmCharsetConverters(boolean flag) {
/* 2313 */     this.mc.setUseJvmCharsetConverters(flag);
/*      */   }
/*      */   
/*      */   public void setUseLocalSessionState(boolean flag) {
/* 2317 */     this.mc.setUseLocalSessionState(flag);
/*      */   }
/*      */   
/*      */   public void setUseNanosForElapsedTime(boolean flag) {
/* 2321 */     this.mc.setUseNanosForElapsedTime(flag);
/*      */   }
/*      */   
/*      */   public void setUseOldAliasMetadataBehavior(boolean flag) {
/* 2325 */     this.mc.setUseOldAliasMetadataBehavior(flag);
/*      */   }
/*      */   
/*      */   public void setUseOldUTF8Behavior(boolean flag) {
/* 2329 */     this.mc.setUseOldUTF8Behavior(flag);
/*      */   }
/*      */   
/*      */   public void setUseOnlyServerErrorMessages(boolean flag) {
/* 2333 */     this.mc.setUseOnlyServerErrorMessages(flag);
/*      */   }
/*      */   
/*      */   public void setUseReadAheadInput(boolean flag) {
/* 2337 */     this.mc.setUseReadAheadInput(flag);
/*      */   }
/*      */   
/*      */   public void setUseSSL(boolean property) {
/* 2341 */     this.mc.setUseSSL(property);
/*      */   }
/*      */   
/*      */   public void setUseSSPSCompatibleTimezoneShift(boolean flag) {
/* 2345 */     this.mc.setUseSSPSCompatibleTimezoneShift(flag);
/*      */   }
/*      */   
/*      */   public void setUseServerPrepStmts(boolean flag) {
/* 2349 */     this.mc.setUseServerPrepStmts(flag);
/*      */   }
/*      */   
/*      */   public void setUseServerPreparedStmts(boolean flag) {
/* 2353 */     this.mc.setUseServerPreparedStmts(flag);
/*      */   }
/*      */   
/*      */   public void setUseSqlStateCodes(boolean flag) {
/* 2357 */     this.mc.setUseSqlStateCodes(flag);
/*      */   }
/*      */   
/*      */   public void setUseStreamLengthsInPrepStmts(boolean property) {
/* 2361 */     this.mc.setUseStreamLengthsInPrepStmts(property);
/*      */   }
/*      */   
/*      */   public void setUseTimezone(boolean property) {
/* 2365 */     this.mc.setUseTimezone(property);
/*      */   }
/*      */   
/*      */   public void setUseUltraDevWorkAround(boolean property) {
/* 2369 */     this.mc.setUseUltraDevWorkAround(property);
/*      */   }
/*      */   
/*      */   public void setUseUnbufferedInput(boolean flag) {
/* 2373 */     this.mc.setUseUnbufferedInput(flag);
/*      */   }
/*      */   
/*      */   public void setUseUnicode(boolean flag) {
/* 2377 */     this.mc.setUseUnicode(flag);
/*      */   }
/*      */   
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag) {
/* 2381 */     this.mc.setUseUsageAdvisor(useUsageAdvisorFlag);
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) {
/* 2385 */     this.mc.setUtf8OutsideBmpExcludedColumnNamePattern(regexPattern);
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) {
/* 2389 */     this.mc.setUtf8OutsideBmpIncludedColumnNamePattern(regexPattern);
/*      */   }
/*      */   
/*      */   public void setYearIsDateType(boolean flag) {
/* 2393 */     this.mc.setYearIsDateType(flag);
/*      */   }
/*      */   
/*      */   public void setZeroDateTimeBehavior(String behavior) {
/* 2397 */     this.mc.setZeroDateTimeBehavior(behavior);
/*      */   }
/*      */   
/*      */   public boolean useUnbufferedInput() {
/* 2401 */     return this.mc.useUnbufferedInput();
/*      */   }
/*      */   
/*      */   public void initializeExtension(Extension ex) throws SQLException {
/* 2405 */     this.mc.initializeExtension(ex);
/*      */   }
/*      */   
/*      */   public String getProfilerEventHandler() {
/* 2409 */     return this.mc.getProfilerEventHandler();
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandler(String handler) {
/* 2413 */     this.mc.setProfilerEventHandler(handler);
/*      */   }
/*      */   
/*      */   public boolean getVerifyServerCertificate() {
/* 2417 */     return this.mc.getVerifyServerCertificate();
/*      */   }
/*      */   
/*      */   public void setVerifyServerCertificate(boolean flag) {
/* 2421 */     this.mc.setVerifyServerCertificate(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseLegacyDatetimeCode() {
/* 2425 */     return this.mc.getUseLegacyDatetimeCode();
/*      */   }
/*      */   
/*      */   public void setUseLegacyDatetimeCode(boolean flag) {
/* 2429 */     this.mc.setUseLegacyDatetimeCode(flag);
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingMaxOperations() {
/* 2433 */     return this.mc.getSelfDestructOnPingMaxOperations();
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingSecondsLifetime() {
/* 2437 */     return this.mc.getSelfDestructOnPingSecondsLifetime();
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingMaxOperations(int maxOperations) throws SQLException {
/* 2441 */     this.mc.setSelfDestructOnPingMaxOperations(maxOperations);
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingSecondsLifetime(int seconds) throws SQLException {
/* 2445 */     this.mc.setSelfDestructOnPingSecondsLifetime(seconds);
/*      */   }
/*      */   
/*      */   public boolean getUseColumnNamesInFindColumn() {
/* 2449 */     return this.mc.getUseColumnNamesInFindColumn();
/*      */   }
/*      */   
/*      */   public void setUseColumnNamesInFindColumn(boolean flag) {
/* 2453 */     this.mc.setUseColumnNamesInFindColumn(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseLocalTransactionState() {
/* 2457 */     return this.mc.getUseLocalTransactionState();
/*      */   }
/*      */   
/*      */   public void setUseLocalTransactionState(boolean flag) {
/* 2461 */     this.mc.setUseLocalTransactionState(flag);
/*      */   }
/*      */   
/*      */   public boolean getCompensateOnDuplicateKeyUpdateCounts() {
/* 2465 */     return this.mc.getCompensateOnDuplicateKeyUpdateCounts();
/*      */   }
/*      */   
/*      */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) {
/* 2469 */     this.mc.setCompensateOnDuplicateKeyUpdateCounts(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseAffectedRows() {
/* 2473 */     return this.mc.getUseAffectedRows();
/*      */   }
/*      */   
/*      */   public void setUseAffectedRows(boolean flag) {
/* 2477 */     this.mc.setUseAffectedRows(flag);
/*      */   }
/*      */   
/*      */   public String getPasswordCharacterEncoding() {
/* 2481 */     return this.mc.getPasswordCharacterEncoding();
/*      */   }
/*      */   
/*      */   public void setPasswordCharacterEncoding(String characterSet) {
/* 2485 */     this.mc.setPasswordCharacterEncoding(characterSet);
/*      */   }
/*      */   
/*      */   public int getAutoIncrementIncrement() {
/* 2489 */     return this.mc.getAutoIncrementIncrement();
/*      */   }
/*      */   
/*      */   public int getLoadBalanceBlacklistTimeout() {
/* 2493 */     return this.mc.getLoadBalanceBlacklistTimeout();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) throws SQLException {
/* 2497 */     this.mc.setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout);
/*      */   }
/*      */   
/*      */   public int getLoadBalancePingTimeout() {
/* 2501 */     return this.mc.getLoadBalancePingTimeout();
/*      */   }
/*      */   
/*      */   public void setLoadBalancePingTimeout(int loadBalancePingTimeout) throws SQLException {
/* 2505 */     this.mc.setLoadBalancePingTimeout(loadBalancePingTimeout);
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceValidateConnectionOnSwapServer() {
/* 2509 */     return this.mc.getLoadBalanceValidateConnectionOnSwapServer();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceValidateConnectionOnSwapServer(boolean loadBalanceValidateConnectionOnSwapServer) {
/* 2513 */     this.mc.setLoadBalanceValidateConnectionOnSwapServer(loadBalanceValidateConnectionOnSwapServer);
/*      */   }
/*      */   
/*      */   public void setRetriesAllDown(int retriesAllDown) throws SQLException {
/* 2517 */     this.mc.setRetriesAllDown(retriesAllDown);
/*      */   }
/*      */   
/*      */   public int getRetriesAllDown() {
/* 2521 */     return this.mc.getRetriesAllDown();
/*      */   }
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/* 2525 */     return this.pooledConnection.getExceptionInterceptor();
/*      */   }
/*      */   
/*      */   public String getExceptionInterceptors() {
/* 2529 */     return this.mc.getExceptionInterceptors();
/*      */   }
/*      */   
/*      */   public void setExceptionInterceptors(String exceptionInterceptors) {
/* 2533 */     this.mc.setExceptionInterceptors(exceptionInterceptors);
/*      */   }
/*      */   
/*      */   public boolean getQueryTimeoutKillsConnection() {
/* 2537 */     return this.mc.getQueryTimeoutKillsConnection();
/*      */   }
/*      */   
/*      */   public void setQueryTimeoutKillsConnection(boolean queryTimeoutKillsConnection) {
/* 2541 */     this.mc.setQueryTimeoutKillsConnection(queryTimeoutKillsConnection);
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(Connection c) {
/* 2545 */     return this.mc.hasSameProperties(c);
/*      */   }
/*      */   
/*      */   public Properties getProperties() {
/* 2549 */     return this.mc.getProperties();
/*      */   }
/*      */   
/*      */   public String getHost() {
/* 2553 */     return this.mc.getHost();
/*      */   }
/*      */   
/*      */   public void setProxy(MySQLConnection conn) {
/* 2557 */     this.mc.setProxy(conn);
/*      */   }
/*      */   
/*      */   public boolean getRetainStatementAfterResultSetClose() {
/* 2561 */     return this.mc.getRetainStatementAfterResultSetClose();
/*      */   }
/*      */   
/*      */   public int getMaxAllowedPacket() {
/* 2565 */     return this.mc.getMaxAllowedPacket();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceConnectionGroup() {
/* 2569 */     return this.mc.getLoadBalanceConnectionGroup();
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceEnableJMX() {
/* 2573 */     return this.mc.getLoadBalanceEnableJMX();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceExceptionChecker() {
/* 2577 */     return this.mc.getLoadBalanceExceptionChecker();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLExceptionSubclassFailover() {
/* 2581 */     return this.mc.getLoadBalanceSQLExceptionSubclassFailover();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLStateFailover() {
/* 2585 */     return this.mc.getLoadBalanceSQLStateFailover();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceConnectionGroup(String loadBalanceConnectionGroup) {
/* 2589 */     this.mc.setLoadBalanceConnectionGroup(loadBalanceConnectionGroup);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceEnableJMX(boolean loadBalanceEnableJMX)
/*      */   {
/* 2594 */     this.mc.setLoadBalanceEnableJMX(loadBalanceEnableJMX);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceExceptionChecker(String loadBalanceExceptionChecker)
/*      */   {
/* 2599 */     this.mc.setLoadBalanceExceptionChecker(loadBalanceExceptionChecker);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLExceptionSubclassFailover(String loadBalanceSQLExceptionSubclassFailover)
/*      */   {
/* 2604 */     this.mc.setLoadBalanceSQLExceptionSubclassFailover(loadBalanceSQLExceptionSubclassFailover);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLStateFailover(String loadBalanceSQLStateFailover)
/*      */   {
/* 2609 */     this.mc.setLoadBalanceSQLStateFailover(loadBalanceSQLStateFailover);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceAutoCommitStatementRegex()
/*      */   {
/* 2614 */     return this.mc.getLoadBalanceAutoCommitStatementRegex();
/*      */   }
/*      */   
/*      */   public int getLoadBalanceAutoCommitStatementThreshold() {
/* 2618 */     return this.mc.getLoadBalanceAutoCommitStatementThreshold();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementRegex(String loadBalanceAutoCommitStatementRegex) {
/* 2622 */     this.mc.setLoadBalanceAutoCommitStatementRegex(loadBalanceAutoCommitStatementRegex);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementThreshold(int loadBalanceAutoCommitStatementThreshold) throws SQLException
/*      */   {
/* 2627 */     this.mc.setLoadBalanceAutoCommitStatementThreshold(loadBalanceAutoCommitStatementThreshold);
/*      */   }
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException
/*      */   {
/* 2632 */     checkClosed();
/*      */     try
/*      */     {
/* 2635 */       this.mc.setTypeMap(map);
/*      */     } catch (SQLException sqlException) {
/* 2637 */       checkAndFireConnectionError(sqlException);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadDumpInDeadlockExceptions() {
/* 2642 */     return this.mc.getIncludeThreadDumpInDeadlockExceptions();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadDumpInDeadlockExceptions(boolean flag) {
/* 2646 */     this.mc.setIncludeThreadDumpInDeadlockExceptions(flag);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadNamesAsStatementComment()
/*      */   {
/* 2651 */     return this.mc.getIncludeThreadNamesAsStatementComment();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadNamesAsStatementComment(boolean flag) {
/* 2655 */     this.mc.setIncludeThreadNamesAsStatementComment(flag);
/*      */   }
/*      */   
/*      */   public boolean isServerLocal() throws SQLException {
/* 2659 */     return this.mc.isServerLocal();
/*      */   }
/*      */   
/*      */   public void setAuthenticationPlugins(String authenticationPlugins) {
/* 2663 */     this.mc.setAuthenticationPlugins(authenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getAuthenticationPlugins() {
/* 2667 */     return this.mc.getAuthenticationPlugins();
/*      */   }
/*      */   
/*      */   public void setDisabledAuthenticationPlugins(String disabledAuthenticationPlugins) {
/* 2671 */     this.mc.setDisabledAuthenticationPlugins(disabledAuthenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getDisabledAuthenticationPlugins() {
/* 2675 */     return this.mc.getDisabledAuthenticationPlugins();
/*      */   }
/*      */   
/*      */   public void setDefaultAuthenticationPlugin(String defaultAuthenticationPlugin) {
/* 2679 */     this.mc.setDefaultAuthenticationPlugin(defaultAuthenticationPlugin);
/*      */   }
/*      */   
/*      */   public String getDefaultAuthenticationPlugin()
/*      */   {
/* 2684 */     return this.mc.getDefaultAuthenticationPlugin();
/*      */   }
/*      */   
/*      */   public void setParseInfoCacheFactory(String factoryClassname) {
/* 2688 */     this.mc.setParseInfoCacheFactory(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getParseInfoCacheFactory() {
/* 2692 */     return this.mc.getParseInfoCacheFactory();
/*      */   }
/*      */   
/*      */   public void setSchema(String schema) throws SQLException {
/* 2696 */     this.mc.setSchema(schema);
/*      */   }
/*      */   
/*      */   public String getSchema() throws SQLException {
/* 2700 */     return this.mc.getSchema();
/*      */   }
/*      */   
/*      */   public void abort(Executor executor) throws SQLException {
/* 2704 */     this.mc.abort(executor);
/*      */   }
/*      */   
/*      */   public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
/* 2708 */     this.mc.setNetworkTimeout(executor, milliseconds);
/*      */   }
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/* 2712 */     return this.mc.getNetworkTimeout();
/*      */   }
/*      */   
/*      */   public void setServerConfigCacheFactory(String factoryClassname) {
/* 2716 */     this.mc.setServerConfigCacheFactory(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getServerConfigCacheFactory() {
/* 2720 */     return this.mc.getServerConfigCacheFactory();
/*      */   }
/*      */   
/*      */   public void setDisconnectOnExpiredPasswords(boolean disconnectOnExpiredPasswords) {
/* 2724 */     this.mc.setDisconnectOnExpiredPasswords(disconnectOnExpiredPasswords);
/*      */   }
/*      */   
/*      */   public boolean getDisconnectOnExpiredPasswords() {
/* 2728 */     return this.mc.getDisconnectOnExpiredPasswords();
/*      */   }
/*      */   
/*      */   public void setGetProceduresReturnsFunctions(boolean getProcedureReturnsFunctions) {
/* 2732 */     this.mc.setGetProceduresReturnsFunctions(getProcedureReturnsFunctions);
/*      */   }
/*      */   
/*      */   public boolean getGetProceduresReturnsFunctions() {
/* 2736 */     return this.mc.getGetProceduresReturnsFunctions();
/*      */   }
/*      */   
/*      */   public void abortInternal() throws SQLException {
/* 2740 */     this.mc.abortInternal();
/*      */   }
/*      */   
/*      */   public Object getConnectionMutex() {
/* 2744 */     return this.mc.getConnectionMutex();
/*      */   }
/*      */   
/*      */   public boolean getAllowMasterDownConnections() {
/* 2748 */     return this.mc.getAllowMasterDownConnections();
/*      */   }
/*      */   
/*      */   public void setAllowMasterDownConnections(boolean connectIfMasterDown) {
/* 2752 */     this.mc.setAllowMasterDownConnections(connectIfMasterDown);
/*      */   }
/*      */   
/*      */   public boolean getReplicationEnableJMX() {
/* 2756 */     return this.mc.getReplicationEnableJMX();
/*      */   }
/*      */   
/*      */   public void setReplicationEnableJMX(boolean replicationEnableJMX) {
/* 2760 */     this.mc.setReplicationEnableJMX(replicationEnableJMX);
/*      */   }
/*      */   
/*      */   public String getConnectionAttributes() throws SQLException
/*      */   {
/* 2765 */     return this.mc.getConnectionAttributes();
/*      */   }
/*      */   
/*      */   public void setDetectCustomCollations(boolean detectCustomCollations) {
/* 2769 */     this.mc.setDetectCustomCollations(detectCustomCollations);
/*      */   }
/*      */   
/*      */   public boolean getDetectCustomCollations() {
/* 2773 */     return this.mc.getDetectCustomCollations();
/*      */   }
/*      */   
/*      */   public int getSessionMaxRows() {
/* 2777 */     return this.mc.getSessionMaxRows();
/*      */   }
/*      */   
/*      */   public void setSessionMaxRows(int max) throws SQLException {
/* 2781 */     this.mc.setSessionMaxRows(max);
/*      */   }
/*      */   
/*      */   public String getServerRSAPublicKeyFile() {
/* 2785 */     return this.mc.getServerRSAPublicKeyFile();
/*      */   }
/*      */   
/*      */   public void setServerRSAPublicKeyFile(String serverRSAPublicKeyFile) throws SQLException {
/* 2789 */     this.mc.setServerRSAPublicKeyFile(serverRSAPublicKeyFile);
/*      */   }
/*      */   
/*      */   public boolean getAllowPublicKeyRetrieval() {
/* 2793 */     return this.mc.getAllowPublicKeyRetrieval();
/*      */   }
/*      */   
/*      */   public void setAllowPublicKeyRetrieval(boolean allowPublicKeyRetrieval) throws SQLException {
/* 2797 */     this.mc.setAllowPublicKeyRetrieval(allowPublicKeyRetrieval);
/*      */   }
/*      */   
/*      */   public void setDontCheckOnDuplicateKeyUpdateInSQL(boolean dontCheckOnDuplicateKeyUpdateInSQL) {
/* 2801 */     this.mc.setDontCheckOnDuplicateKeyUpdateInSQL(dontCheckOnDuplicateKeyUpdateInSQL);
/*      */   }
/*      */   
/*      */   public boolean getDontCheckOnDuplicateKeyUpdateInSQL() {
/* 2805 */     return this.mc.getDontCheckOnDuplicateKeyUpdateInSQL();
/*      */   }
/*      */   
/*      */   public void setSocksProxyHost(String socksProxyHost) {
/* 2809 */     this.mc.setSocksProxyHost(socksProxyHost);
/*      */   }
/*      */   
/*      */   public String getSocksProxyHost() {
/* 2813 */     return this.mc.getSocksProxyHost();
/*      */   }
/*      */   
/*      */   public void setSocksProxyPort(int socksProxyPort) throws SQLException {
/* 2817 */     this.mc.setSocksProxyPort(socksProxyPort);
/*      */   }
/*      */   
/*      */   public int getSocksProxyPort() {
/* 2821 */     return this.mc.getSocksProxyPort();
/*      */   }
/*      */   
/*      */   public boolean getReadOnlyPropagatesToServer() {
/* 2825 */     return this.mc.getReadOnlyPropagatesToServer();
/*      */   }
/*      */   
/*      */   public void setReadOnlyPropagatesToServer(boolean flag) {
/* 2829 */     this.mc.setReadOnlyPropagatesToServer(flag);
/*      */   }
/*      */   
/*      */   public String getEnabledSSLCipherSuites() {
/* 2833 */     return this.mc.getEnabledSSLCipherSuites();
/*      */   }
/*      */   
/*      */   public void setEnabledSSLCipherSuites(String cipherSuites) {
/* 2837 */     this.mc.setEnabledSSLCipherSuites(cipherSuites);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/jdbc2/optional/ConnectionWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */