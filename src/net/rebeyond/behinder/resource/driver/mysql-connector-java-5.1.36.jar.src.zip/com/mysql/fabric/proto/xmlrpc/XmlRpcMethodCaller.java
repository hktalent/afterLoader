package com.mysql.fabric.proto.xmlrpc;

import com.mysql.fabric.FabricCommunicationException;
import java.util.List;

public abstract interface XmlRpcMethodCaller
{
  public abstract List<?> call(String paramString, Object[] paramArrayOfObject)
    throws FabricCommunicationException;
  
  public abstract void setHeader(String paramString1, String paramString2);
  
  public abstract void clearHeader(String paramString);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/proto/xmlrpc/XmlRpcMethodCaller.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */