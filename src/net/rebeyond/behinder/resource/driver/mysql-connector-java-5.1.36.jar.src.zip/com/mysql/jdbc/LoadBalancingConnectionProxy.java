/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadBalancingConnectionProxy
/*     */   extends MultiHostConnectionProxy
/*     */   implements PingTarget
/*     */ {
/*  54 */   private ConnectionGroup connectionGroup = null;
/*  55 */   private long connectionGroupProxyID = 0L;
/*     */   
/*     */   protected Map<String, ConnectionImpl> liveConnections;
/*     */   private Map<String, Integer> hostsToListIndexMap;
/*     */   private Map<ConnectionImpl, String> connectionsToHostsMap;
/*  60 */   private long activePhysicalConnections = 0L;
/*  61 */   private long totalPhysicalConnections = 0L;
/*     */   
/*     */   private long[] responseTimes;
/*     */   private int retriesAllDown;
/*     */   private BalanceStrategy balancer;
/*  66 */   private int autoCommitSwapThreshold = 0;
/*     */   
/*     */   public static final String BLACKLIST_TIMEOUT_PROPERTY_KEY = "loadBalanceBlacklistTimeout";
/*  69 */   private int globalBlacklistTimeout = 0;
/*  70 */   private static Map<String, Long> globalBlacklist = new HashMap();
/*  71 */   private String hostToRemove = null;
/*     */   
/*  73 */   private boolean inTransaction = false;
/*  74 */   private long transactionStartTime = 0L;
/*  75 */   private long transactionCount = 0L;
/*     */   private LoadBalanceExceptionChecker exceptionChecker;
/*     */   private static Constructor<?> JDBC_4_LB_CONNECTION_CTOR;
/*     */   
/*     */   static
/*     */   {
/*  81 */     if (Util.isJdbc4()) {
/*     */       try {
/*  83 */         JDBC_4_LB_CONNECTION_CTOR = Class.forName("com.mysql.jdbc.JDBC4LoadBalancedMySQLConnection").getConstructor(new Class[] { LoadBalancingConnectionProxy.class });
/*     */       }
/*     */       catch (SecurityException e) {
/*  86 */         throw new RuntimeException(e);
/*     */       } catch (NoSuchMethodException e) {
/*  88 */         throw new RuntimeException(e);
/*     */       } catch (ClassNotFoundException e) {
/*  90 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   LoadBalancingConnectionProxy(List<String> hosts, Properties props)
/*     */     throws SQLException
/*     */   {
/* 107 */     String group = props.getProperty("loadBalanceConnectionGroup", null);
/* 108 */     boolean enableJMX = false;
/* 109 */     String enableJMXAsString = props.getProperty("loadBalanceEnableJMX", "false");
/*     */     try {
/* 111 */       enableJMX = Boolean.parseBoolean(enableJMXAsString);
/*     */     } catch (Exception e) {
/* 113 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceEnableJMX", new Object[] { enableJMXAsString }), "S1009", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 118 */     if (group != null) {
/* 119 */       this.connectionGroup = ConnectionGroupManager.getConnectionGroupInstance(group);
/* 120 */       if (enableJMX) {
/* 121 */         ConnectionGroupManager.registerJmx();
/*     */       }
/* 123 */       this.connectionGroupProxyID = this.connectionGroup.registerConnectionProxy(this, hosts);
/* 124 */       hosts = new ArrayList(this.connectionGroup.getInitialHosts());
/*     */     }
/*     */     
/*     */ 
/* 128 */     int numHosts = initializeHostsSpecs(hosts, props);
/*     */     
/* 130 */     this.liveConnections = new HashMap(numHosts);
/* 131 */     this.hostsToListIndexMap = new HashMap(numHosts);
/* 132 */     for (int i = 0; i < numHosts; i++) {
/* 133 */       this.hostsToListIndexMap.put(this.hostList.get(i), Integer.valueOf(i));
/*     */     }
/* 135 */     this.connectionsToHostsMap = new HashMap(numHosts);
/* 136 */     this.responseTimes = new long[numHosts];
/*     */     
/* 138 */     String retriesAllDownAsString = this.localProps.getProperty("retriesAllDown", "120");
/*     */     try {
/* 140 */       this.retriesAllDown = Integer.parseInt(retriesAllDownAsString);
/*     */     } catch (NumberFormatException nfe) {
/* 142 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForRetriesAllDown", new Object[] { retriesAllDownAsString }), "S1009", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 147 */     String blacklistTimeoutAsString = this.localProps.getProperty("loadBalanceBlacklistTimeout", "0");
/*     */     try {
/* 149 */       this.globalBlacklistTimeout = Integer.parseInt(blacklistTimeoutAsString);
/*     */     } catch (NumberFormatException nfe) {
/* 151 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceBlacklistTimeout", new Object[] { retriesAllDownAsString }), "S1009", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 156 */     String strategy = this.localProps.getProperty("loadBalanceStrategy", "random");
/* 157 */     if ("random".equals(strategy)) {
/* 158 */       this.balancer = ((BalanceStrategy)Util.loadExtensions(null, props, "com.mysql.jdbc.RandomBalanceStrategy", "InvalidLoadBalanceStrategy", null).get(0));
/*     */     }
/* 160 */     else if ("bestResponseTime".equals(strategy)) {
/* 161 */       this.balancer = ((BalanceStrategy)Util.loadExtensions(null, props, "com.mysql.jdbc.BestResponseTimeBalanceStrategy", "InvalidLoadBalanceStrategy", null).get(0));
/*     */     }
/*     */     else {
/* 164 */       this.balancer = ((BalanceStrategy)Util.loadExtensions(null, props, strategy, "InvalidLoadBalanceStrategy", null).get(0));
/*     */     }
/*     */     
/* 167 */     String autoCommitSwapThresholdAsString = props.getProperty("loadBalanceAutoCommitStatementThreshold", "0");
/*     */     try {
/* 169 */       this.autoCommitSwapThreshold = Integer.parseInt(autoCommitSwapThresholdAsString);
/*     */     } catch (NumberFormatException nfe) {
/* 171 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceAutoCommitStatementThreshold", new Object[] { autoCommitSwapThresholdAsString }), "S1009", null);
/*     */     }
/*     */     
/*     */ 
/* 175 */     String autoCommitSwapRegex = props.getProperty("loadBalanceAutoCommitStatementRegex", "");
/* 176 */     if (!"".equals(autoCommitSwapRegex)) {
/*     */       try {
/* 178 */         "".matches(autoCommitSwapRegex);
/*     */       } catch (Exception e) {
/* 180 */         throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceAutoCommitStatementRegex", new Object[] { autoCommitSwapRegex }), "S1009", null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 186 */     if (this.autoCommitSwapThreshold > 0) {
/* 187 */       String statementInterceptors = this.localProps.getProperty("statementInterceptors");
/* 188 */       if (statementInterceptors == null) {
/* 189 */         this.localProps.setProperty("statementInterceptors", "com.mysql.jdbc.LoadBalancedAutoCommitInterceptor");
/* 190 */       } else if (statementInterceptors.length() > 0) {
/* 191 */         this.localProps.setProperty("statementInterceptors", statementInterceptors + ",com.mysql.jdbc.LoadBalancedAutoCommitInterceptor");
/*     */       }
/* 193 */       props.setProperty("statementInterceptors", this.localProps.getProperty("statementInterceptors"));
/*     */     }
/*     */     
/*     */ 
/* 197 */     this.balancer.init(null, props);
/*     */     
/* 199 */     String lbExceptionChecker = this.localProps.getProperty("loadBalanceExceptionChecker", "com.mysql.jdbc.StandardLoadBalanceExceptionChecker");
/* 200 */     this.exceptionChecker = ((LoadBalanceExceptionChecker)Util.loadExtensions(null, props, lbExceptionChecker, "InvalidLoadBalanceExceptionChecker", null).get(0));
/*     */     
/*     */ 
/* 203 */     pickNewConnection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MySQLConnection getNewWrapperForThisAsConnection()
/*     */     throws SQLException
/*     */   {
/* 214 */     if ((Util.isJdbc4()) || (JDBC_4_LB_CONNECTION_CTOR != null)) {
/* 215 */       return (MySQLConnection)Util.handleNewInstance(JDBC_4_LB_CONNECTION_CTOR, new Object[] { this }, null);
/*     */     }
/* 217 */     return new LoadBalancedMySQLConnection(this);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   boolean shouldExceptionTriggerFailover(Throwable t) {
/* 222 */     return shouldExceptionTriggerConnectionSwitch(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean shouldExceptionTriggerConnectionSwitch(Throwable t)
/*     */   {
/* 234 */     return ((t instanceof SQLException)) && (this.exceptionChecker.shouldExceptionTriggerFailover((SQLException)t));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void invalidateConnection(MySQLConnection conn)
/*     */     throws SQLException
/*     */   {
/* 245 */     super.invalidateConnection(conn);
/*     */     
/*     */ 
/* 248 */     if (isGlobalBlacklistEnabled()) {
/* 249 */       addToGlobalBlacklist((String)this.connectionsToHostsMap.get(conn));
/*     */     }
/*     */     
/*     */ 
/* 253 */     this.liveConnections.remove(this.connectionsToHostsMap.get(conn));
/* 254 */     Object mappedHost = this.connectionsToHostsMap.remove(conn);
/* 255 */     if ((mappedHost != null) && (this.hostsToListIndexMap.containsKey(mappedHost))) {
/* 256 */       int hostIndex = ((Integer)this.hostsToListIndexMap.get(mappedHost)).intValue();
/*     */       
/* 258 */       synchronized (this.responseTimes) {
/* 259 */         this.responseTimes[hostIndex] = 0L;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void pickNewConnection()
/*     */     throws SQLException
/*     */   {
/* 271 */     if ((this.isClosed) && (this.closedExplicitly)) {
/* 272 */       return;
/*     */     }
/*     */     
/* 275 */     if (this.currentConnection == null) {
/* 276 */       this.currentConnection = this.balancer.pickConnection(this, Collections.unmodifiableList(this.hostList), Collections.unmodifiableMap(this.liveConnections), (long[])this.responseTimes.clone(), this.retriesAllDown);
/*     */       
/* 278 */       return;
/*     */     }
/*     */     
/* 281 */     if (this.currentConnection.isClosed()) {
/* 282 */       invalidateCurrentConnection();
/*     */     }
/*     */     
/* 285 */     int pingTimeout = this.currentConnection.getLoadBalancePingTimeout();
/* 286 */     boolean pingBeforeReturn = this.currentConnection.getLoadBalanceValidateConnectionOnSwapServer();
/*     */     
/* 288 */     int hostsTried = 0; for (int hostsToTry = this.hostList.size(); hostsTried <= hostsToTry; hostsTried++) {
/* 289 */       ConnectionImpl newConn = null;
/*     */       try {
/* 291 */         newConn = this.balancer.pickConnection(this, Collections.unmodifiableList(this.hostList), Collections.unmodifiableMap(this.liveConnections), (long[])this.responseTimes.clone(), this.retriesAllDown);
/*     */         
/*     */ 
/* 294 */         if (this.currentConnection != null) {
/* 295 */           if (pingBeforeReturn) {
/* 296 */             if (pingTimeout == 0) {
/* 297 */               newConn.ping();
/*     */             } else {
/* 299 */               newConn.pingInternal(true, pingTimeout);
/*     */             }
/*     */           }
/*     */           
/* 303 */           syncSessionState(this.currentConnection, newConn);
/*     */         }
/*     */         
/* 306 */         this.currentConnection = newConn;
/* 307 */         return;
/*     */       }
/*     */       catch (SQLException e) {
/* 310 */         if ((shouldExceptionTriggerConnectionSwitch(e)) && (newConn != null))
/*     */         {
/* 312 */           invalidateConnection(newConn);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 318 */     this.isClosed = true;
/* 319 */     this.closedReason = "Connection closed after inability to pick valid new connection during load-balance.";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized ConnectionImpl createConnectionForHost(String hostPortSpec)
/*     */     throws SQLException
/*     */   {
/* 331 */     ConnectionImpl conn = super.createConnectionForHost(hostPortSpec);
/*     */     
/* 333 */     this.liveConnections.put(hostPortSpec, conn);
/* 334 */     this.connectionsToHostsMap.put(conn, hostPortSpec);
/*     */     
/* 336 */     this.activePhysicalConnections += 1L;
/* 337 */     this.totalPhysicalConnections += 1L;
/*     */     
/* 339 */     return conn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void closeAllConnections()
/*     */   {
/* 347 */     for (Connection c : this.liveConnections.values()) {
/*     */       try {
/* 349 */         this.activePhysicalConnections -= 1L;
/* 350 */         c.close();
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */     
/* 355 */     if (!this.isClosed) {
/* 356 */       this.balancer.destroy();
/* 357 */       if (this.connectionGroup != null) {
/* 358 */         this.connectionGroup.closeConnectionProxy(this);
/*     */       }
/*     */     }
/*     */     
/* 362 */     this.liveConnections.clear();
/* 363 */     this.connectionsToHostsMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void doClose()
/*     */   {
/* 371 */     closeAllConnections();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void doAbortInternal()
/*     */   {
/* 380 */     for (Connection c : this.liveConnections.values()) {
/*     */       try {
/* 382 */         this.activePhysicalConnections -= 1L;
/* 383 */         c.abortInternal();
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */     
/* 388 */     if (!this.isClosed) {
/* 389 */       this.balancer.destroy();
/* 390 */       if (this.connectionGroup != null) {
/* 391 */         this.connectionGroup.closeConnectionProxy(this);
/*     */       }
/*     */     }
/*     */     
/* 395 */     this.liveConnections.clear();
/* 396 */     this.connectionsToHostsMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   synchronized void doAbort(Executor executor)
/*     */   {
/* 405 */     for (Connection c : this.liveConnections.values()) {
/*     */       try {
/* 407 */         this.activePhysicalConnections -= 1L;
/* 408 */         c.abort(executor);
/*     */       }
/*     */       catch (SQLException e) {}
/*     */     }
/*     */     
/* 413 */     if (!this.isClosed) {
/* 414 */       this.balancer.destroy();
/* 415 */       if (this.connectionGroup != null) {
/* 416 */         this.connectionGroup.closeConnectionProxy(this);
/*     */       }
/*     */     }
/*     */     
/* 420 */     this.liveConnections.clear();
/* 421 */     this.connectionsToHostsMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Object invokeMore(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/* 431 */     String methodName = method.getName();
/*     */     
/* 433 */     if (this.isClosed) {
/* 434 */       if ((this.autoReconnect) && (!this.closedExplicitly))
/*     */       {
/* 436 */         this.currentConnection = null;
/* 437 */         pickNewConnection();
/* 438 */         this.isClosed = false;
/* 439 */         this.closedReason = null;
/*     */       } else {
/* 441 */         String reason = "No operations allowed after connection closed.";
/* 442 */         if (this.closedReason != null) {
/* 443 */           reason = reason + "  " + this.closedReason;
/*     */         }
/* 445 */         throw SQLError.createSQLException(reason, "08003", null);
/*     */       }
/*     */     }
/*     */     
/* 449 */     if (!this.inTransaction) {
/* 450 */       this.inTransaction = true;
/* 451 */       this.transactionStartTime = System.nanoTime();
/* 452 */       this.transactionCount += 1L;
/*     */     }
/*     */     
/* 455 */     Object result = null;
/*     */     try
/*     */     {
/* 458 */       result = method.invoke(this.thisAsConnection, args);
/*     */       
/* 460 */       if (result != null) {
/* 461 */         if ((result instanceof Statement)) {
/* 462 */           ((Statement)result).setPingTarget(this);
/*     */         }
/* 464 */         result = proxyIfIsJdbcInterface(result);
/*     */       }
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 468 */       dealWithInvocationException(e);
/*     */     }
/*     */     finally {
/* 471 */       if (("commit".equals(methodName)) || ("rollback".equals(methodName))) {
/* 472 */         this.inTransaction = false;
/*     */         
/*     */ 
/* 475 */         String host = (String)this.connectionsToHostsMap.get(this.currentConnection);
/*     */         
/* 477 */         if (host != null) {
/* 478 */           synchronized (this.responseTimes) {
/* 479 */             Integer hostIndex = (Integer)this.hostsToListIndexMap.get(host);
/*     */             
/* 481 */             if ((hostIndex != null) && (hostIndex.intValue() < this.responseTimes.length)) {
/* 482 */               this.responseTimes[hostIndex.intValue()] = (System.nanoTime() - this.transactionStartTime);
/*     */             }
/*     */           }
/*     */         }
/* 486 */         pickNewConnection();
/*     */       }
/*     */     }
/*     */     
/* 490 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void doPing()
/*     */     throws SQLException
/*     */   {
/* 497 */     SQLException se = null;
/* 498 */     boolean foundHost = false;
/* 499 */     int pingTimeout = this.currentConnection.getLoadBalancePingTimeout();
/*     */     Iterator<String> i;
/* 501 */     synchronized (this) {
/* 502 */       for (i = this.hostList.iterator(); i.hasNext();) {
/* 503 */         String host = (String)i.next();
/* 504 */         ConnectionImpl conn = (ConnectionImpl)this.liveConnections.get(host);
/* 505 */         if (conn != null)
/*     */         {
/*     */           try
/*     */           {
/* 509 */             if (pingTimeout == 0) {
/* 510 */               conn.ping();
/*     */             } else {
/* 512 */               conn.pingInternal(true, pingTimeout);
/*     */             }
/* 514 */             foundHost = true;
/*     */           } catch (SQLException e) {
/* 516 */             this.activePhysicalConnections -= 1L;
/*     */             
/* 518 */             if (host.equals(this.connectionsToHostsMap.get(this.currentConnection)))
/*     */             {
/* 520 */               closeAllConnections();
/* 521 */               this.isClosed = true;
/* 522 */               this.closedReason = "Connection closed because ping of current connection failed.";
/* 523 */               throw e;
/*     */             }
/*     */             
/*     */ 
/* 527 */             if (e.getMessage().equals(Messages.getString("Connection.exceededConnectionLifetime")))
/*     */             {
/* 529 */               if (se == null) {
/* 530 */                 se = e;
/*     */               }
/*     */             }
/*     */             else {
/* 534 */               se = e;
/* 535 */               if (isGlobalBlacklistEnabled()) {
/* 536 */                 addToGlobalBlacklist(host);
/*     */               }
/*     */             }
/*     */             
/* 540 */             this.liveConnections.remove(this.connectionsToHostsMap.get(conn));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 545 */     if (!foundHost) {
/* 546 */       closeAllConnections();
/* 547 */       this.isClosed = true;
/* 548 */       this.closedReason = "Connection closed due to inability to ping any active connections.";
/*     */       
/* 550 */       if (se != null) {
/* 551 */         throw se;
/*     */       }
/*     */       
/* 554 */       ((ConnectionImpl)this.currentConnection).throwConnectionClosedException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addToGlobalBlacklist(String host, long timeout)
/*     */   {
/* 567 */     if (isGlobalBlacklistEnabled()) {
/* 568 */       synchronized (globalBlacklist) {
/* 569 */         globalBlacklist.put(host, Long.valueOf(timeout));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addToGlobalBlacklist(String host)
/*     */   {
/* 581 */     addToGlobalBlacklist(host, System.currentTimeMillis() + this.globalBlacklistTimeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isGlobalBlacklistEnabled()
/*     */   {
/* 591 */     return this.globalBlacklistTimeout > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Map<String, Long> getGlobalBlacklist()
/*     */   {
/* 601 */     if (!isGlobalBlacklistEnabled()) {
/* 602 */       String localHostToRemove = this.hostToRemove;
/*     */       
/* 604 */       if (this.hostToRemove != null) {
/* 605 */         HashMap<String, Long> fakedBlacklist = new HashMap();
/* 606 */         fakedBlacklist.put(localHostToRemove, Long.valueOf(System.currentTimeMillis() + 5000L));
/* 607 */         return fakedBlacklist;
/*     */       }
/*     */       
/* 610 */       return new HashMap(1);
/*     */     }
/*     */     
/*     */ 
/* 614 */     Map<String, Long> blacklistClone = new HashMap(globalBlacklist.size());
/*     */     
/* 616 */     synchronized (globalBlacklist) {
/* 617 */       blacklistClone.putAll(globalBlacklist);
/*     */     }
/* 619 */     Set<String> keys = blacklistClone.keySet();
/*     */     
/*     */ 
/* 622 */     keys.retainAll(this.hostList);
/*     */     
/*     */ 
/* 625 */     for (Object i = keys.iterator(); ((Iterator)i).hasNext();) {
/* 626 */       String host = (String)((Iterator)i).next();
/*     */       
/* 628 */       Long timeout = (Long)globalBlacklist.get(host);
/* 629 */       if ((timeout != null) && (timeout.longValue() < System.currentTimeMillis()))
/*     */       {
/* 631 */         synchronized (globalBlacklist) {
/* 632 */           globalBlacklist.remove(host);
/*     */         }
/* 634 */         ((Iterator)i).remove();
/*     */       }
/*     */     }
/*     */     
/* 638 */     if (keys.size() == this.hostList.size())
/*     */     {
/*     */ 
/* 641 */       return new HashMap(1);
/*     */     }
/*     */     
/* 644 */     return blacklistClone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeHostWhenNotInUse(String host)
/*     */     throws SQLException
/*     */   {
/* 655 */     int timeBetweenChecks = 1000;
/* 656 */     long timeBeforeHardFail = 15000L;
/*     */     
/* 658 */     synchronized (this) {
/* 659 */       addToGlobalBlacklist(host, System.currentTimeMillis() + timeBeforeHardFail + 1000L);
/*     */       
/* 661 */       long cur = System.currentTimeMillis();
/*     */       
/* 663 */       while (System.currentTimeMillis() < cur + timeBeforeHardFail) {
/* 664 */         this.hostToRemove = host;
/*     */         
/* 666 */         if (!host.equals(this.currentConnection.getHost())) {
/* 667 */           removeHost(host);
/* 668 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 672 */           Thread.sleep(timeBetweenChecks);
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 679 */     removeHost(host);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeHost(String host)
/*     */     throws SQLException
/*     */   {
/* 690 */     if (this.connectionGroup != null) {
/* 691 */       if ((this.connectionGroup.getInitialHosts().size() == 1) && (this.connectionGroup.getInitialHosts().contains(host))) {
/* 692 */         throw SQLError.createSQLException("Cannot remove only configured host.", null);
/*     */       }
/*     */       
/* 695 */       this.hostToRemove = host;
/*     */       
/* 697 */       if (host.equals(this.currentConnection.getHost())) {
/* 698 */         closeAllConnections();
/*     */       } else {
/* 700 */         this.connectionsToHostsMap.remove(this.liveConnections.remove(host));
/* 701 */         Integer idx = (Integer)this.hostsToListIndexMap.remove(host);
/* 702 */         long[] newResponseTimes = new long[this.responseTimes.length - 1];
/* 703 */         int newIdx = 0;
/* 704 */         for (Iterator<String> i = this.hostList.iterator(); i.hasNext(); newIdx++) {
/* 705 */           String copyHost = (String)i.next();
/* 706 */           if ((idx != null) && (idx.intValue() < this.responseTimes.length)) {
/* 707 */             newResponseTimes[newIdx] = this.responseTimes[idx.intValue()];
/* 708 */             this.hostsToListIndexMap.put(copyHost, Integer.valueOf(newIdx));
/*     */           }
/*     */         }
/* 711 */         this.responseTimes = newResponseTimes;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean addHost(String host)
/*     */   {
/* 724 */     if (this.hostsToListIndexMap.containsKey(host)) {
/* 725 */       return false;
/*     */     }
/*     */     
/* 728 */     long[] newResponseTimes = new long[this.responseTimes.length + 1];
/* 729 */     System.arraycopy(this.responseTimes, 0, newResponseTimes, 0, this.responseTimes.length);
/*     */     
/* 731 */     this.responseTimes = newResponseTimes;
/* 732 */     this.hostList.add(host);
/* 733 */     this.hostsToListIndexMap.put(host, Integer.valueOf(this.responseTimes.length - 1));
/*     */     
/* 735 */     return true;
/*     */   }
/*     */   
/*     */   public synchronized boolean inTransaction() {
/* 739 */     return this.inTransaction;
/*     */   }
/*     */   
/*     */   public synchronized long getTransactionCount() {
/* 743 */     return this.transactionCount;
/*     */   }
/*     */   
/*     */   public synchronized long getActivePhysicalConnectionCount() {
/* 747 */     return this.activePhysicalConnections;
/*     */   }
/*     */   
/*     */   public synchronized long getTotalPhysicalConnectionCount() {
/* 751 */     return this.totalPhysicalConnections;
/*     */   }
/*     */   
/*     */   public synchronized long getConnectionGroupProxyID() {
/* 755 */     return this.connectionGroupProxyID;
/*     */   }
/*     */   
/*     */   public synchronized String getCurrentActiveHost() {
/* 759 */     MySQLConnection c = this.currentConnection;
/* 760 */     if (c != null) {
/* 761 */       Object o = this.connectionsToHostsMap.get(c);
/* 762 */       if (o != null) {
/* 763 */         return o.toString();
/*     */       }
/*     */     }
/* 766 */     return null;
/*     */   }
/*     */   
/*     */   public synchronized long getCurrentTransactionDuration() {
/* 770 */     if ((this.inTransaction) && (this.transactionStartTime > 0L)) {
/* 771 */       return System.nanoTime() - this.transactionStartTime;
/*     */     }
/* 773 */     return 0L;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/LoadBalancingConnectionProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */