/*    */ package com.mysql.fabric.proto.xmlrpc;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultSetParser
/*    */ {
/*    */   public List<Map> parse(Map info, List<List> rows)
/*    */   {
/* 43 */     List<String> fieldNames = (List)info.get("names");
/* 44 */     Map<String, Integer> fieldNameIndexes = new HashMap();
/* 45 */     for (int i = 0; i < fieldNames.size(); i++) {
/* 46 */       fieldNameIndexes.put(fieldNames.get(i), Integer.valueOf(i));
/*    */     }
/*    */     
/* 49 */     List<Map> result = new ArrayList(rows.size());
/* 50 */     for (List r : rows) {
/* 51 */       Map<String, Object> resultRow = new HashMap();
/* 52 */       for (Map.Entry<String, Integer> f : fieldNameIndexes.entrySet()) {
/* 53 */         resultRow.put(f.getKey(), r.get(((Integer)f.getValue()).intValue()));
/*    */       }
/* 55 */       result.add(resultRow);
/*    */     }
/* 57 */     return result;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/proto/xmlrpc/ResultSetParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */