/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MysqlDefs
/*     */ {
/*     */   static final int COM_BINLOG_DUMP = 18;
/*     */   static final int COM_CHANGE_USER = 17;
/*     */   static final int COM_CLOSE_STATEMENT = 25;
/*     */   static final int COM_CONNECT_OUT = 20;
/*     */   static final int COM_END = 29;
/*     */   static final int COM_EXECUTE = 23;
/*     */   static final int COM_FETCH = 28;
/*     */   static final int COM_LONG_DATA = 24;
/*     */   static final int COM_PREPARE = 22;
/*     */   static final int COM_REGISTER_SLAVE = 21;
/*     */   static final int COM_RESET_STMT = 26;
/*     */   static final int COM_SET_OPTION = 27;
/*     */   static final int COM_TABLE_DUMP = 19;
/*     */   static final int CONNECT = 11;
/*     */   static final int CREATE_DB = 5;
/*     */   static final int DEBUG = 13;
/*     */   static final int DELAYED_INSERT = 16;
/*     */   static final int DROP_DB = 6;
/*     */   static final int FIELD_LIST = 4;
/*     */   static final int FIELD_TYPE_BIT = 16;
/*     */   public static final int FIELD_TYPE_BLOB = 252;
/*     */   static final int FIELD_TYPE_DATE = 10;
/*     */   static final int FIELD_TYPE_DATETIME = 12;
/*     */   static final int FIELD_TYPE_DECIMAL = 0;
/*     */   static final int FIELD_TYPE_DOUBLE = 5;
/*     */   static final int FIELD_TYPE_ENUM = 247;
/*     */   static final int FIELD_TYPE_FLOAT = 4;
/*     */   static final int FIELD_TYPE_GEOMETRY = 255;
/*     */   static final int FIELD_TYPE_INT24 = 9;
/*     */   static final int FIELD_TYPE_LONG = 3;
/*     */   static final int FIELD_TYPE_LONG_BLOB = 251;
/*     */   static final int FIELD_TYPE_LONGLONG = 8;
/*     */   static final int FIELD_TYPE_MEDIUM_BLOB = 250;
/*     */   static final int FIELD_TYPE_NEW_DECIMAL = 246;
/*     */   static final int FIELD_TYPE_NEWDATE = 14;
/*     */   static final int FIELD_TYPE_NULL = 6;
/*     */   static final int FIELD_TYPE_SET = 248;
/*     */   static final int FIELD_TYPE_SHORT = 2;
/*     */   static final int FIELD_TYPE_STRING = 254;
/*     */   static final int FIELD_TYPE_TIME = 11;
/*     */   static final int FIELD_TYPE_TIMESTAMP = 7;
/*     */   static final int FIELD_TYPE_TINY = 1;
/*     */   static final int FIELD_TYPE_TINY_BLOB = 249;
/*     */   static final int FIELD_TYPE_VAR_STRING = 253;
/*     */   static final int FIELD_TYPE_VARCHAR = 15;
/*     */   static final int FIELD_TYPE_YEAR = 13;
/*     */   static final int INIT_DB = 2;
/*     */   static final long LENGTH_BLOB = 65535L;
/*     */   static final long LENGTH_LONGBLOB = 4294967295L;
/*     */   static final long LENGTH_MEDIUMBLOB = 16777215L;
/*     */   static final long LENGTH_TINYBLOB = 255L;
/*     */   static final int MAX_ROWS = 50000000;
/*     */   public static final int NO_CHARSET_INFO = -1;
/*     */   static final byte OPEN_CURSOR_FLAG = 1;
/*     */   static final int PING = 14;
/*     */   static final int PROCESS_INFO = 10;
/*     */   static final int PROCESS_KILL = 12;
/*     */   static final int QUERY = 3;
/*     */   static final int QUIT = 1;
/*     */   static final int RELOAD = 7;
/*     */   static final int SHUTDOWN = 8;
/*     */   static final int SLEEP = 0;
/*     */   static final int STATISTICS = 9;
/*     */   static final int TIME = 15;
/*     */   
/*     */   static int mysqlToJavaType(int mysqlType)
/*     */   {
/*     */     int jdbcType;
/* 180 */     switch (mysqlType) {
/*     */     case 0: 
/*     */     case 246: 
/* 183 */       jdbcType = 3;
/*     */       
/* 185 */       break;
/*     */     
/*     */     case 1: 
/* 188 */       jdbcType = -6;
/*     */       
/* 190 */       break;
/*     */     
/*     */     case 2: 
/* 193 */       jdbcType = 5;
/*     */       
/* 195 */       break;
/*     */     
/*     */     case 3: 
/* 198 */       jdbcType = 4;
/*     */       
/* 200 */       break;
/*     */     
/*     */     case 4: 
/* 203 */       jdbcType = 7;
/*     */       
/* 205 */       break;
/*     */     
/*     */     case 5: 
/* 208 */       jdbcType = 8;
/*     */       
/* 210 */       break;
/*     */     
/*     */     case 6: 
/* 213 */       jdbcType = 0;
/*     */       
/* 215 */       break;
/*     */     
/*     */     case 7: 
/* 218 */       jdbcType = 93;
/*     */       
/* 220 */       break;
/*     */     
/*     */     case 8: 
/* 223 */       jdbcType = -5;
/*     */       
/* 225 */       break;
/*     */     
/*     */     case 9: 
/* 228 */       jdbcType = 4;
/*     */       
/* 230 */       break;
/*     */     
/*     */     case 10: 
/* 233 */       jdbcType = 91;
/*     */       
/* 235 */       break;
/*     */     
/*     */     case 11: 
/* 238 */       jdbcType = 92;
/*     */       
/* 240 */       break;
/*     */     
/*     */     case 12: 
/* 243 */       jdbcType = 93;
/*     */       
/* 245 */       break;
/*     */     
/*     */     case 13: 
/* 248 */       jdbcType = 91;
/*     */       
/* 250 */       break;
/*     */     
/*     */     case 14: 
/* 253 */       jdbcType = 91;
/*     */       
/* 255 */       break;
/*     */     
/*     */     case 247: 
/* 258 */       jdbcType = 1;
/*     */       
/* 260 */       break;
/*     */     
/*     */     case 248: 
/* 263 */       jdbcType = 1;
/*     */       
/* 265 */       break;
/*     */     
/*     */     case 249: 
/* 268 */       jdbcType = -3;
/*     */       
/* 270 */       break;
/*     */     
/*     */     case 250: 
/* 273 */       jdbcType = -4;
/*     */       
/* 275 */       break;
/*     */     
/*     */     case 251: 
/* 278 */       jdbcType = -4;
/*     */       
/* 280 */       break;
/*     */     
/*     */     case 252: 
/* 283 */       jdbcType = -4;
/*     */       
/* 285 */       break;
/*     */     
/*     */     case 15: 
/*     */     case 253: 
/* 289 */       jdbcType = 12;
/*     */       
/* 291 */       break;
/*     */     
/*     */     case 254: 
/* 294 */       jdbcType = 1;
/*     */       
/* 296 */       break;
/*     */     case 255: 
/* 298 */       jdbcType = -2;
/*     */       
/* 300 */       break;
/*     */     case 16: 
/* 302 */       jdbcType = -7;
/*     */       
/* 304 */       break;
/*     */     default: 
/* 306 */       jdbcType = 12;
/*     */     }
/*     */     
/* 309 */     return jdbcType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static int mysqlToJavaType(String mysqlType)
/*     */   {
/* 316 */     if (mysqlType.equalsIgnoreCase("BIT"))
/* 317 */       return mysqlToJavaType(16);
/* 318 */     if (mysqlType.equalsIgnoreCase("TINYINT"))
/* 319 */       return mysqlToJavaType(1);
/* 320 */     if (mysqlType.equalsIgnoreCase("SMALLINT"))
/* 321 */       return mysqlToJavaType(2);
/* 322 */     if (mysqlType.equalsIgnoreCase("MEDIUMINT"))
/* 323 */       return mysqlToJavaType(9);
/* 324 */     if ((mysqlType.equalsIgnoreCase("INT")) || (mysqlType.equalsIgnoreCase("INTEGER")))
/* 325 */       return mysqlToJavaType(3);
/* 326 */     if (mysqlType.equalsIgnoreCase("BIGINT"))
/* 327 */       return mysqlToJavaType(8);
/* 328 */     if (mysqlType.equalsIgnoreCase("INT24"))
/* 329 */       return mysqlToJavaType(9);
/* 330 */     if (mysqlType.equalsIgnoreCase("REAL"))
/* 331 */       return mysqlToJavaType(5);
/* 332 */     if (mysqlType.equalsIgnoreCase("FLOAT"))
/* 333 */       return mysqlToJavaType(4);
/* 334 */     if (mysqlType.equalsIgnoreCase("DECIMAL"))
/* 335 */       return mysqlToJavaType(0);
/* 336 */     if (mysqlType.equalsIgnoreCase("NUMERIC"))
/* 337 */       return mysqlToJavaType(0);
/* 338 */     if (mysqlType.equalsIgnoreCase("DOUBLE"))
/* 339 */       return mysqlToJavaType(5);
/* 340 */     if (mysqlType.equalsIgnoreCase("CHAR"))
/* 341 */       return mysqlToJavaType(254);
/* 342 */     if (mysqlType.equalsIgnoreCase("VARCHAR"))
/* 343 */       return mysqlToJavaType(253);
/* 344 */     if (mysqlType.equalsIgnoreCase("DATE"))
/* 345 */       return mysqlToJavaType(10);
/* 346 */     if (mysqlType.equalsIgnoreCase("TIME"))
/* 347 */       return mysqlToJavaType(11);
/* 348 */     if (mysqlType.equalsIgnoreCase("YEAR"))
/* 349 */       return mysqlToJavaType(13);
/* 350 */     if (mysqlType.equalsIgnoreCase("TIMESTAMP"))
/* 351 */       return mysqlToJavaType(7);
/* 352 */     if (mysqlType.equalsIgnoreCase("DATETIME"))
/* 353 */       return mysqlToJavaType(12);
/* 354 */     if (mysqlType.equalsIgnoreCase("TINYBLOB"))
/* 355 */       return -2;
/* 356 */     if (mysqlType.equalsIgnoreCase("BLOB"))
/* 357 */       return -4;
/* 358 */     if (mysqlType.equalsIgnoreCase("MEDIUMBLOB"))
/* 359 */       return -4;
/* 360 */     if (mysqlType.equalsIgnoreCase("LONGBLOB"))
/* 361 */       return -4;
/* 362 */     if (mysqlType.equalsIgnoreCase("TINYTEXT"))
/* 363 */       return 12;
/* 364 */     if (mysqlType.equalsIgnoreCase("TEXT"))
/* 365 */       return -1;
/* 366 */     if (mysqlType.equalsIgnoreCase("MEDIUMTEXT"))
/* 367 */       return -1;
/* 368 */     if (mysqlType.equalsIgnoreCase("LONGTEXT"))
/* 369 */       return -1;
/* 370 */     if (mysqlType.equalsIgnoreCase("ENUM"))
/* 371 */       return mysqlToJavaType(247);
/* 372 */     if (mysqlType.equalsIgnoreCase("SET"))
/* 373 */       return mysqlToJavaType(248);
/* 374 */     if (mysqlType.equalsIgnoreCase("GEOMETRY"))
/* 375 */       return mysqlToJavaType(255);
/* 376 */     if (mysqlType.equalsIgnoreCase("BINARY"))
/* 377 */       return -2;
/* 378 */     if (mysqlType.equalsIgnoreCase("VARBINARY"))
/* 379 */       return -3;
/* 380 */     if (mysqlType.equalsIgnoreCase("BIT")) {
/* 381 */       return mysqlToJavaType(16);
/*     */     }
/*     */     
/*     */ 
/* 385 */     return 1111;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String typeToName(int mysqlType)
/*     */   {
/* 392 */     switch (mysqlType) {
/*     */     case 0: 
/* 394 */       return "FIELD_TYPE_DECIMAL";
/*     */     
/*     */     case 1: 
/* 397 */       return "FIELD_TYPE_TINY";
/*     */     
/*     */     case 2: 
/* 400 */       return "FIELD_TYPE_SHORT";
/*     */     
/*     */     case 3: 
/* 403 */       return "FIELD_TYPE_LONG";
/*     */     
/*     */     case 4: 
/* 406 */       return "FIELD_TYPE_FLOAT";
/*     */     
/*     */     case 5: 
/* 409 */       return "FIELD_TYPE_DOUBLE";
/*     */     
/*     */     case 6: 
/* 412 */       return "FIELD_TYPE_NULL";
/*     */     
/*     */     case 7: 
/* 415 */       return "FIELD_TYPE_TIMESTAMP";
/*     */     
/*     */     case 8: 
/* 418 */       return "FIELD_TYPE_LONGLONG";
/*     */     
/*     */     case 9: 
/* 421 */       return "FIELD_TYPE_INT24";
/*     */     
/*     */     case 10: 
/* 424 */       return "FIELD_TYPE_DATE";
/*     */     
/*     */     case 11: 
/* 427 */       return "FIELD_TYPE_TIME";
/*     */     
/*     */     case 12: 
/* 430 */       return "FIELD_TYPE_DATETIME";
/*     */     
/*     */     case 13: 
/* 433 */       return "FIELD_TYPE_YEAR";
/*     */     
/*     */     case 14: 
/* 436 */       return "FIELD_TYPE_NEWDATE";
/*     */     
/*     */     case 247: 
/* 439 */       return "FIELD_TYPE_ENUM";
/*     */     
/*     */     case 248: 
/* 442 */       return "FIELD_TYPE_SET";
/*     */     
/*     */     case 249: 
/* 445 */       return "FIELD_TYPE_TINY_BLOB";
/*     */     
/*     */     case 250: 
/* 448 */       return "FIELD_TYPE_MEDIUM_BLOB";
/*     */     
/*     */     case 251: 
/* 451 */       return "FIELD_TYPE_LONG_BLOB";
/*     */     
/*     */     case 252: 
/* 454 */       return "FIELD_TYPE_BLOB";
/*     */     
/*     */     case 253: 
/* 457 */       return "FIELD_TYPE_VAR_STRING";
/*     */     
/*     */     case 254: 
/* 460 */       return "FIELD_TYPE_STRING";
/*     */     
/*     */     case 15: 
/* 463 */       return "FIELD_TYPE_VARCHAR";
/*     */     
/*     */     case 255: 
/* 466 */       return "FIELD_TYPE_GEOMETRY";
/*     */     }
/*     */     
/* 469 */     return " Unknown MySQL Type # " + mysqlType;
/*     */   }
/*     */   
/*     */ 
/* 473 */   private static Map<String, Integer> mysqlToJdbcTypesMap = new HashMap();
/*     */   
/*     */   static {
/* 476 */     mysqlToJdbcTypesMap.put("BIT", Integer.valueOf(mysqlToJavaType(16)));
/*     */     
/* 478 */     mysqlToJdbcTypesMap.put("TINYINT", Integer.valueOf(mysqlToJavaType(1)));
/* 479 */     mysqlToJdbcTypesMap.put("SMALLINT", Integer.valueOf(mysqlToJavaType(2)));
/* 480 */     mysqlToJdbcTypesMap.put("MEDIUMINT", Integer.valueOf(mysqlToJavaType(9)));
/* 481 */     mysqlToJdbcTypesMap.put("INT", Integer.valueOf(mysqlToJavaType(3)));
/* 482 */     mysqlToJdbcTypesMap.put("INTEGER", Integer.valueOf(mysqlToJavaType(3)));
/* 483 */     mysqlToJdbcTypesMap.put("BIGINT", Integer.valueOf(mysqlToJavaType(8)));
/* 484 */     mysqlToJdbcTypesMap.put("INT24", Integer.valueOf(mysqlToJavaType(9)));
/* 485 */     mysqlToJdbcTypesMap.put("REAL", Integer.valueOf(mysqlToJavaType(5)));
/* 486 */     mysqlToJdbcTypesMap.put("FLOAT", Integer.valueOf(mysqlToJavaType(4)));
/* 487 */     mysqlToJdbcTypesMap.put("DECIMAL", Integer.valueOf(mysqlToJavaType(0)));
/* 488 */     mysqlToJdbcTypesMap.put("NUMERIC", Integer.valueOf(mysqlToJavaType(0)));
/* 489 */     mysqlToJdbcTypesMap.put("DOUBLE", Integer.valueOf(mysqlToJavaType(5)));
/* 490 */     mysqlToJdbcTypesMap.put("CHAR", Integer.valueOf(mysqlToJavaType(254)));
/* 491 */     mysqlToJdbcTypesMap.put("VARCHAR", Integer.valueOf(mysqlToJavaType(253)));
/* 492 */     mysqlToJdbcTypesMap.put("DATE", Integer.valueOf(mysqlToJavaType(10)));
/* 493 */     mysqlToJdbcTypesMap.put("TIME", Integer.valueOf(mysqlToJavaType(11)));
/* 494 */     mysqlToJdbcTypesMap.put("YEAR", Integer.valueOf(mysqlToJavaType(13)));
/* 495 */     mysqlToJdbcTypesMap.put("TIMESTAMP", Integer.valueOf(mysqlToJavaType(7)));
/* 496 */     mysqlToJdbcTypesMap.put("DATETIME", Integer.valueOf(mysqlToJavaType(12)));
/* 497 */     mysqlToJdbcTypesMap.put("TINYBLOB", Integer.valueOf(-2));
/* 498 */     mysqlToJdbcTypesMap.put("BLOB", Integer.valueOf(-4));
/* 499 */     mysqlToJdbcTypesMap.put("MEDIUMBLOB", Integer.valueOf(-4));
/* 500 */     mysqlToJdbcTypesMap.put("LONGBLOB", Integer.valueOf(-4));
/* 501 */     mysqlToJdbcTypesMap.put("TINYTEXT", Integer.valueOf(12));
/* 502 */     mysqlToJdbcTypesMap.put("TEXT", Integer.valueOf(-1));
/* 503 */     mysqlToJdbcTypesMap.put("MEDIUMTEXT", Integer.valueOf(-1));
/* 504 */     mysqlToJdbcTypesMap.put("LONGTEXT", Integer.valueOf(-1));
/* 505 */     mysqlToJdbcTypesMap.put("ENUM", Integer.valueOf(mysqlToJavaType(247)));
/* 506 */     mysqlToJdbcTypesMap.put("SET", Integer.valueOf(mysqlToJavaType(248)));
/* 507 */     mysqlToJdbcTypesMap.put("GEOMETRY", Integer.valueOf(mysqlToJavaType(255)));
/*     */   }
/*     */   
/*     */   static final void appendJdbcTypeMappingQuery(StringBuilder buf, String mysqlTypeColumnName)
/*     */   {
/* 512 */     buf.append("CASE ");
/* 513 */     Map<String, Integer> typesMap = new HashMap();
/* 514 */     typesMap.putAll(mysqlToJdbcTypesMap);
/* 515 */     typesMap.put("BINARY", Integer.valueOf(-2));
/* 516 */     typesMap.put("VARBINARY", Integer.valueOf(-3));
/*     */     
/* 518 */     Iterator<String> mysqlTypes = typesMap.keySet().iterator();
/*     */     
/* 520 */     while (mysqlTypes.hasNext()) {
/* 521 */       String mysqlTypeName = (String)mysqlTypes.next();
/* 522 */       buf.append(" WHEN ");
/* 523 */       buf.append(mysqlTypeColumnName);
/* 524 */       buf.append("='");
/* 525 */       buf.append(mysqlTypeName);
/* 526 */       buf.append("' THEN ");
/* 527 */       buf.append(typesMap.get(mysqlTypeName));
/*     */       
/* 529 */       if ((mysqlTypeName.equalsIgnoreCase("DOUBLE")) || (mysqlTypeName.equalsIgnoreCase("FLOAT")) || (mysqlTypeName.equalsIgnoreCase("DECIMAL")) || (mysqlTypeName.equalsIgnoreCase("NUMERIC")))
/*     */       {
/* 531 */         buf.append(" WHEN ");
/* 532 */         buf.append(mysqlTypeColumnName);
/* 533 */         buf.append("='");
/* 534 */         buf.append(mysqlTypeName);
/* 535 */         buf.append(" unsigned' THEN ");
/* 536 */         buf.append(typesMap.get(mysqlTypeName));
/*     */       }
/*     */     }
/*     */     
/* 540 */     buf.append(" ELSE ");
/* 541 */     buf.append(1111);
/* 542 */     buf.append(" END ");
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/MysqlDefs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */