/*     */ package com.mysql.fabric.proto.xmlrpc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestAuthentication
/*     */ {
/*     */   public static String getChallengeHeader(String url)
/*     */     throws IOException
/*     */   {
/*  46 */     HttpURLConnection conn = (HttpURLConnection)new URL(url).openConnection();
/*  47 */     conn.setDoOutput(true);
/*  48 */     conn.getOutputStream().close();
/*     */     try {
/*  50 */       conn.getInputStream().close();
/*     */     } catch (IOException ex) {
/*  52 */       if (401 == conn.getResponseCode())
/*     */       {
/*     */ 
/*     */ 
/*  56 */         String hdr = conn.getHeaderField("WWW-Authenticate");
/*  57 */         if ((hdr != null) && (!"".equals(hdr)))
/*  58 */           return hdr;
/*     */       } else {
/*  60 */         if (400 == conn.getResponseCode())
/*     */         {
/*  62 */           throw new IOException("Fabric returns status 400. If authentication is disabled on the Fabric node, omit the `fabricUsername' and `fabricPassword' properties from your connection.");
/*     */         }
/*     */         
/*  65 */         throw ex;
/*     */       }
/*     */     }
/*  68 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String calculateMD5RequestDigest(String uri, String username, String password, String realm, String nonce, String nc, String cnonce, String qop)
/*     */   {
/*  76 */     String reqA1 = username + ":" + realm + ":" + password;
/*     */     
/*  78 */     String reqA2 = "POST:" + uri;
/*     */     
/*  80 */     String hashA1 = checksumMD5(reqA1);
/*  81 */     String hashA2 = checksumMD5(reqA2);
/*  82 */     String requestDigest = digestMD5(hashA1, nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + hashA2);
/*     */     
/*  84 */     return requestDigest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String checksumMD5(String data)
/*     */   {
/*  91 */     MessageDigest md5 = null;
/*     */     try {
/*  93 */       md5 = MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  95 */       throw new RuntimeException("Unable to create MD5 instance", ex);
/*     */     }
/*     */     
/*  98 */     return hexEncode(md5.digest(data.getBytes()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String digestMD5(String secret, String data)
/*     */   {
/* 105 */     return checksumMD5(secret + ":" + data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String hexEncode(byte[] data)
/*     */   {
/* 112 */     StringBuilder sb = new StringBuilder();
/* 113 */     for (int i = 0; i < data.length; i++) {
/* 114 */       sb.append(String.format("%02x", new Object[] { Byte.valueOf(data[i]) }));
/*     */     }
/* 116 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String serializeDigestResponse(Map<String, String> paramMap)
/*     */   {
/* 125 */     StringBuilder sb = new StringBuilder("Digest ");
/*     */     
/* 127 */     boolean prefixComma = false;
/* 128 */     for (Map.Entry<String, String> entry : paramMap.entrySet()) {
/* 129 */       if (!prefixComma) {
/* 130 */         prefixComma = true;
/*     */       } else {
/* 132 */         sb.append(", ");
/*     */       }
/* 134 */       sb.append((String)entry.getKey());
/* 135 */       sb.append("=");
/* 136 */       sb.append((String)entry.getValue());
/*     */     }
/*     */     
/* 139 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> parseDigestChallenge(String headerValue)
/*     */   {
/* 148 */     if (!headerValue.startsWith("Digest ")) {
/* 149 */       throw new IllegalArgumentException("Header is not a digest challenge");
/*     */     }
/*     */     
/* 152 */     String params = headerValue.substring(7);
/* 153 */     Map<String, String> paramMap = new HashMap();
/* 154 */     for (String param : params.split(",\\s*")) {
/* 155 */       String[] pieces = param.split("=");
/* 156 */       paramMap.put(pieces[0], pieces[1].replaceAll("^\"(.*)\"$", "$1"));
/*     */     }
/* 158 */     return paramMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String generateCnonce(String nonce, String nc)
/*     */   {
/* 168 */     byte[] buf = new byte[8];
/* 169 */     new Random().nextBytes(buf);
/* 170 */     for (int i = 0; i < 8; i++) {
/* 171 */       buf[i] = ((byte)(32 + buf[i] % 95));
/*     */     }
/*     */     
/* 174 */     String combo = String.format("%s:%s:%s:%s", new Object[] { nonce, nc, new Date().toGMTString(), new String(buf) });
/* 175 */     MessageDigest sha1 = null;
/*     */     try {
/* 177 */       sha1 = MessageDigest.getInstance("SHA-1");
/*     */     } catch (NoSuchAlgorithmException ex) {
/* 179 */       throw new RuntimeException("Unable to create SHA-1 instance", ex);
/*     */     }
/*     */     
/* 182 */     return hexEncode(sha1.digest(combo.getBytes()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String quoteParam(String param)
/*     */   {
/* 190 */     if ((param.contains("\"")) || (param.contains("'"))) {
/* 191 */       throw new IllegalArgumentException("Invalid character in parameter");
/*     */     }
/* 193 */     return "\"" + param + "\"";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String generateAuthorizationHeader(Map<String, String> digestChallenge, String username, String password)
/*     */   {
/* 201 */     String nonce = (String)digestChallenge.get("nonce");
/* 202 */     String nc = "00000001";
/* 203 */     String cnonce = generateCnonce(nonce, nc);
/* 204 */     String qop = "auth";
/* 205 */     String uri = "/RPC2";
/* 206 */     String realm = (String)digestChallenge.get("realm");
/* 207 */     String opaque = (String)digestChallenge.get("opaque");
/*     */     
/* 209 */     String requestDigest = calculateMD5RequestDigest(uri, username, password, realm, nonce, nc, cnonce, qop);
/* 210 */     Map<String, String> digestResponseMap = new HashMap();
/* 211 */     digestResponseMap.put("algorithm", "MD5");
/* 212 */     digestResponseMap.put("username", quoteParam(username));
/* 213 */     digestResponseMap.put("realm", quoteParam(realm));
/* 214 */     digestResponseMap.put("nonce", quoteParam(nonce));
/* 215 */     digestResponseMap.put("uri", quoteParam(uri));
/* 216 */     digestResponseMap.put("qop", qop);
/* 217 */     digestResponseMap.put("nc", nc);
/* 218 */     digestResponseMap.put("cnonce", quoteParam(cnonce));
/* 219 */     digestResponseMap.put("response", quoteParam(requestDigest));
/* 220 */     digestResponseMap.put("opaque", quoteParam(opaque));
/*     */     
/* 222 */     return serializeDigestResponse(digestResponseMap);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/fabric/proto/xmlrpc/DigestAuthentication.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */