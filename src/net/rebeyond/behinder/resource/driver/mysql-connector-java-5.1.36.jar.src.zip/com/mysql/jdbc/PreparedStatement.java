/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PreparedStatement
/*      */   extends StatementImpl
/*      */   implements java.sql.PreparedStatement
/*      */ {
/*      */   private static final Constructor<?> JDBC_4_PSTMT_2_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_PSTMT_3_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_PSTMT_4_ARG_CTOR;
/*      */   
/*      */   static
/*      */   {
/*   84 */     if (Util.isJdbc4()) {
/*      */       try {
/*   86 */         JDBC_4_PSTMT_2_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */         
/*   88 */         JDBC_4_PSTMT_3_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class });
/*      */         
/*   90 */         JDBC_4_PSTMT_4_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, ParseInfo.class });
/*      */       }
/*      */       catch (SecurityException e) {
/*   93 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*   95 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*   97 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  100 */       JDBC_4_PSTMT_2_ARG_CTOR = null;
/*  101 */       JDBC_4_PSTMT_3_ARG_CTOR = null;
/*  102 */       JDBC_4_PSTMT_4_ARG_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public class BatchParams {
/*  107 */     public boolean[] isNull = null;
/*      */     
/*  109 */     public boolean[] isStream = null;
/*      */     
/*  111 */     public InputStream[] parameterStreams = null;
/*      */     
/*  113 */     public byte[][] parameterStrings = (byte[][])null;
/*      */     
/*  115 */     public int[] streamLengths = null;
/*      */     
/*      */ 
/*      */ 
/*      */     BatchParams(byte[][] strings, InputStream[] streams, boolean[] isStreamFlags, int[] lengths, boolean[] isNullFlags)
/*      */     {
/*  121 */       this.parameterStrings = new byte[strings.length][];
/*  122 */       this.parameterStreams = new InputStream[streams.length];
/*  123 */       this.isStream = new boolean[isStreamFlags.length];
/*  124 */       this.streamLengths = new int[lengths.length];
/*  125 */       this.isNull = new boolean[isNullFlags.length];
/*  126 */       System.arraycopy(strings, 0, this.parameterStrings, 0, strings.length);
/*  127 */       System.arraycopy(streams, 0, this.parameterStreams, 0, streams.length);
/*  128 */       System.arraycopy(isStreamFlags, 0, this.isStream, 0, isStreamFlags.length);
/*  129 */       System.arraycopy(lengths, 0, this.streamLengths, 0, lengths.length);
/*  130 */       System.arraycopy(isNullFlags, 0, this.isNull, 0, isNullFlags.length);
/*      */     }
/*      */   }
/*      */   
/*      */   class EndPoint
/*      */   {
/*      */     int begin;
/*      */     int end;
/*      */     
/*      */     EndPoint(int b, int e) {
/*  140 */       this.begin = b;
/*  141 */       this.end = e;
/*      */     }
/*      */   }
/*      */   
/*      */   public static final class ParseInfo {
/*  146 */     char firstStmtChar = '\000';
/*      */     
/*  148 */     boolean foundLoadData = false;
/*      */     
/*  150 */     long lastUsed = 0L;
/*      */     
/*  152 */     int statementLength = 0;
/*      */     
/*  154 */     int statementStartPos = 0;
/*      */     
/*  156 */     boolean canRewriteAsMultiValueInsert = false;
/*      */     
/*  158 */     byte[][] staticSql = (byte[][])null;
/*      */     
/*  160 */     boolean isOnDuplicateKeyUpdate = false;
/*      */     
/*  162 */     int locationOfOnDuplicateKeyUpdate = -1;
/*      */     
/*      */     String valuesClause;
/*      */     
/*  166 */     boolean parametersInDuplicateKeyClause = false;
/*      */     String charEncoding;
/*      */     private ParseInfo batchHead;
/*      */     private ParseInfo batchValues;
/*      */     private ParseInfo batchODKUClause;
/*      */     
/*      */     ParseInfo(String sql, MySQLConnection conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter)
/*      */       throws SQLException
/*      */     {
/*  175 */       this(sql, conn, dbmd, encoding, converter, true);
/*      */     }
/*      */     
/*      */     public ParseInfo(String sql, MySQLConnection conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter, boolean buildRewriteInfo) throws SQLException
/*      */     {
/*      */       try {
/*  181 */         if (sql == null) {
/*  182 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.61"), "S1009", conn.getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*  186 */         this.charEncoding = encoding;
/*  187 */         this.lastUsed = System.currentTimeMillis();
/*      */         
/*  189 */         String quotedIdentifierString = dbmd.getIdentifierQuoteString();
/*      */         
/*  191 */         char quotedIdentifierChar = '\000';
/*      */         
/*  193 */         if ((quotedIdentifierString != null) && (!quotedIdentifierString.equals(" ")) && (quotedIdentifierString.length() > 0)) {
/*  194 */           quotedIdentifierChar = quotedIdentifierString.charAt(0);
/*      */         }
/*      */         
/*  197 */         this.statementLength = sql.length();
/*      */         
/*  199 */         ArrayList<int[]> endpointList = new ArrayList();
/*  200 */         boolean inQuotes = false;
/*  201 */         char quoteChar = '\000';
/*  202 */         boolean inQuotedId = false;
/*  203 */         int lastParmEnd = 0;
/*      */         
/*      */ 
/*  206 */         boolean noBackslashEscapes = conn.isNoBackslashEscapesSet();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  211 */         this.statementStartPos = StatementImpl.findStartOfStatement(sql);
/*      */         
/*  213 */         for (int i = this.statementStartPos; i < this.statementLength; i++) {
/*  214 */           char c = sql.charAt(i);
/*      */           
/*  216 */           if ((this.firstStmtChar == 0) && (Character.isLetter(c)))
/*      */           {
/*  218 */             this.firstStmtChar = Character.toUpperCase(c);
/*      */             
/*      */ 
/*  221 */             if (this.firstStmtChar == 'I') {
/*  222 */               this.locationOfOnDuplicateKeyUpdate = StatementImpl.getOnDuplicateKeyLocation(sql, conn.getDontCheckOnDuplicateKeyUpdateInSQL(), conn.getRewriteBatchedStatements(), conn.isNoBackslashEscapesSet());
/*      */               
/*  224 */               this.isOnDuplicateKeyUpdate = (this.locationOfOnDuplicateKeyUpdate != -1);
/*      */             }
/*      */           }
/*      */           
/*  228 */           if ((!noBackslashEscapes) && (c == '\\') && (i < this.statementLength - 1)) {
/*  229 */             i++;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  234 */             if ((!inQuotes) && (quotedIdentifierChar != 0) && (c == quotedIdentifierChar)) {
/*  235 */               inQuotedId = !inQuotedId;
/*  236 */             } else if (!inQuotedId)
/*      */             {
/*      */ 
/*  239 */               if (inQuotes) {
/*  240 */                 if (((c == '\'') || (c == '"')) && (c == quoteChar)) {
/*  241 */                   if ((i < this.statementLength - 1) && (sql.charAt(i + 1) == quoteChar)) {
/*  242 */                     i++;
/*  243 */                     continue;
/*      */                   }
/*      */                   
/*  246 */                   inQuotes = !inQuotes;
/*  247 */                   quoteChar = '\000';
/*  248 */                 } else if (((c == '\'') || (c == '"')) && (c == quoteChar)) {
/*  249 */                   inQuotes = !inQuotes;
/*  250 */                   quoteChar = '\000';
/*      */                 }
/*      */               } else {
/*  253 */                 if ((c == '#') || ((c == '-') && (i + 1 < this.statementLength) && (sql.charAt(i + 1) == '-')))
/*      */                 {
/*  255 */                   int endOfStmt = this.statementLength - 1;
/*  257 */                   for (; 
/*  257 */                       i < endOfStmt; i++) {
/*  258 */                     c = sql.charAt(i);
/*      */                     
/*  260 */                     if ((c == '\r') || (c == '\n')) {
/*      */                       break;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 
/*  266 */                 if ((c == '/') && (i + 1 < this.statementLength))
/*      */                 {
/*  268 */                   char cNext = sql.charAt(i + 1);
/*      */                   
/*  270 */                   if (cNext == '*') {
/*  271 */                     i += 2;
/*      */                     
/*  273 */                     for (int j = i; j < this.statementLength; j++) {
/*  274 */                       i++;
/*  275 */                       cNext = sql.charAt(j);
/*      */                       
/*  277 */                       if ((cNext == '*') && (j + 1 < this.statementLength) && 
/*  278 */                         (sql.charAt(j + 1) == '/')) {
/*  279 */                         i++;
/*      */                         
/*  281 */                         if (i >= this.statementLength) break;
/*  282 */                         c = sql.charAt(i); break;
/*      */                       }
/*      */                       
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/*      */                 }
/*  290 */                 else if ((c == '\'') || (c == '"')) {
/*  291 */                   inQuotes = true;
/*  292 */                   quoteChar = c;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*  297 */             if ((c == '?') && (!inQuotes) && (!inQuotedId)) {
/*  298 */               endpointList.add(new int[] { lastParmEnd, i });
/*  299 */               lastParmEnd = i + 1;
/*      */               
/*  301 */               if ((this.isOnDuplicateKeyUpdate) && (i > this.locationOfOnDuplicateKeyUpdate)) {
/*  302 */                 this.parametersInDuplicateKeyClause = true;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  307 */         if (this.firstStmtChar == 'L') {
/*  308 */           if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA")) {
/*  309 */             this.foundLoadData = true;
/*      */           } else {
/*  311 */             this.foundLoadData = false;
/*      */           }
/*      */         } else {
/*  314 */           this.foundLoadData = false;
/*      */         }
/*      */         
/*  317 */         endpointList.add(new int[] { lastParmEnd, this.statementLength });
/*  318 */         this.staticSql = new byte[endpointList.size()][];
/*      */         
/*  320 */         for (i = 0; i < this.staticSql.length; i++) {
/*  321 */           int[] ep = (int[])endpointList.get(i);
/*  322 */           int end = ep[1];
/*  323 */           int begin = ep[0];
/*  324 */           int len = end - begin;
/*      */           
/*  326 */           if (this.foundLoadData) {
/*  327 */             this.staticSql[i] = StringUtils.getBytes(sql, begin, len);
/*  328 */           } else if (encoding == null) {
/*  329 */             byte[] buf = new byte[len];
/*      */             
/*  331 */             for (int j = 0; j < len; j++) {
/*  332 */               buf[j] = ((byte)sql.charAt(begin + j));
/*      */             }
/*      */             
/*  335 */             this.staticSql[i] = buf;
/*      */           }
/*  337 */           else if (converter != null) {
/*  338 */             this.staticSql[i] = StringUtils.getBytes(sql, converter, encoding, conn.getServerCharset(), begin, len, conn.parserKnowsUnicode(), conn.getExceptionInterceptor());
/*      */           }
/*      */           else {
/*  341 */             this.staticSql[i] = StringUtils.getBytes(sql, encoding, conn.getServerCharset(), begin, len, conn.parserKnowsUnicode(), conn, conn.getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (StringIndexOutOfBoundsException oobEx)
/*      */       {
/*  347 */         SQLException sqlEx = new SQLException("Parse error for " + sql);
/*  348 */         sqlEx.initCause(oobEx);
/*      */         
/*  350 */         throw sqlEx;
/*      */       }
/*      */       
/*  353 */       if (buildRewriteInfo) {
/*  354 */         this.canRewriteAsMultiValueInsert = ((PreparedStatement.canRewrite(sql, this.isOnDuplicateKeyUpdate, this.locationOfOnDuplicateKeyUpdate, this.statementStartPos)) && (!this.parametersInDuplicateKeyClause));
/*      */         
/*      */ 
/*  357 */         if ((this.canRewriteAsMultiValueInsert) && (conn.getRewriteBatchedStatements())) {
/*  358 */           buildRewriteBatchedParams(sql, conn, dbmd, encoding, converter);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void buildRewriteBatchedParams(String sql, MySQLConnection conn, DatabaseMetaData metadata, String encoding, SingleByteCharsetConverter converter)
/*      */       throws SQLException
/*      */     {
/*  371 */       this.valuesClause = extractValuesClause(sql, conn.getMetaData().getIdentifierQuoteString());
/*  372 */       String odkuClause = this.isOnDuplicateKeyUpdate ? sql.substring(this.locationOfOnDuplicateKeyUpdate) : null;
/*      */       
/*  374 */       String headSql = null;
/*      */       
/*  376 */       if (this.isOnDuplicateKeyUpdate) {
/*  377 */         headSql = sql.substring(0, this.locationOfOnDuplicateKeyUpdate);
/*      */       } else {
/*  379 */         headSql = sql;
/*      */       }
/*      */       
/*  382 */       this.batchHead = new ParseInfo(headSql, conn, metadata, encoding, converter, false);
/*  383 */       this.batchValues = new ParseInfo("," + this.valuesClause, conn, metadata, encoding, converter, false);
/*  384 */       this.batchODKUClause = null;
/*      */       
/*  386 */       if ((odkuClause != null) && (odkuClause.length() > 0)) {
/*  387 */         this.batchODKUClause = new ParseInfo("," + this.valuesClause + " " + odkuClause, conn, metadata, encoding, converter, false);
/*      */       }
/*      */     }
/*      */     
/*      */     private String extractValuesClause(String sql, String quoteCharStr) throws SQLException {
/*  392 */       int indexOfValues = -1;
/*  393 */       int valuesSearchStart = this.statementStartPos;
/*      */       
/*  395 */       while (indexOfValues == -1) {
/*  396 */         if (quoteCharStr.length() > 0) {
/*  397 */           indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, sql, "VALUES", quoteCharStr, quoteCharStr, StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */         }
/*      */         else {
/*  400 */           indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, sql, "VALUES");
/*      */         }
/*      */         
/*  403 */         if (indexOfValues <= 0)
/*      */           break;
/*  405 */         char c = sql.charAt(indexOfValues - 1);
/*  406 */         if ((!Character.isWhitespace(c)) && (c != ')') && (c != '`')) {
/*  407 */           valuesSearchStart = indexOfValues + 6;
/*  408 */           indexOfValues = -1;
/*      */         }
/*      */         else {
/*  411 */           c = sql.charAt(indexOfValues + 6);
/*  412 */           if ((!Character.isWhitespace(c)) && (c != '(')) {
/*  413 */             valuesSearchStart = indexOfValues + 6;
/*  414 */             indexOfValues = -1;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  422 */       if (indexOfValues == -1) {
/*  423 */         return null;
/*      */       }
/*      */       
/*  426 */       int indexOfFirstParen = sql.indexOf('(', indexOfValues + 6);
/*      */       
/*  428 */       if (indexOfFirstParen == -1) {
/*  429 */         return null;
/*      */       }
/*      */       
/*  432 */       int endOfValuesClause = sql.lastIndexOf(')');
/*      */       
/*  434 */       if (endOfValuesClause == -1) {
/*  435 */         return null;
/*      */       }
/*      */       
/*  438 */       if (this.isOnDuplicateKeyUpdate) {
/*  439 */         endOfValuesClause = this.locationOfOnDuplicateKeyUpdate - 1;
/*      */       }
/*      */       
/*  442 */       return sql.substring(indexOfFirstParen, endOfValuesClause + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     synchronized ParseInfo getParseInfoForBatch(int numBatch)
/*      */     {
/*  449 */       PreparedStatement.AppendingBatchVisitor apv = new PreparedStatement.AppendingBatchVisitor();
/*  450 */       buildInfoForBatch(numBatch, apv);
/*      */       
/*  452 */       ParseInfo batchParseInfo = new ParseInfo(apv.getStaticSqlStrings(), this.firstStmtChar, this.foundLoadData, this.isOnDuplicateKeyUpdate, this.locationOfOnDuplicateKeyUpdate, this.statementLength, this.statementStartPos);
/*      */       
/*      */ 
/*  455 */       return batchParseInfo;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     String getSqlForBatch(int numBatch)
/*      */       throws UnsupportedEncodingException
/*      */     {
/*  464 */       ParseInfo batchInfo = getParseInfoForBatch(numBatch);
/*      */       
/*  466 */       return getSqlForBatch(batchInfo);
/*      */     }
/*      */     
/*      */ 
/*      */     String getSqlForBatch(ParseInfo batchInfo)
/*      */       throws UnsupportedEncodingException
/*      */     {
/*  473 */       int size = 0;
/*  474 */       byte[][] sqlStrings = batchInfo.staticSql;
/*  475 */       int sqlStringsLength = sqlStrings.length;
/*      */       
/*  477 */       for (int i = 0; i < sqlStringsLength; i++) {
/*  478 */         size += sqlStrings[i].length;
/*  479 */         size++;
/*      */       }
/*      */       
/*  482 */       StringBuilder buf = new StringBuilder(size);
/*      */       
/*  484 */       for (int i = 0; i < sqlStringsLength - 1; i++) {
/*  485 */         buf.append(StringUtils.toString(sqlStrings[i], this.charEncoding));
/*  486 */         buf.append("?");
/*      */       }
/*      */       
/*  489 */       buf.append(StringUtils.toString(sqlStrings[(sqlStringsLength - 1)]));
/*      */       
/*  491 */       return buf.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void buildInfoForBatch(int numBatch, PreparedStatement.BatchVisitor visitor)
/*      */     {
/*  503 */       byte[][] headStaticSql = this.batchHead.staticSql;
/*  504 */       int headStaticSqlLength = headStaticSql.length;
/*      */       
/*  506 */       if (headStaticSqlLength > 1) {
/*  507 */         for (int i = 0; i < headStaticSqlLength - 1; i++) {
/*  508 */           visitor.append(headStaticSql[i]).increment();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  513 */       byte[] endOfHead = headStaticSql[(headStaticSqlLength - 1)];
/*  514 */       byte[][] valuesStaticSql = this.batchValues.staticSql;
/*  515 */       byte[] beginOfValues = valuesStaticSql[0];
/*      */       
/*  517 */       visitor.merge(endOfHead, beginOfValues).increment();
/*      */       
/*  519 */       int numValueRepeats = numBatch - 1;
/*      */       
/*  521 */       if (this.batchODKUClause != null) {
/*  522 */         numValueRepeats--;
/*      */       }
/*      */       
/*  525 */       int valuesStaticSqlLength = valuesStaticSql.length;
/*  526 */       byte[] endOfValues = valuesStaticSql[(valuesStaticSqlLength - 1)];
/*      */       
/*  528 */       for (int i = 0; i < numValueRepeats; i++) {
/*  529 */         for (int j = 1; j < valuesStaticSqlLength - 1; j++) {
/*  530 */           visitor.append(valuesStaticSql[j]).increment();
/*      */         }
/*  532 */         visitor.merge(endOfValues, beginOfValues).increment();
/*      */       }
/*      */       
/*  535 */       if (this.batchODKUClause != null) {
/*  536 */         byte[][] batchOdkuStaticSql = this.batchODKUClause.staticSql;
/*  537 */         byte[] beginOfOdku = batchOdkuStaticSql[0];
/*  538 */         visitor.decrement().merge(endOfValues, beginOfOdku).increment();
/*      */         
/*  540 */         int batchOdkuStaticSqlLength = batchOdkuStaticSql.length;
/*      */         
/*  542 */         if (numBatch > 1) {
/*  543 */           for (int i = 1; i < batchOdkuStaticSqlLength; i++) {
/*  544 */             visitor.append(batchOdkuStaticSql[i]).increment();
/*      */           }
/*      */         } else {
/*  547 */           visitor.decrement().append(batchOdkuStaticSql[(batchOdkuStaticSqlLength - 1)]);
/*      */         }
/*      */       }
/*      */       else {
/*  551 */         visitor.decrement().append(this.staticSql[(this.staticSql.length - 1)]);
/*      */       }
/*      */     }
/*      */     
/*      */     private ParseInfo(byte[][] staticSql, char firstStmtChar, boolean foundLoadData, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementLength, int statementStartPos)
/*      */     {
/*  557 */       this.firstStmtChar = firstStmtChar;
/*  558 */       this.foundLoadData = foundLoadData;
/*  559 */       this.isOnDuplicateKeyUpdate = isOnDuplicateKeyUpdate;
/*  560 */       this.locationOfOnDuplicateKeyUpdate = locationOfOnDuplicateKeyUpdate;
/*  561 */       this.statementLength = statementLength;
/*  562 */       this.statementStartPos = statementStartPos;
/*  563 */       this.staticSql = staticSql;
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract interface BatchVisitor {
/*      */     public abstract BatchVisitor increment();
/*      */     
/*      */     public abstract BatchVisitor decrement();
/*      */     
/*      */     public abstract BatchVisitor append(byte[] paramArrayOfByte);
/*      */     
/*      */     public abstract BatchVisitor merge(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   }
/*      */   
/*      */   static class AppendingBatchVisitor implements PreparedStatement.BatchVisitor {
/*  578 */     LinkedList<byte[]> statementComponents = new LinkedList();
/*      */     
/*      */     public PreparedStatement.BatchVisitor append(byte[] values) {
/*  581 */       this.statementComponents.addLast(values);
/*      */       
/*  583 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor increment()
/*      */     {
/*  588 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor decrement() {
/*  592 */       this.statementComponents.removeLast();
/*      */       
/*  594 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor merge(byte[] front, byte[] back) {
/*  598 */       int mergedLength = front.length + back.length;
/*  599 */       byte[] merged = new byte[mergedLength];
/*  600 */       System.arraycopy(front, 0, merged, 0, front.length);
/*  601 */       System.arraycopy(back, 0, merged, front.length, back.length);
/*  602 */       this.statementComponents.addLast(merged);
/*  603 */       return this;
/*      */     }
/*      */     
/*      */     public byte[][] getStaticSqlStrings() {
/*  607 */       byte[][] asBytes = new byte[this.statementComponents.size()][];
/*  608 */       this.statementComponents.toArray(asBytes);
/*      */       
/*  610 */       return asBytes;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  615 */       StringBuilder buf = new StringBuilder();
/*  616 */       Iterator<byte[]> iter = this.statementComponents.iterator();
/*  617 */       while (iter.hasNext()) {
/*  618 */         buf.append(StringUtils.toString((byte[])iter.next()));
/*      */       }
/*      */       
/*  621 */       return buf.toString();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  626 */   private static final byte[] HEX_DIGITS = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static int readFully(Reader reader, char[] buf, int length)
/*      */     throws IOException
/*      */   {
/*  640 */     int numCharsRead = 0;
/*      */     
/*  642 */     while (numCharsRead < length) {
/*  643 */       int count = reader.read(buf, numCharsRead, length - numCharsRead);
/*      */       
/*  645 */       if (count < 0) {
/*      */         break;
/*      */       }
/*      */       
/*  649 */       numCharsRead += count;
/*      */     }
/*      */     
/*  652 */     return numCharsRead;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  661 */   protected boolean batchHasPlainStatements = false;
/*      */   
/*  663 */   private DatabaseMetaData dbmd = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  669 */   protected char firstCharOfStmt = '\000';
/*      */   
/*      */ 
/*  672 */   protected boolean isLoadDataQuery = false;
/*      */   
/*  674 */   protected boolean[] isNull = null;
/*      */   
/*  676 */   private boolean[] isStream = null;
/*      */   
/*  678 */   protected int numberOfExecutions = 0;
/*      */   
/*      */ 
/*  681 */   protected String originalSql = null;
/*      */   
/*      */ 
/*      */   protected int parameterCount;
/*      */   
/*      */   protected MysqlParameterMetadata parameterMetaData;
/*      */   
/*  688 */   private InputStream[] parameterStreams = null;
/*      */   
/*  690 */   private byte[][] parameterValues = (byte[][])null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  696 */   protected int[] parameterTypes = null;
/*      */   
/*      */   protected ParseInfo parseInfo;
/*      */   
/*      */   private java.sql.ResultSetMetaData pstmtResultMetaData;
/*      */   
/*  702 */   private byte[][] staticSqlStrings = (byte[][])null;
/*      */   
/*  704 */   private byte[] streamConvertBuf = null;
/*      */   
/*  706 */   private int[] streamLengths = null;
/*      */   
/*  708 */   private SimpleDateFormat tsdf = null;
/*      */   
/*      */ 
/*      */   private SimpleDateFormat ddf;
/*      */   
/*      */ 
/*      */   private SimpleDateFormat tdf;
/*      */   
/*      */ 
/*  717 */   protected boolean useTrueBoolean = false;
/*      */   
/*      */   protected boolean usingAnsiMode;
/*      */   
/*      */   protected String batchedValuesClause;
/*      */   
/*      */   private boolean doPingInstead;
/*      */   
/*  725 */   private boolean compensateForOnDuplicateKeyUpdate = false;
/*      */   
/*      */ 
/*      */   private CharsetEncoder charsetEncoder;
/*      */   
/*      */ 
/*  731 */   protected int batchCommandIndex = -1;
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean serverSupportsFracSecs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String catalog)
/*      */     throws SQLException
/*      */   {
/*  743 */     if (!Util.isJdbc4()) {
/*  744 */       return new PreparedStatement(conn, catalog);
/*      */     }
/*      */     
/*  747 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_2_ARG_CTOR, new Object[] { conn, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String sql, String catalog)
/*      */     throws SQLException
/*      */   {
/*  758 */     if (!Util.isJdbc4()) {
/*  759 */       return new PreparedStatement(conn, sql, catalog);
/*      */     }
/*      */     
/*  762 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_3_ARG_CTOR, new Object[] { conn, sql, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String sql, String catalog, ParseInfo cachedParseInfo)
/*      */     throws SQLException
/*      */   {
/*  773 */     if (!Util.isJdbc4()) {
/*  774 */       return new PreparedStatement(conn, sql, catalog, cachedParseInfo);
/*      */     }
/*      */     
/*  777 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_4_ARG_CTOR, new Object[] { conn, sql, catalog, cachedParseInfo }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement(MySQLConnection conn, String catalog)
/*      */     throws SQLException
/*      */   {
/*  793 */     super(conn, catalog);
/*      */     
/*  795 */     detectFractionalSecondsSupport();
/*  796 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */   }
/*      */   
/*      */   protected void detectFractionalSecondsSupport() throws SQLException {
/*  800 */     this.serverSupportsFracSecs = ((this.connection != null) && (this.connection.versionMeetsMinimum(5, 6, 4)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement(MySQLConnection conn, String sql, String catalog)
/*      */     throws SQLException
/*      */   {
/*  817 */     super(conn, catalog);
/*      */     
/*  819 */     if (sql == null) {
/*  820 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.0"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  823 */     detectFractionalSecondsSupport();
/*  824 */     this.originalSql = sql;
/*      */     
/*  826 */     if (this.originalSql.startsWith("/* ping */")) {
/*  827 */       this.doPingInstead = true;
/*      */     } else {
/*  829 */       this.doPingInstead = false;
/*      */     }
/*      */     
/*  832 */     this.dbmd = this.connection.getMetaData();
/*      */     
/*  834 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */     
/*  836 */     this.parseInfo = new ParseInfo(sql, this.connection, this.dbmd, this.charEncoding, this.charConverter);
/*      */     
/*  838 */     initializeFromParseInfo();
/*      */     
/*  840 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */     
/*  842 */     if (conn.getRequiresEscapingEncoder()) {
/*  843 */       this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement(MySQLConnection conn, String sql, String catalog, ParseInfo cachedParseInfo)
/*      */     throws SQLException
/*      */   {
/*  862 */     super(conn, catalog);
/*      */     
/*  864 */     if (sql == null) {
/*  865 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.1"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  868 */     detectFractionalSecondsSupport();
/*  869 */     this.originalSql = sql;
/*      */     
/*  871 */     this.dbmd = this.connection.getMetaData();
/*      */     
/*  873 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */     
/*  875 */     this.parseInfo = cachedParseInfo;
/*      */     
/*  877 */     this.usingAnsiMode = (!this.connection.useAnsiQuotedIdentifiers());
/*      */     
/*  879 */     initializeFromParseInfo();
/*      */     
/*  881 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */     
/*  883 */     if (conn.getRequiresEscapingEncoder()) {
/*  884 */       this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  897 */     synchronized (checkClosed().getConnectionMutex()) {
/*  898 */       if (this.batchedArgs == null) {
/*  899 */         this.batchedArgs = new ArrayList();
/*      */       }
/*      */       
/*  902 */       for (int i = 0; i < this.parameterValues.length; i++) {
/*  903 */         checkAllParametersSet(this.parameterValues[i], this.parameterStreams[i], i);
/*      */       }
/*      */       
/*  906 */       this.batchedArgs.add(new BatchParams(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull));
/*      */     }
/*      */   }
/*      */   
/*      */   public void addBatch(String sql) throws SQLException
/*      */   {
/*  912 */     synchronized (checkClosed().getConnectionMutex()) {
/*  913 */       this.batchHasPlainStatements = true;
/*      */       
/*  915 */       super.addBatch(sql);
/*      */     }
/*      */   }
/*      */   
/*      */   public String asSql() throws SQLException {
/*  920 */     return asSql(false);
/*      */   }
/*      */   
/*      */   public String asSql(boolean quoteStreamsAndUnknowns) throws SQLException {
/*  924 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*  926 */       StringBuilder buf = new StringBuilder();
/*      */       try
/*      */       {
/*  929 */         int realParameterCount = this.parameterCount + getParameterIndexOffset();
/*  930 */         Object batchArg = null;
/*  931 */         if (this.batchCommandIndex != -1) {
/*  932 */           batchArg = this.batchedArgs.get(this.batchCommandIndex);
/*      */         }
/*      */         
/*  935 */         for (int i = 0; i < realParameterCount; i++) {
/*  936 */           if (this.charEncoding != null) {
/*  937 */             buf.append(StringUtils.toString(this.staticSqlStrings[i], this.charEncoding));
/*      */           } else {
/*  939 */             buf.append(StringUtils.toString(this.staticSqlStrings[i]));
/*      */           }
/*      */           
/*  942 */           byte[] val = null;
/*  943 */           if ((batchArg != null) && ((batchArg instanceof String))) {
/*  944 */             buf.append((String)batchArg);
/*      */           }
/*      */           else {
/*  947 */             if (this.batchCommandIndex == -1) {
/*  948 */               val = this.parameterValues[i];
/*      */             } else {
/*  950 */               val = ((BatchParams)batchArg).parameterStrings[i];
/*      */             }
/*      */             
/*  953 */             boolean isStreamParam = false;
/*  954 */             if (this.batchCommandIndex == -1) {
/*  955 */               isStreamParam = this.isStream[i];
/*      */             } else {
/*  957 */               isStreamParam = ((BatchParams)batchArg).isStream[i];
/*      */             }
/*      */             
/*  960 */             if ((val == null) && (!isStreamParam)) {
/*  961 */               if (quoteStreamsAndUnknowns) {
/*  962 */                 buf.append("'");
/*      */               }
/*      */               
/*  965 */               buf.append("** NOT SPECIFIED **");
/*      */               
/*  967 */               if (quoteStreamsAndUnknowns) {
/*  968 */                 buf.append("'");
/*      */               }
/*  970 */             } else if (isStreamParam) {
/*  971 */               if (quoteStreamsAndUnknowns) {
/*  972 */                 buf.append("'");
/*      */               }
/*      */               
/*  975 */               buf.append("** STREAM DATA **");
/*      */               
/*  977 */               if (quoteStreamsAndUnknowns) {
/*  978 */                 buf.append("'");
/*      */               }
/*      */             }
/*  981 */             else if (this.charConverter != null) {
/*  982 */               buf.append(this.charConverter.toString(val));
/*      */             }
/*  984 */             else if (this.charEncoding != null) {
/*  985 */               buf.append(new String(val, this.charEncoding));
/*      */             } else {
/*  987 */               buf.append(StringUtils.toAsciiString(val));
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  993 */         if (this.charEncoding != null) {
/*  994 */           buf.append(StringUtils.toString(this.staticSqlStrings[(this.parameterCount + getParameterIndexOffset())], this.charEncoding));
/*      */         } else {
/*  996 */           buf.append(StringUtils.toAsciiString(this.staticSqlStrings[(this.parameterCount + getParameterIndexOffset())]));
/*      */         }
/*      */       } catch (UnsupportedEncodingException uue) {
/*  999 */         throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */       }
/*      */       
/* 1002 */       return buf.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearBatch() throws SQLException
/*      */   {
/* 1008 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1009 */       this.batchHasPlainStatements = false;
/*      */       
/* 1011 */       super.clearBatch();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/* 1026 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1028 */       for (int i = 0; i < this.parameterValues.length; i++) {
/* 1029 */         this.parameterValues[i] = null;
/* 1030 */         this.parameterStreams[i] = null;
/* 1031 */         this.isStream[i] = false;
/* 1032 */         this.isNull[i] = false;
/* 1033 */         this.parameterTypes[i] = 0;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final void escapeblockFast(byte[] buf, Buffer packet, int size) throws SQLException {
/* 1039 */     int lastwritten = 0;
/*      */     
/* 1041 */     for (int i = 0; i < size; i++) {
/* 1042 */       byte b = buf[i];
/*      */       
/* 1044 */       if (b == 0)
/*      */       {
/* 1046 */         if (i > lastwritten) {
/* 1047 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/* 1051 */         packet.writeByte((byte)92);
/* 1052 */         packet.writeByte((byte)48);
/* 1053 */         lastwritten = i + 1;
/*      */       }
/* 1055 */       else if ((b == 92) || (b == 39) || ((!this.usingAnsiMode) && (b == 34)))
/*      */       {
/* 1057 */         if (i > lastwritten) {
/* 1058 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/* 1062 */         packet.writeByte((byte)92);
/* 1063 */         lastwritten = i;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1069 */     if (lastwritten < size) {
/* 1070 */       packet.writeBytesNoNull(buf, lastwritten, size - lastwritten);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void escapeblockFast(byte[] buf, ByteArrayOutputStream bytesOut, int size) {
/* 1075 */     int lastwritten = 0;
/*      */     
/* 1077 */     for (int i = 0; i < size; i++) {
/* 1078 */       byte b = buf[i];
/*      */       
/* 1080 */       if (b == 0)
/*      */       {
/* 1082 */         if (i > lastwritten) {
/* 1083 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/* 1087 */         bytesOut.write(92);
/* 1088 */         bytesOut.write(48);
/* 1089 */         lastwritten = i + 1;
/*      */       }
/* 1091 */       else if ((b == 92) || (b == 39) || ((!this.usingAnsiMode) && (b == 34)))
/*      */       {
/* 1093 */         if (i > lastwritten) {
/* 1094 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/* 1098 */         bytesOut.write(92);
/* 1099 */         lastwritten = i;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1105 */     if (lastwritten < size) {
/* 1106 */       bytesOut.write(buf, lastwritten, size - lastwritten);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkReadOnlySafeStatement()
/*      */     throws SQLException
/*      */   {
/* 1117 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1118 */       return (this.firstCharOfStmt == 'S') || (!this.connection.isReadOnly());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/* 1134 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1136 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1138 */       if (!checkReadOnlySafeStatement()) {
/* 1139 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.20") + Messages.getString("PreparedStatement.21"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1143 */       ResultSetInternalMethods rs = null;
/*      */       
/* 1145 */       CachedResultSetMetaData cachedMetadata = null;
/*      */       
/* 1147 */       this.lastQueryIsOnDupKeyUpdate = false;
/*      */       
/* 1149 */       if (this.retrieveGeneratedKeys) {
/* 1150 */         this.lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyUpdateInSQL();
/*      */       }
/*      */       
/* 1153 */       clearWarnings();
/*      */       
/* 1155 */       setupStreamingTimeout(locallyScopedConn);
/*      */       
/* 1157 */       this.batchedGeneratedKeys = null;
/*      */       
/* 1159 */       Buffer sendPacket = fillSendPacket();
/*      */       
/* 1161 */       String oldCatalog = null;
/*      */       
/* 1163 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1164 */         oldCatalog = locallyScopedConn.getCatalog();
/* 1165 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1171 */       if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1172 */         cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
/*      */       }
/*      */       
/* 1175 */       Field[] metadataFromCache = null;
/*      */       
/* 1177 */       if (cachedMetadata != null) {
/* 1178 */         metadataFromCache = cachedMetadata.fields;
/*      */       }
/*      */       
/* 1181 */       boolean oldInfoMsgState = false;
/*      */       
/* 1183 */       if (this.retrieveGeneratedKeys) {
/* 1184 */         oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 1185 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1191 */       locallyScopedConn.setSessionMaxRows(this.firstCharOfStmt == 'S' ? this.maxRows : -1);
/*      */       
/* 1193 */       rs = executeInternal(this.maxRows, sendPacket, createStreamingResultSet(), this.firstCharOfStmt == 'S', metadataFromCache, false);
/*      */       
/* 1195 */       if (cachedMetadata != null) {
/* 1196 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, rs);
/*      */       }
/* 1198 */       else if ((rs.reallyResult()) && (locallyScopedConn.getCacheResultSetMetadata())) {
/* 1199 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, rs);
/*      */       }
/*      */       
/*      */ 
/* 1203 */       if (this.retrieveGeneratedKeys) {
/* 1204 */         locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
/* 1205 */         rs.setFirstCharOfQuery(this.firstCharOfStmt);
/*      */       }
/*      */       
/* 1208 */       if (oldCatalog != null) {
/* 1209 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */       
/* 1212 */       if (rs != null) {
/* 1213 */         this.lastInsertId = rs.getUpdateID();
/*      */         
/* 1215 */         this.results = rs;
/*      */       }
/*      */       
/* 1218 */       return (rs != null) && (rs.reallyResult());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 1237 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1239 */       if (this.connection.isReadOnly()) {
/* 1240 */         throw new SQLException(Messages.getString("PreparedStatement.25") + Messages.getString("PreparedStatement.26"), "S1009");
/*      */       }
/*      */       
/*      */ 
/* 1244 */       if ((this.batchedArgs == null) || (this.batchedArgs.size() == 0)) {
/* 1245 */         return new int[0];
/*      */       }
/*      */       
/*      */ 
/* 1249 */       int batchTimeout = this.timeoutInMillis;
/* 1250 */       this.timeoutInMillis = 0;
/*      */       
/* 1252 */       resetCancelledState();
/*      */       try
/*      */       {
/* 1255 */         statementBegins();
/*      */         
/* 1257 */         clearWarnings();
/*      */         
/* 1259 */         if ((!this.batchHasPlainStatements) && (this.connection.getRewriteBatchedStatements()))
/*      */         {
/* 1261 */           if (canRewriteAsMultiValueInsertAtSqlLevel()) {
/* 1262 */             arrayOfInt = executeBatchedInserts(batchTimeout);jsr 83;return arrayOfInt;
/*      */           }
/*      */           
/* 1265 */           if ((this.connection.versionMeetsMinimum(4, 1, 0)) && (!this.batchHasPlainStatements) && (this.batchedArgs != null) && (this.batchedArgs.size() > 3))
/*      */           {
/* 1267 */             arrayOfInt = executePreparedBatchAsMultiStatement(batchTimeout);jsr 28;return arrayOfInt;
/*      */           }
/*      */         }
/*      */         
/* 1271 */         int[] arrayOfInt = executeBatchSerially(batchTimeout);jsr 15;return arrayOfInt;
/*      */       } finally {
/* 1273 */         jsr 6; } localObject2 = returnAddress;this.statementExecuting.set(false);
/*      */       
/* 1275 */       clearBatch();ret;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean canRewriteAsMultiValueInsertAtSqlLevel() throws SQLException
/*      */   {
/* 1281 */     return this.parseInfo.canRewriteAsMultiValueInsert;
/*      */   }
/*      */   
/*      */   protected int getLocationOfOnDuplicateKeyUpdate() throws SQLException {
/* 1285 */     return this.parseInfo.locationOfOnDuplicateKeyUpdate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String generateMultiStatementForBatch(int numBatches)
/*      */     throws SQLException
/*      */   {
/* 1466 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1467 */       StringBuilder newStatementSql = new StringBuilder((this.originalSql.length() + 1) * numBatches);
/*      */       
/* 1469 */       newStatementSql.append(this.originalSql);
/*      */       
/* 1471 */       for (int i = 0; i < numBatches - 1; i++) {
/* 1472 */         newStatementSql.append(';');
/* 1473 */         newStatementSql.append(this.originalSql);
/*      */       }
/*      */       
/* 1476 */       return newStatementSql.toString();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getValuesClause()
/*      */     throws SQLException
/*      */   {
/* 1629 */     return this.parseInfo.valuesClause;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int computeBatchSize(int numBatchedArgs)
/*      */     throws SQLException
/*      */   {
/* 1640 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1641 */       long[] combinedValues = computeMaxParameterSetSizeAndBatchSize(numBatchedArgs);
/*      */       
/* 1643 */       long maxSizeOfParameterSet = combinedValues[0];
/* 1644 */       long sizeOfEntireBatch = combinedValues[1];
/*      */       
/* 1646 */       int maxAllowedPacket = this.connection.getMaxAllowedPacket();
/*      */       
/* 1648 */       if (sizeOfEntireBatch < maxAllowedPacket - this.originalSql.length()) {
/* 1649 */         return numBatchedArgs;
/*      */       }
/*      */       
/* 1652 */       return (int)Math.max(1L, (maxAllowedPacket - this.originalSql.length()) / maxSizeOfParameterSet);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs)
/*      */     throws SQLException
/*      */   {
/* 1663 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1664 */       long sizeOfEntireBatch = 0L;
/* 1665 */       long maxSizeOfParameterSet = 0L;
/*      */       
/* 1667 */       for (int i = 0; i < numBatchedArgs; i++) {
/* 1668 */         BatchParams paramArg = (BatchParams)this.batchedArgs.get(i);
/*      */         
/* 1670 */         boolean[] isNullBatch = paramArg.isNull;
/* 1671 */         boolean[] isStreamBatch = paramArg.isStream;
/*      */         
/* 1673 */         long sizeOfParameterSet = 0L;
/*      */         
/* 1675 */         for (int j = 0; j < isNullBatch.length; j++) {
/* 1676 */           if (isNullBatch[j] == 0)
/*      */           {
/* 1678 */             if (isStreamBatch[j] != 0) {
/* 1679 */               int streamLength = paramArg.streamLengths[j];
/*      */               
/* 1681 */               if (streamLength != -1) {
/* 1682 */                 sizeOfParameterSet += streamLength * 2;
/*      */               } else {
/* 1684 */                 int paramLength = paramArg.parameterStrings[j].length;
/* 1685 */                 sizeOfParameterSet += paramLength;
/*      */               }
/*      */             } else {
/* 1688 */               sizeOfParameterSet += paramArg.parameterStrings[j].length;
/*      */             }
/*      */           } else {
/* 1691 */             sizeOfParameterSet += 4L;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1701 */         if (getValuesClause() != null) {
/* 1702 */           sizeOfParameterSet += getValuesClause().length() + 1;
/*      */         } else {
/* 1704 */           sizeOfParameterSet += this.originalSql.length() + 1;
/*      */         }
/*      */         
/* 1707 */         sizeOfEntireBatch += sizeOfParameterSet;
/*      */         
/* 1709 */         if (sizeOfParameterSet > maxSizeOfParameterSet) {
/* 1710 */           maxSizeOfParameterSet = sizeOfParameterSet;
/*      */         }
/*      */       }
/*      */       
/* 1714 */       return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int[] executeBatchSerially(int batchTimeout)
/*      */     throws SQLException
/*      */   {
/* 1727 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1728 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1730 */       if (locallyScopedConn == null) {
/* 1731 */         checkClosed();
/*      */       }
/*      */       
/* 1734 */       int[] updateCounts = null;
/*      */       
/* 1736 */       if (this.batchedArgs != null) {
/* 1737 */         int nbrCommands = this.batchedArgs.size();
/* 1738 */         updateCounts = new int[nbrCommands];
/*      */         
/* 1740 */         for (int i = 0; i < nbrCommands; i++) {
/* 1741 */           updateCounts[i] = -3;
/*      */         }
/*      */         
/* 1744 */         SQLException sqlEx = null;
/*      */         
/* 1746 */         StatementImpl.CancelTask timeoutTask = null;
/*      */         try
/*      */         {
/* 1749 */           if ((locallyScopedConn.getEnableQueryTimeouts()) && (batchTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0))) {
/* 1750 */             timeoutTask = new StatementImpl.CancelTask(this, this);
/* 1751 */             locallyScopedConn.getCancelTimer().schedule(timeoutTask, batchTimeout);
/*      */           }
/*      */           
/* 1754 */           if (this.retrieveGeneratedKeys) {
/* 1755 */             this.batchedGeneratedKeys = new ArrayList(nbrCommands);
/*      */           }
/*      */           
/* 1758 */           for (this.batchCommandIndex = 0; this.batchCommandIndex < nbrCommands; this.batchCommandIndex += 1) {
/* 1759 */             Object arg = this.batchedArgs.get(this.batchCommandIndex);
/*      */             
/* 1761 */             if ((arg instanceof String)) {
/* 1762 */               updateCounts[this.batchCommandIndex] = executeUpdate((String)arg);
/*      */             } else {
/* 1764 */               BatchParams paramArg = (BatchParams)arg;
/*      */               try
/*      */               {
/* 1767 */                 updateCounts[this.batchCommandIndex] = executeUpdate(paramArg.parameterStrings, paramArg.parameterStreams, paramArg.isStream, paramArg.streamLengths, paramArg.isNull, true);
/*      */                 
/*      */ 
/* 1770 */                 if (this.retrieveGeneratedKeys) {
/* 1771 */                   ResultSet rs = null;
/*      */                   try
/*      */                   {
/* 1774 */                     if (containsOnDuplicateKeyUpdateInSQL()) {
/* 1775 */                       rs = getGeneratedKeysInternal(1);
/*      */                     } else {
/* 1777 */                       rs = getGeneratedKeysInternal();
/*      */                     }
/*      */                     
/* 1780 */                     while (rs.next()) {
/* 1781 */                       this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */                     }
/*      */                   } finally {
/* 1784 */                     if (rs != null) {
/* 1785 */                       rs.close();
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               } catch (SQLException ex) {
/* 1790 */                 updateCounts[this.batchCommandIndex] = -3;
/*      */                 
/* 1792 */                 if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */                 {
/* 1794 */                   sqlEx = ex;
/*      */                 } else {
/* 1796 */                   int[] newUpdateCounts = new int[this.batchCommandIndex];
/* 1797 */                   System.arraycopy(updateCounts, 0, newUpdateCounts, 0, this.batchCommandIndex);
/*      */                   
/* 1799 */                   Object batchUpdateException = new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */                   
/* 1801 */                   ((SQLException)batchUpdateException).initCause(ex);
/* 1802 */                   throw ((Throwable)batchUpdateException);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 1808 */           if (sqlEx != null) {
/* 1809 */             SQLException batchUpdateException = new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */             
/* 1811 */             batchUpdateException.initCause(sqlEx);
/* 1812 */             throw batchUpdateException;
/*      */           }
/*      */         } catch (NullPointerException npe) {
/*      */           try {
/* 1816 */             checkClosed();
/*      */           } catch (SQLException connectionClosedEx) {
/* 1818 */             updateCounts[this.batchCommandIndex] = -3;
/*      */             
/* 1820 */             int[] newUpdateCounts = new int[this.batchCommandIndex];
/*      */             
/* 1822 */             System.arraycopy(updateCounts, 0, newUpdateCounts, 0, this.batchCommandIndex);
/*      */             
/* 1824 */             throw new BatchUpdateException(connectionClosedEx.getMessage(), connectionClosedEx.getSQLState(), connectionClosedEx.getErrorCode(), newUpdateCounts);
/*      */           }
/*      */           
/*      */ 
/* 1828 */           throw npe;
/*      */         } finally {
/* 1830 */           this.batchCommandIndex = -1;
/*      */           
/* 1832 */           if (timeoutTask != null) {
/* 1833 */             timeoutTask.cancel();
/* 1834 */             locallyScopedConn.getCancelTimer().purge();
/*      */           }
/*      */           
/* 1837 */           resetCancelledState();
/*      */         }
/*      */       }
/*      */       
/* 1841 */       return updateCounts != null ? updateCounts : new int[0];
/*      */     }
/*      */   }
/*      */   
/*      */   public String getDateTime(String pattern)
/*      */   {
/* 1847 */     SimpleDateFormat sdf = new SimpleDateFormat(pattern);
/* 1848 */     return sdf.format(new java.util.Date());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, Field[] metadataFromCache, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/* 1872 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*      */       try {
/* 1875 */         resetCancelledState();
/*      */         
/* 1877 */         MySQLConnection locallyScopedConnection = this.connection;
/*      */         
/* 1879 */         this.numberOfExecutions += 1;
/*      */         
/* 1881 */         if (this.doPingInstead) {
/* 1882 */           doPingInstead();
/*      */           
/* 1884 */           return this.results;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1889 */         StatementImpl.CancelTask timeoutTask = null;
/*      */         ResultSetInternalMethods rs;
/*      */         try {
/* 1892 */           if ((locallyScopedConnection.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConnection.versionMeetsMinimum(5, 0, 0))) {
/* 1893 */             timeoutTask = new StatementImpl.CancelTask(this, this);
/* 1894 */             locallyScopedConnection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */           }
/*      */           
/* 1897 */           if (!isBatch) {
/* 1898 */             statementBegins();
/*      */           }
/*      */           
/* 1901 */           rs = locallyScopedConnection.execSQL(this, null, maxRowsToRetrieve, sendPacket, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, metadataFromCache, isBatch);
/*      */           
/*      */ 
/* 1904 */           if (timeoutTask != null) {
/* 1905 */             timeoutTask.cancel();
/*      */             
/* 1907 */             locallyScopedConnection.getCancelTimer().purge();
/*      */             
/* 1909 */             if (timeoutTask.caughtWhileCancelling != null) {
/* 1910 */               throw timeoutTask.caughtWhileCancelling;
/*      */             }
/*      */             
/* 1913 */             timeoutTask = null;
/*      */           }
/*      */           
/* 1916 */           synchronized (this.cancelTimeoutMutex) {
/* 1917 */             if (this.wasCancelled) {
/* 1918 */               SQLException cause = null;
/*      */               
/* 1920 */               if (this.wasCancelledByTimeout) {
/* 1921 */                 cause = new MySQLTimeoutException();
/*      */               } else {
/* 1923 */                 cause = new MySQLStatementCancelledException();
/*      */               }
/*      */               
/* 1926 */               resetCancelledState();
/*      */               
/* 1928 */               throw cause;
/*      */             }
/*      */           }
/*      */         } finally {
/* 1932 */           if (!isBatch) {
/* 1933 */             this.statementExecuting.set(false);
/*      */           }
/*      */           
/* 1936 */           if (timeoutTask != null) {
/* 1937 */             timeoutTask.cancel();
/* 1938 */             locallyScopedConnection.getCancelTimer().purge();
/*      */           }
/*      */         }
/*      */         
/* 1942 */         return rs;
/*      */       } catch (NullPointerException npe) {
/* 1944 */         checkClosed();
/*      */         
/*      */ 
/* 1947 */         throw npe;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/* 1962 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 1964 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1966 */       checkForDml(this.originalSql, this.firstCharOfStmt);
/*      */       
/* 1968 */       CachedResultSetMetaData cachedMetadata = null;
/*      */       
/* 1970 */       clearWarnings();
/*      */       
/* 1972 */       this.batchedGeneratedKeys = null;
/*      */       
/* 1974 */       setupStreamingTimeout(locallyScopedConn);
/*      */       
/* 1976 */       Buffer sendPacket = fillSendPacket();
/*      */       
/* 1978 */       implicitlyCloseAllOpenResults();
/*      */       
/* 1980 */       String oldCatalog = null;
/*      */       
/* 1982 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1983 */         oldCatalog = locallyScopedConn.getCatalog();
/* 1984 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1990 */       if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1991 */         cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
/*      */       }
/*      */       
/* 1994 */       Field[] metadataFromCache = null;
/*      */       
/* 1996 */       if (cachedMetadata != null) {
/* 1997 */         metadataFromCache = cachedMetadata.fields;
/*      */       }
/*      */       
/* 2000 */       locallyScopedConn.setSessionMaxRows(this.maxRows);
/*      */       
/* 2002 */       this.results = executeInternal(this.maxRows, sendPacket, createStreamingResultSet(), true, metadataFromCache, false);
/*      */       
/* 2004 */       if (oldCatalog != null) {
/* 2005 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */       
/* 2008 */       if (cachedMetadata != null) {
/* 2009 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
/*      */       }
/* 2011 */       else if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 2012 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, this.results);
/*      */       }
/*      */       
/*      */ 
/* 2016 */       this.lastInsertId = this.results.getUpdateID();
/*      */       
/* 2018 */       return this.results;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/* 2034 */     return executeUpdate(true, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int executeUpdate(boolean clearBatchedGeneratedKeysAndWarnings, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/* 2043 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2044 */       if (clearBatchedGeneratedKeysAndWarnings) {
/* 2045 */         clearWarnings();
/* 2046 */         this.batchedGeneratedKeys = null;
/*      */       }
/*      */       
/* 2049 */       return executeUpdate(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull, isBatch);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int executeUpdate(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths, boolean[] batchedIsNull, boolean isReallyBatch)
/*      */     throws SQLException
/*      */   {
/* 2075 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 2077 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 2079 */       if (locallyScopedConn.isReadOnly()) {
/* 2080 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.34") + Messages.getString("PreparedStatement.35"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 2084 */       if ((this.firstCharOfStmt == 'S') && (isSelectQuery())) {
/* 2085 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.37"), "01S03", getExceptionInterceptor());
/*      */       }
/*      */       
/* 2088 */       implicitlyCloseAllOpenResults();
/*      */       
/* 2090 */       ResultSetInternalMethods rs = null;
/*      */       
/* 2092 */       Buffer sendPacket = fillSendPacket(batchedParameterStrings, batchedParameterStreams, batchedIsStream, batchedStreamLengths);
/*      */       
/* 2094 */       String oldCatalog = null;
/*      */       
/* 2096 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 2097 */         oldCatalog = locallyScopedConn.getCatalog();
/* 2098 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2104 */       locallyScopedConn.setSessionMaxRows(-1);
/*      */       
/* 2106 */       boolean oldInfoMsgState = false;
/*      */       
/* 2108 */       if (this.retrieveGeneratedKeys) {
/* 2109 */         oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 2110 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */       }
/*      */       
/* 2113 */       rs = executeInternal(-1, sendPacket, false, false, null, isReallyBatch);
/*      */       
/* 2115 */       if (this.retrieveGeneratedKeys) {
/* 2116 */         locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
/* 2117 */         rs.setFirstCharOfQuery(this.firstCharOfStmt);
/*      */       }
/*      */       
/* 2120 */       if (oldCatalog != null) {
/* 2121 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */       
/* 2124 */       this.results = rs;
/*      */       
/* 2126 */       this.updateCount = rs.getUpdateCount();
/*      */       
/* 2128 */       if ((containsOnDuplicateKeyUpdateInSQL()) && (this.compensateForOnDuplicateKeyUpdate) && (
/* 2129 */         (this.updateCount == 2L) || (this.updateCount == 0L))) {
/* 2130 */         this.updateCount = 1L;
/*      */       }
/*      */       
/*      */ 
/* 2134 */       int truncatedUpdateCount = 0;
/*      */       
/* 2136 */       if (this.updateCount > 2147483647L) {
/* 2137 */         truncatedUpdateCount = Integer.MAX_VALUE;
/*      */       } else {
/* 2139 */         truncatedUpdateCount = (int)this.updateCount;
/*      */       }
/*      */       
/* 2142 */       this.lastInsertId = rs.getUpdateID();
/*      */       
/* 2144 */       return truncatedUpdateCount;
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean containsOnDuplicateKeyUpdateInSQL() {
/* 2149 */     return this.parseInfo.isOnDuplicateKeyUpdate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths)
/*      */     throws SQLException
/*      */   {
/* 2186 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2187 */       Buffer sendPacket = this.connection.getIO().getSharedSendPacket();
/*      */       
/* 2189 */       sendPacket.clear();
/*      */       
/* 2191 */       sendPacket.writeByte((byte)3);
/*      */       
/* 2193 */       boolean useStreamLengths = this.connection.getUseStreamLengthsInPrepStmts();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2198 */       int ensurePacketSize = 0;
/*      */       
/* 2200 */       String statementComment = this.connection.getStatementComment();
/*      */       
/* 2202 */       byte[] commentAsBytes = null;
/*      */       
/* 2204 */       if (statementComment != null) {
/* 2205 */         if (this.charConverter != null) {
/* 2206 */           commentAsBytes = this.charConverter.toBytes(statementComment);
/*      */         } else {
/* 2208 */           commentAsBytes = StringUtils.getBytes(statementComment, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/* 2212 */         ensurePacketSize += commentAsBytes.length;
/* 2213 */         ensurePacketSize += 6;
/*      */       }
/*      */       
/* 2216 */       for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 2217 */         if ((batchedIsStream[i] != 0) && (useStreamLengths)) {
/* 2218 */           ensurePacketSize += batchedStreamLengths[i];
/*      */         }
/*      */       }
/*      */       
/* 2222 */       if (ensurePacketSize != 0) {
/* 2223 */         sendPacket.ensureCapacity(ensurePacketSize);
/*      */       }
/*      */       
/* 2226 */       if (commentAsBytes != null) {
/* 2227 */         sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 2228 */         sendPacket.writeBytesNoNull(commentAsBytes);
/* 2229 */         sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*      */       }
/*      */       
/* 2232 */       for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 2233 */         checkAllParametersSet(batchedParameterStrings[i], batchedParameterStreams[i], i);
/*      */         
/* 2235 */         sendPacket.writeBytesNoNull(this.staticSqlStrings[i]);
/*      */         
/* 2237 */         if (batchedIsStream[i] != 0) {
/* 2238 */           streamToBytes(sendPacket, batchedParameterStreams[i], true, batchedStreamLengths[i], useStreamLengths);
/*      */         } else {
/* 2240 */           sendPacket.writeBytesNoNull(batchedParameterStrings[i]);
/*      */         }
/*      */       }
/*      */       
/* 2244 */       sendPacket.writeBytesNoNull(this.staticSqlStrings[batchedParameterStrings.length]);
/*      */       
/* 2246 */       return sendPacket;
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkAllParametersSet(byte[] parameterString, InputStream parameterStream, int columnIndex) throws SQLException {
/* 2251 */     if ((parameterString == null) && (parameterStream == null))
/*      */     {
/* 2253 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.40") + (columnIndex + 1), "07001", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected PreparedStatement prepareBatchedInsertSQL(MySQLConnection localConn, int numBatches)
/*      */     throws SQLException
/*      */   {
/* 2262 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2263 */       PreparedStatement pstmt = new PreparedStatement(localConn, "Rewritten batch of: " + this.originalSql, this.currentCatalog, this.parseInfo.getParseInfoForBatch(numBatches));
/*      */       
/* 2265 */       pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);
/* 2266 */       pstmt.rewrittenBatchSize = numBatches;
/*      */       
/* 2268 */       return pstmt;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setRetrieveGeneratedKeys(boolean flag) throws SQLException {
/* 2273 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2274 */       this.retrieveGeneratedKeys = flag;
/*      */     }
/*      */   }
/*      */   
/* 2278 */   protected int rewrittenBatchSize = 0;
/*      */   
/*      */   public int getRewrittenBatchSize() {
/* 2281 */     return this.rewrittenBatchSize;
/*      */   }
/*      */   
/*      */   public String getNonRewrittenSql() throws SQLException {
/* 2285 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2286 */       int indexOfBatch = this.originalSql.indexOf(" of: ");
/*      */       
/* 2288 */       if (indexOfBatch != -1) {
/* 2289 */         return this.originalSql.substring(indexOfBatch + 5);
/*      */       }
/*      */       
/* 2292 */       return this.originalSql;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytesRepresentation(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 2302 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2303 */       if (this.isStream[parameterIndex] != 0) {
/* 2304 */         return streamToBytes(this.parameterStreams[parameterIndex], false, this.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */       }
/*      */       
/*      */ 
/* 2308 */       byte[] parameterVal = this.parameterValues[parameterIndex];
/*      */       
/* 2310 */       if (parameterVal == null) {
/* 2311 */         return null;
/*      */       }
/*      */       
/* 2314 */       if ((parameterVal[0] == 39) && (parameterVal[(parameterVal.length - 1)] == 39)) {
/* 2315 */         byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2316 */         System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */         
/* 2318 */         return valNoQuotes;
/*      */       }
/*      */       
/* 2321 */       return parameterVal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] getBytesRepresentationForBatch(int parameterIndex, int commandIndex)
/*      */     throws SQLException
/*      */   {
/* 2333 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2334 */       Object batchedArg = this.batchedArgs.get(commandIndex);
/* 2335 */       if ((batchedArg instanceof String)) {
/*      */         try {
/* 2337 */           return StringUtils.getBytes((String)batchedArg, this.charEncoding);
/*      */         }
/*      */         catch (UnsupportedEncodingException uue) {
/* 2340 */           throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */         }
/*      */       }
/*      */       
/* 2344 */       BatchParams params = (BatchParams)batchedArg;
/* 2345 */       if (params.isStream[parameterIndex] != 0) {
/* 2346 */         return streamToBytes(params.parameterStreams[parameterIndex], false, params.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */       }
/*      */       
/* 2349 */       byte[] parameterVal = params.parameterStrings[parameterIndex];
/* 2350 */       if (parameterVal == null) {
/* 2351 */         return null;
/*      */       }
/*      */       
/* 2354 */       if ((parameterVal[0] == 39) && (parameterVal[(parameterVal.length - 1)] == 39)) {
/* 2355 */         byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2356 */         System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */         
/* 2358 */         return valNoQuotes;
/*      */       }
/*      */       
/* 2361 */       return parameterVal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String getDateTimePattern(String dt, boolean toTime)
/*      */     throws Exception
/*      */   {
/* 2371 */     int dtLength = dt != null ? dt.length() : 0;
/*      */     
/* 2373 */     if ((dtLength >= 8) && (dtLength <= 10)) {
/* 2374 */       int dashCount = 0;
/* 2375 */       boolean isDateOnly = true;
/*      */       
/* 2377 */       for (int i = 0; i < dtLength; i++) {
/* 2378 */         char c = dt.charAt(i);
/*      */         
/* 2380 */         if ((!Character.isDigit(c)) && (c != '-')) {
/* 2381 */           isDateOnly = false;
/*      */           
/* 2383 */           break;
/*      */         }
/*      */         
/* 2386 */         if (c == '-') {
/* 2387 */           dashCount++;
/*      */         }
/*      */       }
/*      */       
/* 2391 */       if ((isDateOnly) && (dashCount == 2)) {
/* 2392 */         return "yyyy-MM-dd";
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2399 */     boolean colonsOnly = true;
/*      */     
/* 2401 */     for (int i = 0; i < dtLength; i++) {
/* 2402 */       char c = dt.charAt(i);
/*      */       
/* 2404 */       if ((!Character.isDigit(c)) && (c != ':')) {
/* 2405 */         colonsOnly = false;
/*      */         
/* 2407 */         break;
/*      */       }
/*      */     }
/*      */     
/* 2411 */     if (colonsOnly) {
/* 2412 */       return "HH:mm:ss";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2421 */     StringReader reader = new StringReader(dt + " ");
/* 2422 */     ArrayList<Object[]> vec = new ArrayList();
/* 2423 */     ArrayList<Object[]> vecRemovelist = new ArrayList();
/* 2424 */     Object[] nv = new Object[3];
/*      */     
/* 2426 */     nv[0] = Character.valueOf('y');
/* 2427 */     nv[1] = new StringBuilder();
/* 2428 */     nv[2] = Integer.valueOf(0);
/* 2429 */     vec.add(nv);
/*      */     
/* 2431 */     if (toTime) {
/* 2432 */       nv = new Object[3];
/* 2433 */       nv[0] = Character.valueOf('h');
/* 2434 */       nv[1] = new StringBuilder();
/* 2435 */       nv[2] = Integer.valueOf(0);
/* 2436 */       vec.add(nv);
/*      */     }
/*      */     int z;
/* 2439 */     while ((z = reader.read()) != -1) {
/* 2440 */       char separator = (char)z;
/* 2441 */       int maxvecs = vec.size();
/*      */       
/* 2443 */       for (int count = 0; count < maxvecs; count++) {
/* 2444 */         Object[] v = (Object[])vec.get(count);
/* 2445 */         int n = ((Integer)v[2]).intValue();
/* 2446 */         char c = getSuccessor(((Character)v[0]).charValue(), n);
/*      */         
/* 2448 */         if (!Character.isLetterOrDigit(separator)) {
/* 2449 */           if ((c == ((Character)v[0]).charValue()) && (c != 'S')) {
/* 2450 */             vecRemovelist.add(v);
/*      */           } else {
/* 2452 */             ((StringBuilder)v[1]).append(separator);
/*      */             
/* 2454 */             if ((c == 'X') || (c == 'Y')) {
/* 2455 */               v[2] = Integer.valueOf(4);
/*      */             }
/*      */           }
/*      */         } else {
/* 2459 */           if (c == 'X') {
/* 2460 */             c = 'y';
/* 2461 */             nv = new Object[3];
/* 2462 */             nv[1] = new StringBuilder(((StringBuilder)v[1]).toString()).append('M');
/* 2463 */             nv[0] = Character.valueOf('M');
/* 2464 */             nv[2] = Integer.valueOf(1);
/* 2465 */             vec.add(nv);
/* 2466 */           } else if (c == 'Y') {
/* 2467 */             c = 'M';
/* 2468 */             nv = new Object[3];
/* 2469 */             nv[1] = new StringBuilder(((StringBuilder)v[1]).toString()).append('d');
/* 2470 */             nv[0] = Character.valueOf('d');
/* 2471 */             nv[2] = Integer.valueOf(1);
/* 2472 */             vec.add(nv);
/*      */           }
/*      */           
/* 2475 */           ((StringBuilder)v[1]).append(c);
/*      */           
/* 2477 */           if (c == ((Character)v[0]).charValue()) {
/* 2478 */             v[2] = Integer.valueOf(n + 1);
/*      */           } else {
/* 2480 */             v[0] = Character.valueOf(c);
/* 2481 */             v[2] = Integer.valueOf(1);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2486 */       int size = vecRemovelist.size();
/*      */       
/* 2488 */       for (int i = 0; i < size; i++) {
/* 2489 */         Object[] v = (Object[])vecRemovelist.get(i);
/* 2490 */         vec.remove(v);
/*      */       }
/*      */       
/* 2493 */       vecRemovelist.clear();
/*      */     }
/*      */     
/* 2496 */     int size = vec.size();
/*      */     
/* 2498 */     for (int i = 0; i < size; i++) {
/* 2499 */       Object[] v = (Object[])vec.get(i);
/* 2500 */       char c = ((Character)v[0]).charValue();
/* 2501 */       int n = ((Integer)v[2]).intValue();
/*      */       
/* 2503 */       boolean bk = getSuccessor(c, n) != c;
/* 2504 */       boolean atEnd = ((c == 's') || (c == 'm') || ((c == 'h') && (toTime))) && (bk);
/* 2505 */       boolean finishesAtDate = (bk) && (c == 'd') && (!toTime);
/* 2506 */       boolean containsEnd = ((StringBuilder)v[1]).toString().indexOf('W') != -1;
/*      */       
/* 2508 */       if (((!atEnd) && (!finishesAtDate)) || (containsEnd)) {
/* 2509 */         vecRemovelist.add(v);
/*      */       }
/*      */     }
/*      */     
/* 2513 */     size = vecRemovelist.size();
/*      */     
/* 2515 */     for (int i = 0; i < size; i++) {
/* 2516 */       vec.remove(vecRemovelist.get(i));
/*      */     }
/*      */     
/* 2519 */     vecRemovelist.clear();
/* 2520 */     Object[] v = (Object[])vec.get(0);
/*      */     
/* 2522 */     StringBuilder format = (StringBuilder)v[1];
/* 2523 */     format.setLength(format.length() - 1);
/*      */     
/* 2525 */     return format.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 2539 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2547 */       if (!isSelectQuery()) {
/* 2548 */         return null;
/*      */       }
/*      */       
/* 2551 */       PreparedStatement mdStmt = null;
/* 2552 */       ResultSet mdRs = null;
/*      */       
/* 2554 */       if (this.pstmtResultMetaData == null) {
/*      */         try {
/* 2556 */           mdStmt = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog, this.parseInfo);
/*      */           
/* 2558 */           mdStmt.setMaxRows(1);
/*      */           
/* 2560 */           int paramCount = this.parameterValues.length;
/*      */           
/* 2562 */           for (int i = 1; i <= paramCount; i++) {
/* 2563 */             mdStmt.setString(i, "");
/*      */           }
/*      */           
/* 2566 */           boolean hadResults = mdStmt.execute();
/*      */           
/* 2568 */           if (hadResults) {
/* 2569 */             mdRs = mdStmt.getResultSet();
/*      */             
/* 2571 */             this.pstmtResultMetaData = mdRs.getMetaData();
/*      */           } else {
/* 2573 */             this.pstmtResultMetaData = new ResultSetMetaData(new Field[0], this.connection.getUseOldAliasMetadataBehavior(), this.connection.getYearIsDateType(), getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */         finally {
/* 2577 */           SQLException sqlExRethrow = null;
/*      */           
/* 2579 */           if (mdRs != null) {
/*      */             try {
/* 2581 */               mdRs.close();
/*      */             } catch (SQLException sqlEx) {
/* 2583 */               sqlExRethrow = sqlEx;
/*      */             }
/*      */             
/* 2586 */             mdRs = null;
/*      */           }
/*      */           
/* 2589 */           if (mdStmt != null) {
/*      */             try {
/* 2591 */               mdStmt.close();
/*      */             } catch (SQLException sqlEx) {
/* 2593 */               sqlExRethrow = sqlEx;
/*      */             }
/*      */             
/* 2596 */             mdStmt = null;
/*      */           }
/*      */           
/* 2599 */           if (sqlExRethrow != null) {
/* 2600 */             throw sqlExRethrow;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2605 */       return this.pstmtResultMetaData;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/* 2619 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2620 */       if (this.parameterMetaData == null) {
/* 2621 */         if (this.connection.getGenerateSimpleParameterMetadata()) {
/* 2622 */           this.parameterMetaData = new MysqlParameterMetadata(this.parameterCount);
/*      */         } else {
/* 2624 */           this.parameterMetaData = new MysqlParameterMetadata(null, this.parameterCount, getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/* 2628 */       return this.parameterMetaData;
/*      */     }
/*      */   }
/*      */   
/*      */   ParseInfo getParseInfo() {
/* 2633 */     return this.parseInfo;
/*      */   }
/*      */   
/*      */   private final char getSuccessor(char c, int n) {
/* 2637 */     return (c == 's') && (n < 2) ? 's' : c == 'm' ? 's' : (c == 'm') && (n < 2) ? 'm' : c == 'H' ? 'm' : (c == 'H') && (n < 2) ? 'H' : c == 'd' ? 'H' : (c == 'd') && (n < 2) ? 'd' : c == 'M' ? 'd' : (c == 'M') && (n < 3) ? 'M' : (c == 'M') && (n == 2) ? 'Y' : c == 'y' ? 'M' : (c == 'y') && (n < 4) ? 'y' : (c == 'y') && (n == 2) ? 'X' : 'W';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void hexEscapeBlock(byte[] buf, Buffer packet, int size)
/*      */     throws SQLException
/*      */   {
/* 2651 */     for (int i = 0; i < size; i++) {
/* 2652 */       byte b = buf[i];
/* 2653 */       int lowBits = (b & 0xFF) / 16;
/* 2654 */       int highBits = (b & 0xFF) % 16;
/*      */       
/* 2656 */       packet.writeByte(HEX_DIGITS[lowBits]);
/* 2657 */       packet.writeByte(HEX_DIGITS[highBits]);
/*      */     }
/*      */   }
/*      */   
/*      */   private void initializeFromParseInfo() throws SQLException {
/* 2662 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2663 */       this.staticSqlStrings = this.parseInfo.staticSql;
/* 2664 */       this.isLoadDataQuery = this.parseInfo.foundLoadData;
/* 2665 */       this.firstCharOfStmt = this.parseInfo.firstStmtChar;
/*      */       
/* 2667 */       this.parameterCount = (this.staticSqlStrings.length - 1);
/*      */       
/* 2669 */       this.parameterValues = new byte[this.parameterCount][];
/* 2670 */       this.parameterStreams = new InputStream[this.parameterCount];
/* 2671 */       this.isStream = new boolean[this.parameterCount];
/* 2672 */       this.streamLengths = new int[this.parameterCount];
/* 2673 */       this.isNull = new boolean[this.parameterCount];
/* 2674 */       this.parameterTypes = new int[this.parameterCount];
/*      */       
/* 2676 */       clearParameters();
/*      */       
/* 2678 */       for (int j = 0; j < this.parameterCount; j++) {
/* 2679 */         this.isStream[j] = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int readblock(InputStream i, byte[] b)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2692 */       return i.read(b);
/*      */     } catch (Throwable ex) {
/* 2694 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 2696 */       sqlEx.initCause(ex);
/*      */       
/* 2698 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private final int readblock(InputStream i, byte[] b, int length) throws SQLException {
/*      */     try {
/* 2704 */       int lengthToRead = length;
/*      */       
/* 2706 */       if (lengthToRead > b.length) {
/* 2707 */         lengthToRead = b.length;
/*      */       }
/*      */       
/* 2710 */       return i.read(b, 0, lengthToRead);
/*      */     } catch (Throwable ex) {
/* 2712 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 2714 */       sqlEx.initCause(ex);
/*      */       
/* 2716 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/* 2731 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 2733 */     if (locallyScopedConn == null) {
/* 2734 */       return;
/*      */     }
/*      */     
/* 2737 */     synchronized (locallyScopedConn.getConnectionMutex())
/*      */     {
/*      */ 
/*      */ 
/* 2741 */       if (this.isClosed) {
/* 2742 */         return;
/*      */       }
/*      */       
/* 2745 */       if ((this.useUsageAdvisor) && 
/* 2746 */         (this.numberOfExecutions <= 1)) {
/* 2747 */         String message = Messages.getString("PreparedStatement.43");
/*      */         
/* 2749 */         this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2754 */       super.realClose(calledExplicitly, closeOpenResults);
/*      */       
/* 2756 */       this.dbmd = null;
/* 2757 */       this.originalSql = null;
/* 2758 */       this.staticSqlStrings = ((byte[][])null);
/* 2759 */       this.parameterValues = ((byte[][])null);
/* 2760 */       this.parameterStreams = null;
/* 2761 */       this.isStream = null;
/* 2762 */       this.streamLengths = null;
/* 2763 */       this.isNull = null;
/* 2764 */       this.streamConvertBuf = null;
/* 2765 */       this.parameterTypes = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/* 2782 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2807 */     if (x == null) {
/* 2808 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 2810 */       setBinaryStream(parameterIndex, x, length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 2827 */     if (x == null) {
/* 2828 */       setNull(parameterIndex, 3);
/*      */     } else {
/* 2830 */       setInternal(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString(x)));
/*      */       
/* 2832 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 3;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2856 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2857 */       if (x == null) {
/* 2858 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 2860 */         int parameterIndexOffset = getParameterIndexOffset();
/*      */         
/* 2862 */         if ((parameterIndex < 1) || (parameterIndex > this.staticSqlStrings.length)) {
/* 2863 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.2") + parameterIndex + Messages.getString("PreparedStatement.3") + this.staticSqlStrings.length + Messages.getString("PreparedStatement.4"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/* 2866 */         if ((parameterIndexOffset == -1) && (parameterIndex == 1)) {
/* 2867 */           throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/* 2871 */         this.parameterStreams[(parameterIndex - 1 + parameterIndexOffset)] = x;
/* 2872 */         this.isStream[(parameterIndex - 1 + parameterIndexOffset)] = true;
/* 2873 */         this.streamLengths[(parameterIndex - 1 + parameterIndexOffset)] = length;
/* 2874 */         this.isNull[(parameterIndex - 1 + parameterIndexOffset)] = false;
/* 2875 */         this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2004;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
/* 2881 */     setBinaryStream(parameterIndex, inputStream, (int)length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(int i, Blob x)
/*      */     throws SQLException
/*      */   {
/* 2896 */     if (x == null) {
/* 2897 */       setNull(i, 2004);
/*      */     } else {
/* 2899 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */       
/* 2901 */       bytesOut.write(39);
/* 2902 */       escapeblockFast(x.getBytes(1L, (int)x.length()), bytesOut, (int)x.length());
/* 2903 */       bytesOut.write(39);
/*      */       
/* 2905 */       setInternal(i, bytesOut.toByteArray());
/*      */       
/* 2907 */       this.parameterTypes[(i - 1 + getParameterIndexOffset())] = 2004;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 2924 */     if (this.useTrueBoolean) {
/* 2925 */       setInternal(parameterIndex, x ? "1" : "0");
/*      */     } else {
/* 2927 */       setInternal(parameterIndex, x ? "'t'" : "'f'");
/*      */       
/* 2929 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 16;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 2946 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 2948 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -6;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 2965 */     setBytes(parameterIndex, x, true, true);
/*      */     
/* 2967 */     if (x != null) {
/* 2968 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -2;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setBytes(int parameterIndex, byte[] x, boolean checkForIntroducer, boolean escapeForMBChars) throws SQLException {
/* 2973 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2974 */       if (x == null) {
/* 2975 */         setNull(parameterIndex, -2);
/*      */       } else {
/* 2977 */         String connectionEncoding = this.connection.getEncoding();
/*      */         try
/*      */         {
/* 2980 */           if ((this.connection.isNoBackslashEscapesSet()) || ((escapeForMBChars) && (this.connection.getUseUnicode()) && (connectionEncoding != null) && (CharsetMapping.isMultibyteCharset(connectionEncoding))))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2986 */             ByteArrayOutputStream bOut = new ByteArrayOutputStream(x.length * 2 + 3);
/* 2987 */             bOut.write(120);
/* 2988 */             bOut.write(39);
/*      */             
/* 2990 */             for (int i = 0; i < x.length; i++) {
/* 2991 */               int lowBits = (x[i] & 0xFF) / 16;
/* 2992 */               int highBits = (x[i] & 0xFF) % 16;
/*      */               
/* 2994 */               bOut.write(HEX_DIGITS[lowBits]);
/* 2995 */               bOut.write(HEX_DIGITS[highBits]);
/*      */             }
/*      */             
/* 2998 */             bOut.write(39);
/*      */             
/* 3000 */             setInternal(parameterIndex, bOut.toByteArray());
/*      */             
/* 3002 */             return;
/*      */           }
/*      */         } catch (SQLException ex) {
/* 3005 */           throw ex;
/*      */         } catch (RuntimeException ex) {
/* 3007 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 3008 */           sqlEx.initCause(ex);
/* 3009 */           throw sqlEx;
/*      */         }
/*      */         
/*      */ 
/* 3013 */         int numBytes = x.length;
/*      */         
/* 3015 */         int pad = 2;
/*      */         
/* 3017 */         boolean needsIntroducer = (checkForIntroducer) && (this.connection.versionMeetsMinimum(4, 1, 0));
/*      */         
/* 3019 */         if (needsIntroducer) {
/* 3020 */           pad += 7;
/*      */         }
/*      */         
/* 3023 */         ByteArrayOutputStream bOut = new ByteArrayOutputStream(numBytes + pad);
/*      */         
/* 3025 */         if (needsIntroducer) {
/* 3026 */           bOut.write(95);
/* 3027 */           bOut.write(98);
/* 3028 */           bOut.write(105);
/* 3029 */           bOut.write(110);
/* 3030 */           bOut.write(97);
/* 3031 */           bOut.write(114);
/* 3032 */           bOut.write(121);
/*      */         }
/* 3034 */         bOut.write(39);
/*      */         
/* 3036 */         for (int i = 0; i < numBytes; i++) {
/* 3037 */           byte b = x[i];
/*      */           
/* 3039 */           switch (b) {
/*      */           case 0: 
/* 3041 */             bOut.write(92);
/* 3042 */             bOut.write(48);
/*      */             
/* 3044 */             break;
/*      */           
/*      */           case 10: 
/* 3047 */             bOut.write(92);
/* 3048 */             bOut.write(110);
/*      */             
/* 3050 */             break;
/*      */           
/*      */           case 13: 
/* 3053 */             bOut.write(92);
/* 3054 */             bOut.write(114);
/*      */             
/* 3056 */             break;
/*      */           
/*      */           case 92: 
/* 3059 */             bOut.write(92);
/* 3060 */             bOut.write(92);
/*      */             
/* 3062 */             break;
/*      */           
/*      */           case 39: 
/* 3065 */             bOut.write(92);
/* 3066 */             bOut.write(39);
/*      */             
/* 3068 */             break;
/*      */           
/*      */           case 34: 
/* 3071 */             bOut.write(92);
/* 3072 */             bOut.write(34);
/*      */             
/* 3074 */             break;
/*      */           
/*      */           case 26: 
/* 3077 */             bOut.write(92);
/* 3078 */             bOut.write(90);
/*      */             
/* 3080 */             break;
/*      */           
/*      */           default: 
/* 3083 */             bOut.write(b);
/*      */           }
/*      */           
/*      */         }
/* 3087 */         bOut.write(39);
/*      */         
/* 3089 */         setInternal(parameterIndex, bOut.toByteArray());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setBytesNoEscape(int parameterIndex, byte[] parameterAsBytes)
/*      */     throws SQLException
/*      */   {
/* 3107 */     byte[] parameterWithQuotes = new byte[parameterAsBytes.length + 2];
/* 3108 */     parameterWithQuotes[0] = 39;
/* 3109 */     System.arraycopy(parameterAsBytes, 0, parameterWithQuotes, 1, parameterAsBytes.length);
/* 3110 */     parameterWithQuotes[(parameterAsBytes.length + 1)] = 39;
/*      */     
/* 3112 */     setInternal(parameterIndex, parameterWithQuotes);
/*      */   }
/*      */   
/*      */   protected void setBytesNoEscapeNoQuotes(int parameterIndex, byte[] parameterAsBytes) throws SQLException {
/* 3116 */     setInternal(parameterIndex, parameterAsBytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 3141 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 3143 */         if (reader == null) {
/* 3144 */           setNull(parameterIndex, -1);
/*      */         } else {
/* 3146 */           char[] c = null;
/* 3147 */           int len = 0;
/*      */           
/* 3149 */           boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */           
/* 3151 */           String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */           
/* 3153 */           if ((useLength) && (length != -1)) {
/* 3154 */             c = new char[length];
/*      */             
/* 3156 */             int numCharsRead = readFully(reader, c, length);
/*      */             
/* 3158 */             if (forcedEncoding == null) {
/* 3159 */               setString(parameterIndex, new String(c, 0, numCharsRead));
/*      */             } else {
/*      */               try {
/* 3162 */                 setBytes(parameterIndex, StringUtils.getBytes(new String(c, 0, numCharsRead), forcedEncoding));
/*      */               } catch (UnsupportedEncodingException uee) {
/* 3164 */                 throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/* 3169 */             c = new char['က'];
/*      */             
/* 3171 */             StringBuilder buf = new StringBuilder();
/*      */             
/* 3173 */             while ((len = reader.read(c)) != -1) {
/* 3174 */               buf.append(c, 0, len);
/*      */             }
/*      */             
/* 3177 */             if (forcedEncoding == null) {
/* 3178 */               setString(parameterIndex, buf.toString());
/*      */             } else {
/*      */               try {
/* 3181 */                 setBytes(parameterIndex, StringUtils.getBytes(buf.toString(), forcedEncoding));
/*      */               } catch (UnsupportedEncodingException uee) {
/* 3183 */                 throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 3189 */           this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2005;
/*      */         }
/*      */       } catch (IOException ioEx) {
/* 3192 */         throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClob(int i, Clob x)
/*      */     throws SQLException
/*      */   {
/* 3209 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3210 */       if (x == null) {
/* 3211 */         setNull(i, 2005);
/*      */       }
/*      */       else {
/* 3214 */         String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */         
/* 3216 */         if (forcedEncoding == null) {
/* 3217 */           setString(i, x.getSubString(1L, (int)x.length()));
/*      */         } else {
/*      */           try {
/* 3220 */             setBytes(i, StringUtils.getBytes(x.getSubString(1L, (int)x.length()), forcedEncoding));
/*      */           } catch (UnsupportedEncodingException uee) {
/* 3222 */             throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 3227 */         this.parameterTypes[(i - 1 + getParameterIndexOffset())] = 2005;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x)
/*      */     throws SQLException
/*      */   {
/* 3245 */     setDate(parameterIndex, x, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 3263 */     if (x == null) {
/* 3264 */       setNull(parameterIndex, 91);
/*      */     }
/* 3266 */     else if (!this.useLegacyDatetimeCode) {
/* 3267 */       newSetDateInternal(parameterIndex, x, cal);
/*      */     } else {
/* 3269 */       synchronized (checkClosed().getConnectionMutex()) {
/* 3270 */         if (this.ddf == null) {
/* 3271 */           this.ddf = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
/*      */         }
/* 3273 */         if (cal != null) {
/* 3274 */           this.ddf.setTimeZone(cal.getTimeZone());
/*      */         }
/*      */         
/* 3277 */         setInternal(parameterIndex, this.ddf.format(x));
/*      */         
/* 3279 */         this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 91;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 3298 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3299 */       if ((!this.connection.getAllowNanAndInf()) && ((x == Double.POSITIVE_INFINITY) || (x == Double.NEGATIVE_INFINITY) || (Double.isNaN(x)))) {
/* 3300 */         throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3305 */       setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */       
/* 3307 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 8;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 3324 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */     
/* 3326 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 6;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 3342 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3344 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 4;
/*      */   }
/*      */   
/*      */   protected final void setInternal(int paramIndex, byte[] val) throws SQLException {
/* 3348 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 3350 */       int parameterIndexOffset = getParameterIndexOffset();
/*      */       
/* 3352 */       checkBounds(paramIndex, parameterIndexOffset);
/*      */       
/* 3354 */       this.isStream[(paramIndex - 1 + parameterIndexOffset)] = false;
/* 3355 */       this.isNull[(paramIndex - 1 + parameterIndexOffset)] = false;
/* 3356 */       this.parameterStreams[(paramIndex - 1 + parameterIndexOffset)] = null;
/* 3357 */       this.parameterValues[(paramIndex - 1 + parameterIndexOffset)] = val;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void checkBounds(int paramIndex, int parameterIndexOffset) throws SQLException {
/* 3362 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3363 */       if (paramIndex < 1) {
/* 3364 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009", getExceptionInterceptor());
/*      */       }
/* 3366 */       if (paramIndex > this.parameterCount) {
/* 3367 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + this.parameterValues.length + Messages.getString("PreparedStatement.53"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 3370 */       if ((parameterIndexOffset == -1) && (paramIndex == 1)) {
/* 3371 */         throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void setInternal(int paramIndex, String val) throws SQLException
/*      */   {
/* 3378 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 3380 */       byte[] parameterAsBytes = null;
/*      */       
/* 3382 */       if (this.charConverter != null) {
/* 3383 */         parameterAsBytes = this.charConverter.toBytes(val);
/*      */       } else {
/* 3385 */         parameterAsBytes = StringUtils.getBytes(val, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 3389 */       setInternal(paramIndex, parameterAsBytes);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 3406 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3408 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -5;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 3427 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3428 */       setInternal(parameterIndex, "null");
/* 3429 */       this.isNull[(parameterIndex - 1 + getParameterIndexOffset())] = true;
/*      */       
/* 3431 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType, String arg)
/*      */     throws SQLException
/*      */   {
/* 3453 */     setNull(parameterIndex, sqlType);
/*      */     
/* 3455 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 0;
/*      */   }
/*      */   
/*      */   private void setNumericObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale) throws SQLException {
/*      */     Number parameterAsNum;
/*      */     Number parameterAsNum;
/* 3461 */     if ((parameterObj instanceof Boolean)) {
/* 3462 */       parameterAsNum = ((Boolean)parameterObj).booleanValue() ? Integer.valueOf(1) : Integer.valueOf(0);
/* 3463 */     } else if ((parameterObj instanceof String)) { Number parameterAsNum;
/* 3464 */       switch (targetSqlType) {
/*      */       case -7:  Number parameterAsNum;
/* 3466 */         if (("1".equals(parameterObj)) || ("0".equals(parameterObj))) {
/* 3467 */           parameterAsNum = Integer.valueOf((String)parameterObj);
/*      */         } else {
/* 3469 */           boolean parameterAsBoolean = "true".equalsIgnoreCase((String)parameterObj);
/*      */           
/* 3471 */           parameterAsNum = parameterAsBoolean ? Integer.valueOf(1) : Integer.valueOf(0);
/*      */         }
/*      */         
/* 3474 */         break;
/*      */       
/*      */       case -6: 
/*      */       case 4: 
/*      */       case 5: 
/* 3479 */         parameterAsNum = Integer.valueOf((String)parameterObj);
/*      */         
/* 3481 */         break;
/*      */       
/*      */       case -5: 
/* 3484 */         parameterAsNum = Long.valueOf((String)parameterObj);
/*      */         
/* 3486 */         break;
/*      */       
/*      */       case 7: 
/* 3489 */         parameterAsNum = Float.valueOf((String)parameterObj);
/*      */         
/* 3491 */         break;
/*      */       
/*      */       case 6: 
/*      */       case 8: 
/* 3495 */         parameterAsNum = Double.valueOf((String)parameterObj);
/*      */         
/* 3497 */         break;
/*      */       case -4: case -3: case -2: 
/*      */       case -1: case 0: 
/*      */       case 1: case 2: 
/*      */       case 3: default: 
/* 3502 */         parameterAsNum = new BigDecimal((String)parameterObj);break;
/*      */       }
/*      */     } else {
/* 3505 */       parameterAsNum = (Number)parameterObj;
/*      */     }
/*      */     
/* 3508 */     switch (targetSqlType) {
/*      */     case -7: 
/*      */     case -6: 
/*      */     case 4: 
/*      */     case 5: 
/* 3513 */       setInt(parameterIndex, parameterAsNum.intValue());
/*      */       
/* 3515 */       break;
/*      */     
/*      */     case -5: 
/* 3518 */       setLong(parameterIndex, parameterAsNum.longValue());
/*      */       
/* 3520 */       break;
/*      */     
/*      */     case 7: 
/* 3523 */       setFloat(parameterIndex, parameterAsNum.floatValue());
/*      */       
/* 3525 */       break;
/*      */     
/*      */     case 6: 
/*      */     case 8: 
/* 3529 */       setDouble(parameterIndex, parameterAsNum.doubleValue());
/*      */       
/* 3531 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 3: 
/* 3536 */       if ((parameterAsNum instanceof BigDecimal)) {
/* 3537 */         BigDecimal scaledBigDecimal = null;
/*      */         try
/*      */         {
/* 3540 */           scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale);
/*      */         } catch (ArithmeticException ex) {
/*      */           try {
/* 3543 */             scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale, 4);
/*      */           } catch (ArithmeticException arEx) {
/* 3545 */             throw SQLError.createSQLException("Can't set scale of '" + scale + "' for DECIMAL argument '" + parameterAsNum + "'", "S1009", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 3550 */         setBigDecimal(parameterIndex, scaledBigDecimal);
/* 3551 */       } else if ((parameterAsNum instanceof BigInteger)) {
/* 3552 */         setBigDecimal(parameterIndex, new BigDecimal((BigInteger)parameterAsNum, scale));
/*      */       } else {
/* 3554 */         setBigDecimal(parameterIndex, new BigDecimal(parameterAsNum.doubleValue()));
/*      */       }
/*      */       break;
/*      */     }
/*      */   }
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj) throws SQLException
/*      */   {
/* 3562 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3563 */       if (parameterObj == null) {
/* 3564 */         setNull(parameterIndex, 1111);
/*      */       }
/* 3566 */       else if ((parameterObj instanceof Byte)) {
/* 3567 */         setInt(parameterIndex, ((Byte)parameterObj).intValue());
/* 3568 */       } else if ((parameterObj instanceof String)) {
/* 3569 */         setString(parameterIndex, (String)parameterObj);
/* 3570 */       } else if ((parameterObj instanceof BigDecimal)) {
/* 3571 */         setBigDecimal(parameterIndex, (BigDecimal)parameterObj);
/* 3572 */       } else if ((parameterObj instanceof Short)) {
/* 3573 */         setShort(parameterIndex, ((Short)parameterObj).shortValue());
/* 3574 */       } else if ((parameterObj instanceof Integer)) {
/* 3575 */         setInt(parameterIndex, ((Integer)parameterObj).intValue());
/* 3576 */       } else if ((parameterObj instanceof Long)) {
/* 3577 */         setLong(parameterIndex, ((Long)parameterObj).longValue());
/* 3578 */       } else if ((parameterObj instanceof Float)) {
/* 3579 */         setFloat(parameterIndex, ((Float)parameterObj).floatValue());
/* 3580 */       } else if ((parameterObj instanceof Double)) {
/* 3581 */         setDouble(parameterIndex, ((Double)parameterObj).doubleValue());
/* 3582 */       } else if ((parameterObj instanceof byte[])) {
/* 3583 */         setBytes(parameterIndex, (byte[])parameterObj);
/* 3584 */       } else if ((parameterObj instanceof java.sql.Date)) {
/* 3585 */         setDate(parameterIndex, (java.sql.Date)parameterObj);
/* 3586 */       } else if ((parameterObj instanceof Time)) {
/* 3587 */         setTime(parameterIndex, (Time)parameterObj);
/* 3588 */       } else if ((parameterObj instanceof Timestamp)) {
/* 3589 */         setTimestamp(parameterIndex, (Timestamp)parameterObj);
/* 3590 */       } else if ((parameterObj instanceof Boolean)) {
/* 3591 */         setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/* 3592 */       } else if ((parameterObj instanceof InputStream)) {
/* 3593 */         setBinaryStream(parameterIndex, (InputStream)parameterObj, -1);
/* 3594 */       } else if ((parameterObj instanceof Blob)) {
/* 3595 */         setBlob(parameterIndex, (Blob)parameterObj);
/* 3596 */       } else if ((parameterObj instanceof Clob)) {
/* 3597 */         setClob(parameterIndex, (Clob)parameterObj);
/* 3598 */       } else if ((this.connection.getTreatUtilDateAsTimestamp()) && ((parameterObj instanceof java.util.Date))) {
/* 3599 */         setTimestamp(parameterIndex, new Timestamp(((java.util.Date)parameterObj).getTime()));
/* 3600 */       } else if ((parameterObj instanceof BigInteger)) {
/* 3601 */         setString(parameterIndex, parameterObj.toString());
/*      */       } else {
/* 3603 */         setSerializableObject(parameterIndex, parameterObj);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/* 3617 */     if (!(parameterObj instanceof BigDecimal)) {
/* 3618 */       setObject(parameterIndex, parameterObj, targetSqlType, 0);
/*      */     } else {
/* 3620 */       setObject(parameterIndex, parameterObj, targetSqlType, ((BigDecimal)parameterObj).scale());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 3652 */     synchronized (checkClosed().getConnectionMutex()) {
/* 3653 */       if (parameterObj == null) {
/* 3654 */         setNull(parameterIndex, 1111);
/*      */       } else {
/*      */         try {
/* 3657 */           switch (targetSqlType)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           case 16: 
/* 3677 */             if ((parameterObj instanceof Boolean)) {
/* 3678 */               setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */ 
/*      */             }
/* 3681 */             else if ((parameterObj instanceof String)) {
/* 3682 */               setBoolean(parameterIndex, ("true".equalsIgnoreCase((String)parameterObj)) || (!"0".equalsIgnoreCase((String)parameterObj)));
/*      */ 
/*      */             }
/* 3685 */             else if ((parameterObj instanceof Number)) {
/* 3686 */               int intValue = ((Number)parameterObj).intValue();
/*      */               
/* 3688 */               setBoolean(parameterIndex, intValue != 0);
/*      */             }
/*      */             else
/*      */             {
/* 3692 */               throw SQLError.createSQLException("No conversion from " + parameterObj.getClass().getName() + " to Types.BOOLEAN possible.", "S1009", getExceptionInterceptor());
/*      */             }
/*      */             
/*      */ 
/*      */             break;
/*      */           case -7: 
/*      */           case -6: 
/*      */           case -5: 
/*      */           case 2: 
/*      */           case 3: 
/*      */           case 4: 
/*      */           case 5: 
/*      */           case 6: 
/*      */           case 7: 
/*      */           case 8: 
/* 3707 */             setNumericObject(parameterIndex, parameterObj, targetSqlType, scale);
/*      */             
/* 3709 */             break;
/*      */           
/*      */           case -1: 
/*      */           case 1: 
/*      */           case 12: 
/* 3714 */             if ((parameterObj instanceof BigDecimal)) {
/* 3715 */               setString(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString((BigDecimal)parameterObj)));
/*      */             } else {
/* 3717 */               setString(parameterIndex, parameterObj.toString());
/*      */             }
/*      */             
/* 3720 */             break;
/*      */           
/*      */ 
/*      */           case 2005: 
/* 3724 */             if ((parameterObj instanceof Clob)) {
/* 3725 */               setClob(parameterIndex, (Clob)parameterObj);
/*      */             } else {
/* 3727 */               setString(parameterIndex, parameterObj.toString());
/*      */             }
/*      */             
/* 3730 */             break;
/*      */           
/*      */ 
/*      */           case -4: 
/*      */           case -3: 
/*      */           case -2: 
/*      */           case 2004: 
/* 3737 */             if ((parameterObj instanceof byte[])) {
/* 3738 */               setBytes(parameterIndex, (byte[])parameterObj);
/* 3739 */             } else if ((parameterObj instanceof Blob)) {
/* 3740 */               setBlob(parameterIndex, (Blob)parameterObj);
/*      */             } else {
/* 3742 */               setBytes(parameterIndex, StringUtils.getBytes(parameterObj.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */             }
/*      */             
/*      */ 
/* 3746 */             break;
/*      */           case 91: 
/*      */           case 93: 
/*      */             java.util.Date parameterAsDate;
/*      */             
/*      */             java.util.Date parameterAsDate;
/*      */             
/* 3753 */             if ((parameterObj instanceof String)) {
/* 3754 */               ParsePosition pp = new ParsePosition(0);
/* 3755 */               DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, false), Locale.US);
/* 3756 */               parameterAsDate = sdf.parse((String)parameterObj, pp);
/*      */             } else {
/* 3758 */               parameterAsDate = (java.util.Date)parameterObj;
/*      */             }
/*      */             
/* 3761 */             switch (targetSqlType)
/*      */             {
/*      */             case 91: 
/* 3764 */               if ((parameterAsDate instanceof java.sql.Date)) {
/* 3765 */                 setDate(parameterIndex, (java.sql.Date)parameterAsDate);
/*      */               } else {
/* 3767 */                 setDate(parameterIndex, new java.sql.Date(parameterAsDate.getTime()));
/*      */               }
/*      */               
/* 3770 */               break;
/*      */             
/*      */ 
/*      */             case 93: 
/* 3774 */               if ((parameterAsDate instanceof Timestamp)) {
/* 3775 */                 setTimestamp(parameterIndex, (Timestamp)parameterAsDate);
/*      */               } else {
/* 3777 */                 setTimestamp(parameterIndex, new Timestamp(parameterAsDate.getTime()));
/*      */               }
/*      */               
/*      */               break;
/*      */             }
/*      */             
/* 3783 */             break;
/*      */           
/*      */ 
/*      */           case 92: 
/* 3787 */             if ((parameterObj instanceof String)) {
/* 3788 */               DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, true), Locale.US);
/* 3789 */               setTime(parameterIndex, new Time(sdf.parse((String)parameterObj).getTime()));
/* 3790 */             } else if ((parameterObj instanceof Timestamp)) {
/* 3791 */               Timestamp xT = (Timestamp)parameterObj;
/* 3792 */               setTime(parameterIndex, new Time(xT.getTime()));
/*      */             } else {
/* 3794 */               setTime(parameterIndex, (Time)parameterObj);
/*      */             }
/*      */             
/* 3797 */             break;
/*      */           
/*      */           case 1111: 
/* 3800 */             setSerializableObject(parameterIndex, parameterObj);
/*      */             
/* 3802 */             break;
/*      */           
/*      */           default: 
/* 3805 */             throw SQLError.createSQLException(Messages.getString("PreparedStatement.16"), "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */         } catch (Exception ex) {
/* 3809 */           if ((ex instanceof SQLException)) {
/* 3810 */             throw ((SQLException)ex);
/*      */           }
/*      */           
/* 3813 */           SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.17") + parameterObj.getClass().toString() + Messages.getString("PreparedStatement.18") + ex.getClass().getName() + Messages.getString("PreparedStatement.19") + ex.getMessage(), "S1000", getExceptionInterceptor());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3818 */           sqlEx.initCause(ex);
/*      */           
/* 3820 */           throw sqlEx;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected int setOneBatchedParameterSet(java.sql.PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet) throws SQLException {
/* 3827 */     BatchParams paramArg = (BatchParams)paramSet;
/*      */     
/* 3829 */     boolean[] isNullBatch = paramArg.isNull;
/* 3830 */     boolean[] isStreamBatch = paramArg.isStream;
/*      */     
/* 3832 */     for (int j = 0; j < isNullBatch.length; j++) {
/* 3833 */       if (isNullBatch[j] != 0) {
/* 3834 */         batchedStatement.setNull(batchedParamIndex++, 0);
/*      */       }
/* 3836 */       else if (isStreamBatch[j] != 0) {
/* 3837 */         batchedStatement.setBinaryStream(batchedParamIndex++, paramArg.parameterStreams[j], paramArg.streamLengths[j]);
/*      */       } else {
/* 3839 */         ((PreparedStatement)batchedStatement).setBytesNoEscapeNoQuotes(batchedParamIndex++, paramArg.parameterStrings[j]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3844 */     return batchedParamIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/* 3860 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void setSerializableObject(int parameterIndex, Object parameterObj)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3874 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/* 3875 */       ObjectOutputStream objectOut = new ObjectOutputStream(bytesOut);
/* 3876 */       objectOut.writeObject(parameterObj);
/* 3877 */       objectOut.flush();
/* 3878 */       objectOut.close();
/* 3879 */       bytesOut.flush();
/* 3880 */       bytesOut.close();
/*      */       
/* 3882 */       byte[] buf = bytesOut.toByteArray();
/* 3883 */       ByteArrayInputStream bytesIn = new ByteArrayInputStream(buf);
/* 3884 */       setBinaryStream(parameterIndex, bytesIn, buf.length);
/* 3885 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -2;
/*      */     } catch (Exception ex) {
/* 3887 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.54") + ex.getClass().getName(), "S1009", getExceptionInterceptor());
/*      */       
/* 3889 */       sqlEx.initCause(ex);
/*      */       
/* 3891 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 3908 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3910 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 5;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 3927 */     synchronized (checkClosed().getConnectionMutex())
/*      */     {
/* 3929 */       if (x == null) {
/* 3930 */         setNull(parameterIndex, 1);
/*      */       } else {
/* 3932 */         checkClosed();
/*      */         
/* 3934 */         int stringLength = x.length();
/*      */         
/* 3936 */         if (this.connection.isNoBackslashEscapesSet())
/*      */         {
/*      */ 
/* 3939 */           boolean needsHexEscape = isEscapeNeededForString(x, stringLength);
/*      */           
/* 3941 */           if (!needsHexEscape) {
/* 3942 */             byte[] parameterAsBytes = null;
/*      */             
/* 3944 */             StringBuilder quotedString = new StringBuilder(x.length() + 2);
/* 3945 */             quotedString.append('\'');
/* 3946 */             quotedString.append(x);
/* 3947 */             quotedString.append('\'');
/*      */             
/* 3949 */             if (!this.isLoadDataQuery) {
/* 3950 */               parameterAsBytes = StringUtils.getBytes(quotedString.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */             }
/*      */             else
/*      */             {
/* 3954 */               parameterAsBytes = StringUtils.getBytes(quotedString.toString());
/*      */             }
/*      */             
/* 3957 */             setInternal(parameterIndex, parameterAsBytes);
/*      */           } else {
/* 3959 */             byte[] parameterAsBytes = null;
/*      */             
/* 3961 */             if (!this.isLoadDataQuery) {
/* 3962 */               parameterAsBytes = StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */             }
/*      */             else
/*      */             {
/* 3966 */               parameterAsBytes = StringUtils.getBytes(x);
/*      */             }
/*      */             
/* 3969 */             setBytes(parameterIndex, parameterAsBytes);
/*      */           }
/*      */           
/* 3972 */           return;
/*      */         }
/*      */         
/* 3975 */         String parameterAsString = x;
/* 3976 */         boolean needsQuoted = true;
/*      */         
/* 3978 */         if ((this.isLoadDataQuery) || (isEscapeNeededForString(x, stringLength))) {
/* 3979 */           needsQuoted = false;
/*      */           
/* 3981 */           StringBuilder buf = new StringBuilder((int)(x.length() * 1.1D));
/*      */           
/* 3983 */           buf.append('\'');
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3989 */           for (int i = 0; i < stringLength; i++) {
/* 3990 */             char c = x.charAt(i);
/*      */             
/* 3992 */             switch (c) {
/*      */             case '\000': 
/* 3994 */               buf.append('\\');
/* 3995 */               buf.append('0');
/*      */               
/* 3997 */               break;
/*      */             
/*      */             case '\n': 
/* 4000 */               buf.append('\\');
/* 4001 */               buf.append('n');
/*      */               
/* 4003 */               break;
/*      */             
/*      */             case '\r': 
/* 4006 */               buf.append('\\');
/* 4007 */               buf.append('r');
/*      */               
/* 4009 */               break;
/*      */             
/*      */             case '\\': 
/* 4012 */               buf.append('\\');
/* 4013 */               buf.append('\\');
/*      */               
/* 4015 */               break;
/*      */             
/*      */             case '\'': 
/* 4018 */               buf.append('\\');
/* 4019 */               buf.append('\'');
/*      */               
/* 4021 */               break;
/*      */             
/*      */             case '"': 
/* 4024 */               if (this.usingAnsiMode) {
/* 4025 */                 buf.append('\\');
/*      */               }
/*      */               
/* 4028 */               buf.append('"');
/*      */               
/* 4030 */               break;
/*      */             
/*      */             case '\032': 
/* 4033 */               buf.append('\\');
/* 4034 */               buf.append('Z');
/*      */               
/* 4036 */               break;
/*      */             
/*      */ 
/*      */             case '¥': 
/*      */             case '₩': 
/* 4041 */               if (this.charsetEncoder != null) {
/* 4042 */                 CharBuffer cbuf = CharBuffer.allocate(1);
/* 4043 */                 ByteBuffer bbuf = ByteBuffer.allocate(1);
/* 4044 */                 cbuf.put(c);
/* 4045 */                 cbuf.position(0);
/* 4046 */                 this.charsetEncoder.encode(cbuf, bbuf, true);
/* 4047 */                 if (bbuf.get(0) == 92) {
/* 4048 */                   buf.append('\\');
/*      */                 }
/*      */               }
/*      */               break;
/*      */             }
/*      */             
/* 4054 */             buf.append(c);
/*      */           }
/*      */           
/*      */ 
/* 4058 */           buf.append('\'');
/*      */           
/* 4060 */           parameterAsString = buf.toString();
/*      */         }
/*      */         
/* 4063 */         byte[] parameterAsBytes = null;
/*      */         
/* 4065 */         if (!this.isLoadDataQuery) {
/* 4066 */           if (needsQuoted) {
/* 4067 */             parameterAsBytes = StringUtils.getBytesWrapped(parameterAsString, '\'', '\'', this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           }
/*      */           else {
/* 4070 */             parameterAsBytes = StringUtils.getBytes(parameterAsString, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/* 4075 */           parameterAsBytes = StringUtils.getBytes(parameterAsString);
/*      */         }
/*      */         
/* 4078 */         setInternal(parameterIndex, parameterAsBytes);
/*      */         
/* 4080 */         this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 12;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isEscapeNeededForString(String x, int stringLength) {
/* 4086 */     boolean needsHexEscape = false;
/*      */     
/* 4088 */     for (int i = 0; i < stringLength; i++) {
/* 4089 */       char c = x.charAt(i);
/*      */       
/* 4091 */       switch (c)
/*      */       {
/*      */       case '\000': 
/* 4094 */         needsHexEscape = true;
/* 4095 */         break;
/*      */       
/*      */       case '\n': 
/* 4098 */         needsHexEscape = true;
/*      */         
/* 4100 */         break;
/*      */       
/*      */       case '\r': 
/* 4103 */         needsHexEscape = true;
/* 4104 */         break;
/*      */       
/*      */       case '\\': 
/* 4107 */         needsHexEscape = true;
/*      */         
/* 4109 */         break;
/*      */       
/*      */       case '\'': 
/* 4112 */         needsHexEscape = true;
/*      */         
/* 4114 */         break;
/*      */       
/*      */       case '"': 
/* 4117 */         needsHexEscape = true;
/*      */         
/* 4119 */         break;
/*      */       
/*      */       case '\032': 
/* 4122 */         needsHexEscape = true;
/*      */       }
/*      */       
/*      */       
/* 4126 */       if (needsHexEscape) {
/*      */         break;
/*      */       }
/*      */     }
/* 4130 */     return needsHexEscape;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 4148 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4149 */       setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 4166 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4167 */       setTimeInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4187 */     if (x == null) {
/* 4188 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 4190 */       checkClosed();
/*      */       
/* 4192 */       if (!this.useLegacyDatetimeCode) {
/* 4193 */         newSetTimeInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4195 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 4197 */         x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         
/* 4199 */         setInternal(parameterIndex, "'" + x.toString() + "'");
/*      */       }
/*      */       
/* 4202 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 92;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 4221 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4222 */       setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 4239 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4240 */       setTimestampInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4259 */     if (x == null) {
/* 4260 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 4262 */       checkClosed();
/*      */       
/* 4264 */       if (!this.useLegacyDatetimeCode) {
/* 4265 */         newSetTimestampInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4267 */         Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */         
/*      */ 
/* 4270 */         x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         
/* 4272 */         if (this.connection.getUseSSPSCompatibleTimezoneShift()) {
/* 4273 */           doSSPSCompatibleTimezoneShift(parameterIndex, x, sessionCalendar);
/*      */         } else {
/* 4275 */           synchronized (this) {
/* 4276 */             if (this.tsdf == null) {
/* 4277 */               this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss", Locale.US);
/*      */             }
/*      */             
/* 4280 */             StringBuffer buf = new StringBuffer();
/* 4281 */             buf.append(this.tsdf.format(x));
/*      */             
/* 4283 */             if (this.serverSupportsFracSecs) {
/* 4284 */               int nanos = x.getNanos();
/*      */               
/* 4286 */               if (nanos != 0) {
/* 4287 */                 buf.append('.');
/* 4288 */                 buf.append(TimeUtil.formatNanos(nanos, this.serverSupportsFracSecs, true));
/*      */               }
/*      */             }
/*      */             
/* 4292 */             buf.append('\'');
/*      */             
/* 4294 */             setInternal(parameterIndex, buf.toString());
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4300 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 93;
/*      */     }
/*      */   }
/*      */   
/*      */   private void newSetTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar) throws SQLException {
/* 4305 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4306 */       if (this.tsdf == null) {
/* 4307 */         this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss", Locale.US);
/*      */       }
/*      */       
/* 4310 */       if (targetCalendar != null) {
/* 4311 */         this.tsdf.setTimeZone(targetCalendar.getTimeZone());
/*      */       } else {
/* 4313 */         this.tsdf.setTimeZone(this.connection.getServerTimezoneTZ());
/*      */       }
/*      */       
/* 4316 */       StringBuffer buf = new StringBuffer();
/* 4317 */       buf.append(this.tsdf.format(x));
/* 4318 */       buf.append('.');
/* 4319 */       buf.append(TimeUtil.formatNanos(x.getNanos(), this.serverSupportsFracSecs, true));
/* 4320 */       buf.append('\'');
/*      */       
/* 4322 */       setInternal(parameterIndex, buf.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   private void newSetTimeInternal(int parameterIndex, Time x, Calendar targetCalendar) throws SQLException {
/* 4327 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4328 */       if (this.tdf == null) {
/* 4329 */         this.tdf = new SimpleDateFormat("''HH:mm:ss''", Locale.US);
/*      */       }
/*      */       
/* 4332 */       if (targetCalendar != null) {
/* 4333 */         this.tdf.setTimeZone(targetCalendar.getTimeZone());
/*      */       } else {
/* 4335 */         this.tdf.setTimeZone(this.connection.getServerTimezoneTZ());
/*      */       }
/*      */       
/* 4338 */       setInternal(parameterIndex, this.tdf.format(x));
/*      */     }
/*      */   }
/*      */   
/*      */   private void newSetDateInternal(int parameterIndex, java.sql.Date x, Calendar targetCalendar) throws SQLException {
/* 4343 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4344 */       if (this.ddf == null) {
/* 4345 */         this.ddf = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
/*      */       }
/*      */       
/* 4348 */       if (targetCalendar != null) {
/* 4349 */         this.ddf.setTimeZone(targetCalendar.getTimeZone());
/* 4350 */       } else if (this.connection.getNoTimezoneConversionForDateType()) {
/* 4351 */         this.ddf.setTimeZone(this.connection.getDefaultTimeZone());
/*      */       } else {
/* 4353 */         this.ddf.setTimeZone(this.connection.getServerTimezoneTZ());
/*      */       }
/*      */       
/* 4356 */       setInternal(parameterIndex, this.ddf.format(x));
/*      */     }
/*      */   }
/*      */   
/*      */   private void doSSPSCompatibleTimezoneShift(int parameterIndex, Timestamp x, Calendar sessionCalendar) throws SQLException {
/* 4361 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4362 */       Calendar sessionCalendar2 = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */       
/*      */ 
/* 4365 */       synchronized (sessionCalendar2) {
/* 4366 */         java.util.Date oldTime = sessionCalendar2.getTime();
/*      */         try
/*      */         {
/* 4369 */           sessionCalendar2.setTime(x);
/*      */           
/* 4371 */           int year = sessionCalendar2.get(1);
/* 4372 */           int month = sessionCalendar2.get(2) + 1;
/* 4373 */           int date = sessionCalendar2.get(5);
/*      */           
/* 4375 */           int hour = sessionCalendar2.get(11);
/* 4376 */           int minute = sessionCalendar2.get(12);
/* 4377 */           int seconds = sessionCalendar2.get(13);
/*      */           
/* 4379 */           StringBuilder tsBuf = new StringBuilder();
/*      */           
/* 4381 */           tsBuf.append('\'');
/* 4382 */           tsBuf.append(year);
/*      */           
/* 4384 */           tsBuf.append("-");
/*      */           
/* 4386 */           if (month < 10) {
/* 4387 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4390 */           tsBuf.append(month);
/*      */           
/* 4392 */           tsBuf.append('-');
/*      */           
/* 4394 */           if (date < 10) {
/* 4395 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4398 */           tsBuf.append(date);
/*      */           
/* 4400 */           tsBuf.append(' ');
/*      */           
/* 4402 */           if (hour < 10) {
/* 4403 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4406 */           tsBuf.append(hour);
/*      */           
/* 4408 */           tsBuf.append(':');
/*      */           
/* 4410 */           if (minute < 10) {
/* 4411 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4414 */           tsBuf.append(minute);
/*      */           
/* 4416 */           tsBuf.append(':');
/*      */           
/* 4418 */           if (seconds < 10) {
/* 4419 */             tsBuf.append('0');
/*      */           }
/*      */           
/* 4422 */           tsBuf.append(seconds);
/*      */           
/* 4424 */           tsBuf.append('.');
/* 4425 */           tsBuf.append(TimeUtil.formatNanos(x.getNanos(), this.serverSupportsFracSecs, true));
/* 4426 */           tsBuf.append('\'');
/*      */           
/* 4428 */           setInternal(parameterIndex, tsBuf.toString());
/*      */         }
/*      */         finally {
/* 4431 */           sessionCalendar2.setTime(oldTime);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 4462 */     if (x == null) {
/* 4463 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 4465 */       setBinaryStream(parameterIndex, x, length);
/*      */       
/* 4467 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2005;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setURL(int parameterIndex, URL arg)
/*      */     throws SQLException
/*      */   {
/* 4475 */     if (arg != null) {
/* 4476 */       setString(parameterIndex, arg.toString());
/*      */       
/* 4478 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 70;
/*      */     } else {
/* 4480 */       setNull(parameterIndex, 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void streamToBytes(Buffer packet, InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException {
/* 4485 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 4487 */         if (this.streamConvertBuf == null) {
/* 4488 */           this.streamConvertBuf = new byte['က'];
/*      */         }
/*      */         
/* 4491 */         String connectionEncoding = this.connection.getEncoding();
/*      */         
/* 4493 */         boolean hexEscape = false;
/*      */         try
/*      */         {
/* 4496 */           if ((this.connection.isNoBackslashEscapesSet()) || ((this.connection.getUseUnicode()) && (connectionEncoding != null) && (CharsetMapping.isMultibyteCharset(connectionEncoding)) && (!this.connection.parserKnowsUnicode())))
/*      */           {
/*      */ 
/* 4499 */             hexEscape = true;
/*      */           }
/*      */         } catch (RuntimeException ex) {
/* 4502 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 4503 */           sqlEx.initCause(ex);
/* 4504 */           throw sqlEx;
/*      */         }
/*      */         
/* 4507 */         if (streamLength == -1) {
/* 4508 */           useLength = false;
/*      */         }
/*      */         
/* 4511 */         int bc = -1;
/*      */         
/* 4513 */         if (useLength) {
/* 4514 */           bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */         } else {
/* 4516 */           bc = readblock(in, this.streamConvertBuf);
/*      */         }
/*      */         
/* 4519 */         int lengthLeftToRead = streamLength - bc;
/*      */         
/* 4521 */         if (hexEscape) {
/* 4522 */           packet.writeStringNoNull("x");
/* 4523 */         } else if (this.connection.getIO().versionMeetsMinimum(4, 1, 0)) {
/* 4524 */           packet.writeStringNoNull("_binary");
/*      */         }
/*      */         
/* 4527 */         if (escape) {
/* 4528 */           packet.writeByte((byte)39);
/*      */         }
/*      */         
/* 4531 */         while (bc > 0) {
/* 4532 */           if (hexEscape) {
/* 4533 */             hexEscapeBlock(this.streamConvertBuf, packet, bc);
/* 4534 */           } else if (escape) {
/* 4535 */             escapeblockFast(this.streamConvertBuf, packet, bc);
/*      */           } else {
/* 4537 */             packet.writeBytesNoNull(this.streamConvertBuf, 0, bc);
/*      */           }
/*      */           
/* 4540 */           if (useLength) {
/* 4541 */             bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */             
/* 4543 */             if (bc > 0) {
/* 4544 */               lengthLeftToRead -= bc;
/*      */             }
/*      */           } else {
/* 4547 */             bc = readblock(in, this.streamConvertBuf);
/*      */           }
/*      */         }
/*      */         
/* 4551 */         if (escape) {
/* 4552 */           packet.writeByte((byte)39);
/*      */         }
/*      */       } finally {
/* 4555 */         if (this.connection.getAutoClosePStmtStreams()) {
/*      */           try {
/* 4557 */             in.close();
/*      */           }
/*      */           catch (IOException ioEx) {}
/*      */           
/* 4561 */           in = null;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final byte[] streamToBytes(InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException {
/* 4568 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 4570 */         if (this.streamConvertBuf == null) {
/* 4571 */           this.streamConvertBuf = new byte['က'];
/*      */         }
/* 4573 */         if (streamLength == -1) {
/* 4574 */           useLength = false;
/*      */         }
/*      */         
/* 4577 */         ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */         
/* 4579 */         int bc = -1;
/*      */         
/* 4581 */         if (useLength) {
/* 4582 */           bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */         } else {
/* 4584 */           bc = readblock(in, this.streamConvertBuf);
/*      */         }
/*      */         
/* 4587 */         int lengthLeftToRead = streamLength - bc;
/*      */         
/* 4589 */         if (escape) {
/* 4590 */           if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 4591 */             bytesOut.write(95);
/* 4592 */             bytesOut.write(98);
/* 4593 */             bytesOut.write(105);
/* 4594 */             bytesOut.write(110);
/* 4595 */             bytesOut.write(97);
/* 4596 */             bytesOut.write(114);
/* 4597 */             bytesOut.write(121);
/*      */           }
/*      */           
/* 4600 */           bytesOut.write(39);
/*      */         }
/*      */         
/* 4603 */         while (bc > 0) {
/* 4604 */           if (escape) {
/* 4605 */             escapeblockFast(this.streamConvertBuf, bytesOut, bc);
/*      */           } else {
/* 4607 */             bytesOut.write(this.streamConvertBuf, 0, bc);
/*      */           }
/*      */           
/* 4610 */           if (useLength) {
/* 4611 */             bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */             
/* 4613 */             if (bc > 0) {
/* 4614 */               lengthLeftToRead -= bc;
/*      */             }
/*      */           } else {
/* 4617 */             bc = readblock(in, this.streamConvertBuf);
/*      */           }
/*      */         }
/*      */         
/* 4621 */         if (escape) {
/* 4622 */           bytesOut.write(39);
/*      */         }
/*      */         
/* 4625 */         byte[] arrayOfByte = bytesOut.toByteArray();jsr 17;return arrayOfByte;
/*      */       } finally {
/* 4627 */         jsr 6; } localObject2 = returnAddress; if (this.connection.getAutoClosePStmtStreams()) {
/*      */         try {
/* 4629 */           in.close();
/*      */         }
/*      */         catch (IOException ioEx) {}
/*      */         
/* 4633 */         in = null; } ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 4646 */     StringBuilder buf = new StringBuilder();
/* 4647 */     buf.append(super.toString());
/* 4648 */     buf.append(": ");
/*      */     try
/*      */     {
/* 4651 */       buf.append(asSql());
/*      */     } catch (SQLException sqlEx) {
/* 4653 */       buf.append("EXCEPTION: " + sqlEx.toString());
/*      */     }
/*      */     
/* 4656 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getParameterIndexOffset()
/*      */   {
/* 4666 */     return 0;
/*      */   }
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
/* 4670 */     setAsciiStream(parameterIndex, x, -1);
/*      */   }
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 4674 */     setAsciiStream(parameterIndex, x, (int)length);
/* 4675 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2005;
/*      */   }
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
/* 4679 */     setBinaryStream(parameterIndex, x, -1);
/*      */   }
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 4683 */     setBinaryStream(parameterIndex, x, (int)length);
/*      */   }
/*      */   
/*      */   public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
/* 4687 */     setBinaryStream(parameterIndex, inputStream);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
/* 4691 */     setCharacterStream(parameterIndex, reader, -1);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/* 4695 */     setCharacterStream(parameterIndex, reader, (int)length);
/*      */   }
/*      */   
/*      */   public void setClob(int parameterIndex, Reader reader) throws SQLException
/*      */   {
/* 4700 */     setCharacterStream(parameterIndex, reader);
/*      */   }
/*      */   
/*      */   public void setClob(int parameterIndex, Reader reader, long length) throws SQLException
/*      */   {
/* 4705 */     setCharacterStream(parameterIndex, reader, length);
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
/* 4709 */     setNCharacterStream(parameterIndex, value, -1L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 4727 */     synchronized (checkClosed().getConnectionMutex()) {
/* 4728 */       if ((this.charEncoding.equalsIgnoreCase("UTF-8")) || (this.charEncoding.equalsIgnoreCase("utf8"))) {
/* 4729 */         setString(parameterIndex, x);
/* 4730 */         return;
/*      */       }
/*      */       
/*      */ 
/* 4734 */       if (x == null) {
/* 4735 */         setNull(parameterIndex, 1);
/*      */       } else {
/* 4737 */         int stringLength = x.length();
/*      */         
/*      */ 
/*      */ 
/* 4741 */         StringBuilder buf = new StringBuilder((int)(x.length() * 1.1D + 4.0D));
/* 4742 */         buf.append("_utf8");
/* 4743 */         buf.append('\'');
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4749 */         for (int i = 0; i < stringLength; i++) {
/* 4750 */           char c = x.charAt(i);
/*      */           
/* 4752 */           switch (c) {
/*      */           case '\000': 
/* 4754 */             buf.append('\\');
/* 4755 */             buf.append('0');
/*      */             
/* 4757 */             break;
/*      */           
/*      */           case '\n': 
/* 4760 */             buf.append('\\');
/* 4761 */             buf.append('n');
/*      */             
/* 4763 */             break;
/*      */           
/*      */           case '\r': 
/* 4766 */             buf.append('\\');
/* 4767 */             buf.append('r');
/*      */             
/* 4769 */             break;
/*      */           
/*      */           case '\\': 
/* 4772 */             buf.append('\\');
/* 4773 */             buf.append('\\');
/*      */             
/* 4775 */             break;
/*      */           
/*      */           case '\'': 
/* 4778 */             buf.append('\\');
/* 4779 */             buf.append('\'');
/*      */             
/* 4781 */             break;
/*      */           
/*      */           case '"': 
/* 4784 */             if (this.usingAnsiMode) {
/* 4785 */               buf.append('\\');
/*      */             }
/*      */             
/* 4788 */             buf.append('"');
/*      */             
/* 4790 */             break;
/*      */           
/*      */           case '\032': 
/* 4793 */             buf.append('\\');
/* 4794 */             buf.append('Z');
/*      */             
/* 4796 */             break;
/*      */           
/*      */           default: 
/* 4799 */             buf.append(c);
/*      */           }
/*      */           
/*      */         }
/* 4803 */         buf.append('\'');
/*      */         
/* 4805 */         String parameterAsString = buf.toString();
/*      */         
/* 4807 */         byte[] parameterAsBytes = null;
/*      */         
/* 4809 */         if (!this.isLoadDataQuery) {
/* 4810 */           parameterAsBytes = StringUtils.getBytes(parameterAsString, this.connection.getCharsetConverter("UTF-8"), "UTF-8", this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */         }
/*      */         else
/*      */         {
/* 4814 */           parameterAsBytes = StringUtils.getBytes(parameterAsString);
/*      */         }
/*      */         
/* 4817 */         setInternal(parameterIndex, parameterAsBytes);
/*      */         
/* 4819 */         this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -9;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNCharacterStream(int parameterIndex, Reader reader, long length)
/*      */     throws SQLException
/*      */   {
/* 4846 */     synchronized (checkClosed().getConnectionMutex()) {
/*      */       try {
/* 4848 */         if (reader == null) {
/* 4849 */           setNull(parameterIndex, -1);
/*      */         }
/*      */         else {
/* 4852 */           char[] c = null;
/* 4853 */           int len = 0;
/*      */           
/* 4855 */           boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */           
/*      */ 
/*      */ 
/* 4859 */           if ((useLength) && (length != -1L)) {
/* 4860 */             c = new char[(int)length];
/*      */             
/* 4862 */             int numCharsRead = readFully(reader, c, (int)length);
/* 4863 */             setNString(parameterIndex, new String(c, 0, numCharsRead));
/*      */           }
/*      */           else {
/* 4866 */             c = new char['က'];
/*      */             
/* 4868 */             StringBuilder buf = new StringBuilder();
/*      */             
/* 4870 */             while ((len = reader.read(c)) != -1) {
/* 4871 */               buf.append(c, 0, len);
/*      */             }
/*      */             
/* 4874 */             setNString(parameterIndex, buf.toString());
/*      */           }
/*      */           
/* 4877 */           this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2011;
/*      */         }
/*      */       } catch (IOException ioEx) {
/* 4880 */         throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNClob(int parameterIndex, Reader reader) throws SQLException {
/* 4886 */     setNCharacterStream(parameterIndex, reader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNClob(int parameterIndex, Reader reader, long length)
/*      */     throws SQLException
/*      */   {
/* 4903 */     if (reader == null) {
/* 4904 */       setNull(parameterIndex, -1);
/*      */     } else {
/* 4906 */       setNCharacterStream(parameterIndex, reader, length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   class EmulatedPreparedStatementBindings
/*      */     implements ParameterBindings
/*      */   {
/*      */     private ResultSetImpl bindingsAsRs;
/*      */     
/*      */     private boolean[] parameterIsNull;
/*      */     
/*      */ 
/*      */     EmulatedPreparedStatementBindings()
/*      */       throws SQLException
/*      */     {
/* 4922 */       List<ResultSetRow> rows = new ArrayList();
/* 4923 */       this.parameterIsNull = new boolean[PreparedStatement.this.parameterCount];
/* 4924 */       System.arraycopy(PreparedStatement.this.isNull, 0, this.parameterIsNull, 0, PreparedStatement.this.parameterCount);
/* 4925 */       byte[][] rowData = new byte[PreparedStatement.this.parameterCount][];
/* 4926 */       Field[] typeMetadata = new Field[PreparedStatement.this.parameterCount];
/*      */       
/* 4928 */       for (int i = 0; i < PreparedStatement.this.parameterCount; i++) {
/* 4929 */         if (PreparedStatement.this.batchCommandIndex == -1) {
/* 4930 */           rowData[i] = PreparedStatement.this.getBytesRepresentation(i);
/*      */         } else {
/* 4932 */           rowData[i] = PreparedStatement.this.getBytesRepresentationForBatch(i, PreparedStatement.this.batchCommandIndex);
/*      */         }
/*      */         
/* 4935 */         int charsetIndex = 0;
/*      */         
/* 4937 */         if ((PreparedStatement.this.parameterTypes[i] == -2) || (PreparedStatement.this.parameterTypes[i] == 2004)) {
/* 4938 */           charsetIndex = 63;
/*      */         } else {
/*      */           try {
/* 4941 */             charsetIndex = CharsetMapping.getCollationIndexForJavaEncoding(PreparedStatement.this.connection.getEncoding(), PreparedStatement.this.connection);
/*      */           }
/*      */           catch (SQLException ex) {
/* 4944 */             throw ex;
/*      */           } catch (RuntimeException ex) {
/* 4946 */             SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 4947 */             sqlEx.initCause(ex);
/* 4948 */             throw sqlEx;
/*      */           }
/*      */         }
/*      */         
/* 4952 */         Field parameterMetadata = new Field(null, "parameter_" + (i + 1), charsetIndex, PreparedStatement.this.parameterTypes[i], rowData[i].length);
/* 4953 */         parameterMetadata.setConnection(PreparedStatement.this.connection);
/* 4954 */         typeMetadata[i] = parameterMetadata;
/*      */       }
/*      */       
/* 4957 */       rows.add(new ByteArrayRow(rowData, PreparedStatement.this.getExceptionInterceptor()));
/*      */       
/* 4959 */       this.bindingsAsRs = new ResultSetImpl(PreparedStatement.this.connection.getCatalog(), typeMetadata, new RowDataStatic(rows), PreparedStatement.this.connection, null);
/*      */       
/* 4961 */       this.bindingsAsRs.next();
/*      */     }
/*      */     
/*      */     public Array getArray(int parameterIndex) throws SQLException {
/* 4965 */       return this.bindingsAsRs.getArray(parameterIndex);
/*      */     }
/*      */     
/*      */     public InputStream getAsciiStream(int parameterIndex) throws SQLException {
/* 4969 */       return this.bindingsAsRs.getAsciiStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/* 4973 */       return this.bindingsAsRs.getBigDecimal(parameterIndex);
/*      */     }
/*      */     
/*      */     public InputStream getBinaryStream(int parameterIndex) throws SQLException {
/* 4977 */       return this.bindingsAsRs.getBinaryStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Blob getBlob(int parameterIndex) throws SQLException {
/* 4981 */       return this.bindingsAsRs.getBlob(parameterIndex);
/*      */     }
/*      */     
/*      */     public boolean getBoolean(int parameterIndex) throws SQLException {
/* 4985 */       return this.bindingsAsRs.getBoolean(parameterIndex);
/*      */     }
/*      */     
/*      */     public byte getByte(int parameterIndex) throws SQLException {
/* 4989 */       return this.bindingsAsRs.getByte(parameterIndex);
/*      */     }
/*      */     
/*      */     public byte[] getBytes(int parameterIndex) throws SQLException {
/* 4993 */       return this.bindingsAsRs.getBytes(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getCharacterStream(int parameterIndex) throws SQLException {
/* 4997 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Clob getClob(int parameterIndex) throws SQLException {
/* 5001 */       return this.bindingsAsRs.getClob(parameterIndex);
/*      */     }
/*      */     
/*      */     public java.sql.Date getDate(int parameterIndex) throws SQLException {
/* 5005 */       return this.bindingsAsRs.getDate(parameterIndex);
/*      */     }
/*      */     
/*      */     public double getDouble(int parameterIndex) throws SQLException {
/* 5009 */       return this.bindingsAsRs.getDouble(parameterIndex);
/*      */     }
/*      */     
/*      */     public float getFloat(int parameterIndex) throws SQLException {
/* 5013 */       return this.bindingsAsRs.getFloat(parameterIndex);
/*      */     }
/*      */     
/*      */     public int getInt(int parameterIndex) throws SQLException {
/* 5017 */       return this.bindingsAsRs.getInt(parameterIndex);
/*      */     }
/*      */     
/*      */     public long getLong(int parameterIndex) throws SQLException {
/* 5021 */       return this.bindingsAsRs.getLong(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getNCharacterStream(int parameterIndex) throws SQLException {
/* 5025 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getNClob(int parameterIndex) throws SQLException {
/* 5029 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Object getObject(int parameterIndex) throws SQLException {
/* 5033 */       PreparedStatement.this.checkBounds(parameterIndex, 0);
/*      */       
/* 5035 */       if (this.parameterIsNull[(parameterIndex - 1)] != 0) {
/* 5036 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5041 */       switch (PreparedStatement.this.parameterTypes[(parameterIndex - 1)]) {
/*      */       case -6: 
/* 5043 */         return Byte.valueOf(getByte(parameterIndex));
/*      */       case 5: 
/* 5045 */         return Short.valueOf(getShort(parameterIndex));
/*      */       case 4: 
/* 5047 */         return Integer.valueOf(getInt(parameterIndex));
/*      */       case -5: 
/* 5049 */         return Long.valueOf(getLong(parameterIndex));
/*      */       case 6: 
/* 5051 */         return Float.valueOf(getFloat(parameterIndex));
/*      */       case 8: 
/* 5053 */         return Double.valueOf(getDouble(parameterIndex));
/*      */       }
/* 5055 */       return this.bindingsAsRs.getObject(parameterIndex);
/*      */     }
/*      */     
/*      */     public Ref getRef(int parameterIndex) throws SQLException
/*      */     {
/* 5060 */       return this.bindingsAsRs.getRef(parameterIndex);
/*      */     }
/*      */     
/*      */     public short getShort(int parameterIndex) throws SQLException {
/* 5064 */       return this.bindingsAsRs.getShort(parameterIndex);
/*      */     }
/*      */     
/*      */     public String getString(int parameterIndex) throws SQLException {
/* 5068 */       return this.bindingsAsRs.getString(parameterIndex);
/*      */     }
/*      */     
/*      */     public Time getTime(int parameterIndex) throws SQLException {
/* 5072 */       return this.bindingsAsRs.getTime(parameterIndex);
/*      */     }
/*      */     
/*      */     public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/* 5076 */       return this.bindingsAsRs.getTimestamp(parameterIndex);
/*      */     }
/*      */     
/*      */     public URL getURL(int parameterIndex) throws SQLException {
/* 5080 */       return this.bindingsAsRs.getURL(parameterIndex);
/*      */     }
/*      */     
/*      */     public boolean isNull(int parameterIndex) throws SQLException {
/* 5084 */       PreparedStatement.this.checkBounds(parameterIndex, 0);
/*      */       
/* 5086 */       return this.parameterIsNull[(parameterIndex - 1)];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/* 5110 */     int count = super.getUpdateCount();
/*      */     
/* 5112 */     if ((containsOnDuplicateKeyUpdateInSQL()) && (this.compensateForOnDuplicateKeyUpdate) && (
/* 5113 */       (count == 2) || (count == 0))) {
/* 5114 */       count = 1;
/*      */     }
/*      */     
/*      */ 
/* 5118 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */   protected static boolean canRewrite(String sql, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementStartPos)
/*      */   {
/* 5124 */     boolean rewritableOdku = true;
/*      */     
/* 5126 */     if (isOnDuplicateKeyUpdate) {
/* 5127 */       int updateClausePos = StringUtils.indexOfIgnoreCase(locationOfOnDuplicateKeyUpdate, sql, " UPDATE ");
/*      */       
/* 5129 */       if (updateClausePos != -1) {
/* 5130 */         rewritableOdku = StringUtils.indexOfIgnoreCase(updateClausePos, sql, "LAST_INSERT_ID", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) == -1;
/*      */       }
/*      */     }
/*      */     
/* 5134 */     return (StringUtils.startsWithIgnoreCaseAndWs(sql, "INSERT", statementStartPos)) && (StringUtils.indexOfIgnoreCase(statementStartPos, sql, "SELECT", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) == -1) && (rewritableOdku);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected int[] executePreparedBatchAsMultiStatement(int batchTimeout)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 62	com/mysql/jdbc/PreparedStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 63 1 0
/*      */     //   9: dup
/*      */     //   10: astore_2
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 149	com/mysql/jdbc/PreparedStatement:batchedValuesClause	Ljava/lang/String;
/*      */     //   16: ifnonnull +29 -> 45
/*      */     //   19: aload_0
/*      */     //   20: new 73	java/lang/StringBuilder
/*      */     //   23: dup
/*      */     //   24: invokespecial 74	java/lang/StringBuilder:<init>	()V
/*      */     //   27: aload_0
/*      */     //   28: getfield 21	com/mysql/jdbc/PreparedStatement:originalSql	Ljava/lang/String;
/*      */     //   31: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   34: ldc -106
/*      */     //   36: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   39: invokevirtual 94	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   42: putfield 149	com/mysql/jdbc/PreparedStatement:batchedValuesClause	Ljava/lang/String;
/*      */     //   45: aload_0
/*      */     //   46: getfield 35	com/mysql/jdbc/PreparedStatement:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   49: astore_3
/*      */     //   50: aload_3
/*      */     //   51: invokeinterface 151 1 0
/*      */     //   56: istore 4
/*      */     //   58: aconst_null
/*      */     //   59: astore 5
/*      */     //   61: aload_0
/*      */     //   62: invokevirtual 108	com/mysql/jdbc/PreparedStatement:clearWarnings	()V
/*      */     //   65: aload_0
/*      */     //   66: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   69: invokeinterface 135 1 0
/*      */     //   74: istore 6
/*      */     //   76: aload_0
/*      */     //   77: getfield 106	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   80: ifeq +16 -> 96
/*      */     //   83: aload_0
/*      */     //   84: new 65	java/util/ArrayList
/*      */     //   87: dup
/*      */     //   88: iload 6
/*      */     //   90: invokespecial 152	java/util/ArrayList:<init>	(I)V
/*      */     //   93: putfield 110	com/mysql/jdbc/PreparedStatement:batchedGeneratedKeys	Ljava/util/ArrayList;
/*      */     //   96: aload_0
/*      */     //   97: iload 6
/*      */     //   99: invokevirtual 153	com/mysql/jdbc/PreparedStatement:computeBatchSize	(I)I
/*      */     //   102: istore 7
/*      */     //   104: iload 6
/*      */     //   106: iload 7
/*      */     //   108: if_icmpge +7 -> 115
/*      */     //   111: iload 6
/*      */     //   113: istore 7
/*      */     //   115: aconst_null
/*      */     //   116: astore 8
/*      */     //   118: iconst_1
/*      */     //   119: istore 9
/*      */     //   121: iconst_0
/*      */     //   122: istore 10
/*      */     //   124: iconst_0
/*      */     //   125: istore 11
/*      */     //   127: iconst_0
/*      */     //   128: istore 12
/*      */     //   130: iload 6
/*      */     //   132: newarray <illegal type>
/*      */     //   134: astore 13
/*      */     //   136: aconst_null
/*      */     //   137: astore 14
/*      */     //   139: iload 4
/*      */     //   141: ifne +12 -> 153
/*      */     //   144: aload_3
/*      */     //   145: invokeinterface 154 1 0
/*      */     //   150: invokevirtual 155	com/mysql/jdbc/MysqlIO:enableMultiQueries	()V
/*      */     //   153: aload_0
/*      */     //   154: getfield 106	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   157: ifeq +21 -> 178
/*      */     //   160: aload_3
/*      */     //   161: aload_0
/*      */     //   162: iload 7
/*      */     //   164: invokespecial 156	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   167: iconst_1
/*      */     //   168: invokeinterface 157 3 0
/*      */     //   173: astore 8
/*      */     //   175: goto +17 -> 192
/*      */     //   178: aload_3
/*      */     //   179: aload_0
/*      */     //   180: iload 7
/*      */     //   182: invokespecial 156	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   185: invokeinterface 158 2 0
/*      */     //   190: astore 8
/*      */     //   192: aload_3
/*      */     //   193: invokeinterface 159 1 0
/*      */     //   198: ifeq +47 -> 245
/*      */     //   201: iload_1
/*      */     //   202: ifeq +43 -> 245
/*      */     //   205: aload_3
/*      */     //   206: iconst_5
/*      */     //   207: iconst_0
/*      */     //   208: iconst_0
/*      */     //   209: invokeinterface 37 4 0
/*      */     //   214: ifeq +31 -> 245
/*      */     //   217: new 160	com/mysql/jdbc/StatementImpl$CancelTask
/*      */     //   220: dup
/*      */     //   221: aload_0
/*      */     //   222: aload 8
/*      */     //   224: checkcast 161	com/mysql/jdbc/StatementImpl
/*      */     //   227: invokespecial 162	com/mysql/jdbc/StatementImpl$CancelTask:<init>	(Lcom/mysql/jdbc/StatementImpl;Lcom/mysql/jdbc/StatementImpl;)V
/*      */     //   230: astore 5
/*      */     //   232: aload_3
/*      */     //   233: invokeinterface 163 1 0
/*      */     //   238: aload 5
/*      */     //   240: iload_1
/*      */     //   241: i2l
/*      */     //   242: invokevirtual 164	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
/*      */     //   245: iload 6
/*      */     //   247: iload 7
/*      */     //   249: if_icmpge +10 -> 259
/*      */     //   252: iload 6
/*      */     //   254: istore 10
/*      */     //   256: goto +10 -> 266
/*      */     //   259: iload 6
/*      */     //   261: iload 7
/*      */     //   263: idiv
/*      */     //   264: istore 10
/*      */     //   266: iload 10
/*      */     //   268: iload 7
/*      */     //   270: imul
/*      */     //   271: istore 15
/*      */     //   273: iconst_0
/*      */     //   274: istore 16
/*      */     //   276: iload 16
/*      */     //   278: iload 15
/*      */     //   280: if_icmpge +98 -> 378
/*      */     //   283: iload 16
/*      */     //   285: ifeq +63 -> 348
/*      */     //   288: iload 16
/*      */     //   290: iload 7
/*      */     //   292: irem
/*      */     //   293: ifne +55 -> 348
/*      */     //   296: aload 8
/*      */     //   298: invokeinterface 165 1 0
/*      */     //   303: pop
/*      */     //   304: goto +19 -> 323
/*      */     //   307: astore 17
/*      */     //   309: aload_0
/*      */     //   310: iload 11
/*      */     //   312: iload 7
/*      */     //   314: aload 13
/*      */     //   316: aload 17
/*      */     //   318: invokevirtual 166	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   321: astore 14
/*      */     //   323: aload_0
/*      */     //   324: aload 8
/*      */     //   326: checkcast 161	com/mysql/jdbc/StatementImpl
/*      */     //   329: iload 12
/*      */     //   331: aload 13
/*      */     //   333: invokevirtual 167	com/mysql/jdbc/PreparedStatement:processMultiCountsAndKeys	(Lcom/mysql/jdbc/StatementImpl;I[I)I
/*      */     //   336: istore 12
/*      */     //   338: aload 8
/*      */     //   340: invokeinterface 168 1 0
/*      */     //   345: iconst_1
/*      */     //   346: istore 9
/*      */     //   348: aload_0
/*      */     //   349: aload 8
/*      */     //   351: iload 9
/*      */     //   353: aload_0
/*      */     //   354: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   357: iload 11
/*      */     //   359: iinc 11 1
/*      */     //   362: invokeinterface 77 2 0
/*      */     //   367: invokevirtual 169	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   370: istore 9
/*      */     //   372: iinc 16 1
/*      */     //   375: goto -99 -> 276
/*      */     //   378: aload 8
/*      */     //   380: invokeinterface 165 1 0
/*      */     //   385: pop
/*      */     //   386: goto +21 -> 407
/*      */     //   389: astore 16
/*      */     //   391: aload_0
/*      */     //   392: iload 11
/*      */     //   394: iconst_1
/*      */     //   395: isub
/*      */     //   396: iload 7
/*      */     //   398: aload 13
/*      */     //   400: aload 16
/*      */     //   402: invokevirtual 166	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   405: astore 14
/*      */     //   407: aload_0
/*      */     //   408: aload 8
/*      */     //   410: checkcast 161	com/mysql/jdbc/StatementImpl
/*      */     //   413: iload 12
/*      */     //   415: aload 13
/*      */     //   417: invokevirtual 167	com/mysql/jdbc/PreparedStatement:processMultiCountsAndKeys	(Lcom/mysql/jdbc/StatementImpl;I[I)I
/*      */     //   420: istore 12
/*      */     //   422: aload 8
/*      */     //   424: invokeinterface 168 1 0
/*      */     //   429: iload 6
/*      */     //   431: iload 11
/*      */     //   433: isub
/*      */     //   434: istore 7
/*      */     //   436: jsr +14 -> 450
/*      */     //   439: goto +30 -> 469
/*      */     //   442: astore 18
/*      */     //   444: jsr +6 -> 450
/*      */     //   447: aload 18
/*      */     //   449: athrow
/*      */     //   450: astore 19
/*      */     //   452: aload 8
/*      */     //   454: ifnull +13 -> 467
/*      */     //   457: aload 8
/*      */     //   459: invokeinterface 170 1 0
/*      */     //   464: aconst_null
/*      */     //   465: astore 8
/*      */     //   467: ret 19
/*      */     //   469: iload 7
/*      */     //   471: ifle +145 -> 616
/*      */     //   474: aload_0
/*      */     //   475: getfield 106	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   478: ifeq +21 -> 499
/*      */     //   481: aload_3
/*      */     //   482: aload_0
/*      */     //   483: iload 7
/*      */     //   485: invokespecial 156	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   488: iconst_1
/*      */     //   489: invokeinterface 157 3 0
/*      */     //   494: astore 8
/*      */     //   496: goto +17 -> 513
/*      */     //   499: aload_3
/*      */     //   500: aload_0
/*      */     //   501: iload 7
/*      */     //   503: invokespecial 156	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   506: invokeinterface 158 2 0
/*      */     //   511: astore 8
/*      */     //   513: aload 5
/*      */     //   515: ifnull +13 -> 528
/*      */     //   518: aload 5
/*      */     //   520: aload 8
/*      */     //   522: checkcast 161	com/mysql/jdbc/StatementImpl
/*      */     //   525: putfield 171	com/mysql/jdbc/StatementImpl$CancelTask:toCancel	Lcom/mysql/jdbc/StatementImpl;
/*      */     //   528: iconst_1
/*      */     //   529: istore 9
/*      */     //   531: iload 11
/*      */     //   533: iload 6
/*      */     //   535: if_icmpge +30 -> 565
/*      */     //   538: aload_0
/*      */     //   539: aload 8
/*      */     //   541: iload 9
/*      */     //   543: aload_0
/*      */     //   544: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   547: iload 11
/*      */     //   549: iinc 11 1
/*      */     //   552: invokeinterface 77 2 0
/*      */     //   557: invokevirtual 169	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   560: istore 9
/*      */     //   562: goto -31 -> 531
/*      */     //   565: aload 8
/*      */     //   567: invokeinterface 165 1 0
/*      */     //   572: pop
/*      */     //   573: goto +21 -> 594
/*      */     //   576: astore 15
/*      */     //   578: aload_0
/*      */     //   579: iload 11
/*      */     //   581: iconst_1
/*      */     //   582: isub
/*      */     //   583: iload 7
/*      */     //   585: aload 13
/*      */     //   587: aload 15
/*      */     //   589: invokevirtual 166	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   592: astore 14
/*      */     //   594: aload_0
/*      */     //   595: aload 8
/*      */     //   597: checkcast 161	com/mysql/jdbc/StatementImpl
/*      */     //   600: iload 12
/*      */     //   602: aload 13
/*      */     //   604: invokevirtual 167	com/mysql/jdbc/PreparedStatement:processMultiCountsAndKeys	(Lcom/mysql/jdbc/StatementImpl;I[I)I
/*      */     //   607: istore 12
/*      */     //   609: aload 8
/*      */     //   611: invokeinterface 168 1 0
/*      */     //   616: aload 5
/*      */     //   618: ifnull +36 -> 654
/*      */     //   621: aload 5
/*      */     //   623: getfield 172	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
/*      */     //   626: ifnull +9 -> 635
/*      */     //   629: aload 5
/*      */     //   631: getfield 172	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
/*      */     //   634: athrow
/*      */     //   635: aload 5
/*      */     //   637: invokevirtual 173	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
/*      */     //   640: pop
/*      */     //   641: aload_3
/*      */     //   642: invokeinterface 163 1 0
/*      */     //   647: invokevirtual 174	java/util/Timer:purge	()I
/*      */     //   650: pop
/*      */     //   651: aconst_null
/*      */     //   652: astore 5
/*      */     //   654: aload 14
/*      */     //   656: ifnull +40 -> 696
/*      */     //   659: new 175	java/sql/BatchUpdateException
/*      */     //   662: dup
/*      */     //   663: aload 14
/*      */     //   665: invokevirtual 176	java/sql/SQLException:getMessage	()Ljava/lang/String;
/*      */     //   668: aload 14
/*      */     //   670: invokevirtual 177	java/sql/SQLException:getSQLState	()Ljava/lang/String;
/*      */     //   673: aload 14
/*      */     //   675: invokevirtual 178	java/sql/SQLException:getErrorCode	()I
/*      */     //   678: aload 13
/*      */     //   680: invokespecial 179	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
/*      */     //   683: astore 15
/*      */     //   685: aload 15
/*      */     //   687: aload 14
/*      */     //   689: invokevirtual 180	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   692: pop
/*      */     //   693: aload 15
/*      */     //   695: athrow
/*      */     //   696: aload 13
/*      */     //   698: astore 15
/*      */     //   700: jsr +19 -> 719
/*      */     //   703: jsr +40 -> 743
/*      */     //   706: aload_2
/*      */     //   707: monitorexit
/*      */     //   708: aload 15
/*      */     //   710: areturn
/*      */     //   711: astore 20
/*      */     //   713: jsr +6 -> 719
/*      */     //   716: aload 20
/*      */     //   718: athrow
/*      */     //   719: astore 21
/*      */     //   721: aload 8
/*      */     //   723: ifnull +10 -> 733
/*      */     //   726: aload 8
/*      */     //   728: invokeinterface 170 1 0
/*      */     //   733: ret 21
/*      */     //   735: astore 22
/*      */     //   737: jsr +6 -> 743
/*      */     //   740: aload 22
/*      */     //   742: athrow
/*      */     //   743: astore 23
/*      */     //   745: aload 5
/*      */     //   747: ifnull +19 -> 766
/*      */     //   750: aload 5
/*      */     //   752: invokevirtual 173	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
/*      */     //   755: pop
/*      */     //   756: aload_3
/*      */     //   757: invokeinterface 163 1 0
/*      */     //   762: invokevirtual 174	java/util/Timer:purge	()I
/*      */     //   765: pop
/*      */     //   766: aload_0
/*      */     //   767: invokevirtual 137	com/mysql/jdbc/PreparedStatement:resetCancelledState	()V
/*      */     //   770: iload 4
/*      */     //   772: ifne +12 -> 784
/*      */     //   775: aload_3
/*      */     //   776: invokeinterface 154 1 0
/*      */     //   781: invokevirtual 181	com/mysql/jdbc/MysqlIO:disableMultiQueries	()V
/*      */     //   784: aload_0
/*      */     //   785: invokevirtual 146	com/mysql/jdbc/PreparedStatement:clearBatch	()V
/*      */     //   788: ret 23
/*      */     //   790: astore 24
/*      */     //   792: aload_2
/*      */     //   793: monitorexit
/*      */     //   794: aload 24
/*      */     //   796: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1299	-> byte code offset #0
/*      */     //   Java source line #1301	-> byte code offset #12
/*      */     //   Java source line #1302	-> byte code offset #19
/*      */     //   Java source line #1305	-> byte code offset #45
/*      */     //   Java source line #1307	-> byte code offset #50
/*      */     //   Java source line #1308	-> byte code offset #58
/*      */     //   Java source line #1311	-> byte code offset #61
/*      */     //   Java source line #1313	-> byte code offset #65
/*      */     //   Java source line #1315	-> byte code offset #76
/*      */     //   Java source line #1316	-> byte code offset #83
/*      */     //   Java source line #1319	-> byte code offset #96
/*      */     //   Java source line #1321	-> byte code offset #104
/*      */     //   Java source line #1322	-> byte code offset #111
/*      */     //   Java source line #1325	-> byte code offset #115
/*      */     //   Java source line #1327	-> byte code offset #118
/*      */     //   Java source line #1328	-> byte code offset #121
/*      */     //   Java source line #1329	-> byte code offset #124
/*      */     //   Java source line #1330	-> byte code offset #127
/*      */     //   Java source line #1331	-> byte code offset #130
/*      */     //   Java source line #1332	-> byte code offset #136
/*      */     //   Java source line #1335	-> byte code offset #139
/*      */     //   Java source line #1336	-> byte code offset #144
/*      */     //   Java source line #1339	-> byte code offset #153
/*      */     //   Java source line #1340	-> byte code offset #160
/*      */     //   Java source line #1342	-> byte code offset #178
/*      */     //   Java source line #1345	-> byte code offset #192
/*      */     //   Java source line #1346	-> byte code offset #217
/*      */     //   Java source line #1347	-> byte code offset #232
/*      */     //   Java source line #1350	-> byte code offset #245
/*      */     //   Java source line #1351	-> byte code offset #252
/*      */     //   Java source line #1353	-> byte code offset #259
/*      */     //   Java source line #1356	-> byte code offset #266
/*      */     //   Java source line #1358	-> byte code offset #273
/*      */     //   Java source line #1359	-> byte code offset #283
/*      */     //   Java source line #1361	-> byte code offset #296
/*      */     //   Java source line #1364	-> byte code offset #304
/*      */     //   Java source line #1362	-> byte code offset #307
/*      */     //   Java source line #1363	-> byte code offset #309
/*      */     //   Java source line #1366	-> byte code offset #323
/*      */     //   Java source line #1368	-> byte code offset #338
/*      */     //   Java source line #1369	-> byte code offset #345
/*      */     //   Java source line #1372	-> byte code offset #348
/*      */     //   Java source line #1358	-> byte code offset #372
/*      */     //   Java source line #1376	-> byte code offset #378
/*      */     //   Java source line #1379	-> byte code offset #386
/*      */     //   Java source line #1377	-> byte code offset #389
/*      */     //   Java source line #1378	-> byte code offset #391
/*      */     //   Java source line #1381	-> byte code offset #407
/*      */     //   Java source line #1383	-> byte code offset #422
/*      */     //   Java source line #1385	-> byte code offset #429
/*      */     //   Java source line #1386	-> byte code offset #436
/*      */     //   Java source line #1391	-> byte code offset #439
/*      */     //   Java source line #1387	-> byte code offset #442
/*      */     //   Java source line #1388	-> byte code offset #457
/*      */     //   Java source line #1389	-> byte code offset #464
/*      */     //   Java source line #1394	-> byte code offset #469
/*      */     //   Java source line #1396	-> byte code offset #474
/*      */     //   Java source line #1397	-> byte code offset #481
/*      */     //   Java source line #1399	-> byte code offset #499
/*      */     //   Java source line #1402	-> byte code offset #513
/*      */     //   Java source line #1403	-> byte code offset #518
/*      */     //   Java source line #1406	-> byte code offset #528
/*      */     //   Java source line #1408	-> byte code offset #531
/*      */     //   Java source line #1409	-> byte code offset #538
/*      */     //   Java source line #1413	-> byte code offset #565
/*      */     //   Java source line #1416	-> byte code offset #573
/*      */     //   Java source line #1414	-> byte code offset #576
/*      */     //   Java source line #1415	-> byte code offset #578
/*      */     //   Java source line #1418	-> byte code offset #594
/*      */     //   Java source line #1420	-> byte code offset #609
/*      */     //   Java source line #1423	-> byte code offset #616
/*      */     //   Java source line #1424	-> byte code offset #621
/*      */     //   Java source line #1425	-> byte code offset #629
/*      */     //   Java source line #1428	-> byte code offset #635
/*      */     //   Java source line #1430	-> byte code offset #641
/*      */     //   Java source line #1432	-> byte code offset #651
/*      */     //   Java source line #1435	-> byte code offset #654
/*      */     //   Java source line #1436	-> byte code offset #659
/*      */     //   Java source line #1438	-> byte code offset #685
/*      */     //   Java source line #1439	-> byte code offset #693
/*      */     //   Java source line #1442	-> byte code offset #696
/*      */     //   Java source line #1444	-> byte code offset #711
/*      */     //   Java source line #1445	-> byte code offset #726
/*      */     //   Java source line #1449	-> byte code offset #735
/*      */     //   Java source line #1450	-> byte code offset #750
/*      */     //   Java source line #1451	-> byte code offset #756
/*      */     //   Java source line #1454	-> byte code offset #766
/*      */     //   Java source line #1456	-> byte code offset #770
/*      */     //   Java source line #1457	-> byte code offset #775
/*      */     //   Java source line #1460	-> byte code offset #784
/*      */     //   Java source line #1462	-> byte code offset #790
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	797	0	this	PreparedStatement
/*      */     //   0	797	1	batchTimeout	int
/*      */     //   10	783	2	Ljava/lang/Object;	Object
/*      */     //   49	727	3	locallyScopedConn	MySQLConnection
/*      */     //   56	715	4	multiQueriesEnabled	boolean
/*      */     //   59	692	5	timeoutTask	StatementImpl.CancelTask
/*      */     //   74	460	6	numBatchedArgs	int
/*      */     //   102	482	7	numValuesPerBatch	int
/*      */     //   116	611	8	batchedStatement	java.sql.PreparedStatement
/*      */     //   119	442	9	batchedParamIndex	int
/*      */     //   122	145	10	numberToExecuteAsMultiValue	int
/*      */     //   125	455	11	batchCounter	int
/*      */     //   128	480	12	updateCountCounter	int
/*      */     //   134	563	13	updateCounts	int[]
/*      */     //   137	551	14	sqlEx	SQLException
/*      */     //   271	8	15	numberArgsToExecute	int
/*      */     //   576	12	15	ex	SQLException
/*      */     //   683	26	15	batchUpdateException	SQLException
/*      */     //   274	99	16	i	int
/*      */     //   389	12	16	ex	SQLException
/*      */     //   307	10	17	ex	SQLException
/*      */     //   442	6	18	localObject1	Object
/*      */     //   450	1	19	localObject2	Object
/*      */     //   711	6	20	localObject3	Object
/*      */     //   719	1	21	localObject4	Object
/*      */     //   735	6	22	localObject5	Object
/*      */     //   743	1	23	localObject6	Object
/*      */     //   790	5	24	localObject7	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   296	304	307	java/sql/SQLException
/*      */     //   378	386	389	java/sql/SQLException
/*      */     //   139	439	442	finally
/*      */     //   442	447	442	finally
/*      */     //   565	573	576	java/sql/SQLException
/*      */     //   469	703	711	finally
/*      */     //   711	716	711	finally
/*      */     //   61	706	735	finally
/*      */     //   711	740	735	finally
/*      */     //   12	708	790	finally
/*      */     //   711	794	790	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected int[] executeBatchedInserts(int batchTimeout)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 62	com/mysql/jdbc/PreparedStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 63 1 0
/*      */     //   9: dup
/*      */     //   10: astore_2
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: invokevirtual 185	com/mysql/jdbc/PreparedStatement:getValuesClause	()Ljava/lang/String;
/*      */     //   16: astore_3
/*      */     //   17: aload_0
/*      */     //   18: getfield 35	com/mysql/jdbc/PreparedStatement:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   21: astore 4
/*      */     //   23: aload_3
/*      */     //   24: ifnonnull +11 -> 35
/*      */     //   27: aload_0
/*      */     //   28: iload_1
/*      */     //   29: invokevirtual 143	com/mysql/jdbc/PreparedStatement:executeBatchSerially	(I)[I
/*      */     //   32: aload_2
/*      */     //   33: monitorexit
/*      */     //   34: areturn
/*      */     //   35: aload_0
/*      */     //   36: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   39: invokeinterface 135 1 0
/*      */     //   44: istore 5
/*      */     //   46: aload_0
/*      */     //   47: getfield 106	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   50: ifeq +16 -> 66
/*      */     //   53: aload_0
/*      */     //   54: new 65	java/util/ArrayList
/*      */     //   57: dup
/*      */     //   58: iload 5
/*      */     //   60: invokespecial 152	java/util/ArrayList:<init>	(I)V
/*      */     //   63: putfield 110	com/mysql/jdbc/PreparedStatement:batchedGeneratedKeys	Ljava/util/ArrayList;
/*      */     //   66: aload_0
/*      */     //   67: iload 5
/*      */     //   69: invokevirtual 153	com/mysql/jdbc/PreparedStatement:computeBatchSize	(I)I
/*      */     //   72: istore 6
/*      */     //   74: iload 5
/*      */     //   76: iload 6
/*      */     //   78: if_icmpge +7 -> 85
/*      */     //   81: iload 5
/*      */     //   83: istore 6
/*      */     //   85: aconst_null
/*      */     //   86: astore 7
/*      */     //   88: iconst_1
/*      */     //   89: istore 8
/*      */     //   91: iconst_0
/*      */     //   92: istore 9
/*      */     //   94: iconst_0
/*      */     //   95: istore 10
/*      */     //   97: iconst_0
/*      */     //   98: istore 11
/*      */     //   100: aconst_null
/*      */     //   101: astore 12
/*      */     //   103: aconst_null
/*      */     //   104: astore 13
/*      */     //   106: iload 5
/*      */     //   108: newarray <illegal type>
/*      */     //   110: astore 14
/*      */     //   112: aload_0
/*      */     //   113: aload 4
/*      */     //   115: iload 6
/*      */     //   117: invokevirtual 186	com/mysql/jdbc/PreparedStatement:prepareBatchedInsertSQL	(Lcom/mysql/jdbc/MySQLConnection;I)Lcom/mysql/jdbc/PreparedStatement;
/*      */     //   120: astore 7
/*      */     //   122: aload 4
/*      */     //   124: invokeinterface 159 1 0
/*      */     //   129: ifeq +49 -> 178
/*      */     //   132: iload_1
/*      */     //   133: ifeq +45 -> 178
/*      */     //   136: aload 4
/*      */     //   138: iconst_5
/*      */     //   139: iconst_0
/*      */     //   140: iconst_0
/*      */     //   141: invokeinterface 37 4 0
/*      */     //   146: ifeq +32 -> 178
/*      */     //   149: new 160	com/mysql/jdbc/StatementImpl$CancelTask
/*      */     //   152: dup
/*      */     //   153: aload_0
/*      */     //   154: aload 7
/*      */     //   156: checkcast 161	com/mysql/jdbc/StatementImpl
/*      */     //   159: invokespecial 162	com/mysql/jdbc/StatementImpl$CancelTask:<init>	(Lcom/mysql/jdbc/StatementImpl;Lcom/mysql/jdbc/StatementImpl;)V
/*      */     //   162: astore 12
/*      */     //   164: aload 4
/*      */     //   166: invokeinterface 163 1 0
/*      */     //   171: aload 12
/*      */     //   173: iload_1
/*      */     //   174: i2l
/*      */     //   175: invokevirtual 164	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
/*      */     //   178: iload 5
/*      */     //   180: iload 6
/*      */     //   182: if_icmpge +10 -> 192
/*      */     //   185: iload 5
/*      */     //   187: istore 10
/*      */     //   189: goto +10 -> 199
/*      */     //   192: iload 5
/*      */     //   194: iload 6
/*      */     //   196: idiv
/*      */     //   197: istore 10
/*      */     //   199: iload 10
/*      */     //   201: iload 6
/*      */     //   203: imul
/*      */     //   204: istore 15
/*      */     //   206: iconst_0
/*      */     //   207: istore 16
/*      */     //   209: iload 16
/*      */     //   211: iload 15
/*      */     //   213: if_icmpge +95 -> 308
/*      */     //   216: iload 16
/*      */     //   218: ifeq +60 -> 278
/*      */     //   221: iload 16
/*      */     //   223: iload 6
/*      */     //   225: irem
/*      */     //   226: ifne +52 -> 278
/*      */     //   229: iload 9
/*      */     //   231: aload 7
/*      */     //   233: invokeinterface 187 1 0
/*      */     //   238: iadd
/*      */     //   239: istore 9
/*      */     //   241: goto +21 -> 262
/*      */     //   244: astore 17
/*      */     //   246: aload_0
/*      */     //   247: iload 11
/*      */     //   249: iconst_1
/*      */     //   250: isub
/*      */     //   251: iload 6
/*      */     //   253: aload 14
/*      */     //   255: aload 17
/*      */     //   257: invokevirtual 166	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   260: astore 13
/*      */     //   262: aload_0
/*      */     //   263: aload 7
/*      */     //   265: invokevirtual 188	com/mysql/jdbc/PreparedStatement:getBatchedGeneratedKeys	(Ljava/sql/Statement;)V
/*      */     //   268: aload 7
/*      */     //   270: invokeinterface 168 1 0
/*      */     //   275: iconst_1
/*      */     //   276: istore 8
/*      */     //   278: aload_0
/*      */     //   279: aload 7
/*      */     //   281: iload 8
/*      */     //   283: aload_0
/*      */     //   284: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   287: iload 11
/*      */     //   289: iinc 11 1
/*      */     //   292: invokeinterface 77 2 0
/*      */     //   297: invokevirtual 169	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   300: istore 8
/*      */     //   302: iinc 16 1
/*      */     //   305: goto -96 -> 209
/*      */     //   308: iload 9
/*      */     //   310: aload 7
/*      */     //   312: invokeinterface 187 1 0
/*      */     //   317: iadd
/*      */     //   318: istore 9
/*      */     //   320: goto +21 -> 341
/*      */     //   323: astore 16
/*      */     //   325: aload_0
/*      */     //   326: iload 11
/*      */     //   328: iconst_1
/*      */     //   329: isub
/*      */     //   330: iload 6
/*      */     //   332: aload 14
/*      */     //   334: aload 16
/*      */     //   336: invokevirtual 166	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   339: astore 13
/*      */     //   341: aload_0
/*      */     //   342: aload 7
/*      */     //   344: invokevirtual 188	com/mysql/jdbc/PreparedStatement:getBatchedGeneratedKeys	(Ljava/sql/Statement;)V
/*      */     //   347: iload 5
/*      */     //   349: iload 11
/*      */     //   351: isub
/*      */     //   352: istore 6
/*      */     //   354: jsr +14 -> 368
/*      */     //   357: goto +30 -> 387
/*      */     //   360: astore 18
/*      */     //   362: jsr +6 -> 368
/*      */     //   365: aload 18
/*      */     //   367: athrow
/*      */     //   368: astore 19
/*      */     //   370: aload 7
/*      */     //   372: ifnull +13 -> 385
/*      */     //   375: aload 7
/*      */     //   377: invokeinterface 170 1 0
/*      */     //   382: aconst_null
/*      */     //   383: astore 7
/*      */     //   385: ret 19
/*      */     //   387: iload 6
/*      */     //   389: ifle +104 -> 493
/*      */     //   392: aload_0
/*      */     //   393: aload 4
/*      */     //   395: iload 6
/*      */     //   397: invokevirtual 186	com/mysql/jdbc/PreparedStatement:prepareBatchedInsertSQL	(Lcom/mysql/jdbc/MySQLConnection;I)Lcom/mysql/jdbc/PreparedStatement;
/*      */     //   400: astore 7
/*      */     //   402: aload 12
/*      */     //   404: ifnull +13 -> 417
/*      */     //   407: aload 12
/*      */     //   409: aload 7
/*      */     //   411: checkcast 161	com/mysql/jdbc/StatementImpl
/*      */     //   414: putfield 171	com/mysql/jdbc/StatementImpl$CancelTask:toCancel	Lcom/mysql/jdbc/StatementImpl;
/*      */     //   417: iconst_1
/*      */     //   418: istore 8
/*      */     //   420: iload 11
/*      */     //   422: iload 5
/*      */     //   424: if_icmpge +30 -> 454
/*      */     //   427: aload_0
/*      */     //   428: aload 7
/*      */     //   430: iload 8
/*      */     //   432: aload_0
/*      */     //   433: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   436: iload 11
/*      */     //   438: iinc 11 1
/*      */     //   441: invokeinterface 77 2 0
/*      */     //   446: invokevirtual 169	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   449: istore 8
/*      */     //   451: goto -31 -> 420
/*      */     //   454: iload 9
/*      */     //   456: aload 7
/*      */     //   458: invokeinterface 187 1 0
/*      */     //   463: iadd
/*      */     //   464: istore 9
/*      */     //   466: goto +21 -> 487
/*      */     //   469: astore 15
/*      */     //   471: aload_0
/*      */     //   472: iload 11
/*      */     //   474: iconst_1
/*      */     //   475: isub
/*      */     //   476: iload 6
/*      */     //   478: aload 14
/*      */     //   480: aload 15
/*      */     //   482: invokevirtual 166	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   485: astore 13
/*      */     //   487: aload_0
/*      */     //   488: aload 7
/*      */     //   490: invokevirtual 188	com/mysql/jdbc/PreparedStatement:getBatchedGeneratedKeys	(Ljava/sql/Statement;)V
/*      */     //   493: aload 13
/*      */     //   495: ifnull +40 -> 535
/*      */     //   498: new 175	java/sql/BatchUpdateException
/*      */     //   501: dup
/*      */     //   502: aload 13
/*      */     //   504: invokevirtual 176	java/sql/SQLException:getMessage	()Ljava/lang/String;
/*      */     //   507: aload 13
/*      */     //   509: invokevirtual 177	java/sql/SQLException:getSQLState	()Ljava/lang/String;
/*      */     //   512: aload 13
/*      */     //   514: invokevirtual 178	java/sql/SQLException:getErrorCode	()I
/*      */     //   517: aload 14
/*      */     //   519: invokespecial 179	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
/*      */     //   522: astore 15
/*      */     //   524: aload 15
/*      */     //   526: aload 13
/*      */     //   528: invokevirtual 180	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   531: pop
/*      */     //   532: aload 15
/*      */     //   534: athrow
/*      */     //   535: iload 5
/*      */     //   537: iconst_1
/*      */     //   538: if_icmple +42 -> 580
/*      */     //   541: iload 9
/*      */     //   543: ifle +8 -> 551
/*      */     //   546: bipush -2
/*      */     //   548: goto +4 -> 552
/*      */     //   551: iconst_0
/*      */     //   552: istore 15
/*      */     //   554: iconst_0
/*      */     //   555: istore 16
/*      */     //   557: iload 16
/*      */     //   559: iload 5
/*      */     //   561: if_icmpge +16 -> 577
/*      */     //   564: aload 14
/*      */     //   566: iload 16
/*      */     //   568: iload 15
/*      */     //   570: iastore
/*      */     //   571: iinc 16 1
/*      */     //   574: goto -17 -> 557
/*      */     //   577: goto +9 -> 586
/*      */     //   580: aload 14
/*      */     //   582: iconst_0
/*      */     //   583: iload 9
/*      */     //   585: iastore
/*      */     //   586: aload 14
/*      */     //   588: astore 15
/*      */     //   590: jsr +19 -> 609
/*      */     //   593: jsr +40 -> 633
/*      */     //   596: aload_2
/*      */     //   597: monitorexit
/*      */     //   598: aload 15
/*      */     //   600: areturn
/*      */     //   601: astore 20
/*      */     //   603: jsr +6 -> 609
/*      */     //   606: aload 20
/*      */     //   608: athrow
/*      */     //   609: astore 21
/*      */     //   611: aload 7
/*      */     //   613: ifnull +10 -> 623
/*      */     //   616: aload 7
/*      */     //   618: invokeinterface 170 1 0
/*      */     //   623: ret 21
/*      */     //   625: astore 22
/*      */     //   627: jsr +6 -> 633
/*      */     //   630: aload 22
/*      */     //   632: athrow
/*      */     //   633: astore 23
/*      */     //   635: aload 12
/*      */     //   637: ifnull +20 -> 657
/*      */     //   640: aload 12
/*      */     //   642: invokevirtual 173	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
/*      */     //   645: pop
/*      */     //   646: aload 4
/*      */     //   648: invokeinterface 163 1 0
/*      */     //   653: invokevirtual 174	java/util/Timer:purge	()I
/*      */     //   656: pop
/*      */     //   657: aload_0
/*      */     //   658: invokevirtual 137	com/mysql/jdbc/PreparedStatement:resetCancelledState	()V
/*      */     //   661: ret 23
/*      */     //   663: astore 24
/*      */     //   665: aload_2
/*      */     //   666: monitorexit
/*      */     //   667: aload 24
/*      */     //   669: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1490	-> byte code offset #0
/*      */     //   Java source line #1491	-> byte code offset #12
/*      */     //   Java source line #1493	-> byte code offset #17
/*      */     //   Java source line #1495	-> byte code offset #23
/*      */     //   Java source line #1496	-> byte code offset #27
/*      */     //   Java source line #1499	-> byte code offset #35
/*      */     //   Java source line #1501	-> byte code offset #46
/*      */     //   Java source line #1502	-> byte code offset #53
/*      */     //   Java source line #1505	-> byte code offset #66
/*      */     //   Java source line #1507	-> byte code offset #74
/*      */     //   Java source line #1508	-> byte code offset #81
/*      */     //   Java source line #1511	-> byte code offset #85
/*      */     //   Java source line #1513	-> byte code offset #88
/*      */     //   Java source line #1514	-> byte code offset #91
/*      */     //   Java source line #1515	-> byte code offset #94
/*      */     //   Java source line #1516	-> byte code offset #97
/*      */     //   Java source line #1517	-> byte code offset #100
/*      */     //   Java source line #1518	-> byte code offset #103
/*      */     //   Java source line #1520	-> byte code offset #106
/*      */     //   Java source line #1524	-> byte code offset #112
/*      */     //   Java source line #1527	-> byte code offset #122
/*      */     //   Java source line #1528	-> byte code offset #149
/*      */     //   Java source line #1529	-> byte code offset #164
/*      */     //   Java source line #1532	-> byte code offset #178
/*      */     //   Java source line #1533	-> byte code offset #185
/*      */     //   Java source line #1535	-> byte code offset #192
/*      */     //   Java source line #1538	-> byte code offset #199
/*      */     //   Java source line #1540	-> byte code offset #206
/*      */     //   Java source line #1541	-> byte code offset #216
/*      */     //   Java source line #1543	-> byte code offset #229
/*      */     //   Java source line #1546	-> byte code offset #241
/*      */     //   Java source line #1544	-> byte code offset #244
/*      */     //   Java source line #1545	-> byte code offset #246
/*      */     //   Java source line #1548	-> byte code offset #262
/*      */     //   Java source line #1549	-> byte code offset #268
/*      */     //   Java source line #1550	-> byte code offset #275
/*      */     //   Java source line #1554	-> byte code offset #278
/*      */     //   Java source line #1540	-> byte code offset #302
/*      */     //   Java source line #1558	-> byte code offset #308
/*      */     //   Java source line #1561	-> byte code offset #320
/*      */     //   Java source line #1559	-> byte code offset #323
/*      */     //   Java source line #1560	-> byte code offset #325
/*      */     //   Java source line #1563	-> byte code offset #341
/*      */     //   Java source line #1565	-> byte code offset #347
/*      */     //   Java source line #1566	-> byte code offset #354
/*      */     //   Java source line #1571	-> byte code offset #357
/*      */     //   Java source line #1567	-> byte code offset #360
/*      */     //   Java source line #1568	-> byte code offset #375
/*      */     //   Java source line #1569	-> byte code offset #382
/*      */     //   Java source line #1574	-> byte code offset #387
/*      */     //   Java source line #1575	-> byte code offset #392
/*      */     //   Java source line #1577	-> byte code offset #402
/*      */     //   Java source line #1578	-> byte code offset #407
/*      */     //   Java source line #1581	-> byte code offset #417
/*      */     //   Java source line #1583	-> byte code offset #420
/*      */     //   Java source line #1584	-> byte code offset #427
/*      */     //   Java source line #1588	-> byte code offset #454
/*      */     //   Java source line #1591	-> byte code offset #466
/*      */     //   Java source line #1589	-> byte code offset #469
/*      */     //   Java source line #1590	-> byte code offset #471
/*      */     //   Java source line #1593	-> byte code offset #487
/*      */     //   Java source line #1596	-> byte code offset #493
/*      */     //   Java source line #1597	-> byte code offset #498
/*      */     //   Java source line #1599	-> byte code offset #524
/*      */     //   Java source line #1600	-> byte code offset #532
/*      */     //   Java source line #1603	-> byte code offset #535
/*      */     //   Java source line #1604	-> byte code offset #541
/*      */     //   Java source line #1605	-> byte code offset #554
/*      */     //   Java source line #1606	-> byte code offset #564
/*      */     //   Java source line #1605	-> byte code offset #571
/*      */     //   Java source line #1608	-> byte code offset #577
/*      */     //   Java source line #1609	-> byte code offset #580
/*      */     //   Java source line #1611	-> byte code offset #586
/*      */     //   Java source line #1613	-> byte code offset #601
/*      */     //   Java source line #1614	-> byte code offset #616
/*      */     //   Java source line #1618	-> byte code offset #625
/*      */     //   Java source line #1619	-> byte code offset #640
/*      */     //   Java source line #1620	-> byte code offset #646
/*      */     //   Java source line #1623	-> byte code offset #657
/*      */     //   Java source line #1625	-> byte code offset #663
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	670	0	this	PreparedStatement
/*      */     //   0	670	1	batchTimeout	int
/*      */     //   10	656	2	Ljava/lang/Object;	Object
/*      */     //   16	8	3	valuesClause	String
/*      */     //   21	626	4	locallyScopedConn	MySQLConnection
/*      */     //   44	516	5	numBatchedArgs	int
/*      */     //   72	405	6	numValuesPerBatch	int
/*      */     //   86	531	7	batchedStatement	java.sql.PreparedStatement
/*      */     //   89	361	8	batchedParamIndex	int
/*      */     //   92	492	9	updateCountRunningTotal	int
/*      */     //   95	105	10	numberToExecuteAsMultiValue	int
/*      */     //   98	375	11	batchCounter	int
/*      */     //   101	540	12	timeoutTask	StatementImpl.CancelTask
/*      */     //   104	423	13	sqlEx	SQLException
/*      */     //   110	477	14	updateCounts	int[]
/*      */     //   204	8	15	numberArgsToExecute	int
/*      */     //   469	12	15	ex	SQLException
/*      */     //   522	11	15	batchUpdateException	SQLException
/*      */     //   552	47	15	updCount	int
/*      */     //   207	96	16	i	int
/*      */     //   323	12	16	ex	SQLException
/*      */     //   555	17	16	j	int
/*      */     //   244	12	17	ex	SQLException
/*      */     //   360	6	18	localObject1	Object
/*      */     //   368	1	19	localObject2	Object
/*      */     //   601	6	20	localObject3	Object
/*      */     //   609	1	21	localObject4	Object
/*      */     //   625	6	22	localObject5	Object
/*      */     //   633	1	23	localObject6	Object
/*      */     //   663	5	24	localObject7	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   229	241	244	java/sql/SQLException
/*      */     //   308	320	323	java/sql/SQLException
/*      */     //   112	357	360	finally
/*      */     //   360	365	360	finally
/*      */     //   454	466	469	java/sql/SQLException
/*      */     //   387	593	601	finally
/*      */     //   601	606	601	finally
/*      */     //   112	596	625	finally
/*      */     //   601	630	625	finally
/*      */     //   12	34	663	finally
/*      */     //   35	598	663	finally
/*      */     //   601	667	663	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected Buffer fillSendPacket()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 62	com/mysql/jdbc/PreparedStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 63 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: aload_0
/*      */     //   14: getfield 24	com/mysql/jdbc/PreparedStatement:parameterValues	[[B
/*      */     //   17: aload_0
/*      */     //   18: getfield 22	com/mysql/jdbc/PreparedStatement:parameterStreams	[Ljava/io/InputStream;
/*      */     //   21: aload_0
/*      */     //   22: getfield 19	com/mysql/jdbc/PreparedStatement:isStream	[Z
/*      */     //   25: aload_0
/*      */     //   26: getfield 28	com/mysql/jdbc/PreparedStatement:streamLengths	[I
/*      */     //   29: invokevirtual 237	com/mysql/jdbc/PreparedStatement:fillSendPacket	([[B[Ljava/io/InputStream;[Z[I)Lcom/mysql/jdbc/Buffer;
/*      */     //   32: aload_1
/*      */     //   33: monitorexit
/*      */     //   34: areturn
/*      */     //   35: astore_2
/*      */     //   36: aload_1
/*      */     //   37: monitorexit
/*      */     //   38: aload_2
/*      */     //   39: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2162	-> byte code offset #0
/*      */     //   Java source line #2163	-> byte code offset #12
/*      */     //   Java source line #2164	-> byte code offset #35
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	40	0	this	PreparedStatement
/*      */     //   10	27	1	Ljava/lang/Object;	Object
/*      */     //   35	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	34	35	finally
/*      */     //   35	38	35	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected boolean isSelectQuery()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 62	com/mysql/jdbc/PreparedStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 63 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 21	com/mysql/jdbc/PreparedStatement:originalSql	Ljava/lang/String;
/*      */     //   16: ldc_w 308
/*      */     //   19: ldc_w 308
/*      */     //   22: iconst_1
/*      */     //   23: iconst_0
/*      */     //   24: iconst_1
/*      */     //   25: iconst_1
/*      */     //   26: invokestatic 309	com/mysql/jdbc/StringUtils:stripComments	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZ)Ljava/lang/String;
/*      */     //   29: ldc_w 310
/*      */     //   32: invokestatic 311	com/mysql/jdbc/StringUtils:startsWithIgnoreCaseAndWs	(Ljava/lang/String;Ljava/lang/String;)Z
/*      */     //   35: aload_1
/*      */     //   36: monitorexit
/*      */     //   37: ireturn
/*      */     //   38: astore_2
/*      */     //   39: aload_1
/*      */     //   40: monitorexit
/*      */     //   41: aload_2
/*      */     //   42: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2610	-> byte code offset #0
/*      */     //   Java source line #2611	-> byte code offset #12
/*      */     //   Java source line #2612	-> byte code offset #38
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	43	0	this	PreparedStatement
/*      */     //   10	30	1	Ljava/lang/Object;	Object
/*      */     //   38	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	37	38	finally
/*      */     //   38	41	38	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   boolean isNull(int paramIndex)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 62	com/mysql/jdbc/PreparedStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 63 1 0
/*      */     //   9: dup
/*      */     //   10: astore_2
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 18	com/mysql/jdbc/PreparedStatement:isNull	[Z
/*      */     //   16: iload_1
/*      */     //   17: baload
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: ireturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2685	-> byte code offset #0
/*      */     //   Java source line #2686	-> byte code offset #12
/*      */     //   Java source line #2687	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	PreparedStatement
/*      */     //   0	26	1	paramIndex	int
/*      */     //   10	13	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ParameterBindings getParameterBindings()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 62	com/mysql/jdbc/PreparedStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 63 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: new 569	com/mysql/jdbc/PreparedStatement$EmulatedPreparedStatementBindings
/*      */     //   15: dup
/*      */     //   16: aload_0
/*      */     //   17: invokespecial 570	com/mysql/jdbc/PreparedStatement$EmulatedPreparedStatementBindings:<init>	(Lcom/mysql/jdbc/PreparedStatement;)V
/*      */     //   20: aload_1
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_2
/*      */     //   24: aload_1
/*      */     //   25: monitorexit
/*      */     //   26: aload_2
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #4911	-> byte code offset #0
/*      */     //   Java source line #4912	-> byte code offset #12
/*      */     //   Java source line #4913	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	PreparedStatement
/*      */     //   10	15	1	Ljava/lang/Object;	Object
/*      */     //   23	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String getPreparedSql()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 62	com/mysql/jdbc/PreparedStatement:checkClosed	()Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface 63 1 0
/*      */     //   9: dup
/*      */     //   10: astore_1
/*      */     //   11: monitorenter
/*      */     //   12: aload_0
/*      */     //   13: getfield 33	com/mysql/jdbc/PreparedStatement:rewrittenBatchSize	I
/*      */     //   16: ifne +10 -> 26
/*      */     //   19: aload_0
/*      */     //   20: getfield 21	com/mysql/jdbc/PreparedStatement:originalSql	Ljava/lang/String;
/*      */     //   23: aload_1
/*      */     //   24: monitorexit
/*      */     //   25: areturn
/*      */     //   26: aload_0
/*      */     //   27: getfield 52	com/mysql/jdbc/PreparedStatement:parseInfo	Lcom/mysql/jdbc/PreparedStatement$ParseInfo;
/*      */     //   30: aload_0
/*      */     //   31: getfield 52	com/mysql/jdbc/PreparedStatement:parseInfo	Lcom/mysql/jdbc/PreparedStatement$ParseInfo;
/*      */     //   34: invokevirtual 571	com/mysql/jdbc/PreparedStatement$ParseInfo:getSqlForBatch	(Lcom/mysql/jdbc/PreparedStatement$ParseInfo;)Ljava/lang/String;
/*      */     //   37: aload_1
/*      */     //   38: monitorexit
/*      */     //   39: areturn
/*      */     //   40: astore_2
/*      */     //   41: new 91	java/lang/RuntimeException
/*      */     //   44: dup
/*      */     //   45: aload_2
/*      */     //   46: invokespecial 572	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   49: athrow
/*      */     //   50: astore_3
/*      */     //   51: aload_1
/*      */     //   52: monitorexit
/*      */     //   53: aload_3
/*      */     //   54: athrow
/*      */     //   55: astore_1
/*      */     //   56: new 91	java/lang/RuntimeException
/*      */     //   59: dup
/*      */     //   60: aload_1
/*      */     //   61: invokespecial 572	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   64: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5092	-> byte code offset #0
/*      */     //   Java source line #5093	-> byte code offset #12
/*      */     //   Java source line #5094	-> byte code offset #19
/*      */     //   Java source line #5098	-> byte code offset #26
/*      */     //   Java source line #5099	-> byte code offset #40
/*      */     //   Java source line #5100	-> byte code offset #41
/*      */     //   Java source line #5102	-> byte code offset #50
/*      */     //   Java source line #5103	-> byte code offset #55
/*      */     //   Java source line #5104	-> byte code offset #56
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	65	0	this	PreparedStatement
/*      */     //   55	6	1	e	SQLException
/*      */     //   40	6	2	e	UnsupportedEncodingException
/*      */     //   50	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   26	37	40	java/io/UnsupportedEncodingException
/*      */     //   12	25	50	finally
/*      */     //   26	39	50	finally
/*      */     //   40	53	50	finally
/*      */     //   0	25	55	java/sql/SQLException
/*      */     //   26	39	55	java/sql/SQLException
/*      */     //   40	55	55	java/sql/SQLException
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/PreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */