/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.charset.Charset;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   private static Method CAST_METHOD;
/*  64 */   private static Util enclosingInstance = new Util();
/*     */   
/*  66 */   private static boolean isJdbc4 = false;
/*     */   
/*  68 */   private static int jvmVersion = -1;
/*     */   
/*  70 */   private static boolean isColdFusion = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final ConcurrentMap<Class<?>, Boolean> isJdbcInterfaceCache;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String MYSQL_JDBC_PACKAGE_ROOT;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isJdbc4()
/*     */   {
/* 118 */     return isJdbc4;
/*     */   }
/*     */   
/*     */   public static int getJVMVersion() {
/* 122 */     return jvmVersion;
/*     */   }
/*     */   
/*     */   public static boolean isColdFusion() {
/* 126 */     return isColdFusion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isCommunityEdition(String serverVersion)
/*     */   {
/* 133 */     return !isEnterpriseEdition(serverVersion);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isEnterpriseEdition(String serverVersion)
/*     */   {
/* 140 */     return (serverVersion.contains("enterprise")) || (serverVersion.contains("commercial")) || (serverVersion.contains("advanced"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String newCrypt(String password, String seed, String encoding)
/*     */   {
/* 148 */     if ((password == null) || (password.length() == 0)) {
/* 149 */       return password;
/*     */     }
/*     */     
/* 152 */     long[] pw = newHash(seed.getBytes());
/* 153 */     long[] msg = hashPre41Password(password, encoding);
/* 154 */     long max = 1073741823L;
/* 155 */     long seed1 = (pw[0] ^ msg[0]) % max;
/* 156 */     long seed2 = (pw[1] ^ msg[1]) % max;
/* 157 */     char[] chars = new char[seed.length()];
/*     */     
/* 159 */     for (int i = 0; i < seed.length(); i++) {
/* 160 */       seed1 = (seed1 * 3L + seed2) % max;
/* 161 */       seed2 = (seed1 + seed2 + 33L) % max;
/* 162 */       double d = seed1 / max;
/* 163 */       byte b = (byte)(int)Math.floor(d * 31.0D + 64.0D);
/* 164 */       chars[i] = ((char)b);
/*     */     }
/*     */     
/* 167 */     seed1 = (seed1 * 3L + seed2) % max;
/* 168 */     seed2 = (seed1 + seed2 + 33L) % max;
/* 169 */     double d = seed1 / max;
/* 170 */     byte b = (byte)(int)Math.floor(d * 31.0D);
/*     */     
/* 172 */     for (int i = 0; i < seed.length(); tmp213_211++) {
/* 173 */       int tmp213_211 = i; char[] tmp213_209 = chars;tmp213_209[tmp213_211] = ((char)(tmp213_209[tmp213_211] ^ (char)b));
/*     */     }
/*     */     
/* 176 */     return new String(chars);
/*     */   }
/*     */   
/*     */   public static long[] hashPre41Password(String password, String encoding)
/*     */   {
/*     */     try {
/* 182 */       return newHash(password.replaceAll("\\s", "").getBytes(encoding));
/*     */     } catch (UnsupportedEncodingException e) {}
/* 184 */     return new long[0];
/*     */   }
/*     */   
/*     */   public static long[] hashPre41Password(String password)
/*     */   {
/* 189 */     return hashPre41Password(password, Charset.defaultCharset().name());
/*     */   }
/*     */   
/*     */   static long[] newHash(byte[] password) {
/* 193 */     long nr = 1345345333L;
/* 194 */     long add = 7L;
/* 195 */     long nr2 = 305419889L;
/*     */     
/*     */ 
/* 198 */     for (byte b : password) {
/* 199 */       long tmp = 0xFF & b;
/* 200 */       nr ^= ((nr & 0x3F) + add) * tmp + (nr << 8);
/* 201 */       nr2 += (nr2 << 8 ^ nr);
/* 202 */       add += tmp;
/*     */     }
/*     */     
/* 205 */     long[] result = new long[2];
/* 206 */     result[0] = (nr & 0x7FFFFFFF);
/* 207 */     result[1] = (nr2 & 0x7FFFFFFF);
/*     */     
/* 209 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String oldCrypt(String password, String seed)
/*     */   {
/* 217 */     long max = 33554431L;
/*     */     
/*     */ 
/*     */ 
/* 221 */     if ((password == null) || (password.length() == 0)) {
/* 222 */       return password;
/*     */     }
/*     */     
/* 225 */     long hp = oldHash(seed);
/* 226 */     long hm = oldHash(password);
/*     */     
/* 228 */     long nr = hp ^ hm;
/* 229 */     nr %= max;
/* 230 */     long s1 = nr;
/* 231 */     long s2 = nr / 2L;
/*     */     
/* 233 */     char[] chars = new char[seed.length()];
/*     */     
/* 235 */     for (int i = 0; i < seed.length(); i++) {
/* 236 */       s1 = (s1 * 3L + s2) % max;
/* 237 */       s2 = (s1 + s2 + 33L) % max;
/* 238 */       double d = s1 / max;
/* 239 */       byte b = (byte)(int)Math.floor(d * 31.0D + 64.0D);
/* 240 */       chars[i] = ((char)b);
/*     */     }
/*     */     
/* 243 */     return new String(chars);
/*     */   }
/*     */   
/*     */   static long oldHash(String password) {
/* 247 */     long nr = 1345345333L;
/* 248 */     long nr2 = 7L;
/*     */     
/*     */ 
/* 251 */     for (int i = 0; i < password.length(); i++) {
/* 252 */       if ((password.charAt(i) != ' ') && (password.charAt(i) != '\t'))
/*     */       {
/*     */ 
/*     */ 
/* 256 */         long tmp = password.charAt(i);
/* 257 */         nr ^= ((nr & 0x3F) + nr2) * tmp + (nr << 8);
/* 258 */         nr2 += tmp;
/*     */       }
/*     */     }
/* 261 */     return nr & 0x7FFFFFFF;
/*     */   }
/*     */   
/*     */   private static RandStructcture randomInit(long seed1, long seed2) {
/* 265 */     Util tmp7_4 = enclosingInstance;tmp7_4.getClass();RandStructcture randStruct = new RandStructcture(tmp7_4);
/*     */     
/* 267 */     randStruct.maxValue = 1073741823L;
/* 268 */     randStruct.maxValueDbl = randStruct.maxValue;
/* 269 */     randStruct.seed1 = (seed1 % randStruct.maxValue);
/* 270 */     randStruct.seed2 = (seed2 % randStruct.maxValue);
/*     */     
/* 272 */     return randStruct;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object readObject(ResultSet resultSet, int index)
/*     */     throws Exception
/*     */   {
/* 289 */     ObjectInputStream objIn = new ObjectInputStream(resultSet.getBinaryStream(index));
/* 290 */     Object obj = objIn.readObject();
/* 291 */     objIn.close();
/*     */     
/* 293 */     return obj;
/*     */   }
/*     */   
/*     */   private static double rnd(RandStructcture randStruct) {
/* 297 */     randStruct.seed1 = ((randStruct.seed1 * 3L + randStruct.seed2) % randStruct.maxValue);
/* 298 */     randStruct.seed2 = ((randStruct.seed1 + randStruct.seed2 + 33L) % randStruct.maxValue);
/*     */     
/* 300 */     return randStruct.seed1 / randStruct.maxValueDbl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String scramble(String message, String password)
/*     */   {
/* 310 */     byte[] to = new byte[8];
/* 311 */     String val = "";
/*     */     
/* 313 */     message = message.substring(0, 8);
/*     */     
/* 315 */     if ((password != null) && (password.length() > 0)) {
/* 316 */       long[] hashPass = hashPre41Password(password);
/* 317 */       long[] hashMessage = newHash(message.getBytes());
/*     */       
/* 319 */       RandStructcture randStruct = randomInit(hashPass[0] ^ hashMessage[0], hashPass[1] ^ hashMessage[1]);
/*     */       
/* 321 */       int msgPos = 0;
/* 322 */       int msgLength = message.length();
/* 323 */       int toPos = 0;
/*     */       
/* 325 */       while (msgPos++ < msgLength) {
/* 326 */         to[(toPos++)] = ((byte)(int)(Math.floor(rnd(randStruct) * 31.0D) + 64.0D));
/*     */       }
/*     */       
/*     */ 
/* 330 */       byte extra = (byte)(int)Math.floor(rnd(randStruct) * 31.0D);
/*     */       
/* 332 */       for (int i = 0; i < to.length; i++) {
/* 333 */         int tmp143_141 = i; byte[] tmp143_139 = to;tmp143_139[tmp143_141] = ((byte)(tmp143_139[tmp143_141] ^ extra));
/*     */       }
/*     */       
/* 336 */       val = StringUtils.toString(to);
/*     */     }
/*     */     
/* 339 */     return val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String stackTraceToString(Throwable ex)
/*     */   {
/* 352 */     StringBuilder traceBuf = new StringBuilder();
/* 353 */     traceBuf.append(Messages.getString("Util.1"));
/*     */     
/* 355 */     if (ex != null) {
/* 356 */       traceBuf.append(ex.getClass().getName());
/*     */       
/* 358 */       String message = ex.getMessage();
/*     */       
/* 360 */       if (message != null) {
/* 361 */         traceBuf.append(Messages.getString("Util.2"));
/* 362 */         traceBuf.append(message);
/*     */       }
/*     */       
/* 365 */       StringWriter out = new StringWriter();
/*     */       
/* 367 */       PrintWriter printOut = new PrintWriter(out);
/*     */       
/* 369 */       ex.printStackTrace(printOut);
/*     */       
/* 371 */       traceBuf.append(Messages.getString("Util.3"));
/* 372 */       traceBuf.append(out.toString());
/*     */     }
/*     */     
/* 375 */     traceBuf.append(Messages.getString("Util.4"));
/*     */     
/* 377 */     return traceBuf.toString();
/*     */   }
/*     */   
/*     */   public static Object getInstance(String className, Class<?>[] argTypes, Object[] args, ExceptionInterceptor exceptionInterceptor) throws SQLException
/*     */   {
/*     */     try {
/* 383 */       return handleNewInstance(Class.forName(className).getConstructor(argTypes), args, exceptionInterceptor);
/*     */     } catch (SecurityException e) {
/* 385 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/*     */     } catch (NoSuchMethodException e) {
/* 387 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/*     */     } catch (ClassNotFoundException e) {
/* 389 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final Object handleNewInstance(Constructor<?> ctor, Object[] args, ExceptionInterceptor exceptionInterceptor)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 400 */       return ctor.newInstance(args);
/*     */     } catch (IllegalArgumentException e) {
/* 402 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/*     */     } catch (InstantiationException e) {
/* 404 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/*     */     } catch (IllegalAccessException e) {
/* 406 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/*     */     } catch (InvocationTargetException e) {
/* 408 */       Throwable target = e.getTargetException();
/*     */       
/* 410 */       if ((target instanceof SQLException)) {
/* 411 */         throw ((SQLException)target);
/*     */       }
/*     */       
/* 414 */       if ((target instanceof ExceptionInInitializerError)) {
/* 415 */         target = ((ExceptionInInitializerError)target).getException();
/*     */       }
/*     */       
/* 418 */       throw SQLError.createSQLException(target.toString(), "S1000", target, exceptionInterceptor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean interfaceExists(String hostname)
/*     */   {
/*     */     try
/*     */     {
/* 432 */       Class<?> networkInterfaceClass = Class.forName("java.net.NetworkInterface");
/* 433 */       return networkInterfaceClass.getMethod("getByName", (Class[])null).invoke(networkInterfaceClass, new Object[] { hostname }) != null;
/*     */     } catch (Throwable t) {}
/* 435 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object cast(Object invokeOn, Object toCast)
/*     */   {
/* 448 */     if (CAST_METHOD != null) {
/*     */       try {
/* 450 */         return CAST_METHOD.invoke(invokeOn, new Object[] { toCast });
/*     */       } catch (Throwable t) {
/* 452 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 456 */     return null;
/*     */   }
/*     */   
/*     */   public static void resultSetToMap(Map mappedValues, ResultSet rs) throws SQLException
/*     */   {
/* 461 */     while (rs.next()) {
/* 462 */       mappedValues.put(rs.getObject(1), rs.getObject(2));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void resultSetToMap(Map mappedValues, ResultSet rs, int key, int value) throws SQLException
/*     */   {
/* 468 */     while (rs.next()) {
/* 469 */       mappedValues.put(rs.getObject(key), rs.getObject(value));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void resultSetToMap(Map mappedValues, ResultSet rs, String key, String value) throws SQLException
/*     */   {
/* 475 */     while (rs.next()) {
/* 476 */       mappedValues.put(rs.getObject(key), rs.getObject(value));
/*     */     }
/*     */   }
/*     */   
/*     */   public static Map<Object, Object> calculateDifferences(Map<?, ?> map1, Map<?, ?> map2) {
/* 481 */     Map<Object, Object> diffMap = new HashMap();
/*     */     
/* 483 */     for (Map.Entry<?, ?> entry : map1.entrySet()) {
/* 484 */       Object key = entry.getKey();
/*     */       
/* 486 */       Number value1 = null;
/* 487 */       Number value2 = null;
/*     */       
/* 489 */       if ((entry.getValue() instanceof Number))
/*     */       {
/* 491 */         value1 = (Number)entry.getValue();
/* 492 */         value2 = (Number)map2.get(key);
/*     */       } else {
/*     */         try {
/* 495 */           value1 = new Double(entry.getValue().toString());
/* 496 */           value2 = new Double(map2.get(key).toString());
/*     */         } catch (NumberFormatException nfe) {}
/* 498 */         continue;
/*     */       }
/*     */       
/*     */ 
/* 502 */       if (!value1.equals(value2))
/*     */       {
/*     */ 
/*     */ 
/* 506 */         if ((value1 instanceof Byte)) {
/* 507 */           diffMap.put(key, Byte.valueOf((byte)(((Byte)value2).byteValue() - ((Byte)value1).byteValue())));
/* 508 */         } else if ((value1 instanceof Short)) {
/* 509 */           diffMap.put(key, Short.valueOf((short)(((Short)value2).shortValue() - ((Short)value1).shortValue())));
/* 510 */         } else if ((value1 instanceof Integer)) {
/* 511 */           diffMap.put(key, Integer.valueOf(((Integer)value2).intValue() - ((Integer)value1).intValue()));
/* 512 */         } else if ((value1 instanceof Long)) {
/* 513 */           diffMap.put(key, Long.valueOf(((Long)value2).longValue() - ((Long)value1).longValue()));
/* 514 */         } else if ((value1 instanceof Float)) {
/* 515 */           diffMap.put(key, Float.valueOf(((Float)value2).floatValue() - ((Float)value1).floatValue()));
/* 516 */         } else if ((value1 instanceof Double)) {
/* 517 */           diffMap.put(key, Double.valueOf(((Double)value2).shortValue() - ((Double)value1).shortValue()));
/* 518 */         } else if ((value1 instanceof BigDecimal)) {
/* 519 */           diffMap.put(key, ((BigDecimal)value2).subtract((BigDecimal)value1));
/* 520 */         } else if ((value1 instanceof BigInteger)) {
/* 521 */           diffMap.put(key, ((BigInteger)value2).subtract((BigInteger)value1));
/*     */         }
/*     */       }
/*     */     }
/* 525 */     return diffMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<Extension> loadExtensions(Connection conn, Properties props, String extensionClassNames, String errorMessageKey, ExceptionInterceptor exceptionInterceptor)
/*     */     throws SQLException
/*     */   {
/* 541 */     List<Extension> extensionList = new LinkedList();
/*     */     
/* 543 */     List<String> interceptorsToCreate = StringUtils.split(extensionClassNames, ",", true);
/*     */     
/* 545 */     String className = null;
/*     */     try
/*     */     {
/* 548 */       int i = 0; for (int s = interceptorsToCreate.size(); i < s; i++) {
/* 549 */         className = (String)interceptorsToCreate.get(i);
/* 550 */         Extension extensionInstance = (Extension)Class.forName(className).newInstance();
/* 551 */         extensionInstance.init(conn, props);
/*     */         
/* 553 */         extensionList.add(extensionInstance);
/*     */       }
/*     */     } catch (Throwable t) {
/* 556 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString(errorMessageKey, new Object[] { className }), exceptionInterceptor);
/* 557 */       sqlEx.initCause(t);
/*     */       
/* 559 */       throw sqlEx;
/*     */     }
/*     */     
/* 562 */     return extensionList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isJdbcInterface(Class<?> clazz)
/*     */   {
/* 575 */     if (isJdbcInterfaceCache.containsKey(clazz)) {
/* 576 */       return ((Boolean)isJdbcInterfaceCache.get(clazz)).booleanValue();
/*     */     }
/*     */     
/* 579 */     for (Class<?> iface : clazz.getInterfaces()) {
/* 580 */       String packageName = null;
/*     */       try {
/* 582 */         packageName = iface.getPackage().getName();
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */         continue;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 591 */       if (isJdbcPackage(packageName)) {
/* 592 */         isJdbcInterfaceCache.putIfAbsent(iface, Boolean.valueOf(true));
/* 593 */         isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 594 */         return true;
/*     */       }
/*     */       
/* 597 */       if (isJdbcInterface(iface)) {
/* 598 */         isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 599 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 603 */     if ((clazz.getSuperclass() != null) && (isJdbcInterface(clazz.getSuperclass()))) {
/* 604 */       isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 605 */       return true;
/*     */     }
/*     */     
/* 608 */     isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(false));
/* 609 */     return false;
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  74 */       CAST_METHOD = Class.class.getMethod("cast", new Class[] { Object.class });
/*     */     }
/*     */     catch (Throwable t) {}
/*     */     
/*     */     try
/*     */     {
/*  80 */       Class.forName("java.sql.NClob");
/*  81 */       isJdbc4 = true;
/*     */     } catch (Throwable t) {
/*  83 */       isJdbc4 = false;
/*     */     }
/*     */     
/*  86 */     String jvmVersionString = System.getProperty("java.version");
/*  87 */     int startPos = jvmVersionString.indexOf('.');
/*  88 */     int endPos = startPos + 1;
/*  89 */     if (startPos != -1) {
/*  90 */       do { if (!Character.isDigit(jvmVersionString.charAt(endPos))) break; endPos++; } while (endPos < jvmVersionString.length());
/*     */     }
/*     */     
/*     */ 
/*  94 */     startPos++;
/*  95 */     if (endPos > startPos) {
/*  96 */       jvmVersion = Integer.parseInt(jvmVersionString.substring(startPos, endPos));
/*     */     }
/*     */     else {
/*  99 */       jvmVersion = isJdbc4 ? 6 : 5;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */     String loadedFrom = stackTraceToString(new Throwable());
/*     */     
/* 110 */     if (loadedFrom != null) {
/* 111 */       isColdFusion = loadedFrom.indexOf("coldfusion") != -1;
/*     */     } else {
/* 113 */       isColdFusion = false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 566 */     isJdbcInterfaceCache = new ConcurrentHashMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 615 */     String packageName = MultiHostConnectionProxy.class.getPackage().getName();
/*     */     
/* 617 */     MYSQL_JDBC_PACKAGE_ROOT = packageName.substring(0, packageName.indexOf("jdbc") + 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isJdbcPackage(String packageName)
/*     */   {
/* 627 */     return (packageName != null) && ((packageName.startsWith("java.sql")) || (packageName.startsWith("javax.sql")) || (packageName.startsWith(MYSQL_JDBC_PACKAGE_ROOT)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 632 */   private static final ConcurrentMap<Class<?>, Class<?>[]> implementedInterfacesCache = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?>[] getImplementedInterfaces(Class<?> clazz)
/*     */   {
/* 644 */     Class<?>[] implementedInterfaces = (Class[])implementedInterfacesCache.get(clazz);
/* 645 */     if (implementedInterfaces != null) {
/* 646 */       return implementedInterfaces;
/*     */     }
/*     */     
/* 649 */     Set<Class<?>> interfaces = new LinkedHashSet();
/* 650 */     Class<?> superClass = clazz;
/*     */     do {
/* 652 */       Collections.addAll(interfaces, (Class[])superClass.getInterfaces());
/* 653 */     } while ((superClass = superClass.getSuperclass()) != null);
/*     */     
/* 655 */     implementedInterfaces = (Class[])interfaces.toArray(new Class[interfaces.size()]);
/* 656 */     implementedInterfacesCache.putIfAbsent(clazz, implementedInterfaces);
/* 657 */     return implementedInterfaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long secondsSinceMillis(long timeInMillis)
/*     */   {
/* 669 */     return (System.currentTimeMillis() - timeInMillis) / 1000L;
/*     */   }
/*     */   
/*     */   class RandStructcture
/*     */   {
/*     */     long maxValue;
/*     */     double maxValueDbl;
/*     */     long seed1;
/*     */     long seed2;
/*     */     
/*     */     RandStructcture() {}
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/Util.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */