/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.Executor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ReplicationConnection
/*      */   implements Connection, PingTarget
/*      */ {
/*      */   protected Connection currentConnection;
/*      */   protected LoadBalancedConnection masterConnection;
/*      */   protected LoadBalancedConnection slavesConnection;
/*      */   private Properties slaveProperties;
/*      */   private Properties masterProperties;
/*      */   private NonRegisteringDriver driver;
/*   59 */   private long connectionGroupID = -1L;
/*      */   
/*      */   private ReplicationConnectionGroup connectionGroup;
/*      */   
/*      */   private List<String> slaveHosts;
/*      */   
/*      */   private List<String> masterHosts;
/*      */   
/*   67 */   private boolean allowMasterDownConnections = false;
/*      */   
/*   69 */   private boolean enableJMX = false;
/*      */   
/*   71 */   private boolean readOnly = false;
/*      */   
/*      */   private MySQLConnection proxy;
/*      */   
/*      */ 
/*      */   protected ReplicationConnection() {}
/*      */   
/*      */   public ReplicationConnection(Properties masterProperties, Properties slaveProperties, List<String> masterHostList, List<String> slaveHostList)
/*      */     throws SQLException
/*      */   {
/*   81 */     String enableJMXAsString = masterProperties.getProperty("replicationEnableJMX", "false");
/*      */     try {
/*   83 */       this.enableJMX = Boolean.parseBoolean(enableJMXAsString);
/*      */     } catch (Exception e) {
/*   85 */       throw SQLError.createSQLException(Messages.getString("ReplicationConnection.badValueForReplicationEnableJMX", new Object[] { enableJMXAsString }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/*   89 */     String allowMasterDownConnectionsAsString = masterProperties.getProperty("allowMasterDownConnections", "false");
/*      */     try {
/*   91 */       this.allowMasterDownConnections = Boolean.parseBoolean(allowMasterDownConnectionsAsString);
/*      */     } catch (Exception e) {
/*   93 */       throw SQLError.createSQLException(Messages.getString("ReplicationConnection.badValueForAllowMasterDownConnections", new Object[] { enableJMXAsString }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*   98 */     String group = masterProperties.getProperty("replicationConnectionGroup", null);
/*      */     
/*  100 */     if (group != null) {
/*  101 */       this.connectionGroup = ReplicationConnectionGroupManager.getConnectionGroupInstance(group);
/*  102 */       if (this.enableJMX) {
/*  103 */         ReplicationConnectionGroupManager.registerJmx();
/*      */       }
/*  105 */       this.connectionGroupID = this.connectionGroup.registerReplicationConnection(this, masterHostList, slaveHostList);
/*      */       
/*  107 */       this.slaveHosts = new ArrayList(this.connectionGroup.getSlaveHosts());
/*  108 */       this.masterHosts = new ArrayList(this.connectionGroup.getMasterHosts());
/*      */     } else {
/*  110 */       this.slaveHosts = new ArrayList(slaveHostList);
/*  111 */       this.masterHosts = new ArrayList(masterHostList);
/*      */     }
/*      */     
/*  114 */     this.driver = new NonRegisteringDriver();
/*  115 */     this.slaveProperties = slaveProperties;
/*  116 */     this.masterProperties = masterProperties;
/*      */     
/*  118 */     boolean createdMaster = initializeMasterConnection();
/*  119 */     initializeSlaveConnection();
/*  120 */     if (!createdMaster) {
/*  121 */       this.readOnly = true;
/*  122 */       this.currentConnection = this.slavesConnection;
/*  123 */       return;
/*      */     }
/*      */     
/*  126 */     this.currentConnection = this.masterConnection;
/*      */   }
/*      */   
/*      */   private boolean initializeMasterConnection() throws SQLException {
/*  130 */     return initializeMasterConnection(this.allowMasterDownConnections);
/*      */   }
/*      */   
/*      */   public long getConnectionGroupId() {
/*  134 */     return this.connectionGroupID;
/*      */   }
/*      */   
/*      */   private boolean initializeMasterConnection(boolean allowMasterDown) throws SQLException
/*      */   {
/*  139 */     boolean isMaster = isMasterConnection();
/*      */     
/*  141 */     StringBuilder masterUrl = new StringBuilder("jdbc:mysql:loadbalance://");
/*      */     
/*  143 */     boolean firstHost = true;
/*  144 */     for (String host : this.masterHosts) {
/*  145 */       if (!firstHost) {
/*  146 */         masterUrl.append(',');
/*      */       }
/*  148 */       masterUrl.append(host);
/*  149 */       firstHost = false;
/*      */     }
/*      */     
/*  152 */     String masterDb = this.masterProperties.getProperty("DBNAME");
/*      */     
/*  154 */     masterUrl.append("/");
/*      */     
/*  156 */     if (masterDb != null) {
/*  157 */       masterUrl.append(masterDb);
/*      */     }
/*      */     
/*  160 */     LoadBalancedConnection newMasterConn = null;
/*      */     try {
/*  162 */       newMasterConn = (LoadBalancedConnection)this.driver.connect(masterUrl.toString(), this.masterProperties);
/*      */     } catch (SQLException ex) {
/*  164 */       if (allowMasterDown) {
/*  165 */         this.currentConnection = this.slavesConnection;
/*  166 */         this.masterConnection = null;
/*  167 */         this.readOnly = true;
/*  168 */         return false;
/*      */       }
/*  170 */       throw ex;
/*      */     }
/*      */     
/*  173 */     if ((isMaster) && (this.currentConnection != null)) {
/*  174 */       swapConnections(newMasterConn, this.currentConnection);
/*      */     }
/*      */     
/*  177 */     if (this.masterConnection != null) {
/*      */       try {
/*  179 */         this.masterConnection.close();
/*  180 */         this.masterConnection = null;
/*      */       }
/*      */       catch (SQLException e) {}
/*      */     }
/*      */     
/*  185 */     this.masterConnection = newMasterConn;
/*  186 */     this.masterConnection.setProxy(this.proxy);
/*  187 */     return true;
/*      */   }
/*      */   
/*      */   private void initializeSlaveConnection() throws SQLException
/*      */   {
/*  192 */     if (this.slaveHosts.size() == 0) {
/*  193 */       return;
/*      */     }
/*      */     
/*  196 */     StringBuilder slaveUrl = new StringBuilder("jdbc:mysql:loadbalance://");
/*      */     
/*  198 */     boolean firstHost = true;
/*  199 */     for (String host : this.slaveHosts) {
/*  200 */       if (!firstHost) {
/*  201 */         slaveUrl.append(',');
/*      */       }
/*  203 */       slaveUrl.append(host);
/*  204 */       firstHost = false;
/*      */     }
/*      */     
/*  207 */     String slaveDb = this.slaveProperties.getProperty("DBNAME");
/*      */     
/*  209 */     slaveUrl.append("/");
/*      */     
/*  211 */     if (slaveDb != null) {
/*  212 */       slaveUrl.append(slaveDb);
/*      */     }
/*      */     
/*  215 */     this.slavesConnection = ((LoadBalancedConnection)this.driver.connect(slaveUrl.toString(), this.slaveProperties));
/*  216 */     this.slavesConnection.setReadOnly(true);
/*  217 */     this.slavesConnection.setProxy(this.proxy);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  222 */     if ((this.currentConnection != null) && (this.currentConnection == this.masterConnection) && (this.readOnly)) {
/*  223 */       switchToSlavesConnection();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  233 */     getCurrentConnection().clearWarnings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close()
/*      */     throws SQLException
/*      */   {
/*  242 */     if (this.masterConnection != null) {
/*  243 */       this.masterConnection.close();
/*      */     }
/*  245 */     if (this.slavesConnection != null) {
/*  246 */       this.slavesConnection.close();
/*      */     }
/*      */     
/*  249 */     if (this.connectionGroup != null) {
/*  250 */       this.connectionGroup.handleCloseConnection(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void commit()
/*      */     throws SQLException
/*      */   {
/*  261 */     getCurrentConnection().commit();
/*      */   }
/*      */   
/*      */   public boolean isHostMaster(String host) {
/*  265 */     if (host == null) {
/*  266 */       return false;
/*      */     }
/*  268 */     for (String test : this.masterHosts) {
/*  269 */       if (test.equalsIgnoreCase(host)) {
/*  270 */         return true;
/*      */       }
/*      */     }
/*  273 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isHostSlave(String host) {
/*  277 */     if (host == null) {
/*  278 */       return false;
/*      */     }
/*  280 */     for (String test : this.slaveHosts) {
/*  281 */       if (test.equalsIgnoreCase(host)) {
/*  282 */         return true;
/*      */       }
/*      */     }
/*  285 */     return false;
/*      */   }
/*      */   
/*      */   public synchronized void removeSlave(String host) throws SQLException
/*      */   {
/*  290 */     removeSlave(host, true);
/*      */   }
/*      */   
/*      */   public synchronized void removeSlave(String host, boolean closeGently) throws SQLException
/*      */   {
/*  295 */     this.slaveHosts.remove(host);
/*  296 */     if ((this.slavesConnection == null) || (this.slavesConnection.isClosed())) {
/*  297 */       this.slavesConnection = null;
/*  298 */       return;
/*      */     }
/*      */     
/*  301 */     if (closeGently) {
/*  302 */       this.slavesConnection.removeHostWhenNotInUse(host);
/*      */     } else {
/*  304 */       this.slavesConnection.removeHost(host);
/*      */     }
/*      */     
/*      */ 
/*  308 */     if (this.slaveHosts.size() == 0) {
/*  309 */       switchToMasterConnection();
/*  310 */       this.slavesConnection.close();
/*  311 */       this.slavesConnection = null;
/*  312 */       setReadOnly(this.readOnly);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void addSlaveHost(String host) throws SQLException {
/*  317 */     if (isHostSlave(host))
/*      */     {
/*  319 */       return;
/*      */     }
/*  321 */     this.slaveHosts.add(host);
/*  322 */     if (this.slavesConnection == null) {
/*  323 */       initializeSlaveConnection();
/*      */     } else {
/*  325 */       this.slavesConnection.addHost(host);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void promoteSlaveToMaster(String host) throws SQLException {
/*  330 */     if (!isHostSlave(host)) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  337 */     this.masterHosts.add(host);
/*  338 */     removeSlave(host);
/*  339 */     if (this.masterConnection != null) {
/*  340 */       this.masterConnection.addHost(host);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void removeMasterHost(String host) throws SQLException
/*      */   {
/*  346 */     removeMasterHost(host, true);
/*      */   }
/*      */   
/*      */   public synchronized void removeMasterHost(String host, boolean waitUntilNotInUse) throws SQLException {
/*  350 */     removeMasterHost(host, waitUntilNotInUse, false);
/*      */   }
/*      */   
/*      */   public synchronized void removeMasterHost(String host, boolean waitUntilNotInUse, boolean isNowSlave) throws SQLException {
/*  354 */     if (isNowSlave) {
/*  355 */       this.slaveHosts.add(host);
/*      */     }
/*  357 */     this.masterHosts.remove(host);
/*      */     
/*      */ 
/*  360 */     if ((this.masterConnection == null) || (this.masterConnection.isClosed())) {
/*  361 */       this.masterConnection = null;
/*  362 */       return;
/*      */     }
/*      */     
/*  365 */     if (waitUntilNotInUse) {
/*  366 */       this.masterConnection.removeHostWhenNotInUse(host);
/*      */     } else {
/*  368 */       this.masterConnection.removeHost(host);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement()
/*      */     throws SQLException
/*      */   {
/*  379 */     java.sql.Statement stmt = getCurrentConnection().createStatement();
/*  380 */     ((Statement)stmt).setPingTarget(this);
/*      */     
/*  382 */     return stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  391 */     java.sql.Statement stmt = getCurrentConnection().createStatement(resultSetType, resultSetConcurrency);
/*      */     
/*  393 */     ((Statement)stmt).setPingTarget(this);
/*      */     
/*  395 */     return stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/*  404 */     java.sql.Statement stmt = getCurrentConnection().createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */     
/*  406 */     ((Statement)stmt).setPingTarget(this);
/*      */     
/*  408 */     return stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAutoCommit()
/*      */     throws SQLException
/*      */   {
/*  417 */     return getCurrentConnection().getAutoCommit();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCatalog()
/*      */     throws SQLException
/*      */   {
/*  426 */     return getCurrentConnection().getCatalog();
/*      */   }
/*      */   
/*      */   public synchronized Connection getCurrentConnection() {
/*  430 */     return this.currentConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHoldability()
/*      */     throws SQLException
/*      */   {
/*  439 */     return getCurrentConnection().getHoldability();
/*      */   }
/*      */   
/*      */   public synchronized Connection getMasterConnection() {
/*  443 */     return this.masterConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DatabaseMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  452 */     return getCurrentConnection().getMetaData();
/*      */   }
/*      */   
/*      */   public synchronized Connection getSlavesConnection() {
/*  456 */     return this.slavesConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/*  465 */     return getCurrentConnection().getTransactionIsolation();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, Class<?>> getTypeMap()
/*      */     throws SQLException
/*      */   {
/*  474 */     return getCurrentConnection().getTypeMap();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  483 */     return getCurrentConnection().getWarnings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isClosed()
/*      */     throws SQLException
/*      */   {
/*  492 */     return getCurrentConnection().isClosed();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/*  501 */     return this.readOnly;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String nativeSQL(String sql)
/*      */     throws SQLException
/*      */   {
/*  510 */     return getCurrentConnection().nativeSQL(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatement prepareCall(String sql)
/*      */     throws SQLException
/*      */   {
/*  519 */     return getCurrentConnection().prepareCall(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  528 */     return getCurrentConnection().prepareCall(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/*  537 */     return getCurrentConnection().prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/*  546 */     PreparedStatement pstmt = getCurrentConnection().prepareStatement(sql);
/*      */     
/*  548 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  550 */     return pstmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/*  559 */     PreparedStatement pstmt = getCurrentConnection().prepareStatement(sql, autoGeneratedKeys);
/*      */     
/*  561 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  563 */     return pstmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  572 */     PreparedStatement pstmt = getCurrentConnection().prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */     
/*  574 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  576 */     return pstmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/*  586 */     PreparedStatement pstmt = getCurrentConnection().prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */     
/*  588 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  590 */     return pstmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
/*      */     throws SQLException
/*      */   {
/*  599 */     PreparedStatement pstmt = getCurrentConnection().prepareStatement(sql, columnIndexes);
/*      */     
/*  601 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  603 */     return pstmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement prepareStatement(String sql, String[] columnNames)
/*      */     throws SQLException
/*      */   {
/*  613 */     PreparedStatement pstmt = getCurrentConnection().prepareStatement(sql, columnNames);
/*      */     
/*  615 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  617 */     return pstmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void releaseSavepoint(Savepoint savepoint)
/*      */     throws SQLException
/*      */   {
/*  626 */     getCurrentConnection().releaseSavepoint(savepoint);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLException
/*      */   {
/*  635 */     getCurrentConnection().rollback();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback(Savepoint savepoint)
/*      */     throws SQLException
/*      */   {
/*  644 */     getCurrentConnection().rollback(savepoint);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoCommit(boolean autoCommit)
/*      */     throws SQLException
/*      */   {
/*  653 */     getCurrentConnection().setAutoCommit(autoCommit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCatalog(String catalog)
/*      */     throws SQLException
/*      */   {
/*  662 */     getCurrentConnection().setCatalog(catalog);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHoldability(int holdability)
/*      */     throws SQLException
/*      */   {
/*  671 */     getCurrentConnection().setHoldability(holdability);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setReadOnly(boolean readOnly)
/*      */     throws SQLException
/*      */   {
/*  680 */     if (readOnly) {
/*  681 */       if (this.currentConnection != this.slavesConnection) {
/*  682 */         switchToSlavesConnection();
/*      */       }
/*      */     }
/*  685 */     else if (this.currentConnection != this.masterConnection) {
/*  686 */       switchToMasterConnection();
/*      */     }
/*      */     
/*  689 */     this.readOnly = readOnly;
/*      */     
/*      */ 
/*  692 */     if (this.currentConnection == this.masterConnection) {
/*  693 */       this.currentConnection.setReadOnly(this.readOnly);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Savepoint setSavepoint()
/*      */     throws SQLException
/*      */   {
/*  703 */     return getCurrentConnection().setSavepoint();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Savepoint setSavepoint(String name)
/*      */     throws SQLException
/*      */   {
/*  712 */     return getCurrentConnection().setSavepoint(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransactionIsolation(int level)
/*      */     throws SQLException
/*      */   {
/*  721 */     getCurrentConnection().setTransactionIsolation(level);
/*      */   }
/*      */   
/*      */   private synchronized void switchToMasterConnection()
/*      */     throws SQLException
/*      */   {
/*  727 */     if ((this.masterConnection == null) || (this.masterConnection.isClosed())) {
/*  728 */       initializeMasterConnection();
/*      */     }
/*  730 */     swapConnections(this.masterConnection, this.slavesConnection);
/*  731 */     this.masterConnection.setReadOnly(false);
/*      */   }
/*      */   
/*      */   private synchronized void switchToSlavesConnection() throws SQLException {
/*  735 */     if ((this.slavesConnection == null) || (this.slavesConnection.isClosed())) {
/*  736 */       initializeSlaveConnection();
/*      */     }
/*  738 */     if (this.slavesConnection != null) {
/*  739 */       swapConnections(this.slavesConnection, this.masterConnection);
/*  740 */       this.slavesConnection.setReadOnly(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void swapConnections(Connection switchToConnection, Connection switchFromConnection)
/*      */     throws SQLException
/*      */   {
/*  759 */     String switchFromCatalog = switchFromConnection.getCatalog();
/*  760 */     String switchToCatalog = switchToConnection.getCatalog();
/*      */     
/*  762 */     if ((switchToCatalog != null) && (!switchToCatalog.equals(switchFromCatalog))) {
/*  763 */       switchToConnection.setCatalog(switchFromCatalog);
/*  764 */     } else if (switchFromCatalog != null) {
/*  765 */       switchToConnection.setCatalog(switchFromCatalog);
/*      */     }
/*      */     
/*  768 */     boolean switchToAutoCommit = switchToConnection.getAutoCommit();
/*  769 */     boolean switchFromConnectionAutoCommit = switchFromConnection.getAutoCommit();
/*      */     
/*  771 */     if (switchFromConnectionAutoCommit != switchToAutoCommit) {
/*  772 */       switchToConnection.setAutoCommit(switchFromConnectionAutoCommit);
/*      */     }
/*      */     
/*  775 */     int switchToIsolation = switchToConnection.getTransactionIsolation();
/*      */     
/*  777 */     int switchFromIsolation = switchFromConnection.getTransactionIsolation();
/*      */     
/*  779 */     if (switchFromIsolation != switchToIsolation) {
/*  780 */       switchToConnection.setTransactionIsolation(switchFromIsolation);
/*      */     }
/*      */     
/*  783 */     switchToConnection.setSessionMaxRows(switchFromConnection.getSessionMaxRows());
/*      */     
/*  785 */     this.currentConnection = switchToConnection;
/*      */   }
/*      */   
/*      */   public synchronized void doPing() throws SQLException {
/*  789 */     boolean isMasterConn = isMasterConnection();
/*  790 */     if (this.masterConnection != null) {
/*      */       try {
/*  792 */         this.masterConnection.ping();
/*      */       } catch (SQLException e) {
/*  794 */         if (isMasterConn)
/*      */         {
/*  796 */           this.currentConnection = this.slavesConnection;
/*  797 */           this.masterConnection = null;
/*      */           
/*  799 */           throw e;
/*      */         }
/*      */       }
/*      */     } else {
/*  803 */       initializeMasterConnection();
/*      */     }
/*      */     
/*  806 */     if (this.slavesConnection != null) {
/*      */       try {
/*  808 */         this.slavesConnection.ping();
/*      */       } catch (SQLException e) {
/*  810 */         if (!isMasterConn)
/*      */         {
/*  812 */           this.currentConnection = this.masterConnection;
/*  813 */           this.slavesConnection = null;
/*      */           
/*  815 */           throw e;
/*      */         }
/*      */       }
/*      */     } else {
/*  819 */       initializeSlaveConnection();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void changeUser(String userName, String newPassword) throws SQLException {
/*  824 */     this.masterConnection.changeUser(userName, newPassword);
/*  825 */     this.slavesConnection.changeUser(userName, newPassword);
/*      */   }
/*      */   
/*      */   public synchronized void clearHasTriedMaster() {
/*  829 */     this.masterConnection.clearHasTriedMaster();
/*  830 */     this.slavesConnection.clearHasTriedMaster();
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException
/*      */   {
/*  835 */     PreparedStatement pstmt = getCurrentConnection().clientPrepareStatement(sql);
/*  836 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  838 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*  842 */     PreparedStatement pstmt = getCurrentConnection().clientPrepareStatement(sql, autoGenKeyIndex);
/*  843 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  845 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  849 */     PreparedStatement pstmt = getCurrentConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*  850 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  852 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*  856 */     PreparedStatement pstmt = getCurrentConnection().clientPrepareStatement(sql, autoGenKeyIndexes);
/*  857 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  859 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  863 */     PreparedStatement pstmt = getCurrentConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*  864 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  866 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*  870 */     PreparedStatement pstmt = getCurrentConnection().clientPrepareStatement(sql, autoGenKeyColNames);
/*  871 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  873 */     return pstmt;
/*      */   }
/*      */   
/*      */   public int getActiveStatementCount() {
/*  877 */     return getCurrentConnection().getActiveStatementCount();
/*      */   }
/*      */   
/*      */   public long getIdleFor() {
/*  881 */     return getCurrentConnection().getIdleFor();
/*      */   }
/*      */   
/*      */   public Log getLog() throws SQLException {
/*  885 */     return getCurrentConnection().getLog();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getServerCharacterEncoding()
/*      */   {
/*  893 */     return getServerCharset();
/*      */   }
/*      */   
/*      */   public String getServerCharset() {
/*  897 */     return getCurrentConnection().getServerCharset();
/*      */   }
/*      */   
/*      */   public TimeZone getServerTimezoneTZ() {
/*  901 */     return getCurrentConnection().getServerTimezoneTZ();
/*      */   }
/*      */   
/*      */   public String getStatementComment() {
/*  905 */     return getCurrentConnection().getStatementComment();
/*      */   }
/*      */   
/*      */   public boolean hasTriedMaster() {
/*  909 */     return getCurrentConnection().hasTriedMaster();
/*      */   }
/*      */   
/*      */   public void initializeExtension(Extension ex) throws SQLException {
/*  913 */     getCurrentConnection().initializeExtension(ex);
/*      */   }
/*      */   
/*      */   public boolean isAbonormallyLongQuery(long millisOrNanos) {
/*  917 */     return getCurrentConnection().isAbonormallyLongQuery(millisOrNanos);
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx() {
/*  921 */     return getCurrentConnection().isInGlobalTx();
/*      */   }
/*      */   
/*      */   public boolean isMasterConnection() {
/*  925 */     if (this.currentConnection == null) {
/*  926 */       return true;
/*      */     }
/*  928 */     return this.currentConnection == this.masterConnection;
/*      */   }
/*      */   
/*      */   public boolean isNoBackslashEscapesSet() {
/*  932 */     return getCurrentConnection().isNoBackslashEscapesSet();
/*      */   }
/*      */   
/*      */   public boolean lowerCaseTableNames() {
/*  936 */     return getCurrentConnection().lowerCaseTableNames();
/*      */   }
/*      */   
/*      */   public boolean parserKnowsUnicode() {
/*  940 */     return getCurrentConnection().parserKnowsUnicode();
/*      */   }
/*      */   
/*      */   public synchronized void ping() throws SQLException {
/*      */     try {
/*  945 */       this.masterConnection.ping();
/*      */     } catch (SQLException e) {
/*  947 */       if (isMasterConnection()) {
/*  948 */         throw e;
/*      */       }
/*      */     }
/*      */     try {
/*  952 */       this.slavesConnection.ping();
/*      */     } catch (SQLException e) {
/*  954 */       if (!isMasterConnection()) {
/*  955 */         throw e;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void reportQueryTime(long millisOrNanos) {
/*  961 */     getCurrentConnection().reportQueryTime(millisOrNanos);
/*      */   }
/*      */   
/*      */   public void resetServerState() throws SQLException {
/*  965 */     getCurrentConnection().resetServerState();
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/*  969 */     PreparedStatement pstmt = getCurrentConnection().serverPrepareStatement(sql);
/*  970 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  972 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*  976 */     PreparedStatement pstmt = getCurrentConnection().serverPrepareStatement(sql, autoGenKeyIndex);
/*  977 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  979 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  983 */     PreparedStatement pstmt = getCurrentConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*  984 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  986 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  990 */     PreparedStatement pstmt = getCurrentConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*  991 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  993 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*  997 */     PreparedStatement pstmt = getCurrentConnection().serverPrepareStatement(sql, autoGenKeyIndexes);
/*  998 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/* 1000 */     return pstmt;
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/* 1004 */     PreparedStatement pstmt = getCurrentConnection().serverPrepareStatement(sql, autoGenKeyColNames);
/* 1005 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/* 1007 */     return pstmt;
/*      */   }
/*      */   
/*      */   public void setFailedOver(boolean flag) {
/* 1011 */     getCurrentConnection().setFailedOver(flag);
/*      */   }
/*      */   
/*      */   public void setPreferSlaveDuringFailover(boolean flag) {
/* 1015 */     getCurrentConnection().setPreferSlaveDuringFailover(flag);
/*      */   }
/*      */   
/*      */   public synchronized void setStatementComment(String comment) {
/* 1019 */     this.masterConnection.setStatementComment(comment);
/* 1020 */     this.slavesConnection.setStatementComment(comment);
/*      */   }
/*      */   
/*      */   public void shutdownServer() throws SQLException {
/* 1024 */     getCurrentConnection().shutdownServer();
/*      */   }
/*      */   
/*      */   public boolean supportsIsolationLevel() {
/* 1028 */     return getCurrentConnection().supportsIsolationLevel();
/*      */   }
/*      */   
/*      */   public boolean supportsQuotedIdentifiers() {
/* 1032 */     return getCurrentConnection().supportsQuotedIdentifiers();
/*      */   }
/*      */   
/*      */   public boolean supportsTransactions() {
/* 1036 */     return getCurrentConnection().supportsTransactions();
/*      */   }
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException {
/* 1040 */     return getCurrentConnection().versionMeetsMinimum(major, minor, subminor);
/*      */   }
/*      */   
/*      */   public String exposeAsXml() throws SQLException {
/* 1044 */     return getCurrentConnection().exposeAsXml();
/*      */   }
/*      */   
/*      */   public boolean getAllowLoadLocalInfile() {
/* 1048 */     return getCurrentConnection().getAllowLoadLocalInfile();
/*      */   }
/*      */   
/*      */   public boolean getAllowMultiQueries() {
/* 1052 */     return getCurrentConnection().getAllowMultiQueries();
/*      */   }
/*      */   
/*      */   public boolean getAllowNanAndInf() {
/* 1056 */     return getCurrentConnection().getAllowNanAndInf();
/*      */   }
/*      */   
/*      */   public boolean getAllowUrlInLocalInfile() {
/* 1060 */     return getCurrentConnection().getAllowUrlInLocalInfile();
/*      */   }
/*      */   
/*      */   public boolean getAlwaysSendSetIsolation() {
/* 1064 */     return getCurrentConnection().getAlwaysSendSetIsolation();
/*      */   }
/*      */   
/*      */   public boolean getAutoClosePStmtStreams() {
/* 1068 */     return getCurrentConnection().getAutoClosePStmtStreams();
/*      */   }
/*      */   
/*      */   public boolean getAutoDeserialize() {
/* 1072 */     return getCurrentConnection().getAutoDeserialize();
/*      */   }
/*      */   
/*      */   public boolean getAutoGenerateTestcaseScript() {
/* 1076 */     return getCurrentConnection().getAutoGenerateTestcaseScript();
/*      */   }
/*      */   
/*      */   public boolean getAutoReconnectForPools() {
/* 1080 */     return getCurrentConnection().getAutoReconnectForPools();
/*      */   }
/*      */   
/*      */   public boolean getAutoSlowLog() {
/* 1084 */     return getCurrentConnection().getAutoSlowLog();
/*      */   }
/*      */   
/*      */   public int getBlobSendChunkSize() {
/* 1088 */     return getCurrentConnection().getBlobSendChunkSize();
/*      */   }
/*      */   
/*      */   public boolean getBlobsAreStrings() {
/* 1092 */     return getCurrentConnection().getBlobsAreStrings();
/*      */   }
/*      */   
/*      */   public boolean getCacheCallableStatements() {
/* 1096 */     return getCurrentConnection().getCacheCallableStatements();
/*      */   }
/*      */   
/*      */   public boolean getCacheCallableStmts() {
/* 1100 */     return getCurrentConnection().getCacheCallableStmts();
/*      */   }
/*      */   
/*      */   public boolean getCachePrepStmts() {
/* 1104 */     return getCurrentConnection().getCachePrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getCachePreparedStatements() {
/* 1108 */     return getCurrentConnection().getCachePreparedStatements();
/*      */   }
/*      */   
/*      */   public boolean getCacheResultSetMetadata() {
/* 1112 */     return getCurrentConnection().getCacheResultSetMetadata();
/*      */   }
/*      */   
/*      */   public boolean getCacheServerConfiguration() {
/* 1116 */     return getCurrentConnection().getCacheServerConfiguration();
/*      */   }
/*      */   
/*      */   public int getCallableStatementCacheSize() {
/* 1120 */     return getCurrentConnection().getCallableStatementCacheSize();
/*      */   }
/*      */   
/*      */   public int getCallableStmtCacheSize() {
/* 1124 */     return getCurrentConnection().getCallableStmtCacheSize();
/*      */   }
/*      */   
/*      */   public boolean getCapitalizeTypeNames() {
/* 1128 */     return getCurrentConnection().getCapitalizeTypeNames();
/*      */   }
/*      */   
/*      */   public String getCharacterSetResults() {
/* 1132 */     return getCurrentConnection().getCharacterSetResults();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStorePassword() {
/* 1136 */     return getCurrentConnection().getClientCertificateKeyStorePassword();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStoreType() {
/* 1140 */     return getCurrentConnection().getClientCertificateKeyStoreType();
/*      */   }
/*      */   
/*      */   public String getClientCertificateKeyStoreUrl() {
/* 1144 */     return getCurrentConnection().getClientCertificateKeyStoreUrl();
/*      */   }
/*      */   
/*      */   public String getClientInfoProvider() {
/* 1148 */     return getCurrentConnection().getClientInfoProvider();
/*      */   }
/*      */   
/*      */   public String getClobCharacterEncoding() {
/* 1152 */     return getCurrentConnection().getClobCharacterEncoding();
/*      */   }
/*      */   
/*      */   public boolean getClobberStreamingResults() {
/* 1156 */     return getCurrentConnection().getClobberStreamingResults();
/*      */   }
/*      */   
/*      */   public int getConnectTimeout() {
/* 1160 */     return getCurrentConnection().getConnectTimeout();
/*      */   }
/*      */   
/*      */   public String getConnectionCollation() {
/* 1164 */     return getCurrentConnection().getConnectionCollation();
/*      */   }
/*      */   
/*      */   public String getConnectionLifecycleInterceptors() {
/* 1168 */     return getCurrentConnection().getConnectionLifecycleInterceptors();
/*      */   }
/*      */   
/*      */   public boolean getContinueBatchOnError() {
/* 1172 */     return getCurrentConnection().getContinueBatchOnError();
/*      */   }
/*      */   
/*      */   public boolean getCreateDatabaseIfNotExist() {
/* 1176 */     return getCurrentConnection().getCreateDatabaseIfNotExist();
/*      */   }
/*      */   
/*      */   public int getDefaultFetchSize() {
/* 1180 */     return getCurrentConnection().getDefaultFetchSize();
/*      */   }
/*      */   
/*      */   public boolean getDontTrackOpenResources() {
/* 1184 */     return getCurrentConnection().getDontTrackOpenResources();
/*      */   }
/*      */   
/*      */   public boolean getDumpMetadataOnColumnNotFound() {
/* 1188 */     return getCurrentConnection().getDumpMetadataOnColumnNotFound();
/*      */   }
/*      */   
/*      */   public boolean getDumpQueriesOnException() {
/* 1192 */     return getCurrentConnection().getDumpQueriesOnException();
/*      */   }
/*      */   
/*      */   public boolean getDynamicCalendars() {
/* 1196 */     return getCurrentConnection().getDynamicCalendars();
/*      */   }
/*      */   
/*      */   public boolean getElideSetAutoCommits() {
/* 1200 */     return getCurrentConnection().getElideSetAutoCommits();
/*      */   }
/*      */   
/*      */   public boolean getEmptyStringsConvertToZero() {
/* 1204 */     return getCurrentConnection().getEmptyStringsConvertToZero();
/*      */   }
/*      */   
/*      */   public boolean getEmulateLocators() {
/* 1208 */     return getCurrentConnection().getEmulateLocators();
/*      */   }
/*      */   
/*      */   public boolean getEmulateUnsupportedPstmts() {
/* 1212 */     return getCurrentConnection().getEmulateUnsupportedPstmts();
/*      */   }
/*      */   
/*      */   public boolean getEnablePacketDebug() {
/* 1216 */     return getCurrentConnection().getEnablePacketDebug();
/*      */   }
/*      */   
/*      */   public boolean getEnableQueryTimeouts() {
/* 1220 */     return getCurrentConnection().getEnableQueryTimeouts();
/*      */   }
/*      */   
/*      */   public String getEncoding() {
/* 1224 */     return getCurrentConnection().getEncoding();
/*      */   }
/*      */   
/*      */   public boolean getExplainSlowQueries() {
/* 1228 */     return getCurrentConnection().getExplainSlowQueries();
/*      */   }
/*      */   
/*      */   public boolean getFailOverReadOnly() {
/* 1232 */     return getCurrentConnection().getFailOverReadOnly();
/*      */   }
/*      */   
/*      */   public boolean getFunctionsNeverReturnBlobs() {
/* 1236 */     return getCurrentConnection().getFunctionsNeverReturnBlobs();
/*      */   }
/*      */   
/*      */   public boolean getGatherPerfMetrics() {
/* 1240 */     return getCurrentConnection().getGatherPerfMetrics();
/*      */   }
/*      */   
/*      */   public boolean getGatherPerformanceMetrics() {
/* 1244 */     return getCurrentConnection().getGatherPerformanceMetrics();
/*      */   }
/*      */   
/*      */   public boolean getGenerateSimpleParameterMetadata() {
/* 1248 */     return getCurrentConnection().getGenerateSimpleParameterMetadata();
/*      */   }
/*      */   
/*      */   public boolean getHoldResultsOpenOverStatementClose() {
/* 1252 */     return getCurrentConnection().getHoldResultsOpenOverStatementClose();
/*      */   }
/*      */   
/*      */   public boolean getIgnoreNonTxTables() {
/* 1256 */     return getCurrentConnection().getIgnoreNonTxTables();
/*      */   }
/*      */   
/*      */   public boolean getIncludeInnodbStatusInDeadlockExceptions() {
/* 1260 */     return getCurrentConnection().getIncludeInnodbStatusInDeadlockExceptions();
/*      */   }
/*      */   
/*      */   public int getInitialTimeout() {
/* 1264 */     return getCurrentConnection().getInitialTimeout();
/*      */   }
/*      */   
/*      */   public boolean getInteractiveClient() {
/* 1268 */     return getCurrentConnection().getInteractiveClient();
/*      */   }
/*      */   
/*      */   public boolean getIsInteractiveClient() {
/* 1272 */     return getCurrentConnection().getIsInteractiveClient();
/*      */   }
/*      */   
/*      */   public boolean getJdbcCompliantTruncation() {
/* 1276 */     return getCurrentConnection().getJdbcCompliantTruncation();
/*      */   }
/*      */   
/*      */   public boolean getJdbcCompliantTruncationForReads() {
/* 1280 */     return getCurrentConnection().getJdbcCompliantTruncationForReads();
/*      */   }
/*      */   
/*      */   public String getLargeRowSizeThreshold() {
/* 1284 */     return getCurrentConnection().getLargeRowSizeThreshold();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceStrategy() {
/* 1288 */     return getCurrentConnection().getLoadBalanceStrategy();
/*      */   }
/*      */   
/*      */   public String getLocalSocketAddress() {
/* 1292 */     return getCurrentConnection().getLocalSocketAddress();
/*      */   }
/*      */   
/*      */   public int getLocatorFetchBufferSize() {
/* 1296 */     return getCurrentConnection().getLocatorFetchBufferSize();
/*      */   }
/*      */   
/*      */   public boolean getLogSlowQueries() {
/* 1300 */     return getCurrentConnection().getLogSlowQueries();
/*      */   }
/*      */   
/*      */   public boolean getLogXaCommands() {
/* 1304 */     return getCurrentConnection().getLogXaCommands();
/*      */   }
/*      */   
/*      */   public String getLogger() {
/* 1308 */     return getCurrentConnection().getLogger();
/*      */   }
/*      */   
/*      */   public String getLoggerClassName() {
/* 1312 */     return getCurrentConnection().getLoggerClassName();
/*      */   }
/*      */   
/*      */   public boolean getMaintainTimeStats() {
/* 1316 */     return getCurrentConnection().getMaintainTimeStats();
/*      */   }
/*      */   
/*      */   public int getMaxQuerySizeToLog() {
/* 1320 */     return getCurrentConnection().getMaxQuerySizeToLog();
/*      */   }
/*      */   
/*      */   public int getMaxReconnects() {
/* 1324 */     return getCurrentConnection().getMaxReconnects();
/*      */   }
/*      */   
/*      */   public int getMaxRows() {
/* 1328 */     return getCurrentConnection().getMaxRows();
/*      */   }
/*      */   
/*      */   public int getMetadataCacheSize() {
/* 1332 */     return getCurrentConnection().getMetadataCacheSize();
/*      */   }
/*      */   
/*      */   public int getNetTimeoutForStreamingResults() {
/* 1336 */     return getCurrentConnection().getNetTimeoutForStreamingResults();
/*      */   }
/*      */   
/*      */   public boolean getNoAccessToProcedureBodies() {
/* 1340 */     return getCurrentConnection().getNoAccessToProcedureBodies();
/*      */   }
/*      */   
/*      */   public boolean getNoDatetimeStringSync() {
/* 1344 */     return getCurrentConnection().getNoDatetimeStringSync();
/*      */   }
/*      */   
/*      */   public boolean getNoTimezoneConversionForTimeType() {
/* 1348 */     return getCurrentConnection().getNoTimezoneConversionForTimeType();
/*      */   }
/*      */   
/*      */   public boolean getNoTimezoneConversionForDateType() {
/* 1352 */     return getCurrentConnection().getNoTimezoneConversionForDateType();
/*      */   }
/*      */   
/*      */   public boolean getCacheDefaultTimezone() {
/* 1356 */     return getCurrentConnection().getCacheDefaultTimezone();
/*      */   }
/*      */   
/*      */   public boolean getNullCatalogMeansCurrent() {
/* 1360 */     return getCurrentConnection().getNullCatalogMeansCurrent();
/*      */   }
/*      */   
/*      */   public boolean getNullNamePatternMatchesAll() {
/* 1364 */     return getCurrentConnection().getNullNamePatternMatchesAll();
/*      */   }
/*      */   
/*      */   public boolean getOverrideSupportsIntegrityEnhancementFacility() {
/* 1368 */     return getCurrentConnection().getOverrideSupportsIntegrityEnhancementFacility();
/*      */   }
/*      */   
/*      */   public int getPacketDebugBufferSize() {
/* 1372 */     return getCurrentConnection().getPacketDebugBufferSize();
/*      */   }
/*      */   
/*      */   public boolean getPadCharsWithSpace() {
/* 1376 */     return getCurrentConnection().getPadCharsWithSpace();
/*      */   }
/*      */   
/*      */   public boolean getParanoid() {
/* 1380 */     return getCurrentConnection().getParanoid();
/*      */   }
/*      */   
/*      */   public boolean getPedantic() {
/* 1384 */     return getCurrentConnection().getPedantic();
/*      */   }
/*      */   
/*      */   public boolean getPinGlobalTxToPhysicalConnection() {
/* 1388 */     return getCurrentConnection().getPinGlobalTxToPhysicalConnection();
/*      */   }
/*      */   
/*      */   public boolean getPopulateInsertRowWithDefaultValues() {
/* 1392 */     return getCurrentConnection().getPopulateInsertRowWithDefaultValues();
/*      */   }
/*      */   
/*      */   public int getPrepStmtCacheSize() {
/* 1396 */     return getCurrentConnection().getPrepStmtCacheSize();
/*      */   }
/*      */   
/*      */   public int getPrepStmtCacheSqlLimit() {
/* 1400 */     return getCurrentConnection().getPrepStmtCacheSqlLimit();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSize() {
/* 1404 */     return getCurrentConnection().getPreparedStatementCacheSize();
/*      */   }
/*      */   
/*      */   public int getPreparedStatementCacheSqlLimit() {
/* 1408 */     return getCurrentConnection().getPreparedStatementCacheSqlLimit();
/*      */   }
/*      */   
/*      */   public boolean getProcessEscapeCodesForPrepStmts() {
/* 1412 */     return getCurrentConnection().getProcessEscapeCodesForPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getProfileSQL() {
/* 1416 */     return getCurrentConnection().getProfileSQL();
/*      */   }
/*      */   
/*      */   public boolean getProfileSql() {
/* 1420 */     return getCurrentConnection().getProfileSql();
/*      */   }
/*      */   
/*      */   public String getProfilerEventHandler() {
/* 1424 */     return getCurrentConnection().getProfilerEventHandler();
/*      */   }
/*      */   
/*      */   public String getPropertiesTransform() {
/* 1428 */     return getCurrentConnection().getPropertiesTransform();
/*      */   }
/*      */   
/*      */   public int getQueriesBeforeRetryMaster() {
/* 1432 */     return getCurrentConnection().getQueriesBeforeRetryMaster();
/*      */   }
/*      */   
/*      */   public boolean getReconnectAtTxEnd() {
/* 1436 */     return getCurrentConnection().getReconnectAtTxEnd();
/*      */   }
/*      */   
/*      */   public boolean getRelaxAutoCommit() {
/* 1440 */     return getCurrentConnection().getRelaxAutoCommit();
/*      */   }
/*      */   
/*      */   public int getReportMetricsIntervalMillis() {
/* 1444 */     return getCurrentConnection().getReportMetricsIntervalMillis();
/*      */   }
/*      */   
/*      */   public boolean getRequireSSL() {
/* 1448 */     return getCurrentConnection().getRequireSSL();
/*      */   }
/*      */   
/*      */   public String getResourceId() {
/* 1452 */     return getCurrentConnection().getResourceId();
/*      */   }
/*      */   
/*      */   public int getResultSetSizeThreshold() {
/* 1456 */     return getCurrentConnection().getResultSetSizeThreshold();
/*      */   }
/*      */   
/*      */   public boolean getRewriteBatchedStatements() {
/* 1460 */     return getCurrentConnection().getRewriteBatchedStatements();
/*      */   }
/*      */   
/*      */   public boolean getRollbackOnPooledClose() {
/* 1464 */     return getCurrentConnection().getRollbackOnPooledClose();
/*      */   }
/*      */   
/*      */   public boolean getRoundRobinLoadBalance() {
/* 1468 */     return getCurrentConnection().getRoundRobinLoadBalance();
/*      */   }
/*      */   
/*      */   public boolean getRunningCTS13() {
/* 1472 */     return getCurrentConnection().getRunningCTS13();
/*      */   }
/*      */   
/*      */   public int getSecondsBeforeRetryMaster() {
/* 1476 */     return getCurrentConnection().getSecondsBeforeRetryMaster();
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingMaxOperations() {
/* 1480 */     return getCurrentConnection().getSelfDestructOnPingMaxOperations();
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingSecondsLifetime() {
/* 1484 */     return getCurrentConnection().getSelfDestructOnPingSecondsLifetime();
/*      */   }
/*      */   
/*      */   public String getServerTimezone() {
/* 1488 */     return getCurrentConnection().getServerTimezone();
/*      */   }
/*      */   
/*      */   public String getSessionVariables() {
/* 1492 */     return getCurrentConnection().getSessionVariables();
/*      */   }
/*      */   
/*      */   public int getSlowQueryThresholdMillis() {
/* 1496 */     return getCurrentConnection().getSlowQueryThresholdMillis();
/*      */   }
/*      */   
/*      */   public long getSlowQueryThresholdNanos() {
/* 1500 */     return getCurrentConnection().getSlowQueryThresholdNanos();
/*      */   }
/*      */   
/*      */   public String getSocketFactory() {
/* 1504 */     return getCurrentConnection().getSocketFactory();
/*      */   }
/*      */   
/*      */   public String getSocketFactoryClassName() {
/* 1508 */     return getCurrentConnection().getSocketFactoryClassName();
/*      */   }
/*      */   
/*      */   public int getSocketTimeout() {
/* 1512 */     return getCurrentConnection().getSocketTimeout();
/*      */   }
/*      */   
/*      */   public String getStatementInterceptors() {
/* 1516 */     return getCurrentConnection().getStatementInterceptors();
/*      */   }
/*      */   
/*      */   public boolean getStrictFloatingPoint() {
/* 1520 */     return getCurrentConnection().getStrictFloatingPoint();
/*      */   }
/*      */   
/*      */   public boolean getStrictUpdates() {
/* 1524 */     return getCurrentConnection().getStrictUpdates();
/*      */   }
/*      */   
/*      */   public boolean getTcpKeepAlive() {
/* 1528 */     return getCurrentConnection().getTcpKeepAlive();
/*      */   }
/*      */   
/*      */   public boolean getTcpNoDelay() {
/* 1532 */     return getCurrentConnection().getTcpNoDelay();
/*      */   }
/*      */   
/*      */   public int getTcpRcvBuf() {
/* 1536 */     return getCurrentConnection().getTcpRcvBuf();
/*      */   }
/*      */   
/*      */   public int getTcpSndBuf() {
/* 1540 */     return getCurrentConnection().getTcpSndBuf();
/*      */   }
/*      */   
/*      */   public int getTcpTrafficClass() {
/* 1544 */     return getCurrentConnection().getTcpTrafficClass();
/*      */   }
/*      */   
/*      */   public boolean getTinyInt1isBit() {
/* 1548 */     return getCurrentConnection().getTinyInt1isBit();
/*      */   }
/*      */   
/*      */   public boolean getTraceProtocol() {
/* 1552 */     return getCurrentConnection().getTraceProtocol();
/*      */   }
/*      */   
/*      */   public boolean getTransformedBitIsBoolean() {
/* 1556 */     return getCurrentConnection().getTransformedBitIsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getTreatUtilDateAsTimestamp() {
/* 1560 */     return getCurrentConnection().getTreatUtilDateAsTimestamp();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStorePassword() {
/* 1564 */     return getCurrentConnection().getTrustCertificateKeyStorePassword();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStoreType() {
/* 1568 */     return getCurrentConnection().getTrustCertificateKeyStoreType();
/*      */   }
/*      */   
/*      */   public String getTrustCertificateKeyStoreUrl() {
/* 1572 */     return getCurrentConnection().getTrustCertificateKeyStoreUrl();
/*      */   }
/*      */   
/*      */   public boolean getUltraDevHack() {
/* 1576 */     return getCurrentConnection().getUltraDevHack();
/*      */   }
/*      */   
/*      */   public boolean getUseBlobToStoreUTF8OutsideBMP() {
/* 1580 */     return getCurrentConnection().getUseBlobToStoreUTF8OutsideBMP();
/*      */   }
/*      */   
/*      */   public boolean getUseCompression() {
/* 1584 */     return getCurrentConnection().getUseCompression();
/*      */   }
/*      */   
/*      */   public String getUseConfigs() {
/* 1588 */     return getCurrentConnection().getUseConfigs();
/*      */   }
/*      */   
/*      */   public boolean getUseCursorFetch() {
/* 1592 */     return getCurrentConnection().getUseCursorFetch();
/*      */   }
/*      */   
/*      */   public boolean getUseDirectRowUnpack() {
/* 1596 */     return getCurrentConnection().getUseDirectRowUnpack();
/*      */   }
/*      */   
/*      */   public boolean getUseDynamicCharsetInfo() {
/* 1600 */     return getCurrentConnection().getUseDynamicCharsetInfo();
/*      */   }
/*      */   
/*      */   public boolean getUseFastDateParsing() {
/* 1604 */     return getCurrentConnection().getUseFastDateParsing();
/*      */   }
/*      */   
/*      */   public boolean getUseFastIntParsing() {
/* 1608 */     return getCurrentConnection().getUseFastIntParsing();
/*      */   }
/*      */   
/*      */   public boolean getUseGmtMillisForDatetimes() {
/* 1612 */     return getCurrentConnection().getUseGmtMillisForDatetimes();
/*      */   }
/*      */   
/*      */   public boolean getUseHostsInPrivileges() {
/* 1616 */     return getCurrentConnection().getUseHostsInPrivileges();
/*      */   }
/*      */   
/*      */   public boolean getUseInformationSchema() {
/* 1620 */     return getCurrentConnection().getUseInformationSchema();
/*      */   }
/*      */   
/*      */   public boolean getUseJDBCCompliantTimezoneShift() {
/* 1624 */     return getCurrentConnection().getUseJDBCCompliantTimezoneShift();
/*      */   }
/*      */   
/*      */   public boolean getUseJvmCharsetConverters() {
/* 1628 */     return getCurrentConnection().getUseJvmCharsetConverters();
/*      */   }
/*      */   
/*      */   public boolean getUseLegacyDatetimeCode() {
/* 1632 */     return getCurrentConnection().getUseLegacyDatetimeCode();
/*      */   }
/*      */   
/*      */   public boolean getUseLocalSessionState() {
/* 1636 */     return getCurrentConnection().getUseLocalSessionState();
/*      */   }
/*      */   
/*      */   public boolean getUseNanosForElapsedTime() {
/* 1640 */     return getCurrentConnection().getUseNanosForElapsedTime();
/*      */   }
/*      */   
/*      */   public boolean getUseOldAliasMetadataBehavior() {
/* 1644 */     return getCurrentConnection().getUseOldAliasMetadataBehavior();
/*      */   }
/*      */   
/*      */   public boolean getUseOldUTF8Behavior() {
/* 1648 */     return getCurrentConnection().getUseOldUTF8Behavior();
/*      */   }
/*      */   
/*      */   public boolean getUseOnlyServerErrorMessages() {
/* 1652 */     return getCurrentConnection().getUseOnlyServerErrorMessages();
/*      */   }
/*      */   
/*      */   public boolean getUseReadAheadInput() {
/* 1656 */     return getCurrentConnection().getUseReadAheadInput();
/*      */   }
/*      */   
/*      */   public boolean getUseSSL() {
/* 1660 */     return getCurrentConnection().getUseSSL();
/*      */   }
/*      */   
/*      */   public boolean getUseSSPSCompatibleTimezoneShift() {
/* 1664 */     return getCurrentConnection().getUseSSPSCompatibleTimezoneShift();
/*      */   }
/*      */   
/*      */   public boolean getUseServerPrepStmts() {
/* 1668 */     return getCurrentConnection().getUseServerPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseServerPreparedStmts() {
/* 1672 */     return getCurrentConnection().getUseServerPreparedStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseSqlStateCodes() {
/* 1676 */     return getCurrentConnection().getUseSqlStateCodes();
/*      */   }
/*      */   
/*      */   public boolean getUseStreamLengthsInPrepStmts() {
/* 1680 */     return getCurrentConnection().getUseStreamLengthsInPrepStmts();
/*      */   }
/*      */   
/*      */   public boolean getUseTimezone() {
/* 1684 */     return getCurrentConnection().getUseTimezone();
/*      */   }
/*      */   
/*      */   public boolean getUseUltraDevWorkAround() {
/* 1688 */     return getCurrentConnection().getUseUltraDevWorkAround();
/*      */   }
/*      */   
/*      */   public boolean getUseUnbufferedInput() {
/* 1692 */     return getCurrentConnection().getUseUnbufferedInput();
/*      */   }
/*      */   
/*      */   public boolean getUseUnicode() {
/* 1696 */     return getCurrentConnection().getUseUnicode();
/*      */   }
/*      */   
/*      */   public boolean getUseUsageAdvisor() {
/* 1700 */     return getCurrentConnection().getUseUsageAdvisor();
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpExcludedColumnNamePattern() {
/* 1704 */     return getCurrentConnection().getUtf8OutsideBmpExcludedColumnNamePattern();
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpIncludedColumnNamePattern() {
/* 1708 */     return getCurrentConnection().getUtf8OutsideBmpIncludedColumnNamePattern();
/*      */   }
/*      */   
/*      */   public boolean getVerifyServerCertificate() {
/* 1712 */     return getCurrentConnection().getVerifyServerCertificate();
/*      */   }
/*      */   
/*      */   public boolean getYearIsDateType() {
/* 1716 */     return getCurrentConnection().getYearIsDateType();
/*      */   }
/*      */   
/*      */   public String getZeroDateTimeBehavior() {
/* 1720 */     return getCurrentConnection().getZeroDateTimeBehavior();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowLoadLocalInfile(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowMultiQueries(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowNanAndInf(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowUrlInLocalInfile(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlwaysSendSetIsolation(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoClosePStmtStreams(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoDeserialize(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoGenerateTestcaseScript(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnect(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnectForConnectionPools(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnectForPools(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoSlowLog(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlobSendChunkSize(String value)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlobsAreStrings(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheCallableStatements(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheCallableStmts(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCachePrepStmts(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCachePreparedStatements(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheResultSetMetadata(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheServerConfiguration(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCallableStatementCacheSize(int size) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCallableStmtCacheSize(int cacheSize) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCapitalizeDBMDTypes(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCapitalizeTypeNames(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterEncoding(String encoding) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterSetResults(String characterSet) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStorePassword(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStoreType(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStoreUrl(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientInfoProvider(String classname) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClobCharacterEncoding(String encoding) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClobberStreamingResults(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectTimeout(int timeoutMs) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionCollation(String collation) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionLifecycleInterceptors(String interceptors) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContinueBatchOnError(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCreateDatabaseIfNotExist(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultFetchSize(int n) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDetectServerPreparedStmts(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDontTrackOpenResources(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDumpMetadataOnColumnNotFound(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDumpQueriesOnException(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDynamicCalendars(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setElideSetAutoCommits(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEmptyStringsConvertToZero(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEmulateLocators(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEmulateUnsupportedPstmts(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnablePacketDebug(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnableQueryTimeouts(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEncoding(String property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExplainSlowQueries(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFailOverReadOnly(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFunctionsNeverReturnBlobs(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGatherPerfMetrics(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGatherPerformanceMetrics(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGenerateSimpleParameterMetadata(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHoldResultsOpenOverStatementClose(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIgnoreNonTxTables(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInitialTimeout(int property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInteractiveClient(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIsInteractiveClient(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJdbcCompliantTruncation(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLargeRowSizeThreshold(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoadBalanceStrategy(String strategy) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocalSocketAddress(String address) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocatorFetchBufferSize(String value)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogSlowQueries(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogXaCommands(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogger(String property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoggerClassName(String className) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaintainTimeStats(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxQuerySizeToLog(int sizeInBytes) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxReconnects(int property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxRows(int property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMetadataCacheSize(int value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNetTimeoutForStreamingResults(int value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoAccessToProcedureBodies(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoDatetimeStringSync(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoTimezoneConversionForTimeType(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoTimezoneConversionForDateType(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheDefaultTimezone(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNullCatalogMeansCurrent(boolean value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNullNamePatternMatchesAll(boolean value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPacketDebugBufferSize(int size) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPadCharsWithSpace(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParanoid(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPedantic(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPinGlobalTxToPhysicalConnection(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPopulateInsertRowWithDefaultValues(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrepStmtCacheSize(int cacheSize) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrepStmtCacheSqlLimit(int sqlLimit) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPreparedStatementCacheSize(int cacheSize) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessEscapeCodesForPrepStmts(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProfileSQL(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProfileSql(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProfilerEventHandler(String handler) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPropertiesTransform(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQueriesBeforeRetryMaster(int property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReconnectAtTxEnd(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRelaxAutoCommit(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReportMetricsIntervalMillis(int millis) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequireSSL(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResourceId(String resourceId) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResultSetSizeThreshold(int threshold) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRetainStatementAfterResultSetClose(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRewriteBatchedStatements(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRollbackOnPooledClose(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoundRobinLoadBalance(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunningCTS13(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecondsBeforeRetryMaster(int property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelfDestructOnPingMaxOperations(int maxOperations) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelfDestructOnPingSecondsLifetime(int seconds) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerTimezone(String property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionVariables(String variables) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSlowQueryThresholdMillis(int millis) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSlowQueryThresholdNanos(long nanos) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketFactory(String name) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketFactoryClassName(String property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketTimeout(int property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatementInterceptors(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStrictFloatingPoint(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStrictUpdates(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTcpKeepAlive(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTcpNoDelay(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTcpRcvBuf(int bufSize) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTcpSndBuf(int bufSize) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTcpTrafficClass(int classFlags) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTinyInt1isBit(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTraceProtocol(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransformedBitIsBoolean(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTreatUtilDateAsTimestamp(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStorePassword(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStoreType(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStoreUrl(String value) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUltraDevHack(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseCompression(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseConfigs(String configs) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseCursorFetch(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseDirectRowUnpack(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseDynamicCharsetInfo(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseFastDateParsing(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseFastIntParsing(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseGmtMillisForDatetimes(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseHostsInPrivileges(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseInformationSchema(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseJDBCCompliantTimezoneShift(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseJvmCharsetConverters(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseLegacyDatetimeCode(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseLocalSessionState(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseNanosForElapsedTime(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseOldAliasMetadataBehavior(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseOldUTF8Behavior(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseOnlyServerErrorMessages(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseReadAheadInput(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseSSL(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseSSPSCompatibleTimezoneShift(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseServerPrepStmts(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseServerPreparedStmts(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseSqlStateCodes(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseStreamLengthsInPrepStmts(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseTimezone(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseUltraDevWorkAround(boolean property) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseUnbufferedInput(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseUnicode(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setVerifyServerCertificate(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setYearIsDateType(boolean flag) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setZeroDateTimeBehavior(String behavior) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean useUnbufferedInput()
/*      */   {
/* 2599 */     return getCurrentConnection().useUnbufferedInput();
/*      */   }
/*      */   
/*      */   public boolean isSameResource(Connection c) {
/* 2603 */     return getCurrentConnection().isSameResource(c);
/*      */   }
/*      */   
/*      */   public void setInGlobalTx(boolean flag) {
/* 2607 */     getCurrentConnection().setInGlobalTx(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseColumnNamesInFindColumn() {
/* 2611 */     return getCurrentConnection().getUseColumnNamesInFindColumn();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUseColumnNamesInFindColumn(boolean flag) {}
/*      */   
/*      */   public boolean getUseLocalTransactionState()
/*      */   {
/* 2619 */     return getCurrentConnection().getUseLocalTransactionState();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUseLocalTransactionState(boolean flag) {}
/*      */   
/*      */ 
/*      */   public boolean getCompensateOnDuplicateKeyUpdateCounts()
/*      */   {
/* 2628 */     return getCurrentConnection().getCompensateOnDuplicateKeyUpdateCounts();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) {}
/*      */   
/*      */ 
/*      */   public boolean getUseAffectedRows()
/*      */   {
/* 2637 */     return getCurrentConnection().getUseAffectedRows();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUseAffectedRows(boolean flag) {}
/*      */   
/*      */ 
/*      */   public String getPasswordCharacterEncoding()
/*      */   {
/* 2646 */     return getCurrentConnection().getPasswordCharacterEncoding();
/*      */   }
/*      */   
/*      */   public void setPasswordCharacterEncoding(String characterSet) {
/* 2650 */     getCurrentConnection().setPasswordCharacterEncoding(characterSet);
/*      */   }
/*      */   
/*      */   public int getAutoIncrementIncrement() {
/* 2654 */     return getCurrentConnection().getAutoIncrementIncrement();
/*      */   }
/*      */   
/*      */   public int getLoadBalanceBlacklistTimeout() {
/* 2658 */     return getCurrentConnection().getLoadBalanceBlacklistTimeout();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) throws SQLException {
/* 2662 */     getCurrentConnection().setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout);
/*      */   }
/*      */   
/*      */   public int getLoadBalancePingTimeout() {
/* 2666 */     return getCurrentConnection().getLoadBalancePingTimeout();
/*      */   }
/*      */   
/*      */   public void setLoadBalancePingTimeout(int loadBalancePingTimeout) throws SQLException {
/* 2670 */     getCurrentConnection().setLoadBalancePingTimeout(loadBalancePingTimeout);
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceValidateConnectionOnSwapServer() {
/* 2674 */     return getCurrentConnection().getLoadBalanceValidateConnectionOnSwapServer();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceValidateConnectionOnSwapServer(boolean loadBalanceValidateConnectionOnSwapServer) {
/* 2678 */     getCurrentConnection().setLoadBalanceValidateConnectionOnSwapServer(loadBalanceValidateConnectionOnSwapServer);
/*      */   }
/*      */   
/*      */   public int getRetriesAllDown() {
/* 2682 */     return getCurrentConnection().getRetriesAllDown();
/*      */   }
/*      */   
/*      */   public void setRetriesAllDown(int retriesAllDown) throws SQLException {
/* 2686 */     getCurrentConnection().setRetriesAllDown(retriesAllDown);
/*      */   }
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/* 2690 */     return getCurrentConnection().getExceptionInterceptor();
/*      */   }
/*      */   
/*      */   public String getExceptionInterceptors() {
/* 2694 */     return getCurrentConnection().getExceptionInterceptors();
/*      */   }
/*      */   
/*      */   public void setExceptionInterceptors(String exceptionInterceptors) {
/* 2698 */     getCurrentConnection().setExceptionInterceptors(exceptionInterceptors);
/*      */   }
/*      */   
/*      */   public boolean getQueryTimeoutKillsConnection() {
/* 2702 */     return getCurrentConnection().getQueryTimeoutKillsConnection();
/*      */   }
/*      */   
/*      */   public void setQueryTimeoutKillsConnection(boolean queryTimeoutKillsConnection) {
/* 2706 */     getCurrentConnection().setQueryTimeoutKillsConnection(queryTimeoutKillsConnection);
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(Connection c) {
/* 2710 */     return (this.masterConnection.hasSameProperties(c)) && (this.slavesConnection.hasSameProperties(c));
/*      */   }
/*      */   
/*      */   public Properties getProperties() {
/* 2714 */     Properties props = new Properties();
/* 2715 */     props.putAll(this.masterConnection.getProperties());
/* 2716 */     props.putAll(this.slavesConnection.getProperties());
/*      */     
/* 2718 */     return props;
/*      */   }
/*      */   
/*      */   public String getHost() {
/* 2722 */     return getCurrentConnection().getHost();
/*      */   }
/*      */   
/*      */   public void setProxy(MySQLConnection proxy) {
/* 2726 */     this.proxy = proxy;
/* 2727 */     if (this.masterConnection != null) {
/* 2728 */       this.masterConnection.setProxy(proxy);
/*      */     }
/* 2730 */     if (this.slavesConnection != null) {
/* 2731 */       this.slavesConnection.setProxy(proxy);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getRetainStatementAfterResultSetClose() {
/* 2736 */     return getCurrentConnection().getRetainStatementAfterResultSetClose();
/*      */   }
/*      */   
/*      */   public int getMaxAllowedPacket() {
/* 2740 */     return getCurrentConnection().getMaxAllowedPacket();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceConnectionGroup() {
/* 2744 */     return getCurrentConnection().getLoadBalanceConnectionGroup();
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceEnableJMX() {
/* 2748 */     return getCurrentConnection().getLoadBalanceEnableJMX();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceExceptionChecker() {
/* 2752 */     return this.currentConnection.getLoadBalanceExceptionChecker();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLExceptionSubclassFailover() {
/* 2756 */     return this.currentConnection.getLoadBalanceSQLExceptionSubclassFailover();
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLStateFailover() {
/* 2760 */     return this.currentConnection.getLoadBalanceSQLStateFailover();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceConnectionGroup(String loadBalanceConnectionGroup) {
/* 2764 */     this.currentConnection.setLoadBalanceConnectionGroup(loadBalanceConnectionGroup);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceEnableJMX(boolean loadBalanceEnableJMX)
/*      */   {
/* 2769 */     this.currentConnection.setLoadBalanceEnableJMX(loadBalanceEnableJMX);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceExceptionChecker(String loadBalanceExceptionChecker)
/*      */   {
/* 2774 */     this.currentConnection.setLoadBalanceExceptionChecker(loadBalanceExceptionChecker);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLExceptionSubclassFailover(String loadBalanceSQLExceptionSubclassFailover)
/*      */   {
/* 2779 */     this.currentConnection.setLoadBalanceSQLExceptionSubclassFailover(loadBalanceSQLExceptionSubclassFailover);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLStateFailover(String loadBalanceSQLStateFailover)
/*      */   {
/* 2784 */     this.currentConnection.setLoadBalanceSQLStateFailover(loadBalanceSQLStateFailover);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceAutoCommitStatementRegex()
/*      */   {
/* 2789 */     return getCurrentConnection().getLoadBalanceAutoCommitStatementRegex();
/*      */   }
/*      */   
/*      */   public int getLoadBalanceAutoCommitStatementThreshold() {
/* 2793 */     return getCurrentConnection().getLoadBalanceAutoCommitStatementThreshold();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementRegex(String loadBalanceAutoCommitStatementRegex) {
/* 2797 */     getCurrentConnection().setLoadBalanceAutoCommitStatementRegex(loadBalanceAutoCommitStatementRegex);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementThreshold(int loadBalanceAutoCommitStatementThreshold) throws SQLException
/*      */   {
/* 2802 */     getCurrentConnection().setLoadBalanceAutoCommitStatementThreshold(loadBalanceAutoCommitStatementThreshold);
/*      */   }
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException
/*      */   {}
/*      */   
/*      */   public boolean getIncludeThreadDumpInDeadlockExceptions()
/*      */   {
/* 2810 */     return getCurrentConnection().getIncludeThreadDumpInDeadlockExceptions();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadDumpInDeadlockExceptions(boolean flag) {
/* 2814 */     getCurrentConnection().setIncludeThreadDumpInDeadlockExceptions(flag);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadNamesAsStatementComment()
/*      */   {
/* 2819 */     return getCurrentConnection().getIncludeThreadNamesAsStatementComment();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadNamesAsStatementComment(boolean flag) {
/* 2823 */     getCurrentConnection().setIncludeThreadNamesAsStatementComment(flag);
/*      */   }
/*      */   
/*      */   public boolean isServerLocal() throws SQLException {
/* 2827 */     return getCurrentConnection().isServerLocal();
/*      */   }
/*      */   
/*      */   public void setAuthenticationPlugins(String authenticationPlugins) {
/* 2831 */     getCurrentConnection().setAuthenticationPlugins(authenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getAuthenticationPlugins() {
/* 2835 */     return getCurrentConnection().getAuthenticationPlugins();
/*      */   }
/*      */   
/*      */   public void setDisabledAuthenticationPlugins(String disabledAuthenticationPlugins) {
/* 2839 */     getCurrentConnection().setDisabledAuthenticationPlugins(disabledAuthenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getDisabledAuthenticationPlugins() {
/* 2843 */     return getCurrentConnection().getDisabledAuthenticationPlugins();
/*      */   }
/*      */   
/*      */   public void setDefaultAuthenticationPlugin(String defaultAuthenticationPlugin) {
/* 2847 */     getCurrentConnection().setDefaultAuthenticationPlugin(defaultAuthenticationPlugin);
/*      */   }
/*      */   
/*      */   public String getDefaultAuthenticationPlugin() {
/* 2851 */     return getCurrentConnection().getDefaultAuthenticationPlugin();
/*      */   }
/*      */   
/*      */   public void setParseInfoCacheFactory(String factoryClassname) {
/* 2855 */     getCurrentConnection().setParseInfoCacheFactory(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getParseInfoCacheFactory() {
/* 2859 */     return getCurrentConnection().getParseInfoCacheFactory();
/*      */   }
/*      */   
/*      */   public void setSchema(String schema) throws SQLException {
/* 2863 */     getCurrentConnection().setSchema(schema);
/*      */   }
/*      */   
/*      */   public String getSchema() throws SQLException {
/* 2867 */     return getCurrentConnection().getSchema();
/*      */   }
/*      */   
/*      */   public void abort(Executor executor) throws SQLException {
/* 2871 */     getCurrentConnection().abort(executor);
/* 2872 */     if (this.connectionGroup != null) {
/* 2873 */       this.connectionGroup.handleCloseConnection(this);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
/* 2878 */     getCurrentConnection().setNetworkTimeout(executor, milliseconds);
/*      */   }
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/* 2882 */     return getCurrentConnection().getNetworkTimeout();
/*      */   }
/*      */   
/*      */   public void setServerConfigCacheFactory(String factoryClassname) {
/* 2886 */     getCurrentConnection().setServerConfigCacheFactory(factoryClassname);
/*      */   }
/*      */   
/*      */   public String getServerConfigCacheFactory() {
/* 2890 */     return getCurrentConnection().getServerConfigCacheFactory();
/*      */   }
/*      */   
/*      */   public void setDisconnectOnExpiredPasswords(boolean disconnectOnExpiredPasswords) {
/* 2894 */     getCurrentConnection().setDisconnectOnExpiredPasswords(disconnectOnExpiredPasswords);
/*      */   }
/*      */   
/*      */   public boolean getDisconnectOnExpiredPasswords() {
/* 2898 */     return getCurrentConnection().getDisconnectOnExpiredPasswords();
/*      */   }
/*      */   
/*      */   public void setGetProceduresReturnsFunctions(boolean getProcedureReturnsFunctions) {
/* 2902 */     getCurrentConnection().setGetProceduresReturnsFunctions(getProcedureReturnsFunctions);
/*      */   }
/*      */   
/*      */   public boolean getGetProceduresReturnsFunctions() {
/* 2906 */     return getCurrentConnection().getGetProceduresReturnsFunctions();
/*      */   }
/*      */   
/*      */   public void abortInternal() throws SQLException {
/* 2910 */     getCurrentConnection().abortInternal();
/* 2911 */     if (this.connectionGroup != null) {
/* 2912 */       this.connectionGroup.handleCloseConnection(this);
/*      */     }
/*      */   }
/*      */   
/*      */   public void checkClosed() throws SQLException {
/* 2917 */     getCurrentConnection().checkClosed();
/*      */   }
/*      */   
/*      */   public Object getConnectionMutex() {
/* 2921 */     return getCurrentConnection().getConnectionMutex();
/*      */   }
/*      */   
/*      */   public boolean getAllowMasterDownConnections() {
/* 2925 */     return this.allowMasterDownConnections;
/*      */   }
/*      */   
/*      */   public void setAllowMasterDownConnections(boolean connectIfMasterDown) {
/* 2929 */     this.allowMasterDownConnections = connectIfMasterDown;
/*      */   }
/*      */   
/*      */   public boolean getReplicationEnableJMX() {
/* 2933 */     return this.enableJMX;
/*      */   }
/*      */   
/*      */   public void setReplicationEnableJMX(boolean replicationEnableJMX) {
/* 2937 */     this.enableJMX = replicationEnableJMX;
/*      */   }
/*      */   
/*      */   public String getConnectionAttributes() throws SQLException
/*      */   {
/* 2942 */     return getCurrentConnection().getConnectionAttributes();
/*      */   }
/*      */   
/*      */   public void setDetectCustomCollations(boolean detectCustomCollations) {
/* 2946 */     getCurrentConnection().setDetectCustomCollations(detectCustomCollations);
/*      */   }
/*      */   
/*      */   public boolean getDetectCustomCollations() {
/* 2950 */     return getCurrentConnection().getDetectCustomCollations();
/*      */   }
/*      */   
/*      */   public int getSessionMaxRows() {
/* 2954 */     return getCurrentConnection().getSessionMaxRows();
/*      */   }
/*      */   
/*      */   public void setSessionMaxRows(int max) throws SQLException {
/* 2958 */     getCurrentConnection().setSessionMaxRows(max);
/*      */   }
/*      */   
/*      */   public String getServerRSAPublicKeyFile() {
/* 2962 */     return getCurrentConnection().getServerRSAPublicKeyFile();
/*      */   }
/*      */   
/*      */   public void setServerRSAPublicKeyFile(String serverRSAPublicKeyFile) throws SQLException {
/* 2966 */     getCurrentConnection().setServerRSAPublicKeyFile(serverRSAPublicKeyFile);
/*      */   }
/*      */   
/*      */   public boolean getAllowPublicKeyRetrieval() {
/* 2970 */     return getCurrentConnection().getAllowPublicKeyRetrieval();
/*      */   }
/*      */   
/*      */   public void setAllowPublicKeyRetrieval(boolean allowPublicKeyRetrieval) throws SQLException {
/* 2974 */     getCurrentConnection().setAllowPublicKeyRetrieval(allowPublicKeyRetrieval);
/*      */   }
/*      */   
/*      */   public void setDontCheckOnDuplicateKeyUpdateInSQL(boolean dontCheckOnDuplicateKeyUpdateInSQL) {
/* 2978 */     getCurrentConnection().setDontCheckOnDuplicateKeyUpdateInSQL(dontCheckOnDuplicateKeyUpdateInSQL);
/*      */   }
/*      */   
/*      */   public boolean getDontCheckOnDuplicateKeyUpdateInSQL() {
/* 2982 */     return getCurrentConnection().getDontCheckOnDuplicateKeyUpdateInSQL();
/*      */   }
/*      */   
/*      */   public void setSocksProxyHost(String socksProxyHost) {
/* 2986 */     getCurrentConnection().setSocksProxyHost(socksProxyHost);
/*      */   }
/*      */   
/*      */   public String getSocksProxyHost() {
/* 2990 */     return getCurrentConnection().getSocksProxyHost();
/*      */   }
/*      */   
/*      */   public void setSocksProxyPort(int socksProxyPort) throws SQLException {
/* 2994 */     getCurrentConnection().setSocksProxyPort(socksProxyPort);
/*      */   }
/*      */   
/*      */   public int getSocksProxyPort() {
/* 2998 */     return getCurrentConnection().getSocksProxyPort();
/*      */   }
/*      */   
/*      */   public boolean getReadOnlyPropagatesToServer() {
/* 3002 */     return getCurrentConnection().getReadOnlyPropagatesToServer();
/*      */   }
/*      */   
/*      */   public void setReadOnlyPropagatesToServer(boolean flag) {
/* 3006 */     getCurrentConnection().setReadOnlyPropagatesToServer(flag);
/*      */   }
/*      */   
/*      */   public String getEnabledSSLCipherSuites() {
/* 3010 */     return getCurrentConnection().getEnabledSSLCipherSuites();
/*      */   }
/*      */   
/*      */   public void setEnabledSSLCipherSuites(String cipherSuites) {
/* 3014 */     getCurrentConnection().setEnabledSSLCipherSuites(cipherSuites);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/ReplicationConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */