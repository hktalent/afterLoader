/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Properties;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeUtil
/*     */ {
/*  42 */   static final TimeZone GMT_TIMEZONE = TimeZone.getTimeZone("GMT");
/*     */   
/*     */ 
/*  45 */   private static final TimeZone DEFAULT_TIMEZONE = TimeZone.getDefault();
/*     */   
/*     */ 
/*     */   private static final String TIME_ZONE_MAPPINGS_RESOURCE = "/com/mysql/jdbc/TimeZoneMapping.properties";
/*     */   
/*  50 */   private static Properties timeZoneMappings = null;
/*     */   protected static final Method systemNanoTimeMethod;
/*     */   
/*     */   static
/*     */   {
/*     */     Method aMethod;
/*     */     try
/*     */     {
/*  58 */       aMethod = System.class.getMethod("nanoTime", (Class[])null);
/*     */     } catch (SecurityException e) {
/*  60 */       aMethod = null;
/*     */     } catch (NoSuchMethodException e) {
/*  62 */       aMethod = null;
/*     */     }
/*     */     
/*  65 */     systemNanoTimeMethod = aMethod;
/*     */   }
/*     */   
/*     */   public static boolean nanoTimeAvailable() {
/*  69 */     return systemNanoTimeMethod != null;
/*     */   }
/*     */   
/*     */   public static final TimeZone getDefaultTimeZone(boolean useCache) {
/*  73 */     return (TimeZone)(useCache ? DEFAULT_TIMEZONE.clone() : TimeZone.getDefault().clone());
/*     */   }
/*     */   
/*     */   public static long getCurrentTimeNanosOrMillis() {
/*  77 */     if (systemNanoTimeMethod != null) {
/*     */       try {
/*  79 */         return ((Long)systemNanoTimeMethod.invoke(null, (Object[])null)).longValue();
/*     */       }
/*     */       catch (IllegalArgumentException e) {}catch (IllegalAccessException e) {}catch (InvocationTargetException e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     return System.currentTimeMillis();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Time changeTimezone(MySQLConnection conn, Calendar sessionCalendar, Calendar targetCalendar, Time t, TimeZone fromTz, TimeZone toTz, boolean rollForward)
/*     */   {
/* 108 */     if (conn != null) {
/* 109 */       if ((conn.getUseTimezone()) && (!conn.getNoTimezoneConversionForTimeType()))
/*     */       {
/* 111 */         Calendar fromCal = Calendar.getInstance(fromTz);
/* 112 */         fromCal.setTime(t);
/*     */         
/* 114 */         int fromOffset = fromCal.get(15) + fromCal.get(16);
/* 115 */         Calendar toCal = Calendar.getInstance(toTz);
/* 116 */         toCal.setTime(t);
/*     */         
/* 118 */         int toOffset = toCal.get(15) + toCal.get(16);
/* 119 */         int offsetDiff = fromOffset - toOffset;
/* 120 */         long toTime = toCal.getTime().getTime();
/*     */         
/* 122 */         if ((rollForward) || ((conn.isServerTzUTC()) && (!conn.isClientTzUTC()))) {
/* 123 */           toTime += offsetDiff;
/*     */         } else {
/* 125 */           toTime -= offsetDiff;
/*     */         }
/*     */         
/* 128 */         Time changedTime = new Time(toTime);
/*     */         
/* 130 */         return changedTime; }
/* 131 */       if ((conn.getUseJDBCCompliantTimezoneShift()) && 
/* 132 */         (targetCalendar != null))
/*     */       {
/* 134 */         Time adjustedTime = new Time(jdbcCompliantZoneShift(sessionCalendar, targetCalendar, t));
/*     */         
/* 136 */         return adjustedTime;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 141 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Timestamp changeTimezone(MySQLConnection conn, Calendar sessionCalendar, Calendar targetCalendar, Timestamp tstamp, TimeZone fromTz, TimeZone toTz, boolean rollForward)
/*     */   {
/* 160 */     if (conn != null) {
/* 161 */       if (conn.getUseTimezone())
/*     */       {
/* 163 */         Calendar fromCal = Calendar.getInstance(fromTz);
/* 164 */         fromCal.setTime(tstamp);
/*     */         
/* 166 */         int fromOffset = fromCal.get(15) + fromCal.get(16);
/* 167 */         Calendar toCal = Calendar.getInstance(toTz);
/* 168 */         toCal.setTime(tstamp);
/*     */         
/* 170 */         int toOffset = toCal.get(15) + toCal.get(16);
/* 171 */         int offsetDiff = fromOffset - toOffset;
/* 172 */         long toTime = toCal.getTime().getTime();
/*     */         
/* 174 */         if ((rollForward) || ((conn.isServerTzUTC()) && (!conn.isClientTzUTC()))) {
/* 175 */           toTime += offsetDiff;
/*     */         } else {
/* 177 */           toTime -= offsetDiff;
/*     */         }
/*     */         
/* 180 */         Timestamp changedTimestamp = new Timestamp(toTime);
/*     */         
/* 182 */         return changedTimestamp; }
/* 183 */       if ((conn.getUseJDBCCompliantTimezoneShift()) && 
/* 184 */         (targetCalendar != null))
/*     */       {
/* 186 */         Timestamp adjustedTimestamp = new Timestamp(jdbcCompliantZoneShift(sessionCalendar, targetCalendar, tstamp));
/*     */         
/* 188 */         adjustedTimestamp.setNanos(tstamp.getNanos());
/*     */         
/* 190 */         return adjustedTimestamp;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 195 */     return tstamp;
/*     */   }
/*     */   
/*     */   private static long jdbcCompliantZoneShift(Calendar sessionCalendar, Calendar targetCalendar, java.util.Date dt) {
/* 199 */     if (sessionCalendar == null) {
/* 200 */       sessionCalendar = new GregorianCalendar();
/*     */     }
/*     */     
/* 203 */     synchronized (sessionCalendar)
/*     */     {
/*     */ 
/* 206 */       java.util.Date origCalDate = targetCalendar.getTime();
/* 207 */       java.util.Date origSessionDate = sessionCalendar.getTime();
/*     */       try
/*     */       {
/* 210 */         sessionCalendar.setTime(dt);
/*     */         
/* 212 */         targetCalendar.set(1, sessionCalendar.get(1));
/* 213 */         targetCalendar.set(2, sessionCalendar.get(2));
/* 214 */         targetCalendar.set(5, sessionCalendar.get(5));
/*     */         
/* 216 */         targetCalendar.set(11, sessionCalendar.get(11));
/* 217 */         targetCalendar.set(12, sessionCalendar.get(12));
/* 218 */         targetCalendar.set(13, sessionCalendar.get(13));
/* 219 */         targetCalendar.set(14, sessionCalendar.get(14));
/*     */         
/* 221 */         long l = targetCalendar.getTime().getTime();jsr 16;return l;
/*     */       }
/*     */       finally {
/* 224 */         jsr 6; } localObject2 = returnAddress;sessionCalendar.setTime(origSessionDate);
/* 225 */       targetCalendar.setTime(origCalDate);ret;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static final java.sql.Date fastDateCreate(boolean useGmtConversion, Calendar gmtCalIfNeeded, Calendar cal, int year, int month, int day)
/*     */   {
/* 232 */     Calendar dateCal = cal;
/*     */     
/* 234 */     if (useGmtConversion)
/*     */     {
/* 236 */       if (gmtCalIfNeeded == null) {
/* 237 */         gmtCalIfNeeded = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*     */       }
/*     */       
/* 240 */       dateCal = gmtCalIfNeeded;
/*     */     }
/*     */     
/* 243 */     synchronized (dateCal) {
/* 244 */       java.util.Date origCalDate = dateCal.getTime();
/*     */       try {
/* 246 */         dateCal.clear();
/* 247 */         dateCal.set(14, 0);
/*     */         
/*     */ 
/* 250 */         dateCal.set(year, month - 1, day, 0, 0, 0);
/*     */         
/* 252 */         long dateAsMillis = dateCal.getTimeInMillis();
/*     */         
/* 254 */         java.sql.Date localDate = new java.sql.Date(dateAsMillis);jsr 17;return localDate;
/*     */       } finally {
/* 256 */         jsr 6; } localObject2 = returnAddress;dateCal.setTime(origCalDate);ret;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final java.sql.Date fastDateCreate(int year, int month, int day, Calendar targetCalendar)
/*     */   {
/* 264 */     Calendar dateCal = targetCalendar == null ? new GregorianCalendar() : targetCalendar;
/*     */     
/* 266 */     synchronized (dateCal) {
/* 267 */       java.util.Date origCalDate = dateCal.getTime();
/*     */       try {
/* 269 */         dateCal.clear();
/*     */         
/*     */ 
/* 272 */         dateCal.set(year, month - 1, day, 0, 0, 0);
/* 273 */         dateCal.set(14, 0);
/*     */         
/* 275 */         long dateAsMillis = dateCal.getTimeInMillis();
/*     */         
/* 277 */         java.sql.Date localDate = new java.sql.Date(dateAsMillis);jsr 17;return localDate;
/*     */       } finally {
/* 279 */         jsr 6; } localObject2 = returnAddress;dateCal.setTime(origCalDate);ret;
/*     */     }
/*     */   }
/*     */   
/*     */   static final Time fastTimeCreate(Calendar cal, int hour, int minute, int second, ExceptionInterceptor exceptionInterceptor) throws SQLException
/*     */   {
/* 285 */     if ((hour < 0) || (hour > 24)) {
/* 286 */       throw SQLError.createSQLException("Illegal hour value '" + hour + "' for java.sql.Time type in value '" + timeFormattedString(hour, minute, second) + ".", "S1009", exceptionInterceptor);
/*     */     }
/*     */     
/*     */ 
/* 290 */     if ((minute < 0) || (minute > 59)) {
/* 291 */       throw SQLError.createSQLException("Illegal minute value '" + minute + "' for java.sql.Time type in value '" + timeFormattedString(hour, minute, second) + ".", "S1009", exceptionInterceptor);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 296 */     if ((second < 0) || (second > 59)) {
/* 297 */       throw SQLError.createSQLException("Illegal minute value '" + second + "' for java.sql.Time type in value '" + timeFormattedString(hour, minute, second) + ".", "S1009", exceptionInterceptor);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 302 */     synchronized (cal) {
/* 303 */       java.util.Date origCalDate = cal.getTime();
/*     */       try {
/* 305 */         cal.clear();
/*     */         
/*     */ 
/* 308 */         cal.set(1970, 0, 1, hour, minute, second);
/*     */         
/* 310 */         long timeAsMillis = cal.getTimeInMillis();
/*     */         
/* 312 */         Time localTime = new Time(timeAsMillis);jsr 17;return localTime;
/*     */       } finally {
/* 314 */         jsr 6; } localObject2 = returnAddress;cal.setTime(origCalDate);ret;
/*     */     }
/*     */   }
/*     */   
/*     */   static final Time fastTimeCreate(int hour, int minute, int second, Calendar targetCalendar, ExceptionInterceptor exceptionInterceptor) throws SQLException
/*     */   {
/* 320 */     if ((hour < 0) || (hour > 23)) {
/* 321 */       throw SQLError.createSQLException("Illegal hour value '" + hour + "' for java.sql.Time type in value '" + timeFormattedString(hour, minute, second) + ".", "S1009", exceptionInterceptor);
/*     */     }
/*     */     
/*     */ 
/* 325 */     if ((minute < 0) || (minute > 59)) {
/* 326 */       throw SQLError.createSQLException("Illegal minute value '" + minute + "' for java.sql.Time type in value '" + timeFormattedString(hour, minute, second) + ".", "S1009", exceptionInterceptor);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 331 */     if ((second < 0) || (second > 59)) {
/* 332 */       throw SQLError.createSQLException("Illegal minute value '" + second + "' for java.sql.Time type in value '" + timeFormattedString(hour, minute, second) + ".", "S1009", exceptionInterceptor);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 337 */     Calendar cal = targetCalendar == null ? new GregorianCalendar() : targetCalendar;
/*     */     
/* 339 */     synchronized (cal) {
/* 340 */       java.util.Date origCalDate = cal.getTime();
/*     */       try {
/* 342 */         cal.clear();
/*     */         
/*     */ 
/* 345 */         cal.set(1970, 0, 1, hour, minute, second);
/*     */         
/* 347 */         long timeAsMillis = cal.getTimeInMillis();
/*     */         
/* 349 */         Time localTime = new Time(timeAsMillis);jsr 17;return localTime;
/*     */       } finally {
/* 351 */         jsr 6; } localObject2 = returnAddress;cal.setTime(origCalDate);ret;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final Timestamp fastTimestampCreate(boolean useGmtConversion, Calendar gmtCalIfNeeded, Calendar cal, int year, int month, int day, int hour, int minute, int seconds, int secondsPart)
/*     */   {
/* 359 */     synchronized (cal) {
/* 360 */       java.util.Date origCalDate = cal.getTime();
/*     */       try {
/* 362 */         cal.clear();
/*     */         
/*     */ 
/* 365 */         cal.set(year, month - 1, day, hour, minute, seconds);
/*     */         
/* 367 */         int offsetDiff = 0;
/*     */         
/* 369 */         if (useGmtConversion) {
/* 370 */           int fromOffset = cal.get(15) + cal.get(16);
/*     */           
/* 372 */           if (gmtCalIfNeeded == null) {
/* 373 */             gmtCalIfNeeded = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*     */           }
/* 375 */           gmtCalIfNeeded.clear();
/*     */           
/* 377 */           gmtCalIfNeeded.setTimeInMillis(cal.getTimeInMillis());
/*     */           
/* 379 */           int toOffset = gmtCalIfNeeded.get(15) + gmtCalIfNeeded.get(16);
/* 380 */           offsetDiff = fromOffset - toOffset;
/*     */         }
/*     */         
/* 383 */         if (secondsPart != 0) {
/* 384 */           cal.set(14, secondsPart / 1000000);
/*     */         }
/*     */         
/* 387 */         long tsAsMillis = cal.getTimeInMillis();
/*     */         
/* 389 */         Timestamp ts = new Timestamp(tsAsMillis + offsetDiff);
/*     */         
/* 391 */         ts.setNanos(secondsPart);
/*     */         
/* 393 */         Timestamp localTimestamp1 = ts;jsr 17;return localTimestamp1;
/*     */       } finally {
/* 395 */         jsr 6; } localObject2 = returnAddress;cal.setTime(origCalDate);ret;
/*     */     }
/*     */   }
/*     */   
/*     */   static final Timestamp fastTimestampCreate(TimeZone tz, int year, int month, int day, int hour, int minute, int seconds, int secondsPart)
/*     */   {
/* 401 */     Calendar cal = tz == null ? new GregorianCalendar() : new GregorianCalendar(tz);
/* 402 */     cal.clear();
/*     */     
/*     */ 
/* 405 */     cal.set(year, month - 1, day, hour, minute, seconds);
/*     */     
/* 407 */     long tsAsMillis = cal.getTimeInMillis();
/*     */     
/* 409 */     Timestamp ts = new Timestamp(tsAsMillis);
/* 410 */     ts.setNanos(secondsPart);
/*     */     
/* 412 */     return ts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCanonicalTimezone(String timezoneStr, ExceptionInterceptor exceptionInterceptor)
/*     */     throws SQLException
/*     */   {
/* 427 */     if (timezoneStr == null) {
/* 428 */       return null;
/*     */     }
/*     */     
/* 431 */     timezoneStr = timezoneStr.trim();
/*     */     
/*     */ 
/* 434 */     if ((timezoneStr.length() > 2) && 
/* 435 */       ((timezoneStr.charAt(0) == '+') || (timezoneStr.charAt(0) == '-')) && (Character.isDigit(timezoneStr.charAt(1)))) {
/* 436 */       return "GMT" + timezoneStr;
/*     */     }
/*     */     
/*     */ 
/* 440 */     synchronized (TimeUtil.class) {
/* 441 */       if (timeZoneMappings == null) {
/* 442 */         loadTimeZoneMappings(exceptionInterceptor);
/*     */       }
/*     */     }
/*     */     
/*     */     String canonicalTz;
/* 447 */     if ((canonicalTz = timeZoneMappings.getProperty(timezoneStr)) != null) {
/* 448 */       return canonicalTz;
/*     */     }
/*     */     
/* 451 */     throw SQLError.createSQLException(Messages.getString("TimeUtil.UnrecognizedTimezoneId", new Object[] { timezoneStr }), "01S00", exceptionInterceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String timeFormattedString(int hours, int minutes, int seconds)
/*     */   {
/* 458 */     StringBuilder buf = new StringBuilder(8);
/* 459 */     if (hours < 10) {
/* 460 */       buf.append("0");
/*     */     }
/*     */     
/* 463 */     buf.append(hours);
/* 464 */     buf.append(":");
/*     */     
/* 466 */     if (minutes < 10) {
/* 467 */       buf.append("0");
/*     */     }
/*     */     
/* 470 */     buf.append(minutes);
/* 471 */     buf.append(":");
/*     */     
/* 473 */     if (seconds < 10) {
/* 474 */       buf.append("0");
/*     */     }
/*     */     
/* 477 */     buf.append(seconds);
/*     */     
/* 479 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public static String formatNanos(int nanos, boolean serverSupportsFracSecs, boolean usingMicros)
/*     */   {
/* 485 */     if (nanos > 999999999) {
/* 486 */       nanos %= 100000000;
/*     */     }
/*     */     
/* 489 */     if (usingMicros) {
/* 490 */       nanos /= 1000;
/*     */     }
/*     */     
/* 493 */     if ((!serverSupportsFracSecs) || (nanos == 0)) {
/* 494 */       return "0";
/*     */     }
/*     */     
/* 497 */     int digitCount = usingMicros ? 6 : 9;
/*     */     
/* 499 */     String nanosString = Integer.toString(nanos);
/* 500 */     String zeroPadding = usingMicros ? "000000" : "000000000";
/*     */     
/* 502 */     nanosString = zeroPadding.substring(0, digitCount - nanosString.length()) + nanosString;
/*     */     
/* 504 */     int pos = digitCount - 1;
/*     */     
/* 506 */     while (nanosString.charAt(pos) == '0') {
/* 507 */       pos--;
/*     */     }
/*     */     
/* 510 */     nanosString = nanosString.substring(0, pos + 1);
/*     */     
/* 512 */     return nanosString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void loadTimeZoneMappings(ExceptionInterceptor exceptionInterceptor)
/*     */     throws SQLException
/*     */   {
/* 522 */     timeZoneMappings = new Properties();
/*     */     try {
/* 524 */       timeZoneMappings.load(TimeZone.class.getResourceAsStream("/com/mysql/jdbc/TimeZoneMapping.properties"));
/*     */     } catch (IOException e) {
/* 526 */       throw SQLError.createSQLException(Messages.getString("TimeUtil.LoadTimeZoneMappingError"), "01S00", exceptionInterceptor);
/*     */     }
/*     */     
/*     */ 
/* 530 */     for (String tz : TimeZone.getAvailableIDs()) {
/* 531 */       if (!timeZoneMappings.containsKey(tz)) {
/* 532 */         timeZoneMappings.put(tz, tz);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/mysql-connector-java-5.1.36.jar!/com/mysql/jdbc/TimeUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */