/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.sql.NClob;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerNClob
/*    */   extends SQLServerClobBase
/*    */   implements NClob
/*    */ {
/* 15 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerNClob");
/*    */   
/*    */   SQLServerNClob(SQLServerConnection paramSQLServerConnection)
/*    */   {
/* 19 */     super(paramSQLServerConnection, "", paramSQLServerConnection.getDatabaseCollation(), logger);
/*    */   }
/*    */   
/*    */   SQLServerNClob(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo) throws SQLServerException, UnsupportedEncodingException
/*    */   {
/* 24 */     super(null, new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getSQLCollation(), logger);
/*    */   }
/*    */   
/* 27 */   final JDBCType getJdbcType() { return JDBCType.NCLOB; }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerNClob.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */