/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.bind.DatatypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SQLServerSymmetricKeyCache
/*     */ {
/*  53 */   static Object lock = new Object();
/*     */   private final ConcurrentHashMap<String, SQLServerSymmetricKey> cache;
/*  55 */   private static final SQLServerSymmetricKeyCache instance = new SQLServerSymmetricKeyCache();
/*  56 */   private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1, new ThreadFactory()
/*     */   {
/*     */ 
/*     */ 
/*     */     public Thread newThread(Runnable paramAnonymousRunnable)
/*     */     {
/*     */ 
/*  63 */       Thread localThread = Executors.defaultThreadFactory().newThread(paramAnonymousRunnable);
/*  64 */       localThread.setDaemon(true);
/*  65 */       return localThread;
/*     */     }
/*  56 */   });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerSymmetricKeyCache");
/*     */   
/*     */ 
/*     */   private SQLServerSymmetricKeyCache()
/*     */   {
/*  75 */     this.cache = new ConcurrentHashMap();
/*     */   }
/*     */   
/*     */   static SQLServerSymmetricKeyCache getInstance()
/*     */   {
/*  80 */     return instance;
/*     */   }
/*     */   
/*     */   ConcurrentHashMap<String, SQLServerSymmetricKey> getCache()
/*     */   {
/*  85 */     return this.cache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLServerSymmetricKey getKey(EncryptionKeyInfo paramEncryptionKeyInfo, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/*  96 */     SQLServerSymmetricKey localSQLServerSymmetricKey = null;
/*  97 */     synchronized (lock)
/*     */     {
/*  99 */       String str1 = paramSQLServerConnection.getTrustedServerNameAE();
/* 100 */       assert (null != str1) : "serverName should not be null in getKey.";
/*     */       
/* 102 */       StringBuffer localStringBuffer = new StringBuffer(str1);
/* 103 */       String str2 = null;
/* 104 */       localStringBuffer.append(":");
/*     */       Object localObject2;
/*     */       try
/*     */       {
/* 108 */         localStringBuffer.append(DatatypeConverter.printBase64Binary(new String(paramEncryptionKeyInfo.encryptedKey, "UTF-8").getBytes()));
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */       {
/* 112 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/* 113 */         localObject2 = new Object[] { "UTF-8" };
/* 114 */         throw new SQLServerException(this, ((MessageFormat)localObject1).format(localObject2), null, 0, false);
/*     */       }
/*     */       
/* 117 */       localStringBuffer.append(":");
/* 118 */       localStringBuffer.append(paramEncryptionKeyInfo.keyStoreName);
/* 119 */       str2 = localStringBuffer.toString();
/* 120 */       localStringBuffer.setLength(0);
/*     */       
/* 122 */       if (aeLogger.isLoggable(Level.FINE))
/*     */       {
/* 124 */         aeLogger.fine("Checking trusted master key path...");
/*     */       }
/* 126 */       Boolean[] arrayOfBoolean = new Boolean[1];
/* 127 */       Object localObject1 = SQLServerConnection.getColumnEncryptionTrustedMasterKeyPaths(str1, arrayOfBoolean);
/* 128 */       Object localObject3; if (true == arrayOfBoolean[0].booleanValue())
/*     */       {
/* 130 */         if ((null == localObject1) || (0 == ((List)localObject1).size()) || (!((List)localObject1).contains(paramEncryptionKeyInfo.keyPath))) {
/* 131 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_UntrustedKeyPath"));
/* 132 */           localObject3 = new Object[] { paramEncryptionKeyInfo.keyPath, str1 };
/* 133 */           throw new SQLServerException(this, ((MessageFormat)localObject2).format(localObject3), null, 0, false);
/*     */         }
/*     */       }
/*     */       
/* 137 */       if (aeLogger.isLoggable(Level.FINE))
/*     */       {
/* 139 */         aeLogger.fine("Checking Symmetric key cache...");
/*     */       }
/*     */       
/*     */ 
/* 143 */       if (!this.cache.containsKey(str2))
/*     */       {
/*     */ 
/* 146 */         localObject2 = paramSQLServerConnection.getSystemColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
/*     */         
/*     */ 
/* 149 */         if (null == localObject2)
/*     */         {
/* 151 */           localObject2 = SQLServerConnection.getGlobalSystemColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
/*     */         }
/*     */         
/*     */ 
/* 155 */         if (null == localObject2)
/*     */         {
/* 157 */           localObject2 = SQLServerConnection.getGlobalCustomColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
/*     */         }
/*     */         
/*     */ 
/* 161 */         if (null == localObject2) {
/* 162 */           localObject3 = paramSQLServerConnection.getAllSystemColumnEncryptionKeyStoreProviders();
/* 163 */           String str3 = SQLServerConnection.getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders();
/* 164 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecognizedKeyStoreProviderName"));
/* 165 */           Object[] arrayOfObject = { paramEncryptionKeyInfo.keyStoreName, localObject3, str3 };
/* 166 */           throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */         }
/*     */         
/*     */ 
/* 170 */         localObject3 = ((SQLServerColumnEncryptionKeyStoreProvider)localObject2).decryptColumnEncryptionKey(paramEncryptionKeyInfo.keyPath, paramEncryptionKeyInfo.algorithmName, paramEncryptionKeyInfo.encryptedKey);
/* 171 */         localSQLServerSymmetricKey = new SQLServerSymmetricKey((byte[])localObject3);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */         long l = SQLServerConnection.getColumnEncryptionKeyCacheTtl();
/* 180 */         if (0L != l)
/*     */         {
/* 182 */           this.cache.putIfAbsent(str2, localSQLServerSymmetricKey);
/* 183 */           if (aeLogger.isLoggable(Level.FINE))
/*     */           {
/* 185 */             aeLogger.fine("Adding encryption key to cache...");
/*     */           }
/* 187 */           scheduler.schedule(new CacheClear(str2), l, TimeUnit.SECONDS);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 195 */         localSQLServerSymmetricKey = (SQLServerSymmetricKey)this.cache.get(str2);
/*     */       }
/*     */     }
/* 198 */     return localSQLServerSymmetricKey;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSymmetricKeyCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */