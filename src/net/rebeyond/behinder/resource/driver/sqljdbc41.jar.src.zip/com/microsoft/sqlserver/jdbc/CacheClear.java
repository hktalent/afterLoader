/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheClear
/*    */   implements Runnable
/*    */ {
/*    */   private String keylookupValue;
/* 19 */   private static Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.CacheClear");
/*    */   
/*    */ 
/*    */   CacheClear(String paramString)
/*    */   {
/* 24 */     this.keylookupValue = paramString;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/* 31 */     synchronized (SQLServerSymmetricKeyCache.lock)
/*    */     {
/* 33 */       SQLServerSymmetricKeyCache localSQLServerSymmetricKeyCache = SQLServerSymmetricKeyCache.getInstance();
/* 34 */       if (localSQLServerSymmetricKeyCache.getCache().containsKey(this.keylookupValue))
/*    */       {
/* 36 */         ((SQLServerSymmetricKey)localSQLServerSymmetricKeyCache.getCache().get(this.keylookupValue)).zeroOutKey();
/* 37 */         localSQLServerSymmetricKeyCache.getCache().remove(this.keylookupValue);
/* 38 */         if (aeLogger.isLoggable(Level.FINE))
/*    */         {
/* 40 */           aeLogger.fine("Removed encryption key from cache...");
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/CacheClear.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */