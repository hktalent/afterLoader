/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CekTableEntry
/*     */ {
/*  46 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.AE");
/*     */   
/*     */   Vector<EncryptionKeyInfo> columnEncryptionKeyValues;
/*     */   int ordinal;
/*     */   int databaseId;
/*     */   int cekId;
/*     */   int cekVersion;
/*     */   byte[] cekMdVersion;
/*     */   
/*     */   Vector<EncryptionKeyInfo> getColumnEncryptionKeyValues()
/*     */   {
/*  57 */     return this.columnEncryptionKeyValues;
/*     */   }
/*     */   
/*     */   int getOrdinal() {
/*  61 */     return this.ordinal;
/*     */   }
/*     */   
/*     */   int getDatabaseId() {
/*  65 */     return this.databaseId;
/*     */   }
/*     */   
/*     */   int getCekId() {
/*  69 */     return this.cekId;
/*     */   }
/*     */   
/*     */   int getCekVersion() {
/*  73 */     return this.cekVersion;
/*     */   }
/*     */   
/*     */   byte[] getCekMdVersion() {
/*  77 */     return this.cekMdVersion;
/*     */   }
/*     */   
/*     */   CekTableEntry(int paramInt)
/*     */   {
/*  82 */     this.ordinal = paramInt;
/*  83 */     this.databaseId = 0;
/*  84 */     this.cekId = 0;
/*  85 */     this.cekVersion = 0;
/*  86 */     this.cekMdVersion = null;
/*  87 */     this.columnEncryptionKeyValues = new Vector();
/*     */   }
/*     */   
/*     */   int getSize() {
/*  91 */     return this.columnEncryptionKeyValues.size();
/*     */   }
/*     */   
/*     */   void add(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte2, String paramString1, String paramString2, String paramString3)
/*     */   {
/*  96 */     assert (null != this.columnEncryptionKeyValues) : "columnEncryptionKeyValues should already be initialized.";
/*     */     
/*  98 */     if (aeLogger.isLoggable(Level.FINE)) {
/*  99 */       aeLogger.fine("Retrieving CEK values");
/*     */     }
/*     */     
/* 102 */     EncryptionKeyInfo localEncryptionKeyInfo = new EncryptionKeyInfo(paramArrayOfByte1, paramInt1, paramInt2, paramInt3, paramArrayOfByte2, paramString1, paramString2, paramString3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     this.columnEncryptionKeyValues.add(localEncryptionKeyInfo);
/*     */     
/* 113 */     if (0 == this.databaseId) {
/* 114 */       this.databaseId = paramInt1;
/* 115 */       this.cekId = paramInt2;
/* 116 */       this.cekVersion = paramInt3;
/* 117 */       this.cekMdVersion = paramArrayOfByte2;
/*     */     }
/*     */     else {
/* 120 */       assert (this.databaseId == paramInt1);
/* 121 */       assert (this.cekId == paramInt2);
/* 122 */       assert (this.cekVersion == paramInt3);
/* 123 */       assert ((null != this.cekMdVersion) && (null != paramArrayOfByte2) && (this.cekMdVersion.length == paramArrayOfByte2.length));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/CekTableEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */