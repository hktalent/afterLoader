/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SimpleInputStream
/*     */   extends BaseInputStream
/*     */ {
/*     */   private final int payloadLength;
/*     */   private byte[] bSingleByte;
/*     */   
/*     */   SimpleInputStream(TDSReader paramTDSReader, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl)
/*     */     throws SQLServerException
/*     */   {
/* 140 */     super(paramTDSReader, paramInputStreamGetterArgs.isAdaptive, paramInputStreamGetterArgs.isStreaming, paramServerDTVImpl);
/* 141 */     setLoggingInfo(paramInputStreamGetterArgs.logContext);
/* 142 */     this.payloadLength = paramInt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 151 */     if (null == this.tdsReader)
/* 152 */       return;
/* 153 */     if (logger.isLoggable(Level.FINER)) {
/* 154 */       logger.finer(toString() + "Enter Closing SimpleInputStream.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 159 */     skip(this.payloadLength - this.streamPos);
/*     */     
/* 161 */     closeHelper();
/* 162 */     if (logger.isLoggable(Level.FINER)) {
/* 163 */       logger.finer(toString() + "Exit Closing SimpleInputStream.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private final boolean isEOS()
/*     */     throws IOException
/*     */   {
/* 171 */     assert (this.streamPos <= this.payloadLength);
/* 172 */     return this.streamPos == this.payloadLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long paramLong)
/*     */     throws IOException
/*     */   {
/* 185 */     checkClosed();
/* 186 */     if (logger.isLoggable(Level.FINER))
/* 187 */       logger.finer(toString() + " Skipping :" + paramLong);
/* 188 */     if (paramLong < 0L) return 0L;
/* 189 */     if (isEOS()) { return 0L;
/*     */     }
/*     */     int i;
/* 192 */     if (this.streamPos + paramLong > this.payloadLength)
/*     */     {
/* 194 */       i = this.payloadLength - this.streamPos;
/*     */     }
/*     */     else
/*     */     {
/* 198 */       i = (int)paramLong;
/*     */     }
/*     */     try
/*     */     {
/* 202 */       this.tdsReader.skip(i);
/*     */     }
/*     */     catch (SQLServerException localSQLServerException)
/*     */     {
/* 206 */       throw new IOException(localSQLServerException.getMessage());
/*     */     }
/* 208 */     this.streamPos += i;
/* 209 */     if ((this.isReadLimitSet) && (this.streamPos - this.markedStreamPos > this.readLimit)) {
/* 210 */       clearCurrentMark();
/*     */     }
/* 212 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 224 */     checkClosed();
/* 225 */     assert (this.streamPos <= this.payloadLength);
/*     */     
/* 227 */     int i = this.payloadLength - this.streamPos;
/* 228 */     if (this.tdsReader.available() < i)
/* 229 */       i = this.tdsReader.available();
/* 230 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 241 */     checkClosed();
/* 242 */     if (null == this.bSingleByte)
/* 243 */       this.bSingleByte = new byte[1];
/* 244 */     if (isEOS()) return -1;
/* 245 */     int i = read(this.bSingleByte, 0, 1);
/* 246 */     return 0 == i ? -1 : this.bSingleByte[0] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] paramArrayOfByte)
/*     */     throws IOException
/*     */   {
/* 257 */     checkClosed();
/* 258 */     return read(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException
/*     */   {
/* 271 */     checkClosed();
/* 272 */     if (logger.isLoggable(Level.FINER)) {
/* 273 */       logger.finer(toString() + " Reading " + paramInt2 + " from stream offset " + this.streamPos + " payload length " + this.payloadLength);
/*     */     }
/* 275 */     if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 + paramInt2 > paramArrayOfByte.length)) {
/* 276 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 278 */     if (0 == paramInt2) return 0;
/* 279 */     if (isEOS()) { return -1;
/*     */     }
/* 281 */     int i = 0;
/* 282 */     if (this.streamPos + paramInt2 > this.payloadLength)
/*     */     {
/* 284 */       i = this.payloadLength - this.streamPos;
/*     */     }
/*     */     else
/*     */     {
/* 288 */       i = paramInt2;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 293 */       this.tdsReader.readBytes(paramArrayOfByte, paramInt1, i);
/*     */     }
/*     */     catch (SQLServerException localSQLServerException)
/*     */     {
/* 297 */       throw new IOException(localSQLServerException.getMessage());
/*     */     }
/* 299 */     this.streamPos += i;
/*     */     
/* 301 */     if ((this.isReadLimitSet) && (this.streamPos - this.markedStreamPos > this.readLimit)) {
/* 302 */       clearCurrentMark();
/*     */     }
/* 304 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mark(int paramInt)
/*     */   {
/* 313 */     if ((null != this.tdsReader) && (paramInt > 0))
/*     */     {
/* 315 */       this.currentMark = this.tdsReader.mark();
/* 316 */       this.markedStreamPos = this.streamPos;
/* 317 */       setReadLimit(paramInt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 327 */     resetHelper();
/* 328 */     this.streamPos = this.markedStreamPos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final byte[] getBytes()
/*     */     throws SQLServerException
/*     */   {
/* 339 */     assert (0 == this.streamPos);
/*     */     
/* 341 */     byte[] arrayOfByte = new byte[this.payloadLength];
/*     */     try
/*     */     {
/* 344 */       read(arrayOfByte);
/* 345 */       close();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 349 */       SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 358 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SimpleInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */