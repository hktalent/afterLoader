/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.NClob;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import microsoft.sql.DateTimeOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */  enum JavaType
/*     */ {
/* 490 */   INTEGER(Integer.class, JDBCType.INTEGER), 
/* 491 */   STRING(String.class, JDBCType.CHAR), 
/* 492 */   DATE(java.sql.Date.class, JDBCType.DATE), 
/* 493 */   TIME(Time.class, JDBCType.TIME), 
/* 494 */   TIMESTAMP(Timestamp.class, JDBCType.TIMESTAMP), 
/* 495 */   UTILDATE(java.util.Date.class, JDBCType.TIMESTAMP), 
/* 496 */   CALENDAR(Calendar.class, JDBCType.TIMESTAMP), 
/* 497 */   LOCALDATE(getJavaClass("LocalDate"), JDBCType.DATE), 
/* 498 */   LOCALTIME(getJavaClass("LocalTime"), JDBCType.TIME), 
/* 499 */   LOCALDATETIME(getJavaClass("LocalDateTime"), JDBCType.TIMESTAMP), 
/* 500 */   OFFSETTIME(getJavaClass("OffsetTime"), JDBCType.TIME_WITH_TIMEZONE), 
/* 501 */   OFFSETDATETIME(getJavaClass("OffsetDateTime"), JDBCType.TIMESTAMP_WITH_TIMEZONE), 
/* 502 */   DATETIMEOFFSET(DateTimeOffset.class, JDBCType.DATETIMEOFFSET), 
/* 503 */   BOOLEAN(Boolean.class, JDBCType.BIT), 
/* 504 */   BIGDECIMAL(BigDecimal.class, JDBCType.DECIMAL), 
/* 505 */   DOUBLE(Double.class, JDBCType.DOUBLE), 
/* 506 */   FLOAT(Float.class, JDBCType.REAL), 
/* 507 */   SHORT(Short.class, JDBCType.SMALLINT), 
/* 508 */   LONG(Long.class, JDBCType.BIGINT), 
/* 509 */   BIGINTEGER(BigInteger.class, JDBCType.BIGINT), 
/* 510 */   BYTE(Byte.class, JDBCType.TINYINT), 
/* 511 */   BYTEARRAY(byte[].class, JDBCType.BINARY), 
/*     */   
/* 513 */   NCLOB(NClob.class, JDBCType.NCLOB), 
/* 514 */   CLOB(Clob.class, JDBCType.CLOB), 
/* 515 */   BLOB(Blob.class, JDBCType.BLOB), 
/* 516 */   TVP(TVP.class, JDBCType.TVP), 
/*     */   
/* 518 */   INPUTSTREAM(InputStream.class, JDBCType.UNKNOWN), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 571 */   READER(Reader.class, JDBCType.LONGVARCHAR), 
/*     */   
/* 573 */   SQLXML(SQLServerSQLXML.class, JDBCType.SQLXML), 
/* 574 */   OBJECT(Object.class, JDBCType.UNKNOWN);
/*     */   
/*     */   private final Class<?> javaClass;
/*     */   private final JDBCType jdbcTypeFromJavaType;
/* 578 */   private static double jvmVersion = 0.0D;
/*     */   
/*     */   private JavaType(Class<?> paramClass, JDBCType paramJDBCType)
/*     */   {
/* 582 */     this.javaClass = paramClass;
/* 583 */     this.jdbcTypeFromJavaType = paramJDBCType;
/*     */   }
/*     */   
/*     */   static Class<?> getJavaClass(String paramString)
/*     */   {
/* 588 */     if (0.0D == jvmVersion)
/*     */     {
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*     */ 
/* 596 */         String str = System.getProperty("java.specification.version");
/* 597 */         if (str != null)
/*     */         {
/* 599 */           jvmVersion = Double.parseDouble(str);
/*     */         }
/*     */       }
/*     */       catch (NumberFormatException localNumberFormatException) {
/* 603 */         jvmVersion = 0.1D;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 608 */     if (jvmVersion < 1.8D)
/*     */     {
/* 610 */       return TemporalCompatibility.class;
/*     */     }
/*     */     
/* 613 */     if (paramString.equals("LocalDate"))
/*     */     {
/* 615 */       return LocalDate.class;
/*     */     }
/* 617 */     if (paramString.equals("LocalTime"))
/*     */     {
/* 619 */       return LocalTime.class;
/*     */     }
/* 621 */     if (paramString.equals("LocalDateTime"))
/*     */     {
/* 623 */       return LocalDateTime.class;
/*     */     }
/* 625 */     if (paramString.equals("OffsetTime"))
/*     */     {
/* 627 */       return OffsetTime.class;
/*     */     }
/* 629 */     if (paramString.equals("OffsetDateTime"))
/*     */     {
/* 631 */       return OffsetDateTime.class;
/*     */     }
/* 633 */     return TemporalCompatibility.class;
/*     */   }
/*     */   
/*     */   static JavaType of(Object paramObject)
/*     */   {
/* 638 */     if (((paramObject instanceof SQLServerDataTable)) || ((paramObject instanceof ResultSet)) || ((paramObject instanceof ISQLServerDataRecord)))
/* 639 */       return TVP;
/* 640 */     if (null != paramObject)
/*     */     {
/* 642 */       for (JavaType localJavaType : values()) {
/* 643 */         if (localJavaType.javaClass.isInstance(paramObject))
/* 644 */           return localJavaType;
/*     */       }
/*     */     }
/* 647 */     return OBJECT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   JDBCType getJDBCType(SSType paramSSType, JDBCType paramJDBCType)
/*     */   {
/* 657 */     return this.jdbcTypeFromJavaType;
/*     */   }
/*     */   
/*     */   static enum SetterConversionAE
/*     */   {
/* 662 */     BIT(JavaType.BOOLEAN, EnumSet.of(JDBCType.BIT, JDBCType.TINYINT, JDBCType.SMALLINT, JDBCType.INTEGER, JDBCType.BIGINT)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 672 */     SHORT(JavaType.SHORT, EnumSet.of(JDBCType.TINYINT, JDBCType.SMALLINT, JDBCType.INTEGER, JDBCType.BIGINT)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 681 */     INTEGER(JavaType.INTEGER, EnumSet.of(JDBCType.INTEGER, JDBCType.BIGINT)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 687 */     LONG(JavaType.LONG, EnumSet.of(JDBCType.BIGINT)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 693 */     BIGDECIMAL(JavaType.BIGDECIMAL, EnumSet.of(JDBCType.MONEY, JDBCType.SMALLMONEY, JDBCType.DECIMAL, JDBCType.NUMERIC)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 702 */     BYTE(JavaType.BYTE, EnumSet.of(JDBCType.BINARY, JDBCType.VARBINARY, JDBCType.LONGVARBINARY, JDBCType.TINYINT)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 711 */     BYTEARRAY(JavaType.BYTEARRAY, EnumSet.of(JDBCType.BINARY, JDBCType.VARBINARY, JDBCType.LONGVARBINARY)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 719 */     DATE(JavaType.DATE, EnumSet.of(JDBCType.DATE)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 725 */     DATETIMEOFFSET(JavaType.DATETIMEOFFSET, EnumSet.of(JDBCType.DATETIMEOFFSET)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 731 */     DOUBLE(JavaType.DOUBLE, EnumSet.of(JDBCType.DOUBLE)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 737 */     FLOAT(JavaType.FLOAT, EnumSet.of(JDBCType.REAL, JDBCType.DOUBLE)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 744 */     STRING(JavaType.STRING, EnumSet.of(JDBCType.CHAR, new JDBCType[] { JDBCType.VARCHAR, JDBCType.LONGVARCHAR, JDBCType.NCHAR, JDBCType.NVARCHAR, JDBCType.LONGNVARCHAR, JDBCType.GUID })), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 756 */     TIME(JavaType.TIME, EnumSet.of(JDBCType.TIME)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 762 */     TIMESTAMP(JavaType.TIMESTAMP, EnumSet.of(JDBCType.TIME, JDBCType.TIMESTAMP, JDBCType.DATETIME, JDBCType.SMALLDATETIME));
/*     */     
/*     */ 
/*     */ 
/*     */     private final EnumSet<JDBCType> to;
/*     */     
/*     */ 
/*     */     private final JavaType from;
/*     */     
/*     */ 
/*     */     private static final EnumMap<JavaType, EnumSet<JDBCType>> setterConversionAEMap;
/*     */     
/*     */ 
/*     */ 
/*     */     private SetterConversionAE(JavaType paramJavaType, EnumSet<JDBCType> paramEnumSet)
/*     */     {
/* 778 */       this.from = paramJavaType;
/* 779 */       this.to = paramEnumSet;
/*     */     }
/*     */     
/* 782 */     static { setterConversionAEMap = new EnumMap(JavaType.class);
/*     */       
/*     */ 
/*     */       Enum localEnum;
/*     */       
/* 787 */       for (localEnum : JavaType.values()) {
/* 788 */         setterConversionAEMap.put(localEnum, EnumSet.noneOf(JDBCType.class));
/*     */       }
/* 790 */       for (localEnum : values()) {
/* 791 */         ((EnumSet)setterConversionAEMap.get(localEnum.from)).addAll(localEnum.to);
/*     */       }
/*     */     }
/*     */     
/*     */     static boolean converts(JavaType paramJavaType, JDBCType paramJDBCType) {
/* 796 */       if ((null == paramJavaType) || (JavaType.OBJECT == paramJavaType))
/* 797 */         return true;
/* 798 */       if (!setterConversionAEMap.containsKey(paramJavaType))
/* 799 */         return false;
/* 800 */       return ((EnumSet)setterConversionAEMap.get(paramJavaType)).contains(paramJDBCType);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/JavaType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */