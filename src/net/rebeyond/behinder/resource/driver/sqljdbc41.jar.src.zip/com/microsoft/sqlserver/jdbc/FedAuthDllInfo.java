/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FedAuthDllInfo
/*    */ {
/* 10 */   byte[] accessTokenBytes = null;
/* 11 */   long expiresIn = 0L;
/*    */   
/*    */   FedAuthDllInfo(byte[] paramArrayOfByte, long paramLong) {
/* 14 */     this.accessTokenBytes = paramArrayOfByte;
/* 15 */     this.expiresIn = paramLong;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/FedAuthDllInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */