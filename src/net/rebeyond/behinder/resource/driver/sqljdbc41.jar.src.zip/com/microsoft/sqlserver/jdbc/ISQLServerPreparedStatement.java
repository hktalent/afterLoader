package com.microsoft.sqlserver.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import microsoft.sql.DateTimeOffset;

public abstract interface ISQLServerPreparedStatement
  extends PreparedStatement, ISQLServerStatement
{
  public abstract void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset)
    throws SQLException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ISQLServerPreparedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */