/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowIdLifetime;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.EnumMap;
/*      */ import java.util.Properties;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ public final class SQLServerDatabaseMetaData implements DatabaseMetaData, Serializable
/*      */ {
/*      */   private SQLServerConnection connection;
/*      */   static final String urlprefix = "jdbc:sqlserver://";
/*   22 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDatabaseMetaData");
/*      */   
/*      */ 
/*   25 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.DatabaseMetaData");
/*      */   
/*      */ 
/*   28 */   private static int baseID = 0;
/*      */   
/*      */   private final String traceID;
/*      */   
/*      */   static final int MAXLOBSIZE = Integer.MAX_VALUE;
/*      */   
/*      */   static final int uniqueidentifierSize = 36;
/*      */   
/*      */ 
/*      */   static enum CallableHandles
/*      */   {
/*   39 */     SP_COLUMNS("{ call sp_columns(?, ?, ?, ?, ?) }", "{ call sp_columns_100(?, ?, ?, ?, ?, ?) }"), 
/*   40 */     SP_COLUMN_PRIVILEGES("{ call sp_column_privileges(?, ?, ?, ?)}", "{ call sp_column_privileges(?, ?, ?, ?)}"), 
/*   41 */     SP_TABLES("{ call sp_tables(?, ?, ?, ?) }", "{ call sp_tables(?, ?, ?, ?) }"), 
/*   42 */     SP_SPECIAL_COLUMNS("{ call sp_special_columns (?, ?, ?, ?, ?, ?, ?)}", "{ call sp_special_columns_100 (?, ?, ?, ?, ?, ?, ?)}"), 
/*   43 */     SP_FKEYS("{ call sp_fkeys (?, ?, ?, ? , ? ,?)}", "{ call sp_fkeys (?, ?, ?, ? , ? ,?)}"), 
/*   44 */     SP_STATISTICS("{ call sp_statistics(?,?,?,?,?, ?) }", "{ call sp_statistics_100(?,?,?,?,?, ?) }"), 
/*   45 */     SP_SPROC_COLUMNS("{ call sp_sproc_columns(?, ?, ?,?,?) }", "{ call sp_sproc_columns_100(?, ?, ?,?,?) }"), 
/*   46 */     SP_STORED_PROCEDURES("{call sp_stored_procedures(?, ?, ?) }", "{call sp_stored_procedures(?, ?, ?) }"), 
/*   47 */     SP_TABLE_PRIVILEGES("{call sp_table_privileges(?,?,?) }", "{call sp_table_privileges(?,?,?) }"), 
/*   48 */     SP_PKEYS("{ call sp_pkeys (?, ?, ?)}", "{ call sp_pkeys (?, ?, ?)}");
/*      */     
/*      */ 
/*      */     private final String preKatProc;
/*      */     private final String katProc;
/*      */     
/*      */     private CallableHandles(String paramString1, String paramString2)
/*      */     {
/*   56 */       this.preKatProc = paramString1;
/*   57 */       this.katProc = paramString2;
/*      */     }
/*      */     
/*      */     CallableStatement prepare(SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/*   61 */       return paramSQLServerConnection.prepareCall(paramSQLServerConnection.isKatmaiOrLater() ? this.katProc : this.preKatProc);
/*      */     }
/*      */   }
/*      */   
/*      */   final class HandleAssociation
/*      */   {
/*      */     final String databaseName;
/*      */     final CallableStatement stmt;
/*      */     
/*      */     HandleAssociation(String paramString, CallableStatement paramCallableStatement) {
/*   71 */       this.databaseName = paramString;
/*   72 */       this.stmt = paramCallableStatement;
/*      */     }
/*      */     
/*      */ 
/*   76 */     final void close() throws SQLServerException { ((SQLServerCallableStatement)this.stmt).close(); }
/*      */   }
/*      */   
/*   79 */   EnumMap<CallableHandles, HandleAssociation> handleMap = new EnumMap(CallableHandles.class);
/*      */   private static final String ASC_OR_DESC = "ASC_OR_DESC";
/*      */   private static final String ATTR_NAME = "ATTR_NAME";
/*      */   private static final String ATTR_TYPE_NAME = "ATTR_TYPE_NAME";
/*      */   private static final String ATTR_SIZE = "ATTR_SIZE";
/*      */   private static final String ATTR_DEF = "ATTR_DEF";
/*      */   
/*      */   private static synchronized int nextInstanceID() {
/*   87 */     baseID += 1;
/*   88 */     return baseID;
/*      */   }
/*      */   
/*      */   public final String toString() {
/*   92 */     return this.traceID;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLServerDatabaseMetaData(SQLServerConnection paramSQLServerConnection)
/*      */   {
/*  101 */     this.traceID = (" SQLServerDatabaseMetaData:" + nextInstanceID());
/*  102 */     this.connection = paramSQLServerConnection;
/*  103 */     if (logger.isLoggable(Level.FINE))
/*      */     {
/*  105 */       logger.fine(toString() + " created by (" + this.connection.toString() + ")");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException
/*      */   {
/*  111 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*  113 */     return false;
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException
/*      */   {
/*  118 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  119 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */   
/*      */   private void checkClosed() throws SQLServerException
/*      */   {
/*  124 */     if (this.connection.isClosed())
/*      */     {
/*  126 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), "08003", false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static final String BASE_TYPE = "BASE_TYPE";
/*      */   
/*      */   private static final String BUFFER_LENGTH = "BUFFER_LENGTH";
/*      */   
/*      */   private static final String CARDINALITY = "CARDINALITY";
/*      */   
/*      */   private static final String CHAR_OCTET_LENGTH = "CHAR_OCTET_LENGTH";
/*      */   
/*      */   private static final String CLASS_NAME = "CLASS_NAME";
/*      */   
/*      */   private static final String COLUMN_DEF = "COLUMN_DEF";
/*      */   
/*      */   private static final String COLUMN_NAME = "COLUMN_NAME";
/*      */   
/*      */   private static final String COLUMN_SIZE = "COLUMN_SIZE";
/*      */   
/*      */   private static final String COLUMN_TYPE = "COLUMN_TYPE";
/*      */   
/*      */   private static final String DATA_TYPE = "DATA_TYPE";
/*      */   
/*      */   private static final String DECIMAL_DIGITS = "DECIMAL_DIGITS";
/*      */   
/*      */   private static final String DEFERRABILITY = "DEFERRABILITY";
/*      */   
/*      */   private static final String DELETE_RULE = "DELETE_RULE";
/*      */   
/*      */   private static final String FILTER_CONDITION = "FILTER_CONDITION";
/*      */   
/*      */   private static final String FK_NAME = "FK_NAME";
/*      */   
/*      */   private static final String FKCOLUMN_NAME = "FKCOLUMN_NAME";
/*      */   
/*      */   private static final String FKTABLE_CAT = "FKTABLE_CAT";
/*      */   private static final String FKTABLE_NAME = "FKTABLE_NAME";
/*      */   private static final String FKTABLE_SCHEM = "FKTABLE_SCHEM";
/*      */   private static final String GRANTEE = "GRANTEE";
/*      */   private static final String GRANTOR = "GRANTOR";
/*      */   private static final String INDEX_NAME = "INDEX_NAME";
/*      */   private static final String INDEX_QUALIFIER = "INDEX_QUALIFIER";
/*      */   private static final String IS_GRANTABLE = "IS_GRANTABLE";
/*      */   private static final String IS_NULLABLE = "IS_NULLABLE";
/*      */   private static final String KEY_SEQ = "KEY_SEQ";
/*      */   private static final String LENGTH = "LENGTH";
/*      */   private static final String NON_UNIQUE = "NON_UNIQUE";
/*      */   private static final String NULLABLE = "NULLABLE";
/*      */   private static final String NUM_INPUT_PARAMS = "NUM_INPUT_PARAMS";
/*      */   private static final String NUM_OUTPUT_PARAMS = "NUM_OUTPUT_PARAMS";
/*      */   private static final String NUM_PREC_RADIX = "NUM_PREC_RADIX";
/*      */   private static final String NUM_RESULT_SETS = "NUM_RESULT_SETS";
/*      */   private static final String ORDINAL_POSITION = "ORDINAL_POSITION";
/*      */   private static final String PAGES = "PAGES";
/*      */   private static final String PK_NAME = "PK_NAME";
/*      */   private static final String PKCOLUMN_NAME = "PKCOLUMN_NAME";
/*      */   private static final String PKTABLE_CAT = "PKTABLE_CAT";
/*      */   private static final String PKTABLE_NAME = "PKTABLE_NAME";
/*      */   private static final String PKTABLE_SCHEM = "PKTABLE_SCHEM";
/*      */   private static final String PRECISION = "PRECISION";
/*      */   private static final String PRIVILEGE = "PRIVILEGE";
/*      */   private static final String PROCEDURE_CAT = "PROCEDURE_CAT";
/*      */   private static final String PROCEDURE_NAME = "PROCEDURE_NAME";
/*      */   private static final String PROCEDURE_SCHEM = "PROCEDURE_SCHEM";
/*      */   private static final String PROCEDURE_TYPE = "PROCEDURE_TYPE";
/*      */   private static final String PSEUDO_COLUMN = "PSEUDO_COLUMN";
/*      */   private static final String RADIX = "RADIX";
/*      */   private static final String REMARKS = "REMARKS";
/*      */   private static final String SCALE = "SCALE";
/*      */   private static final String SCOPE = "SCOPE";
/*      */   private static final String SCOPE_CATALOG = "SCOPE_CATALOG";
/*      */   private static final String SCOPE_SCHEMA = "SCOPE_SCHEMA";
/*      */   private static final String SCOPE_TABLE = "SCOPE_TABLE";
/*      */   private static final String SOURCE_DATA_TYPE = "SOURCE_DATA_TYPE";
/*      */   private static final String SQL_DATA_TYPE = "SQL_DATA_TYPE";
/*      */   private static final String SQL_DATETIME_SUB = "SQL_DATETIME_SUB";
/*      */   private static final String SS_DATA_TYPE = "SS_DATA_TYPE";
/*      */   private static final String SUPERTABLE_NAME = "SUPERTABLE_NAME";
/*      */   private static final String SUPERTYPE_CAT = "SUPERTYPE_CAT";
/*      */   private static final String SUPERTYPE_NAME = "SUPERTYPE_NAME";
/*      */   private static final String SUPERTYPE_SCHEM = "SUPERTYPE_SCHEM";
/*      */   private static final String TABLE_CAT = "TABLE_CAT";
/*      */   private static final String TABLE_NAME = "TABLE_NAME";
/*      */   private static final String TABLE_SCHEM = "TABLE_SCHEM";
/*      */   private static final String TABLE_TYPE = "TABLE_TYPE";
/*      */   private static final String TYPE = "TYPE";
/*      */   private static final String TYPE_CAT = "TYPE_CAT";
/*      */   private static final String TYPE_NAME = "TYPE_NAME";
/*      */   private static final String TYPE_SCHEM = "TYPE_SCHEM";
/*      */   private static final String UPDATE_RULE = "UPDATE_RULE";
/*      */   private static final String FUNCTION_CAT = "FUNCTION_CAT";
/*      */   private static final String FUNCTION_NAME = "FUNCTION_NAME";
/*      */   private static final String FUNCTION_SCHEM = "FUNCTION_SCHEM";
/*      */   private static final String FUNCTION_TYPE = "FUNCTION_TYPE";
/*      */   private static final String SS_IS_SPARSE = "SS_IS_SPARSE";
/*      */   private static final String SS_IS_COLUMN_SET = "SS_IS_COLUMN_SET";
/*      */   private static final String SS_IS_COMPUTED = "SS_IS_COMPUTED";
/*      */   private static final String IS_AUTOINCREMENT = "IS_AUTOINCREMENT";
/*      */   private final SQLServerResultSet getResultSetFromInternalQueries(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/*  229 */     checkClosed();
/*  230 */     String str = null;
/*  231 */     str = switchCatalogs(paramString1);
/*  232 */     SQLServerResultSet localSQLServerResultSet = null;
/*      */     try
/*      */     {
/*  235 */       localSQLServerResultSet = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal(paramString2);
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  240 */       if (null != str)
/*      */       {
/*  242 */         this.connection.setCatalog(str);
/*      */       }
/*      */     }
/*  245 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private CallableStatement getCallableStatementHandle(CallableHandles paramCallableHandles, String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  254 */     CallableStatement localCallableStatement = null;
/*  255 */     HandleAssociation localHandleAssociation1 = (HandleAssociation)this.handleMap.get(paramCallableHandles);
/*  256 */     if ((null == localHandleAssociation1) || (null == localHandleAssociation1.databaseName) || (!localHandleAssociation1.databaseName.equals(paramString)))
/*      */     {
/*      */ 
/*      */ 
/*  260 */       localCallableStatement = paramCallableHandles.prepare(this.connection);
/*  261 */       localHandleAssociation1 = new HandleAssociation(paramString, localCallableStatement);
/*  262 */       HandleAssociation localHandleAssociation2 = (HandleAssociation)this.handleMap.put(paramCallableHandles, localHandleAssociation1);
/*  263 */       if (null != localHandleAssociation2)
/*      */       {
/*  265 */         localHandleAssociation2.close();
/*      */       }
/*      */     }
/*  268 */     return localHandleAssociation1.stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final SQLServerResultSet getResultSetFromStoredProc(String paramString, CallableHandles paramCallableHandles, String[] paramArrayOfString)
/*      */     throws SQLServerException
/*      */   {
/*  281 */     checkClosed();
/*  282 */     assert (null != paramArrayOfString);
/*  283 */     String str = null;
/*  284 */     str = switchCatalogs(paramString);
/*  285 */     SQLServerResultSet localSQLServerResultSet = null;
/*      */     try
/*      */     {
/*  288 */       SQLServerCallableStatement localSQLServerCallableStatement = (SQLServerCallableStatement)getCallableStatementHandle(paramCallableHandles, paramString);
/*      */       
/*  290 */       for (int i = 1; i <= paramArrayOfString.length; i++)
/*      */       {
/*      */ 
/*  293 */         localSQLServerCallableStatement.setString(i, paramArrayOfString[(i - 1)]);
/*      */       }
/*  295 */       localSQLServerResultSet = (SQLServerResultSet)localSQLServerCallableStatement.executeQueryInternal();
/*      */     }
/*      */     finally
/*      */     {
/*  299 */       if (null != str)
/*      */       {
/*  301 */         this.connection.setCatalog(str);
/*      */       }
/*      */     }
/*  304 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */   private final SQLServerResultSet getResultSetWithProvidedColumnNames(String paramString, CallableHandles paramCallableHandles, String[] paramArrayOfString1, String[] paramArrayOfString2)
/*      */     throws SQLServerException
/*      */   {
/*  311 */     SQLServerResultSet localSQLServerResultSet = getResultSetFromStoredProc(paramString, paramCallableHandles, paramArrayOfString1);
/*      */     
/*      */ 
/*  314 */     for (int i = 0; i < paramArrayOfString2.length; i++)
/*  315 */       localSQLServerResultSet.setColumnName(1 + i, paramArrayOfString2[i]);
/*  316 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String switchCatalogs(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  326 */     if (paramString == null)
/*  327 */       return null;
/*  328 */     String str1 = null;
/*  329 */     str1 = this.connection.getCatalog().trim();
/*  330 */     String str2 = paramString.trim();
/*  331 */     if (str1.equals(str2))
/*  332 */       return null;
/*  333 */     this.connection.setCatalog(str2);
/*  334 */     if ((str1 == null) || (str1.length() == 0))
/*  335 */       return null;
/*  336 */     return str1;
/*      */   }
/*      */   
/*      */   public boolean allProceduresAreCallable()
/*      */     throws SQLServerException
/*      */   {
/*  342 */     checkClosed();
/*  343 */     return true;
/*      */   }
/*      */   
/*      */   public boolean allTablesAreSelectable() throws SQLServerException {
/*  347 */     checkClosed();
/*  348 */     return true;
/*      */   }
/*      */   
/*      */   public boolean autoCommitFailureClosesAllResultSets() throws SQLException
/*      */   {
/*  353 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  354 */     checkClosed();
/*  355 */     return false;
/*      */   }
/*      */   
/*      */   public boolean dataDefinitionCausesTransactionCommit() throws SQLServerException {
/*  359 */     checkClosed();
/*  360 */     return false;
/*      */   }
/*      */   
/*      */   public boolean dataDefinitionIgnoredInTransactions() throws SQLServerException {
/*  364 */     checkClosed();
/*  365 */     return false;
/*      */   }
/*      */   
/*      */   public boolean doesMaxRowSizeIncludeBlobs() throws SQLServerException {
/*  369 */     checkClosed();
/*  370 */     return false;
/*      */   }
/*      */   
/*      */   public boolean generatedKeyAlwaysReturned() throws SQLException
/*      */   {
/*  375 */     DriverJDBCVersion.checkSupportsJDBC41();
/*  376 */     checkClosed();
/*      */     
/*      */ 
/*  379 */     return true;
/*      */   }
/*      */   
/*      */   public long getMaxLogicalLobSize() throws SQLException
/*      */   {
/*  384 */     DriverJDBCVersion.checkSupportsJDBC42();
/*  385 */     checkClosed();
/*      */     
/*  387 */     return 2147483647L;
/*      */   }
/*      */   
/*      */   public boolean supportsRefCursors() throws SQLException
/*      */   {
/*  392 */     DriverJDBCVersion.checkSupportsJDBC42();
/*  393 */     checkClosed();
/*      */     
/*  395 */     return false;
/*      */   }
/*      */   
/*      */   public ResultSet getCatalogs() throws SQLServerException {
/*  399 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  401 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  403 */     checkClosed();
/*      */     
/*  405 */     String str = "SELECT name AS TABLE_CAT FROM sys.databases order by name";
/*  406 */     return getResultSetFromInternalQueries(null, str);
/*      */   }
/*      */   
/*      */   public String getCatalogSeparator() throws SQLServerException {
/*  410 */     checkClosed();
/*  411 */     return ".";
/*      */   }
/*      */   
/*      */   public String getCatalogTerm() throws SQLServerException {
/*  415 */     checkClosed();
/*  416 */     return "database";
/*      */   }
/*      */   
/*  419 */   private static final String[] getColumnPrivilegesColumnNames = { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumnPrivileges(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLServerException
/*      */   {
/*  434 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  436 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  438 */     checkClosed();
/*      */     
/*  440 */     paramString4 = EscapeIDName(paramString4);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  447 */     String[] arrayOfString = new String[4];
/*  448 */     arrayOfString[0] = paramString3;
/*  449 */     arrayOfString[1] = paramString2;
/*  450 */     arrayOfString[2] = paramString1;
/*  451 */     arrayOfString[3] = paramString4;
/*  452 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMN_PRIVILEGES, arrayOfString, getColumnPrivilegesColumnNames);
/*      */   }
/*      */   
/*  455 */   private static final String[] getTablesColumnNames = { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "TABLE_TYPE", "REMARKS" };
/*      */   
/*      */   static final char LEFT_BRACKET = '[';
/*      */   static final char RIGHT_BRACKET = ']';
/*      */   static final char ESCAPE = '\\';
/*      */   static final char PERCENT = '%';
/*      */   static final char UNDERSCORE = '_';
/*      */   
/*      */   public ResultSet getTables(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString)
/*      */     throws SQLServerException
/*      */   {
/*  466 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  468 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  470 */     checkClosed();
/*      */     
/*      */ 
/*  473 */     paramString3 = EscapeIDName(paramString3);
/*  474 */     paramString2 = EscapeIDName(paramString2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  480 */     String[] arrayOfString = new String[4];
/*  481 */     arrayOfString[0] = paramString3;
/*  482 */     arrayOfString[1] = paramString2;
/*  483 */     arrayOfString[2] = paramString1;
/*      */     
/*  485 */     String str = null;
/*  486 */     if (paramArrayOfString != null)
/*      */     {
/*  488 */       str = "'";
/*  489 */       for (int i = 0; i < paramArrayOfString.length; i++)
/*      */       {
/*  491 */         if (i > 0)
/*  492 */           str = str + ",";
/*  493 */         str = str + "''" + paramArrayOfString[i] + "''";
/*      */       }
/*  495 */       str = str + "'";
/*      */     }
/*  497 */     arrayOfString[3] = str;
/*  498 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_TABLES, arrayOfString, getTablesColumnNames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  514 */   static final char[] DOUBLE_RIGHT_BRACKET = { ']', ']' };
/*      */   
/*      */   private static String EscapeIDName(String paramString) throws SQLServerException {
/*  517 */     if (null == paramString) {
/*  518 */       return paramString;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  531 */     StringBuilder localStringBuilder = new StringBuilder(paramString.length() + 2);
/*      */     
/*  533 */     for (int i = 0; i < paramString.length(); i++)
/*      */     {
/*  535 */       char c = paramString.charAt(i);
/*  536 */       if ('\\' == c) { i++; if (i < paramString.length())
/*      */         {
/*  538 */           c = paramString.charAt(i);
/*  539 */           switch (c)
/*      */           {
/*      */           case '%': 
/*      */           case '[': 
/*      */           case '_': 
/*  544 */             localStringBuilder.append('[');
/*  545 */             localStringBuilder.append(c);
/*  546 */             localStringBuilder.append(']');
/*  547 */             break;
/*      */           case '\\': 
/*      */           case ']': 
/*  550 */             localStringBuilder.append(c);
/*  551 */             break;
/*      */           default: 
/*  553 */             localStringBuilder.append('\\');
/*  554 */             localStringBuilder.append(c);break;
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  561 */       localStringBuilder.append(c);
/*      */     }
/*      */     
/*  564 */     return localStringBuilder.toString();
/*      */   }
/*      */   
/*  567 */   private static final String[] getColumnsColumnNames = { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  591 */   private static final String[] getColumnsColumnNamesKatmai = { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE", "SS_IS_SPARSE", "SS_IS_COLUMN_SET", "SS_IS_COMPUTED", "IS_AUTOINCREMENT" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumns(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLServerException
/*      */   {
/*  620 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  622 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  624 */     checkClosed();
/*      */     
/*      */ 
/*  627 */     String str = EscapeIDName(paramString4);
/*  628 */     paramString3 = EscapeIDName(paramString3);
/*  629 */     paramString2 = EscapeIDName(paramString2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     String[] arrayOfString;
/*      */     
/*      */ 
/*      */ 
/*  638 */     if (this.connection.isKatmaiOrLater()) {
/*  639 */       arrayOfString = new String[6];
/*      */     } else
/*  641 */       arrayOfString = new String[5];
/*  642 */     arrayOfString[0] = paramString3;
/*  643 */     arrayOfString[1] = paramString2;
/*  644 */     arrayOfString[2] = paramString1;
/*  645 */     arrayOfString[3] = str;
/*  646 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/*  648 */       arrayOfString[4] = "2";
/*  649 */       arrayOfString[5] = "3";
/*      */     }
/*      */     else {
/*  652 */       arrayOfString[4] = "3"; }
/*      */     SQLServerResultSet localSQLServerResultSet;
/*  654 */     if (this.connection.isKatmaiOrLater()) {
/*  655 */       localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMNS, arrayOfString, getColumnsColumnNamesKatmai);
/*      */     } else {
/*  657 */       localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMNS, arrayOfString, getColumnsColumnNames);
/*      */     }
/*      */     
/*      */ 
/*  661 */     localSQLServerResultSet.getColumn(5).setFilter(new DataTypeFilter());
/*      */     
/*  663 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/*  665 */       localSQLServerResultSet.getColumn(22).setFilter(new IntColumnIdentityFilter());
/*  666 */       localSQLServerResultSet.getColumn(7).setFilter(new ZeroFixupFilter());
/*  667 */       localSQLServerResultSet.getColumn(8).setFilter(new ZeroFixupFilter());
/*  668 */       localSQLServerResultSet.getColumn(16).setFilter(new ZeroFixupFilter());
/*      */     }
/*  670 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*  673 */   private static final String[] getFunctionsColumnNames = { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "FUNCTION_TYPE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getFunctions(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLException
/*      */   {
/*  688 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  689 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  697 */     if ((paramString1 != null) && (paramString1.length() == 0))
/*      */     {
/*  699 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/*  700 */       Object[] arrayOfObject = { "catalog" };
/*  701 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject).format(arrayOfObject), null, false);
/*      */     }
/*      */     
/*  704 */     Object localObject = new String[3];
/*  705 */     localObject[0] = EscapeIDName(paramString3);
/*  706 */     localObject[1] = EscapeIDName(paramString2);
/*  707 */     localObject[2] = paramString1;
/*  708 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STORED_PROCEDURES, (String[])localObject, getFunctionsColumnNames);
/*      */   }
/*      */   
/*  711 */   private static final String[] getFunctionsColumnsColumnNames = { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getFunctionColumns(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLException
/*      */   {
/*  737 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  738 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  747 */     if ((paramString1 != null) && (paramString1.length() == 0))
/*      */     {
/*  749 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/*  750 */       localObject2 = new Object[] { "catalog" };
/*  751 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject1).format(localObject2), null, false);
/*      */     }
/*      */     
/*  754 */     Object localObject1 = new String[5];
/*      */     
/*      */ 
/*  757 */     localObject1[0] = EscapeIDName(paramString3);
/*      */     
/*  759 */     localObject1[1] = EscapeIDName(paramString2);
/*  760 */     localObject1[2] = paramString1;
/*      */     
/*  762 */     localObject1[3] = EscapeIDName(paramString4);
/*  763 */     localObject1[4] = "3";
/*  764 */     Object localObject2 = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPROC_COLUMNS, (String[])localObject1, getFunctionsColumnsColumnNames);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  769 */     ((SQLServerResultSet)localObject2).getColumn(6).setFilter(new DataTypeFilter());
/*      */     
/*  771 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/*  773 */       ((SQLServerResultSet)localObject2).getColumn(8).setFilter(new ZeroFixupFilter());
/*  774 */       ((SQLServerResultSet)localObject2).getColumn(9).setFilter(new ZeroFixupFilter());
/*  775 */       ((SQLServerResultSet)localObject2).getColumn(17).setFilter(new ZeroFixupFilter());
/*      */     }
/*  777 */     return (ResultSet)localObject2;
/*      */   }
/*      */   
/*      */   public ResultSet getClientInfoProperties()
/*      */     throws SQLException
/*      */   {
/*  783 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  784 */     checkClosed();
/*  785 */     return getResultSetFromInternalQueries(null, "SELECT cast(NULL as char(1)) as NAME, cast(0 as int) as MAX_LEN, cast(NULL as char(1)) as DEFAULT_VALUE, cast(NULL as char(1)) as DESCRIPTION  where 0 = 1");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  794 */   private static final String[] getBestRowIdentifierColumnNames = { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getBestRowIdentifier(String paramString1, String paramString2, String paramString3, int paramInt, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*  809 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  811 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  813 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  823 */     String[] arrayOfString = new String[7];
/*  824 */     arrayOfString[0] = paramString3;
/*  825 */     arrayOfString[1] = paramString2;
/*  826 */     arrayOfString[2] = paramString1;
/*  827 */     arrayOfString[3] = "R";
/*  828 */     if (0 == paramInt) {
/*  829 */       arrayOfString[4] = "C";
/*      */     } else
/*  831 */       arrayOfString[4] = "T";
/*  832 */     if (paramBoolean) {
/*  833 */       arrayOfString[5] = "U";
/*      */     } else
/*  835 */       arrayOfString[5] = "O";
/*  836 */     arrayOfString[6] = "3";
/*  837 */     SQLServerResultSet localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPECIAL_COLUMNS, arrayOfString, getBestRowIdentifierColumnNames);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  842 */     localSQLServerResultSet.getColumn(3).setFilter(new DataTypeFilter());
/*  843 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*  846 */   private static final String[] pkfkColumnNames = { "PKTABLE_CAT", "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME", "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME", "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE", "FK_NAME", "PK_NAME", "DEFERRABILITY" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCrossReference(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
/*      */     throws SQLServerException
/*      */   {
/*  868 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  870 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  872 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  880 */     String[] arrayOfString = new String[6];
/*  881 */     arrayOfString[0] = paramString3;
/*  882 */     arrayOfString[1] = paramString2;
/*  883 */     arrayOfString[2] = paramString1;
/*  884 */     arrayOfString[3] = paramString6;
/*  885 */     arrayOfString[4] = paramString5;
/*  886 */     arrayOfString[5] = paramString4;
/*      */     
/*  888 */     return getResultSetWithProvidedColumnNames(null, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
/*      */   }
/*      */   
/*      */   public String getDatabaseProductName() throws SQLServerException {
/*  892 */     checkClosed();
/*  893 */     return "Microsoft SQL Server";
/*      */   }
/*      */   
/*      */   public String getDatabaseProductVersion() throws SQLServerException {
/*  897 */     checkClosed();
/*  898 */     return this.connection.sqlServerVersion;
/*      */   }
/*      */   
/*      */   public int getDefaultTransactionIsolation() throws SQLServerException
/*      */   {
/*  903 */     checkClosed();
/*  904 */     return 2;
/*      */   }
/*      */   
/*      */   public int getDriverMajorVersion()
/*      */   {
/*  909 */     return 6;
/*      */   }
/*      */   
/*      */   public int getDriverMinorVersion()
/*      */   {
/*  914 */     return 0;
/*      */   }
/*      */   
/*      */   public String getDriverName() throws SQLServerException {
/*  918 */     checkClosed();
/*  919 */     return "Microsoft JDBC Driver 6.0 for SQL Server";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDriverVersion()
/*      */     throws SQLServerException
/*      */   {
/*  927 */     int i = getDriverMinorVersion();
/*  928 */     String str = getDriverMajorVersion() + ".";
/*  929 */     str = str + "" + i;
/*  930 */     str = str + ".";
/*  931 */     str = str + 8112;
/*  932 */     str = str + ".";
/*  933 */     str = str + 200;
/*  934 */     return str;
/*      */   }
/*      */   
/*      */   public ResultSet getExportedKeys(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/*  940 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  942 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  944 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  952 */     String[] arrayOfString = new String[6];
/*  953 */     arrayOfString[0] = paramString3;
/*  954 */     arrayOfString[1] = paramString2;
/*  955 */     arrayOfString[2] = paramString1;
/*  956 */     arrayOfString[3] = null;
/*  957 */     arrayOfString[4] = null;
/*  958 */     arrayOfString[5] = null;
/*  959 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
/*      */   }
/*      */   
/*      */   public String getExtraNameCharacters() throws SQLServerException {
/*  963 */     checkClosed();
/*  964 */     return "$#@";
/*      */   }
/*      */   
/*      */   public String getIdentifierQuoteString() throws SQLServerException
/*      */   {
/*  969 */     checkClosed();
/*  970 */     return "\"";
/*      */   }
/*      */   
/*      */   public ResultSet getImportedKeys(String paramString1, String paramString2, String paramString3) throws SQLServerException
/*      */   {
/*  975 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/*  977 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  979 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  987 */     String[] arrayOfString = new String[6];
/*  988 */     arrayOfString[0] = null;
/*  989 */     arrayOfString[1] = null;
/*  990 */     arrayOfString[2] = null;
/*  991 */     arrayOfString[3] = paramString3;
/*  992 */     arrayOfString[4] = paramString2;
/*  993 */     arrayOfString[5] = paramString1;
/*  994 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
/*      */   }
/*      */   
/*  997 */   private static final String[] getIndexInfoColumnNames = { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME", "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC", "CARDINALITY", "PAGES", "FILTER_CONDITION" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getIndexInfo(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLServerException
/*      */   {
/* 1017 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1019 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1021 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1028 */     String[] arrayOfString = new String[6];
/* 1029 */     arrayOfString[0] = paramString3;
/* 1030 */     arrayOfString[1] = paramString2;
/* 1031 */     arrayOfString[2] = paramString1;
/*      */     
/* 1033 */     arrayOfString[3] = "%";
/* 1034 */     if (paramBoolean1) {
/* 1035 */       arrayOfString[4] = "Y";
/*      */     } else
/* 1037 */       arrayOfString[4] = "N";
/* 1038 */     if (paramBoolean2) {
/* 1039 */       arrayOfString[5] = "Q";
/*      */     } else
/* 1041 */       arrayOfString[5] = "E";
/* 1042 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STATISTICS, arrayOfString, getIndexInfoColumnNames);
/*      */   }
/*      */   
/*      */   public int getMaxBinaryLiteralLength() throws SQLServerException {
/* 1046 */     checkClosed();
/* 1047 */     return 0;
/*      */   }
/*      */   
/*      */   public int getMaxCatalogNameLength() throws SQLServerException {
/* 1051 */     checkClosed();
/* 1052 */     return 128;
/*      */   }
/*      */   
/*      */   public int getMaxCharLiteralLength() throws SQLServerException {
/* 1056 */     checkClosed();
/* 1057 */     return 0;
/*      */   }
/*      */   
/*      */   public int getMaxColumnNameLength() throws SQLServerException {
/* 1061 */     checkClosed();
/* 1062 */     return 128;
/*      */   }
/*      */   
/*      */   public int getMaxColumnsInGroupBy() throws SQLServerException {
/* 1066 */     checkClosed();
/* 1067 */     return 0;
/*      */   }
/*      */   
/*      */   public int getMaxColumnsInIndex() throws SQLServerException {
/* 1071 */     checkClosed();
/* 1072 */     return 16;
/*      */   }
/*      */   
/*      */   public int getMaxColumnsInOrderBy() throws SQLServerException {
/* 1076 */     checkClosed();
/* 1077 */     return 0;
/*      */   }
/*      */   
/*      */   public int getMaxColumnsInSelect() throws SQLServerException {
/* 1081 */     checkClosed();
/* 1082 */     return 4096;
/*      */   }
/*      */   
/*      */   public int getMaxColumnsInTable() throws SQLServerException {
/* 1086 */     checkClosed();
/* 1087 */     return 1024;
/*      */   }
/*      */   
/*      */   public int getMaxConnections() throws SQLServerException
/*      */   {
/* 1092 */     checkClosed();
/*      */     try
/*      */     {
/* 1095 */       String str = "sp_configure 'user connections'";
/* 1096 */       SQLServerResultSet localSQLServerResultSet = getResultSetFromInternalQueries(null, str);
/* 1097 */       if (!localSQLServerResultSet.next())
/* 1098 */         return 0;
/* 1099 */       return localSQLServerResultSet.getInt("maximum");
/*      */     }
/*      */     catch (SQLServerException localSQLServerException) {}
/*      */     
/* 1103 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMaxCursorNameLength()
/*      */     throws SQLServerException
/*      */   {
/* 1110 */     checkClosed();
/* 1111 */     return 0;
/*      */   }
/*      */   
/*      */   public int getMaxIndexLength() throws SQLServerException {
/* 1115 */     checkClosed();
/* 1116 */     return 900;
/*      */   }
/*      */   
/*      */   public int getMaxProcedureNameLength() throws SQLServerException {
/* 1120 */     checkClosed();
/* 1121 */     return 128;
/*      */   }
/*      */   
/*      */   public int getMaxRowSize() throws SQLServerException {
/* 1125 */     checkClosed();
/* 1126 */     return 8060;
/*      */   }
/*      */   
/*      */   public int getMaxSchemaNameLength() throws SQLServerException {
/* 1130 */     checkClosed();
/* 1131 */     return 128;
/*      */   }
/*      */   
/*      */   public int getMaxStatementLength() throws SQLServerException {
/* 1135 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1141 */     return 65536 * this.connection.getTDSPacketSize();
/*      */   }
/*      */   
/*      */   public int getMaxStatements() throws SQLServerException {
/* 1145 */     checkClosed();
/* 1146 */     return 0;
/*      */   }
/*      */   
/*      */   public int getMaxTableNameLength() throws SQLServerException {
/* 1150 */     checkClosed();
/* 1151 */     return 128;
/*      */   }
/*      */   
/*      */   public int getMaxTablesInSelect() throws SQLServerException {
/* 1155 */     checkClosed();
/* 1156 */     return 256;
/*      */   }
/*      */   
/*      */   public int getMaxUserNameLength() throws SQLServerException {
/* 1160 */     checkClosed();
/* 1161 */     return 128;
/*      */   }
/*      */   
/*      */   public String getNumericFunctions() throws SQLServerException {
/* 1165 */     checkClosed();
/* 1166 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,CEILING,COS,COT,DEGREES,EXP, FLOOR,LOG,LOG10,MOD,PI,POWER,RADIANS,RAND,ROUND,SIGN,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */   
/* 1169 */   private static final String[] getPrimaryKeysColumnNames = { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "KEY_SEQ", "PK_NAME" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getPrimaryKeys(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1182 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1184 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1186 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1192 */     String[] arrayOfString = new String[3];
/* 1193 */     arrayOfString[0] = paramString3;
/* 1194 */     arrayOfString[1] = paramString2;
/* 1195 */     arrayOfString[2] = paramString1;
/* 1196 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_PKEYS, arrayOfString, getPrimaryKeysColumnNames);
/*      */   }
/*      */   
/* 1199 */   private static final String[] getProcedureColumnsColumnNames = { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedureColumns(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLServerException
/*      */   {
/* 1225 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1227 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1229 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1237 */     String[] arrayOfString = new String[5];
/*      */     
/*      */ 
/* 1240 */     paramString3 = EscapeIDName(paramString3);
/* 1241 */     arrayOfString[0] = paramString3;
/* 1242 */     arrayOfString[1] = paramString2;
/* 1243 */     arrayOfString[2] = paramString1;
/*      */     
/* 1245 */     paramString4 = EscapeIDName(paramString4);
/* 1246 */     arrayOfString[3] = paramString4;
/* 1247 */     arrayOfString[4] = "3";
/* 1248 */     SQLServerResultSet localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPROC_COLUMNS, arrayOfString, getProcedureColumnsColumnNames);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1253 */     localSQLServerResultSet.getColumn(6).setFilter(new DataTypeFilter());
/* 1254 */     if (this.connection.isKatmaiOrLater())
/*      */     {
/* 1256 */       localSQLServerResultSet.getColumn(8).setFilter(new ZeroFixupFilter());
/* 1257 */       localSQLServerResultSet.getColumn(9).setFilter(new ZeroFixupFilter());
/* 1258 */       localSQLServerResultSet.getColumn(17).setFilter(new ZeroFixupFilter());
/*      */     }
/*      */     
/* 1261 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/* 1264 */   private static final String[] getProceduresColumnNames = { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "PROCEDURE_TYPE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedures(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1279 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1281 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/* 1284 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1290 */     String[] arrayOfString = new String[3];
/* 1291 */     arrayOfString[0] = EscapeIDName(paramString3);
/* 1292 */     arrayOfString[1] = paramString2;
/* 1293 */     arrayOfString[2] = paramString1;
/* 1294 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STORED_PROCEDURES, arrayOfString, getProceduresColumnNames);
/*      */   }
/*      */   
/*      */   public String getProcedureTerm() throws SQLServerException {
/* 1298 */     checkClosed();
/* 1299 */     return "stored procedure";
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getPseudoColumns(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */     throws SQLException
/*      */   {
/*      */     
/* 1307 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1309 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/* 1312 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1317 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TABLE_CAT, cast(NULL as char(1)) as TABLE_SCHEM, cast(NULL as char(1)) as TABLE_NAME, cast(NULL as char(1)) as COLUMN_NAME, cast(0 as int) as DATA_TYPE, cast(0 as int) as COLUMN_SIZE, cast(0 as int) as DECIMAL_DIGITS, cast(0 as int) as NUM_PREC_RADIX, cast(NULL as char(1)) as COLUMN_USAGE, cast(NULL as char(1)) as REMARKS, cast(0 as int) as CHAR_OCTET_LENGTH, cast(NULL as char(1)) as IS_NULLABLE where 0 = 1");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSchemas()
/*      */     throws SQLServerException
/*      */   {
/* 1336 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1338 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1340 */     checkClosed();
/* 1341 */     return getSchemasInternal(null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ResultSet getSchemasInternal(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/* 1350 */     String str2 = " ('dbo', 'guest','INFORMATION_SCHEMA','sys','db_owner', 'db_accessadmin', 'db_securityadmin', 'db_ddladmin'  ,'db_backupoperator','db_datareader','db_datawriter','db_denydatareader','db_denydatawriter') ";
/*      */     
/*      */ 
/* 1353 */     String str3 = "sys.schemas";
/* 1354 */     String str4 = "sys.schemas.name";
/* 1355 */     if ((null != paramString1) && (paramString1.length() != 0))
/*      */     {
/* 1357 */       str3 = paramString1 + "." + str3;
/* 1358 */       str4 = paramString1 + "." + str4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1363 */     String str1 = "select " + str4 + " 'TABLE_SCHEM',";
/* 1364 */     if ((null != paramString1) && (paramString1.length() == 0))
/*      */     {
/* 1366 */       str1 = str1 + "null 'TABLE_CATALOG' ";
/*      */     }
/*      */     else
/*      */     {
/* 1370 */       str1 = str1 + " CASE WHEN " + str4 + "  IN " + str2 + " THEN null ELSE ";
/*      */       
/* 1372 */       if ((null != paramString1) && (paramString1.length() != 0))
/*      */       {
/* 1374 */         str1 = str1 + "'" + paramString1 + "' ";
/*      */       }
/*      */       else {
/* 1377 */         str1 = str1 + " DB_NAME() ";
/*      */       }
/* 1379 */       str1 = str1 + " END 'TABLE_CATALOG' ";
/*      */     }
/* 1381 */     str1 = str1 + "   from " + str3;
/*      */     
/*      */ 
/*      */ 
/* 1385 */     if ((null != paramString1) && (paramString1.length() == 0))
/*      */     {
/* 1387 */       if (null != paramString2) {
/* 1388 */         str1 = str1 + " where " + str4 + " like ?  and ";
/*      */       } else
/* 1390 */         str1 = str1 + " where ";
/* 1391 */       str1 = str1 + str4 + " in " + str2;
/*      */ 
/*      */     }
/* 1394 */     else if (null != paramString2) {
/* 1395 */       str1 = str1 + " where " + str4 + " like ?  ";
/*      */     }
/* 1397 */     str1 = str1 + " order by 2, 1";
/* 1398 */     if (logger.isLoggable(Level.FINE))
/*      */     {
/* 1400 */       logger.fine(toString() + " schema query (" + str1 + ")");
/*      */     }
/*      */     SQLServerResultSet localSQLServerResultSet;
/* 1403 */     if (null == paramString2)
/*      */     {
/* 1405 */       paramString1 = null;
/* 1406 */       localSQLServerResultSet = getResultSetFromInternalQueries(paramString1, str1);
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/* 1414 */       SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)this.connection.prepareStatement(str1);
/* 1415 */       localSQLServerPreparedStatement.setString(1, paramString2);
/* 1416 */       localSQLServerResultSet = (SQLServerResultSet)localSQLServerPreparedStatement.executeQueryInternal();
/*      */     }
/* 1418 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*      */   public ResultSet getSchemas(String paramString1, String paramString2) throws SQLException
/*      */   {
/* 1423 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1425 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1427 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1428 */     return getSchemasInternal(paramString1, paramString2);
/*      */   }
/*      */   
/*      */   public String getSchemaTerm() throws SQLServerException {
/* 1432 */     checkClosed();
/* 1433 */     return "schema";
/*      */   }
/*      */   
/*      */   public String getSearchStringEscape() throws SQLServerException {
/* 1437 */     checkClosed();
/* 1438 */     return "\\";
/*      */   }
/*      */   
/*      */   public String getSQLKeywords() throws SQLServerException {
/* 1442 */     checkClosed();
/* 1443 */     return "BACKUP,BREAK,BROWSE,BULK,CHECKPOINT,CLUSTERED,COMPUTE,CONTAINS,CONTAINSTABLE,DATABASE,DBCC,DENY,DISK,DISTRIBUTED,DUMMY,DUMP,ERRLVL,EXIT,FILE,FILLFACTOR,FREETEXT,FREETEXTTABLE,FUNCTION,HOLDLOCK,IDENTITY_INSERT,IDENTITYCOL,IF,KILL,LINENO,LOAD,NOCHECK,NONCLUSTERED,OFF,OFFSETS,OPENDATASOURCE,OPENQUERY,OPENROWSET,OPENXML,OVER,PERCENT,PLAN,PRINT,PROC,RAISERROR,READTEXT,RECONFIGURE,REPLICATION,RESTORE,RETURN,ROWCOUNT,ROWGUIDCOL,RULE,SAVE,SETUSER,SHUTDOWN,STATISTICS,TEXTSIZE,TOP,TRAN,TRIGGER,TRUNCATE,TSEQUAL,UPDATETEXT,USE,WAITFOR,WHILE,WRITETEXT";
/*      */   }
/*      */   
/*      */   public String getStringFunctions() throws SQLServerException {
/* 1447 */     checkClosed();
/* 1448 */     return "ASCII,CHAR,CONCAT, DIFFERENCE,INSERT,LCASE,LEFT,LENGTH,LOCATE,LTRIM,REPEAT,REPLACE,RIGHT,RTRIM,SOUNDEX,SPACE,SUBSTRING,UCASE";
/*      */   }
/*      */   
/*      */   public String getSystemFunctions() throws SQLServerException {
/* 1452 */     checkClosed();
/* 1453 */     return "DATABASE,IFNULL,USER";
/*      */   }
/*      */   
/* 1456 */   private static final String[] getTablePrivilegesColumnNames = { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTablePrivileges(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1469 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1471 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1473 */     checkClosed();
/* 1474 */     paramString3 = EscapeIDName(paramString3);
/* 1475 */     paramString2 = EscapeIDName(paramString2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1481 */     String[] arrayOfString = new String[3];
/* 1482 */     arrayOfString[0] = paramString3;
/* 1483 */     arrayOfString[1] = paramString2;
/* 1484 */     arrayOfString[2] = paramString1;
/*      */     
/* 1486 */     return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_TABLE_PRIVILEGES, arrayOfString, getTablePrivilegesColumnNames);
/*      */   }
/*      */   
/*      */   public ResultSet getTableTypes() throws SQLServerException
/*      */   {
/* 1491 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1493 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1495 */     checkClosed();
/* 1496 */     String str = "SELECT 'VIEW' 'TABLE_TYPE' UNION SELECT 'TABLE' UNION SELECT 'SYSTEM TABLE'";
/* 1497 */     SQLServerResultSet localSQLServerResultSet = getResultSetFromInternalQueries(null, str);
/* 1498 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*      */   public String getTimeDateFunctions() throws SQLServerException {
/* 1502 */     checkClosed();
/* 1503 */     return "CURDATE,CURTIME,DAYNAME,DAYOFMONTH,DAYOFWEEK,DAYOFYEAR,HOUR,MINUTE,MONTH,MONTHNAME,NOW,QUARTER,SECOND,TIMESTAMPADD,TIMESTAMPDIFF,WEEK,YEAR";
/*      */   }
/*      */   
/*      */   public ResultSet getTypeInfo() throws SQLServerException
/*      */   {
/* 1508 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1510 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1512 */     checkClosed();
/*      */     
/*      */     SQLServerResultSet localSQLServerResultSet;
/*      */     
/* 1516 */     if (this.connection.isKatmaiOrLater()) {
/* 1517 */       localSQLServerResultSet = getResultSetFromInternalQueries(null, "sp_datatype_info_100 @ODBCVer=3");
/*      */     } else {
/* 1519 */       localSQLServerResultSet = getResultSetFromInternalQueries(null, "sp_datatype_info @ODBCVer=3");
/*      */     }
/* 1521 */     localSQLServerResultSet.setColumnName(11, "FIXED_PREC_SCALE");
/*      */     
/*      */ 
/*      */ 
/* 1525 */     localSQLServerResultSet.getColumn(2).setFilter(new DataTypeFilter());
/* 1526 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*      */   public String getURL() throws SQLServerException
/*      */   {
/* 1531 */     checkClosed();
/*      */     
/* 1533 */     StringBuilder localStringBuilder = new StringBuilder();
/*      */     
/* 1535 */     Properties localProperties = this.connection.activeConnectionProperties;
/* 1536 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = SQLServerDriver.getPropertyInfoFromProperties(localProperties);
/* 1537 */     Object localObject1 = null;
/* 1538 */     Object localObject2 = null;
/* 1539 */     Object localObject3 = null;
/*      */     
/*      */ 
/*      */ 
/* 1543 */     int i = arrayOfDriverPropertyInfo.length;
/* 1544 */     for (;;) { i--; if (i < 0)
/*      */         break;
/* 1546 */       String str1 = arrayOfDriverPropertyInfo[i].name;
/*      */       
/*      */ 
/* 1549 */       if ((!str1.equals(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString())) && (!str1.equals(SQLServerDriverStringProperty.USER.toString())) && (!str1.equals(SQLServerDriverStringProperty.PASSWORD.toString())) && (!str1.equals(SQLServerDriverStringProperty.KEY_STORE_SECRET.toString())))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1555 */         String str2 = arrayOfDriverPropertyInfo[i].value;
/*      */         
/* 1557 */         if (0 != str2.length())
/*      */         {
/*      */ 
/* 1560 */           if (str1.equals(SQLServerDriverStringProperty.SERVER_NAME.toString()))
/*      */           {
/* 1562 */             localObject1 = str2;
/*      */           }
/* 1564 */           else if (str1.equals(SQLServerDriverStringProperty.INSTANCE_NAME.toString()))
/*      */           {
/* 1566 */             localObject3 = str2;
/*      */           }
/* 1568 */           else if (str1.equals(SQLServerDriverIntProperty.PORT_NUMBER.toString()))
/*      */           {
/* 1570 */             localObject2 = str2;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1575 */             localStringBuilder.append(str1);
/* 1576 */             localStringBuilder.append("=");
/* 1577 */             localStringBuilder.append(str2);
/* 1578 */             localStringBuilder.append(";");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1588 */     localStringBuilder.insert(0, ";");
/* 1589 */     localStringBuilder.insert(0, (String)localObject2);
/* 1590 */     localStringBuilder.insert(0, ":");
/* 1591 */     if (null != localObject3)
/*      */     {
/* 1593 */       localStringBuilder.insert(0, (String)localObject3);
/* 1594 */       localStringBuilder.insert(0, "\\");
/*      */     }
/* 1596 */     localStringBuilder.insert(0, (String)localObject1);
/*      */     
/* 1598 */     localStringBuilder.insert(0, "jdbc:sqlserver://");
/* 1599 */     return localStringBuilder.toString();
/*      */   }
/*      */   
/*      */   public String getUserName() throws SQLServerException {
/* 1603 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1605 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1607 */     checkClosed();
/* 1608 */     SQLServerStatement localSQLServerStatement = null;
/* 1609 */     SQLServerResultSet localSQLServerResultSet = null;
/* 1610 */     String str = "";
/*      */     try
/*      */     {
/* 1613 */       localSQLServerStatement = (SQLServerStatement)this.connection.createStatement();
/* 1614 */       localSQLServerResultSet = localSQLServerStatement.executeQueryInternal("select system_user");
/*      */       
/* 1616 */       boolean bool = localSQLServerResultSet.next();
/* 1617 */       assert (bool);
/*      */       
/* 1619 */       str = localSQLServerResultSet.getString(1);
/*      */     }
/*      */     finally {
/* 1622 */       if (localSQLServerResultSet != null) {
/* 1623 */         localSQLServerResultSet.close();
/*      */       }
/* 1625 */       if (localSQLServerStatement != null) {
/* 1626 */         localSQLServerStatement.close();
/*      */       }
/*      */     }
/* 1629 */     return str;
/*      */   }
/*      */   
/* 1632 */   private static final String[] getVersionColumnsColumnNames = { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getVersionColumns(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 1647 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 1649 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1651 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1659 */     String[] arrayOfString = new String[7];
/* 1660 */     arrayOfString[0] = paramString3;
/* 1661 */     arrayOfString[1] = paramString2;
/* 1662 */     arrayOfString[2] = paramString1;
/* 1663 */     arrayOfString[3] = "V";
/* 1664 */     arrayOfString[4] = "T";
/* 1665 */     arrayOfString[5] = "U";
/* 1666 */     arrayOfString[6] = "3";
/* 1667 */     SQLServerResultSet localSQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPECIAL_COLUMNS, arrayOfString, getVersionColumnsColumnNames);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1672 */     localSQLServerResultSet.getColumn(3).setFilter(new DataTypeFilter());
/* 1673 */     return localSQLServerResultSet;
/*      */   }
/*      */   
/*      */   public boolean isCatalogAtStart() throws SQLServerException {
/* 1677 */     checkClosed();
/* 1678 */     return true;
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() throws SQLServerException {
/* 1682 */     checkClosed();
/* 1683 */     return false;
/*      */   }
/*      */   
/*      */   public boolean nullPlusNonNullIsNull() throws SQLServerException {
/* 1687 */     checkClosed();
/* 1688 */     return true;
/*      */   }
/*      */   
/*      */   public boolean nullsAreSortedAtEnd() throws SQLServerException {
/* 1692 */     checkClosed();
/* 1693 */     return false;
/*      */   }
/*      */   
/*      */   public boolean nullsAreSortedAtStart() throws SQLServerException {
/* 1697 */     checkClosed();
/* 1698 */     return false;
/*      */   }
/*      */   
/*      */   public boolean nullsAreSortedHigh() throws SQLServerException {
/* 1702 */     checkClosed();
/* 1703 */     return false;
/*      */   }
/*      */   
/*      */   public boolean nullsAreSortedLow() throws SQLServerException {
/* 1707 */     checkClosed();
/* 1708 */     return true;
/*      */   }
/*      */   
/* 1711 */   public boolean storesLowerCaseIdentifiers() throws SQLServerException { checkClosed();
/* 1712 */     return false;
/*      */   }
/*      */   
/*      */   public boolean storesLowerCaseQuotedIdentifiers() throws SQLServerException {
/* 1716 */     checkClosed();
/* 1717 */     return false;
/*      */   }
/*      */   
/*      */   public boolean storesMixedCaseIdentifiers() throws SQLServerException {
/* 1721 */     checkClosed();
/* 1722 */     return true;
/*      */   }
/*      */   
/*      */   public boolean storesMixedCaseQuotedIdentifiers() throws SQLServerException {
/* 1726 */     checkClosed();
/* 1727 */     return true;
/*      */   }
/*      */   
/*      */   public boolean storesUpperCaseIdentifiers() throws SQLServerException {
/* 1731 */     checkClosed();
/* 1732 */     return false;
/*      */   }
/*      */   
/*      */   public boolean storesUpperCaseQuotedIdentifiers() throws SQLServerException {
/* 1736 */     checkClosed();
/* 1737 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsAlterTableWithAddColumn() throws SQLServerException {
/* 1741 */     checkClosed();
/* 1742 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsAlterTableWithDropColumn() throws SQLServerException {
/* 1746 */     checkClosed();
/* 1747 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsANSI92EntryLevelSQL() throws SQLServerException {
/* 1751 */     checkClosed();
/* 1752 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsANSI92FullSQL() throws SQLServerException {
/* 1756 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean supportsANSI92IntermediateSQL() throws SQLServerException {
/* 1760 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean supportsCatalogsInDataManipulation() throws SQLServerException {
/* 1764 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsCatalogsInIndexDefinitions() throws SQLServerException {
/* 1768 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLServerException {
/* 1772 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsCatalogsInProcedureCalls() throws SQLServerException {
/* 1776 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsCatalogsInTableDefinitions() throws SQLServerException {
/* 1780 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsColumnAliasing() throws SQLServerException {
/* 1784 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsConvert() throws SQLServerException {
/* 1788 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsConvert(int paramInt1, int paramInt2) throws SQLServerException {
/* 1792 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsCoreSQLGrammar() throws SQLServerException {
/* 1796 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsCorrelatedSubqueries() throws SQLServerException {
/* 1800 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLServerException {
/* 1804 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsDataManipulationTransactionsOnly() throws SQLServerException {
/* 1808 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean supportsDifferentTableCorrelationNames() throws SQLServerException {
/* 1812 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean supportsExpressionsInOrderBy() throws SQLServerException {
/* 1816 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsExtendedSQLGrammar() throws SQLServerException {
/* 1820 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean supportsFullOuterJoins() throws SQLServerException {
/* 1824 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsGroupBy() throws SQLServerException {
/* 1828 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsGroupByBeyondSelect() throws SQLServerException {
/* 1832 */     checkClosed();
/* 1833 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsGroupByUnrelated() throws SQLServerException {
/* 1837 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsIntegrityEnhancementFacility() throws SQLServerException {
/* 1841 */     checkClosed();
/* 1842 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsLikeEscapeClause() throws SQLServerException
/*      */   {
/* 1847 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsLimitedOuterJoins() throws SQLServerException {
/* 1851 */     checkClosed();
/* 1852 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsMinimumSQLGrammar() throws SQLServerException {
/* 1856 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsMixedCaseIdentifiers() throws SQLServerException {
/* 1860 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsMixedCaseQuotedIdentifiers() throws SQLServerException {
/* 1864 */     checkClosed();
/* 1865 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsMultipleResultSets() throws SQLServerException {
/* 1869 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsMultipleTransactions() throws SQLServerException {
/* 1873 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsNonNullableColumns() throws SQLServerException {
/* 1877 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossCommit() throws SQLServerException {
/* 1881 */     checkClosed();
/* 1882 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossRollback() throws SQLServerException {
/* 1886 */     checkClosed();
/* 1887 */     return false;
/*      */   }
/*      */   
/* 1890 */   public boolean supportsOpenStatementsAcrossCommit() throws SQLServerException { checkClosed();
/* 1891 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsOpenStatementsAcrossRollback() throws SQLServerException {
/* 1895 */     checkClosed();
/* 1896 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsOrderByUnrelated() throws SQLServerException {
/* 1900 */     checkClosed();
/* 1901 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsOuterJoins() throws SQLServerException {
/* 1905 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsPositionedDelete() throws SQLServerException {
/* 1909 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsPositionedUpdate() throws SQLServerException {
/* 1913 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSchemasInDataManipulation() throws SQLServerException {
/* 1917 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSchemasInIndexDefinitions() throws SQLServerException {
/* 1921 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSchemasInPrivilegeDefinitions() throws SQLServerException {
/* 1925 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSchemasInProcedureCalls() throws SQLServerException {
/* 1929 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSchemasInTableDefinitions() throws SQLServerException {
/* 1933 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSelectForUpdate() throws SQLServerException {
/* 1937 */     checkClosed();
/* 1938 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsStoredProcedures() throws SQLServerException {
/* 1942 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSubqueriesInComparisons() throws SQLServerException {
/* 1946 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSubqueriesInExists() throws SQLServerException {
/* 1950 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSubqueriesInIns() throws SQLServerException {
/* 1954 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSubqueriesInQuantifieds() throws SQLServerException {
/* 1958 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsTableCorrelationNames() throws SQLServerException {
/* 1962 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsTransactionIsolationLevel(int paramInt) throws SQLServerException {
/* 1966 */     checkClosed();
/* 1967 */     switch (paramInt)
/*      */     {
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 4: 
/*      */     case 8: 
/*      */     case 4096: 
/* 1974 */       return true;
/*      */     }
/* 1976 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsTransactions() throws SQLServerException {
/* 1980 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsUnion() throws SQLServerException {
/* 1984 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsUnionAll() throws SQLServerException {
/* 1988 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean usesLocalFilePerTable() throws SQLServerException {
/* 1992 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean usesLocalFiles() throws SQLServerException {
/* 1996 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean supportsResultSetType(int paramInt) throws SQLServerException {
/* 2000 */     checkClosed();
/* 2001 */     checkResultType(paramInt);
/* 2002 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */     case 1003: 
/*      */     case 1004: 
/*      */     case 1005: 
/*      */     case 1006: 
/*      */     case 2003: 
/*      */     case 2004: 
/* 2012 */       return true; }
/*      */     
/* 2014 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsResultSetConcurrency(int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 2019 */     checkClosed();
/* 2020 */     checkResultType(paramInt1);
/* 2021 */     checkConcurrencyType(paramInt2);
/* 2022 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 1003: 
/*      */     case 1005: 
/*      */     case 1006: 
/*      */     case 2004: 
/* 2029 */       return true;
/*      */     
/*      */     case 1004: 
/*      */     case 2003: 
/* 2033 */       if (1007 == paramInt2) {
/* 2034 */         return true;
/*      */       }
/* 2036 */       return false;
/*      */     }
/*      */     
/* 2039 */     return false;
/*      */   }
/*      */   
/*      */   public boolean ownUpdatesAreVisible(int paramInt) throws SQLServerException {
/* 2043 */     checkClosed();
/* 2044 */     checkResultType(paramInt);
/* 2045 */     if ((paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt))
/*      */     {
/*      */ 
/* 2048 */       return true; }
/* 2049 */     return false;
/*      */   }
/*      */   
/*      */   public boolean ownDeletesAreVisible(int paramInt) throws SQLServerException {
/* 2053 */     checkClosed();
/* 2054 */     checkResultType(paramInt);
/* 2055 */     if ((paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt))
/*      */     {
/*      */ 
/* 2058 */       return true; }
/* 2059 */     return false;
/*      */   }
/*      */   
/*      */   public boolean ownInsertsAreVisible(int paramInt) throws SQLServerException {
/* 2063 */     checkClosed();
/* 2064 */     checkResultType(paramInt);
/* 2065 */     if ((paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt))
/*      */     {
/*      */ 
/* 2068 */       return true; }
/* 2069 */     return false;
/*      */   }
/*      */   
/*      */   public boolean othersUpdatesAreVisible(int paramInt) throws SQLServerException {
/* 2073 */     checkClosed();
/* 2074 */     checkResultType(paramInt);
/* 2075 */     if ((paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt))
/*      */     {
/*      */ 
/* 2078 */       return true; }
/* 2079 */     return false;
/*      */   }
/*      */   
/*      */   public boolean othersDeletesAreVisible(int paramInt) throws SQLServerException {
/* 2083 */     checkClosed();
/* 2084 */     checkResultType(paramInt);
/* 2085 */     if ((paramInt == 1006) || (1003 == paramInt) || (1005 == paramInt) || (1005 == paramInt) || (2004 == paramInt))
/*      */     {
/*      */ 
/* 2088 */       return true; }
/* 2089 */     return false;
/*      */   }
/*      */   
/*      */   public boolean othersInsertsAreVisible(int paramInt) throws SQLServerException {
/* 2093 */     checkClosed();
/* 2094 */     checkResultType(paramInt);
/* 2095 */     if ((paramInt == 1006) || (1003 == paramInt) || (2004 == paramInt))
/*      */     {
/* 2097 */       return true; }
/* 2098 */     return false;
/*      */   }
/*      */   
/*      */   public boolean updatesAreDetected(int paramInt) throws SQLServerException {
/* 2102 */     checkClosed();
/* 2103 */     checkResultType(paramInt);
/* 2104 */     return false;
/*      */   }
/*      */   
/*      */   public boolean deletesAreDetected(int paramInt) throws SQLServerException
/*      */   {
/* 2109 */     checkClosed();
/* 2110 */     checkResultType(paramInt);
/* 2111 */     if (1005 == paramInt) {
/* 2112 */       return true;
/*      */     }
/* 2114 */     return false;
/*      */   }
/*      */   
/*      */   private void checkResultType(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2120 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */     case 1003: 
/*      */     case 1004: 
/*      */     case 1005: 
/*      */     case 1006: 
/*      */     case 2003: 
/*      */     case 2004: 
/* 2130 */       return;
/*      */     }
/*      */     
/* 2133 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2134 */     Object[] arrayOfObject = { new Integer(paramInt) };
/* 2135 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*      */   }
/*      */   
/*      */   private void checkConcurrencyType(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2141 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */     case 1007: 
/*      */     case 1008: 
/*      */     case 1009: 
/*      */     case 1010: 
/* 2148 */       return;
/*      */     }
/*      */     
/* 2151 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2152 */     Object[] arrayOfObject = { new Integer(paramInt) };
/* 2153 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*      */   }
/*      */   
/*      */   public boolean insertsAreDetected(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 2159 */     checkClosed();
/* 2160 */     checkResultType(paramInt);
/* 2161 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsBatchUpdates() throws SQLServerException {
/* 2165 */     checkClosed();
/* 2166 */     return true;
/*      */   }
/*      */   
/*      */   public ResultSet getUDTs(String paramString1, String paramString2, String paramString3, int[] paramArrayOfInt) throws SQLServerException
/*      */   {
/* 2171 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2173 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 2175 */     checkClosed();
/* 2176 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as CLASS_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as REMARKS, cast(0 as smallint) as BASE_TYPE where 0 = 1");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLServerException
/*      */   {
/* 2189 */     checkClosed();
/* 2190 */     return this.connection.getConnection();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getSQLStateType()
/*      */     throws SQLServerException
/*      */   {
/* 2197 */     checkClosed();
/* 2198 */     if ((this.connection != null) && (this.connection.xopenStates)) {
/* 2199 */       return 1;
/*      */     }
/* 2201 */     return 2;
/*      */   }
/*      */   
/*      */   public int getDatabaseMajorVersion() throws SQLServerException {
/* 2205 */     checkClosed();
/* 2206 */     String str = this.connection.sqlServerVersion;
/* 2207 */     int i = str.indexOf('.');
/* 2208 */     if (i > 0)
/* 2209 */       str = str.substring(0, i);
/*      */     try {
/* 2211 */       return new Integer(str).intValue();
/*      */     }
/*      */     catch (NumberFormatException localNumberFormatException) {}
/* 2214 */     return 0;
/*      */   }
/*      */   
/*      */   public int getDatabaseMinorVersion() throws SQLServerException
/*      */   {
/* 2219 */     checkClosed();
/* 2220 */     String str = this.connection.sqlServerVersion;
/* 2221 */     int i = str.indexOf('.');
/* 2222 */     int j = str.indexOf('.', i + 1);
/* 2223 */     if ((i > 0) && (j > 0))
/* 2224 */       str = str.substring(i + 1, j);
/*      */     try {
/* 2226 */       return new Integer(str).intValue();
/*      */     }
/*      */     catch (NumberFormatException localNumberFormatException) {}
/* 2229 */     return 0;
/*      */   }
/*      */   
/*      */   public int getJDBCMajorVersion() throws SQLServerException
/*      */   {
/* 2234 */     checkClosed();
/* 2235 */     return 4;
/*      */   }
/*      */   
/* 2238 */   public int getJDBCMinorVersion() throws SQLServerException { checkClosed();
/* 2239 */     return 1;
/*      */   }
/*      */   
/*      */   public int getResultSetHoldability() throws SQLServerException {
/* 2243 */     checkClosed();return 1;
/*      */   }
/*      */   
/*      */   public RowIdLifetime getRowIdLifetime() throws SQLException
/*      */   {
/* 2248 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2249 */     checkClosed();
/* 2250 */     return RowIdLifetime.ROWID_UNSUPPORTED;
/*      */   }
/*      */   
/*      */   public boolean supportsResultSetHoldability(int paramInt) throws SQLServerException
/*      */   {
/* 2255 */     checkClosed();
/* 2256 */     if ((1 == paramInt) || (2 == paramInt))
/*      */     {
/* 2258 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 2262 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2263 */     Object[] arrayOfObject = { new Integer(paramInt) };
/* 2264 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*      */   }
/*      */   
/*      */   public ResultSet getAttributes(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLServerException
/*      */   {
/* 2269 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2271 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 2273 */     checkClosed();
/* 2274 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as ATTR_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as ATTR_TYPE_NAME, cast(0 as int) as ATTR_SIZE, cast(0 as int) as DECIMAL_DIGITS, cast(0 as int) as NUM_PREC_RADIX, cast(0 as int) as NULLABLE, cast(NULL as char(1)) as REMARKS, cast(NULL as char(1)) as ATTR_DEF, cast(0 as int) as SQL_DATA_TYPE, cast(0 as int) as SQL_DATETIME_SUB, cast(0 as int) as CHAR_OCTET_LENGTH, cast(0 as int) as ORDINAL_POSITION, cast(NULL as char(1)) as IS_NULLABLE, cast(NULL as char(1)) as SCOPE_CATALOG, cast(NULL as char(1)) as SCOPE_SCHEMA, cast(NULL as char(1)) as SCOPE_TABLE, cast(0 as smallint) as SOURCE_DATA_TYPE where 0 = 1");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSuperTables(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 2301 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2303 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 2305 */     checkClosed();
/* 2306 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTABLE_NAME where 0 = 1");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSuperTypes(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLServerException
/*      */   {
/* 2316 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2318 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 2320 */     checkClosed();
/* 2321 */     return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTYPE_CAT, cast(NULL as char(1)) as SUPERTYPE_SCHEM, cast(NULL as char(1)) as SUPERTYPE_NAME where 0 = 1");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGetGeneratedKeys()
/*      */     throws SQLServerException
/*      */   {
/* 2333 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsMultipleOpenResults() throws SQLServerException {
/* 2337 */     checkClosed();return false;
/*      */   }
/*      */   
/*      */   public boolean supportsNamedParameters() throws SQLServerException {
/* 2341 */     checkClosed();return true;
/*      */   }
/*      */   
/*      */   public boolean supportsSavepoints() throws SQLServerException {
/* 2345 */     checkClosed();return true;
/*      */   }
/*      */   
/* 2348 */   public boolean supportsStatementPooling() throws SQLException { checkClosed();
/* 2349 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException
/*      */   {
/* 2354 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2355 */     checkClosed();
/* 2356 */     return true;
/*      */   }
/*      */   
/*      */   public boolean locatorsUpdateCopy() throws SQLException {
/* 2360 */     checkClosed();return true;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerDatabaseMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */