/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.Permission;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ class SQLServerConnectionPoolProxy implements ISQLServerConnection, java.io.Serializable
/*     */ {
/*     */   private SQLServerConnection wrappedConnection;
/*     */   private boolean bIsOpen;
/*  25 */   private static int baseConnectionID = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   private final String traceID;
/*     */   
/*     */ 
/*     */   private static final String callAbortPerm = "callAbort";
/*     */   
/*     */ 
/*     */ 
/*     */   private static synchronized int nextConnectionID()
/*     */   {
/*  38 */     baseConnectionID += 1;
/*  39 */     return baseConnectionID;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  44 */     return this.traceID;
/*     */   }
/*     */   
/*     */   SQLServerConnectionPoolProxy(SQLServerConnection paramSQLServerConnection)
/*     */   {
/*  49 */     this.traceID = (" ProxyConnectionID:" + nextConnectionID());
/*  50 */     this.wrappedConnection = paramSQLServerConnection;
/*     */     
/*     */ 
/*  53 */     paramSQLServerConnection.setAssociatedProxy(this);
/*  54 */     this.bIsOpen = true;
/*     */   }
/*     */   
/*     */   void checkClosed() throws SQLServerException
/*     */   {
/*  59 */     if (!this.bIsOpen)
/*     */     {
/*  61 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), null, false);
/*     */     }
/*     */   }
/*     */   
/*     */   public Statement createStatement() throws SQLServerException {
/*  66 */     checkClosed();
/*  67 */     return this.wrappedConnection.createStatement();
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString) throws SQLServerException
/*     */   {
/*  72 */     checkClosed();
/*  73 */     return this.wrappedConnection.prepareStatement(paramString);
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCall(String paramString) throws SQLServerException
/*     */   {
/*  78 */     checkClosed();
/*  79 */     return this.wrappedConnection.prepareCall(paramString);
/*     */   }
/*     */   
/*     */   public String nativeSQL(String paramString) throws SQLServerException
/*     */   {
/*  84 */     checkClosed();
/*  85 */     return this.wrappedConnection.nativeSQL(paramString);
/*     */   }
/*     */   
/*     */   public void setAutoCommit(boolean paramBoolean) throws SQLServerException
/*     */   {
/*  90 */     checkClosed();
/*  91 */     this.wrappedConnection.setAutoCommit(paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getAutoCommit() throws SQLServerException
/*     */   {
/*  96 */     checkClosed();
/*  97 */     return this.wrappedConnection.getAutoCommit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void commit()
/*     */     throws SQLServerException
/*     */   {
/* 105 */     checkClosed();
/* 106 */     this.wrappedConnection.commit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rollback()
/*     */     throws SQLServerException
/*     */   {
/* 116 */     checkClosed();
/* 117 */     this.wrappedConnection.rollback();
/*     */   }
/*     */   
/*     */   public void abort(Executor paramExecutor)
/*     */     throws SQLException
/*     */   {
/*     */     
/* 124 */     if ((!this.bIsOpen) || (null == this.wrappedConnection))
/*     */       return;
/*     */     Object localObject2;
/* 127 */     if (null == paramExecutor)
/*     */     {
/* 129 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 130 */       localObject2 = new Object[] { "executor" };
/* 131 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject1).format(localObject2), null, false);
/*     */     }
/*     */     
/*     */ 
/* 135 */     Object localObject1 = System.getSecurityManager();
/* 136 */     if (localObject1 != null)
/*     */     {
/*     */       try
/*     */       {
/* 140 */         localObject2 = new java.sql.SQLPermission("callAbort");
/* 141 */         ((SecurityManager)localObject1).checkPermission((Permission)localObject2);
/*     */       }
/*     */       catch (SecurityException localSecurityException)
/*     */       {
/* 145 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_permissionDenied"));
/* 146 */         Object[] arrayOfObject = { "callAbort" };
/* 147 */         throw new SQLServerException(localMessageFormat.format(arrayOfObject), null, 0, localSecurityException);
/*     */       }
/*     */     }
/*     */     
/* 151 */     this.bIsOpen = false;
/*     */     
/*     */ 
/* 154 */     paramExecutor.execute(new Runnable()
/*     */     {
/*     */       public void run() {
/* 157 */         if (SQLServerConnectionPoolProxy.this.wrappedConnection.getConnectionLogger().isLoggable(Level.FINER)) {
/* 158 */           SQLServerConnectionPoolProxy.this.wrappedConnection.getConnectionLogger().finer(toString() + " Connection proxy aborted ");
/*     */         }
/*     */         try {
/* 161 */           SQLServerConnectionPoolProxy.this.wrappedConnection.poolCloseEventNotify();
/* 162 */           SQLServerConnectionPoolProxy.this.wrappedConnection = null;
/*     */         }
/*     */         catch (SQLException localSQLException)
/*     */         {
/* 166 */           throw new RuntimeException(localSQLException);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void close() throws SQLServerException
/*     */   {
/* 174 */     if ((this.bIsOpen) && (null != this.wrappedConnection))
/*     */     {
/* 176 */       if (this.wrappedConnection.getConnectionLogger().isLoggable(Level.FINER))
/* 177 */         this.wrappedConnection.getConnectionLogger().finer(toString() + " Connection proxy closed ");
/* 178 */       this.wrappedConnection.poolCloseEventNotify();
/* 179 */       this.wrappedConnection = null;
/*     */     }
/* 181 */     this.bIsOpen = false;
/*     */   }
/*     */   
/*     */   void internalClose() {
/* 185 */     this.bIsOpen = false;
/* 186 */     this.wrappedConnection = null;
/*     */   }
/*     */   
/*     */   public boolean isClosed()
/*     */     throws SQLServerException
/*     */   {
/* 192 */     return !this.bIsOpen;
/*     */   }
/*     */   
/*     */   public DatabaseMetaData getMetaData() throws SQLServerException
/*     */   {
/* 197 */     checkClosed();
/* 198 */     return this.wrappedConnection.getMetaData();
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean paramBoolean) throws SQLServerException
/*     */   {
/* 203 */     checkClosed();
/* 204 */     this.wrappedConnection.setReadOnly(paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() throws SQLServerException
/*     */   {
/* 209 */     checkClosed();
/* 210 */     return this.wrappedConnection.isReadOnly();
/*     */   }
/*     */   
/*     */   public void setCatalog(String paramString) throws SQLServerException
/*     */   {
/* 215 */     checkClosed();
/* 216 */     this.wrappedConnection.setCatalog(paramString);
/*     */   }
/*     */   
/*     */   public String getCatalog() throws SQLServerException
/*     */   {
/* 221 */     checkClosed();
/* 222 */     return this.wrappedConnection.getCatalog();
/*     */   }
/*     */   
/*     */   public void setTransactionIsolation(int paramInt) throws SQLServerException
/*     */   {
/* 227 */     checkClosed();
/* 228 */     this.wrappedConnection.setTransactionIsolation(paramInt);
/*     */   }
/*     */   
/*     */   public int getTransactionIsolation() throws SQLServerException
/*     */   {
/* 233 */     checkClosed();
/* 234 */     return this.wrappedConnection.getTransactionIsolation();
/*     */   }
/*     */   
/*     */   public java.sql.SQLWarning getWarnings() throws SQLServerException
/*     */   {
/* 239 */     checkClosed();
/* 240 */     return this.wrappedConnection.getWarnings();
/*     */   }
/*     */   
/*     */   public void clearWarnings() throws SQLServerException
/*     */   {
/* 245 */     checkClosed();
/* 246 */     this.wrappedConnection.clearWarnings();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Statement createStatement(int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 255 */     checkClosed();
/* 256 */     return this.wrappedConnection.createStatement(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 264 */     checkClosed();
/* 265 */     return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 271 */     checkClosed();
/* 272 */     return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public void setTypeMap(Map<String, Class<?>> paramMap) throws SQLServerException
/*     */   {
/* 277 */     checkClosed();
/* 278 */     this.wrappedConnection.setTypeMap(paramMap);
/*     */   }
/*     */   
/*     */   public Map<String, Class<?>> getTypeMap() throws SQLServerException
/*     */   {
/* 283 */     checkClosed();
/* 284 */     return this.wrappedConnection.getTypeMap();
/*     */   }
/*     */   
/*     */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*     */   {
/* 289 */     checkClosed();
/* 290 */     return this.wrappedConnection.createStatement(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting)
/*     */     throws SQLServerException
/*     */   {
/* 300 */     checkClosed();
/* 301 */     return this.wrappedConnection.createStatement(paramInt1, paramInt2, paramInt3, paramSQLServerStatementColumnEncryptionSetting);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*     */   {
/* 306 */     checkClosed();
/* 307 */     return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting)
/*     */     throws SQLServerException
/*     */   {
/* 318 */     checkClosed();
/* 319 */     return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2, paramInt3, paramSQLServerStatementColumnEncryptionSetting);
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*     */   {
/* 324 */     checkClosed();
/* 325 */     return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting)
/*     */     throws SQLServerException
/*     */   {
/* 336 */     checkClosed();
/* 337 */     return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2, paramInt3, paramSQLServerStatementColumnEncryptionSetting);
/*     */   }
/*     */   
/*     */ 
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 344 */     checkClosed();
/* 345 */     return this.wrappedConnection.prepareStatement(paramString, paramInt);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int paramInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*     */   {
/* 350 */     checkClosed();
/* 351 */     return this.wrappedConnection.prepareStatement(paramString, paramInt, paramSQLServerStatementColumnEncryptionSetting);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfInt) throws SQLServerException
/*     */   {
/* 356 */     checkClosed();
/* 357 */     return this.wrappedConnection.prepareStatement(paramString, paramArrayOfInt);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*     */   {
/* 362 */     checkClosed();
/* 363 */     return this.wrappedConnection.prepareStatement(paramString, paramArrayOfInt, paramSQLServerStatementColumnEncryptionSetting);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLServerException
/*     */   {
/* 368 */     checkClosed();
/* 369 */     return this.wrappedConnection.prepareStatement(paramString, paramArrayOfString);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*     */   {
/* 374 */     checkClosed();
/* 375 */     return this.wrappedConnection.prepareStatement(paramString, paramArrayOfString, paramSQLServerStatementColumnEncryptionSetting);
/*     */   }
/*     */   
/*     */ 
/*     */   public void releaseSavepoint(Savepoint paramSavepoint)
/*     */     throws SQLServerException
/*     */   {
/* 382 */     checkClosed();
/* 383 */     this.wrappedConnection.releaseSavepoint(paramSavepoint);
/*     */   }
/*     */   
/*     */   public Savepoint setSavepoint(String paramString) throws SQLServerException
/*     */   {
/* 388 */     checkClosed();
/* 389 */     return this.wrappedConnection.setSavepoint(paramString);
/*     */   }
/*     */   
/*     */   public Savepoint setSavepoint() throws SQLServerException
/*     */   {
/* 394 */     checkClosed();
/* 395 */     return this.wrappedConnection.setSavepoint();
/*     */   }
/*     */   
/*     */   public void rollback(Savepoint paramSavepoint) throws SQLServerException
/*     */   {
/* 400 */     checkClosed();
/* 401 */     this.wrappedConnection.rollback(paramSavepoint);
/*     */   }
/*     */   
/*     */   public int getHoldability() throws SQLServerException
/*     */   {
/* 406 */     checkClosed();
/* 407 */     return this.wrappedConnection.getHoldability();
/*     */   }
/*     */   
/*     */   public void setHoldability(int paramInt) throws SQLServerException
/*     */   {
/* 412 */     checkClosed();
/* 413 */     this.wrappedConnection.setHoldability(paramInt);
/*     */   }
/*     */   
/*     */   public int getNetworkTimeout() throws SQLException
/*     */   {
/* 418 */     DriverJDBCVersion.checkSupportsJDBC41();
/*     */     
/*     */ 
/* 421 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */   
/*     */   public void setNetworkTimeout(Executor paramExecutor, int paramInt) throws SQLException
/*     */   {
/* 426 */     DriverJDBCVersion.checkSupportsJDBC41();
/*     */     
/*     */ 
/* 429 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */   
/*     */   public String getSchema() throws SQLException
/*     */   {
/* 434 */     DriverJDBCVersion.checkSupportsJDBC41();
/*     */     
/* 436 */     checkClosed();
/* 437 */     return this.wrappedConnection.getSchema();
/*     */   }
/*     */   
/*     */   public void setSchema(String paramString) throws SQLException
/*     */   {
/* 442 */     DriverJDBCVersion.checkSupportsJDBC41();
/*     */     
/* 444 */     checkClosed();
/* 445 */     this.wrappedConnection.setSchema(paramString);
/*     */   }
/*     */   
/*     */   public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException
/*     */   {
/* 450 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 452 */     checkClosed();
/* 453 */     return this.wrappedConnection.createArrayOf(paramString, paramArrayOfObject);
/*     */   }
/*     */   
/*     */   public Blob createBlob() throws SQLException
/*     */   {
/* 458 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 460 */     checkClosed();
/* 461 */     return this.wrappedConnection.createBlob();
/*     */   }
/*     */   
/*     */   public java.sql.Clob createClob() throws SQLException
/*     */   {
/* 466 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 468 */     checkClosed();
/* 469 */     return this.wrappedConnection.createClob();
/*     */   }
/*     */   
/*     */   public java.sql.NClob createNClob() throws SQLException
/*     */   {
/* 474 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 476 */     checkClosed();
/* 477 */     return this.wrappedConnection.createNClob();
/*     */   }
/*     */   
/*     */   public java.sql.SQLXML createSQLXML() throws SQLException
/*     */   {
/* 482 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 484 */     checkClosed();
/* 485 */     return this.wrappedConnection.createSQLXML();
/*     */   }
/*     */   
/*     */   public java.sql.Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException
/*     */   {
/* 490 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 492 */     checkClosed();
/* 493 */     return this.wrappedConnection.createStruct(paramString, paramArrayOfObject);
/*     */   }
/*     */   
/*     */   public Properties getClientInfo() throws SQLException
/*     */   {
/* 498 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 500 */     checkClosed();
/* 501 */     return this.wrappedConnection.getClientInfo();
/*     */   }
/*     */   
/*     */   public String getClientInfo(String paramString) throws SQLException
/*     */   {
/* 506 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 508 */     checkClosed();
/* 509 */     return this.wrappedConnection.getClientInfo(paramString);
/*     */   }
/*     */   
/*     */   public void setClientInfo(Properties paramProperties) throws SQLClientInfoException
/*     */   {
/* 514 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/*     */ 
/* 517 */     this.wrappedConnection.setClientInfo(paramProperties);
/*     */   }
/*     */   
/*     */   public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException
/*     */   {
/* 522 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/*     */ 
/* 525 */     this.wrappedConnection.setClientInfo(paramString1, paramString2);
/*     */   }
/*     */   
/*     */   public boolean isValid(int paramInt) throws SQLException
/*     */   {
/* 530 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 532 */     checkClosed();
/* 533 */     return this.wrappedConnection.isValid(paramInt);
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException
/*     */   {
/* 538 */     this.wrappedConnection.getConnectionLogger().entering(toString(), "isWrapperFor", paramClass);
/* 539 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 540 */     boolean bool = paramClass.isInstance(this);
/* 541 */     this.wrappedConnection.getConnectionLogger().exiting(toString(), "isWrapperFor", Boolean.valueOf(bool));
/* 542 */     return bool;
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException
/*     */   {
/* 547 */     this.wrappedConnection.getConnectionLogger().entering(toString(), "unwrap", paramClass);
/* 548 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/*     */     Object localObject;
/*     */     try
/*     */     {
/* 553 */       localObject = paramClass.cast(this);
/*     */     }
/*     */     catch (ClassCastException localClassCastException)
/*     */     {
/* 557 */       SQLServerException localSQLServerException = new SQLServerException(localClassCastException.getMessage(), localClassCastException);
/* 558 */       throw localSQLServerException;
/*     */     }
/* 560 */     this.wrappedConnection.getConnectionLogger().exiting(toString(), "unwrap", localObject);
/* 561 */     return (T)localObject;
/*     */   }
/*     */   
/*     */   public java.util.UUID getClientConnectionId() throws SQLServerException
/*     */   {
/* 566 */     checkClosed();
/* 567 */     return this.wrappedConnection.getClientConnectionId();
/*     */   }
/*     */   
/*     */   public synchronized void setSendTimeAsDatetime(boolean paramBoolean) throws SQLServerException
/*     */   {
/* 572 */     checkClosed();
/* 573 */     this.wrappedConnection.setSendTimeAsDatetime(paramBoolean);
/*     */   }
/*     */   
/*     */   public final synchronized boolean getSendTimeAsDatetime() throws SQLServerException
/*     */   {
/* 578 */     checkClosed();
/* 579 */     return this.wrappedConnection.getSendTimeAsDatetime();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerConnectionPoolProxy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */