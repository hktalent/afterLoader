package com.microsoft.sqlserver.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import microsoft.sql.DateTimeOffset;

public abstract interface ISQLServerResultSet
  extends ResultSet
{
  public static final int TYPE_SS_DIRECT_FORWARD_ONLY = 2003;
  public static final int TYPE_SS_SERVER_CURSOR_FORWARD_ONLY = 2004;
  public static final int TYPE_SS_SCROLL_STATIC = 1004;
  public static final int TYPE_SS_SCROLL_KEYSET = 1005;
  public static final int TYPE_SS_SCROLL_DYNAMIC = 1006;
  public static final int CONCUR_SS_OPTIMISTIC_CC = 1008;
  public static final int CONCUR_SS_SCROLL_LOCKS = 1009;
  public static final int CONCUR_SS_OPTIMISTIC_CCVAL = 1010;
  
  public abstract DateTimeOffset getDateTimeOffset(int paramInt)
    throws SQLException;
  
  public abstract DateTimeOffset getDateTimeOffset(String paramString)
    throws SQLException;
  
  public abstract void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset)
    throws SQLException;
  
  public abstract void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset)
    throws SQLException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ISQLServerResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */