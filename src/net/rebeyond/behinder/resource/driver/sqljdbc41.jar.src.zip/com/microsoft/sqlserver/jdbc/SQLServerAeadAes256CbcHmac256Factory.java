/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.text.MessageFormat;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import javax.xml.bind.DatatypeConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SQLServerAeadAes256CbcHmac256Factory
/*    */   extends SQLServerEncryptionAlgorithmFactory
/*    */ {
/* 16 */   private byte algorithmVersion = 1;
/* 17 */   private ConcurrentHashMap<String, SQLServerAeadAes256CbcHmac256Algorithm> encryptionAlgorithms = new ConcurrentHashMap();
/*    */   
/*    */ 
/*    */ 
/*    */   SQLServerEncryptionAlgorithm create(SQLServerSymmetricKey paramSQLServerSymmetricKey, SQLServerEncryptionType paramSQLServerEncryptionType, String paramString)
/*    */     throws SQLServerException
/*    */   {
/* 24 */     assert (paramSQLServerSymmetricKey != null);
/* 25 */     Object localObject2; if ((paramSQLServerEncryptionType != SQLServerEncryptionType.Deterministic) && (paramSQLServerEncryptionType != SQLServerEncryptionType.Randomized)) {
/* 26 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionType"));
/* 27 */       localObject2 = new Object[] { paramSQLServerEncryptionType, paramString, "'" + SQLServerEncryptionType.Deterministic + "," + SQLServerEncryptionType.Randomized + "'" };
/* 28 */       throw new SQLServerException(this, ((MessageFormat)localObject1).format(localObject2), null, 0, false);
/*    */     }
/*    */     
/* 31 */     Object localObject1 = "";
/*    */     try
/*    */     {
/* 34 */       localObject2 = new StringBuffer();
/* 35 */       ((StringBuffer)localObject2).append(DatatypeConverter.printBase64Binary(new String(paramSQLServerSymmetricKey.getRootKey(), "UTF-8").getBytes()));
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 44 */       ((StringBuffer)localObject2).append(":");
/* 45 */       ((StringBuffer)localObject2).append(paramSQLServerEncryptionType);
/* 46 */       ((StringBuffer)localObject2).append(":");
/* 47 */       ((StringBuffer)localObject2).append(this.algorithmVersion);
/*    */       
/* 49 */       localObject1 = ((StringBuffer)localObject2).toString();
/*    */       
/*    */ 
/*    */ 
/* 53 */       if (!this.encryptionAlgorithms.containsKey(localObject1)) {
/* 54 */         localObject4 = new SQLServerAeadAes256CbcHmac256EncryptionKey(paramSQLServerSymmetricKey.getRootKey(), "AEAD_AES_256_CBC_HMAC_SHA256");
/* 55 */         localObject3 = new SQLServerAeadAes256CbcHmac256Algorithm((SQLServerAeadAes256CbcHmac256EncryptionKey)localObject4, paramSQLServerEncryptionType, this.algorithmVersion);
/* 56 */         this.encryptionAlgorithms.putIfAbsent(localObject1, localObject3);
/*    */       }
/*    */       
/*    */     }
/*    */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*    */     {
/* 62 */       Object localObject3 = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*    */       
/* 64 */       Object localObject4 = { "UTF-8" };
/* 65 */       throw new SQLServerException(this, ((MessageFormat)localObject3).format(localObject4), null, 0, false);
/*    */     }
/* 67 */     return (SQLServerEncryptionAlgorithm)this.encryptionAlgorithms.get(localObject1);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerAeadAes256CbcHmac256Factory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */