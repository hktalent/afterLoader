/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UDTTDSHeader
/*    */ {
/*    */   private final int maxLen;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String databaseName;
/*    */   
/*    */ 
/*    */ 
/*    */   private final String schemaName;
/*    */   
/*    */ 
/*    */ 
/*    */   private final String typeName;
/*    */   
/*    */ 
/*    */ 
/*    */   private final String assemblyQualifiedName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   UDTTDSHeader(TDSReader paramTDSReader)
/*    */     throws SQLServerException
/*    */   {
/* 34 */     this.maxLen = paramTDSReader.readUnsignedShort();
/* 35 */     this.databaseName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 36 */     this.schemaName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 37 */     this.typeName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 38 */     this.assemblyQualifiedName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
/*    */   }
/*    */   
/* 41 */   int getMaxLen() { return this.maxLen; }
/*    */   
/*    */   String getTypeName() {
/* 44 */     return this.typeName;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/UDTTDSHeader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */