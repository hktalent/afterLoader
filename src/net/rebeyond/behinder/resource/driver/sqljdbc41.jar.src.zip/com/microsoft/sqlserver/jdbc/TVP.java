/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TVP
/*     */ {
/*     */   String TVPName;
/*     */   String TVP_owningSchema;
/*     */   String TVP_dbName;
/*  26 */   ResultSet sourceResultSet = null;
/*  27 */   SQLServerDataTable sourceDataTable = null;
/*  28 */   Map<Integer, SQLServerMetaData> columnMetadata = null;
/*  29 */   Iterator<Map.Entry<Integer, Object[]>> sourceDataTableRowIterator = null;
/*  30 */   ISQLServerDataRecord sourceRecord = null;
/*     */   
/*  32 */   TVPType tvpType = null;
/*     */   
/*     */   static enum MPIState
/*     */   {
/*  36 */     MPI_Value, 
/*  37 */     MPI_ParseNonQuote, 
/*  38 */     MPI_LookForSeparator, 
/*  39 */     MPI_LookForNextCharOrSeparator, 
/*  40 */     MPI_ParseQuote, 
/*  41 */     MPI_RightQuote;
/*     */     
/*     */     private MPIState() {}
/*     */   }
/*     */   
/*  46 */   void initTVP(TVPType paramTVPType, String paramString) throws SQLServerException { this.tvpType = paramTVPType;
/*  47 */     this.columnMetadata = new LinkedHashMap();
/*  48 */     parseTypeName(paramString);
/*     */   }
/*     */   
/*     */   TVP(String paramString) throws SQLServerException
/*     */   {
/*  53 */     initTVP(TVPType.Null, paramString);
/*     */   }
/*     */   
/*     */   TVP(String paramString, SQLServerDataTable paramSQLServerDataTable)
/*     */     throws SQLServerException
/*     */   {
/*  59 */     initTVP(TVPType.SQLServerDataTable, paramString);
/*  60 */     this.sourceDataTable = paramSQLServerDataTable;
/*  61 */     this.sourceDataTableRowIterator = this.sourceDataTable.getIterator();
/*  62 */     populateMetadataFromDataTable();
/*     */   }
/*     */   
/*     */   TVP(String paramString, ResultSet paramResultSet) throws SQLServerException
/*     */   {
/*  67 */     initTVP(TVPType.ResultSet, paramString);
/*  68 */     this.sourceResultSet = paramResultSet;
/*     */     
/*  70 */     populateMetadataFromResultSet();
/*     */   }
/*     */   
/*     */   TVP(String paramString, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException
/*     */   {
/*  75 */     initTVP(TVPType.ISQLServerDataRecord, paramString);
/*  76 */     this.sourceRecord = paramISQLServerDataRecord;
/*     */     
/*  78 */     populateMetadataFromDataRecord();
/*     */     
/*     */ 
/*  81 */     validateOrderProperty();
/*     */   }
/*     */   
/*     */   boolean isNull()
/*     */   {
/*  86 */     return TVPType.Null == this.tvpType;
/*     */   }
/*     */   
/*     */   Object[] getRowData()
/*     */     throws SQLServerException
/*     */   {
/*  92 */     if (TVPType.ResultSet == this.tvpType)
/*     */     {
/*  94 */       int i = this.columnMetadata.size();
/*  95 */       Object[] arrayOfObject = new Object[i];
/*  96 */       for (int j = 0; j < i; j++)
/*     */       {
/*     */         try
/*     */         {
/* 100 */           arrayOfObject[j] = this.sourceResultSet.getObject(j + 1);
/*     */         }
/*     */         catch (SQLException localSQLException)
/*     */         {
/* 104 */           throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), localSQLException);
/*     */         }
/*     */       }
/* 107 */       return arrayOfObject;
/*     */     }
/* 109 */     if (TVPType.SQLServerDataTable == this.tvpType)
/*     */     {
/* 111 */       Map.Entry localEntry = (Map.Entry)this.sourceDataTableRowIterator.next();
/* 112 */       return (Object[])localEntry.getValue();
/*     */     }
/*     */     
/* 115 */     return this.sourceRecord.getRowData();
/*     */   }
/*     */   
/*     */   boolean next() throws SQLServerException
/*     */   {
/* 120 */     if (TVPType.ResultSet == this.tvpType)
/*     */     {
/*     */       try
/*     */       {
/* 124 */         return this.sourceResultSet.next();
/*     */       }
/*     */       catch (SQLException localSQLException)
/*     */       {
/* 128 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), localSQLException);
/*     */       }
/*     */     }
/* 131 */     if (TVPType.SQLServerDataTable == this.tvpType)
/*     */     {
/* 133 */       return this.sourceDataTableRowIterator.hasNext();
/*     */     }
/*     */     
/* 136 */     return this.sourceRecord.next();
/*     */   }
/*     */   
/*     */   void populateMetadataFromDataTable() throws SQLServerException
/*     */   {
/* 141 */     assert (null != this.sourceDataTable);
/*     */     
/* 143 */     Map localMap = this.sourceDataTable.getColumnMetadata();
/* 144 */     if ((null == localMap) || (localMap.isEmpty()))
/*     */     {
/* 146 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*     */     }
/*     */     
/*     */ 
/* 150 */     Iterator localIterator = localMap.entrySet().iterator();
/* 151 */     while (localIterator.hasNext())
/*     */     {
/* 153 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/*     */       
/* 155 */       this.columnMetadata.put(localEntry.getKey(), new SQLServerMetaData(((SQLServerDataColumn)localEntry.getValue()).columnName, ((SQLServerDataColumn)localEntry.getValue()).javaSqlType, ((SQLServerDataColumn)localEntry.getValue()).precision, ((SQLServerDataColumn)localEntry.getValue()).scale));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void populateMetadataFromResultSet()
/*     */     throws SQLServerException
/*     */   {
/* 167 */     assert (null != this.sourceResultSet);
/*     */     try
/*     */     {
/* 170 */       ResultSetMetaData localResultSetMetaData = this.sourceResultSet.getMetaData();
/* 171 */       for (int i = 0; i < localResultSetMetaData.getColumnCount(); i++)
/*     */       {
/* 173 */         SQLServerMetaData localSQLServerMetaData = new SQLServerMetaData(localResultSetMetaData.getColumnName(i + 1), localResultSetMetaData.getColumnType(i + 1), localResultSetMetaData.getPrecision(i + 1), localResultSetMetaData.getScale(i + 1));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 178 */         this.columnMetadata.put(Integer.valueOf(i), localSQLServerMetaData);
/*     */       }
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 183 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), localSQLException);
/*     */     }
/*     */   }
/*     */   
/*     */   void populateMetadataFromDataRecord() throws SQLServerException
/*     */   {
/* 189 */     assert (null != this.sourceRecord);
/* 190 */     if (0 >= this.sourceRecord.getColumnCount())
/*     */     {
/* 192 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*     */     }
/*     */     
/*     */ 
/* 196 */     for (int i = 0; i < this.sourceRecord.getColumnCount(); i++)
/*     */     {
/*     */ 
/* 199 */       Util.checkDuplicateColumnName(this.sourceRecord.getColumnMetaData(i + 1).columnName, this.columnMetadata);
/* 200 */       SQLServerMetaData localSQLServerMetaData = new SQLServerMetaData(this.sourceRecord.getColumnMetaData(i + 1));
/* 201 */       this.columnMetadata.put(Integer.valueOf(i), localSQLServerMetaData);
/*     */     }
/*     */   }
/*     */   
/*     */   void validateOrderProperty() throws SQLServerException
/*     */   {
/* 207 */     int i = this.columnMetadata.size();
/* 208 */     boolean[] arrayOfBoolean = new boolean[i];
/*     */     
/* 210 */     int j = -1;
/* 211 */     int k = 0;
/* 212 */     Iterator localIterator = this.columnMetadata.entrySet().iterator();
/* 213 */     Object localObject; while (localIterator.hasNext())
/*     */     {
/* 215 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 216 */       localObject = ((SQLServerMetaData)localEntry.getValue()).sortOrder;
/* 217 */       int n = ((SQLServerMetaData)localEntry.getValue()).sortOrdinal;
/*     */       
/* 219 */       if (SQLServerSortOrder.Unspecified != localObject)
/*     */       {
/*     */         MessageFormat localMessageFormat;
/* 222 */         if (i <= n)
/*     */         {
/* 224 */           localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPSortOrdinalGreaterThanFieldCount"));
/* 225 */           throw new SQLServerException(localMessageFormat.format(new Object[] { Integer.valueOf(n), localEntry.getKey() }), null, 0, null);
/*     */         }
/*     */         
/*     */ 
/* 229 */         if (arrayOfBoolean[n] != 0)
/*     */         {
/* 231 */           localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateSortOrdinal"));
/* 232 */           throw new SQLServerException(localMessageFormat.format(new Object[] { Integer.valueOf(n) }), null, 0, null);
/*     */         }
/*     */         
/* 235 */         arrayOfBoolean[n] = true;
/* 236 */         if (n > j) {
/* 237 */           j = n;
/*     */         }
/* 239 */         k++;
/*     */       }
/*     */     }
/*     */     
/* 243 */     if (0 < k)
/*     */     {
/*     */ 
/* 246 */       if (j >= k)
/*     */       {
/*     */ 
/*     */ 
/* 250 */         for (int m = 0; m < k; m++)
/*     */         {
/* 252 */           if (arrayOfBoolean[m] == 0)
/*     */             break;
/*     */         }
/* 255 */         localObject = new MessageFormat(SQLServerException.getErrString("R_TVPMissingSortOrdinal"));
/* 256 */         throw new SQLServerException(((MessageFormat)localObject).format(new Object[] { Integer.valueOf(m) }), null, 0, null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void parseTypeName(String paramString) throws SQLServerException
/*     */   {
/* 263 */     String str1 = "[\"";
/* 264 */     String str2 = "]\"";
/* 265 */     char c1 = '.';
/* 266 */     int i = 3;
/* 267 */     String[] arrayOfString = new String[i];
/* 268 */     int j = 0;
/*     */     
/* 270 */     if ((null == paramString) || (0 == paramString.length()))
/*     */     {
/* 272 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_invalidTVPName"));
/* 273 */       localObject2 = new Object[0];
/* 274 */       throw new SQLServerException(null, ((MessageFormat)localObject1).format(localObject2), null, 0, false);
/*     */     }
/*     */     
/* 277 */     Object localObject1 = new StringBuilder(paramString.length());
/*     */     
/*     */ 
/* 280 */     Object localObject2 = null;
/*     */     
/*     */ 
/* 283 */     char c2 = ' ';
/* 284 */     MPIState localMPIState = MPIState.MPI_Value;
/*     */     
/* 286 */     for (int k = 0; k < paramString.length(); k++)
/*     */     {
/* 288 */       char c3 = paramString.charAt(k);
/* 289 */       MessageFormat localMessageFormat2; switch (localMPIState)
/*     */       {
/*     */ 
/*     */       case MPI_Value: 
/* 293 */         if (!Character.isWhitespace(c3))
/*     */         {
/* 295 */           if (c3 == c1)
/*     */           {
/*     */ 
/* 298 */             arrayOfString[j] = "";
/* 299 */             j++;
/*     */           } else { int i1;
/* 301 */             if (-1 != (i1 = str1.indexOf(c3)))
/*     */             {
/*     */ 
/* 304 */               c2 = str2.charAt(i1);
/* 305 */               ((StringBuilder)localObject1).setLength(0);
/* 306 */               localMPIState = MPIState.MPI_ParseQuote;
/*     */             } else {
/* 308 */               if (-1 != str2.indexOf(c3))
/*     */               {
/*     */ 
/* 311 */                 localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 312 */                 throw new SQLServerException(null, localMessageFormat2.format(new Object[0]), null, 0, false);
/*     */               }
/*     */               
/*     */ 
/* 316 */               ((StringBuilder)localObject1).setLength(0);
/* 317 */               ((StringBuilder)localObject1).append(c3);
/* 318 */               localMPIState = MPIState.MPI_ParseNonQuote;
/*     */             } } }
/* 320 */         break;
/*     */       
/*     */       case MPI_ParseNonQuote: 
/* 323 */         if (c3 == c1)
/*     */         {
/* 325 */           arrayOfString[j] = ((StringBuilder)localObject1).toString();
/* 326 */           j = incrementStringCount(arrayOfString, j);
/* 327 */           localMPIState = MPIState.MPI_Value;
/*     */         }
/*     */         else {
/* 330 */           if ((-1 != str2.indexOf(c3)) || (-1 != str1.indexOf(c3)))
/*     */           {
/*     */ 
/* 333 */             localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 334 */             throw new SQLServerException(null, localMessageFormat2.format(new Object[0]), null, 0, false);
/*     */           }
/* 336 */           if (Character.isWhitespace(c3))
/*     */           {
/*     */ 
/* 339 */             arrayOfString[j] = ((StringBuilder)localObject1).toString();
/* 340 */             if (null == localObject2)
/* 341 */               localObject2 = new StringBuilder();
/* 342 */             ((StringBuilder)localObject2).setLength(0);
/*     */             
/* 344 */             ((StringBuilder)localObject2).append(c3);
/* 345 */             localMPIState = MPIState.MPI_LookForNextCharOrSeparator;
/*     */           }
/*     */           else {
/* 348 */             ((StringBuilder)localObject1).append(c3);
/*     */           } }
/* 350 */         break;
/*     */       
/*     */       case MPI_LookForNextCharOrSeparator: 
/* 353 */         if (!Character.isWhitespace(c3))
/*     */         {
/*     */ 
/* 356 */           if (c3 == c1)
/*     */           {
/* 358 */             j = incrementStringCount(arrayOfString, j);
/* 359 */             localMPIState = MPIState.MPI_Value;
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 364 */             ((StringBuilder)localObject1).append((CharSequence)localObject2);
/* 365 */             ((StringBuilder)localObject1).append(c3);
/* 366 */             arrayOfString[j] = ((StringBuilder)localObject1).toString();
/* 367 */             localMPIState = MPIState.MPI_ParseNonQuote;
/*     */           }
/*     */         }
/*     */         else
/* 371 */           ((StringBuilder)localObject2).append(c3);
/* 372 */         break;
/*     */       
/*     */ 
/*     */       case MPI_ParseQuote: 
/* 376 */         if (c3 == c2) {
/* 377 */           localMPIState = MPIState.MPI_RightQuote;
/*     */         } else
/* 379 */           ((StringBuilder)localObject1).append(c3);
/* 380 */         break;
/*     */       
/*     */       case MPI_RightQuote: 
/* 383 */         if (c3 == c2)
/*     */         {
/*     */ 
/* 386 */           ((StringBuilder)localObject1).append(c3);
/* 387 */           localMPIState = MPIState.MPI_ParseQuote;
/*     */         }
/* 389 */         else if (c3 == c1)
/*     */         {
/*     */ 
/* 392 */           arrayOfString[j] = ((StringBuilder)localObject1).toString();
/* 393 */           j = incrementStringCount(arrayOfString, j);
/* 394 */           localMPIState = MPIState.MPI_Value;
/*     */         } else {
/* 396 */           if (!Character.isWhitespace(c3))
/*     */           {
/*     */ 
/* 399 */             localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 400 */             throw new SQLServerException(null, localMessageFormat2.format(new Object[0]), null, 0, false);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 406 */           arrayOfString[j] = ((StringBuilder)localObject1).toString();
/* 407 */           localMPIState = MPIState.MPI_LookForSeparator;
/*     */         }
/* 409 */         break;
/*     */       
/*     */       case MPI_LookForSeparator: 
/* 412 */         if (!Character.isWhitespace(c3))
/*     */         {
/*     */ 
/* 415 */           if (c3 == c1)
/*     */           {
/*     */ 
/* 418 */             j = incrementStringCount(arrayOfString, j);
/* 419 */             localMPIState = MPIState.MPI_Value;
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 424 */             localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 425 */             throw new SQLServerException(null, localMessageFormat2.format(new Object[0]), null, 0, false);
/*     */           } }
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/*     */     MessageFormat localMessageFormat1;
/* 432 */     if (j > i - 1)
/*     */     {
/* 434 */       localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 435 */       throw new SQLServerException(null, localMessageFormat1.format(new Object[0]), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 439 */     switch (localMPIState)
/*     */     {
/*     */     case MPI_Value: 
/*     */     case MPI_LookForNextCharOrSeparator: 
/*     */     case MPI_LookForSeparator: 
/*     */       break;
/*     */     case MPI_ParseNonQuote: 
/*     */     case MPI_RightQuote: 
/* 447 */       arrayOfString[j] = ((StringBuilder)localObject1).toString();
/* 448 */       break;
/*     */     
/*     */     case MPI_ParseQuote: 
/*     */     default: 
/* 452 */       localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 453 */       throw new SQLServerException(null, localMessageFormat1.format(new Object[0]), null, 0, false);
/*     */     }
/*     */     
/* 456 */     if (arrayOfString[0] == null)
/*     */     {
/* 458 */       localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 459 */       throw new SQLServerException(null, localMessageFormat1.format(new Object[0]), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 464 */     int m = i - j - 1;
/* 465 */     if (m > 0) {
/* 466 */       for (int n = i - 1; n >= m; n--)
/*     */       {
/* 468 */         arrayOfString[n] = arrayOfString[(n - m)];
/* 469 */         arrayOfString[(n - m)] = null;
/*     */       }
/*     */     }
/*     */     
/* 473 */     this.TVPName = arrayOfString[2];
/* 474 */     this.TVP_owningSchema = arrayOfString[1];
/* 475 */     this.TVP_dbName = arrayOfString[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int incrementStringCount(String[] paramArrayOfString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 488 */     paramInt++;
/* 489 */     int i = paramArrayOfString.length;
/* 490 */     if (paramInt >= i)
/*     */     {
/* 492 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 493 */       throw new SQLServerException(null, localMessageFormat.format(new Object[0]), null, 0, false);
/*     */     }
/* 495 */     paramArrayOfString[paramInt] = new String();
/* 496 */     return paramInt;
/*     */   }
/*     */   
/*     */   String getTVPName()
/*     */   {
/* 501 */     return this.TVPName;
/*     */   }
/*     */   
/*     */   String getDbNameTVP()
/*     */   {
/* 506 */     return this.TVP_dbName;
/*     */   }
/*     */   
/*     */   String getOwningSchemaNameTVP()
/*     */   {
/* 511 */     return this.TVP_owningSchema;
/*     */   }
/*     */   
/*     */   int getTVPColumnCount()
/*     */   {
/* 516 */     return this.columnMetadata.size();
/*     */   }
/*     */   
/*     */   Map<Integer, SQLServerMetaData> getColumnMetadata()
/*     */   {
/* 521 */     return this.columnMetadata;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/TVP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */