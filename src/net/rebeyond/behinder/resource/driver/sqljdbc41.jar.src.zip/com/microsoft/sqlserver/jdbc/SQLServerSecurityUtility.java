/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerSecurityUtility
/*     */ {
/*     */   static byte[] getHMACWithSHA256(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
/*     */     throws NoSuchAlgorithmException, InvalidKeyException
/*     */   {
/*  27 */     byte[] arrayOfByte2 = new byte[paramInt];
/*  28 */     Mac localMac = Mac.getInstance("HmacSHA256");
/*  29 */     SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte2, "HmacSHA256");
/*  30 */     localMac.init(localSecretKeySpec);
/*  31 */     byte[] arrayOfByte1 = localMac.doFinal(paramArrayOfByte1);
/*     */     
/*  33 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);
/*  34 */     return arrayOfByte2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean compareBytes(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
/*     */   {
/*  46 */     if ((null == paramArrayOfByte1) || (null == paramArrayOfByte2)) {
/*  47 */       return false;
/*     */     }
/*     */     
/*  50 */     if (paramArrayOfByte2.length - paramInt1 < paramInt2) {
/*  51 */       return false;
/*     */     }
/*     */     
/*  54 */     for (int i = 0; (i < paramArrayOfByte1.length) && (i < paramInt2); i++) {
/*  55 */       if (paramArrayOfByte1[i] != paramArrayOfByte2[(paramInt1 + i)]) {
/*  56 */         return false;
/*     */       }
/*     */     }
/*  59 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] encryptWithKey(byte[] paramArrayOfByte, CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/*  69 */     String str = paramSQLServerConnection.getTrustedServerNameAE();
/*  70 */     assert (str != null) : "Server name should npt be null in EncryptWithKey";
/*     */     
/*     */ 
/*  73 */     if (!paramCryptoMetadata.IsAlgorithmInitialized()) {
/*  74 */       decryptSymmetricKey(paramCryptoMetadata, paramSQLServerConnection);
/*     */     }
/*     */     
/*  77 */     assert (paramCryptoMetadata.IsAlgorithmInitialized());
/*  78 */     byte[] arrayOfByte = paramCryptoMetadata.cipherAlgorithm.encryptData(paramArrayOfByte);
/*  79 */     if ((null == arrayOfByte) || (0 == arrayOfByte.length)) {
/*  80 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullCipherTextAE"), null, 0, false);
/*     */     }
/*  82 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String ValidateAndGetEncryptionAlgorithmName(byte paramByte, String paramString)
/*     */     throws SQLServerException
/*     */   {
/*  94 */     if (2 != paramByte) {
/*  95 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomCipherAlgorithmNotSupportedAE"), null, 0, false);
/*     */     }
/*  97 */     return "AEAD_AES_256_CBC_HMAC_SHA256";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void decryptSymmetricKey(CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/* 108 */     assert (null != paramCryptoMetadata) : "md should not be null in DecryptSymmetricKey.";
/* 109 */     assert (null != paramCryptoMetadata.cekTableEntry) : "md.EncryptionInfo should not be null in DecryptSymmetricKey.";
/* 110 */     assert (null != paramCryptoMetadata.cekTableEntry.columnEncryptionKeyValues) : "md.EncryptionInfo.ColumnEncryptionKeyValues should not be null in DecryptSymmetricKey.";
/*     */     
/* 112 */     SQLServerSymmetricKey localSQLServerSymmetricKey = null;
/* 113 */     Object localObject1 = null;
/* 114 */     SQLServerSymmetricKeyCache localSQLServerSymmetricKeyCache = SQLServerSymmetricKeyCache.getInstance();
/* 115 */     Iterator localIterator = paramCryptoMetadata.cekTableEntry.columnEncryptionKeyValues.iterator();
/* 116 */     Object localObject2 = null;
/* 117 */     while (localIterator.hasNext())
/*     */     {
/* 119 */       localObject3 = (EncryptionKeyInfo)localIterator.next();
/*     */       try {
/* 121 */         localSQLServerSymmetricKey = localSQLServerSymmetricKeyCache.getKey((EncryptionKeyInfo)localObject3, paramSQLServerConnection);
/* 122 */         if (null != localSQLServerSymmetricKey) {
/* 123 */           localObject1 = localObject3;
/* 124 */           break;
/*     */         }
/*     */       }
/*     */       catch (SQLServerException localSQLServerException)
/*     */       {
/* 129 */         localObject2 = localSQLServerException;
/*     */       }
/*     */     }
/*     */     
/* 133 */     if (null == localSQLServerSymmetricKey) {
/* 134 */       assert (null != localObject2) : "CEK decryption failed without raising exceptions";
/* 135 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/* 139 */     paramCryptoMetadata.cipherAlgorithm = null;
/* 140 */     Object localObject3 = null;
/* 141 */     String str = ValidateAndGetEncryptionAlgorithmName(paramCryptoMetadata.cipherAlgorithmId, paramCryptoMetadata.cipherAlgorithmName);
/* 142 */     localObject3 = SQLServerEncryptionAlgorithmFactoryList.getInstance().getAlgorithm(localSQLServerSymmetricKey, paramCryptoMetadata.encryptionType, str);
/* 143 */     assert (null != localObject3) : "Cipher algorithm cannot be null in DecryptSymmetricKey";
/* 144 */     paramCryptoMetadata.cipherAlgorithm = ((SQLServerEncryptionAlgorithm)localObject3);
/* 145 */     paramCryptoMetadata.encryptionKeyInfo = ((EncryptionKeyInfo)localObject1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] decryptWithKey(byte[] paramArrayOfByte, CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/* 154 */     String str = paramSQLServerConnection.getTrustedServerNameAE();
/* 155 */     assert (null != str) : "serverName should not be null in DecryptWithKey.";
/*     */     
/*     */ 
/* 158 */     if (!paramCryptoMetadata.IsAlgorithmInitialized()) {
/* 159 */       decryptSymmetricKey(paramCryptoMetadata, paramSQLServerConnection);
/*     */     }
/*     */     
/* 162 */     assert (paramCryptoMetadata.IsAlgorithmInitialized()) : "Decryption Algorithm is not initialized";
/* 163 */     byte[] arrayOfByte = paramCryptoMetadata.cipherAlgorithm.decryptData(paramArrayOfByte);
/* 164 */     if (null == arrayOfByte) {
/* 165 */       throw new SQLServerException(null, SQLServerException.getErrString("R_PlainTextNullAE"), null, 0, false);
/*     */     }
/*     */     
/* 168 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSecurityUtility.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */