/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FailoverMapSingleton
/*    */ {
/* 15 */   private static int INITIALHASHMAPSIZE = 5;
/* 16 */   private static HashMap<String, FailoverInfo> failoverMap = new HashMap(INITIALHASHMAPSIZE);
/*    */   
/*    */   private static String concatPrimaryDatabase(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 20 */     StringBuilder localStringBuilder = new StringBuilder();
/* 21 */     localStringBuilder.append(paramString1);
/* 22 */     if (null != paramString2)
/*    */     {
/* 24 */       localStringBuilder.append("\\");
/* 25 */       localStringBuilder.append(paramString2);
/*    */     }
/* 27 */     localStringBuilder.append(";");
/* 28 */     localStringBuilder.append(paramString3);
/* 29 */     return localStringBuilder.toString();
/*    */   }
/*    */   
/*    */   static FailoverInfo getFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3) {
/* 33 */     synchronized (FailoverMapSingleton.class)
/*    */     {
/* 35 */       if (true == failoverMap.isEmpty())
/*    */       {
/* 37 */         return null;
/*    */       }
/*    */       
/*    */ 
/* 41 */       String str = concatPrimaryDatabase(paramString1, paramString2, paramString3);
/* 42 */       if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINER))
/* 43 */         paramSQLServerConnection.getConnectionLogger().finer(paramSQLServerConnection.toString() + " Looking up info in the map using key: " + str);
/* 44 */       FailoverInfo localFailoverInfo = (FailoverInfo)failoverMap.get(str);
/* 45 */       if (null != localFailoverInfo)
/* 46 */         localFailoverInfo.log(paramSQLServerConnection);
/* 47 */       return localFailoverInfo;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static void putFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3, FailoverInfo paramFailoverInfo, boolean paramBoolean, String paramString4)
/*    */     throws SQLServerException
/*    */   {
/* 59 */     synchronized (FailoverMapSingleton.class)
/*    */     {
/*    */       FailoverInfo localFailoverInfo;
/* 62 */       if (null == (localFailoverInfo = getFailoverInfo(paramSQLServerConnection, paramString1, paramString2, paramString3)))
/*    */       {
/* 64 */         if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE)) {
/* 65 */           paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover map add server: " + paramString1 + "; database:" + paramString3 + "; Mirror:" + paramString4);
/*    */         }
/* 67 */         failoverMap.put(concatPrimaryDatabase(paramString1, paramString2, paramString3), paramFailoverInfo);
/*    */       }
/*    */       else
/*    */       {
/* 71 */         localFailoverInfo.failoverAdd(paramSQLServerConnection, paramBoolean, paramString4);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/FailoverMapSingleton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */