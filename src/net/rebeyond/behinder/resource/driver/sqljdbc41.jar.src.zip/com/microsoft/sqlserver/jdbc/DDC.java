/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.RoundingMode;
/*      */ import java.sql.Date;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DDC
/*      */ {
/*      */   static final Object convertIntegerToObject(int paramInt1, int paramInt2, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */   {
/*   33 */     switch (paramJDBCType)
/*      */     {
/*      */     case INTEGER: 
/*   36 */       return new Integer(paramInt1);
/*      */     case SMALLINT: 
/*      */     case TINYINT: 
/*   39 */       return new Short((short)paramInt1);
/*      */     case BIT: 
/*      */     case BOOLEAN: 
/*   42 */       return new Boolean(0 != paramInt1);
/*      */     case BIGINT: 
/*   44 */       return new Long(paramInt1);
/*      */     case DECIMAL: 
/*      */     case NUMERIC: 
/*      */     case MONEY: 
/*      */     case SMALLMONEY: 
/*   49 */       return new BigDecimal(Integer.toString(paramInt1));
/*      */     case FLOAT: 
/*      */     case DOUBLE: 
/*   52 */       return new Double(paramInt1);
/*      */     case REAL: 
/*   54 */       return new Float(paramInt1);
/*      */     case BINARY: 
/*   56 */       return convertIntToBytes(paramInt1, paramInt2);
/*      */     }
/*   58 */     return Integer.toString(paramInt1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertLongToObject(long paramLong, JDBCType paramJDBCType, SSType paramSSType, StreamType paramStreamType)
/*      */   {
/*   70 */     switch (paramJDBCType)
/*      */     {
/*      */     case BIGINT: 
/*   73 */       return new Long(paramLong);
/*      */     case INTEGER: 
/*   75 */       return new Integer((int)paramLong);
/*      */     case SMALLINT: 
/*      */     case TINYINT: 
/*   78 */       return new Short((short)(int)paramLong);
/*      */     case BIT: 
/*      */     case BOOLEAN: 
/*   81 */       return new Boolean(0L != paramLong);
/*      */     case DECIMAL: 
/*      */     case NUMERIC: 
/*      */     case MONEY: 
/*      */     case SMALLMONEY: 
/*   86 */       return new BigDecimal(Long.toString(paramLong));
/*      */     case FLOAT: 
/*      */     case DOUBLE: 
/*   89 */       return new Double(paramLong);
/*      */     case REAL: 
/*   91 */       return new Float((float)paramLong);
/*      */     case BINARY: 
/*   93 */       byte[] arrayOfByte1 = convertLongToBytes(paramLong);
/*   94 */       int i = 0;
/*      */       
/*      */       byte[] arrayOfByte2;
/*   97 */       switch (paramSSType) {
/*      */       case BIT: 
/*      */       case TINYINT: 
/*  100 */         i = 1;
/*  101 */         arrayOfByte2 = new byte[i];
/*  102 */         System.arraycopy(arrayOfByte1, arrayOfByte1.length - i, arrayOfByte2, 0, i);
/*  103 */         return arrayOfByte2;
/*      */       case SMALLINT: 
/*  105 */         i = 2;
/*  106 */         arrayOfByte2 = new byte[i];
/*  107 */         System.arraycopy(arrayOfByte1, arrayOfByte1.length - i, arrayOfByte2, 0, i);
/*  108 */         return arrayOfByte2;
/*      */       case INTEGER: 
/*  110 */         i = 4;
/*  111 */         arrayOfByte2 = new byte[i];
/*  112 */         System.arraycopy(arrayOfByte1, arrayOfByte1.length - i, arrayOfByte2, 0, i);
/*  113 */         return arrayOfByte2;
/*      */       case BIGINT: 
/*  115 */         i = 8;
/*  116 */         arrayOfByte2 = new byte[i];
/*  117 */         System.arraycopy(arrayOfByte1, arrayOfByte1.length - i, arrayOfByte2, 0, i);
/*  118 */         return arrayOfByte2;
/*      */       }
/*  120 */       return arrayOfByte1;
/*      */     
/*      */ 
/*      */     case VARBINARY: 
/*  124 */       switch (paramSSType)
/*      */       {
/*      */       case BIGINT: 
/*  127 */         return new Long(paramLong);
/*      */       case INTEGER: 
/*  129 */         return new Integer((int)paramLong);
/*      */       case TINYINT: 
/*      */       case SMALLINT: 
/*  132 */         return new Short((short)(int)paramLong);
/*      */       case BIT: 
/*  134 */         return new Boolean(0L != paramLong);
/*      */       case DECIMAL: 
/*      */       case NUMERIC: 
/*      */       case MONEY: 
/*      */       case SMALLMONEY: 
/*  139 */         return new BigDecimal(Long.toString(paramLong));
/*      */       case FLOAT: 
/*  141 */         return new Double(paramLong);
/*      */       case REAL: 
/*  143 */         return new Float((float)paramLong);
/*      */       case BINARY: 
/*  145 */         return convertLongToBytes(paramLong);
/*      */       }
/*  147 */       return Long.toString(paramLong);
/*      */     }
/*      */     
/*  150 */     return Long.toString(paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte[] convertIntToBytes(int paramInt1, int paramInt2)
/*      */   {
/*  162 */     byte[] arrayOfByte = new byte[paramInt2];
/*  163 */     for (int i = paramInt2; i-- > 0;)
/*      */     {
/*  165 */       arrayOfByte[i] = ((byte)(paramInt1 & 0xFF));
/*  166 */       paramInt1 >>= 8;
/*      */     }
/*  168 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertFloatToObject(float paramFloat, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */   {
/*  179 */     switch (paramJDBCType)
/*      */     {
/*      */     case REAL: 
/*  182 */       return new Float(paramFloat);
/*      */     case INTEGER: 
/*  184 */       return new Integer((int)paramFloat);
/*      */     case SMALLINT: 
/*      */     case TINYINT: 
/*  187 */       return new Short((short)(int)paramFloat);
/*      */     case BIT: 
/*      */     case BOOLEAN: 
/*  190 */       return new Boolean(0 != Float.compare(0.0F, paramFloat));
/*      */     case BIGINT: 
/*  192 */       return new Long(paramFloat);
/*      */     case DECIMAL: 
/*      */     case NUMERIC: 
/*      */     case MONEY: 
/*      */     case SMALLMONEY: 
/*  197 */       return new BigDecimal(Float.toString(paramFloat));
/*      */     case FLOAT: 
/*      */     case DOUBLE: 
/*  200 */       return new Double(new Float(paramFloat).doubleValue());
/*      */     case BINARY: 
/*  202 */       return convertIntToBytes(Float.floatToRawIntBits(paramFloat), 4);
/*      */     }
/*  204 */     return Float.toString(paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte[] convertLongToBytes(long paramLong)
/*      */   {
/*  215 */     byte[] arrayOfByte = new byte[8];
/*  216 */     for (int i = 8; i-- > 0;)
/*      */     {
/*  218 */       arrayOfByte[i] = ((byte)(int)(paramLong & 0xFF));
/*  219 */       paramLong >>= 8;
/*      */     }
/*  221 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertDoubleToObject(double paramDouble, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */   {
/*  232 */     switch (paramJDBCType)
/*      */     {
/*      */     case FLOAT: 
/*      */     case DOUBLE: 
/*  236 */       return new Double(paramDouble);
/*      */     case REAL: 
/*  238 */       return new Float(new Double(paramDouble).floatValue());
/*      */     case INTEGER: 
/*  240 */       return new Integer((int)paramDouble);
/*      */     case SMALLINT: 
/*      */     case TINYINT: 
/*  243 */       return new Short((short)(int)paramDouble);
/*      */     case BIT: 
/*      */     case BOOLEAN: 
/*  246 */       return new Boolean(0 != Double.compare(0.0D, paramDouble));
/*      */     case BIGINT: 
/*  248 */       return new Long(paramDouble);
/*      */     case DECIMAL: 
/*      */     case NUMERIC: 
/*      */     case MONEY: 
/*      */     case SMALLMONEY: 
/*  253 */       return new BigDecimal(Double.toString(paramDouble));
/*      */     case BINARY: 
/*  255 */       return convertLongToBytes(Double.doubleToRawLongBits(paramDouble));
/*      */     }
/*  257 */     return Double.toString(paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */   static final byte[] convertBigDecimalToBytes(BigDecimal paramBigDecimal, int paramInt)
/*      */   {
/*      */     byte[] arrayOfByte1;
/*      */     
/*  265 */     if (paramBigDecimal == null)
/*      */     {
/*  267 */       arrayOfByte1 = new byte[2];
/*  268 */       arrayOfByte1[0] = ((byte)paramInt);
/*  269 */       arrayOfByte1[1] = 0;
/*      */     }
/*      */     else
/*      */     {
/*  273 */       int i = paramBigDecimal.signum() < 0 ? 1 : 0;
/*      */       
/*      */ 
/*  276 */       if (paramBigDecimal.scale() < 0) {
/*  277 */         paramBigDecimal = paramBigDecimal.setScale(0);
/*      */       }
/*  279 */       BigInteger localBigInteger = paramBigDecimal.unscaledValue();
/*      */       
/*  281 */       if (i != 0) {
/*  282 */         localBigInteger = localBigInteger.negate();
/*      */       }
/*  284 */       byte[] arrayOfByte2 = localBigInteger.toByteArray();
/*      */       
/*  286 */       arrayOfByte1 = new byte[arrayOfByte2.length + 3];
/*  287 */       int j = 0;
/*  288 */       arrayOfByte1[(j++)] = ((byte)paramBigDecimal.scale());
/*  289 */       arrayOfByte1[(j++)] = ((byte)(arrayOfByte2.length + 1));
/*  290 */       arrayOfByte1[(j++)] = ((byte)(i != 0 ? 0 : 1));
/*  291 */       for (int k = arrayOfByte2.length - 1; k >= 0; k--) {
/*  292 */         arrayOfByte1[(j++)] = arrayOfByte2[k];
/*      */       }
/*      */     }
/*  295 */     return arrayOfByte1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertBigDecimalToObject(BigDecimal paramBigDecimal, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */   {
/*  306 */     switch (paramJDBCType)
/*      */     {
/*      */     case DECIMAL: 
/*      */     case NUMERIC: 
/*      */     case MONEY: 
/*      */     case SMALLMONEY: 
/*  312 */       return paramBigDecimal;
/*      */     case FLOAT: 
/*      */     case DOUBLE: 
/*  315 */       return new Double(paramBigDecimal.doubleValue());
/*      */     case REAL: 
/*  317 */       return new Float(paramBigDecimal.floatValue());
/*      */     case INTEGER: 
/*  319 */       return new Integer(paramBigDecimal.intValue());
/*      */     case SMALLINT: 
/*      */     case TINYINT: 
/*  322 */       return new Short(paramBigDecimal.shortValue());
/*      */     case BIT: 
/*      */     case BOOLEAN: 
/*  325 */       return new Boolean(0 != paramBigDecimal.compareTo(BigDecimal.valueOf(0L)));
/*      */     case BIGINT: 
/*  327 */       return new Long(paramBigDecimal.longValue());
/*      */     case BINARY: 
/*  329 */       return convertBigDecimalToBytes(paramBigDecimal, paramBigDecimal.scale());
/*      */     }
/*  331 */     return paramBigDecimal.toString();
/*      */   }
/*      */   
/*      */ 
/*      */   static final Object convertMoneyToObject(BigDecimal paramBigDecimal, JDBCType paramJDBCType, StreamType paramStreamType, int paramInt)
/*      */   {
/*  337 */     switch (paramJDBCType)
/*      */     {
/*      */     case DECIMAL: 
/*      */     case NUMERIC: 
/*      */     case MONEY: 
/*      */     case SMALLMONEY: 
/*  343 */       return paramBigDecimal;
/*      */     case FLOAT: 
/*      */     case DOUBLE: 
/*  346 */       return new Double(paramBigDecimal.doubleValue());
/*      */     case REAL: 
/*  348 */       return new Float(paramBigDecimal.floatValue());
/*      */     case INTEGER: 
/*  350 */       return new Integer(paramBigDecimal.intValue());
/*      */     case SMALLINT: 
/*      */     case TINYINT: 
/*  353 */       return new Short(paramBigDecimal.shortValue());
/*      */     case BIT: 
/*      */     case BOOLEAN: 
/*  356 */       return new Boolean(0 != paramBigDecimal.compareTo(BigDecimal.valueOf(0L)));
/*      */     case BIGINT: 
/*  358 */       return new Long(paramBigDecimal.longValue());
/*      */     case BINARY: 
/*  360 */       return convertToBytes(paramBigDecimal, paramBigDecimal.scale(), paramInt);
/*      */     }
/*  362 */     return paramBigDecimal.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static byte[] convertToBytes(BigDecimal paramBigDecimal, int paramInt1, int paramInt2)
/*      */   {
/*  369 */     int i = paramBigDecimal.signum() < 0 ? 1 : 0;
/*      */     
/*  371 */     paramBigDecimal = paramBigDecimal.setScale(paramInt1, RoundingMode.DOWN);
/*      */     
/*  373 */     BigInteger localBigInteger = paramBigDecimal.unscaledValue();
/*      */     
/*  375 */     byte[] arrayOfByte1 = localBigInteger.toByteArray();
/*      */     
/*  377 */     byte[] arrayOfByte2 = new byte[paramInt2];
/*  378 */     if (arrayOfByte1.length < paramInt2)
/*      */     {
/*  380 */       for (j = 0; j < paramInt2 - arrayOfByte1.length; j++)
/*      */       {
/*  382 */         arrayOfByte2[j] = ((byte)(i != 0 ? -1 : 0));
/*      */       }
/*      */     }
/*  385 */     int j = paramInt2 - arrayOfByte1.length;
/*  386 */     for (int k = j; k < paramInt2; k++)
/*      */     {
/*  388 */       arrayOfByte2[k] = arrayOfByte1[(k - j)];
/*      */     }
/*  390 */     return arrayOfByte2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertBytesToObject(byte[] paramArrayOfByte, JDBCType paramJDBCType, TypeInfo paramTypeInfo)
/*      */     throws SQLServerException
/*      */   {
/*  403 */     switch (paramJDBCType)
/*      */     {
/*      */     case CHAR: 
/*  406 */       String str = Util.bytesToHexString(paramArrayOfByte, paramArrayOfByte.length);
/*      */       
/*  408 */       if ((SSType.BINARY == paramTypeInfo.getSSType()) && (str.length() < paramTypeInfo.getPrecision() * 2))
/*      */       {
/*      */ 
/*  411 */         localObject = new StringBuffer(str);
/*      */         
/*  413 */         while (((StringBuffer)localObject).length() < paramTypeInfo.getPrecision() * 2) {
/*  414 */           ((StringBuffer)localObject).append('0');
/*      */         }
/*  416 */         return ((StringBuffer)localObject).toString();
/*      */       }
/*  418 */       return str;
/*      */     
/*      */     case BINARY: 
/*      */     case VARBINARY: 
/*      */     case LONGVARBINARY: 
/*  423 */       if ((SSType.BINARY == paramTypeInfo.getSSType()) && (paramArrayOfByte.length < paramTypeInfo.getPrecision()))
/*      */       {
/*      */ 
/*  426 */         localObject = new byte[paramTypeInfo.getPrecision()];
/*  427 */         System.arraycopy(paramArrayOfByte, 0, localObject, 0, paramArrayOfByte.length);
/*  428 */         return localObject;
/*      */       }
/*      */       
/*  431 */       return paramArrayOfByte;
/*      */     }
/*      */     
/*  434 */     Object localObject = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/*  435 */     throw new SQLServerException(((MessageFormat)localObject).format(new Object[] { paramTypeInfo.getSSType().name(), paramJDBCType }), null, 0, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertStringToObject(String paramString1, String paramString2, JDBCType paramJDBCType, StreamType paramStreamType)
/*      */     throws UnsupportedEncodingException, IllegalArgumentException
/*      */   {
/*  451 */     switch (paramJDBCType)
/*      */     {
/*      */ 
/*      */     case DECIMAL: 
/*      */     case NUMERIC: 
/*      */     case MONEY: 
/*      */     case SMALLMONEY: 
/*  458 */       return new BigDecimal(paramString1.trim());
/*      */     case FLOAT: 
/*      */     case DOUBLE: 
/*  461 */       return Double.valueOf(paramString1.trim());
/*      */     case REAL: 
/*  463 */       return Float.valueOf(paramString1.trim());
/*      */     case INTEGER: 
/*  465 */       return Integer.valueOf(paramString1.trim());
/*      */     case SMALLINT: 
/*      */     case TINYINT: 
/*  468 */       return Short.valueOf(paramString1.trim());
/*      */     case BIT: 
/*      */     case BOOLEAN: 
/*  471 */       String str = paramString1.trim();
/*  472 */       return 1 == str.length() ? Boolean.valueOf('1' == str.charAt(0)) : Boolean.valueOf(str);
/*      */     
/*      */ 
/*      */     case BIGINT: 
/*  476 */       return Long.valueOf(paramString1.trim());
/*      */     
/*      */ 
/*      */     case TIMESTAMP: 
/*  480 */       return Timestamp.valueOf(paramString1.trim());
/*      */     case DATE: 
/*  482 */       return Date.valueOf(getDatePart(paramString1.trim()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TIME: 
/*  493 */       Timestamp localTimestamp = Timestamp.valueOf("1970-01-01 " + getTimePart(paramString1.trim()));
/*  494 */       GregorianCalendar localGregorianCalendar = new GregorianCalendar(Locale.US);
/*  495 */       localGregorianCalendar.clear();
/*  496 */       localGregorianCalendar.setTimeInMillis(localTimestamp.getTime());
/*  497 */       if (localTimestamp.getNanos() % 1000000 >= 500000)
/*  498 */         localGregorianCalendar.add(14, 1);
/*  499 */       localGregorianCalendar.set(1970, 0, 1);
/*  500 */       return new Time(localGregorianCalendar.getTimeInMillis());
/*      */     
/*      */ 
/*      */     case BINARY: 
/*  504 */       return paramString1.getBytes(paramString2);
/*      */     }
/*      */     
/*      */     
/*  508 */     switch (paramStreamType)
/*      */     {
/*      */     case CHARACTER: 
/*  511 */       return new StringReader(paramString1);
/*      */     case ASCII: 
/*  513 */       return new ByteArrayInputStream(paramString1.getBytes("US-ASCII"));
/*      */     case BINARY: 
/*  515 */       return new ByteArrayInputStream(paramString1.getBytes());
/*      */     }
/*      */     
/*  518 */     return paramString1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertStreamToObject(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs)
/*      */     throws SQLServerException
/*      */   {
/*  531 */     if (null == paramBaseInputStream) {
/*  532 */       return null;
/*      */     }
/*  534 */     assert (null != paramTypeInfo);
/*  535 */     assert (null != paramInputStreamGetterArgs);
/*      */     
/*  537 */     SSType localSSType = paramTypeInfo.getSSType();
/*      */     
/*      */     try
/*      */     {
/*  541 */       switch (paramJDBCType)
/*      */       {
/*      */ 
/*      */       case CHAR: 
/*      */       case TIMESTAMP: 
/*      */       case DATE: 
/*      */       case TIME: 
/*      */       case VARCHAR: 
/*      */       case LONGVARCHAR: 
/*      */       case NCHAR: 
/*      */       case NVARCHAR: 
/*      */       case LONGNVARCHAR: 
/*      */       default: 
/*  554 */         if ((SSType.BINARY == localSSType) || (SSType.VARBINARY == localSSType) || (SSType.VARBINARYMAX == localSSType) || (SSType.TIMESTAMP == localSSType) || (SSType.IMAGE == localSSType) || (SSType.UDT == localSSType))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  561 */           if (StreamType.ASCII == paramInputStreamGetterArgs.streamType)
/*      */           {
/*  563 */             return paramBaseInputStream;
/*      */           }
/*      */           
/*      */ 
/*  567 */           assert ((StreamType.CHARACTER == paramInputStreamGetterArgs.streamType) || (StreamType.NONE == paramInputStreamGetterArgs.streamType));
/*      */           
/*      */ 
/*  570 */           byte[] arrayOfByte = paramBaseInputStream.getBytes();
/*  571 */           if (JDBCType.GUID == paramJDBCType)
/*      */           {
/*  573 */             return Util.readGUID(arrayOfByte);
/*      */           }
/*      */           
/*      */ 
/*  577 */           localObject = Util.bytesToHexString(arrayOfByte, arrayOfByte.length);
/*      */           
/*  579 */           if (StreamType.NONE == paramInputStreamGetterArgs.streamType) {
/*  580 */             return localObject;
/*      */           }
/*  582 */           return new StringReader((String)localObject);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  588 */         if (StreamType.ASCII == paramInputStreamGetterArgs.streamType)
/*      */         {
/*      */ 
/*  591 */           if (paramTypeInfo.supportsFastAsciiConversion()) {
/*  592 */             return new AsciiFilteredInputStream(paramBaseInputStream);
/*      */           }
/*      */           
/*  595 */           if (paramInputStreamGetterArgs.isAdaptive)
/*      */           {
/*  597 */             return AsciiFilteredUnicodeInputStream.MakeAsciiFilteredUnicodeInputStream(paramBaseInputStream, new BufferedReader(new InputStreamReader(paramBaseInputStream, paramTypeInfo.getCharset())));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  603 */           return new ByteArrayInputStream(new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()).getBytes("US-ASCII"));
/*      */         }
/*      */         
/*  606 */         if ((StreamType.CHARACTER == paramInputStreamGetterArgs.streamType) || (StreamType.NCHARACTER == paramInputStreamGetterArgs.streamType))
/*      */         {
/*      */ 
/*  609 */           if (paramInputStreamGetterArgs.isAdaptive) {
/*  610 */             return new BufferedReader(new InputStreamReader(paramBaseInputStream, paramTypeInfo.getCharset()));
/*      */           }
/*  612 */           return new StringReader(new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()));
/*      */         }
/*      */         
/*      */ 
/*  616 */         return convertStringToObject(new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getCharset(), paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */       
/*      */       case CLOB: 
/*  619 */         return new SQLServerClob(paramBaseInputStream, paramTypeInfo);
/*      */       
/*      */       case NCLOB: 
/*  622 */         return new SQLServerNClob(paramBaseInputStream, paramTypeInfo);
/*      */       case SQLXML: 
/*  624 */         return new SQLServerSQLXML(paramBaseInputStream, paramInputStreamGetterArgs, paramTypeInfo);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  633 */       if (StreamType.BINARY == paramInputStreamGetterArgs.streamType) {
/*  634 */         return paramBaseInputStream;
/*      */       }
/*  636 */       if (JDBCType.BLOB == paramJDBCType) {
/*  637 */         return new SQLServerBlob(paramBaseInputStream);
/*      */       }
/*  639 */       return paramBaseInputStream.getBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (IllegalArgumentException localIllegalArgumentException)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  652 */       localObject = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/*  653 */       throw new SQLServerException(((MessageFormat)localObject).format(new Object[] { paramTypeInfo.getSSType(), paramJDBCType }), null, 0, localIllegalArgumentException);
/*      */     }
/*      */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */     {
/*  657 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/*  658 */       throw new SQLServerException(((MessageFormat)localObject).format(new Object[] { paramTypeInfo.getSSType(), paramJDBCType }), null, 0, localUnsupportedEncodingException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String getDatePart(String paramString)
/*      */   {
/*  666 */     int i = paramString.indexOf(' ');
/*  667 */     if (-1 == i) return paramString;
/*  668 */     return paramString.substring(0, i);
/*      */   }
/*      */   
/*      */ 
/*      */   private static final String getTimePart(String paramString)
/*      */   {
/*  674 */     int i = paramString.indexOf(' ');
/*  675 */     if (-1 == i) return paramString;
/*  676 */     return paramString.substring(i + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static String fractionalSecondsString(long paramLong, int paramInt)
/*      */   {
/*  683 */     assert ((0L <= paramLong) && (paramLong < 1000000000L));
/*  684 */     assert ((0 <= paramInt) && (paramInt <= 7));
/*      */     
/*      */ 
/*      */ 
/*  688 */     if (0 == paramInt) {
/*  689 */       return "";
/*      */     }
/*  691 */     return BigDecimal.valueOf(paramLong % 1000000000L, 9).setScale(paramInt).toPlainString().substring(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final Object convertTemporalToObject(JDBCType paramJDBCType, SSType paramSSType, Calendar paramCalendar, int paramInt1, long paramLong, int paramInt2)
/*      */   {
/*  759 */     TimeZone localTimeZone1 = null != paramCalendar ? paramCalendar.getTimeZone() : TimeZone.getDefault();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  768 */     TimeZone localTimeZone2 = SSType.DATETIMEOFFSET == paramSSType ? UTC.timeZone : localTimeZone1;
/*      */     
/*  770 */     int i = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  775 */     Object localObject1 = new GregorianCalendar(localTimeZone2, Locale.US);
/*      */     
/*      */ 
/*      */ 
/*  779 */     ((GregorianCalendar)localObject1).setLenient(true);
/*      */     
/*      */ 
/*      */ 
/*  783 */     ((GregorianCalendar)localObject1).clear();
/*      */     
/*      */     Object localObject2;
/*      */     
/*  787 */     switch (paramSSType)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TIME: 
/*  801 */       ((GregorianCalendar)localObject1).set(1900, 0, 1, 0, 0, 0);
/*  802 */       ((GregorianCalendar)localObject1).set(14, (int)(paramLong / 1000000L));
/*      */       
/*  804 */       i = (int)(paramLong % 1000000000L);
/*  805 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case DATE: 
/*      */     case DATETIME2: 
/*      */     case DATETIMEOFFSET: 
/*  818 */       if (paramInt1 >= GregorianChange.DAYS_SINCE_BASE_DATE_HINT)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  825 */         ((GregorianCalendar)localObject1).set(1, 0, 1 + paramInt1 + GregorianChange.EXTRA_DAYS_TO_BE_ADDED, 0, 0, 0);
/*  826 */         ((GregorianCalendar)localObject1).set(14, (int)(paramLong / 1000000L));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  840 */         ((GregorianCalendar)localObject1).setGregorianChange(GregorianChange.PURE_CHANGE_DATE);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  846 */         ((GregorianCalendar)localObject1).set(1, 0, 1 + paramInt1, 0, 0, 0);
/*  847 */         ((GregorianCalendar)localObject1).set(14, (int)(paramLong / 1000000L));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  852 */         int j = ((GregorianCalendar)localObject1).get(1);
/*  853 */         int n = ((GregorianCalendar)localObject1).get(2);
/*  854 */         int i2 = ((GregorianCalendar)localObject1).get(5);
/*  855 */         int i3 = ((GregorianCalendar)localObject1).get(11);
/*  856 */         int i4 = ((GregorianCalendar)localObject1).get(12);
/*  857 */         int i5 = ((GregorianCalendar)localObject1).get(13);
/*  858 */         int i6 = ((GregorianCalendar)localObject1).get(14);
/*      */         
/*  860 */         ((GregorianCalendar)localObject1).setGregorianChange(GregorianChange.STANDARD_CHANGE_DATE);
/*  861 */         ((GregorianCalendar)localObject1).set(j, n, i2, i3, i4, i5);
/*  862 */         ((GregorianCalendar)localObject1).set(14, i6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  871 */       if ((SSType.DATETIMEOFFSET == paramSSType) && (!localTimeZone2.hasSameRules(localTimeZone1)))
/*      */       {
/*  873 */         localObject2 = new GregorianCalendar(localTimeZone1, Locale.US);
/*  874 */         ((GregorianCalendar)localObject2).clear();
/*  875 */         ((GregorianCalendar)localObject2).setTimeInMillis(((GregorianCalendar)localObject1).getTimeInMillis());
/*  876 */         localObject1 = localObject2;
/*      */       }
/*      */       
/*  879 */       i = (int)(paramLong % 1000000000L);
/*  880 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case DATETIME: 
/*  894 */       ((GregorianCalendar)localObject1).set(1900, 0, 1 + paramInt1, 0, 0, 0);
/*  895 */       ((GregorianCalendar)localObject1).set(14, (int)paramLong);
/*      */       
/*  897 */       i = (int)(paramLong * 1000000L % 1000000000L);
/*      */       
/*  899 */       break;
/*      */     
/*      */ 
/*      */     default: 
/*  903 */       throw new AssertionError("Unexpected SSType: " + paramSSType); }
/*      */     
/*      */     Timestamp localTimestamp2;
/*      */     int m;
/*  907 */     switch (paramJDBCType.category)
/*      */     {
/*      */ 
/*      */     case BINARY: 
/*  911 */       switch (paramSSType)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */       case DATE: 
/*  917 */         ((GregorianCalendar)localObject1).set(11, 0);
/*  918 */         ((GregorianCalendar)localObject1).set(12, 0);
/*  919 */         ((GregorianCalendar)localObject1).set(13, 0);
/*  920 */         ((GregorianCalendar)localObject1).set(14, 0);
/*  921 */         return new Date(((GregorianCalendar)localObject1).getTimeInMillis());
/*      */       
/*      */ 
/*      */ 
/*      */       case DATETIME2: 
/*      */       case DATETIME: 
/*  927 */         localObject2 = new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis());
/*  928 */         ((Timestamp)localObject2).setNanos(i);
/*  929 */         return localObject2;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case DATETIMEOFFSET: 
/*  936 */         assert (SSType.DATETIMEOFFSET == paramSSType);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  943 */         int k = paramCalendar.get(15);
/*  944 */         assert (0 == k % 60000);
/*      */         
/*  946 */         localTimestamp2 = new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis());
/*  947 */         localTimestamp2.setNanos(i);
/*  948 */         return DateTimeOffset.valueOf(localTimestamp2, k / 60000);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case TIME: 
/*  957 */         if (i % 1000000 >= 500000) {
/*  958 */           ((GregorianCalendar)localObject1).add(14, 1);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  964 */         ((GregorianCalendar)localObject1).set(1970, 0, 1);
/*      */         
/*  966 */         return new Time(((GregorianCalendar)localObject1).getTimeInMillis());
/*      */       }
/*      */       
/*      */       
/*  970 */       throw new AssertionError("Unexpected SSType: " + paramSSType);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case DATE: 
/*  978 */       ((GregorianCalendar)localObject1).set(11, 0);
/*  979 */       ((GregorianCalendar)localObject1).set(12, 0);
/*  980 */       ((GregorianCalendar)localObject1).set(13, 0);
/*  981 */       ((GregorianCalendar)localObject1).set(14, 0);
/*  982 */       return new Date(((GregorianCalendar)localObject1).getTimeInMillis());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TIME: 
/*  992 */       if (i % 1000000 >= 500000) {
/*  993 */         ((GregorianCalendar)localObject1).add(14, 1);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  999 */       ((GregorianCalendar)localObject1).set(1970, 0, 1);
/*      */       
/* 1001 */       return new Time(((GregorianCalendar)localObject1).getTimeInMillis());
/*      */     
/*      */ 
/*      */ 
/*      */     case TIMESTAMP: 
/* 1006 */       Timestamp localTimestamp1 = new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis());
/* 1007 */       localTimestamp1.setNanos(i);
/* 1008 */       return localTimestamp1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case DATETIMEOFFSET: 
/* 1015 */       assert (SSType.DATETIMEOFFSET == paramSSType);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1022 */       m = paramCalendar.get(15);
/* 1023 */       assert (0 == m % 60000);
/*      */       
/* 1025 */       localTimestamp2 = new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis());
/* 1026 */       localTimestamp2.setNanos(i);
/* 1027 */       return DateTimeOffset.valueOf(localTimestamp2, m / 60000);
/*      */     
/*      */ 
/*      */ 
/*      */     case CHARACTER: 
/* 1032 */       switch (paramSSType)
/*      */       {
/*      */ 
/*      */       case DATE: 
/* 1036 */         return String.format(Locale.US, "%1$tF", new Object[] { localObject1 });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case TIME: 
/* 1044 */         return String.format(Locale.US, "%1$tT%2$s", new Object[] { localObject1, fractionalSecondsString(i, paramInt2) });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case DATETIME2: 
/* 1055 */         return String.format(Locale.US, "%1$tF %1$tT%2$s", new Object[] { localObject1, fractionalSecondsString(i, paramInt2) });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case DATETIMEOFFSET: 
/* 1068 */         m = paramCalendar.get(15);
/* 1069 */         assert (0 == m % 60000);
/*      */         
/* 1071 */         int i1 = Math.abs(m / 60000);
/* 1072 */         return String.format(Locale.US, "%1$tF %1$tT%2$s %3$c%4$02d:%5$02d", new Object[] { localObject1, fractionalSecondsString(i, paramInt2), Character.valueOf(m >= 0 ? 43 : '-'), Integer.valueOf(i1 / 60), Integer.valueOf(i1 % 60) });
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case DATETIME: 
/* 1086 */         return new Timestamp(((GregorianCalendar)localObject1).getTimeInMillis()).toString();
/*      */       }
/*      */       
/*      */       
/* 1090 */       throw new AssertionError("Unexpected SSType: " + paramSSType);
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 1095 */     throw new AssertionError("Unexpected JDBCType: " + paramJDBCType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int daysSinceBaseDate(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 1109 */     assert (paramInt1 >= 1);
/* 1110 */     assert (paramInt3 >= 1);
/* 1111 */     assert (paramInt2 >= 1);
/*      */     
/* 1113 */     return paramInt2 - 1 + (paramInt1 - paramInt3) * 365 + leapDaysBeforeYear(paramInt1) - leapDaysBeforeYear(paramInt3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int leapDaysBeforeYear(int paramInt)
/*      */   {
/* 1126 */     assert (paramInt >= 1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1137 */     return (paramInt - 1) / 4 - (paramInt - 1) / 100 + (paramInt - 1) / 400;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1142 */   private static final BigInteger maxRPCDecimalValue = new BigInteger("99999999999999999999999999999999999999");
/*      */   
/*      */ 
/*      */ 
/*      */   static final boolean exceedsMaxRPCDecimalPrecisionOrScale(BigDecimal paramBigDecimal)
/*      */   {
/* 1148 */     if (null == paramBigDecimal) { return false;
/*      */     }
/*      */     
/* 1151 */     if (paramBigDecimal.scale() > 38) { return true;
/*      */     }
/*      */     
/*      */ 
/* 1155 */     BigInteger localBigInteger = paramBigDecimal.scale() < 0 ? paramBigDecimal.setScale(0).unscaledValue() : paramBigDecimal.unscaledValue();
/*      */     
/* 1157 */     if (paramBigDecimal.signum() < 0) localBigInteger = localBigInteger.negate();
/* 1158 */     return localBigInteger.compareTo(maxRPCDecimalValue) > 0;
/*      */   }
/*      */   
/*      */   static String convertReaderToString(Reader paramReader, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1164 */     assert ((-1 == paramInt) || (paramInt >= 0));
/*      */     
/*      */ 
/* 1167 */     if (null == paramReader) return null;
/* 1168 */     if (0 == paramInt) { return "";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1175 */       StringBuilder localStringBuilder = new StringBuilder(-1 != paramInt ? paramInt : 4000);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1180 */       localObject = new char[(-1 != paramInt) && (paramInt < 4000) ? paramInt : 'ྠ'];
/*      */       
/*      */ 
/*      */       int i;
/*      */       
/* 1185 */       while ((i = paramReader.read((char[])localObject, 0, localObject.length)) > 0)
/*      */       {
/*      */ 
/* 1188 */         if (i > localObject.length)
/*      */         {
/* 1190 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1191 */           Object[] arrayOfObject2 = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
/* 1192 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject2), "", true);
/*      */         }
/*      */         
/* 1195 */         localStringBuilder.append((char[])localObject, 0, i);
/*      */       }
/*      */       
/* 1198 */       return localStringBuilder.toString();
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1202 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1203 */       Object[] arrayOfObject1 = { localIOException.toString() };
/* 1204 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject).format(arrayOfObject1), "", true);
/*      */     }
/*      */     
/*      */ 
/* 1208 */     return null;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/DDC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */