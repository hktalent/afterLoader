/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ServerPortPlaceHolder
/*     */ {
/*     */   private final String serverName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int port;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String instanceName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean checkLink;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final SQLServerConnectionSecurityManager securityManager;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ServerPortPlaceHolder(String paramString1, int paramInt, String paramString2, boolean paramBoolean)
/*     */   {
/* 130 */     this.serverName = paramString1;
/* 131 */     this.port = paramInt;
/* 132 */     this.instanceName = paramString2;
/* 133 */     this.checkLink = paramBoolean;
/* 134 */     this.securityManager = new SQLServerConnectionSecurityManager(this.serverName, this.port);
/* 135 */     doSecurityCheck();
/*     */   }
/*     */   
/*     */ 
/* 139 */   int getPortNumber() { return this.port; }
/* 140 */   String getServerName() { return this.serverName; }
/* 141 */   String getInstanceName() { return this.instanceName; }
/*     */   
/*     */   void doSecurityCheck() {
/* 144 */     this.securityManager.checkConnect();
/* 145 */     if (this.checkLink) {
/* 146 */       this.securityManager.checkLink();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ServerPortPlaceHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */