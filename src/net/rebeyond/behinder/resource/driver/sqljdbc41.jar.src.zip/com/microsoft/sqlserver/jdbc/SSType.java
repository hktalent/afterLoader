/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */  enum SSType
/*     */ {
/* 112 */   UNKNOWN(Category.UNKNOWN, "unknown", JDBCType.UNKNOWN), 
/* 113 */   TINYINT(Category.NUMERIC, "tinyint", JDBCType.TINYINT), 
/* 114 */   BIT(Category.NUMERIC, "bit", JDBCType.BIT), 
/* 115 */   SMALLINT(Category.NUMERIC, "smallint", JDBCType.SMALLINT), 
/* 116 */   INTEGER(Category.NUMERIC, "int", JDBCType.INTEGER), 
/* 117 */   BIGINT(Category.NUMERIC, "bigint", JDBCType.BIGINT), 
/* 118 */   FLOAT(Category.NUMERIC, "float", JDBCType.DOUBLE), 
/* 119 */   REAL(Category.NUMERIC, "real", JDBCType.REAL), 
/* 120 */   SMALLDATETIME(Category.DATETIME, "smalldatetime", JDBCType.SMALLDATETIME), 
/* 121 */   DATETIME(Category.DATETIME, "datetime", JDBCType.DATETIME), 
/* 122 */   DATE(Category.DATE, "date", JDBCType.DATE), 
/* 123 */   TIME(Category.TIME, "time", JDBCType.TIME), 
/* 124 */   DATETIME2(Category.DATETIME2, "datetime2", JDBCType.TIMESTAMP), 
/* 125 */   DATETIMEOFFSET(Category.DATETIMEOFFSET, "datetimeoffset", JDBCType.DATETIMEOFFSET), 
/* 126 */   SMALLMONEY(Category.NUMERIC, "smallmoney", JDBCType.SMALLMONEY), 
/* 127 */   MONEY(Category.NUMERIC, "money", JDBCType.MONEY), 
/* 128 */   CHAR(Category.CHARACTER, "char", JDBCType.CHAR), 
/* 129 */   VARCHAR(Category.CHARACTER, "varchar", JDBCType.VARCHAR), 
/* 130 */   VARCHARMAX(Category.LONG_CHARACTER, "varchar", JDBCType.LONGVARCHAR), 
/* 131 */   TEXT(Category.LONG_CHARACTER, "text", JDBCType.LONGVARCHAR), 
/* 132 */   NCHAR(Category.NCHARACTER, "nchar", JDBCType.NCHAR), 
/* 133 */   NVARCHAR(Category.NCHARACTER, "nvarchar", JDBCType.NVARCHAR), 
/* 134 */   NVARCHARMAX(Category.LONG_NCHARACTER, "nvarchar", JDBCType.LONGNVARCHAR), 
/* 135 */   NTEXT(Category.LONG_NCHARACTER, "ntext", JDBCType.LONGNVARCHAR), 
/* 136 */   BINARY(Category.BINARY, "binary", JDBCType.BINARY), 
/* 137 */   VARBINARY(Category.BINARY, "varbinary", JDBCType.VARBINARY), 
/* 138 */   VARBINARYMAX(Category.LONG_BINARY, "varbinary", JDBCType.LONGVARBINARY), 
/* 139 */   IMAGE(Category.LONG_BINARY, "image", JDBCType.LONGVARBINARY), 
/* 140 */   DECIMAL(Category.NUMERIC, "decimal", JDBCType.DECIMAL), 
/* 141 */   NUMERIC(Category.NUMERIC, "numeric", JDBCType.NUMERIC), 
/* 142 */   GUID(Category.GUID, "uniqueidentifier", JDBCType.GUID), 
/* 143 */   SQL_VARIANT(Category.VARIANT, "sql_variant", JDBCType.VARCHAR), 
/* 144 */   UDT(Category.UDT, "udt", JDBCType.VARBINARY), 
/* 145 */   XML(Category.XML, "xml", JDBCType.LONGNVARCHAR), 
/* 146 */   TIMESTAMP(Category.TIMESTAMP, "timestamp", JDBCType.BINARY);
/*     */   
/*     */ 
/*     */   final Category category;
/*     */   private final String name;
/*     */   private final JDBCType jdbcType;
/* 152 */   static final BigDecimal MAX_VALUE_MONEY = new BigDecimal("922337203685477.5807");
/* 153 */   static final BigDecimal MIN_VALUE_MONEY = new BigDecimal("-922337203685477.5808");
/* 154 */   static final BigDecimal MAX_VALUE_SMALLMONEY = new BigDecimal("214748.3647");
/* 155 */   static final BigDecimal MIN_VALUE_SMALLMONEY = new BigDecimal("-214748.3648");
/*     */   
/*     */ 
/*     */   private SSType(Category paramCategory, String paramString, JDBCType paramJDBCType)
/*     */   {
/* 160 */     this.category = paramCategory;
/* 161 */     this.name = paramString;
/* 162 */     this.jdbcType = paramJDBCType;
/*     */   }
/*     */   
/* 165 */   public String toString() { return this.name; }
/* 166 */   final JDBCType getJDBCType() { return this.jdbcType; }
/*     */   
/*     */   static SSType of(String paramString) throws SQLServerException
/*     */   {
/* 170 */     for (SSType localSSType : ) {
/* 171 */       if (localSSType.name.equalsIgnoreCase(paramString))
/* 172 */         return localSSType;
/*     */     }
/* 174 */     ??? = new MessageFormat(SQLServerException.getErrString("R_unknownSSType"));
/* 175 */     Object[] arrayOfObject = { paramString };
/* 176 */     SQLServerException.makeFromDriverError(null, null, ((MessageFormat)???).format(arrayOfObject), null, true);
/* 177 */     return UNKNOWN;
/*     */   }
/*     */   
/*     */   static enum Category
/*     */   {
/* 182 */     BINARY, 
/* 183 */     CHARACTER, 
/* 184 */     DATE, 
/* 185 */     DATETIME, 
/* 186 */     DATETIME2, 
/* 187 */     DATETIMEOFFSET, 
/* 188 */     GUID, 
/* 189 */     LONG_BINARY, 
/* 190 */     LONG_CHARACTER, 
/* 191 */     LONG_NCHARACTER, 
/* 192 */     NCHARACTER, 
/* 193 */     NUMERIC, 
/* 194 */     UNKNOWN, 
/* 195 */     TIME, 
/* 196 */     TIMESTAMP, 
/* 197 */     UDT, 
/* 198 */     VARIANT, 
/* 199 */     XML;
/*     */     
/*     */     private Category() {}
/*     */   }
/*     */   
/* 204 */   static enum GetterConversion { NUMERIC(SSType.Category.NUMERIC, EnumSet.of(JDBCType.Category.NUMERIC, JDBCType.Category.CHARACTER, JDBCType.Category.BINARY)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 211 */     DATETIME(SSType.Category.DATETIME, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.BINARY)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 220 */     DATETIME2(SSType.Category.DATETIME2, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */     DATE(SSType.Category.DATE, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */     TIME(SSType.Category.TIME, EnumSet.of(JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */     DATETIMEOFFSET(SSType.Category.DATETIMEOFFSET, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */     CHARACTER(SSType.Category.CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BINARY, JDBCType.Category.GUID })), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */     LONG_CHARACTER(SSType.Category.LONG_CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BINARY, JDBCType.Category.CLOB })), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 275 */     NCHARACTER(SSType.Category.NCHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP })), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 288 */     LONG_NCHARACTER(SSType.Category.LONG_NCHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CLOB, JDBCType.Category.NCLOB })), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 303 */     BINARY(SSType.Category.BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.GUID)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 312 */     LONG_BINARY(SSType.Category.LONG_BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BLOB)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 321 */     TIMESTAMP(SSType.Category.TIMESTAMP, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 328 */     XML(SSType.Category.XML, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.LONG_CHARACTER, JDBCType.Category.CLOB, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB, JDBCType.Category.SQLXML })), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */     UDT(SSType.Category.UDT, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER)), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 349 */     GUID(SSType.Category.GUID, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.CHARACTER));
/*     */     
/*     */ 
/*     */ 
/*     */     private final SSType.Category from;
/*     */     
/*     */     private final EnumSet<JDBCType.Category> to;
/*     */     
/*     */     private static final EnumMap<SSType.Category, EnumSet<JDBCType.Category>> conversionMap;
/*     */     
/*     */ 
/*     */     private GetterConversion(SSType.Category paramCategory, EnumSet<JDBCType.Category> paramEnumSet)
/*     */     {
/* 362 */       this.from = paramCategory;
/* 363 */       this.to = paramEnumSet;
/*     */     }
/*     */     
/* 366 */     static { conversionMap = new EnumMap(SSType.Category.class);
/*     */       
/*     */ 
/*     */       Enum localEnum;
/*     */       
/* 371 */       for (localEnum : SSType.Category.values()) {
/* 372 */         conversionMap.put(localEnum, EnumSet.noneOf(JDBCType.Category.class));
/*     */       }
/* 374 */       for (localEnum : values()) {
/* 375 */         ((EnumSet)conversionMap.get(localEnum.from)).addAll(localEnum.to);
/*     */       }
/*     */     }
/*     */     
/*     */     static final boolean converts(SSType paramSSType, JDBCType paramJDBCType) {
/* 380 */       return ((EnumSet)conversionMap.get(paramSSType.category)).contains(paramJDBCType.category);
/*     */     }
/*     */   }
/*     */   
/*     */   boolean convertsTo(JDBCType paramJDBCType)
/*     */   {
/* 386 */     return GetterConversion.converts(this, paramJDBCType);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SSType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */