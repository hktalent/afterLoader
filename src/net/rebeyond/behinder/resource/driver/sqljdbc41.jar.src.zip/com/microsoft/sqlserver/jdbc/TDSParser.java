/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TDSParser
/*     */ {
/*  25 */   private static Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.TOKEN");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void parse(TDSReader paramTDSReader, String paramString)
/*     */     throws SQLServerException
/*     */   {
/*  36 */     parse(paramTDSReader, new TDSTokenHandler(paramString));
/*     */   }
/*     */   
/*     */   static void parse(TDSReader paramTDSReader, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException
/*     */   {
/*  41 */     boolean bool1 = logger.isLoggable(Level.FINEST);
/*     */     
/*     */ 
/*  44 */     boolean bool2 = true;
/*     */     
/*     */ 
/*  47 */     int i = 0;
/*  48 */     boolean bool3 = false;
/*  49 */     while (bool2)
/*     */     {
/*  51 */       int j = paramTDSReader.peekTokenType();
/*  52 */       if (bool1)
/*     */       {
/*  54 */         logger.finest(paramTDSReader.toString() + ": " + paramTDSTokenHandler.logContext + ": Processing " + (-1 == j ? "EOF" : TDS.getTokenName(j)));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  60 */       switch (j) {
/*     */       case 237: 
/*  62 */         bool2 = paramTDSTokenHandler.onSSPI(paramTDSReader); break;
/*     */       case 173: 
/*  64 */         i = 1;
/*  65 */         bool2 = paramTDSTokenHandler.onLoginAck(paramTDSReader);
/*  66 */         break;
/*     */       case 174: 
/*  68 */         bool3 = true;
/*  69 */         paramTDSReader.getConnection().processFeatureExtAck(paramTDSReader);
/*  70 */         bool2 = true;
/*  71 */         break;
/*  72 */       case 227:  bool2 = paramTDSTokenHandler.onEnvChange(paramTDSReader); break;
/*  73 */       case 121:  bool2 = paramTDSTokenHandler.onRetStatus(paramTDSReader); break;
/*  74 */       case 172:  bool2 = paramTDSTokenHandler.onRetValue(paramTDSReader); break;
/*     */       case 253: 
/*     */       case 254: 
/*     */       case 255: 
/*  78 */         paramTDSReader.getCommand().checkForInterrupt();
/*  79 */         bool2 = paramTDSTokenHandler.onDone(paramTDSReader);
/*  80 */         break;
/*     */       
/*     */       case 170: 
/*  83 */         bool2 = paramTDSTokenHandler.onError(paramTDSReader);
/*  84 */         break;
/*  85 */       case 171:  bool2 = paramTDSTokenHandler.onInfo(paramTDSReader); break;
/*  86 */       case 169:  bool2 = paramTDSTokenHandler.onOrder(paramTDSReader); break;
/*  87 */       case 129:  bool2 = paramTDSTokenHandler.onColMetaData(paramTDSReader); break;
/*  88 */       case 209:  bool2 = paramTDSTokenHandler.onRow(paramTDSReader); break;
/*  89 */       case 210:  bool2 = paramTDSTokenHandler.onNBCRow(paramTDSReader); break;
/*  90 */       case 165:  bool2 = paramTDSTokenHandler.onColInfo(paramTDSReader); break;
/*  91 */       case 164:  bool2 = paramTDSTokenHandler.onTabName(paramTDSReader); break;
/*     */       
/*     */       case 238: 
/*  94 */         bool2 = paramTDSTokenHandler.onFedAuthInfo(paramTDSReader);
/*  95 */         break;
/*     */       
/*     */       case -1: 
/*  98 */         paramTDSReader.getCommand().onTokenEOF();
/*  99 */         paramTDSTokenHandler.onEOF(paramTDSReader);
/* 100 */         bool2 = false;
/* 101 */         break;
/*     */       
/*     */       default: 
/* 104 */         throwUnexpectedTokenException(paramTDSReader, paramTDSTokenHandler.logContext);
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/* 110 */     if ((i != 0) && (!bool3)) {
/* 111 */       paramTDSReader.TryProcessFeatureExtAck(bool3);
/*     */     }
/*     */   }
/*     */   
/*     */   static void throwUnexpectedTokenException(TDSReader paramTDSReader, String paramString) throws SQLServerException
/*     */   {
/* 117 */     if (logger.isLoggable(Level.SEVERE))
/* 118 */       logger.severe(paramTDSReader.toString() + ": " + paramString + ": Encountered unexpected " + TDS.getTokenName(paramTDSReader.peekTokenType()));
/* 119 */     paramTDSReader.throwInvalidTDSToken(TDS.getTokenName(paramTDSReader.peekTokenType()));
/*     */   }
/*     */   
/*     */   static void ignoreLengthPrefixedToken(TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 125 */     paramTDSReader.readUnsignedByte();
/* 126 */     int i = paramTDSReader.readUnsignedShort();
/* 127 */     byte[] arrayOfByte = new byte[i];
/* 128 */     paramTDSReader.readBytes(arrayOfByte, 0, i);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/TDSParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */