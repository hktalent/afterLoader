package com.microsoft.sqlserver.jdbc;

import java.sql.CallableStatement;
import java.sql.SQLException;
import microsoft.sql.DateTimeOffset;

public abstract interface ISQLServerCallableStatement
  extends CallableStatement, ISQLServerPreparedStatement
{
  public abstract void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset)
    throws SQLException;
  
  public abstract DateTimeOffset getDateTimeOffset(int paramInt)
    throws SQLException;
  
  public abstract DateTimeOffset getDateTimeOffset(String paramString)
    throws SQLException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ISQLServerCallableStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */