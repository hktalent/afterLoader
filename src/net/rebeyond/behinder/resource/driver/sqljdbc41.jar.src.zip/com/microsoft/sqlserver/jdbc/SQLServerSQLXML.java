/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ final class SQLServerSQLXML implements java.sql.SQLXML
/*     */ {
/*     */   private final SQLServerConnection con;
/*     */   private final PLPXMLInputStream contents;
/*     */   private final InputStreamGetterArgs getterArgs;
/*     */   private final TypeInfo typeInfo;
/*  35 */   private boolean isUsed = false;
/*  36 */   private boolean isFreed = false;
/*     */   
/*  38 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerSQLXML");
/*     */   
/*     */ 
/*     */   private ByteArrayOutputStreamToInputStream outputStreamValue;
/*     */   
/*     */ 
/*     */   private org.w3c.dom.Document docValue;
/*     */   
/*     */   private String strValue;
/*     */   
/*  48 */   private static int baseID = 0;
/*     */   private final String traceID;
/*     */   
/*     */   public final String toString() {
/*  52 */     return this.traceID;
/*     */   }
/*     */   
/*     */   private static synchronized int nextInstanceID()
/*     */   {
/*  57 */     baseID += 1;
/*  58 */     return baseID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   InputStream getValue()
/*     */     throws SQLServerException
/*     */   {
/*  66 */     checkClosed();
/*     */     
/*     */ 
/*  69 */     if (!this.isUsed)
/*  70 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_noDataXML"), null, true);
/*  71 */     assert (null == this.contents);
/*  72 */     java.io.ByteArrayInputStream localByteArrayInputStream = null;
/*  73 */     if (null != this.outputStreamValue)
/*     */     {
/*  75 */       localByteArrayInputStream = this.outputStreamValue.getInputStream();
/*  76 */       assert (null == this.docValue);
/*  77 */       if ((!$assertionsDisabled) && (null != this.strValue)) { throw new AssertionError();
/*     */       }
/*     */     }
/*  80 */     else if (null != this.docValue)
/*     */     {
/*  82 */       assert (null == this.outputStreamValue);
/*  83 */       assert (null == this.strValue);
/*  84 */       ByteArrayOutputStreamToInputStream localByteArrayOutputStreamToInputStream = new ByteArrayOutputStreamToInputStream();
/*     */       
/*     */ 
/*  87 */       Object localObject = null;
/*     */       try
/*     */       {
/*  90 */         TransformerFactory localTransformerFactory = TransformerFactory.newInstance();
/*  91 */         localTransformerFactory.newTransformer().transform(new DOMSource(this.docValue), new StreamResult(localByteArrayOutputStreamToInputStream));
/*     */       }
/*     */       catch (TransformerException localTransformerException)
/*     */       {
/*  95 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/*  96 */         Object[] arrayOfObject = { localTransformerException.toString() };
/*  97 */         SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */       }
/*  99 */       localByteArrayInputStream = localByteArrayOutputStreamToInputStream.getInputStream();
/*     */     }
/*     */     else
/*     */     {
/* 103 */       assert (null == this.outputStreamValue);
/* 104 */       assert (null == this.docValue);
/* 105 */       assert (null != this.strValue);
/*     */       try
/*     */       {
/* 108 */         localByteArrayInputStream = new java.io.ByteArrayInputStream(this.strValue.getBytes(Encoding.UNICODE.charsetName()));
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */       {
/* 112 */         throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*     */       }
/*     */     }
/* 115 */     assert (null != localByteArrayInputStream);
/* 116 */     this.isFreed = true;
/* 117 */     return localByteArrayInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */   SQLServerSQLXML(SQLServerConnection paramSQLServerConnection)
/*     */   {
/* 123 */     this.contents = null;
/* 124 */     this.traceID = (" SQLServerSQLXML:" + nextInstanceID());
/* 125 */     this.con = paramSQLServerConnection;
/*     */     
/* 127 */     if (logger.isLoggable(java.util.logging.Level.FINE))
/* 128 */       logger.fine(toString() + " created by (" + paramSQLServerConnection.toString() + ")");
/* 129 */     this.getterArgs = null;
/* 130 */     this.typeInfo = null;
/*     */   }
/*     */   
/*     */   SQLServerSQLXML(InputStream paramInputStream, InputStreamGetterArgs paramInputStreamGetterArgs, TypeInfo paramTypeInfo) throws SQLServerException
/*     */   {
/* 135 */     this.traceID = (" SQLServerSQLXML:" + nextInstanceID());
/* 136 */     this.contents = ((PLPXMLInputStream)paramInputStream);
/* 137 */     this.con = null;
/* 138 */     this.getterArgs = paramInputStreamGetterArgs;
/* 139 */     this.typeInfo = paramTypeInfo;
/* 140 */     if (logger.isLoggable(java.util.logging.Level.FINE))
/* 141 */       logger.fine(toString() + " created by (null connection)");
/*     */   }
/*     */   
/*     */   InputStream getStream() {
/* 145 */     return this.contents;
/*     */   }
/*     */   
/*     */   public void free() throws SQLException {
/* 149 */     if (!this.isFreed)
/*     */     {
/* 151 */       this.isFreed = true;
/* 152 */       if (null != this.contents)
/*     */       {
/*     */         try
/*     */         {
/* 156 */           this.contents.close();
/*     */         }
/*     */         catch (IOException localIOException)
/*     */         {
/* 160 */           SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/* 167 */     if ((this.isFreed) || ((null != this.con) && (this.con.isClosed())))
/*     */     {
/* 169 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 170 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(new Object[] { "SQLXML" }), null, true);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkReadXML() throws SQLException {
/* 175 */     if (null == this.contents)
/* 176 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_writeOnlyXML"), null, true);
/* 177 */     if (this.isUsed) {
/* 178 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenReadXML"), null, true);
/*     */     }
/*     */     try {
/* 181 */       this.contents.checkClosed();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 185 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 186 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(new Object[] { "SQLXML" }), null, true);
/*     */     }
/*     */   }
/*     */   
/*     */   void checkWriteXML() throws SQLException {
/* 191 */     if (null != this.contents)
/* 192 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_readOnlyXML"), null, true);
/* 193 */     if (this.isUsed) {
/* 194 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenSetXML"), null, true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getBinaryStream()
/*     */     throws SQLException
/*     */   {
/* 205 */     checkClosed();
/* 206 */     checkReadXML();
/* 207 */     this.isUsed = true;
/* 208 */     return this.contents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public java.io.OutputStream setBinaryStream()
/*     */     throws SQLException
/*     */   {
/* 220 */     checkClosed();
/* 221 */     checkWriteXML();
/* 222 */     this.isUsed = true;
/* 223 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 224 */     return this.outputStreamValue;
/*     */   }
/*     */   
/*     */   public java.io.Writer setCharacterStream() throws SQLException {
/* 228 */     checkClosed();
/* 229 */     checkWriteXML();
/* 230 */     this.isUsed = true;
/* 231 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 232 */     java.io.OutputStreamWriter localOutputStreamWriter = null;
/*     */     try
/*     */     {
/* 235 */       localOutputStreamWriter = new java.io.OutputStreamWriter(this.outputStreamValue, Encoding.UNICODE.charsetName());
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */     {
/* 239 */       throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*     */     }
/* 241 */     return localOutputStreamWriter;
/*     */   }
/*     */   
/*     */   public Reader getCharacterStream() throws SQLException {
/* 245 */     checkClosed();
/* 246 */     checkReadXML();
/* 247 */     this.isUsed = true;
/* 248 */     StreamType localStreamType = StreamType.CHARACTER;
/* 249 */     InputStreamGetterArgs localInputStreamGetterArgs = new InputStreamGetterArgs(localStreamType, this.getterArgs.isAdaptive, this.getterArgs.isStreaming, this.getterArgs.logContext);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 255 */     assert (null != this.contents);
/*     */     
/*     */     try
/*     */     {
/* 259 */       this.contents.read();
/* 260 */       this.contents.read();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 264 */       SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */     }
/*     */     
/* 267 */     Reader localReader = (Reader)DDC.convertStreamToObject(this.contents, this.typeInfo, localStreamType.getJDBCType(), localInputStreamGetterArgs);
/* 268 */     return localReader;
/*     */   }
/*     */   
/*     */   public String getString() throws SQLException
/*     */   {
/* 273 */     checkClosed();
/* 274 */     checkReadXML();
/* 275 */     this.isUsed = true;
/* 276 */     assert (null != this.contents);
/*     */     
/*     */     try
/*     */     {
/* 280 */       this.contents.read();
/* 281 */       this.contents.read();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 285 */       SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */     }
/*     */     
/* 288 */     byte[] arrayOfByte = this.contents.getBytes();
/* 289 */     String str = null;
/*     */     try
/*     */     {
/* 292 */       str = new String(arrayOfByte, 0, arrayOfByte.length, Encoding.UNICODE.charsetName());
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */     {
/* 296 */       throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*     */     }
/* 298 */     return str;
/*     */   }
/*     */   
/*     */   public void setString(String paramString) throws SQLException {
/* 302 */     checkClosed();
/* 303 */     checkWriteXML();
/* 304 */     this.isUsed = true;
/* 305 */     if (null == paramString)
/* 306 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/* 307 */     this.strValue = paramString;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends Source> T getSource(Class<T> paramClass)
/*     */     throws SQLException
/*     */   {
/* 314 */     checkClosed();
/* 315 */     checkReadXML();
/* 316 */     if (null == paramClass)
/*     */     {
/*     */ 
/*     */ 
/* 320 */       Source localSource = getSourceInternal(javax.xml.transform.stream.StreamSource.class);
/* 321 */       return localSource;
/*     */     }
/*     */     
/* 324 */     return getSourceInternal(paramClass);
/*     */   }
/*     */   
/*     */   <T extends Source> T getSourceInternal(Class<T> paramClass) throws SQLException {
/* 328 */     this.isUsed = true;
/* 329 */     Source localSource = null;
/* 330 */     if (DOMSource.class == paramClass)
/*     */     {
/* 332 */       localSource = (Source)paramClass.cast(getDOMSource());
/*     */     }
/* 334 */     else if (SAXSource.class == paramClass)
/*     */     {
/* 336 */       localSource = (Source)paramClass.cast(getSAXSource());
/*     */ 
/*     */     }
/* 339 */     else if (StAXSource.class == paramClass)
/*     */     {
/* 341 */       localSource = (Source)paramClass.cast(getStAXSource());
/*     */ 
/*     */     }
/* 344 */     else if (javax.xml.transform.stream.StreamSource.class == paramClass)
/*     */     {
/* 346 */       localSource = (Source)paramClass.cast(new javax.xml.transform.stream.StreamSource(this.contents));
/*     */     }
/*     */     else
/*     */     {
/* 350 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true); }
/* 351 */     return localSource;
/*     */   }
/*     */   
/*     */   public <T extends Result> T setResult(Class<T> paramClass) throws SQLException {
/* 355 */     checkClosed();
/* 356 */     checkWriteXML();
/* 357 */     if (null == paramClass)
/*     */     {
/*     */ 
/*     */ 
/* 361 */       Result localResult = setResultInternal(StreamResult.class);
/* 362 */       return localResult;
/*     */     }
/*     */     
/* 365 */     return setResultInternal(paramClass);
/*     */   }
/*     */   
/*     */   <T extends Result> T setResultInternal(Class<T> paramClass)
/*     */     throws SQLException
/*     */   {
/* 371 */     this.isUsed = true;
/* 372 */     Result localResult = null;
/* 373 */     if (DOMResult.class == paramClass)
/*     */     {
/* 375 */       localResult = (Result)paramClass.cast(getDOMResult());
/*     */ 
/*     */     }
/* 378 */     else if (SAXResult.class == paramClass)
/*     */     {
/* 380 */       localResult = (Result)paramClass.cast(getSAXResult());
/*     */ 
/*     */     }
/* 383 */     else if (javax.xml.transform.stax.StAXResult.class == paramClass)
/*     */     {
/* 385 */       localResult = (Result)paramClass.cast(getStAXResult());
/*     */     }
/* 387 */     else if (StreamResult.class == paramClass)
/*     */     {
/* 389 */       this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 390 */       localResult = (Result)paramClass.cast(new StreamResult(this.outputStreamValue));
/*     */     }
/*     */     else {
/* 393 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true); }
/* 394 */     return localResult;
/*     */   }
/*     */   
/*     */   private final DOMSource getDOMSource() throws SQLException
/*     */   {
/* 399 */     org.w3c.dom.Document localDocument = null;
/* 400 */     DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 410 */       localDocumentBuilderFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 411 */       DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
/*     */       
/*     */ 
/* 414 */       localDocumentBuilder.setEntityResolver(new SQLServerEntityResolver());
/*     */       try
/*     */       {
/* 417 */         localDocument = localDocumentBuilder.parse(this.contents);
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/* 421 */         localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 422 */         arrayOfObject = new Object[] { localIOException.toString() };
/* 423 */         SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), "", true);
/*     */       }
/* 425 */       return new DOMSource(localDocument);
/*     */ 
/*     */     }
/*     */     catch (ParserConfigurationException localParserConfigurationException)
/*     */     {
/* 430 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 431 */       arrayOfObject = new Object[] { localParserConfigurationException.toString() };
/* 432 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     catch (SAXException localSAXException)
/*     */     {
/* 436 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 437 */       Object[] arrayOfObject = { localSAXException.toString() };
/* 438 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 440 */     return null;
/*     */   }
/*     */   
/*     */   private final SAXSource getSAXSource() throws SQLException
/*     */   {
/*     */     try {
/* 446 */       org.xml.sax.InputSource localInputSource = new org.xml.sax.InputSource(this.contents);
/* 447 */       localObject1 = org.xml.sax.helpers.XMLReaderFactory.createXMLReader();
/* 448 */       return new SAXSource((org.xml.sax.XMLReader)localObject1, localInputSource);
/*     */ 
/*     */     }
/*     */     catch (SAXException localSAXException)
/*     */     {
/*     */ 
/* 454 */       Object localObject1 = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 455 */       Object localObject2 = { localSAXException.toString() };
/* 456 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject1).format(localObject2), null, true);
/*     */     }
/* 458 */     return null;
/*     */   }
/*     */   
/*     */   private final StAXSource getStAXSource() throws SQLException {
/* 462 */     XMLInputFactory localXMLInputFactory = XMLInputFactory.newInstance();
/*     */     try
/*     */     {
/* 465 */       javax.xml.stream.XMLStreamReader localXMLStreamReader = localXMLInputFactory.createXMLStreamReader(this.contents);
/* 466 */       return new StAXSource(localXMLStreamReader);
/*     */ 
/*     */     }
/*     */     catch (XMLStreamException localXMLStreamException)
/*     */     {
/* 471 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 472 */       Object[] arrayOfObject = { localXMLStreamException.toString() };
/* 473 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/* 475 */     return null;
/*     */   }
/*     */   
/*     */   private final javax.xml.transform.stax.StAXResult getStAXResult() throws SQLException
/*     */   {
/* 480 */     XMLOutputFactory localXMLOutputFactory = XMLOutputFactory.newInstance();
/* 481 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/*     */     try
/*     */     {
/* 484 */       javax.xml.stream.XMLStreamWriter localXMLStreamWriter = localXMLOutputFactory.createXMLStreamWriter(this.outputStreamValue);
/* 485 */       return new javax.xml.transform.stax.StAXResult(localXMLStreamWriter);
/*     */ 
/*     */     }
/*     */     catch (XMLStreamException localXMLStreamException)
/*     */     {
/* 490 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 491 */       Object[] arrayOfObject = { localXMLStreamException.toString() };
/* 492 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/* 494 */     return null;
/*     */   }
/*     */   
/*     */   private final SAXResult getSAXResult() throws SQLException {
/* 498 */     javax.xml.transform.sax.TransformerHandler localTransformerHandler = null;
/*     */     try
/*     */     {
/* 501 */       SAXTransformerFactory localSAXTransformerFactory = (SAXTransformerFactory)TransformerFactory.newInstance();
/*     */       
/* 503 */       localTransformerHandler = localSAXTransformerFactory.newTransformerHandler();
/*     */     }
/*     */     catch (javax.xml.transform.TransformerConfigurationException localTransformerConfigurationException)
/*     */     {
/* 507 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 508 */       arrayOfObject = new Object[] { localTransformerConfigurationException.toString() };
/* 509 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     catch (ClassCastException localClassCastException)
/*     */     {
/* 513 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 514 */       Object[] arrayOfObject = { localClassCastException.toString() };
/* 515 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 517 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 518 */     localTransformerHandler.setResult(new StreamResult(this.outputStreamValue));
/* 519 */     SAXResult localSAXResult = new SAXResult(localTransformerHandler);
/* 520 */     return localSAXResult;
/*     */   }
/*     */   
/*     */   private final DOMResult getDOMResult() throws SQLException {
/* 524 */     DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
/*     */     
/* 526 */     assert (null == this.outputStreamValue);
/*     */     try
/*     */     {
/* 529 */       DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
/* 530 */       this.docValue = localDocumentBuilder.newDocument();
/* 531 */       return new DOMResult(this.docValue);
/*     */ 
/*     */     }
/*     */     catch (ParserConfigurationException localParserConfigurationException)
/*     */     {
/* 536 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 537 */       Object[] arrayOfObject = { localParserConfigurationException.toString() };
/* 538 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 540 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSQLXML.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */