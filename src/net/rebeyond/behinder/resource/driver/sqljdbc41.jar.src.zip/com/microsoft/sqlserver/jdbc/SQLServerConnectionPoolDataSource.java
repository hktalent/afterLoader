/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.InvalidObjectException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.naming.Reference;
/*    */ import javax.sql.ConnectionPoolDataSource;
/*    */ import javax.sql.PooledConnection;
/*    */ 
/*    */ 
/*    */ public class SQLServerConnectionPoolDataSource
/*    */   extends SQLServerDataSource
/*    */   implements ConnectionPoolDataSource
/*    */ {
/*    */   public PooledConnection getPooledConnection()
/*    */     throws SQLException
/*    */   {
/* 22 */     if (loggerExternal.isLoggable(Level.FINER))
/* 23 */       loggerExternal.entering(getClassNameLogging(), "getPooledConnection");
/* 24 */     PooledConnection localPooledConnection = getPooledConnection(getUser(), getPassword());
/* 25 */     if (loggerExternal.isLoggable(Level.FINER))
/* 26 */       loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", localPooledConnection);
/* 27 */     return localPooledConnection;
/*    */   }
/*    */   
/*    */   public PooledConnection getPooledConnection(String paramString1, String paramString2) throws SQLException
/*    */   {
/* 32 */     if (loggerExternal.isLoggable(Level.FINER))
/* 33 */       loggerExternal.entering(getClassNameLogging(), "getPooledConnection", new Object[] { paramString1, "Password not traced" });
/* 34 */     SQLServerPooledConnection localSQLServerPooledConnection = new SQLServerPooledConnection(this, paramString1, paramString2);
/* 35 */     if (loggerExternal.isLoggable(Level.FINER))
/* 36 */       loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", localSQLServerPooledConnection);
/* 37 */     return localSQLServerPooledConnection;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Reference getReference()
/*    */   {
/* 44 */     if (loggerExternal.isLoggable(Level.FINER))
/* 45 */       loggerExternal.entering(getClassNameLogging(), "getReference");
/* 46 */     Reference localReference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource");
/* 47 */     if (loggerExternal.isLoggable(Level.FINER))
/* 48 */       loggerExternal.exiting(getClassNameLogging(), "getReference", localReference);
/* 49 */     return localReference;
/*    */   }
/*    */   
/*    */   private Object writeReplace() throws ObjectStreamException {
/* 53 */     return new SerializationProxy(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void readObject(ObjectInputStream paramObjectInputStream)
/*    */     throws InvalidObjectException
/*    */   {
/* 63 */     throw new InvalidObjectException("");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private static class SerializationProxy
/*    */     implements Serializable
/*    */   {
/*    */     private final Reference ref;
/*    */     
/*    */     private static final long serialVersionUID = 654661379842314126L;
/*    */     
/*    */ 
/*    */     SerializationProxy(SQLServerConnectionPoolDataSource paramSQLServerConnectionPoolDataSource)
/*    */     {
/* 78 */       this.ref = paramSQLServerConnectionPoolDataSource.getReferenceInternal(null);
/*    */     }
/*    */     
/*    */     private Object readResolve() {
/* 82 */       SQLServerConnectionPoolDataSource localSQLServerConnectionPoolDataSource = new SQLServerConnectionPoolDataSource();
/* 83 */       localSQLServerConnectionPoolDataSource.initializeFromReference(this.ref);
/* 84 */       return localSQLServerConnectionPoolDataSource;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerConnectionPoolDataSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */