/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class AppDTVImpl
/*      */   extends DTVImpl
/*      */ {
/*      */   private JDBCType jdbcType;
/*      */   private Object value;
/*      */   private JavaType javaType;
/*      */   private StreamSetterArgs streamSetterArgs;
/*      */   private Calendar cal;
/*      */   private Integer scale;
/*      */   private boolean forceEncrypt;
/*      */   
/*      */   AppDTVImpl()
/*      */   {
/* 2214 */     this.jdbcType = JDBCType.UNKNOWN;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 2223 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */   
/*      */   final void initFromCompressedNull() {
/* 2227 */     if (!$assertionsDisabled) throw new AssertionError();
/*      */   }
/*      */   
/*      */   final class SetValueOp
/*      */     extends DTVExecuteOp
/*      */   {
/*      */     private final SQLCollation collation;
/*      */     private final SQLServerConnection con;
/*      */     
/*      */     SetValueOp(SQLCollation paramSQLCollation, SQLServerConnection paramSQLServerConnection)
/*      */     {
/* 2238 */       this.collation = paramSQLCollation;
/* 2239 */       this.con = paramSQLServerConnection;
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, String paramString) throws SQLServerException
/*      */     {
/* 2244 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2253 */       if ((JDBCType.DECIMAL == localJDBCType) || (JDBCType.NUMERIC == localJDBCType) || (JDBCType.MONEY == localJDBCType) || (JDBCType.SMALLMONEY == localJDBCType))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2258 */         assert (null != paramString);
/*      */         
/*      */         try
/*      */         {
/* 2262 */           paramDTV.setValue(new BigDecimal(paramString), JavaType.BIGDECIMAL);
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException)
/*      */         {
/* 2266 */           DataTypes.throwConversionError("String", localJDBCType.toString());
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/* 2274 */       else if (localJDBCType.isBinary())
/*      */       {
/* 2276 */         assert (null != paramString);
/* 2277 */         paramDTV.setValue(ParameterUtils.HexToBin(paramString), JavaType.BYTEARRAY);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 2284 */       else if ((null != this.collation) && ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.LONGVARCHAR == localJDBCType) || (JDBCType.CLOB == localJDBCType)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2290 */         byte[] arrayOfByte = null;
/*      */         
/* 2292 */         if (null != paramString)
/*      */         {
/*      */           try
/*      */           {
/* 2296 */             arrayOfByte = paramString.getBytes(this.collation.getCharset());
/*      */           }
/*      */           catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */           {
/* 2300 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/* 2301 */             Object[] arrayOfObject = { new String(localUnsupportedEncodingException.getMessage()) };
/* 2302 */             SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2311 */         paramDTV.setValue(arrayOfByte, JavaType.BYTEARRAY);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Clob paramClob)
/*      */       throws SQLServerException
/*      */     {
/* 2318 */       assert (null != paramClob);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 2327 */         DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramClob.length(), false);
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 2331 */         SQLServerException.makeFromDriverError(this.con, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Byte paramByte)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Integer paramInteger)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Time paramTime)
/*      */       throws SQLServerException
/*      */     {
/* 2350 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2352 */         assert (paramTime != null) : "value is null";
/* 2353 */         paramDTV.setValue(paramTime.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, java.sql.Date paramDate) throws SQLServerException
/*      */     {
/* 2359 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2361 */         assert (paramDate != null) : "value is null";
/* 2362 */         paramDTV.setValue(paramDate.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Timestamp paramTimestamp) throws SQLServerException
/*      */     {
/* 2368 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2370 */         assert (paramTimestamp != null) : "value is null";
/* 2371 */         paramDTV.setValue(paramTimestamp.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, java.util.Date paramDate) throws SQLServerException
/*      */     {
/* 2377 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2379 */         assert (paramDate != null) : "value is null";
/* 2380 */         paramDTV.setValue(paramDate.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, LocalDate paramLocalDate) throws SQLServerException
/*      */     {
/* 2386 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2388 */         assert (paramLocalDate != null) : "value is null";
/* 2389 */         paramDTV.setValue(paramLocalDate.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, LocalTime paramLocalTime) throws SQLServerException
/*      */     {
/* 2395 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2397 */         assert (paramLocalTime != null) : "value is null";
/* 2398 */         paramDTV.setValue(paramLocalTime.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, LocalDateTime paramLocalDateTime) throws SQLServerException
/*      */     {
/* 2404 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2406 */         assert (paramLocalDateTime != null) : "value is null";
/* 2407 */         paramDTV.setValue(paramLocalDateTime.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, OffsetTime paramOffsetTime) throws SQLServerException
/*      */     {
/* 2413 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2415 */         assert (paramOffsetTime != null) : "value is null";
/* 2416 */         paramDTV.setValue(paramOffsetTime.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, OffsetDateTime paramOffsetDateTime) throws SQLServerException
/*      */     {
/* 2422 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2424 */         assert (paramOffsetDateTime != null) : "value is null";
/* 2425 */         paramDTV.setValue(paramOffsetDateTime.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Calendar paramCalendar) throws SQLServerException
/*      */     {
/* 2431 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2433 */         assert (paramCalendar != null) : "value is null";
/* 2434 */         paramDTV.setValue(paramCalendar.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset) throws SQLServerException
/*      */     {
/* 2440 */       if (paramDTV.getJdbcType().isTextual())
/*      */       {
/* 2442 */         assert (paramDateTimeOffset != null) : "value is null";
/* 2443 */         paramDTV.setValue(paramDateTimeOffset.toString(), JavaType.STRING);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, TVP paramTVP)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Float paramFloat)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Double paramDouble)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, BigDecimal paramBigDecimal)
/*      */       throws SQLServerException
/*      */     {
/* 2462 */       if (null != paramBigDecimal)
/*      */       {
/* 2464 */         Integer localInteger = paramDTV.getScale();
/* 2465 */         if ((null != localInteger) && (localInteger.intValue() != paramBigDecimal.scale())) {
/* 2466 */           paramBigDecimal = paramBigDecimal.setScale(localInteger.intValue(), 1);
/*      */         }
/*      */       }
/* 2469 */       paramDTV.setValue(paramBigDecimal, JavaType.BIGDECIMAL);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Long paramLong)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, BigInteger paramBigInteger)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Short paramShort)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Boolean paramBoolean)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, byte[] paramArrayOfByte)
/*      */       throws SQLServerException
/*      */     {}
/*      */     
/*      */     void execute(DTV paramDTV, Blob paramBlob) throws SQLServerException
/*      */     {
/* 2494 */       assert (null != paramBlob);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 2503 */         DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramBlob.length(), false);
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 2507 */         SQLServerException.makeFromDriverError(this.con, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, InputStream paramInputStream) throws SQLServerException
/*      */     {
/* 2513 */       DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramDTV.getStreamSetterArgs().getLength(), true);
/*      */       
/*      */ 
/* 2516 */       if ((JDBCType.NCHAR == AppDTVImpl.this.jdbcType) || (JDBCType.NVARCHAR == AppDTVImpl.this.jdbcType) || (JDBCType.LONGNVARCHAR == AppDTVImpl.this.jdbcType))
/*      */       {
/*      */ 
/*      */ 
/* 2520 */         InputStreamReader localInputStreamReader = null;
/*      */         try
/*      */         {
/* 2523 */           localInputStreamReader = new InputStreamReader(paramInputStream, "US-ASCII");
/*      */         }
/*      */         catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */         {
/* 2527 */           throw new SQLServerException(null, localUnsupportedEncodingException.getMessage(), null, 0, true);
/*      */         }
/*      */         
/* 2530 */         paramDTV.setValue(localInputStreamReader, JavaType.READER);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2537 */         execute(paramDTV, localInputStreamReader);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Reader paramReader)
/*      */       throws SQLServerException
/*      */     {
/* 2544 */       assert (null != paramReader);
/*      */       
/* 2546 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/* 2547 */       long l = DataTypes.getCheckedLength(this.con, paramDTV.getJdbcType(), paramDTV.getStreamSetterArgs().getLength(), true);
/*      */       Object localObject1;
/* 2549 */       Object localObject2; if (localJDBCType.isBinary())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2556 */         localObject1 = DDC.convertReaderToString(paramReader, (int)l);
/*      */         
/*      */ 
/*      */ 
/* 2560 */         if ((-1L != l) && (((String)localObject1).length() != l))
/*      */         {
/* 2562 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 2563 */           localObject2 = new Object[] { Long.valueOf(l), Integer.valueOf(((String)localObject1).length()) };
/* 2564 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(localObject2), "", true);
/*      */         }
/*      */         
/* 2567 */         paramDTV.setValue(localObject1, JavaType.STRING);
/* 2568 */         execute(paramDTV, (String)localObject1);
/*      */ 
/*      */ 
/*      */       }
/* 2572 */       else if ((null != this.collation) && ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.LONGVARCHAR == localJDBCType) || (JDBCType.CLOB == localJDBCType)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2578 */         localObject1 = null;
/*      */         
/*      */         try
/*      */         {
/* 2582 */           localObject1 = new ReaderInputStream(paramReader, this.collation.getCharset(), l);
/*      */ 
/*      */ 
/*      */         }
/*      */         catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */         {
/*      */ 
/* 2589 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/* 2590 */           Object[] arrayOfObject = { new String(localUnsupportedEncodingException.getMessage()) };
/* 2591 */           SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject2).format(arrayOfObject), null, true);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2599 */         paramDTV.setValue(localObject1, JavaType.INPUTSTREAM);
/*      */         
/*      */ 
/* 2602 */         paramDTV.setStreamSetterArgs(new StreamSetterArgs(StreamType.CHARACTER, -1L));
/* 2603 */         execute(paramDTV, (InputStream)localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setValue(DTV paramDTV, SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/* 2622 */     paramDTV.setValue(paramObject, paramJavaType);
/* 2623 */     paramDTV.setJdbcType(paramJDBCType);
/* 2624 */     paramDTV.setStreamSetterArgs(paramStreamSetterArgs);
/* 2625 */     paramDTV.setCalendar(paramCalendar);
/* 2626 */     paramDTV.setScale(paramInteger);
/* 2627 */     paramDTV.setForceEncrypt(paramBoolean);
/* 2628 */     paramDTV.executeOp(new SetValueOp(paramSQLCollation, paramSQLServerConnection));
/*      */   }
/*      */   
/*      */   void setValue(Object paramObject, JavaType paramJavaType)
/*      */   {
/* 2633 */     this.value = paramObject;
/* 2634 */     this.javaType = paramJavaType;
/*      */   }
/*      */   
/*      */   void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs)
/*      */   {
/* 2639 */     this.streamSetterArgs = paramStreamSetterArgs;
/*      */   }
/*      */   
/*      */   void setCalendar(Calendar paramCalendar)
/*      */   {
/* 2644 */     this.cal = paramCalendar;
/*      */   }
/*      */   
/*      */   void setScale(Integer paramInteger)
/*      */   {
/* 2649 */     this.scale = paramInteger;
/*      */   }
/*      */   
/*      */   void setForceEncrypt(boolean paramBoolean)
/*      */   {
/* 2654 */     this.forceEncrypt = paramBoolean;
/*      */   }
/*      */   
/* 2657 */   StreamSetterArgs getStreamSetterArgs() { return this.streamSetterArgs; }
/* 2658 */   Calendar getCalendar() { return this.cal; }
/* 2659 */   Integer getScale() { return this.scale; }
/*      */   
/*      */   boolean isNull()
/*      */   {
/* 2663 */     return null == this.value;
/*      */   }
/*      */   
/*      */   void setJdbcType(JDBCType paramJDBCType)
/*      */   {
/* 2668 */     this.jdbcType = paramJDBCType;
/*      */   }
/*      */   
/*      */   JDBCType getJdbcType()
/*      */   {
/* 2673 */     return this.jdbcType;
/*      */   }
/*      */   
/*      */   JavaType getJavaType()
/*      */   {
/* 2678 */     return this.javaType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getValue(DTV paramDTV, JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 2691 */     if (this.jdbcType != paramJDBCType) {
/* 2692 */       DataTypes.throwConversionError(this.jdbcType.toString(), paramJDBCType.toString());
/*      */     }
/* 2694 */     return this.value;
/*      */   }
/*      */   
/*      */   Object getSetterValue()
/*      */   {
/* 2699 */     return this.value;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/AppDTVImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */