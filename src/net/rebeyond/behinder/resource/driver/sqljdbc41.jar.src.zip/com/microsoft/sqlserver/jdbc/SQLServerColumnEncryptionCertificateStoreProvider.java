/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Path;
/*     */ import java.security.Key;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.bind.DatatypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerColumnEncryptionCertificateStoreProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  29 */   private static final Logger windowsCertificateStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionCertificateStoreProvider");
/*     */   
/*     */ 
/*     */   static boolean isWindows;
/*     */   
/*  34 */   String name = "MSSQL_CERTIFICATE_STORE";
/*     */   
/*     */   static final String localMachineDirectory = "LocalMachine";
/*     */   static final String currentUserDirectory = "CurrentUser";
/*     */   static final String myCertificateStore = "My";
/*     */   
/*     */   static
/*     */   {
/*  42 */     if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows"))
/*     */     {
/*  44 */       isWindows = true;
/*     */     }
/*     */     else
/*     */     {
/*  48 */       isWindows = false; }
/*     */   }
/*     */   
/*  51 */   private Path keyStoreDirectoryPath = null;
/*     */   
/*     */   public SQLServerColumnEncryptionCertificateStoreProvider()
/*     */   {
/*  55 */     windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "SQLServerColumnEncryptionCertificateStoreProvider");
/*     */   }
/*     */   
/*     */   public void setName(String paramString)
/*     */   {
/*  60 */     this.name = paramString;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  65 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/*  87 */     throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidWindowsCertificateStoreEncryption"), null, 0, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] decryptColumnEncryptionKeyWindows(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/*     */     try
/*     */     {
/* 100 */       return AuthenticationJNI.DecryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfByte);
/*     */ 
/*     */     }
/*     */     catch (DLLException localDLLException)
/*     */     {
/* 105 */       DLLException.buildException(localDLLException.GetErrCode(), localDLLException.GetParam1(), localDLLException.GetParam2(), localDLLException.GetParam3()); }
/* 106 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private CertificateDetails getCertificateDetails(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 114 */     String str = null;
/*     */     
/* 116 */     String[] arrayOfString = paramString.split("/");
/*     */     
/*     */     Object localObject2;
/*     */     
/* 120 */     if (arrayOfString.length > 3)
/*     */     {
/* 122 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_AECertpathBad"));
/* 123 */       localObject2 = new Object[] { paramString };
/* 124 */       throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), null);
/*     */     }
/*     */     
/*     */ 
/* 128 */     if (arrayOfString.length > 2)
/*     */     {
/* 130 */       if (arrayOfString[0].equalsIgnoreCase("LocalMachine"))
/*     */       {
/* 132 */         str = "LocalMachine";
/*     */       }
/* 134 */       else if (arrayOfString[0].equalsIgnoreCase("CurrentUser"))
/*     */       {
/* 136 */         str = "CurrentUser";
/*     */       }
/*     */       else
/*     */       {
/* 140 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_AECertLocBad"));
/* 141 */         localObject2 = new Object[] { arrayOfString[0], paramString };
/* 142 */         throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 147 */     if (arrayOfString.length > 1)
/*     */     {
/* 149 */       if (!arrayOfString[(arrayOfString.length - 2)].equalsIgnoreCase("My"))
/*     */       {
/* 151 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_AECertStoreBad"));
/* 152 */         localObject2 = new Object[] { arrayOfString[(arrayOfString.length - 2)], paramString };
/* 153 */         throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 158 */     Object localObject1 = arrayOfString[(arrayOfString.length - 1)];
/* 159 */     if ((null == localObject1) || (0 == ((String)localObject1).length()))
/*     */     {
/*     */ 
/* 162 */       localObject2 = new MessageFormat(SQLServerException.getErrString("R_AECertHashEmpty"));
/* 163 */       Object[] arrayOfObject = { paramString };
/* 164 */       throw new SQLServerException(((MessageFormat)localObject2).format(arrayOfObject), null);
/*     */     }
/*     */     
/*     */ 
/* 168 */     return getCertificateByThumbprint(str, (String)localObject1, paramString);
/*     */   }
/*     */   
/*     */   private String getThumbPrint(X509Certificate paramX509Certificate) throws NoSuchAlgorithmException, CertificateEncodingException
/*     */   {
/* 173 */     MessageDigest localMessageDigest = MessageDigest.getInstance("SHA-1");
/* 174 */     byte[] arrayOfByte1 = paramX509Certificate.getEncoded();
/* 175 */     localMessageDigest.update(arrayOfByte1);
/* 176 */     byte[] arrayOfByte2 = localMessageDigest.digest();
/* 177 */     return DatatypeConverter.printHexBinary(arrayOfByte2);
/*     */   }
/*     */   
/*     */   private CertificateDetails getCertificateByThumbprint(String paramString1, String paramString2, String paramString3)
/*     */     throws SQLServerException
/*     */   {
/* 183 */     FileInputStream localFileInputStream = null;
/*     */     
/* 185 */     if (null == this.keyStoreDirectoryPath)
/*     */     {
/* 187 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_AEKeyPathEmptyOrReserved"));
/* 188 */       localObject2 = new Object[] { this.keyStoreDirectoryPath };
/* 189 */       throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), null);
/*     */     }
/*     */     
/* 192 */     Object localObject1 = this.keyStoreDirectoryPath.resolve(paramString1);
/*     */     
/*     */ 
/* 195 */     Object localObject2 = null;
/*     */     Object localObject4;
/*     */     try {
/* 198 */       localObject2 = KeyStore.getInstance("PKCS12");
/*     */     }
/*     */     catch (KeyStoreException localKeyStoreException)
/*     */     {
/* 202 */       localObject3 = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
/* 203 */       localObject4 = new Object[] { paramString3, this.name };
/* 204 */       throw new SQLServerException(this, ((MessageFormat)localObject3).format(localObject4), null, 0, false);
/*     */     }
/*     */     
/* 207 */     File localFile1 = ((Path)localObject1).toFile();
/* 208 */     Object localObject3 = localFile1.listFiles();
/*     */     
/* 210 */     if ((null == localObject3) || ((null != localObject3) && (0 == localObject3.length)))
/*     */     {
/*     */ 
/* 213 */       throw new SQLServerException(SQLServerException.getErrString("R_KeyStoreNotFound"), null);
/*     */     }
/*     */     
/* 216 */     for (File localFile2 : localObject3)
/*     */     {
/* 218 */       if (!localFile2.isDirectory())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 224 */         char[] arrayOfChar = "".toCharArray();
/*     */         try
/*     */         {
/* 227 */           localFileInputStream = new FileInputStream(localFile2);
/* 228 */           ((KeyStore)localObject2).load(localFileInputStream, arrayOfChar);
/*     */         }
/*     */         catch (IOException|CertificateException|NoSuchAlgorithmException localIOException)
/*     */         {
/*     */           continue;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 241 */           for (localEnumeration = ((KeyStore)localObject2).aliases(); localEnumeration.hasMoreElements();)
/*     */           {
/*     */ 
/* 244 */             localObject5 = (String)localEnumeration.nextElement();
/*     */             
/* 246 */             localObject6 = (X509Certificate)((KeyStore)localObject2).getCertificate((String)localObject5);
/*     */             
/* 248 */             if (paramString2.matches(getThumbPrint((X509Certificate)localObject6)))
/*     */             {
/*     */ 
/* 251 */               Key localKey = null;
/*     */               try
/*     */               {
/* 254 */                 localKey = ((KeyStore)localObject2).getKey((String)localObject5, "".toCharArray());
/*     */                 
/*     */ 
/* 257 */                 if (null == localKey)
/*     */                 {
/* 259 */                   MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
/* 260 */                   localObject7 = new Object[] { paramString3 };
/* 261 */                   throw new SQLServerException(this, localMessageFormat.format(localObject7), null, 0, false);
/*     */                 }
/*     */               }
/*     */               catch (UnrecoverableKeyException|NoSuchAlgorithmException|KeyStoreException localUnrecoverableKeyException)
/*     */               {
/* 266 */                 Object localObject7 = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
/* 267 */                 Object[] arrayOfObject = { paramString3 };
/* 268 */                 throw new SQLServerException(this, ((MessageFormat)localObject7).format(arrayOfObject), null, 0, false);
/*     */               }
/* 270 */               return new CertificateDetails((X509Certificate)localObject6, localKey);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (CertificateException|NoSuchAlgorithmException|KeyStoreException localCertificateException)
/*     */         {
/*     */           Enumeration localEnumeration;
/*     */           
/* 278 */           Object localObject5 = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
/*     */           
/* 280 */           Object localObject6 = { paramString3, this.name };
/* 281 */           throw new SQLServerException(((MessageFormat)localObject5).format(localObject6), localCertificateException);
/*     */         }
/*     */       }
/*     */     }
/* 285 */     throw new SQLServerException(SQLServerException.getErrString("R_KeyStoreNotFound"), null);
/*     */   }
/*     */   
/*     */   private byte[] decryptColumnEncryptionKeyLinux(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/* 291 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
/* 292 */     CertificateDetails localCertificateDetails = getCertificateDetails(paramString1);
/* 293 */     return KeyStoreProviderCommon.decryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfByte, localCertificateDetails);
/*     */   }
/*     */   
/*     */   public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/* 299 */     windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
/* 300 */     byte[] arrayOfByte = null;
/* 301 */     if (isWindows)
/*     */     {
/* 303 */       arrayOfByte = decryptColumnEncryptionKeyWindows(paramString1, paramString2, paramArrayOfByte);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 309 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null);
/*     */     }
/* 311 */     windowsCertificateStoreLogger.exiting(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
/* 312 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerColumnEncryptionCertificateStoreProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */