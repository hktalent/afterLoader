/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.AppConfigurationEntry;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSManager;
/*     */ import org.ietf.jgss.Oid;
/*     */ 
/*     */ final class KerbAuthentication extends SSPIAuthentication
/*     */ {
/*     */   private static final String CONFIGNAME = "SQLJDBCDriver";
/*  19 */   private static final Logger authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.KerbAuthentication");
/*     */   
/*     */   private final SQLServerConnection con;
/*     */   
/*     */   private final String spn;
/*     */   
/*  25 */   private final GSSManager manager = GSSManager.getInstance();
/*  26 */   private LoginContext lc = null;
/*  27 */   private GSSCredential peerCredentials = null;
/*  28 */   private GSSContext peerContext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 115 */     Configuration local1SQLJDBCDriverConfig = new Configuration()
/*     */     {
/*  40 */       Configuration current = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       AppConfigurationEntry[] driverConf;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public AppConfigurationEntry[] getAppConfigurationEntry(String paramAnonymousString)
/*     */       {
/*  96 */         if (paramAnonymousString.equals("SQLJDBCDriver"))
/*     */         {
/*  98 */           return this.driverConf;
/*     */         }
/*     */         
/*     */ 
/* 102 */         if (null != this.current) {
/* 103 */           return this.current.getAppConfigurationEntry(paramAnonymousString);
/*     */         }
/* 105 */         return null;
/*     */       }
/*     */       
/*     */ 
/*     */       public void refresh()
/*     */       {
/* 111 */         if (null != this.current) {
/* 112 */           this.current.refresh();
/*     */         }
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   private void intAuthInit()
/*     */     throws SQLServerException
/*     */   {
/*     */     try
/*     */     {
/* 124 */       Oid localOid = new Oid("1.2.840.113554.1.2.2");
/* 125 */       Subject localSubject = null;
/*     */       try
/*     */       {
/* 128 */         java.security.AccessControlContext localAccessControlContext = java.security.AccessController.getContext();
/* 129 */         localSubject = Subject.getSubject(localAccessControlContext);
/* 130 */         if (null == localSubject)
/*     */         {
/* 132 */           this.lc = new LoginContext("SQLJDBCDriver");
/* 133 */           this.lc.login();
/*     */           
/* 135 */           localSubject = this.lc.getSubject();
/*     */         }
/*     */       }
/*     */       catch (javax.security.auth.login.LoginException localLoginException)
/*     */       {
/* 140 */         this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localLoginException);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 145 */       org.ietf.jgss.GSSName localGSSName = this.manager.createName(this.spn, null);
/* 146 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 148 */         authLogger.finer(toString() + " Getting client credentials");
/*     */       }
/* 150 */       this.peerCredentials = getClientCredential(localSubject, this.manager, localOid);
/* 151 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 153 */         authLogger.finer(toString() + " creating security context");
/*     */       }
/*     */       
/* 156 */       this.peerContext = this.manager.createContext(localGSSName, localOid, this.peerCredentials, 0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 161 */       this.peerContext.requestCredDeleg(true);
/* 162 */       this.peerContext.requestMutualAuth(true);
/* 163 */       this.peerContext.requestInteg(true);
/*     */ 
/*     */     }
/*     */     catch (GSSException localGSSException)
/*     */     {
/* 168 */       authLogger.finer(toString() + "initAuthInit failed GSSException:-" + localGSSException);
/*     */       
/* 170 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localGSSException);
/*     */     }
/*     */     catch (java.security.PrivilegedActionException localPrivilegedActionException)
/*     */     {
/* 174 */       authLogger.finer(toString() + "initAuthInit failed privileged exception:-" + localPrivilegedActionException);
/*     */       
/* 176 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localPrivilegedActionException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static GSSCredential getClientCredential(Subject paramSubject, GSSManager paramGSSManager, final Oid paramOid)
/*     */     throws java.security.PrivilegedActionException
/*     */   {
/* 186 */     java.security.PrivilegedExceptionAction local1 = new java.security.PrivilegedExceptionAction()
/*     */     {
/*     */       public GSSCredential run() throws GSSException {
/* 189 */         return this.val$MANAGER.createCredential(null, 0, paramOid, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 198 */     };
/* 199 */     Object localObject = Subject.doAs(paramSubject, local1);
/* 200 */     return (GSSCredential)localObject;
/*     */   }
/*     */   
/*     */   private byte[] intAuthHandShake(byte[] paramArrayOfByte, boolean[] paramArrayOfBoolean) throws SQLServerException
/*     */   {
/*     */     try {
/* 206 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 208 */         authLogger.finer(toString() + " Sending token to server over secure context");
/*     */       }
/* 210 */       byte[] arrayOfByte = this.peerContext.initSecContext(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */       
/* 212 */       if (this.peerContext.isEstablished())
/*     */       {
/* 214 */         paramArrayOfBoolean[0] = true;
/* 215 */         if (authLogger.isLoggable(Level.FINER)) {
/* 216 */           authLogger.finer(toString() + "Authentication done.");
/*     */         }
/*     */       }
/* 219 */       else if (null == arrayOfByte)
/*     */       {
/*     */ 
/* 222 */         authLogger.info(toString() + "byteToken is null in initSecContext.");
/* 223 */         this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"));
/*     */       }
/* 225 */       return arrayOfByte;
/*     */     }
/*     */     catch (GSSException localGSSException)
/*     */     {
/* 229 */       authLogger.finer(toString() + "initSecContext Failed :-" + localGSSException);
/*     */       
/* 231 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), localGSSException);
/*     */     }
/*     */     
/* 234 */     return null;
/*     */   }
/*     */   
/*     */   private String makeSpn(String paramString, int paramInt) throws SQLServerException
/*     */   {
/* 239 */     if (authLogger.isLoggable(Level.FINER))
/*     */     {
/* 241 */       authLogger.finer(toString() + " Server: " + paramString + " port: " + paramInt);
/*     */     }
/* 243 */     StringBuilder localStringBuilder = new StringBuilder("MSSQLSvc/");
/*     */     
/*     */ 
/* 246 */     if (this.con.serverNameAsACE())
/*     */     {
/* 248 */       localStringBuilder.append(java.net.IDN.toASCII(paramString));
/*     */     }
/*     */     else
/*     */     {
/* 252 */       localStringBuilder.append(paramString);
/*     */     }
/* 254 */     localStringBuilder.append(":");
/* 255 */     localStringBuilder.append(paramInt);
/* 256 */     String str = localStringBuilder.toString();
/* 257 */     if (authLogger.isLoggable(Level.FINER))
/*     */     {
/* 259 */       authLogger.finer(toString() + " SPN: " + str);
/*     */     }
/* 261 */     return str;
/*     */   }
/*     */   
/*     */   KerbAuthentication(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 267 */     this.con = paramSQLServerConnection;
/*     */     
/* 269 */     String str = paramSQLServerConnection.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_SPN.toString());
/*     */     
/*     */ 
/* 272 */     if (null != str)
/*     */     {
/*     */ 
/* 275 */       if (paramSQLServerConnection.serverNameAsACE())
/*     */       {
/* 277 */         int i = str.indexOf("/");
/* 278 */         this.spn = (str.substring(0, i + 1) + java.net.IDN.toASCII(str.substring(i + 1)));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 283 */         this.spn = str;
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 288 */       this.spn = makeSpn(paramString, paramInt);
/*     */     }
/*     */   }
/*     */   
/*     */   byte[] GenerateClientContext(byte[] paramArrayOfByte, boolean[] paramArrayOfBoolean) throws SQLServerException
/*     */   {
/* 294 */     if (null == this.peerContext)
/*     */     {
/* 296 */       intAuthInit();
/*     */     }
/* 298 */     return intAuthHandShake(paramArrayOfByte, paramArrayOfBoolean);
/*     */   }
/*     */   
/*     */   int ReleaseClientContext() throws SQLServerException
/*     */   {
/*     */     try {
/* 304 */       if (null != this.peerCredentials)
/* 305 */         this.peerCredentials.dispose();
/* 306 */       if (null != this.peerContext)
/* 307 */         this.peerContext.dispose();
/* 308 */       if (null != this.lc) {
/* 309 */         this.lc.logout();
/*     */       }
/*     */       
/*     */     }
/*     */     catch (javax.security.auth.login.LoginException localLoginException)
/*     */     {
/* 315 */       authLogger.fine(toString() + " Release of the credentials failed LoginException: " + localLoginException);
/*     */ 
/*     */     }
/*     */     catch (GSSException localGSSException)
/*     */     {
/*     */ 
/* 321 */       authLogger.fine(toString() + " Release of the credentials failed GSSException: " + localGSSException);
/*     */     }
/* 323 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/KerbAuthentication.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */