/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamError
/*    */   extends StreamPacket
/*    */ {
/* 16 */   String errorMessage = "";
/*    */   
/*    */   int errorNumber;
/*    */   
/*    */   int errorState;
/*    */   
/*    */   int errorSeverity;
/*    */   String serverName;
/*    */   String procName;
/*    */   long lineNumber;
/*    */   
/*    */   final String getMessage()
/*    */   {
/* 29 */     return this.errorMessage;
/*    */   }
/*    */   
/* 32 */   final int getErrorNumber() { return this.errorNumber; }
/*    */   
/*    */   final int getErrorState() {
/* 35 */     return this.errorState;
/*    */   }
/*    */   
/* 38 */   final int getErrorSeverity() { return this.errorSeverity; }
/*    */   
/*    */ 
/*    */   StreamError()
/*    */   {
/* 43 */     super(170);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 48 */     if ((170 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 49 */     setContentsFromTDS(paramTDSReader);
/*    */   }
/*    */   
/*    */   void setContentsFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 54 */     paramTDSReader.readUnsignedShort();
/* 55 */     this.errorNumber = paramTDSReader.readInt();
/* 56 */     this.errorState = paramTDSReader.readUnsignedByte();
/* 57 */     this.errorSeverity = paramTDSReader.readUnsignedByte();
/* 58 */     this.errorMessage = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
/* 59 */     this.serverName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 60 */     this.procName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 61 */     this.lineNumber = paramTDSReader.readUnsignedInt();
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */