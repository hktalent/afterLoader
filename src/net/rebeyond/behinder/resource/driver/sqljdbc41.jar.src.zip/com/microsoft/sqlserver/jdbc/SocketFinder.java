/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.Inet4Address;
/*      */ import java.net.Inet6Address;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.channels.SelectionKey;
/*      */ import java.nio.channels.Selector;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.SynchronousQueue;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class SocketFinder
/*      */ {
/*      */   static enum Result
/*      */   {
/* 2112 */     UNKNOWN, 
/* 2113 */     SUCCESS, 
/* 2114 */     FAILURE;
/*      */     
/*      */     private Result() {}
/*      */   }
/*      */   
/* 2119 */   private static final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 5L, TimeUnit.SECONDS, new SynchronousQueue());
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int minTimeoutForParallelConnections = 1500;
/*      */   
/*      */ 
/* 2126 */   private final Object socketFinderlock = new Object();
/*      */   
/*      */ 
/*      */ 
/* 2130 */   private final Object parentThreadLock = new Object();
/*      */   
/*      */ 
/*      */ 
/* 2134 */   private volatile Result result = Result.UNKNOWN;
/*      */   
/*      */ 
/*      */ 
/* 2138 */   private int noOfSpawnedThreads = 0;
/*      */   
/*      */ 
/*      */ 
/* 2142 */   private volatile int noOfThreadsThatNotified = 0;
/*      */   
/*      */ 
/*      */ 
/* 2146 */   private volatile Socket selectedSocket = null;
/*      */   
/*      */ 
/*      */ 
/* 2150 */   private volatile IOException selectedException = null;
/*      */   
/*      */ 
/* 2153 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SocketFinder");
/*      */   
/*      */ 
/*      */   private final String traceID;
/*      */   
/*      */ 
/*      */   private static final int ipAddressLimit = 64;
/*      */   
/*      */ 
/*      */   private final SQLServerConnection conn;
/*      */   
/*      */ 
/*      */ 
/*      */   SocketFinder(String paramString, SQLServerConnection paramSQLServerConnection)
/*      */   {
/* 2168 */     this.traceID = ("SocketFinder(" + paramString + ")");
/* 2169 */     this.conn = paramSQLServerConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Socket findSocket(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3)
/*      */     throws SQLServerException
/*      */   {
/* 2190 */     assert (paramInt2 != 0) : "The driver does not allow a time out of 0";
/*      */     
/*      */     try
/*      */     {
/* 2194 */       InetAddress[] arrayOfInetAddress = null;
/*      */       
/*      */ 
/* 2197 */       if ((paramBoolean1) || (paramBoolean2))
/*      */       {
/*      */ 
/* 2200 */         arrayOfInetAddress = InetAddress.getAllByName(paramString);
/*      */         
/* 2202 */         if ((paramBoolean2) && (arrayOfInetAddress.length > 64))
/*      */         {
/* 2204 */           paramBoolean2 = false;
/* 2205 */           paramInt2 = paramInt3;
/*      */         }
/*      */       }
/*      */       
/* 2209 */       if (!paramBoolean1)
/*      */       {
/*      */ 
/*      */ 
/* 2213 */         if ((paramBoolean2) && (paramBoolean3))
/*      */         {
/* 2215 */           return getDefaultSocket(paramString, paramInt1, 500);
/*      */         }
/* 2217 */         if (!paramBoolean2)
/*      */         {
/* 2219 */           return getDefaultSocket(paramString, paramInt1, paramInt2);
/*      */         }
/*      */       }
/*      */       
/*      */       Object localObject1;
/*      */       
/* 2225 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2227 */         localObject1 = toString() + " Total no of InetAddresses: " + arrayOfInetAddress.length + ". They are: ";
/* 2228 */         for (Object localObject4 : arrayOfInetAddress)
/*      */         {
/* 2230 */           localObject1 = (String)localObject1 + ((InetAddress)localObject4).toString() + ";";
/*      */         }
/*      */         
/* 2233 */         logger.finer((String)localObject1);
/*      */       }
/*      */       Object localObject3;
/* 2236 */       if (arrayOfInetAddress.length > 64)
/*      */       {
/* 2238 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_ipAddressLimitWithMultiSubnetFailover"));
/* 2239 */         ??? = new Object[] { Integer.toString(64) };
/* 2240 */         localObject3 = ((MessageFormat)localObject1).format(???);
/*      */         
/*      */ 
/* 2243 */         this.conn.terminate(6, (String)localObject3);
/*      */       }
/*      */       
/* 2246 */       if (Util.isIBM())
/*      */       {
/* 2248 */         paramInt2 = Math.max(paramInt2, 1500);
/* 2249 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2251 */           logger.finer(toString() + "Using Java NIO with timeout:" + paramInt2);
/*      */         }
/* 2253 */         findSocketUsingJavaNIO(arrayOfInetAddress, paramInt1, paramInt2);
/*      */       }
/*      */       else
/*      */       {
/* 2257 */         localObject1 = new LinkedList();
/* 2258 */         ??? = new LinkedList();
/*      */         
/* 2260 */         for (Object localObject5 : arrayOfInetAddress)
/*      */         {
/* 2262 */           if ((localObject5 instanceof Inet4Address))
/*      */           {
/* 2264 */             ((LinkedList)localObject1).add((Inet4Address)localObject5);
/*      */           }
/*      */           else
/*      */           {
/* 2268 */             assert ((localObject5 instanceof Inet6Address)) : ("Unexpected IP address " + ((InetAddress)localObject5).toString());
/* 2269 */             ((LinkedList)???).add((Inet6Address)localObject5);
/*      */           }
/*      */         }
/*      */         
/*      */         int j;
/*      */         
/* 2275 */         if ((!((LinkedList)localObject1).isEmpty()) && (!((LinkedList)???).isEmpty()))
/*      */         {
/* 2277 */           j = Math.max(paramInt2 / 2, 1500);
/*      */         }
/*      */         else {
/* 2280 */           j = Math.max(paramInt2, 1500);
/*      */         }
/* 2282 */         if (!((LinkedList)localObject1).isEmpty())
/*      */         {
/* 2284 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2286 */             logger.finer(toString() + "Using Java NIO with timeout:" + j);
/*      */           }
/*      */           
/*      */ 
/* 2290 */           findSocketUsingJavaNIO((InetAddress[])((LinkedList)localObject1).toArray(new InetAddress[0]), paramInt1, j);
/*      */         }
/*      */         
/* 2293 */         if (!this.result.equals(Result.SUCCESS))
/*      */         {
/*      */ 
/* 2296 */           if (!((LinkedList)???).isEmpty())
/*      */           {
/*      */ 
/* 2299 */             if (((LinkedList)???).size() == 1)
/*      */             {
/* 2301 */               return getConnectedSocket((InetAddress)((LinkedList)???).get(0), paramInt1, j);
/*      */             }
/*      */             
/* 2304 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2306 */               logger.finer(toString() + "Using Threading with timeout:" + j);
/*      */             }
/*      */             
/* 2309 */             findSocketUsingThreading((LinkedList)???, paramInt1, j);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2318 */       if (this.result.equals(Result.UNKNOWN))
/*      */       {
/* 2320 */         synchronized (this.socketFinderlock)
/*      */         {
/* 2322 */           if (this.result.equals(Result.UNKNOWN))
/*      */           {
/* 2324 */             this.result = Result.FAILURE;
/* 2325 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2327 */               logger.finer(toString() + " The parent thread updated the result to failure");
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2337 */       if (this.result.equals(Result.FAILURE))
/*      */       {
/* 2339 */         if (this.selectedException == null)
/*      */         {
/* 2341 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2343 */             logger.finer(toString() + " There is no selectedException. The wait calls timed out before any connect call returned or timed out.");
/*      */           }
/* 2345 */           ??? = SQLServerException.getErrString("R_connectionTimedOut");
/* 2346 */           this.selectedException = new IOException((String)???);
/*      */         }
/* 2348 */         throw this.selectedException;
/*      */       }
/*      */       
/*      */     }
/*      */     catch (InterruptedException localInterruptedException)
/*      */     {
/* 2354 */       close(this.selectedSocket);
/* 2355 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, localInterruptedException);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2359 */       close(this.selectedSocket);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2369 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, localIOException);
/*      */     }
/*      */     
/*      */ 
/* 2373 */     assert (this.result.equals(Result.SUCCESS) == true);
/* 2374 */     assert (this.selectedSocket != null) : "Bug in code. Selected Socket cannot be null here.";
/*      */     
/* 2376 */     return this.selectedSocket;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void findSocketUsingJavaNIO(InetAddress[] paramArrayOfInetAddress, int paramInt1, int paramInt2)
/*      */     throws IOException
/*      */   {
/* 2394 */     assert (paramInt2 != 0) : "The timeout cannot be zero";
/* 2395 */     assert (paramArrayOfInetAddress.length != 0) : "Number of inetAddresses should not be zero in this function";
/*      */     
/* 2397 */     Selector localSelector = null;
/* 2398 */     LinkedList localLinkedList = new LinkedList();
/* 2399 */     Object localObject1 = null;
/*      */     
/*      */     try
/*      */     {
/* 2403 */       localSelector = Selector.open();
/*      */       
/* 2405 */       for (int i = 0; i < paramArrayOfInetAddress.length; i++)
/*      */       {
/* 2407 */         localSocketChannel1 = SocketChannel.open();
/* 2408 */         localLinkedList.add(localSocketChannel1);
/*      */         
/*      */ 
/* 2411 */         localSocketChannel1.configureBlocking(false);
/*      */         
/*      */ 
/* 2414 */         int j = 8;
/* 2415 */         SelectionKey localSelectionKey1 = localSocketChannel1.register(localSelector, j);
/*      */         
/* 2417 */         localSocketChannel1.connect(new InetSocketAddress(paramArrayOfInetAddress[i], paramInt1));
/*      */         
/* 2419 */         if (logger.isLoggable(Level.FINER)) {
/* 2420 */           logger.finer(toString() + " initiated connection to address: " + paramArrayOfInetAddress[i] + ", portNumber: " + paramInt1);
/*      */         }
/*      */       }
/* 2423 */       long l1 = System.currentTimeMillis();
/* 2424 */       long l2 = l1 + paramInt2;
/*      */       
/*      */ 
/* 2427 */       int k = paramArrayOfInetAddress.length;
/*      */       
/*      */       for (;;)
/*      */       {
/* 2431 */         long l3 = l2 - l1;
/*      */         
/* 2433 */         if ((l3 <= 0L) || (localObject1 != null) || (k <= 0)) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/* 2438 */         int m = localSelector.select(l3);
/*      */         
/* 2440 */         if (logger.isLoggable(Level.FINER)) {
/* 2441 */           logger.finer(toString() + " no of channels ready: " + m);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2447 */         if (m != 0)
/*      */         {
/* 2449 */           Set localSet = localSelector.selectedKeys();
/* 2450 */           Iterator localIterator2 = localSet.iterator();
/*      */           
/* 2452 */           while (localIterator2.hasNext())
/*      */           {
/*      */ 
/* 2455 */             SelectionKey localSelectionKey2 = (SelectionKey)localIterator2.next();
/* 2456 */             SocketChannel localSocketChannel2 = (SocketChannel)localSelectionKey2.channel();
/*      */             
/* 2458 */             if (logger.isLoggable(Level.FINER)) {
/* 2459 */               logger.finer(toString() + " processing the channel :" + localSocketChannel2);
/*      */             }
/* 2461 */             boolean bool = false;
/*      */             try
/*      */             {
/* 2464 */               bool = localSocketChannel2.finishConnect();
/*      */               
/*      */ 
/*      */ 
/* 2468 */               assert (bool == true) : ("finishConnect on channel:" + localSocketChannel2 + " cannot be false");
/*      */               
/* 2470 */               localObject1 = localSocketChannel2;
/*      */               
/* 2472 */               if (logger.isLoggable(Level.FINER)) {
/* 2473 */                 logger.finer(toString() + " selected the channel :" + localObject1);
/*      */               }
/*      */               
/*      */             }
/*      */             catch (IOException localIOException2)
/*      */             {
/* 2479 */               if (logger.isLoggable(Level.FINER)) {
/* 2480 */                 logger.finer(toString() + " the exception: " + localIOException2.getClass() + " with message: " + localIOException2.getMessage() + " occured while processing the channel: " + localSocketChannel2);
/*      */               }
/*      */               
/* 2483 */               updateSelectedException(localIOException2, toString());
/*      */               
/*      */ 
/* 2486 */               localSocketChannel2.close();
/*      */               
/*      */ 
/*      */ 
/* 2490 */               localSelectionKey2.cancel();
/* 2491 */               localIterator2.remove();
/* 2492 */               k--;
/*      */             }
/*      */           }
/*      */         }
/* 2496 */         l1 = System.currentTimeMillis();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException1)
/*      */     {
/*      */       SocketChannel localSocketChannel1;
/*      */       
/*      */       Iterator localIterator1;
/* 2504 */       close((SocketChannel)localObject1);
/* 2505 */       throw localIOException1;
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2515 */       close(localSelector);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2523 */       for (SocketChannel localSocketChannel3 : localLinkedList)
/*      */       {
/* 2525 */         if (localSocketChannel3 != localObject1)
/*      */         {
/* 2527 */           close(localSocketChannel3);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2533 */     if (localObject1 != null)
/*      */     {
/*      */ 
/*      */ 
/* 2537 */       ((SocketChannel)localObject1).configureBlocking(true);
/* 2538 */       this.selectedSocket = ((SocketChannel)localObject1).socket();
/* 2539 */       this.result = Result.SUCCESS;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Socket getDefaultSocket(String paramString, int paramInt1, int paramInt2)
/*      */     throws IOException
/*      */   {
/* 2556 */     InetSocketAddress localInetSocketAddress = new InetSocketAddress(paramString, paramInt1);
/* 2557 */     return getConnectedSocket(localInetSocketAddress, paramInt2);
/*      */   }
/*      */   
/*      */   private Socket getConnectedSocket(InetAddress paramInetAddress, int paramInt1, int paramInt2) throws IOException
/*      */   {
/* 2562 */     InetSocketAddress localInetSocketAddress = new InetSocketAddress(paramInetAddress, paramInt1);
/* 2563 */     return getConnectedSocket(localInetSocketAddress, paramInt2);
/*      */   }
/*      */   
/*      */   private Socket getConnectedSocket(InetSocketAddress paramInetSocketAddress, int paramInt) throws IOException
/*      */   {
/* 2568 */     assert (paramInt != 0) : "timeout cannot be zero";
/* 2569 */     if (paramInetSocketAddress.isUnresolved())
/* 2570 */       throw new UnknownHostException();
/* 2571 */     this.selectedSocket = new Socket();
/* 2572 */     this.selectedSocket.connect(paramInetSocketAddress, paramInt);
/* 2573 */     return this.selectedSocket;
/*      */   }
/*      */   
/*      */   private void findSocketUsingThreading(LinkedList<Inet6Address> paramLinkedList, int paramInt1, int paramInt2) throws IOException, InterruptedException
/*      */   {
/* 2578 */     assert (paramInt2 != 0) : "The timeout cannot be zero";
/* 2579 */     assert (!paramLinkedList.isEmpty()) : "Number of inetAddresses should not be zero in this function";
/*      */     
/* 2581 */     LinkedList localLinkedList1 = new LinkedList();
/* 2582 */     LinkedList localLinkedList2 = new LinkedList();
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 2588 */       this.noOfSpawnedThreads = paramLinkedList.size();
/* 2589 */       for (Iterator localIterator1 = paramLinkedList.iterator(); localIterator1.hasNext();) { localObject1 = (InetAddress)localIterator1.next();
/*      */         
/* 2591 */         localObject2 = new Socket();
/* 2592 */         localLinkedList1.add(localObject2);
/*      */         
/* 2594 */         InetSocketAddress localInetSocketAddress = new InetSocketAddress((InetAddress)localObject1, paramInt1);
/*      */         
/* 2596 */         SocketConnector localSocketConnector = new SocketConnector((Socket)localObject2, localInetSocketAddress, paramInt2, this);
/* 2597 */         localLinkedList2.add(localSocketConnector);
/*      */       }
/*      */       
/*      */ 
/* 2601 */       synchronized (this.parentThreadLock) {
/*      */         Object localObject2;
/* 2603 */         for (Object localObject1 = localLinkedList2.iterator(); ((Iterator)localObject1).hasNext();) { localObject2 = (SocketConnector)((Iterator)localObject1).next();
/*      */           
/* 2605 */           threadPoolExecutor.execute((Runnable)localObject2);
/*      */         }
/*      */         
/* 2608 */         long l1 = System.currentTimeMillis();
/* 2609 */         long l2 = l1 + paramInt2;
/*      */         
/*      */ 
/*      */         for (;;)
/*      */         {
/* 2614 */           long l3 = l2 - l1;
/*      */           
/* 2616 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2618 */             logger.finer(toString() + " TimeRemaining:" + l3 + "; Result:" + this.result + "; Max. open thread count: " + threadPoolExecutor.getLargestPoolSize() + "; Current open thread count:" + threadPoolExecutor.getActiveCount());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2632 */           if ((l3 <= 0L) || (!this.result.equals(Result.UNKNOWN))) {
/*      */             break;
/*      */           }
/* 2635 */           this.parentThreadLock.wait(l3);
/*      */           
/* 2637 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2639 */             logger.finer(toString() + " The parent thread wokeup.");
/*      */           }
/*      */           
/*      */ 
/* 2643 */           l1 = System.currentTimeMillis();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2660 */       for (??? = localLinkedList1.iterator(); ((Iterator)???).hasNext();) { Socket localSocket1 = (Socket)((Iterator)???).next();
/*      */         
/* 2662 */         if (localSocket1 != this.selectedSocket)
/*      */         {
/* 2664 */           close(localSocket1);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2660 */       for (Socket localSocket2 : localLinkedList1)
/*      */       {
/* 2662 */         if (localSocket2 != this.selectedSocket)
/*      */         {
/* 2664 */           close(localSocket2);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Result getResult()
/*      */   {
/* 2677 */     return this.result;
/*      */   }
/*      */   
/*      */   void close(Selector paramSelector)
/*      */   {
/* 2682 */     if (null != paramSelector)
/*      */     {
/* 2684 */       if (logger.isLoggable(Level.FINER)) {
/* 2685 */         logger.finer(toString() + ": Closing Selector");
/*      */       }
/*      */       try
/*      */       {
/* 2689 */         paramSelector.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 2693 */         if (logger.isLoggable(Level.FINE)) {
/* 2694 */           logger.log(Level.FINE, toString() + ": Ignored the following error while closing Selector", localIOException);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void close(Socket paramSocket) {
/* 2701 */     if (null != paramSocket)
/*      */     {
/* 2703 */       if (logger.isLoggable(Level.FINER)) {
/* 2704 */         logger.finer(toString() + ": Closing TCP socket:" + paramSocket);
/*      */       }
/*      */       try
/*      */       {
/* 2708 */         paramSocket.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 2712 */         if (logger.isLoggable(Level.FINE)) {
/* 2713 */           logger.log(Level.FINE, toString() + ": Ignored the following error while closing socket", localIOException);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void close(SocketChannel paramSocketChannel) {
/* 2720 */     if (null != paramSocketChannel)
/*      */     {
/* 2722 */       if (logger.isLoggable(Level.FINER)) {
/* 2723 */         logger.finer(toString() + ": Closing TCP socket channel:" + paramSocketChannel);
/*      */       }
/*      */       try
/*      */       {
/* 2727 */         paramSocketChannel.close();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 2731 */         if (logger.isLoggable(Level.FINE)) {
/* 2732 */           logger.log(Level.FINE, toString() + "Ignored the following error while closing socketChannel", localIOException);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateResult(Socket paramSocket, IOException paramIOException, String paramString)
/*      */   {
/* 2753 */     if (this.result.equals(Result.UNKNOWN))
/*      */     {
/* 2755 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2757 */         logger.finer("The following child thread is waiting for socketFinderLock:" + paramString);
/*      */       }
/*      */       
/* 2760 */       synchronized (this.socketFinderlock)
/*      */       {
/* 2762 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2764 */           logger.finer("The following child thread acquired socketFinderLock:" + paramString);
/*      */         }
/*      */         
/* 2767 */         if (this.result.equals(Result.UNKNOWN))
/*      */         {
/*      */ 
/*      */ 
/* 2771 */           if ((paramIOException == null) && (this.selectedSocket == null))
/*      */           {
/* 2773 */             this.selectedSocket = paramSocket;
/* 2774 */             this.result = Result.SUCCESS;
/* 2775 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2777 */               logger.finer("The socket of the following thread has been chosen:" + paramString);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2782 */           if (paramIOException != null)
/*      */           {
/* 2784 */             updateSelectedException(paramIOException, paramString);
/*      */           }
/*      */         }
/*      */         
/* 2788 */         this.noOfThreadsThatNotified += 1;
/*      */         
/*      */ 
/*      */ 
/* 2792 */         if ((this.noOfThreadsThatNotified >= this.noOfSpawnedThreads) && (this.result.equals(Result.UNKNOWN)))
/*      */         {
/*      */ 
/* 2795 */           this.result = Result.FAILURE;
/*      */         }
/*      */         
/* 2798 */         if (!this.result.equals(Result.UNKNOWN))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2822 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2824 */             logger.finer("The following child thread is waiting for parentThreadLock:" + paramString);
/*      */           }
/*      */           
/* 2827 */           synchronized (this.parentThreadLock)
/*      */           {
/* 2829 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2831 */               logger.finer("The following child thread acquired parentThreadLock:" + paramString);
/*      */             }
/*      */             
/* 2834 */             this.parentThreadLock.notify();
/*      */           }
/*      */           
/* 2837 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2839 */             logger.finer("The following child thread released parentThreadLock and notified the parent thread:" + paramString);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2844 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2846 */         logger.finer("The following child thread released socketFinderLock:" + paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateSelectedException(IOException paramIOException, String paramString)
/*      */   {
/* 2861 */     int i = 0;
/* 2862 */     if (this.selectedException == null)
/*      */     {
/* 2864 */       this.selectedException = paramIOException;
/* 2865 */       i = 1;
/*      */     }
/* 2867 */     else if ((!(paramIOException instanceof SocketTimeoutException)) && ((this.selectedException instanceof SocketTimeoutException)))
/*      */     {
/* 2869 */       this.selectedException = paramIOException;
/* 2870 */       i = 1;
/*      */     }
/*      */     
/* 2873 */     if (i != 0)
/*      */     {
/* 2875 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2877 */         logger.finer("The selected exception is updated to the following: ExceptionType:" + paramIOException.getClass() + "; ExceptionMessage:" + paramIOException.getMessage() + "; by the following thread:" + paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2889 */     return this.traceID;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SocketFinder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */