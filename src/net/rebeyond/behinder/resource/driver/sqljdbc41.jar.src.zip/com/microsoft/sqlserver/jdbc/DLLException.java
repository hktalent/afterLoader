/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ class DLLException
/*     */   extends Exception
/*     */ {
/*  10 */   private int category = -9;
/*     */   
/*  12 */   private int status = -9;
/*     */   
/*  14 */   private int state = -9;
/*     */   
/*     */ 
/*  17 */   private int errCode = -1;
/*     */   
/*  19 */   private String param1 = "";
/*  20 */   private String param2 = "";
/*  21 */   private String param3 = "";
/*     */   
/*     */   DLLException(String paramString, int paramInt1, int paramInt2, int paramInt3)
/*     */   {
/*  25 */     super(paramString);
/*  26 */     this.category = paramInt1;
/*  27 */     this.status = paramInt2;
/*  28 */     this.state = paramInt3;
/*     */   }
/*     */   
/*     */   DLLException(String paramString1, String paramString2, String paramString3, int paramInt)
/*     */   {
/*  33 */     this.errCode = paramInt;
/*  34 */     this.param1 = paramString1;
/*  35 */     this.param2 = paramString2;
/*  36 */     this.param3 = paramString3;
/*     */   }
/*     */   
/*     */   int GetCategory()
/*     */   {
/*  41 */     return this.category;
/*     */   }
/*     */   
/*     */   int GetStatus() {
/*  45 */     return this.status;
/*     */   }
/*     */   
/*     */   int GetState() {
/*  49 */     return this.state;
/*     */   }
/*     */   
/*     */   int GetErrCode() {
/*  53 */     return this.errCode;
/*     */   }
/*     */   
/*     */   String GetParam1() {
/*  57 */     return this.param1;
/*     */   }
/*     */   
/*     */   String GetParam2() {
/*  61 */     return this.param2;
/*     */   }
/*     */   
/*     */   String GetParam3() {
/*  65 */     return this.param3;
/*     */   }
/*     */   
/*     */   static void buildException(int paramInt, String paramString1, String paramString2, String paramString3) throws SQLServerException
/*     */   {
/*  70 */     String str = getErrMessage(paramInt);
/*  71 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString(str));
/*     */     
/*  73 */     Object[] arrayOfObject = { null, null, null };
/*     */     
/*  75 */     buildMsgParams(str, arrayOfObject, paramString1, paramString2, paramString3);
/*     */     
/*  77 */     throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void buildMsgParams(String paramString1, Object[] paramArrayOfObject, String paramString2, String paramString3, String paramString4)
/*     */   {
/*  88 */     if (paramString1.equalsIgnoreCase("R_AECertLocBad")) {
/*  89 */       paramArrayOfObject[0] = paramString2;
/*  90 */       paramArrayOfObject[1] = (paramString2 + "/" + paramString3 + "/" + paramString4);
/*     */     }
/*  92 */     else if (paramString1.equalsIgnoreCase("R_AECertStoreBad")) {
/*  93 */       paramArrayOfObject[0] = paramString3;
/*  94 */       paramArrayOfObject[1] = (paramString2 + "/" + paramString3 + "/" + paramString4);
/*     */     }
/*  96 */     else if (paramString1.equalsIgnoreCase("R_AECertHashEmpty")) {
/*  97 */       paramArrayOfObject[0] = (paramString2 + "/" + paramString3 + "/" + paramString4);
/*     */     }
/*     */     else {
/* 100 */       paramArrayOfObject[0] = paramString2;
/* 101 */       paramArrayOfObject[1] = paramString3;
/* 102 */       paramArrayOfObject[2] = paramString4;
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getErrMessage(int paramInt) {
/* 107 */     String str = null;
/* 108 */     switch (paramInt) {
/*     */     case 1: 
/* 110 */       str = "R_AEKeypathEmpty";
/* 111 */       break;
/*     */     case 2: 
/* 113 */       str = "R_EncryptedCEKNull";
/* 114 */       break;
/*     */     case 3: 
/* 116 */       str = "R_NullKeyEncryptionAlgorithm";
/* 117 */       break;
/*     */     case 4: 
/* 119 */       str = "R_AEWinApiErr";
/* 120 */       break;
/*     */     case 5: 
/* 122 */       str = "R_AECertpathBad";
/* 123 */       break;
/*     */     case 6: 
/* 125 */       str = "R_AECertLocBad";
/* 126 */       break;
/*     */     case 7: 
/* 128 */       str = "R_AECertStoreBad";
/* 129 */       break;
/*     */     case 8: 
/* 131 */       str = "R_AECertHashEmpty";
/* 132 */       break;
/*     */     case 9: 
/* 134 */       str = "R_AECertNotFound";
/* 135 */       break;
/*     */     case 10: 
/* 137 */       str = "R_AEMaloc";
/* 138 */       break;
/*     */     case 11: 
/* 140 */       str = "R_EmptyEncryptedCEK";
/* 141 */       break;
/*     */     case 12: 
/* 143 */       str = "R_InvalidKeyEncryptionAlgorithm";
/* 144 */       break;
/*     */     case 13: 
/* 146 */       str = "R_AEKeypathLong";
/* 147 */       break;
/*     */     case 14: 
/* 149 */       str = "R_InvalidEcryptionAlgorithmVersion";
/* 150 */       break;
/*     */     case 15: 
/* 152 */       str = "R_AEECEKLenBad";
/* 153 */       break;
/*     */     case 16: 
/* 155 */       str = "R_AEECEKSigLenBad";
/* 156 */       break;
/*     */     case 17: 
/* 158 */       str = "R_InvalidCertificateSignature";
/* 159 */       break;
/*     */     default: 
/* 161 */       str = "R_AEWinApiErr";
/*     */     }
/*     */     
/*     */     
/* 165 */     return str;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/DLLException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */