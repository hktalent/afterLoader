/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerDataColumn
/*    */ {
/*    */   String columnName;
/*    */   
/*    */ 
/*    */ 
/*    */   int javaSqlType;
/*    */   
/*    */ 
/* 15 */   int precision = 0;
/* 16 */   int scale = 0;
/*    */   
/*    */   public SQLServerDataColumn(String paramString, int paramInt)
/*    */   {
/* 20 */     this.columnName = paramString;
/* 21 */     this.javaSqlType = paramInt;
/*    */   }
/*    */   
/*    */   public String getColumnName()
/*    */   {
/* 26 */     return this.columnName;
/*    */   }
/*    */   
/*    */   public int getColumnType()
/*    */   {
/* 31 */     return this.javaSqlType;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerDataColumn.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */