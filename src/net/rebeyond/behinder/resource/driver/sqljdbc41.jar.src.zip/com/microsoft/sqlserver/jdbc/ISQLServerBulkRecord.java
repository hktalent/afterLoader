package com.microsoft.sqlserver.jdbc;

import java.util.Set;

public abstract interface ISQLServerBulkRecord
{
  public abstract Set<Integer> getColumnOrdinals();
  
  public abstract String getColumnName(int paramInt);
  
  public abstract int getColumnType(int paramInt);
  
  public abstract int getPrecision(int paramInt);
  
  public abstract int getScale(int paramInt);
  
  public abstract boolean isAutoIncrement(int paramInt);
  
  public abstract Object[] getRowData()
    throws SQLServerException;
  
  public abstract boolean next()
    throws SQLServerException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ISQLServerBulkRecord.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */