/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KeyStoreProviderCommon
/*     */ {
/*     */   static final String rsaEncryptionAlgorithmWithOAEP = "RSA_OAEP";
/*  40 */   static byte[] version = { 1 };
/*     */   
/*     */   static void validateEncryptionAlgorithm(String paramString, boolean paramBoolean) throws SQLServerException
/*     */   {
/*  44 */     String str = paramBoolean ? "R_NullKeyEncryptionAlgorithm" : "R_NullKeyEncryptionAlgorithmInternal";
/*  45 */     if (null == paramString)
/*     */     {
/*     */ 
/*  48 */       throw new SQLServerException(null, SQLServerException.getErrString(str), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */     str = paramBoolean ? "R_InvalidKeyEncryptionAlgorithm" : "R_InvalidKeyEncryptionAlgorithmInternal";
/*  58 */     if (!"RSA_OAEP".equalsIgnoreCase(paramString.trim()))
/*     */     {
/*     */ 
/*  61 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString(str));
/*     */       
/*  63 */       Object[] arrayOfObject = { paramString, "RSA_OAEP" };
/*  64 */       throw new SQLServerException(localMessageFormat.format(arrayOfObject), null);
/*     */     }
/*     */   }
/*     */   
/*     */   static void validateNonEmptyMasterKeyPath(String paramString)
/*     */     throws SQLServerException
/*     */   {
/*  71 */     if ((null == paramString) || (paramString.trim().length() == 0))
/*     */     {
/*  73 */       throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte, CertificateDetails paramCertificateDetails)
/*     */     throws SQLServerException
/*     */   {
/*  88 */     if (null == paramArrayOfByte)
/*     */     {
/*  90 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     if (0 == paramArrayOfByte.length)
/*     */     {
/* 100 */       throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */     validateEncryptionAlgorithm(paramString2, false);
/*     */     
/* 111 */     int i = version.length;
/* 112 */     int j = convertTwoBytesToShort(paramArrayOfByte, i);
/*     */     
/* 114 */     i += 2;
/*     */     
/*     */ 
/* 117 */     int k = convertTwoBytesToShort(paramArrayOfByte, i);
/*     */     
/*     */ 
/* 120 */     i += 2;
/*     */     
/* 122 */     i += j;
/*     */     
/* 124 */     int m = paramArrayOfByte.length - i - k;
/*     */     
/*     */ 
/*     */ 
/* 128 */     byte[] arrayOfByte1 = new byte[k];
/* 129 */     System.arraycopy(paramArrayOfByte, i, arrayOfByte1, 0, k);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     i += k;
/*     */     
/* 137 */     byte[] arrayOfByte2 = new byte[m];
/* 138 */     System.arraycopy(paramArrayOfByte, i, arrayOfByte2, 0, m);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */     byte[] arrayOfByte3 = new byte[paramArrayOfByte.length - arrayOfByte2.length];
/*     */     
/* 149 */     System.arraycopy(paramArrayOfByte, 0, arrayOfByte3, 0, paramArrayOfByte.length - arrayOfByte2.length);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     if (!verifyRSASignature(arrayOfByte3, arrayOfByte2, paramCertificateDetails.certificate, paramString1))
/*     */     {
/* 158 */       localObject = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
/*     */       
/* 160 */       Object[] arrayOfObject = { paramString1 };
/* 161 */       throw new SQLServerException(((MessageFormat)localObject).format(arrayOfObject), null);
/*     */     }
/*     */     
/* 164 */     Object localObject = decryptRSAOAEP(arrayOfByte1, paramCertificateDetails);
/*     */     
/* 166 */     return (byte[])localObject;
/*     */   }
/*     */   
/*     */   private static byte[] decryptRSAOAEP(byte[] paramArrayOfByte, CertificateDetails paramCertificateDetails)
/*     */     throws SQLServerException
/*     */   {
/* 172 */     byte[] arrayOfByte = null;
/*     */     try
/*     */     {
/* 175 */       Cipher localCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/* 176 */       localCipher.init(2, paramCertificateDetails.privateKey);
/* 177 */       localCipher.update(paramArrayOfByte);
/* 178 */       arrayOfByte = localCipher.doFinal();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (InvalidKeyException|NoSuchAlgorithmException|NoSuchPaddingException|IllegalBlockSizeException|BadPaddingException localInvalidKeyException)
/*     */     {
/*     */ 
/*     */ 
/* 186 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_CEKDecryptionFailed"));
/*     */       
/* 188 */       Object[] arrayOfObject = { localInvalidKeyException.getMessage() };
/* 189 */       throw new SQLServerException(localMessageFormat.format(arrayOfObject), null);
/*     */     }
/*     */     
/* 192 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean verifyRSASignature(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, X509Certificate paramX509Certificate, String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 199 */     boolean bool = false;
/*     */     try
/*     */     {
/* 202 */       Signature localSignature = Signature.getInstance("SHA256withRSA");
/* 203 */       localSignature.initVerify(paramX509Certificate.getPublicKey());
/* 204 */       localSignature.update(paramArrayOfByte1);
/* 205 */       bool = localSignature.verify(paramArrayOfByte2);
/*     */ 
/*     */     }
/*     */     catch (InvalidKeyException|NoSuchAlgorithmException|SignatureException localInvalidKeyException)
/*     */     {
/*     */ 
/* 211 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
/* 212 */       Object[] arrayOfObject = { paramString };
/* 213 */       throw new SQLServerException(localMessageFormat.format(arrayOfObject), null);
/*     */     }
/*     */     
/* 216 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */   private static short convertTwoBytesToShort(byte[] paramArrayOfByte, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 223 */     short s = -1;
/* 224 */     if (paramInt + 1 >= paramArrayOfByte.length)
/*     */     {
/* 226 */       throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */     ByteBuffer localByteBuffer = ByteBuffer.allocate(2);
/* 234 */     localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 235 */     localByteBuffer.put(paramArrayOfByte[paramInt]);
/* 236 */     localByteBuffer.put(paramArrayOfByte[(paramInt + 1)]);
/* 237 */     s = localByteBuffer.getShort(0);
/* 238 */     return s;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/KeyStoreProviderCommon.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */