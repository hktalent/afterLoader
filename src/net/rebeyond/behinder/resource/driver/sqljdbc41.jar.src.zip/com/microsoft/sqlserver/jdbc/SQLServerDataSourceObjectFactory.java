/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.Name;
/*    */ import javax.naming.RefAddr;
/*    */ import javax.naming.Reference;
/*    */ import javax.naming.spi.ObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerDataSourceObjectFactory
/*    */   implements ObjectFactory
/*    */ {
/*    */   public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable<?, ?> paramHashtable)
/*    */     throws SQLServerException
/*    */   {
/*    */     try
/*    */     {
/* 29 */       Reference localReference = (Reference)paramObject;
/*    */       
/* 31 */       RefAddr localRefAddr = localReference.get("class");
/*    */       
/*    */ 
/* 34 */       if (null == localRefAddr)
/*    */       {
/* 36 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */       }
/*    */       
/*    */ 
/* 40 */       String str = (String)localRefAddr.getContent();
/*    */       
/* 42 */       if (null == str) {
/* 43 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */       }
/*    */       
/*    */ 
/* 47 */       if ((str.equals("com.microsoft.sqlserver.jdbc.SQLServerDataSource")) || (str.equals("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource")) || (str.equals("com.microsoft.sqlserver.jdbc.SQLServerXADataSource")))
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 53 */         Class localClass = Class.forName(str);
/* 54 */         Object localObject = localClass.newInstance();
/*    */         
/*    */ 
/*    */ 
/* 58 */         SQLServerDataSource localSQLServerDataSource = (SQLServerDataSource)localObject;
/* 59 */         localSQLServerDataSource.initializeFromReference(localReference);
/* 60 */         return localObject;
/*    */       }
/*    */       
/* 63 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */ 
/*    */     }
/*    */     catch (ClassNotFoundException localClassNotFoundException)
/*    */     {
/* 68 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */ 
/*    */     }
/*    */     catch (InstantiationException localInstantiationException)
/*    */     {
/* 73 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */ 
/*    */     }
/*    */     catch (IllegalAccessException localIllegalAccessException)
/*    */     {
/* 78 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     }
/*    */     
/*    */ 
/* 82 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerDataSourceObjectFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */