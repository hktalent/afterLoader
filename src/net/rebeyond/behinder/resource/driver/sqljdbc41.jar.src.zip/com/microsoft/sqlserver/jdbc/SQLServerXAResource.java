/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerXAResource
/*     */   implements XAResource
/*     */ {
/* 145 */   static { baseResourceID = 0; }
/* 146 */   private int tightlyCoupled = 0;
/* 147 */   private int isTransacrionTimeoutSet = 0;
/*     */   
/*     */ 
/* 150 */   private SQLServerCallableStatement[] xaStatements = { null, null, null, null, null, null, null, null, null, null };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */   private static Integer xaInitLock = new Integer(0);
/*     */   private int timeoutSeconds;
/*     */   static final int XA_START = 0;
/*     */   static final int XA_END = 1;
/*     */   
/* 161 */   public String toString() { return this.traceID; }
/*     */   
/*     */   static final int XA_PREPARE = 2;
/*     */   static final int XA_COMMIT = 3;
/*     */   static final int XA_ROLLBACK = 4;
/* 166 */   SQLServerXAResource(SQLServerConnection paramSQLServerConnection1, SQLServerConnection paramSQLServerConnection2, String paramString) { this.traceID = (" XAResourceID:" + nextResourceID());
/*     */     
/* 168 */     this.xaLogger = SQLServerXADataSource.xaLogger;
/* 169 */     this.controlConnection = paramSQLServerConnection2;
/* 170 */     this.con = paramSQLServerConnection1;
/* 171 */     Properties localProperties = paramSQLServerConnection1.activeConnectionProperties;
/* 172 */     if (localProperties == null) {
/* 173 */       this.sResourceManagerId = "";
/*     */     }
/*     */     else {
/* 176 */       this.sResourceManagerId = (localProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString()) + "." + localProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString()) + "." + localProperties.getProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString()));
/*     */     }
/*     */     
/*     */ 
/* 180 */     if (this.xaLogger.isLoggable(Level.FINE)) {
/* 181 */       this.xaLogger.fine(toString() + " created by (" + paramString + ")");
/*     */     }
/*     */     
/* 184 */     this.serverInfoRetrieved = false;
/* 185 */     this.version = "0";
/* 186 */     this.instanceName = "";
/* 187 */     this.ArchitectureMSSQL = 0;
/* 188 */     this.ArchitectureOS = 0;
/*     */   }
/*     */   
/*     */   private synchronized SQLServerCallableStatement getXACallableStatementHandle(int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 194 */     assert ((paramInt >= 0) && (paramInt <= 9));
/* 195 */     assert (paramInt < this.xaStatements.length);
/* 196 */     if (null != this.xaStatements[paramInt]) {
/* 197 */       return this.xaStatements[paramInt];
/*     */     }
/* 199 */     CallableStatement localCallableStatement = null;
/*     */     
/* 201 */     switch (paramInt)
/*     */     {
/*     */     case 0: 
/* 204 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_start(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
/* 205 */       break;
/*     */     case 1: 
/* 207 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_end(?, ?, ?, ?, ?, ?, ?)}");
/* 208 */       break;
/*     */     case 2: 
/* 210 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare(?, ?, ?, ?, ?)}");
/* 211 */       break;
/*     */     case 3: 
/* 213 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_commit(?, ?, ?, ?, ?, ?)}");
/* 214 */       break;
/*     */     case 4: 
/* 216 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback(?, ?, ?, ?, ?)}");
/* 217 */       break;
/*     */     case 5: 
/* 219 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget(?, ?, ?, ?, ?)}");
/* 220 */       break;
/*     */     case 6: 
/* 222 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_recover(?, ?, ?, ?)}");
/* 223 */       break;
/*     */     case 7: 
/* 225 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare_ex(?, ?, ?, ?, ?, ?)}");
/* 226 */       break;
/*     */     case 8: 
/* 228 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback_ex(?, ?, ?, ?, ?, ?)}");
/* 229 */       break;
/*     */     case 9: 
/* 231 */       localCallableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget_ex(?, ?, ?, ?, ?, ?)}");
/* 232 */       break;
/*     */     default: 
/* 234 */       if (!$assertionsDisabled) { throw new AssertionError("Bad handle request:" + paramInt);
/*     */       }
/*     */       break;
/*     */     }
/* 238 */     this.xaStatements[paramInt] = ((SQLServerCallableStatement)localCallableStatement);
/* 239 */     return this.xaStatements[paramInt];
/*     */   }
/*     */   
/*     */   private synchronized void closeXAStatements() throws SQLServerException {
/* 243 */     for (int i = 0; i < this.xaStatements.length; i++) {
/* 244 */       if (null != this.xaStatements[i])
/*     */       {
/* 246 */         this.xaStatements[i].close();
/* 247 */         this.xaStatements[i] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   final synchronized void close() throws SQLServerException {
/*     */     try {
/* 254 */       closeXAStatements();
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 258 */       if (this.xaLogger.isLoggable(Level.WARNING)) {
/* 259 */         this.xaLogger.warning(toString() + "Closing exception ignored: " + localException);
/*     */       }
/*     */     }
/* 262 */     if (null != this.controlConnection)
/* 263 */       this.controlConnection.close();
/*     */   }
/*     */   
/*     */   static final int XA_FORGET = 5;
/*     */   static final int XA_RECOVER = 6;
/*     */   static final int XA_PREPARE_EX = 7;
/*     */   static final int XA_ROLLBACK_EX = 8;
/*     */   static final int XA_FORGET_EX = 9;
/*     */   static final int XA_INIT = 10;
/*     */   private SQLServerConnection controlConnection;
/* 273 */   private String flagsDisplay(int paramInt) { if (0 == paramInt) { return "TMNOFLAGS";
/*     */     }
/*     */     
/* 276 */     StringBuilder localStringBuilder = new StringBuilder(100);
/*     */     
/* 278 */     if (0 != (0x800000 & paramInt)) { localStringBuilder.append("TMENDRSCAN");
/*     */     }
/* 280 */     if (0 != (0x20000000 & paramInt))
/*     */     {
/* 282 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 283 */       localStringBuilder.append("TMFAIL");
/*     */     }
/* 285 */     if (0 != (0x200000 & paramInt))
/*     */     {
/* 287 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 288 */       localStringBuilder.append("TMJOIN");
/*     */     }
/* 290 */     if (0 != (0x40000000 & paramInt))
/*     */     {
/* 292 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 293 */       localStringBuilder.append("TMONEPHASE");
/*     */     }
/* 295 */     if (0 != (0x8000000 & paramInt))
/*     */     {
/* 297 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 298 */       localStringBuilder.append("TMRESUME");
/*     */     }
/* 300 */     if (0 != (0x1000000 & paramInt))
/*     */     {
/* 302 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 303 */       localStringBuilder.append("TMSTARTRSCAN");
/*     */     }
/* 305 */     if (0 != (0x4000000 & paramInt))
/*     */     {
/* 307 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 308 */       localStringBuilder.append("TMSUCCESS");
/*     */     }
/* 310 */     if (0 != (0x2000000 & paramInt))
/*     */     {
/* 312 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 313 */       localStringBuilder.append("TMSUSPEND");
/*     */     }
/*     */     
/* 316 */     if (0 != (0x8000 & paramInt))
/*     */     {
/* 318 */       if (localStringBuilder.length() > 0) localStringBuilder.append("|");
/* 319 */       localStringBuilder.append("SSTRANSTIGHTLYCPLD");
/*     */     }
/* 321 */     return localStringBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   private String cookieDisplay(byte[] paramArrayOfByte)
/*     */   {
/* 327 */     return Util.byteToHexDisplayString(paramArrayOfByte);
/*     */   }
/*     */   
/*     */ 
/*     */   private String typeDisplay(int paramInt)
/*     */   {
/* 333 */     switch (paramInt) {
/*     */     case 0: 
/* 335 */       return "XA_START";
/* 336 */     case 1:  return "XA_END";
/* 337 */     case 2:  return "XA_PREPARE";
/* 338 */     case 3:  return "XA_COMMIT";
/* 339 */     case 4:  return "XA_ROLLBACK";
/* 340 */     case 5:  return "XA_FORGET";
/* 341 */     case 6:  return "XA_RECOVER"; }
/* 342 */     return "UNKNOWN" + paramInt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final XAReturnValue DTC_XA_Interface(int paramInt1, Xid paramXid, int paramInt2)
/*     */     throws XAException
/*     */   {
/* 351 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 352 */       this.xaLogger.finer(toString() + " Calling XA function for type:" + typeDisplay(paramInt1) + " flags:" + flagsDisplay(paramInt2) + " xid:" + XidImpl.xidDisplay(paramXid));
/*     */     }
/* 354 */     int i = 0;
/* 355 */     byte[] arrayOfByte1 = null;
/* 356 */     byte[] arrayOfByte2 = null;
/* 357 */     if (paramXid != null)
/*     */     {
/* 359 */       i = paramXid.getFormatId();
/* 360 */       arrayOfByte1 = paramXid.getGlobalTransactionId();
/* 361 */       arrayOfByte2 = paramXid.getBranchQualifier();
/*     */     }
/*     */     
/* 364 */     String str1 = "DTC_XA_";
/* 365 */     int j = 1;
/* 366 */     int k = 0;
/* 367 */     XAReturnValue localXAReturnValue = new XAReturnValue();
/*     */     
/* 369 */     SQLServerCallableStatement localSQLServerCallableStatement = null;
/*     */     try { Object localObject2;
/*     */       Object localObject3;
/* 372 */       synchronized (this)
/*     */       {
/* 374 */         if (this.controlConnection == null)
/*     */         {
/*     */           try
/*     */           {
/* 378 */             synchronized (xaInitLock)
/*     */             {
/* 380 */               if (!xaInitDone)
/*     */               {
/* 382 */                 localObject2 = null;
/*     */                 
/* 384 */                 localObject2 = (SQLServerCallableStatement)this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_init_ex(?, ?,?)}");
/* 385 */                 ((SQLServerCallableStatement)localObject2).registerOutParameter(1, 4);
/* 386 */                 ((SQLServerCallableStatement)localObject2).registerOutParameter(2, 1);
/* 387 */                 ((SQLServerCallableStatement)localObject2).registerOutParameter(3, 1);
/*     */                 try
/*     */                 {
/* 390 */                   ((SQLServerCallableStatement)localObject2).execute();
/*     */                 }
/*     */                 catch (SQLServerException localSQLServerException6)
/*     */                 {
/*     */                   try
/*     */                   {
/* 396 */                     ((SQLServerCallableStatement)localObject2).close();
/*     */                     
/* 398 */                     this.controlConnection.close();
/*     */ 
/*     */                   }
/*     */                   catch (SQLException localSQLException)
/*     */                   {
/* 403 */                     if (this.xaLogger.isLoggable(Level.FINER))
/* 404 */                       this.xaLogger.finer(toString() + " Ignoring exception when closing failed execution. exception:" + localSQLException);
/*     */                   }
/* 406 */                   if (this.xaLogger.isLoggable(Level.FINER))
/* 407 */                     this.xaLogger.finer(toString() + " exception:" + localSQLServerException6);
/* 408 */                   throw localSQLServerException6;
/*     */                 }
/*     */                 
/*     */ 
/* 412 */                 int m = ((SQLServerCallableStatement)localObject2).getInt(1);
/* 413 */                 String str3 = ((SQLServerCallableStatement)localObject2).getString(2);
/* 414 */                 String str4 = ((SQLServerCallableStatement)localObject2).getString(3);
/* 415 */                 if (this.xaLogger.isLoggable(Level.FINE))
/* 416 */                   this.xaLogger.fine(toString() + " Server XA DLL version:" + str4);
/* 417 */                 ((SQLServerCallableStatement)localObject2).close();
/* 418 */                 if (0 != m)
/*     */                 {
/* 420 */                   assert ((null != str3) && (str3.length() > 1));
/* 421 */                   this.controlConnection.close();
/*     */                   
/* 423 */                   MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_failedToInitializeXA"));
/* 424 */                   Object[] arrayOfObject2 = { String.valueOf(m), str3 };
/* 425 */                   XAException localXAException2 = new XAException(localMessageFormat2.format(arrayOfObject2));
/* 426 */                   localXAException2.errorCode = m;
/* 427 */                   if (this.xaLogger.isLoggable(Level.FINER))
/* 428 */                     this.xaLogger.finer(toString() + " exception:" + localXAException2);
/* 429 */                   throw localXAException2;
/*     */                 }
/*     */                 
/* 432 */                 xaInitDone = true;
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (SQLServerException localSQLServerException2)
/*     */           {
/* 438 */             localObject2 = new MessageFormat(SQLServerException.getErrString("R_failedToCreateXAConnection"));
/* 439 */             localObject3 = new Object[] { new String(localSQLServerException2.getMessage()) };
/* 440 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 441 */               this.xaLogger.finer(toString() + " exception:" + ((MessageFormat)localObject2).format(localObject3));
/* 442 */             SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject2).format(localObject3), null, true);
/*     */           }
/*     */         }
/*     */       }
/*     */       Object localObject1;
/* 447 */       switch (paramInt1)
/*     */       {
/*     */       case 0: 
/* 450 */         if (!this.serverInfoRetrieved) {
/*     */           try
/*     */           {
/* 453 */             this.serverInfoRetrieved = true;
/*     */             
/* 455 */             ??? = "select convert(varchar(100), SERVERPROPERTY('Edition'))as edition,  convert(varchar(100), SERVERPROPERTY('InstanceName'))as instance, convert(varchar(100), SERVERPROPERTY('ProductVersion')) as version, SUBSTRING(@@VERSION, CHARINDEX('<', @@VERSION)+2, 2)";
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 460 */             localObject1 = this.controlConnection.createStatement();
/* 461 */             localObject2 = ((Statement)localObject1).executeQuery((String)???);
/* 462 */             ((ResultSet)localObject2).next();
/*     */             
/* 464 */             localObject3 = ((ResultSet)localObject2).getString(1);
/* 465 */             this.ArchitectureMSSQL = ((null != localObject3) && (((String)localObject3).contains("(64-bit)")) ? 64 : 32);
/*     */             
/*     */ 
/* 468 */             this.instanceName = (((ResultSet)localObject2).getString(2) == null ? "MSSQLSERVER" : ((ResultSet)localObject2).getString(2));
/* 469 */             this.version = ((ResultSet)localObject2).getString(3);
/* 470 */             if (null == this.version)
/*     */             {
/* 472 */               this.version = "0";
/*     */             }
/* 474 */             else if (-1 != this.version.indexOf('.'))
/*     */             {
/* 476 */               this.version = this.version.substring(0, this.version.indexOf('.'));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 481 */             this.ArchitectureOS = Integer.parseInt(((ResultSet)localObject2).getString(4));
/*     */             
/* 483 */             ((ResultSet)localObject2).close();
/* 484 */             ((Statement)localObject1).close();
/*     */ 
/*     */           }
/*     */           catch (Exception localException)
/*     */           {
/* 489 */             if (this.xaLogger.isLoggable(Level.WARNING)) {
/* 490 */               this.xaLogger.warning(toString() + " Cannot retrieve server information: :" + localException.getMessage());
/*     */             }
/*     */           }
/*     */         }
/* 494 */         str1 = "START:";
/* 495 */         localSQLServerCallableStatement = getXACallableStatementHandle(0);
/* 496 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 497 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 498 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 499 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 500 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 501 */         localSQLServerCallableStatement.registerOutParameter(j++, -2);
/* 502 */         localSQLServerCallableStatement.setInt(j++, this.timeoutSeconds);
/* 503 */         localSQLServerCallableStatement.setInt(j++, i);
/* 504 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 505 */         localSQLServerCallableStatement.setInt(j++, Integer.parseInt(this.version));
/* 506 */         localSQLServerCallableStatement.setInt(j++, this.instanceName.length());
/* 507 */         localSQLServerCallableStatement.setBytes(j++, this.instanceName.getBytes());
/* 508 */         localSQLServerCallableStatement.setInt(j++, this.ArchitectureMSSQL);
/* 509 */         localSQLServerCallableStatement.setInt(j++, this.ArchitectureOS);
/* 510 */         localSQLServerCallableStatement.setInt(j++, this.isTransacrionTimeoutSet);
/* 511 */         localSQLServerCallableStatement.registerOutParameter(j++, -2);
/*     */         
/* 513 */         break;
/*     */       
/*     */       case 1: 
/* 516 */         str1 = "END:";
/* 517 */         localSQLServerCallableStatement = getXACallableStatementHandle(1);
/* 518 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 519 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 520 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 521 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 522 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 523 */         localSQLServerCallableStatement.setInt(j++, i);
/* 524 */         localSQLServerCallableStatement.registerOutParameter(j++, -2);
/* 525 */         break;
/*     */       
/*     */       case 2: 
/* 528 */         str1 = "PREPARE:";
/* 529 */         if ((0x8000 & paramInt2) == 32768) {
/* 530 */           localSQLServerCallableStatement = getXACallableStatementHandle(7);
/*     */         } else {
/* 532 */           localSQLServerCallableStatement = getXACallableStatementHandle(2);
/*     */         }
/* 534 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 535 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 536 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 537 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 538 */         if ((0x8000 & paramInt2) == 32768)
/* 539 */           localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 540 */         localSQLServerCallableStatement.setInt(j++, i);
/* 541 */         break;
/*     */       
/*     */       case 3: 
/* 544 */         str1 = "COMMIT:";
/* 545 */         localSQLServerCallableStatement = getXACallableStatementHandle(3);
/* 546 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 547 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 548 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 549 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 550 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 551 */         localSQLServerCallableStatement.setInt(j++, i);
/* 552 */         break;
/*     */       
/*     */       case 4: 
/* 555 */         str1 = "ROLLBACK:";
/* 556 */         if ((0x8000 & paramInt2) == 32768) {
/* 557 */           localSQLServerCallableStatement = getXACallableStatementHandle(8);
/*     */         } else {
/* 559 */           localSQLServerCallableStatement = getXACallableStatementHandle(4);
/*     */         }
/* 561 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 562 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 563 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 564 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 565 */         if ((0x8000 & paramInt2) == 32768)
/* 566 */           localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 567 */         localSQLServerCallableStatement.setInt(j++, i);
/* 568 */         break;
/*     */       
/*     */       case 5: 
/* 571 */         str1 = "FORGET:";
/* 572 */         if ((0x8000 & paramInt2) == 32768) {
/* 573 */           localSQLServerCallableStatement = getXACallableStatementHandle(9);
/*     */         } else
/* 575 */           localSQLServerCallableStatement = getXACallableStatementHandle(5);
/* 576 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 577 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 578 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte1);
/* 579 */         localSQLServerCallableStatement.setBytes(j++, arrayOfByte2);
/* 580 */         if ((0x8000 & paramInt2) == 32768)
/* 581 */           localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 582 */         localSQLServerCallableStatement.setInt(j++, i);
/* 583 */         break;
/*     */       
/*     */       case 6: 
/* 586 */         str1 = "RECOVER:";
/* 587 */         localSQLServerCallableStatement = getXACallableStatementHandle(6);
/* 588 */         localSQLServerCallableStatement.registerOutParameter(j++, 4);
/* 589 */         localSQLServerCallableStatement.registerOutParameter(j++, 1);
/* 590 */         localSQLServerCallableStatement.setInt(j++, paramInt2);
/* 591 */         localSQLServerCallableStatement.registerOutParameter(j++, -2);
/*     */         
/* 593 */         break;
/*     */       default: 
/* 595 */         if (!$assertionsDisabled) { throw new AssertionError("Unknown execution type:" + paramInt1);
/*     */         }
/*     */         
/*     */         break;
/*     */       }
/*     */       
/*     */       
/* 602 */       localSQLServerCallableStatement.execute();
/* 603 */       k = localSQLServerCallableStatement.getInt(1);
/* 604 */       String str2 = localSQLServerCallableStatement.getString(2);
/* 605 */       if (paramInt1 == 0)
/*     */       {
/* 607 */         localObject1 = localSQLServerCallableStatement.getString(9);
/* 608 */         if (this.xaLogger.isLoggable(Level.FINE))
/*     */         {
/* 610 */           this.xaLogger.fine(toString() + " Server XA DLL version:" + (String)localObject1);
/* 611 */           if (null != localSQLServerCallableStatement.getString(16))
/*     */           {
/* 613 */             localObject2 = new StringBuffer(localSQLServerCallableStatement.getString(16));
/* 614 */             ((StringBuffer)localObject2).insert(20, '-');
/* 615 */             ((StringBuffer)localObject2).insert(16, '-');
/* 616 */             ((StringBuffer)localObject2).insert(12, '-');
/* 617 */             ((StringBuffer)localObject2).insert(8, '-');
/* 618 */             this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_START XID: " + XidImpl.xidDisplay(paramXid) + " UoW: " + ((StringBuffer)localObject2).toString());
/*     */           }
/*     */         }
/*     */       }
/* 622 */       if (paramInt1 == 1)
/*     */       {
/* 624 */         if (this.xaLogger.isLoggable(Level.FINE))
/*     */         {
/* 626 */           if (null != localSQLServerCallableStatement.getString(7))
/*     */           {
/* 628 */             localObject1 = new StringBuffer(localSQLServerCallableStatement.getString(7));
/* 629 */             ((StringBuffer)localObject1).insert(20, '-');
/* 630 */             ((StringBuffer)localObject1).insert(16, '-');
/* 631 */             ((StringBuffer)localObject1).insert(12, '-');
/* 632 */             ((StringBuffer)localObject1).insert(8, '-');
/* 633 */             this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_END XID: " + XidImpl.xidDisplay(paramXid) + " UoW: " + ((StringBuffer)localObject1).toString());
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 639 */       if (((3 == k) && (1 != paramInt1) && (2 != paramInt1)) || ((0 != k) && (3 != k)))
/*     */       {
/*     */ 
/* 642 */         assert ((null != str2) && (str2.length() > 1));
/* 643 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_failedFunctionXA"));
/* 644 */         localObject2 = new Object[] { str1, String.valueOf(k), str2 };
/* 645 */         localObject3 = new XAException(((MessageFormat)localObject1).format(localObject2));
/* 646 */         ((XAException)localObject3).errorCode = k;
/*     */         
/* 648 */         if ((paramInt1 == 1) && (-7 == k))
/*     */         {
/*     */           try
/*     */           {
/* 652 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 653 */               this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + this.enlistedTransactionCount);
/* 654 */             this.con.JTAUnenlistConnection();
/* 655 */             this.enlistedTransactionCount -= 1;
/* 656 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 657 */               this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + this.enlistedTransactionCount);
/*     */             }
/*     */           }
/*     */           catch (SQLServerException localSQLServerException7)
/*     */           {
/* 662 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 663 */               this.xaLogger.finer(toString() + " Ignoring exception:" + localSQLServerException7);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 668 */         throw ((Throwable)localObject3);
/*     */       }
/*     */       
/*     */ 
/* 672 */       if (paramInt1 == 0)
/*     */       {
/*     */ 
/*     */ 
/* 676 */         localObject1 = localSQLServerCallableStatement.getBytes(6);
/* 677 */         if (localObject1 == null)
/*     */         {
/* 679 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_noTransactionCookie"));
/* 680 */           localObject3 = new Object[] { str1 };
/* 681 */           SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject2).format(localObject3), null, true);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/* 688 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 689 */               this.xaLogger.finer(toString() + " Begin enlisting, cookie:" + cookieDisplay((byte[])localObject1) + " enlisted count:" + this.enlistedTransactionCount);
/* 690 */             this.con.JTAEnlistConnection((byte[])localObject1);
/* 691 */             this.enlistedTransactionCount += 1;
/* 692 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 693 */               this.xaLogger.finer(toString() + " End enlisting, cookie:" + cookieDisplay((byte[])localObject1) + " enlisted count:" + this.enlistedTransactionCount);
/*     */             }
/*     */           }
/*     */           catch (SQLServerException localSQLServerException5) {
/* 697 */             localObject3 = new MessageFormat(SQLServerException.getErrString("R_failedToEnlist"));
/* 698 */             Object[] arrayOfObject1 = { localSQLServerException5.getMessage() };
/* 699 */             SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject3).format(arrayOfObject1), null, true);
/*     */           }
/*     */         }
/*     */       }
/*     */       MessageFormat localMessageFormat1;
/* 704 */       if (paramInt1 == 1)
/*     */       {
/*     */         try
/*     */         {
/* 708 */           if (this.xaLogger.isLoggable(Level.FINER))
/* 709 */             this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + this.enlistedTransactionCount);
/* 710 */           this.con.JTAUnenlistConnection();
/* 711 */           this.enlistedTransactionCount -= 1;
/* 712 */           if (this.xaLogger.isLoggable(Level.FINER)) {
/* 713 */             this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + this.enlistedTransactionCount);
/*     */           }
/*     */         }
/*     */         catch (SQLServerException localSQLServerException3) {
/* 717 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_failedToUnEnlist"));
/* 718 */           localObject3 = new Object[] { localSQLServerException3.getMessage() };
/* 719 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat1.format(localObject3), null, true);
/*     */         }
/*     */       }
/* 722 */       if (paramInt1 == 6)
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/* 727 */           localXAReturnValue.bData = localSQLServerCallableStatement.getBytes(4);
/*     */         }
/*     */         catch (SQLServerException localSQLServerException4)
/*     */         {
/* 731 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_failedToReadRecoveryXIDs"));
/* 732 */           localObject3 = new Object[] { localSQLServerException4.getMessage() };
/* 733 */           SQLServerException.makeFromDriverError(null, null, localMessageFormat1.format(localObject3), null, true);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (SQLServerException localSQLServerException1)
/*     */     {
/* 740 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 741 */         this.xaLogger.finer(toString() + " exception:" + localSQLServerException1);
/* 742 */       XAException localXAException1 = new XAException(localSQLServerException1.toString());
/* 743 */       localXAException1.errorCode = -3;
/* 744 */       throw localXAException1;
/*     */     }
/*     */     
/* 747 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 748 */       this.xaLogger.finer(toString() + " Status:" + k);
/*     */     }
/* 750 */     localXAReturnValue.nStatus = k;
/* 751 */     return localXAReturnValue;
/*     */   }
/*     */   
/*     */ 
/*     */   private SQLServerConnection con;
/*     */   
/*     */   private boolean serverInfoRetrieved;
/*     */   
/*     */   private String version;
/*     */   private String instanceName;
/*     */   private int ArchitectureMSSQL;
/*     */   private int ArchitectureOS;
/*     */   private static boolean xaInitDone;
/*     */   private String sResourceManagerId;
/*     */   private int enlistedTransactionCount;
/*     */   private final Logger xaLogger;
/*     */   private static int baseResourceID;
/*     */   public static final int SSTRANSTIGHTLYCPLD = 32768;
/*     */   private final String traceID;
/*     */   public void start(Xid paramXid, int paramInt)
/*     */     throws XAException
/*     */   {
/* 773 */     this.tightlyCoupled = (paramInt & 0x8000);
/* 774 */     DTC_XA_Interface(0, paramXid, paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void end(Xid paramXid, int paramInt)
/*     */     throws XAException
/*     */   {
/* 787 */     DTC_XA_Interface(1, paramXid, paramInt | this.tightlyCoupled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int prepare(Xid paramXid)
/*     */     throws XAException
/*     */   {
/* 799 */     int i = 0;
/* 800 */     XAReturnValue localXAReturnValue = DTC_XA_Interface(2, paramXid, this.tightlyCoupled);
/* 801 */     i = localXAReturnValue.nStatus;
/*     */     
/* 803 */     return i;
/*     */   }
/*     */   
/*     */   public void commit(Xid paramXid, boolean paramBoolean) throws XAException
/*     */   {
/* 808 */     DTC_XA_Interface(3, paramXid, (paramBoolean ? 1073741824 : 0) | this.tightlyCoupled);
/*     */   }
/*     */   
/*     */   public void rollback(Xid paramXid) throws XAException
/*     */   {
/* 813 */     DTC_XA_Interface(4, paramXid, this.tightlyCoupled);
/*     */   }
/*     */   
/*     */   public void forget(Xid paramXid) throws XAException
/*     */   {
/* 818 */     DTC_XA_Interface(5, paramXid, this.tightlyCoupled);
/*     */   }
/*     */   
/*     */   public Xid[] recover(int paramInt) throws XAException
/*     */   {
/* 823 */     XAReturnValue localXAReturnValue = DTC_XA_Interface(6, null, paramInt | this.tightlyCoupled);
/* 824 */     int i = 0;
/* 825 */     Vector localVector = new Vector();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 836 */     if (null == localXAReturnValue.bData) { return new XidImpl[0];
/*     */     }
/* 838 */     while (i < localXAReturnValue.bData.length)
/*     */     {
/* 840 */       int j = 1;
/* 841 */       k = 0;
/* 842 */       for (int m = 0; m < 4; m++)
/*     */       {
/* 844 */         n = localXAReturnValue.bData[(i + m)] & 0xFF;
/* 845 */         n *= j;
/* 846 */         k += n;
/* 847 */         j *= 256;
/*     */       }
/* 849 */       i += 4;
/* 850 */       m = localXAReturnValue.bData[(i++)] & 0xFF;
/* 851 */       int n = localXAReturnValue.bData[(i++)] & 0xFF;
/* 852 */       byte[] arrayOfByte1 = new byte[m];
/* 853 */       byte[] arrayOfByte2 = new byte[n];
/* 854 */       System.arraycopy(localXAReturnValue.bData, i, arrayOfByte1, 0, m);
/* 855 */       i += m;
/* 856 */       System.arraycopy(localXAReturnValue.bData, i, arrayOfByte2, 0, n);
/* 857 */       i += n;
/* 858 */       XidImpl localXidImpl = new XidImpl(k, arrayOfByte1, arrayOfByte2);
/* 859 */       localVector.add(localXidImpl);
/*     */     }
/* 861 */     XidImpl[] arrayOfXidImpl = new XidImpl[localVector.size()];
/* 862 */     for (int k = 0; k < localVector.size(); k++)
/*     */     {
/* 864 */       arrayOfXidImpl[k] = ((XidImpl)localVector.elementAt(k));
/* 865 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 866 */         this.xaLogger.finer(toString() + arrayOfXidImpl[k].toString());
/*     */     }
/* 868 */     return arrayOfXidImpl;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSameRM(XAResource paramXAResource)
/*     */     throws XAException
/*     */   {
/* 875 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 876 */       this.xaLogger.finer(toString() + " xares:" + paramXAResource);
/*     */     }
/*     */     
/* 879 */     if (!(paramXAResource instanceof SQLServerXAResource))
/* 880 */       return false;
/* 881 */     SQLServerXAResource localSQLServerXAResource = (SQLServerXAResource)paramXAResource;
/* 882 */     return localSQLServerXAResource.sResourceManagerId.equals(this.sResourceManagerId);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setTransactionTimeout(int paramInt)
/*     */     throws XAException
/*     */   {
/* 889 */     this.isTransacrionTimeoutSet = 1;
/* 890 */     this.timeoutSeconds = paramInt;
/* 891 */     if (this.xaLogger.isLoggable(Level.FINER))
/* 892 */       this.xaLogger.finer(toString() + " TransactionTimeout:" + paramInt);
/* 893 */     return true;
/*     */   }
/*     */   
/*     */   public int getTransactionTimeout() throws XAException
/*     */   {
/* 898 */     return this.timeoutSeconds;
/*     */   }
/*     */   
/*     */ 
/*     */   private static synchronized int nextResourceID()
/*     */   {
/* 904 */     baseResourceID += 1;
/* 905 */     return baseResourceID;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerXAResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */