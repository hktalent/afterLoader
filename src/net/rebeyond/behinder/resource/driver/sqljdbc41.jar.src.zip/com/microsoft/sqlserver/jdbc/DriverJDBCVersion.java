/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DriverJDBCVersion
/*    */ {
/*    */   static final int major = 4;
/*    */   
/*    */ 
/*    */   static final int minor = 1;
/*    */   
/*    */ 
/*    */ 
/*    */   static final void checkSupportsJDBC4() {}
/*    */   
/*    */ 
/*    */   static final void checkSupportsJDBC41() {}
/*    */   
/*    */ 
/*    */   static final void checkSupportsJDBC42()
/*    */   {
/* 22 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*    */   }
/*    */   
/*    */ 
/*    */   static final void throwBatchUpdateException(SQLServerException paramSQLServerException, long[] paramArrayOfLong)
/*    */   {
/* 28 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/DriverJDBCVersion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */