/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamRetValue
/*    */   extends StreamPacket
/*    */ {
/*    */   private String paramName;
/*    */   
/*    */   private int ordinalOrLength;
/*    */   
/*    */   private int status;
/*    */   
/*    */ 
/*    */   final int getOrdinalOrLength()
/*    */   {
/* 17 */     return this.ordinalOrLength;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   StreamRetValue()
/*    */   {
/* 28 */     super(172);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 33 */     if ((172 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) throw new AssertionError();
/* 34 */     this.ordinalOrLength = paramTDSReader.readUnsignedShort();
/* 35 */     this.paramName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 36 */     this.status = paramTDSReader.readUnsignedByte();
/*    */   }
/*    */   
/*    */   CryptoMetadata getCryptoMetadata(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 41 */     CryptoMetadata localCryptoMetadata = new StreamColumns().readCryptoMetadata(paramTDSReader);
/*    */     
/* 43 */     return localCryptoMetadata;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamRetValue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */