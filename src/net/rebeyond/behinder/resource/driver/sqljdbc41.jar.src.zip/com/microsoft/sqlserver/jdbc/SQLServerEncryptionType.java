/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */  enum SQLServerEncryptionType
/*    */ {
/* 11 */   Deterministic((byte)1), 
/* 12 */   Randomized((byte)2), 
/* 13 */   PlainText((byte)0);
/*    */   
/*    */   byte value;
/*    */   
/*    */   private SQLServerEncryptionType(byte paramByte) {
/* 18 */     this.value = paramByte;
/*    */   }
/*    */   
/*    */   byte getValue()
/*    */   {
/* 23 */     return this.value;
/*    */   }
/*    */   
/*    */   static SQLServerEncryptionType of(byte paramByte) throws SQLServerException
/*    */   {
/* 28 */     for (SQLServerEncryptionType localSQLServerEncryptionType : ) {
/* 29 */       if (paramByte == localSQLServerEncryptionType.value) {
/* 30 */         return localSQLServerEncryptionType;
/*    */       }
/*    */     }
/* 33 */     ??? = new MessageFormat(SQLServerException.getErrString("R_unknownColumnEncryptionType"));
/* 34 */     Object[] arrayOfObject = { Byte.valueOf(paramByte) };
/* 35 */     SQLServerException.makeFromDriverError(null, null, ((MessageFormat)???).format(arrayOfObject), null, true);
/*    */     
/*    */ 
/* 38 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerEncryptionType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */