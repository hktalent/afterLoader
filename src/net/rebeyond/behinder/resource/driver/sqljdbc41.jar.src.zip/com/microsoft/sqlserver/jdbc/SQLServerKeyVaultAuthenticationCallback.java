package com.microsoft.sqlserver.jdbc;

public abstract interface SQLServerKeyVaultAuthenticationCallback
{
  public abstract String getAccessToken(String paramString1, String paramString2, String paramString3);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerKeyVaultAuthenticationCallback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */