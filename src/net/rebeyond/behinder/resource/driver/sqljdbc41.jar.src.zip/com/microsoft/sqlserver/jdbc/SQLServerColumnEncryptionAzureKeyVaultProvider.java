/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.microsoft.azure.keyvault.KeyVaultClient;
/*     */ import com.microsoft.azure.keyvault.KeyVaultClientImpl;
/*     */ import com.microsoft.azure.keyvault.models.KeyBundle;
/*     */ import com.microsoft.azure.keyvault.models.KeyOperationResult;
/*     */ import com.microsoft.azure.keyvault.webkey.JsonWebKey;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.http.impl.client.HttpClientBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerColumnEncryptionAzureKeyVaultProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  39 */   String name = "AZURE_KEY_VAULT";
/*     */   
/*  41 */   private final String azureKeyVaultDomainName = "vault.azure.net";
/*     */   
/*  43 */   private final String rsaEncryptionAlgorithmWithOAEPForAKV = "RSA-OAEP";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private final byte[] firstVersion = { 1 };
/*     */   
/*     */   private KeyVaultClient keyVaultClient;
/*     */   
/*     */   private KeyVaultCredential credential;
/*     */   
/*     */ 
/*     */   public void setName(String paramString)
/*     */   {
/*  57 */     this.name = paramString;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  62 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SQLServerColumnEncryptionAzureKeyVaultProvider(SQLServerKeyVaultAuthenticationCallback paramSQLServerKeyVaultAuthenticationCallback, ExecutorService paramExecutorService)
/*     */     throws SQLServerException
/*     */   {
/*  73 */     if (null == paramSQLServerKeyVaultAuthenticationCallback) {
/*  74 */       localObject = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/*  75 */       Object[] arrayOfObject = { "SQLServerKeyVaultAuthenticationCallback" };
/*  76 */       throw new SQLServerException(((MessageFormat)localObject).format(arrayOfObject), null);
/*     */     }
/*  78 */     this.credential = new KeyVaultCredential(paramSQLServerKeyVaultAuthenticationCallback);
/*  79 */     Object localObject = HttpClientBuilder.create();
/*  80 */     this.keyVaultClient = new KeyVaultClientImpl((HttpClientBuilder)localObject, paramExecutorService, this.credential);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/*  97 */     ValidateNonEmptyAKVPath(paramString1);
/*     */     
/*  99 */     if (null == paramArrayOfByte)
/*     */     {
/* 101 */       throw new SQLServerException(SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null);
/*     */     }
/*     */     
/* 104 */     if (0 == paramArrayOfByte.length)
/*     */     {
/* 106 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null);
/*     */     }
/*     */     
/*     */ 
/* 110 */     paramString2 = validateEncryptionAlgorithm(paramString2);
/*     */     
/*     */ 
/* 113 */     int i = getAKVKeySize(paramString1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */     if (paramArrayOfByte[0] != this.firstVersion[0])
/*     */     {
/* 125 */       MessageFormat localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidEcryptionAlgorithmVersion"));
/* 126 */       Object[] arrayOfObject1 = { String.format("%02X ", new Object[] { Byte.valueOf(paramArrayOfByte[0]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.firstVersion[0]) }) };
/* 127 */       throw new SQLServerException(this, localMessageFormat1.format(arrayOfObject1), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 131 */     int j = this.firstVersion.length;
/* 132 */     int k = convertTwoBytesToShort(paramArrayOfByte, j);
/*     */     
/* 134 */     j += 2;
/*     */     
/*     */ 
/* 137 */     int m = convertTwoBytesToShort(paramArrayOfByte, j);
/* 138 */     j += 2;
/*     */     
/*     */ 
/*     */ 
/* 142 */     j += k;
/*     */     
/*     */ 
/* 145 */     if (m != i)
/*     */     {
/* 147 */       MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_AKVKeyLengthError"));
/* 148 */       localObject1 = new Object[] { Short.valueOf(m), Integer.valueOf(i), paramString1 };
/* 149 */       throw new SQLServerException(this, localMessageFormat2.format(localObject1), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 153 */     int n = paramArrayOfByte.length - j - m;
/*     */     
/* 155 */     if (n != i)
/*     */     {
/* 157 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_AKVSignatureLengthError"));
/* 158 */       localObject2 = new Object[] { Integer.valueOf(n), Integer.valueOf(i), paramString1 };
/* 159 */       throw new SQLServerException(this, ((MessageFormat)localObject1).format(localObject2), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 163 */     Object localObject1 = new byte[m];
/* 164 */     System.arraycopy(paramArrayOfByte, j, localObject1, 0, m);
/* 165 */     j += m;
/*     */     
/*     */ 
/* 168 */     Object localObject2 = new byte[n];
/* 169 */     System.arraycopy(paramArrayOfByte, j, localObject2, 0, n);
/*     */     
/*     */ 
/* 172 */     byte[] arrayOfByte1 = new byte[paramArrayOfByte.length - localObject2.length];
/*     */     
/* 174 */     System.arraycopy(paramArrayOfByte, 0, arrayOfByte1, 0, paramArrayOfByte.length - localObject2.length);
/*     */     
/*     */ 
/* 177 */     MessageDigest localMessageDigest = null;
/*     */     try {
/* 179 */       localMessageDigest = MessageDigest.getInstance("SHA-256");
/*     */     } catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {
/* 181 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), null);
/*     */     }
/* 183 */     localMessageDigest.update(arrayOfByte1);
/* 184 */     byte[] arrayOfByte2 = localMessageDigest.digest();
/*     */     
/* 186 */     if (null == arrayOfByte2)
/*     */     {
/* 188 */       throw new SQLServerException(SQLServerException.getErrString("R_HashNull"), null);
/*     */     }
/*     */     
/*     */ 
/* 192 */     if (!AzureKeyVaultVerifySignature(arrayOfByte2, (byte[])localObject2, paramString1))
/*     */     {
/* 194 */       localObject3 = new MessageFormat(SQLServerException.getErrString("R_CEKSignatureNotMatchCMK"));
/* 195 */       Object[] arrayOfObject2 = { paramString1 };
/* 196 */       throw new SQLServerException(this, ((MessageFormat)localObject3).format(arrayOfObject2), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 200 */     Object localObject3 = AzureKeyVaultUnWrap(paramString1, paramString2, (byte[])localObject1);
/*     */     
/* 202 */     return (byte[])localObject3;
/*     */   }
/*     */   
/*     */   private short convertTwoBytesToShort(byte[] paramArrayOfByte, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 208 */     short s = -1;
/* 209 */     if (paramInt + 1 >= paramArrayOfByte.length)
/*     */     {
/* 211 */       throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 218 */     ByteBuffer localByteBuffer = ByteBuffer.allocate(2);
/* 219 */     localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 220 */     localByteBuffer.put(paramArrayOfByte[paramInt]);
/* 221 */     localByteBuffer.put(paramArrayOfByte[(paramInt + 1)]);
/* 222 */     s = localByteBuffer.getShort(0);
/* 223 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/* 241 */     ValidateNonEmptyAKVPath(paramString1);
/*     */     
/* 243 */     if (null == paramArrayOfByte)
/*     */     {
/* 245 */       throw new SQLServerException(SQLServerException.getErrString("R_NullColumnEncryptionKey"), null);
/*     */     }
/*     */     
/* 248 */     if (0 == paramArrayOfByte.length)
/*     */     {
/* 250 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyCEK"), null);
/*     */     }
/*     */     
/*     */ 
/* 254 */     paramString2 = validateEncryptionAlgorithm(paramString2);
/*     */     
/*     */ 
/* 257 */     int i = getAKVKeySize(paramString1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 264 */     byte[] arrayOfByte1 = { this.firstVersion[0] };
/*     */     
/*     */ 
/* 267 */     byte[] arrayOfByte2 = null;
/*     */     try {
/* 269 */       arrayOfByte2 = paramString1.toLowerCase().getBytes("UTF-16LE");
/*     */     } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 271 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*     */       
/* 273 */       localObject2 = new Object[] { "UTF-16LE" };
/* 274 */       throw new SQLServerException(this, ((MessageFormat)localObject1).format(localObject2), null, 0, false);
/*     */     }
/*     */     
/* 277 */     byte[] arrayOfByte3 = new byte[2];
/* 278 */     arrayOfByte3[0] = ((byte)((short)arrayOfByte2.length & 0xFF));
/* 279 */     arrayOfByte3[1] = ((byte)((short)arrayOfByte2.length >> 8 & 0xFF));
/*     */     
/*     */ 
/* 282 */     Object localObject1 = AzureKeyVaultWrap(paramString1, paramString2, paramArrayOfByte);
/*     */     
/* 284 */     Object localObject2 = new byte[2];
/* 285 */     localObject2[0] = ((byte)((short)localObject1.length & 0xFF));
/* 286 */     localObject2[1] = ((byte)((short)localObject1.length >> 8 & 0xFF));
/*     */     
/* 288 */     if (localObject1.length != i)
/*     */     {
/* 290 */       throw new SQLServerException(SQLServerException.getErrString("R_CipherTextLengthNotMatchRSASize"), null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 295 */     byte[] arrayOfByte4 = new byte[arrayOfByte1.length + arrayOfByte3.length + localObject2.length + arrayOfByte2.length + localObject1.length];
/* 296 */     int j = arrayOfByte1.length;
/* 297 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte4, 0, arrayOfByte1.length);
/*     */     
/* 299 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte4, j, arrayOfByte3.length);
/* 300 */     j += arrayOfByte3.length;
/*     */     
/* 302 */     System.arraycopy(localObject2, 0, arrayOfByte4, j, localObject2.length);
/* 303 */     j += localObject2.length;
/*     */     
/* 305 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte4, j, arrayOfByte2.length);
/* 306 */     j += arrayOfByte2.length;
/*     */     
/* 308 */     System.arraycopy(localObject1, 0, arrayOfByte4, j, localObject1.length);
/*     */     
/* 310 */     MessageDigest localMessageDigest = null;
/*     */     try {
/* 312 */       localMessageDigest = MessageDigest.getInstance("SHA-256");
/*     */     } catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {
/* 314 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), null);
/*     */     }
/* 316 */     localMessageDigest.update(arrayOfByte4);
/* 317 */     byte[] arrayOfByte5 = localMessageDigest.digest();
/*     */     
/*     */ 
/* 320 */     byte[] arrayOfByte6 = null;
/* 321 */     arrayOfByte6 = AzureKeyVaultSignHashedData(arrayOfByte5, paramString1);
/*     */     
/* 323 */     if (arrayOfByte6.length != i)
/*     */     {
/* 325 */       throw new SQLServerException(SQLServerException.getErrString("R_SignedHashLengthError"), null);
/*     */     }
/*     */     
/* 328 */     if (!AzureKeyVaultVerifySignature(arrayOfByte5, arrayOfByte6, paramString1))
/*     */     {
/* 330 */       throw new SQLServerException(SQLServerException.getErrString("R_InvalidSignatureComputed"), null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 335 */     int k = arrayOfByte1.length + localObject2.length + arrayOfByte3.length + localObject1.length + arrayOfByte2.length + arrayOfByte6.length;
/* 336 */     byte[] arrayOfByte7 = new byte[k];
/*     */     
/*     */ 
/* 339 */     int m = 0;
/* 340 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte7, m, arrayOfByte1.length);
/* 341 */     m += arrayOfByte1.length;
/*     */     
/*     */ 
/* 344 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte7, m, arrayOfByte3.length);
/* 345 */     m += arrayOfByte3.length;
/*     */     
/*     */ 
/* 348 */     System.arraycopy(localObject2, 0, arrayOfByte7, m, localObject2.length);
/* 349 */     m += localObject2.length;
/*     */     
/*     */ 
/* 352 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte7, m, arrayOfByte2.length);
/* 353 */     m += arrayOfByte2.length;
/*     */     
/*     */ 
/* 356 */     System.arraycopy(localObject1, 0, arrayOfByte7, m, localObject1.length);
/* 357 */     m += localObject1.length;
/*     */     
/*     */ 
/* 360 */     System.arraycopy(arrayOfByte6, 0, arrayOfByte7, m, arrayOfByte6.length);
/*     */     
/* 362 */     return arrayOfByte7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String validateEncryptionAlgorithm(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 375 */     if (null == paramString)
/*     */     {
/* 377 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullKeyEncryptionAlgorithm"), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     if (paramString.equalsIgnoreCase("RSA_OAEP"))
/*     */     {
/* 388 */       paramString = "RSA-OAEP";
/*     */     }
/*     */     
/* 391 */     if (!"RSA-OAEP".equalsIgnoreCase(paramString.trim()))
/*     */     {
/* 393 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidKeyEncryptionAlgorithm"));
/*     */       
/* 395 */       Object[] arrayOfObject = { paramString, "RSA-OAEP" };
/* 396 */       throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 400 */     return paramString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ValidateNonEmptyAKVPath(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 412 */     if ((null == paramString) || (paramString.trim().isEmpty()))
/*     */     {
/* 414 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_AKVPathNull"));
/* 415 */       Object[] arrayOfObject1 = { paramString };
/* 416 */       throw new SQLServerException(null, ((MessageFormat)localObject1).format(arrayOfObject1), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 420 */     Object localObject1 = null;
/*     */     Object localObject2;
/* 422 */     try { localObject1 = new URI(paramString);
/*     */     } catch (URISyntaxException localURISyntaxException) {
/* 424 */       localObject2 = new MessageFormat(SQLServerException.getErrString("R_AKVURLInvalid"));
/* 425 */       Object[] arrayOfObject2 = { paramString };
/* 426 */       throw new SQLServerException(null, ((MessageFormat)localObject2).format(arrayOfObject2), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 431 */     if (!((URI)localObject1).getHost().toLowerCase().endsWith("vault.azure.net"))
/*     */     {
/* 433 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVMasterKeyPathInvalid"));
/* 434 */       localObject2 = new Object[] { paramString };
/* 435 */       throw new SQLServerException(null, localMessageFormat.format(localObject2), null, 0, false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] AzureKeyVaultWrap(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/* 451 */     if (null == paramArrayOfByte)
/*     */     {
/* 453 */       throw new SQLServerException(SQLServerException.getErrString("R_CEKNull"), null);
/*     */     }
/*     */     
/* 456 */     KeyOperationResult localKeyOperationResult = null;
/*     */     try {
/* 458 */       localKeyOperationResult = (KeyOperationResult)this.keyVaultClient.wrapKeyAsync(paramString1, paramString2, paramArrayOfByte).get();
/*     */     } catch (InterruptedException|ExecutionException localInterruptedException) {
/* 460 */       throw new SQLServerException(SQLServerException.getErrString("R_EncryptCEKError"), null);
/*     */     }
/* 462 */     return localKeyOperationResult.getResult();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] AzureKeyVaultUnWrap(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/* 476 */     if (null == paramArrayOfByte)
/*     */     {
/* 478 */       throw new SQLServerException(SQLServerException.getErrString("R_EncryptedCEKNull"), null);
/*     */     }
/*     */     
/* 481 */     if (0 == paramArrayOfByte.length)
/*     */     {
/* 483 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedCEK"), null);
/*     */     }
/*     */     KeyOperationResult localKeyOperationResult;
/*     */     try
/*     */     {
/* 488 */       localKeyOperationResult = (KeyOperationResult)this.keyVaultClient.unwrapKeyAsync(paramString1, paramString2, paramArrayOfByte).get();
/*     */     } catch (InterruptedException|ExecutionException localInterruptedException) {
/* 490 */       throw new SQLServerException(SQLServerException.getErrString("R_DecryptCEKError"), null);
/*     */     }
/* 492 */     return localKeyOperationResult.getResult();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] AzureKeyVaultSignHashedData(byte[] paramArrayOfByte, String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 505 */     assert ((null != paramArrayOfByte) && (0 != paramArrayOfByte.length));
/*     */     
/* 507 */     KeyOperationResult localKeyOperationResult = null;
/*     */     try {
/* 509 */       localKeyOperationResult = (KeyOperationResult)this.keyVaultClient.signAsync(paramString, "RS256", paramArrayOfByte).get();
/*     */     } catch (InterruptedException|ExecutionException localInterruptedException) {
/* 511 */       throw new SQLServerException(SQLServerException.getErrString("R_GenerateSignature"), null);
/*     */     }
/* 513 */     return localKeyOperationResult.getResult();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean AzureKeyVaultVerifySignature(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 527 */     assert ((null != paramArrayOfByte1) && (0 != paramArrayOfByte1.length));
/* 528 */     assert ((null != paramArrayOfByte2) && (0 != paramArrayOfByte2.length));
/*     */     
/* 530 */     boolean bool = false;
/*     */     try {
/* 532 */       bool = ((Boolean)this.keyVaultClient.verifyAsync(paramString, "RS256", paramArrayOfByte1, paramArrayOfByte2).get()).booleanValue();
/*     */     } catch (InterruptedException|ExecutionException localInterruptedException) {
/* 534 */       throw new SQLServerException(SQLServerException.getErrString("R_VerifySignature"), null);
/*     */     }
/*     */     
/* 537 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getAKVKeySize(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 550 */     KeyBundle localKeyBundle = null;
/*     */     try {
/* 552 */       localKeyBundle = (KeyBundle)this.keyVaultClient.getKeyAsync(paramString).get();
/*     */     } catch (InterruptedException|ExecutionException localInterruptedException) {
/* 554 */       throw new SQLServerException(SQLServerException.getErrString("R_GetAKVKeySize"), null);
/*     */     }
/*     */     
/* 557 */     if ((!localKeyBundle.getKey().getKty().equalsIgnoreCase("RSA")) && (!localKeyBundle.getKey().getKty().equalsIgnoreCase("RSA-HSM")))
/*     */     {
/*     */ 
/* 560 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_NonRSAKey"));
/* 561 */       Object[] arrayOfObject = { localKeyBundle.getKey().getKty() };
/* 562 */       throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/*     */     
/* 565 */     return localKeyBundle.getKey().getN().length;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerColumnEncryptionAzureKeyVaultProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */