/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */  enum SQLState
/*    */ {
/* 17 */   STATEMENT_CANCELED("HY008"), 
/* 18 */   DATA_EXCEPTION_NOT_SPECIFIC("22000"), 
/* 19 */   DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW("22008"), 
/* 20 */   DATA_EXCEPTION_LENGTH_MISMATCH("22026"), 
/* 21 */   COL_NOT_FOUND("42S22");
/*    */   
/*    */   final String getSQLStateCode() {
/* 24 */     return this.sqlStateCode;
/*    */   }
/*    */   
/*    */   private final String sqlStateCode;
/* 28 */   private SQLState(String paramString) { this.sqlStateCode = paramString; }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLState.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */