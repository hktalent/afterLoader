/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PLPXMLInputStream
/*     */   extends PLPInputStream
/*     */ {
/* 411 */   private static final byte[] xmlBOM = { -1, -2 };
/* 412 */   private final ByteArrayInputStream bomStream = new ByteArrayInputStream(xmlBOM);
/*     */   
/*     */   static final PLPXMLInputStream makeXMLStream(TDSReader paramTDSReader, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl)
/*     */     throws SQLServerException
/*     */   {
/* 417 */     long l = paramTDSReader.readLong();
/*     */     
/*     */ 
/* 420 */     if (-1L == l) {
/* 421 */       return null;
/*     */     }
/* 423 */     PLPXMLInputStream localPLPXMLInputStream = new PLPXMLInputStream(paramTDSReader, l, paramInputStreamGetterArgs, paramServerDTVImpl);
/* 424 */     if (null != localPLPXMLInputStream) {
/* 425 */       localPLPXMLInputStream.setLoggingInfo(paramInputStreamGetterArgs.logContext);
/*     */     }
/* 427 */     return localPLPXMLInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   PLPXMLInputStream(TDSReader paramTDSReader, long paramLong, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl)
/*     */     throws SQLServerException
/*     */   {
/* 436 */     super(paramTDSReader, paramLong, paramInputStreamGetterArgs.isAdaptive, paramInputStreamGetterArgs.isStreaming, paramServerDTVImpl);
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 441 */     super.close();
/*     */   }
/*     */   
/*     */   int readBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*     */   {
/* 446 */     assert (paramInt1 >= 0);
/* 447 */     assert (paramInt2 >= 0);
/*     */     
/* 449 */     if (0 == paramInt2) {
/* 450 */       return 0;
/*     */     }
/* 452 */     int i = 0;
/* 453 */     int j = 0;
/*     */     
/*     */     int k;
/* 456 */     if (null == paramArrayOfByte)
/*     */     {
/* 458 */       k = 0;
/* 459 */       while ((i < paramInt2) && (0 != (k = (int)this.bomStream.skip(paramInt2 - i)))) {
/* 460 */         i += k;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 465 */       k = 0;
/* 466 */       while ((i < paramInt2) && (-1 != (k = this.bomStream.read(paramArrayOfByte, paramInt1 + i, paramInt2 - i)))) {
/* 467 */         i += k;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 473 */     while ((i < paramInt2) && (-1 != (j = super.readBytes(paramArrayOfByte, paramInt1 + i, paramInt2 - i)))) {
/* 474 */       i += j;
/*     */     }
/*     */     
/* 477 */     if (i > 0) {
/* 478 */       return i;
/*     */     }
/*     */     
/* 481 */     assert (-1 == j);
/* 482 */     return -1;
/*     */   }
/*     */   
/*     */   public void mark(int paramInt)
/*     */   {
/* 487 */     this.bomStream.mark(xmlBOM.length);
/* 488 */     super.mark(paramInt);
/*     */   }
/*     */   
/*     */   public void reset() throws IOException
/*     */   {
/* 493 */     this.bomStream.reset();
/* 494 */     super.reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */     throws SQLServerException
/*     */   {
/* 505 */     byte[] arrayOfByte1 = new byte[2];
/*     */     try
/*     */     {
/* 508 */       int i = this.bomStream.read(arrayOfByte1);
/* 509 */       byte[] arrayOfByte2 = super.getBytes();
/*     */       
/* 511 */       if (i > 0)
/*     */       {
/* 513 */         assert (2 == i);
/* 514 */         byte[] arrayOfByte3 = new byte[arrayOfByte2.length + i];
/* 515 */         System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, i);
/* 516 */         System.arraycopy(arrayOfByte2, 0, arrayOfByte3, i, arrayOfByte2.length);
/* 517 */         return arrayOfByte3;
/*     */       }
/*     */       
/* 520 */       return arrayOfByte2;
/*     */     }
/*     */     catch (IOException localIOException) {
/* 523 */       SQLServerException.makeFromDriverError(null, null, localIOException.getMessage(), null, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 531 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/PLPXMLInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */