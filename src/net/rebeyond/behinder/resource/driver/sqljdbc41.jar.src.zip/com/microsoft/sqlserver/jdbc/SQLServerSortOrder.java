/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ public enum SQLServerSortOrder {
/*  4 */   Ascending(0), 
/*  5 */   Descending(1), 
/*  6 */   Unspecified(-1);
/*    */   
/*    */   int value;
/*    */   
/*    */   private SQLServerSortOrder(int paramInt) {
/* 11 */     this.value = paramInt;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSortOrder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */