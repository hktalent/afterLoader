/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AuthenticationJNI
/*     */   extends SSPIAuthentication
/*     */ {
/*     */   private static final int maximumpointersize = 128;
/*     */   private static boolean enabled;
/*     */   private static Logger authLogger;
/*     */   private static int sspiBlobMaxlen;
/*  25 */   private byte[] sniSec = new byte[''];
/*  26 */   private int[] sniSecLen = { 0 };
/*     */   private final String DNSName;
/*     */   private final int port;
/*     */   private SQLServerConnection con;
/*     */   private static final UnsatisfiedLinkError linkError;
/*     */   
/*  32 */   static int GetMaxSSPIBlobSize() { return sspiBlobMaxlen; }
/*     */   
/*     */   static
/*     */   {
/*  22 */     enabled = false;
/*  23 */     authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.AuthenticationJNI");
/*  24 */     sspiBlobMaxlen = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  36 */     Object localObject1 = null;
/*     */     
/*     */     try
/*     */     {
/*  40 */       String str = "sqljdbc_auth";
/*  41 */       System.loadLibrary(str);
/*  42 */       int[] arrayOfInt = new int[1];
/*  43 */       arrayOfInt[0] = 0;
/*  44 */       if (0 == SNISecInitPackage(arrayOfInt, authLogger))
/*     */       {
/*  46 */         sspiBlobMaxlen = arrayOfInt[0];
/*     */       }
/*     */       else
/*  49 */         throw new UnsatisfiedLinkError();
/*  50 */       enabled = true;
/*     */     }
/*     */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
/*     */     {
/*  54 */       localObject1 = localUnsatisfiedLinkError;
/*  55 */       authLogger.warning("Failed to load the sqljdbc_auth.dll cause : " + localUnsatisfiedLinkError.getMessage());
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*  60 */       linkError = (UnsatisfiedLinkError)localObject1;
/*     */     }
/*     */   }
/*     */   
/*     */   AuthenticationJNI(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/*  67 */     if (!enabled) {
/*  68 */       paramSQLServerConnection.terminate(0, SQLServerException.getErrString("R_notConfiguredForIntegrated"), linkError);
/*     */     }
/*  70 */     this.con = paramSQLServerConnection;
/*  71 */     this.DNSName = GetDNSName(paramString);
/*  72 */     this.port = paramInt;
/*     */   }
/*     */   
/*     */   static FedAuthDllInfo getAccessTokenForWindowsIntegrated(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong) throws DLLException {
/*  76 */     FedAuthDllInfo localFedAuthDllInfo = ADALGetAccessTokenForWindowsIntegrated(paramString1, paramString2, paramString3, paramString4, paramLong, authLogger);
/*  77 */     return localFedAuthDllInfo;
/*     */   }
/*     */   
/*     */   static FedAuthDllInfo getAccessToken(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, long paramLong) throws DLLException {
/*  81 */     FedAuthDllInfo localFedAuthDllInfo = ADALGetAccessToken(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramLong, authLogger);
/*  82 */     return localFedAuthDllInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] GenerateClientContext(byte[] paramArrayOfByte, boolean[] paramArrayOfBoolean)
/*     */     throws SQLServerException
/*     */   {
/*  91 */     int[] arrayOfInt = new int[1];
/*  92 */     arrayOfInt[0] = GetMaxSSPIBlobSize();
/*  93 */     byte[] arrayOfByte1 = new byte[arrayOfInt[0]];
/*     */     
/*     */ 
/*  96 */     assert (this.DNSName != null);
/*     */     
/*  98 */     int i = SNISecGenClientContext(this.sniSec, this.sniSecLen, paramArrayOfByte, paramArrayOfByte.length, arrayOfByte1, arrayOfInt, paramArrayOfBoolean, this.DNSName, this.port, null, null, authLogger);
/*     */     
/* 100 */     if (i != 0)
/*     */     {
/* 102 */       authLogger.warning(toString() + " Authentication failed code : " + i);
/* 103 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), linkError);
/*     */     }
/*     */     
/* 106 */     byte[] arrayOfByte2 = new byte[arrayOfInt[0]];
/* 107 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfInt[0]);
/* 108 */     return arrayOfByte2;
/*     */   }
/*     */   
/*     */ 
/*     */   int ReleaseClientContext()
/*     */   {
/* 114 */     int i = 0;
/* 115 */     if (this.sniSecLen[0] > 0)
/*     */     {
/* 117 */       i = SNISecReleaseClientContext(this.sniSec, this.sniSecLen[0], authLogger);
/* 118 */       this.sniSecLen[0] = 0;
/*     */     }
/* 120 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */   private static String GetDNSName(String paramString)
/*     */   {
/* 126 */     String[] arrayOfString = new String[1];
/* 127 */     if (GetDNSName(paramString, arrayOfString, authLogger) != 0)
/*     */     {
/*     */ 
/* 130 */       arrayOfString[0] = paramString;
/*     */     }
/* 132 */     return arrayOfString[0];
/*     */   }
/*     */   
/*     */   private static native int SNISecGenClientContext(byte[] paramArrayOfByte1, int[] paramArrayOfInt1, byte[] paramArrayOfByte2, int paramInt1, byte[] paramArrayOfByte3, int[] paramArrayOfInt2, boolean[] paramArrayOfBoolean, String paramString1, int paramInt2, String paramString2, String paramString3, Logger paramLogger);
/*     */   
/*     */   private static native int SNISecReleaseClientContext(byte[] paramArrayOfByte, int paramInt, Logger paramLogger);
/*     */   
/*     */   private static native int SNISecInitPackage(int[] paramArrayOfInt, Logger paramLogger);
/*     */   
/*     */   private static native int SNISecTerminatePackage(Logger paramLogger);
/*     */   
/*     */   private static native int SNIGetSID(byte[] paramArrayOfByte, Logger paramLogger);
/*     */   
/*     */   private static native boolean SNIIsEqualToCurrentSID(byte[] paramArrayOfByte, Logger paramLogger);
/*     */   
/*     */   private static native int GetDNSName(String paramString, String[] paramArrayOfString, Logger paramLogger);
/*     */   
/*     */   private static native FedAuthDllInfo ADALGetAccessTokenForWindowsIntegrated(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong, Logger paramLogger);
/*     */   
/*     */   private static native FedAuthDllInfo ADALGetAccessToken(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, long paramLong, Logger paramLogger);
/*     */   
/*     */   static native byte[] DecryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws DLLException;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/AuthenticationJNI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */