/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.UUID;
/*     */ import microsoft.sql.DateTimeOffset;
/*     */ 
/*     */ public final class SQLServerDataTable
/*     */ {
/*  14 */   int rowCount = 0;
/*  15 */   int columnCount = 0;
/*  16 */   Map<Integer, SQLServerDataColumn> columnMetadata = null;
/*  17 */   Map<Integer, Object[]> rows = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SQLServerDataTable()
/*     */     throws SQLServerException
/*     */   {
/*  26 */     this.columnMetadata = new java.util.LinkedHashMap();
/*  27 */     this.rows = new java.util.HashMap();
/*     */   }
/*     */   
/*     */   public synchronized void clear()
/*     */   {
/*  32 */     this.rowCount = 0;
/*  33 */     this.columnCount = 0;
/*  34 */     this.columnMetadata.clear();
/*  35 */     this.rows.clear();
/*     */   }
/*     */   
/*     */   public synchronized Iterator<Map.Entry<Integer, Object[]>> getIterator()
/*     */   {
/*  40 */     if ((null != this.rows) && (null != this.rows.entrySet()))
/*     */     {
/*  42 */       return this.rows.entrySet().iterator();
/*     */     }
/*  44 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void addColumnMetadata(String paramString, int paramInt)
/*     */     throws SQLServerException
/*     */   {
/*  51 */     Util.checkDuplicateColumnName(paramString, this.columnMetadata);
/*  52 */     this.columnMetadata.put(Integer.valueOf(this.columnCount++), new SQLServerDataColumn(paramString, paramInt));
/*     */   }
/*     */   
/*     */   public synchronized void addColumnMetadata(SQLServerDataColumn paramSQLServerDataColumn)
/*     */     throws SQLServerException
/*     */   {
/*  58 */     Util.checkDuplicateColumnName(paramSQLServerDataColumn.columnName, this.columnMetadata);
/*  59 */     this.columnMetadata.put(Integer.valueOf(this.columnCount++), paramSQLServerDataColumn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addRow(Object... paramVarArgs)
/*     */     throws SQLServerException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       int i = this.columnMetadata.size();
/*     */       
/*  74 */       if ((null != paramVarArgs) && (paramVarArgs.length > i))
/*     */       {
/*  76 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_moreDataInRowThanColumnInTVP"));
/*  77 */         arrayOfObject1 = new Object[0];
/*  78 */         throw new SQLServerException(null, ((MessageFormat)localObject1).format(arrayOfObject1), null, 0, false);
/*     */       }
/*     */       
/*  81 */       Object localObject1 = this.columnMetadata.entrySet().iterator();
/*  82 */       Object[] arrayOfObject1 = new Object[i];
/*  83 */       int j = 0;
/*  84 */       while (((Iterator)localObject1).hasNext())
/*     */       {
/*  86 */         Object localObject2 = null;
/*     */         
/*     */ 
/*     */ 
/*  90 */         if ((null != paramVarArgs) && (j < paramVarArgs.length) && (null != paramVarArgs[j]))
/*  91 */           localObject2 = null == paramVarArgs[j] ? null : paramVarArgs[j];
/*  92 */         j++;
/*  93 */         Map.Entry localEntry = (Map.Entry)((Iterator)localObject1).next();
/*  94 */         SQLServerDataColumn localSQLServerDataColumn = (SQLServerDataColumn)localEntry.getValue();
/*  95 */         JDBCType localJDBCType = JDBCType.of(((SQLServerDataColumn)localEntry.getValue()).javaSqlType);
/*     */         
/*  97 */         int n = 0;
/*  98 */         int k; int m; switch (localJDBCType)
/*     */         {
/*     */         case BIGINT: 
/* 101 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (null == localObject2 ? null : Long.valueOf(Long.parseLong(localObject2.toString())));
/* 102 */           break;
/*     */         
/*     */         case BIT: 
/* 105 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (null == localObject2 ? null : Boolean.valueOf(Boolean.parseBoolean(localObject2.toString())));
/* 106 */           break;
/*     */         
/*     */         case INTEGER: 
/* 109 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (null == localObject2 ? null : Integer.valueOf(Integer.parseInt(localObject2.toString())));
/* 110 */           break;
/*     */         
/*     */         case SMALLINT: 
/*     */         case TINYINT: 
/* 114 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (null == localObject2 ? null : Short.valueOf(Short.parseShort(localObject2.toString())));
/* 115 */           break;
/*     */         
/*     */         case DECIMAL: 
/*     */         case NUMERIC: 
/* 119 */           BigDecimal localBigDecimal = null;
/* 120 */           if (null != localObject2)
/*     */           {
/* 122 */             localBigDecimal = new BigDecimal(localObject2.toString());
/* 123 */             if (localBigDecimal.scale() > localSQLServerDataColumn.scale)
/*     */             {
/* 125 */               localSQLServerDataColumn.scale = localBigDecimal.scale();
/* 126 */               n = 1;
/*     */             }
/* 128 */             if (localBigDecimal.precision() > localSQLServerDataColumn.precision)
/*     */             {
/* 130 */               localSQLServerDataColumn.precision = localBigDecimal.precision();
/* 131 */               n = 1;
/*     */             }
/* 133 */             if (n != 0)
/* 134 */               this.columnMetadata.put(localEntry.getKey(), localSQLServerDataColumn);
/*     */           }
/* 136 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = localBigDecimal;
/* 137 */           break;
/*     */         
/*     */         case DOUBLE: 
/* 140 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (null == localObject2 ? null : Double.valueOf(Double.parseDouble(localObject2.toString())));
/* 141 */           break;
/*     */         
/*     */         case FLOAT: 
/*     */         case REAL: 
/* 145 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (null == localObject2 ? null : Float.valueOf(Float.parseFloat(localObject2.toString())));
/* 146 */           break;
/*     */         
/*     */         case TIMESTAMP_WITH_TIMEZONE: 
/*     */         case TIME_WITH_TIMEZONE: 
/* 150 */           DriverJDBCVersion.checkSupportsJDBC42();
/*     */         
/*     */ 
/*     */ 
/*     */         case DATE: 
/*     */         case TIME: 
/*     */         case TIMESTAMP: 
/*     */         case DATETIMEOFFSET: 
/* 158 */           if (null == localObject2) {
/* 159 */             arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = null;
/*     */           }
/* 161 */           else if ((localObject2 instanceof Date)) {
/* 162 */             arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = ((Date)localObject2).toString();
/* 163 */           } else if ((localObject2 instanceof DateTimeOffset)) {
/* 164 */             arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = ((DateTimeOffset)localObject2).toString();
/* 165 */           } else if ((localObject2 instanceof OffsetDateTime)) {
/* 166 */             arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = ((OffsetDateTime)localObject2).toString();
/* 167 */           } else if ((localObject2 instanceof OffsetTime)) {
/* 168 */             arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = ((OffsetTime)localObject2).toString();
/*     */           } else
/* 170 */             arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (null == localObject2 ? null : (String)localObject2);
/* 171 */           break;
/*     */         
/*     */         case BINARY: 
/*     */         case VARBINARY: 
/* 175 */           k = null == localObject2 ? 1 : 0;
/* 176 */           m = k != 0 ? 0 : ((byte[])localObject2).length;
/*     */           
/* 178 */           if (m > localSQLServerDataColumn.precision)
/*     */           {
/* 180 */             localSQLServerDataColumn.precision = m;
/* 181 */             this.columnMetadata.put(localEntry.getKey(), localSQLServerDataColumn);
/*     */           }
/* 183 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (k != 0 ? null : (byte[])(byte[])localObject2);
/*     */           
/* 185 */           break;
/*     */         
/*     */         case CHAR: 
/* 188 */           if (((localObject2 instanceof UUID)) && (localObject2 != null)) {
/* 189 */             localObject2 = ((UUID)localObject2).toString();
/*     */           }
/*     */         
/*     */         case VARCHAR: 
/*     */         case NCHAR: 
/*     */         case NVARCHAR: 
/* 195 */           k = null == localObject2 ? 1 : 0;
/* 196 */           m = k != 0 ? 0 : 2 * ((String)localObject2).length();
/*     */           
/* 198 */           if (m > localSQLServerDataColumn.precision)
/*     */           {
/* 200 */             localSQLServerDataColumn.precision = m;
/* 201 */             this.columnMetadata.put(localEntry.getKey(), localSQLServerDataColumn);
/*     */           }
/* 203 */           arrayOfObject1[((Integer)localEntry.getKey()).intValue()] = (k != 0 ? null : (String)localObject2);
/* 204 */           break;
/*     */         }
/*     */         
/* 207 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedDataTypeTVP"));
/* 208 */         Object[] arrayOfObject2 = { localJDBCType };
/* 209 */         throw new SQLServerException(null, localMessageFormat.format(arrayOfObject2), null, 0, false);
/*     */       }
/*     */       
/* 212 */       this.rows.put(Integer.valueOf(this.rowCount++), arrayOfObject1);
/*     */     }
/*     */     catch (NumberFormatException localNumberFormatException)
/*     */     {
/* 216 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), localNumberFormatException);
/*     */     }
/*     */     catch (ClassCastException localClassCastException)
/*     */     {
/* 220 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), localClassCastException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized Map<Integer, SQLServerDataColumn> getColumnMetadata()
/*     */   {
/* 227 */     return this.columnMetadata;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerDataTable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */