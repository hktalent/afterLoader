/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ActivityId
/*     */ {
/*     */   private final UUID Id;
/*     */   private long Sequence;
/*     */   private boolean isSentToServer;
/*     */   
/*     */   ActivityId()
/*     */   {
/*  60 */     this.Id = UUID.randomUUID();
/*  61 */     this.Sequence = 0L;
/*  62 */     this.isSentToServer = false;
/*     */   }
/*     */   
/*     */   UUID getId()
/*     */   {
/*  67 */     return this.Id;
/*     */   }
/*     */   
/*     */   long getSequence()
/*     */   {
/*  72 */     return this.Sequence;
/*     */   }
/*     */   
/*     */   void Increment()
/*     */   {
/*  77 */     if (this.Sequence < 4294967295L)
/*     */     {
/*  79 */       this.Sequence += 1L;
/*     */     }
/*     */     else
/*     */     {
/*  83 */       this.Sequence = 0L;
/*     */     }
/*     */     
/*  86 */     this.isSentToServer = false;
/*     */   }
/*     */   
/*     */   void setSentFlag()
/*     */   {
/*  91 */     this.isSentToServer = true;
/*     */   }
/*     */   
/*     */   boolean IsSentToServer()
/*     */   {
/*  96 */     return this.isSentToServer;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 101 */     StringBuilder localStringBuilder = new StringBuilder();
/* 102 */     localStringBuilder.append(this.Id.toString());
/* 103 */     localStringBuilder.append("-");
/* 104 */     localStringBuilder.append(this.Sequence);
/* 105 */     return localStringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ActivityId.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */