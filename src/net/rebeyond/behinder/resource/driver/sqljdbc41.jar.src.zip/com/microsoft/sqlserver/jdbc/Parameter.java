/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Locale;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Parameter
/*      */ {
/*      */   private TypeInfo typeInfo;
/*   28 */   CryptoMetadata cryptoMeta = null;
/*   29 */   TypeInfo getTypeInfo() { return this.typeInfo; }
/*   30 */   final CryptoMetadata getCryptoMetadata() { return this.cryptoMeta; }
/*      */   
/*   32 */   private boolean shouldHonorAEForParameter = false;
/*   33 */   private boolean userProvidesPrecision = false;
/*   34 */   private boolean userProvidesScale = false;
/*      */   
/*      */ 
/*   37 */   private String typeDefinition = null;
/*   38 */   boolean renewDefinition = false;
/*      */   
/*      */ 
/*   41 */   private JDBCType jdbcTypeSetByUser = null;
/*      */   
/*      */ 
/*   44 */   private int valueLength = 0;
/*      */   
/*   46 */   private boolean forceEncryption = false;
/*      */   
/*      */ 
/*      */   Parameter(boolean paramBoolean)
/*      */   {
/*   51 */     this.shouldHonorAEForParameter = paramBoolean;
/*      */   }
/*      */   
/*      */   boolean isOutput() {
/*   55 */     return null != this.registeredOutDTV;
/*      */   }
/*      */   
/*      */ 
/*      */   JDBCType getJdbcType()
/*      */     throws SQLServerException
/*      */   {
/*   62 */     return null != this.inputDTV ? this.inputDTV.getJdbcType() : JDBCType.UNKNOWN;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static JDBCType getSSPAUJDBCType(JDBCType paramJDBCType)
/*      */   {
/*   71 */     switch (paramJDBCType) {
/*      */     case CHAR: 
/*   73 */       return JDBCType.NCHAR;
/*   74 */     case VARCHAR:  return JDBCType.NVARCHAR;
/*   75 */     case LONGVARCHAR:  return JDBCType.LONGNVARCHAR;
/*   76 */     case CLOB:  return JDBCType.NCLOB; }
/*   77 */     return paramJDBCType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void registerForOutput(JDBCType paramJDBCType, SQLServerConnection paramSQLServerConnection)
/*      */     throws SQLServerException
/*      */   {
/*   87 */     if ((JDBCType.DATETIMEOFFSET == paramJDBCType) && (!paramSQLServerConnection.isKatmaiOrLater()))
/*      */     {
/*   89 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  100 */     if (paramSQLServerConnection.sendStringParametersAsUnicode())
/*      */     {
/*      */ 
/*  103 */       if (this.shouldHonorAEForParameter)
/*      */       {
/*  105 */         setJdbcTypeSetByUser(paramJDBCType);
/*      */       }
/*      */       
/*  108 */       paramJDBCType = getSSPAUJDBCType(paramJDBCType);
/*      */     }
/*      */     
/*  111 */     this.registeredOutDTV = new DTV();
/*  112 */     this.registeredOutDTV.setJdbcType(paramJDBCType);
/*      */     
/*  114 */     if (null == this.setterDTV) {
/*  115 */       this.inputDTV = this.registeredOutDTV;
/*      */     }
/*  117 */     resetOutputValue();
/*      */   }
/*      */   
/*  120 */   int scale = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  125 */   private int outScale = 4;
/*  126 */   int getOutScale() { return this.outScale; }
/*      */   
/*      */   void setOutScale(int paramInt) {
/*  129 */     this.outScale = paramInt;
/*  130 */     this.userProvidesScale = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DTV getterDTV;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  167 */   private DTV registeredOutDTV = null;
/*  168 */   private DTV setterDTV = null;
/*  169 */   private DTV inputDTV = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Parameter cloneForBatch()
/*      */   {
/*  183 */     Parameter localParameter = new Parameter(this.shouldHonorAEForParameter);
/*  184 */     localParameter.typeInfo = this.typeInfo;
/*  185 */     localParameter.typeDefinition = this.typeDefinition;
/*  186 */     localParameter.outScale = this.outScale;
/*  187 */     localParameter.name = this.name;
/*  188 */     localParameter.getterDTV = this.getterDTV;
/*  189 */     localParameter.registeredOutDTV = this.registeredOutDTV;
/*  190 */     localParameter.setterDTV = this.setterDTV;
/*  191 */     localParameter.inputDTV = this.inputDTV;
/*  192 */     localParameter.cryptoMeta = this.cryptoMeta;
/*  193 */     localParameter.jdbcTypeSetByUser = this.jdbcTypeSetByUser;
/*  194 */     localParameter.valueLength = this.valueLength;
/*  195 */     localParameter.userProvidesPrecision = this.userProvidesPrecision;
/*  196 */     localParameter.userProvidesScale = this.userProvidesScale;
/*  197 */     return localParameter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final void skipValue(TDSReader paramTDSReader, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*  205 */     if (null == this.getterDTV) {
/*  206 */       this.getterDTV = new DTV();
/*      */     }
/*  208 */     deriveTypeInfo(paramTDSReader);
/*      */     
/*  210 */     this.getterDTV.skipValue(this.typeInfo, paramTDSReader, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final void skipRetValStatus(TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/*  219 */     StreamRetValue localStreamRetValue = new StreamRetValue();
/*  220 */     localStreamRetValue.setFromTDS(paramTDSReader);
/*      */   }
/*      */   
/*      */ 
/*      */   void clearInputValue()
/*      */   {
/*  226 */     this.setterDTV = null;
/*  227 */     this.inputDTV = this.registeredOutDTV;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void resetOutputValue()
/*      */   {
/*  234 */     this.getterDTV = null;
/*  235 */     this.typeInfo = null;
/*      */   }
/*      */   
/*      */   void deriveTypeInfo(TDSReader paramTDSReader) throws SQLServerException
/*      */   {
/*  240 */     if (null == this.typeInfo)
/*      */     {
/*  242 */       this.typeInfo = TypeInfo.getInstance(paramTDSReader, true);
/*      */       
/*  244 */       if ((this.shouldHonorAEForParameter) && (this.typeInfo.isEncrypted()))
/*      */       {
/*      */ 
/*      */ 
/*  248 */         CekTableEntry localCekTableEntry = this.cryptoMeta.getCekTableEntry();
/*  249 */         this.cryptoMeta = new StreamRetValue().getCryptoMetadata(paramTDSReader);
/*  250 */         this.cryptoMeta.setCekTableEntry(localCekTableEntry);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void setFromReturnStatus(int paramInt, SQLServerConnection paramSQLServerConnection) throws SQLServerException
/*      */   {
/*  257 */     if (null == this.getterDTV) {
/*  258 */       this.getterDTV = new DTV();
/*      */     }
/*  260 */     this.getterDTV.setValue(null, JDBCType.INTEGER, new Integer(paramInt), JavaType.INTEGER, null, null, null, paramSQLServerConnection, getForceEncryption());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setValue(JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger1, Integer paramInteger2, SQLServerConnection paramSQLServerConnection, boolean paramBoolean, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, int paramInt, String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/*      */     Object localObject2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  278 */     if (this.shouldHonorAEForParameter)
/*      */     {
/*  280 */       this.userProvidesPrecision = false;
/*  281 */       this.userProvidesScale = false;
/*      */       
/*  283 */       if (null != paramInteger1) {
/*  284 */         this.userProvidesPrecision = true;
/*      */       }
/*      */       
/*  287 */       if (null != paramInteger2) {
/*  288 */         this.userProvidesScale = true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  295 */       if ((!isOutput()) && 
/*  296 */         (JavaType.SHORT == paramJavaType) && ((JDBCType.TINYINT == paramJDBCType) || (JDBCType.SMALLINT == paramJDBCType)))
/*      */       {
/*      */ 
/*  299 */         if ((((Short)paramObject).shortValue() >= 0) && (((Short)paramObject).shortValue() <= 255)) {
/*  300 */           paramObject = Byte.valueOf(((Short)paramObject).byteValue());
/*  301 */           paramJavaType = JavaType.of(paramObject);
/*  302 */           paramJDBCType = paramJavaType.getJDBCType(SSType.UNKNOWN, paramJDBCType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  308 */         else if (JDBCType.TINYINT == paramJDBCType)
/*      */         {
/*      */ 
/*  311 */           localObject1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/*  312 */           localObject2 = new Object[] { paramJavaType.toString().toLowerCase(Locale.ENGLISH), paramJDBCType.toString().toLowerCase(Locale.ENGLISH) };
/*  313 */           throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), null);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  321 */     if ((true == paramBoolean) && (false == Util.shouldHonorAEForParameters(paramSQLServerStatementColumnEncryptionSetting, paramSQLServerConnection)))
/*      */     {
/*  323 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAEFalse"));
/*  324 */       localObject2 = new Object[] { Integer.valueOf(paramInt), paramString1 };
/*  325 */       SQLServerException.makeFromDriverError(paramSQLServerConnection, this, ((MessageFormat)localObject1).format(localObject2), null, true);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  330 */     if (((JDBCType.DATETIMEOFFSET == paramJDBCType) || (JavaType.DATETIMEOFFSET == paramJavaType)) && (!paramSQLServerConnection.isKatmaiOrLater()))
/*      */     {
/*      */ 
/*  333 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  340 */     if (JavaType.TVP == paramJavaType)
/*      */     {
/*  342 */       localObject1 = null;
/*  343 */       if (null == paramObject)
/*      */       {
/*  345 */         localObject1 = new TVP(paramString2);
/*      */       }
/*  347 */       else if ((paramObject instanceof SQLServerDataTable))
/*      */       {
/*  349 */         localObject1 = new TVP(paramString2, (SQLServerDataTable)paramObject);
/*      */       }
/*  351 */       else if ((paramObject instanceof ResultSet))
/*      */       {
/*      */ 
/*      */ 
/*  355 */         if ((paramSQLServerConnection.getSelectMethod().equalsIgnoreCase("cursor")) && ((paramObject instanceof SQLServerResultSet)))
/*      */         {
/*  357 */           localObject2 = (SQLServerStatement)((SQLServerResultSet)paramObject).getStatement();
/*      */           
/*  359 */           if (paramSQLServerConnection.equals(((SQLServerStatement)localObject2).connection))
/*      */           {
/*  361 */             if (Locale.getDefault().getLanguage() == Locale.ENGLISH.getLanguage())
/*      */             {
/*  363 */               throw new SQLServerException(SQLServerException.getErrString("R_invalidServerCursorForTVP"), null);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  368 */             throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null, 0, null);
/*      */           }
/*      */         }
/*      */         
/*  372 */         localObject1 = new TVP(paramString2, (ResultSet)paramObject);
/*      */       }
/*  374 */       else if ((paramObject instanceof ISQLServerDataRecord))
/*      */       {
/*  376 */         localObject1 = new TVP(paramString2, (ISQLServerDataRecord)paramObject);
/*      */       }
/*      */       else
/*      */       {
/*  380 */         localObject2 = new MessageFormat(SQLServerException.getErrString("R_TVPInvalidValue"));
/*  381 */         Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/*  382 */         throw new SQLServerException(((MessageFormat)localObject2).format(arrayOfObject), null);
/*      */       }
/*      */       
/*      */ 
/*  386 */       if ((!((TVP)localObject1).isNull()) && (0 == ((TVP)localObject1).getTVPColumnCount()))
/*      */       {
/*  388 */         throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*      */       }
/*      */       
/*      */ 
/*  392 */       this.name = ((TVP)localObject1).getTVPName();
/*      */       
/*  394 */       paramObject = localObject1;
/*      */     }
/*      */     
/*      */ 
/*  398 */     if (this.shouldHonorAEForParameter)
/*      */     {
/*  400 */       setForceEncryption(paramBoolean);
/*      */       
/*      */ 
/*  403 */       if ((!isOutput()) || (this.jdbcTypeSetByUser == null)) {
/*  404 */         setJdbcTypeSetByUser(paramJDBCType);
/*      */       }
/*      */       
/*      */ 
/*  408 */       if (((!paramJDBCType.isTextual()) && (!paramJDBCType.isBinary())) || (!isOutput()) || (this.valueLength == 0)) {
/*  409 */         this.valueLength = Util.getValueLengthBaseOnJavaType(paramObject, paramJavaType, paramInteger1, paramInteger2, paramJDBCType);
/*      */       }
/*      */       
/*  412 */       if (null != paramInteger2) {
/*  413 */         this.outScale = paramInteger2.intValue();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  421 */     if ((paramSQLServerConnection.sendStringParametersAsUnicode()) && ((JavaType.STRING == paramJavaType) || (JavaType.READER == paramJavaType) || (JavaType.CLOB == paramJavaType)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  426 */       paramJDBCType = getSSPAUJDBCType(paramJDBCType);
/*      */     }
/*      */     
/*  429 */     Object localObject1 = new DTV();
/*  430 */     ((DTV)localObject1).setValue(paramSQLServerConnection.getDatabaseCollation(), paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger2, paramSQLServerConnection, paramBoolean);
/*  431 */     this.inputDTV = (this.setterDTV = localObject1);
/*      */   }
/*      */   
/*      */   boolean isNull()
/*      */   {
/*  436 */     if (null != this.getterDTV) {
/*  437 */       return this.getterDTV.isNull();
/*      */     }
/*  439 */     return false;
/*      */   }
/*      */   
/*      */   boolean isValueGotten()
/*      */   {
/*  444 */     return null != this.getterDTV;
/*      */   }
/*      */   
/*      */   Object getValue(JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/*  450 */     if (null == this.getterDTV) {
/*  451 */       this.getterDTV = new DTV();
/*      */     }
/*  453 */     deriveTypeInfo(paramTDSReader);
/*      */     
/*      */ 
/*  456 */     return this.getterDTV.getValue(paramJDBCType, this.outScale, paramInputStreamGetterArgs, paramCalendar, this.typeInfo, this.cryptoMeta, paramTDSReader);
/*      */   }
/*      */   
/*      */   int getInt(TDSReader paramTDSReader) throws SQLServerException
/*      */   {
/*  461 */     Integer localInteger = (Integer)getValue(JDBCType.INTEGER, null, null, paramTDSReader);
/*  462 */     return null != localInteger ? localInteger.intValue() : 0;
/*      */   }
/*      */   
/*      */ 
/*      */   final class GetTypeDefinitionOp
/*      */     extends DTVExecuteOp
/*      */   {
/*      */     private static final String NVARCHAR_MAX = "nvarchar(max)";
/*      */     
/*      */     private static final String NVARCHAR_4K = "nvarchar(4000)";
/*      */     
/*      */     private static final String NTEXT = "ntext";
/*      */     
/*      */     private static final String VARCHAR_MAX = "varchar(max)";
/*      */     
/*      */     private static final String VARCHAR_8K = "varchar(8000)";
/*      */     
/*      */     private static final String TEXT = "text";
/*      */     
/*      */     private static final String VARBINARY_MAX = "varbinary(max)";
/*      */     private static final String VARBINARY_8K = "varbinary(8000)";
/*      */     private static final String IMAGE = "image";
/*      */     private final Parameter param;
/*      */     private final SQLServerConnection con;
/*      */     
/*      */     GetTypeDefinitionOp(Parameter paramParameter, SQLServerConnection paramSQLServerConnection)
/*      */     {
/*  489 */       this.param = paramParameter;
/*  490 */       this.con = paramSQLServerConnection;
/*      */     }
/*      */     
/*      */     private void setTypeDefinition(DTV paramDTV)
/*      */     {
/*  495 */       switch (Parameter.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[paramDTV.getJdbcType().ordinal()])
/*      */       {
/*      */       case 5: 
/*  498 */         this.param.typeDefinition = SSType.TINYINT.toString();
/*  499 */         break;
/*      */       
/*      */       case 6: 
/*  502 */         this.param.typeDefinition = SSType.SMALLINT.toString();
/*  503 */         break;
/*      */       
/*      */       case 7: 
/*  506 */         this.param.typeDefinition = SSType.INTEGER.toString();
/*  507 */         break;
/*      */       
/*      */       case 8: 
/*  510 */         this.param.typeDefinition = SSType.BIGINT.toString();
/*  511 */         break;
/*      */       
/*      */ 
/*      */       case 9: 
/*  515 */         if ((this.param.shouldHonorAEForParameter) && (null != Parameter.this.jdbcTypeSetByUser) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  525 */           this.param.typeDefinition = SSType.REAL.toString(); }
/*  526 */         break;
/*      */       
/*      */       case 10: 
/*      */       case 11: 
/*  530 */         this.param.typeDefinition = SSType.FLOAT.toString();
/*  531 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/*      */       case 13: 
/*  536 */         if (Parameter.this.scale > 38) {
/*  537 */           Parameter.this.scale = 38;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  543 */         Integer localInteger = paramDTV.getScale();
/*  544 */         if ((null != localInteger) && (Parameter.this.scale < localInteger.intValue())) {
/*  545 */           Parameter.this.scale = localInteger.intValue();
/*      */         }
/*  547 */         if ((this.param.isOutput()) && (Parameter.this.scale < this.param.getOutScale())) {
/*  548 */           Parameter.this.scale = this.param.getOutScale();
/*      */         }
/*  550 */         if ((this.param.shouldHonorAEForParameter) && (null != Parameter.this.jdbcTypeSetByUser) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  560 */           if (0 == Parameter.this.valueLength)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  567 */             if (!Parameter.this.isOutput()) {
/*  568 */               this.param.typeDefinition = ("decimal(18, " + Parameter.this.scale + ")");
/*      */             }
/*      */             
/*      */           }
/*  572 */           else if (18 >= Parameter.this.valueLength) {
/*  573 */             this.param.typeDefinition = ("decimal(18," + Parameter.this.scale + ")");
/*      */             
/*  575 */             if (18 < Parameter.this.valueLength + Parameter.this.scale) {
/*  576 */               this.param.typeDefinition = ("decimal(" + (18 + Parameter.this.scale) + "," + Parameter.this.scale + ")");
/*      */             }
/*      */           }
/*      */           else {
/*  580 */             this.param.typeDefinition = ("decimal(38," + Parameter.this.scale + ")");
/*      */           }
/*      */           
/*      */ 
/*  584 */           if (Parameter.this.isOutput()) {
/*  585 */             this.param.typeDefinition = ("decimal(38, " + Parameter.this.scale + ")");
/*      */           }
/*      */           
/*  588 */           if (Parameter.this.userProvidesPrecision) {
/*  589 */             this.param.typeDefinition = ("decimal(" + Parameter.this.valueLength + "," + Parameter.this.scale + ")");
/*      */           }
/*      */         }
/*      */         else {
/*  593 */           this.param.typeDefinition = ("decimal(38," + Parameter.this.scale + ")");
/*      */         }
/*  595 */         break;
/*      */       
/*      */       case 14: 
/*  598 */         this.param.typeDefinition = SSType.MONEY.toString();
/*  599 */         break;
/*      */       case 15: 
/*  601 */         this.param.typeDefinition = SSType.SMALLMONEY.toString();
/*  602 */         break;
/*      */       case 16: 
/*      */       case 17: 
/*  605 */         this.param.typeDefinition = SSType.BIT.toString();
/*  606 */         break;
/*      */       
/*      */       case 18: 
/*      */       case 19: 
/*  610 */         this.param.typeDefinition = "varbinary(max)";
/*  611 */         break;
/*      */       
/*      */ 
/*      */       case 20: 
/*      */       case 21: 
/*  616 */         if (("varbinary(max)" == this.param.typeDefinition) || ("image" == this.param.typeDefinition))
/*      */           return;
/*  618 */         if ((this.param.shouldHonorAEForParameter) && (null != Parameter.this.jdbcTypeSetByUser) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  628 */           if (0 == Parameter.this.valueLength) {
/*  629 */             this.param.typeDefinition = "varbinary";
/*      */           }
/*      */           else {
/*  632 */             this.param.typeDefinition = ("varbinary(" + Parameter.this.valueLength + ")");
/*      */           }
/*      */           
/*  635 */           if (JDBCType.LONGVARBINARY == Parameter.this.jdbcTypeSetByUser) {
/*  636 */             this.param.typeDefinition = "varbinary(max)";
/*      */           }
/*      */         }
/*      */         else {
/*  640 */           this.param.typeDefinition = "varbinary(8000)"; }
/*  641 */         break;
/*      */       
/*      */ 
/*      */       case 22: 
/*  645 */         this.param.typeDefinition = (this.con.isKatmaiOrLater() ? SSType.DATE.toString() : SSType.DATETIME.toString());
/*  646 */         break;
/*      */       
/*      */       case 23: 
/*  649 */         if ((this.param.shouldHonorAEForParameter) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  660 */           if (Parameter.this.userProvidesScale) {
/*  661 */             this.param.typeDefinition = (SSType.TIME.toString() + "(" + Parameter.this.outScale + ")");
/*      */           }
/*      */           else {
/*  664 */             this.param.typeDefinition = Parameter.access$002(this.param, SSType.TIME.toString() + "(" + Parameter.this.valueLength + ")");
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/*  669 */           this.param.typeDefinition = (this.con.getSendTimeAsDatetime() ? SSType.DATETIME.toString() : SSType.TIME.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  674 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 24: 
/*  679 */         if ((this.param.shouldHonorAEForParameter) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  688 */           if (Parameter.this.userProvidesScale) {
/*  689 */             this.param.typeDefinition = (this.con.isKatmaiOrLater() ? SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")" : SSType.DATETIME.toString());
/*      */           }
/*      */           else
/*      */           {
/*  693 */             this.param.typeDefinition = (this.con.isKatmaiOrLater() ? SSType.DATETIME2.toString() + "(" + Parameter.this.valueLength + ")" : SSType.DATETIME.toString());
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/*  698 */           this.param.typeDefinition = (this.con.isKatmaiOrLater() ? SSType.DATETIME2.toString() : SSType.DATETIME.toString());
/*      */         }
/*      */         
/*  701 */         break;
/*      */       
/*      */ 
/*      */       case 25: 
/*  705 */         this.param.typeDefinition = SSType.DATETIME.toString();
/*      */         
/*  707 */         if (!this.param.shouldHonorAEForParameter)
/*      */         {
/*      */ 
/*  710 */           if (this.param.isOutput()) {
/*  711 */             this.param.typeDefinition = (SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")");
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */         }
/*  718 */         else if ((null == this.param.getCryptoMetadata()) && (this.param.renewDefinition) && 
/*  719 */           (this.param.isOutput())) {
/*  720 */           this.param.typeDefinition = (SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 26: 
/*  728 */         this.param.typeDefinition = SSType.SMALLDATETIME.toString();
/*  729 */         break;
/*      */       
/*      */       case 27: 
/*      */       case 28: 
/*      */       case 29: 
/*  734 */         if ((this.param.shouldHonorAEForParameter) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  743 */           if (Parameter.this.userProvidesScale) {
/*  744 */             this.param.typeDefinition = (SSType.DATETIMEOFFSET.toString() + "(" + Parameter.this.outScale + ")");
/*      */           }
/*      */           else {
/*  747 */             this.param.typeDefinition = (SSType.DATETIMEOFFSET.toString() + "(" + Parameter.this.valueLength + ")");
/*      */           }
/*      */         }
/*      */         else {
/*  751 */           this.param.typeDefinition = SSType.DATETIMEOFFSET.toString();
/*      */         }
/*  753 */         break;
/*      */       
/*      */       case 3: 
/*      */       case 4: 
/*  757 */         this.param.typeDefinition = "varchar(max)";
/*  758 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 2: 
/*  763 */         if (("varchar(max)" == this.param.typeDefinition) || ("text" == this.param.typeDefinition)) {
/*      */           return;
/*      */         }
/*      */         
/*  767 */         if ((this.param.shouldHonorAEForParameter) && (null != Parameter.this.jdbcTypeSetByUser) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  777 */           if (0 == Parameter.this.valueLength) {
/*  778 */             this.param.typeDefinition = "varchar";
/*      */           }
/*      */           else {
/*  781 */             this.param.typeDefinition = ("varchar(" + Parameter.this.valueLength + ")");
/*      */             
/*  783 */             if (8000 <= Parameter.this.valueLength) {
/*  784 */               this.param.typeDefinition = "varchar(max)";
/*      */             }
/*      */           }
/*      */         }
/*      */         else
/*  789 */           this.param.typeDefinition = "varchar(8000)";
/*  790 */         break;
/*      */       
/*      */       case 30: 
/*  793 */         if ((this.param.shouldHonorAEForParameter) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  802 */           if ((null != Parameter.this.jdbcTypeSetByUser) && ((Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR) || (Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR) || (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR)))
/*      */           {
/*  804 */             if (0 == Parameter.this.valueLength) {
/*  805 */               this.param.typeDefinition = "varchar";
/*      */             }
/*  807 */             else if (8000 < Parameter.this.valueLength) {
/*  808 */               this.param.typeDefinition = "varchar(max)";
/*      */             }
/*      */             else {
/*  811 */               this.param.typeDefinition = ("varchar(" + Parameter.this.valueLength + ")");
/*      */             }
/*      */             
/*  814 */             if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR) {
/*  815 */               this.param.typeDefinition = "varchar(max)";
/*      */             }
/*      */           }
/*  818 */           else if ((null != Parameter.this.jdbcTypeSetByUser) && ((Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR) || (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR)))
/*      */           {
/*  820 */             if (0 == Parameter.this.valueLength) {
/*  821 */               this.param.typeDefinition = "nvarchar";
/*      */             }
/*  823 */             else if (4000 < Parameter.this.valueLength) {
/*  824 */               this.param.typeDefinition = "nvarchar(max)";
/*      */             }
/*      */             else {
/*  827 */               this.param.typeDefinition = ("nvarchar(" + Parameter.this.valueLength + ")");
/*      */             }
/*      */             
/*  830 */             if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR) {
/*  831 */               this.param.typeDefinition = "nvarchar(max)";
/*      */             }
/*      */             
/*      */           }
/*  835 */           else if (0 == Parameter.this.valueLength) {
/*  836 */             this.param.typeDefinition = "nvarchar";
/*      */           }
/*      */           else {
/*  839 */             this.param.typeDefinition = ("nvarchar(" + Parameter.this.valueLength + ")");
/*      */             
/*  841 */             if (8000 <= Parameter.this.valueLength) {
/*  842 */               this.param.typeDefinition = "nvarchar(max)";
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*      */         else
/*  849 */           this.param.typeDefinition = "nvarchar(max)";
/*  850 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 31: 
/*  855 */         this.param.typeDefinition = "nvarchar(max)";
/*  856 */         break;
/*      */       
/*      */ 
/*      */       case 32: 
/*      */       case 33: 
/*  861 */         if (("nvarchar(max)" == this.param.typeDefinition) || ("ntext" == this.param.typeDefinition)) {
/*      */           return;
/*      */         }
/*  864 */         if ((this.param.shouldHonorAEForParameter) && ((null != this.param.getCryptoMetadata()) || (!this.param.renewDefinition)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  873 */           if ((null != Parameter.this.jdbcTypeSetByUser) && ((Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR) || (Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR) || (JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser)))
/*      */           {
/*      */ 
/*  876 */             if (0 == Parameter.this.valueLength) {
/*  877 */               this.param.typeDefinition = "varchar";
/*      */             }
/*      */             else {
/*  880 */               this.param.typeDefinition = ("varchar(" + Parameter.this.valueLength + ")");
/*      */               
/*  882 */               if (8000 <= Parameter.this.valueLength) {
/*  883 */                 this.param.typeDefinition = "varchar(max)";
/*      */               }
/*      */             }
/*      */             
/*  887 */             if (JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser) {
/*  888 */               this.param.typeDefinition = "varchar(max)";
/*      */             }
/*      */           }
/*  891 */           else if ((null != Parameter.this.jdbcTypeSetByUser) && ((Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR) || (Parameter.this.jdbcTypeSetByUser == JDBCType.NCHAR) || (JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser)))
/*      */           {
/*      */ 
/*  894 */             if (0 == Parameter.this.valueLength) {
/*  895 */               this.param.typeDefinition = "nvarchar";
/*      */             }
/*      */             else {
/*  898 */               this.param.typeDefinition = ("nvarchar(" + Parameter.this.valueLength + ")");
/*      */               
/*  900 */               if (8000 <= Parameter.this.valueLength) {
/*  901 */                 this.param.typeDefinition = "nvarchar(max)";
/*      */               }
/*      */             }
/*      */             
/*  905 */             if (JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser) {
/*  906 */               this.param.typeDefinition = "nvarchar(max)";
/*      */             }
/*      */             
/*      */           }
/*  910 */           else if (0 == Parameter.this.valueLength) {
/*  911 */             this.param.typeDefinition = "nvarchar";
/*      */           }
/*      */           else {
/*  914 */             this.param.typeDefinition = ("nvarchar(" + Parameter.this.valueLength + ")");
/*      */             
/*  916 */             if (8000 <= Parameter.this.valueLength) {
/*  917 */               this.param.typeDefinition = "nvarchar(max)";
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*      */         else
/*  924 */           this.param.typeDefinition = "nvarchar(4000)";
/*  925 */         break;
/*      */       case 34: 
/*  927 */         this.param.typeDefinition = SSType.XML.toString();
/*  928 */         break;
/*      */       
/*      */ 
/*      */       case 35: 
/*  932 */         this.param.typeDefinition = ("[" + this.param.name + "] READONLY");
/*  933 */         break;
/*      */       
/*      */ 
/*      */       case 36: 
/*  937 */         this.param.typeDefinition = SSType.GUID.toString();
/*  938 */         break;
/*      */       }
/*      */       
/*  941 */       if (!$assertionsDisabled) { throw new AssertionError("Unexpected JDBC type " + paramDTV.getJdbcType());
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, String paramString)
/*      */       throws SQLServerException
/*      */     {
/*  948 */       if ((null != paramString) && (paramString.length() > 4000)) {
/*  949 */         paramDTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */       }
/*  951 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Clob paramClob) throws SQLServerException
/*      */     {
/*  956 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Byte paramByte) throws SQLServerException
/*      */     {
/*  961 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Integer paramInteger) throws SQLServerException
/*      */     {
/*  966 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Time paramTime) throws SQLServerException
/*      */     {
/*  971 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, java.sql.Date paramDate) throws SQLServerException
/*      */     {
/*  976 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Timestamp paramTimestamp) throws SQLServerException
/*      */     {
/*  981 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, java.util.Date paramDate) throws SQLServerException
/*      */     {
/*  986 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Calendar paramCalendar) throws SQLServerException
/*      */     {
/*  991 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, LocalDate paramLocalDate) throws SQLServerException
/*      */     {
/*  996 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, LocalTime paramLocalTime) throws SQLServerException
/*      */     {
/* 1001 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, LocalDateTime paramLocalDateTime) throws SQLServerException
/*      */     {
/* 1006 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, OffsetTime paramOffsetTime) throws SQLServerException
/*      */     {
/* 1011 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, OffsetDateTime paramOffsetDateTime) throws SQLServerException
/*      */     {
/* 1016 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset) throws SQLServerException
/*      */     {
/* 1021 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Float paramFloat) throws SQLServerException
/*      */     {
/* 1026 */       Parameter.this.scale = 4;
/* 1027 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Double paramDouble) throws SQLServerException
/*      */     {
/* 1032 */       Parameter.this.scale = 4;
/* 1033 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, BigDecimal paramBigDecimal) throws SQLServerException
/*      */     {
/* 1038 */       if (null != paramBigDecimal)
/*      */       {
/* 1040 */         Parameter.this.scale = paramBigDecimal.scale();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1047 */         if (Parameter.this.scale < 0) {
/* 1048 */           Parameter.this.scale = 0;
/*      */         }
/*      */       }
/* 1051 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Long paramLong) throws SQLServerException
/*      */     {
/* 1056 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, BigInteger paramBigInteger) throws SQLServerException
/*      */     {
/* 1061 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Short paramShort) throws SQLServerException
/*      */     {
/* 1066 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Boolean paramBoolean) throws SQLServerException
/*      */     {
/* 1071 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, byte[] paramArrayOfByte) throws SQLServerException
/*      */     {
/* 1076 */       if ((null != paramArrayOfByte) && (paramArrayOfByte.length > 8000)) {
/* 1077 */         paramDTV.setJdbcType(paramDTV.getJdbcType().isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */       }
/* 1079 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Blob paramBlob) throws SQLServerException
/*      */     {
/* 1084 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, InputStream paramInputStream) throws SQLServerException
/*      */     {
/* 1089 */       StreamSetterArgs localStreamSetterArgs = paramDTV.getStreamSetterArgs();
/*      */       
/* 1091 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*      */       
/*      */ 
/* 1094 */       if ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.BINARY == localJDBCType) || (JDBCType.VARBINARY == localJDBCType))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1100 */         if (localStreamSetterArgs.getLength() > 8000L) {
/* 1101 */           paramDTV.setJdbcType(localJDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */ 
/*      */ 
/*      */         }
/* 1105 */         else if (-1L == localStreamSetterArgs.getLength())
/*      */         {
/* 1107 */           byte[] arrayOfByte = new byte['ὁ'];
/* 1108 */           BufferedInputStream localBufferedInputStream = new BufferedInputStream(paramInputStream, arrayOfByte.length);
/*      */           
/* 1110 */           int i = 0;
/*      */           
/*      */           try
/*      */           {
/* 1114 */             localBufferedInputStream.mark(arrayOfByte.length);
/*      */             
/* 1116 */             i = localBufferedInputStream.read(arrayOfByte, 0, arrayOfByte.length);
/*      */             
/* 1118 */             if (-1 == i) {
/* 1119 */               i = 0;
/*      */             }
/* 1121 */             localBufferedInputStream.reset();
/*      */           }
/*      */           catch (IOException localIOException)
/*      */           {
/* 1125 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1126 */             Object[] arrayOfObject = { localIOException.toString() };
/* 1127 */             SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), "", true);
/*      */           }
/*      */           
/* 1130 */           paramDTV.setValue(localBufferedInputStream, JavaType.INPUTSTREAM);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1136 */           if (i > 8000) {
/* 1137 */             paramDTV.setJdbcType(localJDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */           } else {
/* 1139 */             localStreamSetterArgs.setLength(i);
/*      */           }
/*      */         }
/*      */       }
/* 1143 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Reader paramReader)
/*      */       throws SQLServerException
/*      */     {
/* 1149 */       if ((JDBCType.NCHAR == paramDTV.getJdbcType()) || (JDBCType.NVARCHAR == paramDTV.getJdbcType()))
/*      */       {
/* 1151 */         StreamSetterArgs localStreamSetterArgs = paramDTV.getStreamSetterArgs();
/*      */         
/*      */ 
/* 1154 */         if (localStreamSetterArgs.getLength() > 4000L) {
/* 1155 */           paramDTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */ 
/*      */ 
/*      */         }
/* 1159 */         else if (-1L == localStreamSetterArgs.getLength())
/*      */         {
/* 1161 */           char[] arrayOfChar = new char['ྡ'];
/* 1162 */           BufferedReader localBufferedReader = new BufferedReader(paramReader, arrayOfChar.length);
/*      */           
/* 1164 */           int i = 0;
/*      */           
/*      */           try
/*      */           {
/* 1168 */             localBufferedReader.mark(arrayOfChar.length);
/*      */             
/* 1170 */             i = localBufferedReader.read(arrayOfChar, 0, arrayOfChar.length);
/*      */             
/* 1172 */             if (-1 == i) {
/* 1173 */               i = 0;
/*      */             }
/* 1175 */             localBufferedReader.reset();
/*      */           }
/*      */           catch (IOException localIOException)
/*      */           {
/* 1179 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1180 */             Object[] arrayOfObject = { localIOException.toString() };
/* 1181 */             SQLServerException.makeFromDriverError(null, null, localMessageFormat.format(arrayOfObject), "", true);
/*      */           }
/*      */           
/* 1184 */           paramDTV.setValue(localBufferedReader, JavaType.READER);
/*      */           
/* 1186 */           if (i > 4000) {
/* 1187 */             paramDTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */           } else {
/* 1189 */             localStreamSetterArgs.setLength(i);
/*      */           }
/*      */         }
/*      */       }
/* 1193 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML) throws SQLServerException {
/* 1197 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, TVP paramTVP) throws SQLServerException
/*      */     {
/* 1202 */       setTypeDefinition(paramDTV);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getTypeDefinition(SQLServerConnection paramSQLServerConnection, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 1213 */     if (null == this.inputDTV) {
/* 1214 */       return null;
/*      */     }
/* 1216 */     this.inputDTV.executeOp(new GetTypeDefinitionOp(this, paramSQLServerConnection));
/* 1217 */     return this.typeDefinition;
/*      */   }
/*      */   
/*      */ 
/*      */   void sendByRPC(TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection)
/*      */     throws SQLServerException
/*      */   {
/* 1224 */     assert (null != this.inputDTV) : "Parameter was neither set nor registered";
/*      */     
/*      */     try
/*      */     {
/* 1228 */       this.inputDTV.sendCryptoMetaData(this.cryptoMeta, paramTDSWriter);
/* 1229 */       this.inputDTV.jdbcTypeSetByUser(getJdbcTypeSetByUser(), getValueLength());
/* 1230 */       this.inputDTV.sendByRPC(this.name, null, paramSQLServerConnection.getDatabaseCollation(), this.valueLength, isOutput() ? this.outScale : this.scale, isOutput(), paramTDSWriter, paramSQLServerConnection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1243 */       this.inputDTV.sendCryptoMetaData(null, paramTDSWriter);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1254 */     if ((JavaType.INPUTSTREAM == this.inputDTV.getJavaType()) || (JavaType.READER == this.inputDTV.getJavaType()))
/*      */     {
/*      */ 
/* 1257 */       this.inputDTV = (this.setterDTV = null); }
/*      */   }
/*      */   
/*      */   JDBCType getJdbcTypeSetByUser() {
/* 1261 */     return this.jdbcTypeSetByUser;
/*      */   }
/*      */   
/* 1264 */   void setJdbcTypeSetByUser(JDBCType paramJDBCType) { this.jdbcTypeSetByUser = paramJDBCType; }
/*      */   
/*      */ 
/* 1267 */   int getValueLength() { return this.valueLength; }
/*      */   
/*      */   void setValueLength(int paramInt) {
/* 1270 */     this.valueLength = paramInt;
/* 1271 */     this.userProvidesPrecision = true;
/*      */   }
/*      */   
/* 1274 */   boolean getForceEncryption() { return this.forceEncryption; }
/*      */   
/*      */   void setForceEncryption(boolean paramBoolean) {
/* 1277 */     this.forceEncryption = paramBoolean;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/Parameter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */