/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ 
/*     */ public class SQLServerColumnEncryptionJavaKeyStoreProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  32 */   String name = "MSSQL_JAVA_KEYSTORE";
/*     */   
/*     */ 
/*  35 */   String keyStorePath = null;
/*  36 */   char[] keyStorePwd = null;
/*     */   
/*  38 */   private static final Logger javaKeyStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */   
/*     */ 
/*     */   public void setName(String paramString)
/*     */   {
/*  43 */     this.name = paramString;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  48 */     return this.name;
/*     */   }
/*     */   
/*     */   public SQLServerColumnEncryptionJavaKeyStoreProvider(String paramString, char[] paramArrayOfChar) throws SQLServerException
/*     */   {
/*  53 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */     
/*  55 */     if ((null == paramString) || (0 == paramString.length()))
/*     */     {
/*  57 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/*  58 */       Object[] arrayOfObject = { "keyStoreLocation", paramString };
/*  59 */       throw new SQLServerException(localMessageFormat.format(arrayOfObject), null);
/*     */     }
/*     */     
/*  62 */     this.keyStorePath = paramString;
/*     */     
/*  64 */     if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
/*  65 */       javaKeyStoreLogger.fine("Path of key store provider is set.");
/*     */     }
/*     */     
/*     */ 
/*  69 */     if (null == paramArrayOfChar)
/*     */     {
/*  71 */       paramArrayOfChar = "".toCharArray();
/*     */     }
/*     */     
/*  74 */     this.keyStorePwd = new char[paramArrayOfChar.length];
/*  75 */     System.arraycopy(paramArrayOfChar, 0, this.keyStorePwd, 0, paramArrayOfChar.length);
/*     */     
/*  77 */     if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
/*  78 */       javaKeyStoreLogger.fine("Password for key store provider is set.");
/*     */     }
/*     */     
/*  81 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/*  90 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
/*     */     
/*  92 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
/*  93 */     CertificateDetails localCertificateDetails = getCertificateDetails(paramString1);
/*  94 */     byte[] arrayOfByte = KeyStoreProviderCommon.decryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfByte, localCertificateDetails);
/*     */     
/*  96 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
/*  97 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */ 
/*     */   private CertificateDetails getCertificateDetails(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 104 */     FileInputStream localFileInputStream = null;
/* 105 */     KeyStore localKeyStore = null;
/* 106 */     localCertificateDetails = null;
/*     */     
/*     */     try
/*     */     {
/* 110 */       if ((null == paramString) || (0 == paramString.length()))
/*     */       {
/* 112 */         throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 123 */         localKeyStore = KeyStore.getInstance("JKS");
/* 124 */         localFileInputStream = new FileInputStream(this.keyStorePath);
/* 125 */         localKeyStore.load(localFileInputStream, this.keyStorePwd);
/*     */       }
/*     */       catch (IOException localIOException1)
/*     */       {
/* 129 */         if (null != localFileInputStream) { localFileInputStream.close();
/*     */         }
/*     */         
/* 132 */         localKeyStore = KeyStore.getInstance("PKCS12");
/* 133 */         localFileInputStream = new FileInputStream(this.keyStorePath);
/* 134 */         localKeyStore.load(localFileInputStream, this.keyStorePwd); }
/*     */       MessageFormat localMessageFormat;
/*     */       Object[] arrayOfObject;
/* 137 */       return getCertificateDetailsByAlias(localKeyStore, paramString);
/*     */     }
/*     */     catch (FileNotFoundException localFileNotFoundException)
/*     */     {
/* 141 */       throw new SQLServerException(this, SQLServerException.getErrString("R_KeyStoreNotFound"), null, 0, false);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (IOException|CertificateException|NoSuchAlgorithmException|KeyStoreException localIOException3)
/*     */     {
/*     */ 
/* 148 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidKeyStoreFile"));
/*     */       
/* 150 */       arrayOfObject = new Object[] { this.keyStorePath };
/* 151 */       throw new SQLServerException(localMessageFormat.format(arrayOfObject), localIOException3);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 157 */         if (null != localFileInputStream) { localFileInputStream.close();
/*     */         }
/*     */       }
/*     */       catch (IOException localIOException4) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CertificateDetails getCertificateDetailsByAlias(KeyStore paramKeyStore, String paramString)
/*     */     throws SQLServerException
/*     */   {
/*     */     try
/*     */     {
/* 172 */       X509Certificate localX509Certificate = (X509Certificate)paramKeyStore.getCertificate(paramString);
/* 173 */       localObject1 = paramKeyStore.getKey(paramString, this.keyStorePwd);
/* 174 */       if (null == localX509Certificate)
/*     */       {
/*     */ 
/* 177 */         localObject2 = new MessageFormat(SQLServerException.getErrString("R_CertificateNotFoundForAlias"));
/*     */         
/* 179 */         Object[] arrayOfObject = { paramString, "MSSQL_JAVA_KEYSTORE" };
/* 180 */         throw new SQLServerException(this, ((MessageFormat)localObject2).format(arrayOfObject), null, 0, false);
/*     */       }
/*     */       
/*     */ 
/* 184 */       if (null == localObject1) {
/* 185 */         throw new UnrecoverableKeyException();
/*     */       }
/*     */       
/* 188 */       return new CertificateDetails(localX509Certificate, (Key)localObject1);
/*     */     }
/*     */     catch (UnrecoverableKeyException localUnrecoverableKeyException)
/*     */     {
/* 192 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
/*     */       
/* 194 */       localObject2 = new Object[] { paramString };
/* 195 */       throw new SQLServerException(this, ((MessageFormat)localObject1).format(localObject2), null, 0, false);
/*     */     }
/*     */     catch (NoSuchAlgorithmException|KeyStoreException localNoSuchAlgorithmException) {
/* 198 */       Object localObject1 = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
/*     */       
/* 200 */       Object localObject2 = { paramString, this.name };
/* 201 */       throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), localNoSuchAlgorithmException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/* 209 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Encrypting Column Encryption Key.");
/*     */     
/* 211 */     byte[] arrayOfByte1 = KeyStoreProviderCommon.version;
/* 212 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
/*     */     
/* 214 */     if (null == paramArrayOfByte)
/*     */     {
/* 216 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 224 */     if (0 == paramArrayOfByte.length)
/*     */     {
/* 226 */       throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */     KeyStoreProviderCommon.validateEncryptionAlgorithm(paramString2, true);
/*     */     
/* 237 */     CertificateDetails localCertificateDetails = getCertificateDetails(paramString1);
/* 238 */     byte[] arrayOfByte2 = encryptRSAOAEP(paramArrayOfByte, localCertificateDetails);
/* 239 */     byte[] arrayOfByte3 = getLittleEndianBytesFromShort((short)arrayOfByte2.length);
/*     */     byte[] arrayOfByte4;
/*     */     try
/*     */     {
/* 243 */       arrayOfByte4 = paramString1.toLowerCase().getBytes("UTF-16LE");
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 246 */       localObject = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/* 247 */       throw new SQLServerException(((MessageFormat)localObject).format(new Object[] { "UTF-16LE" }), null, 0, null);
/*     */     }
/*     */     
/* 250 */     byte[] arrayOfByte5 = getLittleEndianBytesFromShort((short)arrayOfByte4.length);
/*     */     
/* 252 */     Object localObject = new byte[arrayOfByte1.length + arrayOfByte5.length + arrayOfByte3.length + arrayOfByte4.length + arrayOfByte2.length];
/* 253 */     int i = arrayOfByte1.length;
/* 254 */     System.arraycopy(arrayOfByte1, 0, localObject, 0, arrayOfByte1.length);
/*     */     
/* 256 */     System.arraycopy(arrayOfByte5, 0, localObject, i, arrayOfByte5.length);
/* 257 */     i += arrayOfByte5.length;
/*     */     
/* 259 */     System.arraycopy(arrayOfByte3, 0, localObject, i, arrayOfByte3.length);
/* 260 */     i += arrayOfByte3.length;
/*     */     
/* 262 */     System.arraycopy(arrayOfByte4, 0, localObject, i, arrayOfByte4.length);
/* 263 */     i += arrayOfByte4.length;
/*     */     
/* 265 */     System.arraycopy(arrayOfByte2, 0, localObject, i, arrayOfByte2.length);
/* 266 */     byte[] arrayOfByte6 = rsaSignHashedData((byte[])localObject, localCertificateDetails);
/*     */     
/* 268 */     int j = arrayOfByte1.length + arrayOfByte3.length + arrayOfByte5.length + arrayOfByte2.length + arrayOfByte4.length + arrayOfByte6.length;
/* 269 */     byte[] arrayOfByte7 = new byte[j];
/*     */     
/* 271 */     int k = 0;
/* 272 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte7, k, arrayOfByte1.length);
/* 273 */     k += arrayOfByte1.length;
/*     */     
/* 275 */     System.arraycopy(arrayOfByte5, 0, arrayOfByte7, k, arrayOfByte5.length);
/* 276 */     k += arrayOfByte5.length;
/*     */     
/* 278 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte7, k, arrayOfByte3.length);
/* 279 */     k += arrayOfByte3.length;
/*     */     
/* 281 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte7, k, arrayOfByte4.length);
/* 282 */     k += arrayOfByte4.length;
/*     */     
/* 284 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte7, k, arrayOfByte2.length);
/* 285 */     k += arrayOfByte2.length;
/*     */     
/* 287 */     System.arraycopy(arrayOfByte6, 0, arrayOfByte7, k, arrayOfByte6.length);
/*     */     
/* 289 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Finished encrypting Column Encryption Key.");
/* 290 */     return arrayOfByte7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] encryptRSAOAEP(byte[] paramArrayOfByte, CertificateDetails paramCertificateDetails)
/*     */     throws SQLServerException
/*     */   {
/* 303 */     byte[] arrayOfByte = null;
/*     */     try
/*     */     {
/* 306 */       Cipher localCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/* 307 */       localCipher.init(1, paramCertificateDetails.certificate.getPublicKey());
/* 308 */       localCipher.update(paramArrayOfByte);
/* 309 */       arrayOfByte = localCipher.doFinal();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (InvalidKeyException|NoSuchAlgorithmException|IllegalBlockSizeException|NoSuchPaddingException|BadPaddingException localInvalidKeyException)
/*     */     {
/*     */ 
/*     */ 
/* 317 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */       
/* 319 */       Object[] arrayOfObject = { localInvalidKeyException.getMessage() };
/* 320 */       throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/*     */     
/* 323 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */   private byte[] rsaSignHashedData(byte[] paramArrayOfByte, CertificateDetails paramCertificateDetails)
/*     */     throws SQLServerException
/*     */   {
/* 329 */     byte[] arrayOfByte = null;
/*     */     try
/*     */     {
/* 332 */       Signature localSignature = Signature.getInstance("SHA256withRSA");
/* 333 */       localSignature.initSign((PrivateKey)paramCertificateDetails.privateKey);
/* 334 */       localSignature.update(paramArrayOfByte);
/* 335 */       arrayOfByte = localSignature.sign();
/*     */     } catch (InvalidKeyException|NoSuchAlgorithmException|SignatureException localInvalidKeyException) {
/* 337 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */       
/* 339 */       Object[] arrayOfObject = { localInvalidKeyException.getMessage() };
/* 340 */       throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/*     */     
/* 343 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getLittleEndianBytesFromShort(short paramShort)
/*     */   {
/* 352 */     ByteBuffer localByteBuffer = ByteBuffer.allocate(2);
/* 353 */     localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 354 */     byte[] arrayOfByte = localByteBuffer.putShort(paramShort).array();
/* 355 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerColumnEncryptionJavaKeyStoreProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */