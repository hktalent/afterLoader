/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.ShortBufferException;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerAeadAes256CbcHmac256Algorithm
/*     */   extends SQLServerEncryptionAlgorithm
/*     */ {
/*  28 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerAeadAes256CbcHmac256Algorithm");
/*     */   
/*     */ 
/*     */   static final String algorithmName = "AEAD_AES_256_CBC_HMAC_SHA256";
/*     */   
/*     */   private SQLServerAeadAes256CbcHmac256EncryptionKey columnEncryptionkey;
/*     */   
/*     */   private byte algorithmVersion;
/*     */   
/*  37 */   private boolean isDeterministic = false;
/*     */   
/*  39 */   private int blockSizeInBytes = 16;
/*  40 */   private int keySizeInBytes = 32;
/*  41 */   private byte[] version = { 1 };
/*     */   
/*  43 */   private byte[] versionSize = { 1 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private int minimumCipherTextLengthInBytesNoAuthenticationTag = 1 + this.blockSizeInBytes + this.blockSizeInBytes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private int minimumCipherTextLengthInBytesWithAuthenticationTag = this.minimumCipherTextLengthInBytesNoAuthenticationTag + this.keySizeInBytes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLServerAeadAes256CbcHmac256Algorithm(SQLServerAeadAes256CbcHmac256EncryptionKey paramSQLServerAeadAes256CbcHmac256EncryptionKey, SQLServerEncryptionType paramSQLServerEncryptionType, byte paramByte)
/*     */   {
/*  75 */     this.columnEncryptionkey = paramSQLServerAeadAes256CbcHmac256EncryptionKey;
/*     */     
/*  77 */     if (paramSQLServerEncryptionType == SQLServerEncryptionType.Deterministic)
/*     */     {
/*  79 */       this.isDeterministic = true;
/*     */     }
/*  81 */     this.algorithmVersion = paramByte;
/*  82 */     this.version[0] = paramByte;
/*     */   }
/*     */   
/*     */   byte[] encryptData(byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/*  88 */     return encryptData(paramArrayOfByte, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] encryptData(byte[] paramArrayOfByte, boolean paramBoolean)
/*     */     throws SQLServerException
/*     */   {
/*  99 */     aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Encrypting data.");
/*     */     
/*     */ 
/* 102 */     assert (paramArrayOfByte != null);
/* 103 */     byte[] arrayOfByte1 = new byte[this.blockSizeInBytes];
/*     */     
/* 105 */     SecretKeySpec localSecretKeySpec1 = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");
/*     */     
/*     */ 
/* 108 */     if (this.isDeterministic)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/* 113 */         arrayOfByte1 = SQLServerSecurityUtility.getHMACWithSHA256(paramArrayOfByte, this.columnEncryptionkey.getIVKey(), this.blockSizeInBytes);
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (InvalidKeyException|NoSuchAlgorithmException localInvalidKeyException)
/*     */       {
/*     */ 
/* 120 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */         
/* 122 */         Object[] arrayOfObject1 = { localInvalidKeyException.getMessage() };
/* 123 */         throw new SQLServerException(this, localMessageFormat.format(arrayOfObject1), null, 0, false);
/*     */       }
/*     */     } else {
/* 126 */       SecureRandom localSecureRandom = new SecureRandom();
/* 127 */       localSecureRandom.nextBytes(arrayOfByte1);
/*     */     }
/*     */     
/*     */ 
/* 131 */     int i = paramArrayOfByte.length / this.blockSizeInBytes + 1;
/*     */     
/* 133 */     int j = 1;
/* 134 */     int k = paramBoolean ? this.keySizeInBytes : 0;
/* 135 */     int m = j + k;
/* 136 */     int n = m + this.blockSizeInBytes;
/*     */     
/*     */ 
/* 139 */     int i1 = 1 + k + arrayOfByte1.length + i * this.blockSizeInBytes;
/* 140 */     byte[] arrayOfByte2 = new byte[i1];
/*     */     
/*     */ 
/* 143 */     arrayOfByte2[0] = this.algorithmVersion;
/*     */     
/* 145 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, m, arrayOfByte1.length);
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 151 */       IvParameterSpec localIvParameterSpec = new IvParameterSpec(arrayOfByte1);
/* 152 */       localObject = Cipher.getInstance("AES/CBC/PKCS5Padding");
/* 153 */       ((Cipher)localObject).init(1, localSecretKeySpec1, localIvParameterSpec);
/*     */       
/* 155 */       int i2 = 0;
/* 156 */       int i3 = n;
/*     */       
/* 158 */       if (i > 1) {
/* 159 */         i2 = (i - 1) * this.blockSizeInBytes;
/* 160 */         i3 += ((Cipher)localObject).update(paramArrayOfByte, 0, i2, arrayOfByte2, i3);
/*     */       }
/*     */       
/* 163 */       byte[] arrayOfByte3 = ((Cipher)localObject).doFinal(paramArrayOfByte, i2, paramArrayOfByte.length - i2);
/*     */       
/* 165 */       System.arraycopy(arrayOfByte3, 0, arrayOfByte2, i3, arrayOfByte3.length);
/*     */       
/* 167 */       if (paramBoolean)
/*     */       {
/* 169 */         Mac localMac = Mac.getInstance("HmacSHA256");
/* 170 */         SecretKeySpec localSecretKeySpec2 = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
/* 171 */         localMac.init(localSecretKeySpec2);
/* 172 */         localMac.update(this.version, 0, this.version.length);
/* 173 */         localMac.update(arrayOfByte1, 0, arrayOfByte1.length);
/* 174 */         localMac.update(arrayOfByte2, n, i * this.blockSizeInBytes);
/* 175 */         localMac.update(this.versionSize, 0, this.version.length);
/* 176 */         byte[] arrayOfByte4 = localMac.doFinal();
/*     */         
/* 178 */         System.arraycopy(arrayOfByte4, 0, arrayOfByte2, j, k);
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (NoSuchAlgorithmException|InvalidAlgorithmParameterException|InvalidKeyException|NoSuchPaddingException|IllegalBlockSizeException|BadPaddingException|ShortBufferException localNoSuchAlgorithmException)
/*     */     {
/*     */ 
/*     */ 
/* 190 */       Object localObject = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */       
/* 192 */       Object[] arrayOfObject2 = { localNoSuchAlgorithmException.getMessage() };
/* 193 */       throw new SQLServerException(this, ((MessageFormat)localObject).format(arrayOfObject2), null, 0, false);
/*     */     }
/*     */     
/* 196 */     aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Data encrypted.");
/* 197 */     return arrayOfByte2;
/*     */   }
/*     */   
/*     */ 
/*     */   byte[] decryptData(byte[] paramArrayOfByte)
/*     */     throws SQLServerException
/*     */   {
/* 204 */     return decryptData(paramArrayOfByte, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] decryptData(byte[] paramArrayOfByte, boolean paramBoolean)
/*     */     throws SQLServerException
/*     */   {
/* 216 */     assert (paramArrayOfByte != null);
/*     */     
/* 218 */     byte[] arrayOfByte1 = new byte[this.blockSizeInBytes];
/*     */     
/* 220 */     int i = paramBoolean ? this.minimumCipherTextLengthInBytesWithAuthenticationTag : this.minimumCipherTextLengthInBytesNoAuthenticationTag;
/*     */     
/*     */     Object localObject;
/*     */     
/* 224 */     if (paramArrayOfByte.length < i) {
/* 225 */       MessageFormat localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidCipherTextSize"));
/* 226 */       localObject = new Object[] { Integer.valueOf(paramArrayOfByte.length), Integer.valueOf(i) };
/* 227 */       throw new SQLServerException(this, localMessageFormat1.format(localObject), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 232 */     Object[] arrayOfObject1 = 0;
/* 233 */     if (paramArrayOfByte[arrayOfObject1] != this.algorithmVersion) {
/* 234 */       localObject = new MessageFormat(SQLServerException.getErrString("R_InvalidAlgorithmVersion"));
/*     */       
/* 236 */       arrayOfObject2 = new Object[] { String.format("%02X ", new Object[] { Byte.valueOf(paramArrayOfByte[arrayOfObject1]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.algorithmVersion) }) };
/* 237 */       throw new SQLServerException(this, ((MessageFormat)localObject).format(arrayOfObject2), null, 0, false);
/*     */     }
/*     */     
/*     */ 
/* 241 */     arrayOfObject1++;
/* 242 */     int j = 0;
/*     */     
/*     */ 
/* 245 */     if (paramBoolean) {
/* 246 */       j = arrayOfObject1;
/*     */       
/* 248 */       arrayOfObject1 += this.keySizeInBytes;
/*     */     }
/*     */     
/*     */ 
/* 252 */     System.arraycopy(paramArrayOfByte, arrayOfObject1, arrayOfByte1, 0, arrayOfByte1.length);
/* 253 */     arrayOfObject1 += arrayOfByte1.length;
/*     */     
/*     */ 
/* 256 */     Object[] arrayOfObject2 = arrayOfObject1;
/*     */     
/* 258 */     int k = paramArrayOfByte.length - arrayOfObject1;
/*     */     
/* 260 */     if (paramBoolean)
/*     */     {
/*     */       byte[] arrayOfByte2;
/*     */       try {
/* 264 */         arrayOfByte2 = prepareAuthenticationTag(arrayOfByte1, paramArrayOfByte, arrayOfObject2, k);
/*     */       }
/*     */       catch (InvalidKeyException|NoSuchAlgorithmException localInvalidKeyException)
/*     */       {
/* 268 */         MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
/*     */         
/* 270 */         Object[] arrayOfObject3 = { localInvalidKeyException.getMessage() };
/* 271 */         throw new SQLServerException(this, localMessageFormat2.format(arrayOfObject3), null, 0, false);
/*     */       }
/*     */       
/* 274 */       if (!SQLServerSecurityUtility.compareBytes(arrayOfByte2, paramArrayOfByte, j, k))
/*     */       {
/* 276 */         throw new SQLServerException(this, SQLServerException.getErrString("R_InvalidAuthenticationTag"), null, 0, false);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 283 */     return decryptData(arrayOfByte1, paramArrayOfByte, arrayOfObject2, k);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] decryptData(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
/*     */     throws SQLServerException
/*     */   {
/* 296 */     aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Decrypting data.");
/* 297 */     assert (paramArrayOfByte2 != null);
/* 298 */     assert (paramArrayOfByte1 != null);
/* 299 */     byte[] arrayOfByte = null;
/*     */     
/* 301 */     SecretKeySpec localSecretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");
/*     */     
/* 303 */     IvParameterSpec localIvParameterSpec = new IvParameterSpec(paramArrayOfByte1);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 308 */       Cipher localCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/* 309 */       localCipher.init(2, localSecretKeySpec, localIvParameterSpec);
/* 310 */       arrayOfByte = localCipher.doFinal(paramArrayOfByte2, paramInt1, paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (NoSuchAlgorithmException|InvalidAlgorithmParameterException|InvalidKeyException|NoSuchPaddingException|IllegalBlockSizeException|BadPaddingException localNoSuchAlgorithmException)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 321 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
/*     */       
/* 323 */       Object[] arrayOfObject = { localNoSuchAlgorithmException.getMessage() };
/* 324 */       throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/*     */     
/* 327 */     aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Data decrypted.");
/* 328 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] prepareAuthenticationTag(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
/*     */     throws NoSuchAlgorithmException, InvalidKeyException
/*     */   {
/* 344 */     assert (paramArrayOfByte2 != null);
/*     */     
/* 346 */     byte[] arrayOfByte2 = new byte[this.keySizeInBytes];
/*     */     
/* 348 */     Mac localMac = Mac.getInstance("HmacSHA256");
/* 349 */     SecretKeySpec localSecretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
/*     */     
/* 351 */     localMac.init(localSecretKeySpec);
/* 352 */     localMac.update(this.version, 0, this.version.length);
/* 353 */     localMac.update(paramArrayOfByte1, 0, paramArrayOfByte1.length);
/* 354 */     localMac.update(paramArrayOfByte2, paramInt1, paramInt2);
/* 355 */     localMac.update(this.versionSize, 0, this.version.length);
/* 356 */     byte[] arrayOfByte1 = localMac.doFinal();
/* 357 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);
/*     */     
/*     */ 
/*     */ 
/* 361 */     return arrayOfByte2;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerAeadAes256CbcHmac256Algorithm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */