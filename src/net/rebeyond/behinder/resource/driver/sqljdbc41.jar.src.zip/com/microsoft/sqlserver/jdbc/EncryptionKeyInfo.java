/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ class EncryptionKeyInfo
/*    */ {
/*    */   byte[] encryptedKey;
/*    */   
/*    */   int databaseId;
/*    */   int cekId;
/*    */   int cekVersion;
/*    */   byte[] cekMdVersion;
/*    */   String keyPath;
/*    */   String keyStoreName;
/*    */   String algorithmName;
/*    */   byte normalizationRuleVersion;
/*    */   
/*    */   EncryptionKeyInfo(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte2, String paramString1, String paramString2, String paramString3)
/*    */   {
/* 19 */     this.encryptedKey = paramArrayOfByte1;
/* 20 */     this.databaseId = paramInt1;
/* 21 */     this.cekId = paramInt2;
/* 22 */     this.cekVersion = paramInt3;
/* 23 */     this.cekMdVersion = paramArrayOfByte2;
/* 24 */     this.keyPath = paramString1;
/* 25 */     this.keyStoreName = paramString2;
/* 26 */     this.algorithmName = paramString3;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/EncryptionKeyInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */