/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.security.KeyStore;
/*      */ import java.security.Provider;
/*      */ import java.security.Security;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Properties;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLSocket;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.TrustManagerFactory;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ import javax.security.auth.x500.X500Principal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class TDSChannel
/*      */ {
/*  466 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Channel");
/*  467 */   final Logger getLogger() { return logger; }
/*      */   
/*  469 */   public final String toString() { return this.traceID; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  474 */   final TDSWriter getWriter() { return this.tdsWriter; }
/*  475 */   final TDSReader getReader(TDSCommand paramTDSCommand) { return new TDSReader(this, this.con, paramTDSCommand); }
/*      */   
/*      */ 
/*      */ 
/*      */   private final String traceID;
/*      */   
/*      */ 
/*      */   private final SQLServerConnection con;
/*      */   
/*      */   private final TDSWriter tdsWriter;
/*      */   
/*      */   private Socket tcpSocket;
/*      */   
/*      */   private SSLSocket sslSocket;
/*      */   
/*      */   private Socket channelSocket;
/*      */   
/*  492 */   ProxySocket proxySocket = null;
/*      */   
/*      */ 
/*      */   private InputStream tcpInputStream;
/*      */   
/*      */ 
/*      */   private OutputStream tcpOutputStream;
/*      */   
/*      */ 
/*      */   private InputStream inputStream;
/*      */   
/*      */ 
/*      */   private OutputStream outputStream;
/*      */   
/*  506 */   private static Logger packetLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.DATA");
/*  507 */   private final boolean isLoggingPackets = packetLogger.isLoggable(Level.FINEST);
/*  508 */   final boolean isLoggingPackets() { return this.isLoggingPackets; }
/*      */   
/*      */ 
/*  511 */   int numMsgsSent = 0;
/*  512 */   int numMsgsRcvd = 0;
/*      */   
/*      */ 
/*      */ 
/*  516 */   private int spid = 0;
/*  517 */   void setSPID(int paramInt) { this.spid = paramInt; }
/*  518 */   int getSPID() { return this.spid; }
/*  519 */   void resetPooledConnection() { this.tdsWriter.resetPooledConnection(); }
/*      */   
/*      */   TDSChannel(SQLServerConnection paramSQLServerConnection)
/*      */   {
/*  523 */     this.con = paramSQLServerConnection;
/*  524 */     this.traceID = ("TDSChannel (" + paramSQLServerConnection.toString() + ")");
/*  525 */     this.tcpSocket = null;
/*  526 */     this.sslSocket = null;
/*  527 */     this.channelSocket = null;
/*  528 */     this.tcpInputStream = null;
/*  529 */     this.tcpOutputStream = null;
/*  530 */     this.inputStream = null;
/*  531 */     this.outputStream = null;
/*  532 */     this.tdsWriter = new TDSWriter(this, paramSQLServerConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void open(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3)
/*      */     throws SQLServerException
/*      */   {
/*  547 */     if (logger.isLoggable(Level.FINER)) {
/*  548 */       logger.finer(toString() + ": Opening TCP socket...");
/*      */     }
/*  550 */     SocketFinder localSocketFinder = new SocketFinder(this.traceID, this.con);
/*  551 */     this.channelSocket = (this.tcpSocket = localSocketFinder.findSocket(paramString, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3));
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  557 */       this.tcpSocket.setTcpNoDelay(true);
/*  558 */       this.tcpSocket.setKeepAlive(true);
/*      */       
/*  560 */       this.inputStream = (this.tcpInputStream = this.tcpSocket.getInputStream());
/*  561 */       this.outputStream = (this.tcpOutputStream = this.tcpSocket.getOutputStream());
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  565 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.con, localIOException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void disableSSL()
/*      */   {
/*  574 */     if (logger.isLoggable(Level.FINER)) {
/*  575 */       logger.finer(toString() + " Disabling SSL...");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  594 */     ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(new byte[0]);
/*      */     try
/*      */     {
/*  597 */       localByteArrayInputStream.close();
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException1)
/*      */     {
/*      */ 
/*  603 */       logger.fine("Ignored error closing InputStream: " + localIOException1.getMessage());
/*      */     }
/*      */     
/*  606 */     ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*      */     try
/*      */     {
/*  609 */       localByteArrayOutputStream.close();
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/*      */ 
/*  615 */       logger.fine("Ignored error closing OutputStream: " + localIOException2.getMessage());
/*      */     }
/*      */     
/*      */ 
/*  619 */     if (logger.isLoggable(Level.FINEST))
/*  620 */       logger.finest(toString() + " Rewiring proxy streams for SSL socket close");
/*  621 */     this.proxySocket.setStreams(localByteArrayInputStream, localByteArrayOutputStream);
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  627 */       if (logger.isLoggable(Level.FINER)) {
/*  628 */         logger.finer(toString() + " Closing SSL socket");
/*      */       }
/*  630 */       this.sslSocket.close();
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException3)
/*      */     {
/*  635 */       logger.fine("Ignored error closing SSLSocket: " + localIOException3.getMessage());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  641 */     this.proxySocket = null;
/*      */     
/*      */ 
/*      */ 
/*  645 */     this.inputStream = this.tcpInputStream;
/*  646 */     this.outputStream = this.tcpOutputStream;
/*  647 */     this.channelSocket = this.tcpSocket;
/*  648 */     this.sslSocket = null;
/*      */     
/*  650 */     if (logger.isLoggable(Level.FINER)) {
/*  651 */       logger.finer(toString() + " SSL disabled");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private class SSLHandshakeInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private final TDSReader tdsReader;
/*      */     
/*      */     private final TDSChannel.SSLHandshakeOutputStream sslHandshakeOutputStream;
/*      */     
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */ 
/*      */     SSLHandshakeInputStream(TDSChannel paramTDSChannel, TDSChannel.SSLHandshakeOutputStream paramSSLHandshakeOutputStream)
/*      */     {
/*  670 */       this.tdsReader = paramTDSChannel.getReader(null);
/*  671 */       this.sslHandshakeOutputStream = paramSSLHandshakeOutputStream;
/*  672 */       this.logger = paramTDSChannel.getLogger();
/*  673 */       this.logContext = (paramTDSChannel.toString() + " (SSLHandshakeInputStream):");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final void ensureSSLPayload()
/*      */       throws IOException
/*      */     {
/*  686 */       if (0 == this.tdsReader.available())
/*      */       {
/*  688 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  689 */           this.logger.finest(this.logContext + " No handshake response bytes available. Flushing SSL handshake output stream.");
/*      */         }
/*      */         try
/*      */         {
/*  693 */           this.sslHandshakeOutputStream.endMessage();
/*      */         }
/*      */         catch (SQLServerException localSQLServerException1)
/*      */         {
/*  697 */           this.logger.finer(this.logContext + " Ending TDS message threw exception:" + localSQLServerException1.getMessage());
/*  698 */           throw new IOException(localSQLServerException1.getMessage());
/*      */         }
/*      */         
/*  701 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  702 */           this.logger.finest(this.logContext + " Reading first packet of SSL handshake response");
/*      */         }
/*      */         try
/*      */         {
/*  706 */           this.tdsReader.readPacket();
/*      */         }
/*      */         catch (SQLServerException localSQLServerException2)
/*      */         {
/*  710 */           this.logger.finer(this.logContext + " Reading response packet threw exception:" + localSQLServerException2.getMessage());
/*  711 */           throw new IOException(localSQLServerException2.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public long skip(long paramLong) throws IOException
/*      */     {
/*  718 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  719 */         this.logger.finest(this.logContext + " Skipping " + paramLong + " bytes...");
/*      */       }
/*  721 */       if (paramLong <= 0L) { return 0L;
/*      */       }
/*  723 */       if (paramLong > 2147483647L) {
/*  724 */         paramLong = 2147483647L;
/*      */       }
/*  726 */       ensureSSLPayload();
/*      */       
/*      */       try
/*      */       {
/*  730 */         this.tdsReader.skip((int)paramLong);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  734 */         this.logger.finer(this.logContext + " Skipping bytes threw exception:" + localSQLServerException.getMessage());
/*  735 */         throw new IOException(localSQLServerException.getMessage());
/*      */       }
/*      */       
/*  738 */       return paramLong;
/*      */     }
/*      */     
/*  741 */     private final byte[] oneByte = new byte[1];
/*      */     
/*      */     public int read() throws IOException
/*      */     {
/*      */       int i;
/*  746 */       while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length))) {}
/*      */       
/*      */ 
/*  749 */       assert ((1 == i) || (-1 == i));
/*  750 */       return 1 == i ? this.oneByte[0] : -1;
/*      */     }
/*      */     
/*      */     public int read(byte[] paramArrayOfByte) throws IOException
/*      */     {
/*  755 */       return readInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */     
/*      */     public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  760 */       return readInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     
/*      */     private int readInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  765 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  766 */         this.logger.finest(this.logContext + " Reading " + paramInt2 + " bytes...");
/*      */       }
/*  768 */       ensureSSLPayload();
/*      */       
/*      */       try
/*      */       {
/*  772 */         this.tdsReader.readBytes(paramArrayOfByte, paramInt1, paramInt2);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  776 */         this.logger.finer(this.logContext + " Reading bytes threw exception:" + localSQLServerException.getMessage());
/*  777 */         throw new IOException(localSQLServerException.getMessage());
/*      */       }
/*      */       
/*  780 */       return paramInt2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private class SSLHandshakeOutputStream
/*      */     extends OutputStream
/*      */   {
/*      */     private final TDSWriter tdsWriter;
/*      */     
/*      */     private boolean messageStarted;
/*      */     
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */ 
/*      */     SSLHandshakeOutputStream(TDSChannel paramTDSChannel)
/*      */     {
/*  800 */       this.tdsWriter = paramTDSChannel.getWriter();
/*  801 */       this.messageStarted = false;
/*  802 */       this.logger = paramTDSChannel.getLogger();
/*  803 */       this.logContext = (paramTDSChannel.toString() + " (SSLHandshakeOutputStream):");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void flush()
/*      */       throws IOException
/*      */     {
/*  815 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  816 */         this.logger.finest(this.logContext + " Ignored a request to flush the stream");
/*      */       }
/*      */     }
/*      */     
/*      */     void endMessage() throws SQLServerException
/*      */     {
/*  822 */       assert (this.messageStarted);
/*      */       
/*  824 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  825 */         this.logger.finest(this.logContext + " Finishing TDS message");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  830 */       this.tdsWriter.endMessage();
/*  831 */       this.messageStarted = false;
/*      */     }
/*      */     
/*  834 */     private final byte[] singleByte = new byte[1];
/*      */     
/*      */     public void write(int paramInt) throws IOException {
/*  837 */       this.singleByte[0] = ((byte)(paramInt & 0xFF));
/*  838 */       writeInternal(this.singleByte, 0, this.singleByte.length);
/*      */     }
/*      */     
/*      */     public void write(byte[] paramArrayOfByte) throws IOException
/*      */     {
/*  843 */       writeInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */     
/*      */     public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  848 */       writeInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     
/*      */ 
/*      */     private void writeInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */       throws IOException
/*      */     {
/*      */       try
/*      */       {
/*  857 */         if (!this.messageStarted)
/*      */         {
/*  859 */           if (this.logger.isLoggable(Level.FINEST)) {
/*  860 */             this.logger.finest(this.logContext + " Starting new TDS packet...");
/*      */           }
/*  862 */           this.tdsWriter.startMessage(null, (byte)18);
/*  863 */           this.messageStarted = true;
/*      */         }
/*      */         
/*  866 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  867 */           this.logger.finest(this.logContext + " Writing " + paramInt2 + " bytes...");
/*      */         }
/*  869 */         this.tdsWriter.writeBytes(paramArrayOfByte, paramInt1, paramInt2);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  873 */         this.logger.finer(this.logContext + " Writing bytes threw exception:" + localSQLServerException.getMessage());
/*  874 */         throw new IOException(localSQLServerException.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final class ProxyInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private InputStream filteredStream;
/*      */     
/*      */ 
/*      */ 
/*      */     ProxyInputStream(InputStream paramInputStream)
/*      */     {
/*  891 */       this.filteredStream = paramInputStream;
/*      */     }
/*      */     
/*      */     final void setFilteredStream(InputStream paramInputStream)
/*      */     {
/*  896 */       this.filteredStream = paramInputStream;
/*      */     }
/*      */     
/*      */ 
/*      */     public long skip(long paramLong)
/*      */       throws IOException
/*      */     {
/*  903 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  904 */         TDSChannel.logger.finest(toString() + " Skipping " + paramLong + " bytes");
/*      */       }
/*  906 */       long l = this.filteredStream.skip(paramLong);
/*      */       
/*  908 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  909 */         TDSChannel.logger.finest(toString() + " Skipped " + paramLong + " bytes");
/*      */       }
/*  911 */       return l;
/*      */     }
/*      */     
/*      */     public int available() throws IOException
/*      */     {
/*  916 */       int i = this.filteredStream.available();
/*      */       
/*  918 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  919 */         TDSChannel.logger.finest(toString() + " " + i + " bytes available");
/*      */       }
/*  921 */       return i;
/*      */     }
/*      */     
/*  924 */     private final byte[] oneByte = new byte[1];
/*      */     
/*      */     public int read() throws IOException
/*      */     {
/*      */       int i;
/*  929 */       while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length))) {}
/*      */       
/*      */ 
/*  932 */       assert ((1 == i) || (-1 == i));
/*  933 */       return 1 == i ? this.oneByte[0] : -1;
/*      */     }
/*      */     
/*      */     public int read(byte[] paramArrayOfByte) throws IOException
/*      */     {
/*  938 */       return readInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */     
/*      */     public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/*  943 */       return readInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     
/*      */ 
/*      */     private int readInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */       throws IOException
/*      */     {
/*  950 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  951 */         TDSChannel.logger.finest(toString() + " Reading " + paramInt2 + " bytes");
/*      */       }
/*      */       int i;
/*      */       try {
/*  955 */         i = this.filteredStream.read(paramArrayOfByte, paramInt1, paramInt2);
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*  959 */         if (TDSChannel.logger.isLoggable(Level.FINER)) {
/*  960 */           TDSChannel.logger.finer(toString() + " " + localIOException.getMessage());
/*      */         }
/*  962 */         TDSChannel.logger.finer(toString() + " Reading bytes threw exception:" + localIOException.getMessage());
/*  963 */         throw localIOException;
/*      */       }
/*      */       
/*  966 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  967 */         TDSChannel.logger.finest(toString() + " Read " + i + " bytes");
/*      */       }
/*  969 */       return i;
/*      */     }
/*      */     
/*      */     public boolean markSupported()
/*      */     {
/*  974 */       boolean bool = this.filteredStream.markSupported();
/*      */       
/*  976 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  977 */         TDSChannel.logger.finest(toString() + " Returning markSupported: " + bool);
/*      */       }
/*  979 */       return bool;
/*      */     }
/*      */     
/*      */     public void mark(int paramInt)
/*      */     {
/*  984 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  985 */         TDSChannel.logger.finest(toString() + " Marking next " + paramInt + " bytes");
/*      */       }
/*  987 */       this.filteredStream.mark(paramInt);
/*      */     }
/*      */     
/*      */     public void reset() throws IOException
/*      */     {
/*  992 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  993 */         TDSChannel.logger.finest(toString() + " Resetting to previous mark");
/*      */       }
/*  995 */       this.filteredStream.reset();
/*      */     }
/*      */     
/*      */     public void close() throws IOException
/*      */     {
/* 1000 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1001 */         TDSChannel.logger.finest(toString() + " Closing");
/*      */       }
/* 1003 */       this.filteredStream.close();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final class ProxyOutputStream
/*      */     extends OutputStream
/*      */   {
/*      */     private OutputStream filteredStream;
/*      */     
/*      */ 
/*      */ 
/*      */     ProxyOutputStream(OutputStream paramOutputStream)
/*      */     {
/* 1019 */       this.filteredStream = paramOutputStream;
/*      */     }
/*      */     
/*      */     final void setFilteredStream(OutputStream paramOutputStream)
/*      */     {
/* 1024 */       this.filteredStream = paramOutputStream;
/*      */     }
/*      */     
/*      */     public void close() throws IOException
/*      */     {
/* 1029 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1030 */         TDSChannel.logger.finest(toString() + " Closing");
/*      */       }
/* 1032 */       this.filteredStream.close();
/*      */     }
/*      */     
/*      */     public void flush() throws IOException
/*      */     {
/* 1037 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1038 */         TDSChannel.logger.finest(toString() + " Flushing");
/*      */       }
/* 1040 */       this.filteredStream.flush();
/*      */     }
/*      */     
/* 1043 */     private final byte[] singleByte = new byte[1];
/*      */     
/*      */     public void write(int paramInt) throws IOException {
/* 1046 */       this.singleByte[0] = ((byte)(paramInt & 0xFF));
/* 1047 */       writeInternal(this.singleByte, 0, this.singleByte.length);
/*      */     }
/*      */     
/*      */     public void write(byte[] paramArrayOfByte) throws IOException
/*      */     {
/* 1052 */       writeInternal(paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */     }
/*      */     
/*      */     public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/* 1057 */       writeInternal(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     
/*      */     private void writeInternal(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException
/*      */     {
/* 1062 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1063 */         TDSChannel.logger.finest(toString() + " Writing " + paramInt2 + " bytes");
/*      */       }
/* 1065 */       this.filteredStream.write(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private class ProxySocket
/*      */     extends Socket
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */     
/*      */ 
/*      */     private final Logger logger;
/*      */     
/*      */ 
/*      */     private final String logContext;
/*      */     
/*      */ 
/*      */     private final TDSChannel.ProxyInputStream proxyInputStream;
/*      */     
/*      */ 
/*      */     private final TDSChannel.ProxyOutputStream proxyOutputStream;
/*      */     
/*      */ 
/*      */ 
/*      */     ProxySocket(TDSChannel paramTDSChannel)
/*      */     {
/* 1092 */       this.tdsChannel = paramTDSChannel;
/* 1093 */       this.logger = paramTDSChannel.getLogger();
/* 1094 */       this.logContext = (paramTDSChannel.toString() + " (ProxySocket):");
/*      */       
/*      */ 
/* 1097 */       TDSChannel.SSLHandshakeOutputStream localSSLHandshakeOutputStream = new TDSChannel.SSLHandshakeOutputStream(TDSChannel.this, paramTDSChannel);
/* 1098 */       TDSChannel.SSLHandshakeInputStream localSSLHandshakeInputStream = new TDSChannel.SSLHandshakeInputStream(TDSChannel.this, paramTDSChannel, localSSLHandshakeOutputStream);
/* 1099 */       this.proxyOutputStream = new TDSChannel.ProxyOutputStream(TDSChannel.this, localSSLHandshakeOutputStream);
/* 1100 */       this.proxyInputStream = new TDSChannel.ProxyInputStream(TDSChannel.this, localSSLHandshakeInputStream);
/*      */     }
/*      */     
/*      */     void setStreams(InputStream paramInputStream, OutputStream paramOutputStream)
/*      */     {
/* 1105 */       this.proxyInputStream.setFilteredStream(paramInputStream);
/* 1106 */       this.proxyOutputStream.setFilteredStream(paramOutputStream);
/*      */     }
/*      */     
/*      */     public InputStream getInputStream() throws IOException
/*      */     {
/* 1111 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1112 */         this.logger.finest(this.logContext + " Getting input stream");
/*      */       }
/* 1114 */       return this.proxyInputStream;
/*      */     }
/*      */     
/*      */     public OutputStream getOutputStream() throws IOException
/*      */     {
/* 1119 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1120 */         this.logger.finest(this.logContext + " Getting output stream");
/*      */       }
/* 1122 */       return this.proxyOutputStream;
/*      */     }
/*      */     
/*      */ 
/* 1126 */     public InetAddress getInetAddress() { return this.tdsChannel.tcpSocket.getInetAddress(); }
/* 1127 */     public boolean getKeepAlive() throws SocketException { return this.tdsChannel.tcpSocket.getKeepAlive(); }
/* 1128 */     public InetAddress getLocalAddress() { return this.tdsChannel.tcpSocket.getLocalAddress(); }
/* 1129 */     public int getLocalPort() { return this.tdsChannel.tcpSocket.getLocalPort(); }
/* 1130 */     public SocketAddress getLocalSocketAddress() { return this.tdsChannel.tcpSocket.getLocalSocketAddress(); }
/* 1131 */     public boolean getOOBInline() throws SocketException { return this.tdsChannel.tcpSocket.getOOBInline(); }
/* 1132 */     public int getPort() { return this.tdsChannel.tcpSocket.getPort(); }
/* 1133 */     public int getReceiveBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getReceiveBufferSize(); }
/* 1134 */     public SocketAddress getRemoteSocketAddress() { return this.tdsChannel.tcpSocket.getRemoteSocketAddress(); }
/* 1135 */     public boolean getReuseAddress() throws SocketException { return this.tdsChannel.tcpSocket.getReuseAddress(); }
/* 1136 */     public int getSendBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getSendBufferSize(); }
/* 1137 */     public int getSoLinger() throws SocketException { return this.tdsChannel.tcpSocket.getSoLinger(); }
/* 1138 */     public int getSoTimeout() throws SocketException { return this.tdsChannel.tcpSocket.getSoTimeout(); }
/* 1139 */     public boolean getTcpNoDelay() throws SocketException { return this.tdsChannel.tcpSocket.getTcpNoDelay(); }
/* 1140 */     public int getTrafficClass() throws SocketException { return this.tdsChannel.tcpSocket.getTrafficClass(); }
/* 1141 */     public boolean isBound() { return true; }
/* 1142 */     public boolean isClosed() { return false; }
/* 1143 */     public boolean isConnected() { return true; }
/* 1144 */     public boolean isInputShutdown() { return false; }
/* 1145 */     public boolean isOutputShutdown() { return false; }
/* 1146 */     public String toString() { return this.tdsChannel.tcpSocket.toString(); }
/* 1147 */     public SocketChannel getChannel() { return null; }
/*      */     
/*      */     public void bind(SocketAddress paramSocketAddress)
/*      */       throws IOException
/*      */     {
/* 1152 */       this.logger.finer(this.logContext + " Disallowed call to bind.  Throwing IOException.");
/* 1153 */       throw new IOException();
/*      */     }
/*      */     
/*      */     public void connect(SocketAddress paramSocketAddress) throws IOException
/*      */     {
/* 1158 */       this.logger.finer(this.logContext + " Disallowed call to connect (without timeout).  Throwing IOException.");
/* 1159 */       throw new IOException();
/*      */     }
/*      */     
/*      */     public void connect(SocketAddress paramSocketAddress, int paramInt) throws IOException
/*      */     {
/* 1164 */       this.logger.finer(this.logContext + " Disallowed call to connect (with timeout).  Throwing IOException.");
/* 1165 */       throw new IOException();
/*      */     }
/*      */     
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 1172 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1173 */         this.logger.finer(this.logContext + " Ignoring close");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setReceiveBufferSize(int paramInt) throws SocketException {
/* 1178 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1179 */         this.logger.finer(toString() + " Ignoring setReceiveBufferSize size:" + paramInt);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setSendBufferSize(int paramInt) throws SocketException {
/* 1184 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1185 */         this.logger.finer(toString() + " Ignoring setSendBufferSize size:" + paramInt);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setReuseAddress(boolean paramBoolean) throws SocketException {
/* 1190 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1191 */         this.logger.finer(toString() + " Ignoring setReuseAddress");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setSoLinger(boolean paramBoolean, int paramInt) throws SocketException {
/* 1196 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1197 */         this.logger.finer(toString() + " Ignoring setSoLinger");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setSoTimeout(int paramInt) throws SocketException {
/* 1202 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1203 */         this.logger.finer(toString() + " Ignoring setSoTimeout");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setTcpNoDelay(boolean paramBoolean) throws SocketException {
/* 1208 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1209 */         this.logger.finer(toString() + " Ignoring setTcpNoDelay");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setTrafficClass(int paramInt) throws SocketException {
/* 1214 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1215 */         this.logger.finer(toString() + " Ignoring setTrafficClass");
/*      */       }
/*      */     }
/*      */     
/*      */     public void shutdownInput() throws IOException {
/* 1220 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1221 */         this.logger.finer(toString() + " Ignoring shutdownInput");
/*      */       }
/*      */     }
/*      */     
/*      */     public void shutdownOutput() throws IOException {
/* 1226 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1227 */         this.logger.finer(toString() + " Ignoring shutdownOutput");
/*      */       }
/*      */     }
/*      */     
/*      */     public void sendUrgentData(int paramInt) throws IOException {
/* 1232 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1233 */         this.logger.finer(toString() + " Ignoring sendUrgentData");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setKeepAlive(boolean paramBoolean) throws SocketException {
/* 1238 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1239 */         this.logger.finer(toString() + " Ignoring setKeepAlive");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setOOBInline(boolean paramBoolean) throws SocketException {
/* 1244 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1245 */         this.logger.finer(toString() + " Ignoring setOOBInline");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private final class PermissiveX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */     
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */ 
/*      */     PermissiveX509TrustManager(TDSChannel paramTDSChannel)
/*      */     {
/* 1263 */       this.tdsChannel = paramTDSChannel;
/* 1264 */       this.logger = paramTDSChannel.getLogger();
/* 1265 */       this.logContext = (paramTDSChannel.toString() + " (PermissiveX509TrustManager):");
/*      */     }
/*      */     
/*      */     public void checkClientTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException
/*      */     {
/* 1270 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1271 */         this.logger.finer(this.logContext + " Trusting client certificate (!)");
/*      */       }
/*      */     }
/*      */     
/*      */     public void checkServerTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException {
/* 1276 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1277 */         this.logger.finer(this.logContext + " Trusting server certificate");
/*      */       }
/*      */     }
/*      */     
/*      */     public X509Certificate[] getAcceptedIssuers() {
/* 1282 */       return new X509Certificate[0];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private final class HostNameOverrideX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */     private final X509TrustManager defaultTrustManager;
/*      */     private String hostName;
/*      */     
/*      */     HostNameOverrideX509TrustManager(TDSChannel paramTDSChannel, X509TrustManager paramX509TrustManager, String paramString)
/*      */     {
/* 1299 */       this.logger = paramTDSChannel.getLogger();
/* 1300 */       this.logContext = (paramTDSChannel.toString() + " (HostNameOverrideX509TrustManager):");
/* 1301 */       this.defaultTrustManager = paramX509TrustManager;
/*      */       
/* 1303 */       this.hostName = paramString.toLowerCase();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private String parseCommonName(String paramString)
/*      */     {
/* 1314 */       int i = paramString.indexOf("cn=");
/* 1315 */       if (i == -1)
/*      */       {
/* 1317 */         return null;
/*      */       }
/* 1319 */       paramString = paramString.substring(i + 3);
/*      */       
/*      */ 
/*      */ 
/* 1323 */       for (i = 0; i < paramString.length(); i++)
/*      */       {
/* 1325 */         if (paramString.charAt(i) == ',') {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/* 1330 */       String str = paramString.substring(0, i);
/*      */       
/* 1332 */       if ((str.length() > 1) && ('"' == str.charAt(0)))
/*      */       {
/* 1334 */         if ('"' == str.charAt(str.length() - 1)) {
/* 1335 */           str = str.substring(1, str.length() - 1);
/*      */         }
/*      */         else
/*      */         {
/* 1339 */           str = null;
/*      */         }
/*      */       }
/* 1342 */       return str;
/*      */     }
/*      */     
/*      */     private boolean validateServerName(String paramString)
/*      */       throws CertificateException
/*      */     {
/* 1348 */       if (null == paramString)
/*      */       {
/* 1350 */         if (this.logger.isLoggable(Level.FINER))
/* 1351 */           this.logger.finer(this.logContext + " Failed to parse the name from the certificate or name is empty.");
/* 1352 */         return false;
/*      */       }
/*      */       
/*      */ 
/* 1356 */       if (!paramString.equals(this.hostName))
/*      */       {
/* 1358 */         if (this.logger.isLoggable(Level.FINER))
/* 1359 */           this.logger.finer(this.logContext + " The name in certificate " + paramString + " does not match with the server name " + this.hostName + ".");
/* 1360 */         return false;
/*      */       }
/*      */       
/* 1363 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1364 */         this.logger.finer(this.logContext + " The name in certificate:" + paramString + " validated against server name " + this.hostName + ".");
/*      */       }
/* 1366 */       return true;
/*      */     }
/*      */     
/*      */     public void checkClientTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException
/*      */     {
/* 1371 */       if (this.logger.isLoggable(Level.FINEST))
/* 1372 */         this.logger.finest(this.logContext + " Forwarding ClientTrusted.");
/* 1373 */       this.defaultTrustManager.checkClientTrusted(paramArrayOfX509Certificate, paramString);
/*      */     }
/*      */     
/*      */     public void checkServerTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws CertificateException
/*      */     {
/* 1378 */       if (this.logger.isLoggable(Level.FINEST))
/* 1379 */         this.logger.finest(this.logContext + " Forwarding Trusting server certificate");
/* 1380 */       this.defaultTrustManager.checkServerTrusted(paramArrayOfX509Certificate, paramString);
/* 1381 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1382 */         this.logger.finest(this.logContext + " default serverTrusted succeeded proceeding with server name validation");
/*      */       }
/* 1384 */       validateServerNameInCertificate(paramArrayOfX509Certificate[0]);
/*      */     }
/*      */     
/*      */     private void validateServerNameInCertificate(X509Certificate paramX509Certificate) throws CertificateException
/*      */     {
/* 1389 */       String str1 = paramX509Certificate.getSubjectX500Principal().getName("canonical");
/* 1390 */       if (this.logger.isLoggable(Level.FINER))
/*      */       {
/* 1392 */         this.logger.finer(this.logContext + " Validating the server name:" + this.hostName);
/* 1393 */         this.logger.finer(this.logContext + " The DN name in certificate:" + str1);
/*      */       }
/*      */       
/* 1396 */       boolean bool = false;
/*      */       
/*      */ 
/* 1399 */       String str2 = parseCommonName(str1);
/*      */       
/* 1401 */       bool = validateServerName(str2);
/*      */       Object localObject1;
/* 1403 */       if (!bool)
/*      */       {
/*      */ 
/* 1406 */         localObject1 = paramX509Certificate.getSubjectAlternativeNames();
/*      */         
/* 1408 */         if (localObject1 != null)
/*      */         {
/*      */ 
/* 1411 */           for (List localList : (Collection)localObject1)
/*      */           {
/*      */ 
/* 1414 */             if ((localList != null) && (localList.size() >= 2))
/*      */             {
/* 1416 */               Object localObject2 = localList.get(0);
/* 1417 */               Object localObject3 = localList.get(1);
/*      */               
/* 1419 */               if (this.logger.isLoggable(Level.FINER))
/*      */               {
/* 1421 */                 this.logger.finer(this.logContext + "Key: " + localObject2 + "; KeyClass:" + (localObject2 != null ? localObject2.getClass() : null) + ";value: " + localObject3 + "; valueClass:" + (localObject3 != null ? localObject3.getClass() : null));
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1435 */               if ((localObject2 != null) && ((localObject2 instanceof Integer)) && (((Integer)localObject2).intValue() == 2))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1443 */                 if ((localObject3 != null) && ((localObject3 instanceof String)))
/*      */                 {
/* 1445 */                   String str3 = (String)localObject3;
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1452 */                   str3 = str3.toUpperCase(Locale.US);
/* 1453 */                   str3 = str3.toLowerCase(Locale.US);
/*      */                   
/* 1455 */                   bool = validateServerName(str3);
/*      */                   
/* 1457 */                   if (bool)
/*      */                   {
/* 1459 */                     if (!this.logger.isLoggable(Level.FINER))
/*      */                       break;
/* 1461 */                     this.logger.finer(this.logContext + " found a valid name in certificate: " + str3); break;
/*      */                   }
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 1468 */                 if (this.logger.isLoggable(Level.FINER))
/*      */                 {
/* 1470 */                   this.logger.finer(this.logContext + " the following name in certificate does not match the serverName: " + localObject3);
/*      */ 
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */ 
/*      */             }
/* 1478 */             else if (this.logger.isLoggable(Level.FINER))
/*      */             {
/* 1480 */               this.logger.finer(this.logContext + " found an invalid san entry: " + localList);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1488 */       if (!bool)
/*      */       {
/* 1490 */         localObject1 = SQLServerException.getErrString("R_certNameFailed");
/* 1491 */         throw new CertificateException((String)localObject1);
/*      */       }
/*      */     }
/*      */     
/*      */     public X509Certificate[] getAcceptedIssuers()
/*      */     {
/* 1497 */       return this.defaultTrustManager.getAcceptedIssuers();
/*      */     }
/*      */   }
/*      */   
/*      */   static enum SSLHandhsakeState
/*      */   {
/* 1503 */     SSL_HANDHSAKE_NOT_STARTED, 
/* 1504 */     SSL_HANDHSAKE_STARTED, 
/* 1505 */     SSL_HANDHSAKE_COMPLETE;
/*      */     
/*      */     private SSLHandhsakeState() {}
/*      */   }
/*      */   
/*      */   void enableSSL(String paramString, int paramInt) throws SQLServerException
/*      */   {
/* 1512 */     Provider localProvider1 = null;
/* 1513 */     Provider localProvider2 = null;
/* 1514 */     Provider localProvider3 = null;
/* 1515 */     String str1 = null;
/* 1516 */     SSLHandhsakeState localSSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_NOT_STARTED;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1521 */       if (logger.isLoggable(Level.FINER)) {
/* 1522 */         logger.finer(toString() + " Enabling SSL...");
/*      */       }
/* 1524 */       String str2 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE.toString());
/* 1525 */       localObject1 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/* 1526 */       localObject2 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString());
/*      */       
/* 1528 */       assert ((0 == this.con.getRequestedEncryptionLevel()) || (1 == this.con.getRequestedEncryptionLevel()));
/*      */       
/*      */ 
/*      */ 
/* 1532 */       assert ((0 == this.con.getNegotiatedEncryptionLevel()) || (1 == this.con.getNegotiatedEncryptionLevel()) || (3 == this.con.getNegotiatedEncryptionLevel()));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1540 */       localObject3 = null;
/* 1541 */       if ((0 == this.con.getRequestedEncryptionLevel()) || ((1 == this.con.getRequestedEncryptionLevel()) && (this.con.trustServerCertificate())))
/*      */       {
/*      */ 
/* 1544 */         if (logger.isLoggable(Level.FINER)) {
/* 1545 */           logger.finer(toString() + " SSL handshake will trust any certificate");
/*      */         }
/* 1547 */         localObject3 = new TrustManager[] { new PermissiveX509TrustManager(this) };
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1554 */         if (logger.isLoggable(Level.FINER)) {
/* 1555 */           logger.finer(toString() + " SSL handshake will validate server certificate");
/*      */         }
/* 1557 */         localObject4 = null;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1562 */         if ((null == str2) && (null == localObject1))
/*      */         {
/* 1564 */           if (logger.isLoggable(Level.FINER)) {
/* 1565 */             logger.finer(toString() + " Using system default trust store and password");
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 1574 */           if (logger.isLoggable(Level.FINEST)) {
/* 1575 */             logger.finest(toString() + " Finding key store interface");
/*      */           }
/* 1577 */           localObject4 = KeyStore.getInstance("JKS");
/* 1578 */           localProvider3 = ((KeyStore)localObject4).getProvider();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1584 */           localObject5 = loadTrustStore(str2);
/*      */           
/*      */ 
/*      */ 
/* 1588 */           if (logger.isLoggable(Level.FINEST)) {
/* 1589 */             logger.finest(toString() + " Loading key store");
/*      */           }
/*      */           try
/*      */           {
/* 1593 */             ((KeyStore)localObject4).load((InputStream)localObject5, null == localObject1 ? null : ((String)localObject1).toCharArray());
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1598 */             this.con.activeConnectionProperties.remove(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*      */             
/*      */ 
/* 1601 */             if (null != localObject5)
/*      */             {
/*      */               try
/*      */               {
/* 1605 */                 ((InputStream)localObject5).close();
/*      */               }
/*      */               catch (IOException localIOException1)
/*      */               {
/* 1609 */                 if (logger.isLoggable(Level.FINE)) {
/* 1610 */                   logger.fine(toString() + " Ignoring error closing trust material InputStream...");
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1623 */             localObject5 = null;
/*      */           }
/*      */           finally
/*      */           {
/* 1598 */             this.con.activeConnectionProperties.remove(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*      */             
/*      */ 
/* 1601 */             if (null != localObject5)
/*      */             {
/*      */               try
/*      */               {
/* 1605 */                 ((InputStream)localObject5).close();
/*      */               }
/*      */               catch (IOException localIOException2)
/*      */               {
/* 1609 */                 if (logger.isLoggable(Level.FINE)) {
/* 1610 */                   logger.fine(toString() + " Ignoring error closing trust material InputStream...");
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1625 */         if (logger.isLoggable(Level.FINEST)) {
/* 1626 */           logger.finest(toString() + " Locating X.509 trust manager factory");
/*      */         }
/* 1628 */         str1 = TrustManagerFactory.getDefaultAlgorithm();
/* 1629 */         Object localObject5 = TrustManagerFactory.getInstance(str1);
/* 1630 */         localProvider1 = ((TrustManagerFactory)localObject5).getProvider();
/*      */         
/*      */ 
/*      */ 
/* 1634 */         if (logger.isLoggable(Level.FINEST)) {
/* 1635 */           logger.finest(toString() + " Getting trust manager");
/*      */         }
/* 1637 */         ((TrustManagerFactory)localObject5).init((KeyStore)localObject4);
/* 1638 */         localObject3 = ((TrustManagerFactory)localObject5).getTrustManagers();
/*      */         
/*      */ 
/* 1641 */         if (null != localObject2)
/*      */         {
/* 1643 */           localObject3 = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)localObject3[0], (String)localObject2) };
/*      */         }
/*      */         else
/*      */         {
/* 1647 */           localObject3 = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)localObject3[0], paramString) };
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1653 */       Object localObject4 = null;
/*      */       
/* 1655 */       if (logger.isLoggable(Level.FINEST)) {
/* 1656 */         logger.finest(toString() + " Getting TLS or better SSL context");
/*      */       }
/* 1658 */       localObject4 = SSLContext.getInstance("TLS");
/* 1659 */       localProvider2 = ((SSLContext)localObject4).getProvider();
/*      */       
/* 1661 */       if (logger.isLoggable(Level.FINEST)) {
/* 1662 */         logger.finest(toString() + " Initializing SSL context");
/*      */       }
/* 1664 */       ((SSLContext)localObject4).init(null, (TrustManager[])localObject3, null);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1669 */       this.proxySocket = new ProxySocket(this);
/*      */       
/* 1671 */       if (logger.isLoggable(Level.FINEST)) {
/* 1672 */         logger.finest(toString() + " Creating SSL socket");
/*      */       }
/* 1674 */       this.sslSocket = ((SSLSocket)((SSLContext)localObject4).getSocketFactory().createSocket(this.proxySocket, paramString, paramInt, false));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1683 */       if (logger.isLoggable(Level.FINER)) {
/* 1684 */         logger.finer(toString() + " Starting SSL handshake");
/*      */       }
/*      */       
/* 1687 */       localSSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_STARTED;
/* 1688 */       this.sslSocket.startHandshake();
/* 1689 */       localSSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_COMPLETE;
/*      */       
/*      */ 
/* 1692 */       if (logger.isLoggable(Level.FINEST)) {
/* 1693 */         logger.finest(toString() + " Rewiring proxy streams after handshake");
/*      */       }
/* 1695 */       this.proxySocket.setStreams(this.inputStream, this.outputStream);
/*      */       
/*      */ 
/* 1698 */       if (logger.isLoggable(Level.FINEST)) {
/* 1699 */         logger.finest(toString() + " Getting SSL InputStream");
/*      */       }
/* 1701 */       this.inputStream = this.sslSocket.getInputStream();
/*      */       
/* 1703 */       if (logger.isLoggable(Level.FINEST)) {
/* 1704 */         logger.finest(toString() + " Getting SSL OutputStream");
/*      */       }
/* 1706 */       this.outputStream = this.sslSocket.getOutputStream();
/*      */       
/*      */ 
/* 1709 */       this.channelSocket = this.sslSocket;
/*      */       
/* 1711 */       if (logger.isLoggable(Level.FINER)) {
/* 1712 */         logger.finer(toString() + " SSL enabled");
/*      */       }
/*      */     }
/*      */     catch (Exception localException)
/*      */     {
/* 1717 */       if (logger.isLoggable(Level.FINER)) {
/* 1718 */         logger.log(Level.FINER, localException.getMessage(), localException);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1724 */       if (logger.isLoggable(Level.FINER)) {
/* 1725 */         logger.log(Level.FINER, "java.security path: " + JAVA_SECURITY + "\n" + "Security providers: " + Arrays.asList(Security.getProviders()) + "\n" + (null != localProvider2 ? "SSLContext provider info: " + localProvider2.getInfo() + "\n" + "SSLContext provider services:\n" + localProvider2.getServices() + "\n" : "") + (null != localProvider1 ? "TrustManagerFactory provider info: " + localProvider1.getInfo() + "\n" : "") + (null != str1 ? "TrustManagerFactory default algorithm: " + str1 + "\n" : "") + (null != localProvider3 ? "KeyStore provider info: " + localProvider3.getInfo() + "\n" : "") + "java.ext.dirs: " + System.getProperty("java.ext.dirs"));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1740 */       Object localObject1 = new MessageFormat(SQLServerException.getErrString("R_sslFailed"));
/* 1741 */       Object localObject2 = { localException.getMessage() };
/*      */       
/*      */ 
/* 1744 */       Object localObject3 = localException.getLocalizedMessage();
/*      */       
/*      */ 
/*      */ 
/* 1748 */       if (-1 != ((String)localObject3).indexOf(" ClientConnectionId:"))
/*      */       {
/* 1750 */         localObject3 = ((String)localObject3).substring(0, ((String)localObject3).indexOf(" ClientConnectionId:"));
/*      */       }
/*      */       
/*      */ 
/* 1754 */       if (((localException instanceof IOException)) && (SSLHandhsakeState.SSL_HANDHSAKE_STARTED == localSSLHandhsakeState) && (((String)localObject3).equals(SQLServerException.getErrString("R_truncatedServerResponse"))))
/*      */       {
/*      */ 
/*      */ 
/* 1758 */         this.con.terminate(7, ((MessageFormat)localObject1).format(localObject2), localException);
/*      */       }
/*      */       else
/*      */       {
/* 1762 */         this.con.terminate(5, ((MessageFormat)localObject1).format(localObject2), localException);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1782 */   private static final String SEPARATOR = System.getProperty("file.separator");
/* 1783 */   private static final String JAVA_HOME = System.getProperty("java.home");
/* 1784 */   private static final String JAVA_SECURITY = JAVA_HOME + SEPARATOR + "lib" + SEPARATOR + "security";
/* 1785 */   private static final String JSSECACERTS = JAVA_SECURITY + SEPARATOR + "jssecacerts";
/* 1786 */   private static final String CACERTS = JAVA_SECURITY + SEPARATOR + "cacerts";
/*      */   
/*      */   final InputStream loadTrustStore(String paramString) {
/* 1789 */     FileInputStream localFileInputStream = null;
/*      */     
/*      */ 
/* 1792 */     if (null != paramString)
/*      */     {
/*      */       try
/*      */       {
/* 1796 */         if (logger.isLoggable(Level.FINEST)) {
/* 1797 */           logger.finest(toString() + " Opening specified trust store: " + paramString);
/*      */         }
/* 1799 */         localFileInputStream = new FileInputStream(paramString);
/*      */       }
/*      */       catch (FileNotFoundException localFileNotFoundException1)
/*      */       {
/* 1803 */         if (logger.isLoggable(Level.FINE)) {
/* 1804 */           logger.fine(toString() + " Trust store not found: " + localFileNotFoundException1.getMessage());
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1813 */     else if (null != (paramString = System.getProperty("javax.net.ssl.trustStore")))
/*      */     {
/*      */       try
/*      */       {
/* 1817 */         if (logger.isLoggable(Level.FINEST)) {
/* 1818 */           logger.finest(toString() + " Opening default trust store (from javax.net.ssl.trustStore): " + paramString);
/*      */         }
/* 1820 */         localFileInputStream = new FileInputStream(paramString);
/*      */       }
/*      */       catch (FileNotFoundException localFileNotFoundException2)
/*      */       {
/* 1824 */         if (logger.isLoggable(Level.FINE)) {
/* 1825 */           logger.fine(toString() + " Trust store not found: " + localFileNotFoundException2.getMessage());
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/* 1838 */         if (logger.isLoggable(Level.FINEST)) {
/* 1839 */           logger.finest(toString() + " Opening default trust store: " + JSSECACERTS);
/*      */         }
/* 1841 */         localFileInputStream = new FileInputStream(JSSECACERTS);
/*      */       }
/*      */       catch (FileNotFoundException localFileNotFoundException3)
/*      */       {
/* 1845 */         if (logger.isLoggable(Level.FINE)) {
/* 1846 */           logger.fine(toString() + " Trust store not found: " + localFileNotFoundException3.getMessage());
/*      */         }
/*      */       }
/*      */       
/* 1850 */       if (null == localFileInputStream)
/*      */       {
/*      */         try
/*      */         {
/* 1854 */           if (logger.isLoggable(Level.FINEST)) {
/* 1855 */             logger.finest(toString() + " Opening default trust store: " + CACERTS);
/*      */           }
/* 1857 */           localFileInputStream = new FileInputStream(CACERTS);
/*      */         }
/*      */         catch (FileNotFoundException localFileNotFoundException4)
/*      */         {
/* 1861 */           if (logger.isLoggable(Level.FINE)) {
/* 1862 */             logger.fine(toString() + " Trust store not found: " + localFileNotFoundException4.getMessage());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1870 */     return localFileInputStream;
/*      */   }
/*      */   
/*      */   final int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/* 1877 */       return this.inputStream.read(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1881 */       if (logger.isLoggable(Level.FINE)) {
/* 1882 */         logger.fine(toString() + " read failed:" + localIOException.getMessage());
/*      */       }
/* 1884 */       this.con.terminate(3, localIOException.getMessage()); }
/* 1885 */     return 0;
/*      */   }
/*      */   
/*      */   final void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/* 1893 */       this.outputStream.write(paramArrayOfByte, paramInt1, paramInt2);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1897 */       if (logger.isLoggable(Level.FINER)) {
/* 1898 */         logger.finer(toString() + " write failed:" + localIOException.getMessage());
/*      */       }
/* 1900 */       this.con.terminate(3, localIOException.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */   final void flush() throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/* 1908 */       this.outputStream.flush();
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1912 */       if (logger.isLoggable(Level.FINER)) {
/* 1913 */         logger.finer(toString() + " flush failed:" + localIOException.getMessage());
/*      */       }
/* 1915 */       this.con.terminate(3, localIOException.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */   final void close()
/*      */   {
/* 1921 */     if (null != this.sslSocket) {
/* 1922 */       disableSSL();
/*      */     }
/* 1924 */     if (null != this.inputStream)
/*      */     {
/* 1926 */       if (logger.isLoggable(Level.FINEST)) {
/* 1927 */         logger.finest(toString() + ": Closing inputStream...");
/*      */       }
/*      */       try
/*      */       {
/* 1931 */         this.inputStream.close();
/*      */       }
/*      */       catch (IOException localIOException1)
/*      */       {
/* 1935 */         if (logger.isLoggable(Level.FINE)) {
/* 1936 */           logger.log(Level.FINE, toString() + ": Ignored error closing inputStream", localIOException1);
/*      */         }
/*      */       }
/*      */     }
/* 1940 */     if (null != this.outputStream)
/*      */     {
/* 1942 */       if (logger.isLoggable(Level.FINEST)) {
/* 1943 */         logger.finest(toString() + ": Closing outputStream...");
/*      */       }
/*      */       try
/*      */       {
/* 1947 */         this.outputStream.close();
/*      */       }
/*      */       catch (IOException localIOException2)
/*      */       {
/* 1951 */         if (logger.isLoggable(Level.FINE)) {
/* 1952 */           logger.log(Level.FINE, toString() + ": Ignored error closing outputStream", localIOException2);
/*      */         }
/*      */       }
/*      */     }
/* 1956 */     if (null != this.tcpSocket)
/*      */     {
/* 1958 */       if (logger.isLoggable(Level.FINER)) {
/* 1959 */         logger.finer(toString() + ": Closing TCP socket...");
/*      */       }
/*      */       try
/*      */       {
/* 1963 */         this.tcpSocket.close();
/*      */       }
/*      */       catch (IOException localIOException3)
/*      */       {
/* 1967 */         if (logger.isLoggable(Level.FINE)) {
/* 1968 */           logger.log(Level.FINE, toString() + ": Ignored error closing socket", localIOException3);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void logPacket(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString)
/*      */   {
/* 1983 */     assert ((0 <= paramInt2) && (paramInt2 <= paramArrayOfByte.length));
/* 1984 */     assert ((0 <= paramInt1) && (paramInt1 <= paramArrayOfByte.length));
/*      */     
/* 1986 */     char[] arrayOfChar1 = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1992 */     char[] arrayOfChar2 = { '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2018 */     char[] arrayOfChar3 = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2031 */     char[] arrayOfChar4 = new char[arrayOfChar3.length];
/* 2032 */     System.arraycopy(arrayOfChar3, 0, arrayOfChar4, 0, arrayOfChar3.length);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2037 */     StringBuilder localStringBuilder = new StringBuilder(paramString.length() + 4 * paramInt2 + 4 * (1 + paramInt2 / 16) + 80);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2048 */     localStringBuilder.append(this.tcpSocket.getLocalAddress().toString() + ":" + this.tcpSocket.getLocalPort() + " SPID:" + this.spid + " " + paramString + "\r\n");
/*      */     
/*      */ 
/* 2051 */     int i = 0;
/*      */     
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2056 */       int j = 0;
/* 2057 */       for (; (j < 16) && (i < paramInt2); 
/* 2058 */           i++)
/*      */       {
/* 2060 */         k = (paramArrayOfByte[(paramInt1 + i)] + 256) % 256;
/* 2061 */         arrayOfChar4[(3 * j)] = arrayOfChar1[(k / 16)];
/* 2062 */         arrayOfChar4[(3 * j + 1)] = arrayOfChar1[(k % 16)];
/* 2063 */         arrayOfChar4[(50 + j)] = arrayOfChar2[k];j++;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2067 */       for (int k = j; 
/* 2068 */           k < 16; k++)
/*      */       {
/* 2070 */         arrayOfChar4[(3 * k)] = ' ';
/* 2071 */         arrayOfChar4[(3 * k + 1)] = ' ';
/*      */       }
/*      */       
/* 2074 */       localStringBuilder.append(arrayOfChar4, 0, 50 + j);
/* 2075 */       if (i == paramInt2) {
/*      */         break;
/*      */       }
/* 2078 */       localStringBuilder.append("\r\n");
/*      */     }
/*      */     
/* 2081 */     packetLogger.finest(localStringBuilder.toString());
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/TDSChannel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */