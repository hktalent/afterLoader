/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseInputStream
/*     */   extends InputStream
/*     */ {
/*     */   final boolean isAdaptive;
/*     */   final boolean isStreaming;
/*     */   
/*     */   abstract byte[] getBytes()
/*     */     throws SQLServerException;
/*     */   
/*  25 */   private String parentLoggingInfo = "";
/*  26 */   private static int lastLoggingID = 0;
/*  27 */   private static synchronized int nextLoggingID() { return ++lastLoggingID; }
/*  28 */   static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.InputStream");
/*     */   private String traceID;
/*     */   
/*     */   public final String toString() {
/*  32 */     if (this.traceID == null)
/*  33 */       this.traceID = (getClass().getName() + "ID:" + nextLoggingID());
/*  34 */     return this.traceID;
/*     */   }
/*     */   
/*     */   final void setLoggingInfo(String paramString) {
/*  38 */     this.parentLoggingInfo = paramString;
/*  39 */     if (logger.isLoggable(Level.FINER)) {
/*  40 */       logger.finer(toString());
/*     */     }
/*     */   }
/*     */   
/*  44 */   int streamPos = 0;
/*  45 */   int markedStreamPos = 0;
/*     */   TDSReaderMark currentMark;
/*     */   private ServerDTVImpl dtv;
/*     */   TDSReader tdsReader;
/*  49 */   int readLimit = 0;
/*  50 */   boolean isReadLimitSet = false;
/*     */   
/*     */   BaseInputStream(TDSReader paramTDSReader, boolean paramBoolean1, boolean paramBoolean2, ServerDTVImpl paramServerDTVImpl)
/*     */   {
/*  54 */     this.tdsReader = paramTDSReader;
/*  55 */     this.isAdaptive = paramBoolean1;
/*  56 */     this.isStreaming = paramBoolean2;
/*     */     
/*  58 */     if (paramBoolean1) {
/*  59 */       clearCurrentMark();
/*     */     } else
/*  61 */       this.currentMark = paramTDSReader.mark();
/*  62 */     this.dtv = paramServerDTVImpl;
/*     */   }
/*     */   
/*     */   final void clearCurrentMark()
/*     */   {
/*  67 */     this.currentMark = null;
/*  68 */     this.isReadLimitSet = false;
/*  69 */     if ((this.isAdaptive) && (this.isStreaming)) {
/*  70 */       this.tdsReader.stream();
/*     */     }
/*     */   }
/*     */   
/*     */   void closeHelper() throws IOException {
/*  75 */     if ((this.isAdaptive) && (null != this.dtv))
/*     */     {
/*  77 */       if (logger.isLoggable(Level.FINER))
/*  78 */         logger.finer(toString() + " closing the adaptive stream.");
/*  79 */       this.dtv.setPositionAfterStreamed(this.tdsReader);
/*     */     }
/*  81 */     this.currentMark = null;
/*  82 */     this.tdsReader = null;
/*  83 */     this.dtv = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   final void checkClosed()
/*     */     throws IOException
/*     */   {
/*  91 */     if (null == this.tdsReader) {
/*  92 */       throw new IOException(SQLServerException.getErrString("R_streamIsClosed"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 101 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setReadLimit(int paramInt)
/*     */   {
/* 108 */     if ((this.isAdaptive) && (paramInt > 0))
/*     */     {
/* 110 */       this.readLimit = paramInt;
/* 111 */       this.isReadLimitSet = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void resetHelper()
/*     */     throws IOException
/*     */   {
/* 120 */     checkClosed();
/*     */     
/* 122 */     if (null == this.currentMark)
/* 123 */       throw new IOException(SQLServerException.getErrString("R_streamWasNotMarkedBefore"));
/* 124 */     this.tdsReader.reset(this.currentMark);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/BaseInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */