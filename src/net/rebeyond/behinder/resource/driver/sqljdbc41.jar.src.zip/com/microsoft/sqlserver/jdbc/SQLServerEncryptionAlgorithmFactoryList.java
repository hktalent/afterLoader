/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SQLServerEncryptionAlgorithmFactoryList
/*    */ {
/*    */   private ConcurrentHashMap<String, SQLServerEncryptionAlgorithmFactory> encryptionAlgoFactoryMap;
/* 15 */   private static final SQLServerEncryptionAlgorithmFactoryList instance = new SQLServerEncryptionAlgorithmFactoryList();
/*    */   
/*    */   private SQLServerEncryptionAlgorithmFactoryList() {
/* 18 */     this.encryptionAlgoFactoryMap = new ConcurrentHashMap();
/* 19 */     this.encryptionAlgoFactoryMap.putIfAbsent("AEAD_AES_256_CBC_HMAC_SHA256", new SQLServerAeadAes256CbcHmac256Factory());
/*    */   }
/*    */   
/*    */   static SQLServerEncryptionAlgorithmFactoryList getInstance() {
/* 23 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   String getRegisteredCipherAlgorithmNames()
/*    */   {
/* 30 */     StringBuffer localStringBuffer = new StringBuffer();
/* 31 */     int i = 1;
/* 32 */     for (String str : this.encryptionAlgoFactoryMap.keySet()) {
/* 33 */       if (i != 0) {
/* 34 */         localStringBuffer.append("'");
/* 35 */         i = 0;
/*    */       } else {
/* 37 */         localStringBuffer.append(", '");
/*    */       }
/* 39 */       localStringBuffer.append(str);
/* 40 */       localStringBuffer.append("'");
/*    */     }
/*    */     
/* 43 */     return localStringBuffer.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   SQLServerEncryptionAlgorithm getAlgorithm(SQLServerSymmetricKey paramSQLServerSymmetricKey, SQLServerEncryptionType paramSQLServerEncryptionType, String paramString)
/*    */     throws SQLServerException
/*    */   {
/* 55 */     SQLServerEncryptionAlgorithm localSQLServerEncryptionAlgorithm = null;
/* 56 */     SQLServerEncryptionAlgorithmFactory localSQLServerEncryptionAlgorithmFactory = null;
/* 57 */     if (!this.encryptionAlgoFactoryMap.containsKey(paramString)) {
/* 58 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_UnknownColumnEncryptionAlgorithm"));
/* 59 */       Object[] arrayOfObject = { paramString, getInstance().getRegisteredCipherAlgorithmNames() };
/* 60 */       throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*    */     }
/*    */     
/* 63 */     localSQLServerEncryptionAlgorithmFactory = (SQLServerEncryptionAlgorithmFactory)this.encryptionAlgoFactoryMap.get(paramString);
/* 64 */     assert (null != localSQLServerEncryptionAlgorithmFactory) : "Null Algorithm Factory class detected";
/* 65 */     localSQLServerEncryptionAlgorithm = localSQLServerEncryptionAlgorithmFactory.create(paramSQLServerSymmetricKey, paramSQLServerEncryptionType, paramString);
/* 66 */     return localSQLServerEncryptionAlgorithm;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerEncryptionAlgorithmFactoryList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */