/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.sql.Clob;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SQLServerClobBase
/*     */   implements Serializable
/*     */ {
/*     */   private String value;
/*     */   private final SQLCollation sqlCollation;
/*  54 */   private boolean isClosed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private ArrayList<Closeable> activeStreams = new ArrayList(1);
/*     */   
/*     */   SQLServerConnection con;
/*     */   private final Logger logger;
/*  65 */   private final String traceID = getClass().getName().substring(1 + getClass().getName().lastIndexOf('.')) + ":" + nextInstanceID();
/*     */   
/*     */ 
/*  68 */   public final String toString() { return this.traceID; }
/*     */   
/*  70 */   private static int baseID = 0;
/*     */   
/*     */   private static synchronized int nextInstanceID()
/*     */   {
/*  74 */     baseID += 1;
/*  75 */     return baseID;
/*     */   }
/*     */   
/*     */   abstract JDBCType getJdbcType();
/*     */   
/*     */   private String getDisplayClassName()
/*     */   {
/*  82 */     String str = getJdbcType().className();
/*  83 */     return str.substring(1 + str.lastIndexOf('.'));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLServerClobBase(SQLServerConnection paramSQLServerConnection, String paramString, SQLCollation paramSQLCollation, Logger paramLogger)
/*     */   {
/*  93 */     this.con = paramSQLServerConnection;
/*  94 */     this.value = paramString;
/*  95 */     this.sqlCollation = paramSQLCollation;
/*  96 */     this.logger = paramLogger;
/*     */     
/*  98 */     if (paramLogger.isLoggable(Level.FINE))
/*     */     {
/* 100 */       String str = null != paramSQLServerConnection ? paramSQLServerConnection.toString() : "null connection";
/* 101 */       paramLogger.fine(toString() + " created by (" + str + ")");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void free()
/*     */     throws SQLException
/*     */   {
/*     */     
/*     */     
/*     */ 
/*     */ 
/* 116 */     if (!this.isClosed)
/*     */     {
/*     */ 
/* 119 */       if (null != this.activeStreams)
/*     */       {
/* 121 */         for (Closeable localCloseable : this.activeStreams)
/*     */         {
/*     */           try
/*     */           {
/* 125 */             localCloseable.close();
/*     */           }
/*     */           catch (IOException localIOException)
/*     */           {
/* 129 */             this.logger.fine(toString() + " ignored IOException closing stream " + localCloseable + ": " + localIOException.getMessage());
/*     */           }
/*     */         }
/* 132 */         this.activeStreams = null;
/*     */       }
/*     */       
/*     */ 
/* 136 */       this.value = null;
/*     */       
/* 138 */       this.isClosed = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final void checkClosed()
/*     */     throws SQLServerException
/*     */   {
/* 147 */     if (this.isClosed)
/*     */     {
/* 149 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 150 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(new Object[] { getDisplayClassName() }), null, true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getAsciiStream()
/*     */     throws SQLException
/*     */   {
/* 161 */     checkClosed();
/*     */     
/* 163 */     if ((null != this.sqlCollation) && (!this.sqlCollation.supportsAsciiConversion())) {
/* 164 */       DataTypes.throwConversionError(getDisplayClassName(), "AsciiStream");
/*     */     }
/*     */     
/*     */     BufferedInputStream localBufferedInputStream;
/*     */     try
/*     */     {
/* 170 */       localBufferedInputStream = new BufferedInputStream(new ReaderInputStream(new StringReader(this.value), "US-ASCII", this.value.length()));
/*     */     }
/*     */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*     */     {
/* 174 */       throw new SQLServerException(localUnsupportedEncodingException.getMessage(), null, 0, localUnsupportedEncodingException);
/*     */     }
/*     */     
/* 177 */     this.activeStreams.add(localBufferedInputStream);
/* 178 */     return localBufferedInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Reader getCharacterStream()
/*     */     throws SQLException
/*     */   {
/* 189 */     checkClosed();
/*     */     
/* 191 */     StringReader localStringReader = new StringReader(this.value);
/* 192 */     this.activeStreams.add(localStringReader);
/* 193 */     return localStringReader;
/*     */   }
/*     */   
/*     */   public Reader getCharacterStream(long paramLong1, long paramLong2) throws SQLException
/*     */   {
/* 198 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/*     */ 
/* 201 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSubString(long paramLong, int paramInt)
/*     */     throws SQLException
/*     */   {
/* 215 */     checkClosed();
/*     */     MessageFormat localMessageFormat;
/* 217 */     Object[] arrayOfObject; if (paramLong < 1L)
/*     */     {
/* 219 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 220 */       arrayOfObject = new Object[] { new Long(paramLong) };
/* 221 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     
/* 224 */     if (paramInt < 0)
/*     */     {
/* 226 */       localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 227 */       arrayOfObject = new Object[] { new Integer(paramInt) };
/* 228 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     
/*     */ 
/* 232 */     paramLong -= 1L;
/*     */     
/*     */ 
/* 235 */     if (paramLong > this.value.length()) {
/* 236 */       paramLong = this.value.length();
/*     */     }
/*     */     
/*     */ 
/* 240 */     if (paramInt > this.value.length() - paramLong) {
/* 241 */       paramInt = (int)(this.value.length() - paramLong);
/*     */     }
/*     */     
/* 244 */     return this.value.substring((int)paramLong, (int)paramLong + paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long length()
/*     */     throws SQLException
/*     */   {
/* 254 */     checkClosed();
/*     */     
/* 256 */     return this.value.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long position(Clob paramClob, long paramLong)
/*     */     throws SQLException
/*     */   {
/* 270 */     checkClosed();
/*     */     
/* 272 */     if (paramLong < 1L)
/*     */     {
/* 274 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 275 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 276 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     
/* 279 */     if (null == paramClob) {
/* 280 */       return -1L;
/*     */     }
/* 282 */     return position(paramClob.getSubString(1L, (int)paramClob.length()), paramLong);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long position(String paramString, long paramLong)
/*     */     throws SQLException
/*     */   {
/* 297 */     checkClosed();
/*     */     
/* 299 */     if (paramLong < 1L)
/*     */     {
/* 301 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 302 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 303 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 308 */     if (null == paramString) {
/* 309 */       return -1L;
/*     */     }
/* 311 */     int i = this.value.indexOf(paramString, (int)(paramLong - 1L));
/* 312 */     if (-1 != i) {
/* 313 */       return i + 1;
/*     */     }
/* 315 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void truncate(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 327 */     checkClosed();
/*     */     
/* 329 */     if (paramLong < 0L)
/*     */     {
/* 331 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 332 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 333 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     
/* 336 */     if ((paramLong <= 2147483647L) && (this.value.length() > paramLong)) {
/* 337 */       this.value = this.value.substring(0, (int)paramLong);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputStream setAsciiStream(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 349 */     checkClosed();
/*     */     
/* 351 */     if (paramLong < 1L)
/*     */     {
/* 353 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 354 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 355 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     
/* 358 */     return new SQLServerClobAsciiOutputStream(this, paramLong);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Writer setCharacterStream(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 370 */     checkClosed();
/*     */     
/* 372 */     if (paramLong < 1L)
/*     */     {
/* 374 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 375 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 376 */       SQLServerException.makeFromDriverError(this.con, null, localMessageFormat.format(arrayOfObject), null, true);
/*     */     }
/*     */     
/* 379 */     return new SQLServerClobWriter(this, paramLong);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int setString(long paramLong, String paramString)
/*     */     throws SQLException
/*     */   {
/* 392 */     checkClosed();
/*     */     
/* 394 */     if (null == paramString) {
/* 395 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/* 397 */     return setString(paramLong, paramString, 0, paramString.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int setString(long paramLong, String paramString, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 419 */     checkClosed();
/*     */     
/* 421 */     if (null == paramString)
/* 422 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     Object localObject;
/*     */     Object[] arrayOfObject;
/* 425 */     if ((paramInt1 < 0) || (paramInt1 > paramString.length()))
/*     */     {
/* 427 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidOffset"));
/* 428 */       arrayOfObject = new Object[] { new Integer(paramInt1) };
/* 429 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */     
/*     */ 
/* 433 */     if ((paramInt2 < 0) || (paramInt2 > paramString.length() - paramInt1))
/*     */     {
/* 435 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 436 */       arrayOfObject = new Object[] { new Integer(paramInt2) };
/* 437 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 443 */     if ((paramLong < 1L) || (paramLong > this.value.length() + 1))
/*     */     {
/* 445 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 446 */       arrayOfObject = new Object[] { new Long(paramLong) };
/* 447 */       SQLServerException.makeFromDriverError(this.con, null, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*     */     }
/*     */     
/*     */ 
/* 451 */     paramLong -= 1L;
/*     */     
/*     */ 
/* 454 */     if (paramInt2 >= this.value.length() - paramLong)
/*     */     {
/*     */ 
/* 457 */       DataTypes.getCheckedLength(this.con, getJdbcType(), paramLong + paramInt2, false);
/* 458 */       assert (paramLong + paramInt2 <= 2147483647L);
/*     */       
/*     */ 
/* 461 */       localObject = new StringBuilder((int)paramLong + paramInt2);
/* 462 */       ((StringBuilder)localObject).append(this.value.substring(0, (int)paramLong));
/*     */       
/*     */ 
/* 465 */       ((StringBuilder)localObject).append(paramString.substring(paramInt1, paramInt1 + paramInt2));
/*     */       
/*     */ 
/* 468 */       this.value = ((StringBuilder)localObject).toString();
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 475 */       localObject = new StringBuilder(this.value.length());
/* 476 */       ((StringBuilder)localObject).append(this.value.substring(0, (int)paramLong));
/*     */       
/*     */ 
/* 479 */       ((StringBuilder)localObject).append(paramString.substring(paramInt1, paramInt1 + paramInt2));
/*     */       
/*     */ 
/*     */ 
/* 483 */       ((StringBuilder)localObject).append(this.value.substring((int)paramLong + paramInt2));
/*     */       
/*     */ 
/* 486 */       this.value = ((StringBuilder)localObject).toString();
/*     */     }
/*     */     
/* 489 */     return paramInt2;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerClobBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */