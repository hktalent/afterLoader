/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.sql.XAConnection;
/*    */ import javax.transaction.xa.XAResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerXAConnection
/*    */   extends SQLServerPooledConnection
/*    */   implements XAConnection
/*    */ {
/*    */   private SQLServerXAResource XAResource;
/*    */   private SQLServerConnection physicalControlConnection;
/*    */   private Logger xaLogger;
/*    */   
/*    */   SQLServerXAConnection(SQLServerDataSource paramSQLServerDataSource, String paramString1, String paramString2)
/*    */     throws SQLException
/*    */   {
/* 30 */     super(paramSQLServerDataSource, paramString1, paramString2);
/*    */     
/* 32 */     this.xaLogger = SQLServerXADataSource.xaLogger;
/* 33 */     SQLServerConnection localSQLServerConnection = getPhysicalConnection();
/*    */     
/* 35 */     Properties localProperties = (Properties)localSQLServerConnection.activeConnectionProperties.clone();
/*    */     
/* 37 */     localProperties.setProperty(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), "true");
/* 38 */     localProperties.remove(SQLServerDriverStringProperty.SELECT_METHOD.toString());
/*    */     
/* 40 */     if (this.xaLogger.isLoggable(Level.FINER))
/* 41 */       this.xaLogger.finer("Creating an internal control connection for" + toString());
/* 42 */     this.physicalControlConnection = new SQLServerConnection(toString());
/* 43 */     this.physicalControlConnection.connect(localProperties, null);
/* 44 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 45 */       this.xaLogger.finer("Created an internal control connection" + this.physicalControlConnection.toString() + " for " + toString() + " Physical connection:" + getPhysicalConnection().toString());
/*    */     }
/*    */     
/*    */ 
/* 49 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 50 */       this.xaLogger.finer(paramSQLServerDataSource.toString() + " user:" + paramString1);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized XAResource getXAResource()
/*    */     throws SQLException
/*    */   {
/* 61 */     if (this.XAResource == null) {
/* 62 */       this.XAResource = new SQLServerXAResource(getPhysicalConnection(), this.physicalControlConnection, toString());
/*    */     }
/* 64 */     return this.XAResource;
/*    */   }
/*    */   
/*    */ 
/*    */   public void close()
/*    */     throws SQLException
/*    */   {
/* 71 */     synchronized (this)
/*    */     {
/* 73 */       if (this.XAResource != null)
/*    */       {
/* 75 */         this.XAResource.close();
/* 76 */         this.XAResource = null;
/*    */       }
/* 78 */       if (null != this.physicalControlConnection)
/*    */       {
/* 80 */         this.physicalControlConnection.close();
/* 81 */         this.physicalControlConnection = null;
/*    */       }
/*    */     }
/* 84 */     super.close();
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerXAConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */