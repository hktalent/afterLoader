/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XidImpl
/*    */   implements Xid
/*    */ {
/*    */   private final int formatId;
/*    */   private final byte[] gtrid;
/*    */   private final byte[] bqual;
/*    */   private final String traceID;
/*    */   
/*    */   public XidImpl(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*    */   {
/* 44 */     this.formatId = paramInt;
/* 45 */     this.gtrid = paramArrayOfByte1;
/* 46 */     this.bqual = paramArrayOfByte2;
/* 47 */     this.traceID = (" XID:" + xidDisplay(this));
/*    */   }
/*    */   
/*    */   public byte[] getGlobalTransactionId() {
/* 51 */     return this.gtrid;
/*    */   }
/*    */   
/*    */   public byte[] getBranchQualifier() {
/* 55 */     return this.bqual;
/*    */   }
/*    */   
/*    */   public int getFormatId() {
/* 59 */     return this.formatId;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 63 */     return this.traceID;
/*    */   }
/*    */   
/*    */ 
/*    */   static String xidDisplay(Xid paramXid)
/*    */   {
/* 69 */     if (null == paramXid) return "(null)";
/* 70 */     StringBuilder localStringBuilder = new StringBuilder(300);
/* 71 */     localStringBuilder.append("formatId=");
/* 72 */     localStringBuilder.append(paramXid.getFormatId());
/* 73 */     localStringBuilder.append(" gtrid=");
/* 74 */     localStringBuilder.append(Util.byteToHexDisplayString(paramXid.getGlobalTransactionId()));
/* 75 */     localStringBuilder.append(" bqual=");
/* 76 */     localStringBuilder.append(Util.byteToHexDisplayString(paramXid.getBranchQualifier()));
/* 77 */     return localStringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/XidImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */