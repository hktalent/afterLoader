/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.naming.Reference;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerXADataSource
/*     */   extends SQLServerConnectionPoolDataSource
/*     */   implements XADataSource
/*     */ {
/*  44 */   static Logger xaLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.XA");
/*     */   
/*     */   public XAConnection getXAConnection(String paramString1, String paramString2) throws SQLException
/*     */   {
/*  48 */     if (loggerExternal.isLoggable(Level.FINER))
/*  49 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection", new Object[] { paramString1, "Password not traced" });
/*  50 */     SQLServerXAConnection localSQLServerXAConnection = new SQLServerXAConnection(this, paramString1, paramString2);
/*     */     
/*  52 */     if (xaLogger.isLoggable(Level.FINER)) {
/*  53 */       xaLogger.finer(toString() + " user:" + paramString1 + localSQLServerXAConnection.toString());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */     if (xaLogger.isLoggable(Level.FINER))
/*  61 */       xaLogger.finer(toString() + " Start get physical connection.");
/*  62 */     SQLServerConnection localSQLServerConnection = localSQLServerXAConnection.getPhysicalConnection();
/*  63 */     if (xaLogger.isLoggable(Level.FINE))
/*  64 */       xaLogger.fine(toString() + " End get physical connection, " + localSQLServerConnection.toString());
/*  65 */     if (loggerExternal.isLoggable(Level.FINER))
/*  66 */       loggerExternal.exiting(getClassNameLogging(), "getXAConnection", localSQLServerXAConnection);
/*  67 */     return localSQLServerXAConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XAConnection getXAConnection()
/*     */     throws SQLException
/*     */   {
/*  81 */     if (loggerExternal.isLoggable(Level.FINER))
/*  82 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection");
/*  83 */     return getXAConnection(getUser(), getPassword());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Reference getReference()
/*     */   {
/*  90 */     if (loggerExternal.isLoggable(Level.FINER))
/*  91 */       loggerExternal.entering(getClassNameLogging(), "getReference");
/*  92 */     Reference localReference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerXADataSource");
/*  93 */     if (loggerExternal.isLoggable(Level.FINER))
/*  94 */       loggerExternal.exiting(getClassNameLogging(), "getReference", localReference);
/*  95 */     return localReference;
/*     */   }
/*     */   
/*     */   private Object writeReplace() throws ObjectStreamException {
/*  99 */     return new SerializationProxy(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream paramObjectInputStream)
/*     */     throws InvalidObjectException
/*     */   {
/* 109 */     throw new InvalidObjectException("");
/*     */   }
/*     */   
/*     */ 
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final Reference ref;
/*     */     
/*     */     private static final long serialVersionUID = 454661379842314126L;
/*     */     
/*     */ 
/*     */     SerializationProxy(SQLServerXADataSource paramSQLServerXADataSource)
/*     */     {
/* 123 */       this.ref = paramSQLServerXADataSource.getReferenceInternal(null);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 127 */       SQLServerXADataSource localSQLServerXADataSource = new SQLServerXADataSource();
/* 128 */       localSQLServerXADataSource.initializeFromReference(this.ref);
/* 129 */       return localSQLServerXADataSource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerXADataSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */