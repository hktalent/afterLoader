/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class Util
/*     */ {
/*  21 */   static final String SYSTEM_SPEC_VERSION = System.getProperty("java.specification.version");
/*  22 */   static final char[] hexChars = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */   
/*     */ 
/*     */   static final String WSIDNotAvailable = "";
/*     */   
/*     */   static final String ActivityIdTraceProperty = "com.microsoft.sqlserver.jdbc.traceactivity";
/*     */   
/*  29 */   static final String SYSTEM_JRE = System.getProperty("java.vendor") + " " + System.getProperty("java.version");
/*     */   
/*     */   static boolean isIBM()
/*     */   {
/*  33 */     return SYSTEM_JRE.startsWith("IBM");
/*     */   }
/*     */   
/*     */ 
/*     */   static final Boolean isCharType(int paramInt)
/*     */   {
/*  39 */     switch (paramInt)
/*     */     {
/*     */     case -16: 
/*     */     case -15: 
/*     */     case -9: 
/*     */     case -1: 
/*     */     case 1: 
/*     */     case 12: 
/*  47 */       return Boolean.valueOf(true);
/*     */     }
/*  49 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */ 
/*     */   static final Boolean isCharType(SSType paramSSType)
/*     */   {
/*  55 */     switch (paramSSType)
/*     */     {
/*     */     case CHAR: 
/*     */     case NCHAR: 
/*     */     case VARCHAR: 
/*     */     case NVARCHAR: 
/*     */     case VARCHARMAX: 
/*     */     case NVARCHARMAX: 
/*  63 */       return Boolean.valueOf(true);
/*     */     }
/*  65 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */ 
/*     */   static final Boolean isBinaryType(SSType paramSSType)
/*     */   {
/*  71 */     switch (paramSSType)
/*     */     {
/*     */     case BINARY: 
/*     */     case VARBINARY: 
/*     */     case VARBINARYMAX: 
/*     */     case IMAGE: 
/*  77 */       return Boolean.valueOf(true);
/*     */     }
/*  79 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */ 
/*     */   static final Boolean isBinaryType(int paramInt)
/*     */   {
/*  85 */     switch (paramInt)
/*     */     {
/*     */     case -4: 
/*     */     case -3: 
/*     */     case -2: 
/*  90 */       return Boolean.valueOf(true);
/*     */     }
/*  92 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static short readShort(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 103 */     return (short)(paramArrayOfByte[paramInt] & 0xFF | (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 8);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int readUnsignedShort(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 113 */     return paramArrayOfByte[paramInt] & 0xFF | (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 8;
/*     */   }
/*     */   
/*     */   static int readUnsignedShortBigEndian(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 118 */     return (paramArrayOfByte[paramInt] & 0xFF) << 8 | paramArrayOfByte[(paramInt + 1)] & 0xFF;
/*     */   }
/*     */   
/*     */   static void writeShort(short paramShort, byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 123 */     paramArrayOfByte[(paramInt + 0)] = ((byte)(paramShort >> 0 & 0xFF));
/* 124 */     paramArrayOfByte[(paramInt + 1)] = ((byte)(paramShort >> 8 & 0xFF));
/*     */   }
/*     */   
/*     */   static void writeShortBigEndian(short paramShort, byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 129 */     paramArrayOfByte[(paramInt + 0)] = ((byte)(paramShort >> 8 & 0xFF));
/* 130 */     paramArrayOfByte[(paramInt + 1)] = ((byte)(paramShort >> 0 & 0xFF));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int readInt(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 139 */     int i = paramArrayOfByte[(paramInt + 0)] & 0xFF;
/* 140 */     int j = (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 8;
/* 141 */     int k = (paramArrayOfByte[(paramInt + 2)] & 0xFF) << 16;
/* 142 */     int m = (paramArrayOfByte[(paramInt + 3)] & 0xFF) << 24;
/* 143 */     return m | k | j | i;
/*     */   }
/*     */   
/*     */   static int readIntBigEndian(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 148 */     return (paramArrayOfByte[(paramInt + 3)] & 0xFF) << 0 | (paramArrayOfByte[(paramInt + 2)] & 0xFF) << 8 | (paramArrayOfByte[(paramInt + 1)] & 0xFF) << 16 | (paramArrayOfByte[(paramInt + 0)] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void writeInt(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*     */   {
/* 157 */     paramArrayOfByte[(paramInt2 + 0)] = ((byte)(paramInt1 >> 0 & 0xFF));
/* 158 */     paramArrayOfByte[(paramInt2 + 1)] = ((byte)(paramInt1 >> 8 & 0xFF));
/* 159 */     paramArrayOfByte[(paramInt2 + 2)] = ((byte)(paramInt1 >> 16 & 0xFF));
/* 160 */     paramArrayOfByte[(paramInt2 + 3)] = ((byte)(paramInt1 >> 24 & 0xFF));
/*     */   }
/*     */   
/*     */   static void writeIntBigEndian(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*     */   {
/* 165 */     paramArrayOfByte[(paramInt2 + 0)] = ((byte)(paramInt1 >> 24 & 0xFF));
/* 166 */     paramArrayOfByte[(paramInt2 + 1)] = ((byte)(paramInt1 >> 16 & 0xFF));
/* 167 */     paramArrayOfByte[(paramInt2 + 2)] = ((byte)(paramInt1 >> 8 & 0xFF));
/* 168 */     paramArrayOfByte[(paramInt2 + 3)] = ((byte)(paramInt1 >> 0 & 0xFF));
/*     */   }
/*     */   
/*     */   static void writeLongBigEndian(long paramLong, byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 173 */     paramArrayOfByte[(paramInt + 0)] = ((byte)(int)(paramLong >> 56 & 0xFF));
/* 174 */     paramArrayOfByte[(paramInt + 1)] = ((byte)(int)(paramLong >> 48 & 0xFF));
/* 175 */     paramArrayOfByte[(paramInt + 2)] = ((byte)(int)(paramLong >> 40 & 0xFF));
/* 176 */     paramArrayOfByte[(paramInt + 3)] = ((byte)(int)(paramLong >> 32 & 0xFF));
/* 177 */     paramArrayOfByte[(paramInt + 4)] = ((byte)(int)(paramLong >> 24 & 0xFF));
/* 178 */     paramArrayOfByte[(paramInt + 5)] = ((byte)(int)(paramLong >> 16 & 0xFF));
/* 179 */     paramArrayOfByte[(paramInt + 6)] = ((byte)(int)(paramLong >> 8 & 0xFF));
/* 180 */     paramArrayOfByte[(paramInt + 7)] = ((byte)(int)(paramLong >> 0 & 0xFF));
/*     */   }
/*     */   
/*     */   static BigDecimal readBigDecimal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */   {
/* 185 */     int i = 0 == paramArrayOfByte[0] ? -1 : 1;
/* 186 */     byte[] arrayOfByte = new byte[paramInt1 - 1];
/* 187 */     for (int j = 1; j <= arrayOfByte.length; j++)
/* 188 */       arrayOfByte[(arrayOfByte.length - j)] = paramArrayOfByte[j];
/* 189 */     return new BigDecimal(new java.math.BigInteger(i, arrayOfByte), paramInt2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static long readLong(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 200 */     long l = 0L;
/* 201 */     for (int i = 7; i > 0; i--)
/*     */     {
/* 203 */       l += (paramArrayOfByte[(paramInt + i)] & 0xFF);
/* 204 */       l <<= 8;
/*     */     }
/* 206 */     return l + (paramArrayOfByte[paramInt] & 0xFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Properties parseUrl(String paramString, Logger paramLogger)
/*     */     throws SQLServerException
/*     */   {
/* 216 */     Properties localProperties = new Properties();
/* 217 */     String str1 = paramString;
/* 218 */     String str2 = "jdbc:sqlserver://";
/* 219 */     String str3 = "";
/* 220 */     String str4 = "";
/* 221 */     String str5 = "";
/*     */     
/* 223 */     if (!str1.startsWith(str2)) {
/* 224 */       return null;
/*     */     }
/* 226 */     str1 = str1.substring(str2.length());
/* 227 */     int i = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 240 */     int j = 0;
/*     */     
/* 242 */     i = 0;
/* 243 */     while (i < str1.length())
/*     */     {
/* 245 */       char c = str1.charAt(i);
/* 246 */       switch (j)
/*     */       {
/*     */ 
/*     */       case 0: 
/* 250 */         if (c == ';')
/*     */         {
/*     */ 
/* 253 */           j = 7;
/*     */         }
/*     */         else
/*     */         {
/* 257 */           str3 = str3 + c;
/* 258 */           j = 1;
/*     */         }
/* 260 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case 1: 
/* 265 */         if ((c == ';') || (c == ':') || (c == '\\'))
/*     */         {
/*     */ 
/* 268 */           str3 = str3.trim();
/* 269 */           if (str3.length() > 0)
/*     */           {
/* 271 */             localProperties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3);
/* 272 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 274 */               paramLogger.fine("Property:serverName Value:" + str3);
/*     */             }
/*     */           }
/* 277 */           str3 = "";
/*     */           
/* 279 */           if (c == ';') {
/* 280 */             j = 7;
/*     */           }
/* 282 */           else if (c == ':') {
/* 283 */             j = 2;
/*     */           } else {
/* 285 */             j = 3;
/*     */           }
/*     */         }
/*     */         else {
/* 289 */           str3 = str3 + c;
/*     */         }
/*     */         
/* 292 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case 2: 
/* 297 */         if (c == ';')
/*     */         {
/* 299 */           str3 = str3.trim();
/* 300 */           if (paramLogger.isLoggable(Level.FINE))
/*     */           {
/* 302 */             paramLogger.fine("Property:portNumber Value:" + str3);
/*     */           }
/* 304 */           localProperties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
/* 305 */           str3 = "";
/* 306 */           j = 7;
/*     */         }
/*     */         else
/*     */         {
/* 310 */           str3 = str3 + c;
/*     */         }
/*     */         
/* 313 */         break;
/*     */       
/*     */ 
/*     */       case 3: 
/* 317 */         if ((c == ';') || (c == ':'))
/*     */         {
/*     */ 
/* 320 */           str3 = str3.trim();
/* 321 */           if (paramLogger.isLoggable(Level.FINE))
/*     */           {
/* 323 */             paramLogger.fine("Property:instanceName Value:" + str3);
/*     */           }
/* 325 */           localProperties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3.toLowerCase(java.util.Locale.US));
/* 326 */           str3 = "";
/*     */           
/* 328 */           if (c == ';') {
/* 329 */             j = 7;
/*     */           } else {
/* 331 */             j = 2;
/*     */           }
/*     */         }
/*     */         else {
/* 335 */           str3 = str3 + c;
/*     */         }
/*     */         
/* 338 */         break;
/*     */       
/*     */ 
/*     */       case 7: 
/* 342 */         if (c == '=')
/*     */         {
/*     */ 
/* 345 */           str4 = str4.trim();
/* 346 */           if (str4.length() <= 0)
/*     */           {
/* 348 */             SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */           }
/*     */           
/* 351 */           j = 6;
/*     */ 
/*     */         }
/* 354 */         else if (c == ';')
/*     */         {
/* 356 */           str4 = str4.trim();
/* 357 */           if (str4.length() > 0)
/*     */           {
/* 359 */             SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 366 */           str4 = str4 + c;
/*     */         }
/*     */         
/* 369 */         break;
/*     */       
/*     */ 
/*     */       case 6: 
/* 373 */         if (c == ';')
/*     */         {
/*     */ 
/* 376 */           str5 = str5.trim();
/* 377 */           str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 378 */           if (null != str4)
/*     */           {
/* 380 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 382 */               if ((false == str4.equals(SQLServerDriverStringProperty.USER.toString())) && (false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString())))
/* 383 */                 paramLogger.fine("Property:" + str4 + " Value:" + str5);
/*     */             }
/* 385 */             localProperties.put(str4, str5);
/*     */           }
/* 387 */           str4 = "";
/* 388 */           str5 = "";
/* 389 */           j = 7;
/*     */ 
/*     */ 
/*     */         }
/* 393 */         else if (c == '{')
/*     */         {
/* 395 */           j = 4;
/* 396 */           str5 = str5.trim();
/* 397 */           if (str5.length() > 0)
/*     */           {
/* 399 */             SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 404 */           str5 = str5 + c;
/*     */         }
/*     */         
/* 407 */         break;
/*     */       
/*     */ 
/*     */       case 4: 
/* 411 */         if (c == '}')
/*     */         {
/*     */ 
/* 414 */           str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 415 */           if (null != str4)
/*     */           {
/* 417 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 419 */               if ((false == str4.equals(SQLServerDriverStringProperty.USER.toString())) && (false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString())))
/* 420 */                 paramLogger.fine("Property:" + str4 + " Value:" + str5);
/*     */             }
/* 422 */             localProperties.put(str4, str5);
/*     */           }
/*     */           
/* 425 */           str4 = "";
/* 426 */           str5 = "";
/*     */           
/*     */ 
/* 429 */           j = 5;
/*     */         }
/*     */         else
/*     */         {
/* 433 */           str5 = str5 + c;
/*     */         }
/*     */         
/* 436 */         break;
/*     */       
/*     */ 
/*     */       case 5: 
/* 440 */         if (c == ';')
/*     */         {
/* 442 */           j = 7;
/*     */         }
/* 444 */         else if (c != ' ')
/*     */         {
/*     */ 
/* 447 */           SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         break;
/*     */       default: 
/* 454 */         if (!$assertionsDisabled) throw new AssertionError("parseURL: Invalid state " + j);
/*     */         break; }
/* 456 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 460 */     switch (j)
/*     */     {
/*     */     case 1: 
/* 463 */       str3 = str3.trim();
/* 464 */       if (str3.length() > 0)
/*     */       {
/* 466 */         if (paramLogger.isLoggable(Level.FINE))
/*     */         {
/* 468 */           paramLogger.fine("Property:serverName Value:" + str3);
/*     */         }
/* 470 */         localProperties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3);
/*     */       }
/*     */       break;
/*     */     case 2: 
/* 474 */       str3 = str3.trim();
/* 475 */       if (paramLogger.isLoggable(Level.FINE))
/*     */       {
/* 477 */         paramLogger.fine("Property:portNumber Value:" + str3);
/*     */       }
/* 479 */       localProperties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
/* 480 */       break;
/*     */     case 3: 
/* 482 */       str3 = str3.trim();
/* 483 */       if (paramLogger.isLoggable(Level.FINE))
/*     */       {
/* 485 */         paramLogger.fine("Property:instanceName Value:" + str3);
/*     */       }
/* 487 */       localProperties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3);
/* 488 */       break;
/*     */     
/*     */     case 6: 
/* 491 */       str5 = str5.trim();
/* 492 */       str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 493 */       if (null != str4)
/*     */       {
/* 495 */         if (paramLogger.isLoggable(Level.FINE))
/*     */         {
/* 497 */           if ((false == str4.equals(SQLServerDriverStringProperty.USER.toString())) && (false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString())))
/* 498 */             paramLogger.fine("Property:" + str4 + " Value:" + str5);
/*     */         }
/* 500 */         localProperties.put(str4, str5);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       break;
/*     */     case 0: 
/*     */     case 5: 
/*     */       break;
/*     */     case 7: 
/* 510 */       str4 = str4.trim();
/* 511 */       if (str4.length() > 0)
/*     */       {
/* 513 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     case 4: 
/*     */     default: 
/* 520 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */     }
/*     */     
/* 523 */     return localProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String escapeSQLId(String paramString)
/*     */   {
/* 545 */     StringBuilder localStringBuilder = new StringBuilder(paramString.length() + 2);
/*     */     
/* 547 */     localStringBuilder.append('[');
/* 548 */     for (int i = 0; i < paramString.length(); i++)
/*     */     {
/* 550 */       char c = paramString.charAt(i);
/* 551 */       if (']' == c) {
/* 552 */         localStringBuilder.append("]]");
/*     */       } else
/* 554 */         localStringBuilder.append(c);
/*     */     }
/* 556 */     localStringBuilder.append(']');
/* 557 */     return localStringBuilder.toString(); }
/*     */   
/*     */   static void checkDuplicateColumnName(String paramString, Map<Integer, ?> paramMap) throws SQLServerException { Iterator localIterator;
/*     */     Map.Entry localEntry;
/*     */     Object localObject;
/* 562 */     MessageFormat localMessageFormat; Object[] arrayOfObject; if ((paramMap.get(Integer.valueOf(0)) instanceof SQLServerMetaData))
/*     */     {
/* 564 */       for (localIterator = paramMap.entrySet().iterator(); localIterator.hasNext();) { localEntry = (Map.Entry)localIterator.next();
/*     */         
/* 566 */         localObject = (SQLServerMetaData)localEntry.getValue();
/* 567 */         if (((SQLServerMetaData)localObject).columnName.equals(paramString))
/*     */         {
/* 569 */           localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateColumnName"));
/* 570 */           arrayOfObject = new Object[] { paramString };
/* 571 */           throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */         }
/*     */         
/*     */       }
/* 575 */     } else if ((paramMap.get(Integer.valueOf(0)) instanceof SQLServerDataColumn))
/*     */     {
/* 577 */       for (localIterator = paramMap.entrySet().iterator(); localIterator.hasNext();) { localEntry = (Map.Entry)localIterator.next();
/*     */         
/* 579 */         localObject = (SQLServerDataColumn)localEntry.getValue();
/* 580 */         if (((SQLServerDataColumn)localObject).columnName.equals(paramString))
/*     */         {
/* 582 */           localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateColumnName"));
/* 583 */           arrayOfObject = new Object[] { paramString };
/* 584 */           throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String readUnicodeString(byte[] paramArrayOfByte, int paramInt1, int paramInt2, SQLServerConnection paramSQLServerConnection)
/*     */     throws SQLServerException
/*     */   {
/*     */     try
/*     */     {
/* 602 */       return new String(paramArrayOfByte, paramInt1, paramInt2, Encoding.UNICODE.charsetName());
/*     */     }
/*     */     catch (java.io.UnsupportedEncodingException localUnsupportedEncodingException)
/*     */     {
/* 606 */       str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
/* 607 */       localMessageFormat = new MessageFormat(str);
/* 608 */       arrayOfObject = new Object[] { new Integer(paramInt1) };
/*     */       
/* 610 */       throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*     */     }
/*     */     catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
/*     */     {
/* 614 */       String str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
/* 615 */       MessageFormat localMessageFormat = new MessageFormat(str);
/* 616 */       Object[] arrayOfObject = { new Integer(paramInt1) };
/*     */       
/* 618 */       throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String byteToHexDisplayString(byte[] paramArrayOfByte)
/*     */   {
/* 631 */     if (null == paramArrayOfByte) { return "(null)";
/*     */     }
/* 633 */     StringBuilder localStringBuilder = new StringBuilder(paramArrayOfByte.length * 2 + 2);
/* 634 */     localStringBuilder.append("0x");
/* 635 */     for (int j = 0; j < paramArrayOfByte.length; j++)
/*     */     {
/* 637 */       int i = paramArrayOfByte[j] & 0xFF;
/* 638 */       localStringBuilder.append(hexChars[((i & 0xF0) >> 4)]);
/* 639 */       localStringBuilder.append(hexChars[(i & 0xF)]);
/*     */     }
/* 641 */     return localStringBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String bytesToHexString(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 652 */     StringBuilder localStringBuilder = new StringBuilder(paramInt * 2);
/* 653 */     for (int i = 0; i < paramInt; i++)
/*     */     {
/* 655 */       int j = paramArrayOfByte[i] & 0xFF;
/* 656 */       localStringBuilder.append(hexChars[((j & 0xF0) >> 4)]);
/* 657 */       localStringBuilder.append(hexChars[(j & 0xF)]);
/*     */     }
/* 659 */     return localStringBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String lookupHostName()
/*     */   {
/*     */     try
/*     */     {
/* 673 */       InetAddress localInetAddress = InetAddress.getLocalHost();
/* 674 */       if (null != localInetAddress)
/*     */       {
/* 676 */         String str = localInetAddress.getHostName();
/* 677 */         if ((null != str) && (str.length() > 0)) { return str;
/*     */         }
/* 679 */         str = localInetAddress.getHostAddress();
/* 680 */         if ((null != str) && (str.length() > 0)) return str;
/*     */       }
/*     */     }
/*     */     catch (UnknownHostException localUnknownHostException)
/*     */     {
/* 685 */       return "";
/*     */     }
/*     */     
/* 688 */     return "";
/*     */   }
/*     */   
/*     */   static final byte[] asGuidByteArray(UUID paramUUID)
/*     */   {
/* 693 */     long l1 = paramUUID.getMostSignificantBits();
/* 694 */     long l2 = paramUUID.getLeastSignificantBits();
/* 695 */     byte[] arrayOfByte = new byte[16];
/* 696 */     writeLongBigEndian(l1, arrayOfByte, 0);
/* 697 */     writeLongBigEndian(l2, arrayOfByte, 8);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 706 */     int i = arrayOfByte[0];
/* 707 */     arrayOfByte[0] = arrayOfByte[3];
/* 708 */     arrayOfByte[3] = i;
/* 709 */     i = arrayOfByte[1];
/* 710 */     arrayOfByte[1] = arrayOfByte[2];
/* 711 */     arrayOfByte[2] = i;
/*     */     
/*     */ 
/* 714 */     i = arrayOfByte[4];
/* 715 */     arrayOfByte[4] = arrayOfByte[5];
/* 716 */     arrayOfByte[5] = i;
/*     */     
/*     */ 
/* 719 */     i = arrayOfByte[6];
/* 720 */     arrayOfByte[6] = arrayOfByte[7];
/* 721 */     arrayOfByte[7] = i;
/*     */     
/* 723 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */   static final String readGUID(byte[] paramArrayOfByte) throws SQLServerException
/*     */   {
/* 728 */     String str = "NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN";
/* 729 */     byte[] arrayOfByte = paramArrayOfByte;
/*     */     
/* 731 */     StringBuilder localStringBuilder = new StringBuilder(str.length());
/* 732 */     for (int i = 0; i < 4; i++)
/*     */     {
/* 734 */       localStringBuilder.append(hexChars[((arrayOfByte[(3 - i)] & 0xF0) >> 4)]);
/* 735 */       localStringBuilder.append(hexChars[(arrayOfByte[(3 - i)] & 0xF)]);
/*     */     }
/* 737 */     localStringBuilder.append('-');
/* 738 */     for (i = 0; i < 2; i++)
/*     */     {
/* 740 */       localStringBuilder.append(hexChars[((arrayOfByte[(5 - i)] & 0xF0) >> 4)]);
/* 741 */       localStringBuilder.append(hexChars[(arrayOfByte[(5 - i)] & 0xF)]);
/*     */     }
/* 743 */     localStringBuilder.append('-');
/* 744 */     for (i = 0; i < 2; i++)
/*     */     {
/* 746 */       localStringBuilder.append(hexChars[((arrayOfByte[(7 - i)] & 0xF0) >> 4)]);
/* 747 */       localStringBuilder.append(hexChars[(arrayOfByte[(7 - i)] & 0xF)]);
/*     */     }
/* 749 */     localStringBuilder.append('-');
/* 750 */     for (i = 0; i < 2; i++)
/*     */     {
/* 752 */       localStringBuilder.append(hexChars[((arrayOfByte[(8 + i)] & 0xF0) >> 4)]);
/* 753 */       localStringBuilder.append(hexChars[(arrayOfByte[(8 + i)] & 0xF)]);
/*     */     }
/* 755 */     localStringBuilder.append('-');
/* 756 */     for (i = 0; i < 6; i++)
/*     */     {
/* 758 */       localStringBuilder.append(hexChars[((arrayOfByte[(10 + i)] & 0xF0) >> 4)]);
/* 759 */       localStringBuilder.append(hexChars[(arrayOfByte[(10 + i)] & 0xF)]);
/*     */     }
/*     */     
/* 762 */     return localStringBuilder.toString();
/*     */   }
/*     */   
/*     */   static boolean IsActivityTraceOn()
/*     */   {
/* 767 */     LogManager localLogManager = LogManager.getLogManager();
/* 768 */     String str = localLogManager.getProperty("com.microsoft.sqlserver.jdbc.traceactivity");
/* 769 */     if ((null != str) && (str.equalsIgnoreCase("on"))) {
/* 770 */       return true;
/*     */     }
/* 772 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean shouldHonorAEForRead(SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, SQLServerConnection paramSQLServerConnection)
/*     */   {
/* 781 */     switch (paramSQLServerStatementColumnEncryptionSetting) {
/*     */     case Disabled: 
/* 783 */       return false;
/*     */     case Enabled: 
/* 785 */       return true;
/*     */     case ResultSetOnly: 
/* 787 */       return true;
/*     */     }
/*     */     
/*     */     
/* 791 */     assert (SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == paramSQLServerStatementColumnEncryptionSetting) : "Unexpected value for command level override";
/* 792 */     return (paramSQLServerConnection != null) && (paramSQLServerConnection.isColumnEncryptionSettingEnabled());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean shouldHonorAEForParameters(SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, SQLServerConnection paramSQLServerConnection)
/*     */   {
/* 802 */     switch (paramSQLServerStatementColumnEncryptionSetting) {
/*     */     case Disabled: 
/* 804 */       return false;
/*     */     case Enabled: 
/* 806 */       return true;
/*     */     case ResultSetOnly: 
/* 808 */       return false;
/*     */     }
/*     */     
/*     */     
/* 812 */     assert (SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == paramSQLServerStatementColumnEncryptionSetting) : "Unexpected value for command level override";
/* 813 */     return (paramSQLServerConnection != null) && (paramSQLServerConnection.isColumnEncryptionSettingEnabled());
/*     */   }
/*     */   
/*     */   static void validateMoneyRange(BigDecimal paramBigDecimal, JDBCType paramJDBCType)
/*     */     throws SQLServerException
/*     */   {
/* 819 */     if (null == paramBigDecimal) {
/* 820 */       return;
/*     */     }
/* 822 */     switch (paramJDBCType)
/*     */     {
/*     */     case MONEY: 
/* 825 */       if ((1 != paramBigDecimal.compareTo(SSType.MAX_VALUE_MONEY)) && (-1 != paramBigDecimal.compareTo(SSType.MIN_VALUE_MONEY))) {
/*     */         return;
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     case SMALLMONEY: 
/* 832 */       if ((1 != paramBigDecimal.compareTo(SSType.MAX_VALUE_SMALLMONEY)) && (-1 != paramBigDecimal.compareTo(SSType.MIN_VALUE_SMALLMONEY))) {
/*     */         return;
/*     */       }
/*     */       
/*     */       break;
/*     */     }
/*     */     
/* 839 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 840 */     Object[] arrayOfObject = { paramJDBCType };
/* 841 */     throw new SQLServerException(localMessageFormat.format(arrayOfObject), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static int getValueLengthBaseOnJavaType(Object paramObject, JavaType paramJavaType, Integer paramInteger1, Integer paramInteger2, JDBCType paramJDBCType)
/*     */   {
/* 849 */     switch (paramJavaType)
/*     */     {
/*     */ 
/*     */ 
/*     */     case OBJECT: 
/* 854 */       switch (paramJDBCType) {
/*     */       case DECIMAL: 
/*     */       case NUMERIC: 
/* 857 */         paramJavaType = JavaType.BIGDECIMAL;
/* 858 */         break;
/*     */       case TIME: 
/* 860 */         paramJavaType = JavaType.TIME;
/* 861 */         break;
/*     */       case TIMESTAMP: 
/* 863 */         paramJavaType = JavaType.TIMESTAMP;
/* 864 */         break;
/*     */       case DATETIMEOFFSET: 
/* 866 */         paramJavaType = JavaType.DATETIMEOFFSET; }
/* 867 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 874 */     switch (paramJavaType)
/*     */     {
/*     */     case STRING: 
/* 877 */       if (JDBCType.GUID == paramJDBCType) {
/* 878 */         String str1 = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";
/* 879 */         return null == paramObject ? 0 : str1.length();
/*     */       }
/* 881 */       if ((JDBCType.TIMESTAMP == paramJDBCType) || (JDBCType.TIME == paramJDBCType) || (JDBCType.DATETIMEOFFSET == paramJDBCType))
/*     */       {
/*     */ 
/* 884 */         return null == paramInteger2 ? 7 : paramInteger2.intValue();
/*     */       }
/*     */       
/* 887 */       return null == paramObject ? 0 : ((String)paramObject).length();
/*     */     
/*     */ 
/*     */     case BYTEARRAY: 
/* 891 */       return null == paramObject ? 0 : ((byte[])paramObject).length;
/*     */     
/*     */     case BIGDECIMAL: 
/* 894 */       int i = -1;
/*     */       
/* 896 */       if (null == paramInteger1) {
/* 897 */         if (null == paramObject) {
/* 898 */           i = 0;
/*     */         }
/*     */         else
/*     */         {
/*     */           Object localObject;
/* 903 */           if (0 == ((BigDecimal)paramObject).intValue()) {
/* 904 */             localObject = "" + (BigDecimal)paramObject;
/* 905 */             localObject = ((String)localObject).replaceAll("\\.", "");
/* 906 */             localObject = ((String)localObject).replaceAll("\\-", "");
/* 907 */             i = ((String)localObject).length();
/*     */ 
/*     */           }
/* 910 */           else if (("" + (BigDecimal)paramObject).contains("E")) {
/* 911 */             localObject = new DecimalFormat("###.#####");
/* 912 */             String str2 = ((DecimalFormat)localObject).format((BigDecimal)paramObject);
/* 913 */             str2 = str2.replaceAll("\\.", "");
/* 914 */             str2 = str2.replaceAll("\\-", "");
/* 915 */             i = str2.length();
/*     */           }
/*     */           else {
/* 918 */             i = ((BigDecimal)paramObject).precision();
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 923 */         i = paramInteger1.intValue();
/*     */       }
/*     */       
/* 926 */       return i;
/*     */     
/*     */     case TIMESTAMP: 
/*     */     case TIME: 
/*     */     case DATETIMEOFFSET: 
/* 931 */       return null == paramInteger2 ? 7 : paramInteger2.intValue();
/*     */     case READER: 
/* 933 */       return null == paramObject ? 0 : 1073741823;
/*     */     
/*     */     case CLOB: 
/* 936 */       return null == paramObject ? 0 : 2147483646;
/*     */     
/*     */     case NCLOB: 
/* 939 */       return null == paramObject ? 0 : 1073741823;
/*     */     }
/* 941 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static synchronized boolean checkIfNeedNewAccessToken(SQLServerConnection paramSQLServerConnection)
/*     */   {
/* 948 */     Date localDate1 = paramSQLServerConnection.getAuthenticationResult().getExpiresOnDate();
/* 949 */     Date localDate2 = new Date();
/*     */     
/*     */ 
/*     */ 
/* 953 */     if (localDate1.getTime() - localDate2.getTime() < 2700000L)
/*     */     {
/*     */ 
/* 956 */       if (localDate1.getTime() - localDate2.getTime() < 600000L) {
/* 957 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 961 */       if (paramSQLServerConnection.attemptRefreshTokenLocked) {
/* 962 */         return false;
/*     */       }
/*     */       
/* 965 */       paramSQLServerConnection.attemptRefreshTokenLocked = true;
/* 966 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 971 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/Util.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */