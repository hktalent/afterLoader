/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.DatagramPacket;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.IDN;
/*      */ import java.net.InetAddress;
/*      */ import java.net.SocketException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLClientInfoException;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLPermission;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Struct;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.xml.bind.DatatypeConverter;
/*      */ 
/*      */ public class SQLServerConnection implements ISQLServerConnection
/*      */ {
/*      */   long timerExpire;
/*   46 */   boolean attemptRefreshTokenLocked = false;
/*      */   
/*   48 */   private boolean fedAuthRequiredByUser = false;
/*   49 */   private boolean fedAuthRequiredPreLoginResponse = false;
/*   50 */   private boolean federatedAuthenticationAcknowledged = false;
/*   51 */   private boolean federatedAuthenticationRequested = false;
/*   52 */   private boolean federatedAuthenticationInfoRequested = false;
/*      */   
/*   54 */   private FederatedAuthenticationFeatureExtensionData fedAuthFeatureExtensionData = null;
/*   55 */   private String authenticationString = null;
/*   56 */   private byte[] accessTokenInByte = null;
/*      */   
/*   58 */   private SqlFedAuthToken fedAuthToken = null;
/*      */   private static final float TIMEOUTSTEP = 0.08F;
/*      */   
/*   61 */   SqlFedAuthToken getAuthenticationResult() { return this.fedAuthToken; }
/*      */   
/*      */ 
/*      */ 
/*      */   class FederatedAuthenticationFeatureExtensionData
/*      */   {
/*      */     boolean fedAuthRequiredPreLoginResponse;
/*      */     
/*      */ 
/*   70 */     int libraryType = -1;
/*   71 */     byte[] accessToken = null;
/*   72 */     SqlAuthentication authentication = null;
/*      */     
/*      */     FederatedAuthenticationFeatureExtensionData(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException {
/*   75 */       this.libraryType = paramInt;
/*   76 */       this.fedAuthRequiredPreLoginResponse = paramBoolean;
/*      */       
/*   78 */       switch (paramString.toUpperCase(Locale.ENGLISH).trim()) {
/*      */       case "ACTIVEDIRECTORYPASSWORD": 
/*   80 */         this.authentication = SqlAuthentication.ActiveDirectoryPassword;
/*   81 */         break;
/*      */       case "ACTIVEDIRECTORYINTEGRATED": 
/*   83 */         this.authentication = SqlAuthentication.ActiveDirectoryIntegrated;
/*   84 */         break;
/*      */       default: 
/*   86 */         if (!$assertionsDisabled) throw new AssertionError();
/*   87 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/*   88 */         Object[] arrayOfObject = { "authentication", paramString };
/*   89 */         throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */       }
/*      */     }
/*      */     
/*      */     FederatedAuthenticationFeatureExtensionData(int paramInt, boolean paramBoolean, byte[] paramArrayOfByte) {
/*   94 */       this.libraryType = paramInt;
/*   95 */       this.fedAuthRequiredPreLoginResponse = paramBoolean;
/*   96 */       this.accessToken = paramArrayOfByte;
/*      */     }
/*      */   }
/*      */   
/*      */   class SqlFedAuthInfo {
/*      */     private String spn;
/*      */     private String stsurl;
/*      */     
/*      */     SqlFedAuthInfo() {}
/*      */     
/*  106 */     public String toString() { return "STSURL: " + this.stsurl + ", SPN: " + this.spn; }
/*      */   }
/*      */   
/*      */   final class SqlFedAuthToken
/*      */   {
/*      */     private final Date expiresOn;
/*      */     private final String accessToken;
/*      */     
/*      */     SqlFedAuthToken(String paramString, long paramLong) {
/*  115 */       this.accessToken = paramString;
/*      */       
/*  117 */       Date localDate = new Date();
/*  118 */       localDate.setTime(localDate.getTime() + paramLong * 1000L);
/*  119 */       this.expiresOn = localDate;
/*      */     }
/*      */     
/*      */     Date getExpiresOnDate() {
/*  123 */       return this.expiresOn;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private class ActiveDirectoryAuthentication
/*      */   {
/*      */     private static final String jdbcFedauthClientId = "7f98cb04-cd1e-40df-9140-3bf7e2cea4db";
/*      */     
/*      */     private static final String AdalGetAccessTokenFunctionName = "ADALGetAccessToken";
/*      */     
/*      */     private static final int GetAccessTokenSuccess = 0;
/*      */     private static final int GetAccessTokenInvalidGrant = 1;
/*      */     private static final int GetAccessTokenTansisentError = 2;
/*      */     private static final int GetAccessTokenOtherError = 3;
/*      */     
/*      */     private ActiveDirectoryAuthentication() {}
/*      */   }
/*      */   
/*      */   private static enum State
/*      */   {
/*  144 */     Initialized, 
/*  145 */     Connected, 
/*  146 */     Opened, 
/*  147 */     Closed;
/*      */     
/*      */ 
/*      */ 
/*      */     private State() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final int TnirFirstAttemptTimeoutMs = 500;
/*      */   
/*      */ 
/*      */   private static final int INTERMITTENT_TLS_MAX_RETRY = 5;
/*      */   
/*      */ 
/*  162 */   private boolean isRoutedInCurrentAttempt = false;
/*      */   
/*      */ 
/*  165 */   private ServerPortPlaceHolder routingInfo = null;
/*      */   
/*      */ 
/*      */   private static final String callAbortPerm = "callAbort";
/*      */   
/*      */ 
/*  171 */   private boolean sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue();
/*  172 */   boolean sendStringParametersAsUnicode() { return this.sendStringParametersAsUnicode; }
/*      */   
/*  174 */   final boolean useLastUpdateCount() { return this.lastUpdateCount; }
/*      */   
/*      */   private boolean lastUpdateCount;
/*  177 */   private boolean serverNameAsACE = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue();
/*  178 */   boolean serverNameAsACE() { return this.serverNameAsACE; }
/*      */   
/*      */   private boolean multiSubnetFailover;
/*      */   private boolean transparentNetworkIPResolution;
/*      */   final boolean getMultiSubnetFailover()
/*      */   {
/*  184 */     return this.multiSubnetFailover;
/*      */   }
/*      */   
/*      */ 
/*      */   final boolean getTransparentNetworkIPResolution()
/*      */   {
/*  190 */     return this.transparentNetworkIPResolution;
/*      */   }
/*      */   
/*      */ 
/*  194 */   private ApplicationIntent applicationIntent = null;
/*      */   private int nLockTimeout;
/*      */   
/*  197 */   final ApplicationIntent getApplicationIntent() { return this.applicationIntent; }
/*      */   
/*      */   private String selectMethod;
/*      */   private String responseBuffering;
/*      */   final String getSelectMethod() {
/*  202 */     return this.selectMethod; }
/*      */   
/*  204 */   final String getResponseBuffering() { return this.responseBuffering; }
/*      */   
/*  206 */   private boolean sendTimeAsDatetime = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue();
/*      */   
/*      */   public final synchronized boolean getSendTimeAsDatetime()
/*      */   {
/*  210 */     return (!isKatmaiOrLater()) || (this.sendTimeAsDatetime);
/*      */   }
/*      */   
/*      */   final int baseYear()
/*      */   {
/*  215 */     return getSendTimeAsDatetime() ? 1970 : 1900;
/*      */   }
/*      */   
/*  218 */   private byte requestedEncryptionLevel = -1;
/*      */   private boolean trustServerCertificate;
/*      */   
/*  221 */   final byte getRequestedEncryptionLevel() { assert (-1 != this.requestedEncryptionLevel);
/*  222 */     return this.requestedEncryptionLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  227 */   final boolean trustServerCertificate() { return this.trustServerCertificate; }
/*      */   
/*  229 */   private byte negotiatedEncryptionLevel = -1;
/*      */   static final String RESERVED_PROVIDER_NAME_PREFIX = "MSSQL_";
/*      */   
/*  232 */   final byte getNegotiatedEncryptionLevel() { assert (-1 != this.negotiatedEncryptionLevel);
/*  233 */     return this.negotiatedEncryptionLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  238 */   String columnEncryptionSetting = null;
/*      */   
/*  240 */   boolean isColumnEncryptionSettingEnabled() { return this.columnEncryptionSetting.equalsIgnoreCase(ColumnEncryptionSetting.Enabled.toString()); }
/*      */   
/*      */ 
/*  243 */   String keyStoreAuthentication = null;
/*  244 */   String keyStoreSecret = null;
/*  245 */   String keyStoreLocation = null;
/*      */   
/*  247 */   private boolean serverSupportsColumnEncryption = false;
/*      */   static boolean isWindows;
/*      */   
/*  250 */   boolean getServerSupportsColumnEncryption() { return this.serverSupportsColumnEncryption; }
/*      */   
/*      */   static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalSystemColumnEncryptionKeyStoreProviders;
/*  253 */   static { globalSystemColumnEncryptionKeyStoreProviders = new HashMap();
/*      */     
/*      */ 
/*      */ 
/*  257 */     if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows"))
/*      */     {
/*  259 */       isWindows = true;
/*  260 */       SQLServerColumnEncryptionCertificateStoreProvider localSQLServerColumnEncryptionCertificateStoreProvider = new SQLServerColumnEncryptionCertificateStoreProvider();
/*  261 */       globalSystemColumnEncryptionKeyStoreProviders.put(localSQLServerColumnEncryptionCertificateStoreProvider.getName(), localSQLServerColumnEncryptionCertificateStoreProvider);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  267 */       isWindows = false;
/*      */     } }
/*      */   
/*  270 */   static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalCustomColumnEncryptionKeyStoreProviders = null;
/*      */   
/*  272 */   Map<String, SQLServerColumnEncryptionKeyStoreProvider> systemColumnEncryptionKeyStoreProvider = new HashMap();
/*      */   
/*      */ 
/*      */   public static synchronized void registerColumnEncryptionKeyStoreProviders(Map<String, SQLServerColumnEncryptionKeyStoreProvider> paramMap)
/*      */     throws SQLServerException
/*      */   {
/*  278 */     loggerExternal.entering(SQLServerConnection.class.getName(), "registerColumnEncryptionKeyStoreProviders", "Registering Column Encryption Key Store Providers");
/*      */     
/*  280 */     if (null == paramMap)
/*      */     {
/*  282 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderMapNull"), null, 0, false);
/*      */     }
/*      */     
/*  285 */     if (null != globalCustomColumnEncryptionKeyStoreProviders)
/*      */     {
/*  287 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderSetOnce"), null, 0, false);
/*      */     }
/*      */     
/*  290 */     globalCustomColumnEncryptionKeyStoreProviders = new HashMap();
/*      */     
/*  292 */     for (Map.Entry localEntry : paramMap.entrySet())
/*      */     {
/*  294 */       String str = (String)localEntry.getKey();
/*  295 */       if ((null == str) || (0 == str.length()))
/*      */       {
/*  297 */         throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyCustomKeyStoreProviderName"), null, 0, false); }
/*      */       MessageFormat localMessageFormat;
/*  299 */       Object[] arrayOfObject; if (str.substring(0, 6).equalsIgnoreCase("MSSQL_"))
/*      */       {
/*  301 */         localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCustomKeyStoreProviderName"));
/*  302 */         arrayOfObject = new Object[] { str, "MSSQL_" };
/*  303 */         throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */       }
/*  305 */       if (null == localEntry.getValue())
/*      */       {
/*  307 */         localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_CustomKeyStoreProviderValueNull"));
/*  308 */         arrayOfObject = new Object[] { str, "MSSQL_" };
/*  309 */         throw new SQLServerException(null, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */       }
/*  311 */       globalCustomColumnEncryptionKeyStoreProviders.put(localEntry.getKey(), localEntry.getValue());
/*      */     }
/*      */     
/*  314 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "registerColumnEncryptionKeyStoreProviders", "Number of Key store providers that are registered:" + globalCustomColumnEncryptionKeyStoreProviders.size());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalSystemColumnEncryptionKeyStoreProvider(String paramString)
/*      */   {
/*  323 */     if ((null != globalSystemColumnEncryptionKeyStoreProviders) && (globalSystemColumnEncryptionKeyStoreProviders.containsKey(paramString)))
/*      */     {
/*      */ 
/*  326 */       return (SQLServerColumnEncryptionKeyStoreProvider)globalSystemColumnEncryptionKeyStoreProviders.get(paramString);
/*      */     }
/*  328 */     return null;
/*      */   }
/*      */   
/*      */   static synchronized String getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders()
/*      */   {
/*  333 */     if (null != globalCustomColumnEncryptionKeyStoreProviders) {
/*  334 */       return globalCustomColumnEncryptionKeyStoreProviders.keySet().toString();
/*      */     }
/*  336 */     return null;
/*      */   }
/*      */   
/*      */   synchronized String getAllSystemColumnEncryptionKeyStoreProviders()
/*      */   {
/*  341 */     String str = "";
/*  342 */     if (0 != this.systemColumnEncryptionKeyStoreProvider.size())
/*  343 */       str = this.systemColumnEncryptionKeyStoreProvider.keySet().toString();
/*  344 */     if (0 != globalSystemColumnEncryptionKeyStoreProviders.size())
/*  345 */       str = str + "," + globalSystemColumnEncryptionKeyStoreProviders.keySet().toString();
/*  346 */     return str;
/*      */   }
/*      */   
/*      */   static synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalCustomColumnEncryptionKeyStoreProvider(String paramString)
/*      */   {
/*  351 */     if ((null != globalCustomColumnEncryptionKeyStoreProviders) && (globalCustomColumnEncryptionKeyStoreProviders.containsKey(paramString)))
/*      */     {
/*      */ 
/*  354 */       return (SQLServerColumnEncryptionKeyStoreProvider)globalCustomColumnEncryptionKeyStoreProviders.get(paramString);
/*      */     }
/*  356 */     return null;
/*      */   }
/*      */   
/*      */   synchronized SQLServerColumnEncryptionKeyStoreProvider getSystemColumnEncryptionKeyStoreProvider(String paramString)
/*      */   {
/*  361 */     if ((null != this.systemColumnEncryptionKeyStoreProvider) && (this.systemColumnEncryptionKeyStoreProvider.containsKey(paramString)))
/*      */     {
/*      */ 
/*  364 */       return (SQLServerColumnEncryptionKeyStoreProvider)this.systemColumnEncryptionKeyStoreProvider.get(paramString);
/*      */     }
/*      */     
/*      */ 
/*  368 */     return null;
/*      */   }
/*      */   
/*      */ 
/*  372 */   private String trustedServerNameAE = null;
/*  373 */   private static Map<String, List<String>> columnEncryptionTrustedMasterKeyPaths = new HashMap();
/*      */   Properties activeConnectionProperties;
/*      */   
/*      */   public static synchronized void setColumnEncryptionTrustedMasterKeyPaths(Map<String, List<String>> paramMap) {
/*  377 */     loggerExternal.entering(SQLServerConnection.class.getName(), "setColumnEncryptionTrustedMasterKeyPaths", "Setting Trusted Master Key Paths");
/*      */     
/*      */ 
/*  380 */     columnEncryptionTrustedMasterKeyPaths.clear();
/*  381 */     for (Map.Entry localEntry : paramMap.entrySet())
/*      */     {
/*  383 */       columnEncryptionTrustedMasterKeyPaths.put(((String)localEntry.getKey()).toUpperCase(), localEntry.getValue());
/*      */     }
/*      */     
/*  386 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "setColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
/*      */   }
/*      */   
/*      */   public static synchronized void updateColumnEncryptionTrustedMasterKeyPaths(String paramString, List<String> paramList)
/*      */   {
/*  391 */     loggerExternal.entering(SQLServerConnection.class.getName(), "updateColumnEncryptionTrustedMasterKeyPaths", "Updating Trusted Master Key Paths");
/*      */     
/*      */ 
/*  394 */     columnEncryptionTrustedMasterKeyPaths.put(paramString.toUpperCase(), paramList);
/*      */     
/*  396 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "updateColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
/*      */   }
/*      */   
/*      */   public static synchronized void removeColumnEncryptionTrustedMasterKeyPaths(String paramString)
/*      */   {
/*  401 */     loggerExternal.entering(SQLServerConnection.class.getName(), "removeColumnEncryptionTrustedMasterKeyPaths", "Removing Trusted Master Key Paths");
/*      */     
/*      */ 
/*  404 */     columnEncryptionTrustedMasterKeyPaths.remove(paramString.toUpperCase());
/*      */     
/*  406 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "removeColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
/*      */   }
/*      */   
/*      */   public static synchronized Map<String, List<String>> getColumnEncryptionTrustedMasterKeyPaths()
/*      */   {
/*  411 */     loggerExternal.entering(SQLServerConnection.class.getName(), "getColumnEncryptionTrustedMasterKeyPaths", "Getting Trusted Master Key Paths");
/*      */     
/*  413 */     HashMap localHashMap = new HashMap();
/*      */     
/*  415 */     for (Map.Entry localEntry : columnEncryptionTrustedMasterKeyPaths.entrySet()) {
/*  416 */       localHashMap.put(localEntry.getKey(), localEntry.getValue());
/*      */     }
/*      */     
/*  419 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "getColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + localHashMap.size());
/*      */     
/*  421 */     return localHashMap;
/*      */   }
/*      */   
/*      */   static synchronized List<String> getColumnEncryptionTrustedMasterKeyPaths(String paramString, Boolean[] paramArrayOfBoolean)
/*      */   {
/*  426 */     if (columnEncryptionTrustedMasterKeyPaths.containsKey(paramString))
/*      */     {
/*  428 */       paramArrayOfBoolean[0] = Boolean.valueOf(true);
/*  429 */       return (List)columnEncryptionTrustedMasterKeyPaths.get(paramString);
/*      */     }
/*      */     
/*      */ 
/*  433 */     paramArrayOfBoolean[0] = Boolean.valueOf(false);
/*  434 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  439 */   private boolean integratedSecurity = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue();
/*  440 */   private AuthenticationScheme intAuthScheme = AuthenticationScheme.nativeAuthentication;
/*      */   
/*  442 */   ServerPortPlaceHolder currentConnectPlaceHolder = null;
/*      */   
/*      */   String sqlServerVersion;
/*      */   boolean xopenStates;
/*      */   private boolean databaseAutoCommitMode;
/*  447 */   private boolean inXATransaction = false;
/*  448 */   private byte[] transactionDescriptor = new byte[8];
/*      */   
/*      */   private boolean rolledBackTransaction;
/*      */   
/*      */ 
/*  453 */   final boolean rolledBackTransaction() { return this.rolledBackTransaction; }
/*      */   
/*  455 */   private State state = State.Initialized;
/*      */   static final int maxDecimalPrecision = 38;
/*      */   
/*      */   private void setState(State paramState) {
/*  459 */     this.state = paramState;
/*      */   }
/*      */   
/*      */   static final int defaultDecimalPrecision = 18;
/*      */   final String traceID;
/*      */   final boolean isSessionUnAvailable() {
/*  465 */     return !this.state.equals(State.Opened);
/*      */   }
/*      */   
/*      */ 
/*      */   private int maxFieldSize;
/*      */   
/*      */   private int maxRows;
/*      */   
/*      */   private SQLCollation databaseCollation;
/*      */   final void setMaxFieldSize(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  477 */     if (this.maxFieldSize != paramInt)
/*      */     {
/*  479 */       if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */       {
/*  481 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*      */       
/*  484 */       connectionCommand("SET TEXTSIZE " + (0 == paramInt ? Integer.MAX_VALUE : paramInt), "setMaxFieldSize");
/*  485 */       this.maxFieldSize = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void initResettableValues()
/*      */   {
/*  496 */     this.rolledBackTransaction = false;
/*  497 */     this.transactionIsolationLevel = 2;
/*  498 */     this.maxFieldSize = 0;
/*  499 */     this.maxRows = 0;
/*  500 */     this.nLockTimeout = -1;
/*  501 */     this.databaseAutoCommitMode = true;
/*  502 */     this.holdability = 1;
/*  503 */     this.sqlWarnings = null;
/*  504 */     this.sCatalog = this.originalCatalog;
/*  505 */     this.databaseMetaData = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final void setMaxRows(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/*  513 */     if (this.maxRows != paramInt)
/*      */     {
/*  515 */       if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */       {
/*  517 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*  519 */       connectionCommand("SET ROWCOUNT " + paramInt, "setMaxRows");
/*  520 */       this.maxRows = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  525 */   final SQLCollation getDatabaseCollation() { return this.databaseCollation; }
/*      */   
/*  527 */   private static int baseConnectionID = 0;
/*      */   
/*  529 */   private String sCatalog = "master";
/*      */   
/*  531 */   private String originalCatalog = "master";
/*      */   
/*      */   private int transactionIsolationLevel;
/*      */   private SQLServerPooledConnection pooledConnectionParent;
/*      */   private DatabaseMetaData databaseMetaData;
/*  536 */   private int nNextSavePointId = 10000;
/*      */   
/*  538 */   private static final Logger connectionlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerConnection");
/*      */   
/*  540 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Connection");
/*      */   
/*      */ 
/*      */ 
/*      */   private final String loggingClassName;
/*      */   
/*      */ 
/*  547 */   private String failoverPartnerServerProvided = null;
/*      */   private int holdability;
/*      */   
/*  550 */   final int getHoldabilityInternal() { return this.holdability; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  555 */   private int tdsPacketSize = 4096;
/*  556 */   private int requestedPacketSize = 8000;
/*  557 */   final int getTDSPacketSize() { return this.tdsPacketSize; }
/*      */   
/*      */ 
/*      */   private TDSChannel tdsChannel;
/*  561 */   private TDSCommand currentCommand = null;
/*      */   
/*  563 */   private int tdsVersion = 0;
/*      */   private int serverMajorVersion;
/*      */   private SQLServerConnectionPoolProxy proxy;
/*      */   
/*  567 */   final boolean isKatmaiOrLater() { assert (0 != this.tdsVersion);
/*  568 */     assert (this.tdsVersion >= 1913192450);
/*  569 */     return this.tdsVersion >= 1930100739;
/*      */   }
/*      */   
/*      */   final boolean isDenaliOrLater()
/*      */   {
/*  574 */     return this.tdsVersion >= 1946157060;
/*      */   }
/*      */   
/*      */ 
/*      */   int getServerMajorVersion()
/*      */   {
/*  580 */     return this.serverMajorVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  585 */   private UUID clientConnectionId = null;
/*      */   static final int MAX_SQL_LOGIN_NAME_WCHARS = 128;
/*      */   
/*      */   public UUID getClientConnectionId()
/*      */     throws SQLServerException
/*      */   {
/*  591 */     checkClosed();
/*  592 */     return this.clientConnectionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final UUID getClientConIdInternal()
/*      */   {
/*  599 */     return this.clientConnectionId;
/*      */   }
/*      */   
/*      */   final boolean attachConnId()
/*      */   {
/*  604 */     return this.state.equals(State.Connected);
/*      */   }
/*      */   
/*      */ 
/*      */   SQLServerConnection(String paramString)
/*      */     throws SQLServerException
/*      */   {
/*  611 */     int i = nextConnectionID();
/*  612 */     this.traceID = ("ConnectionID:" + i);
/*  613 */     this.loggingClassName = ("com.microsoft.sqlserver.jdbc.SQLServerConnection:" + i);
/*  614 */     if (connectionlogger.isLoggable(Level.FINE))
/*  615 */       connectionlogger.fine(toString() + " created by (" + paramString + ")");
/*  616 */     initResettableValues();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setFailoverPartnerServerProvided(String paramString)
/*      */   {
/*  631 */     this.failoverPartnerServerProvided = paramString;
/*      */   }
/*      */   
/*      */ 
/*      */   final void setAssociatedProxy(SQLServerConnectionPoolProxy paramSQLServerConnectionPoolProxy)
/*      */   {
/*  637 */     this.proxy = paramSQLServerConnectionPoolProxy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Connection getConnection()
/*      */   {
/*  648 */     if (null != this.proxy) {
/*  649 */       return this.proxy;
/*      */     }
/*  651 */     return this;
/*      */   }
/*      */   
/*      */   final void resetPooledConnection()
/*      */   {
/*  656 */     this.tdsChannel.resetPooledConnection();
/*  657 */     initResettableValues();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static synchronized int nextConnectionID()
/*      */   {
/*  666 */     baseConnectionID += 1;
/*  667 */     return baseConnectionID;
/*      */   }
/*      */   
/*      */   Logger getConnectionLogger() {
/*  671 */     return connectionlogger;
/*      */   }
/*      */   
/*      */   String getClassNameLogging()
/*      */   {
/*  676 */     return this.loggingClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  685 */     if (null != this.clientConnectionId) {
/*  686 */       return this.traceID + " ClientConnectionId: " + this.clientConnectionId.toString();
/*      */     }
/*  688 */     return this.traceID;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void NotImplemented()
/*      */     throws SQLServerException
/*      */   {
/*  698 */     SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_notSupported"), null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkClosed()
/*      */     throws SQLServerException
/*      */   {
/*  708 */     if (isSessionUnAvailable())
/*      */     {
/*  710 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), null, false);
/*      */     }
/*      */     
/*  713 */     if ((null != this.fedAuthToken) && 
/*  714 */       (Util.checkIfNeedNewAccessToken(this)))
/*      */     {
/*  716 */       connect(this.activeConnectionProperties, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean booleanPropertyOn(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/*  731 */     if (null == paramString2) return false;
/*  732 */     String str = paramString2.toLowerCase(Locale.US);
/*      */     
/*  734 */     if (str.equals("true")) return true;
/*  735 */     if (str.equals("false")) return false;
/*  736 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidBooleanValue"));
/*  737 */     Object[] arrayOfObject = { new String(paramString1) };
/*  738 */     SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */     
/*  740 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void ValidateMaxSQLLoginName(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/*  756 */     if ((paramString2 != null) && (paramString2.length() > 128))
/*      */     {
/*  758 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_propertyMaximumExceedsChars"));
/*  759 */       Object[] arrayOfObject = { paramString1, Integer.toString(128) };
/*  760 */       SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */     }
/*      */   }
/*      */   
/*      */   Connection connect(Properties paramProperties, SQLServerPooledConnection paramSQLServerPooledConnection) throws SQLServerException
/*      */   {
/*  766 */     int i = 0;
/*  767 */     long l1 = System.currentTimeMillis();
/*      */     
/*  769 */     int j = 0;
/*      */     for (;;)
/*      */     {
/*      */       try {
/*  773 */         return connectInternal(paramProperties, paramSQLServerPooledConnection);
/*      */ 
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/*  778 */         if (7 != localSQLServerException.getDriverErrorCode())
/*      */         {
/*      */ 
/*  781 */           throw localSQLServerException;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  788 */         if (0 == j)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  793 */           i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  794 */           String str = paramProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/*  795 */           if ((null != str) && (str.length() > 0))
/*      */           {
/*  797 */             i = Integer.parseInt(str);
/*      */           }
/*      */         }
/*      */         
/*  801 */         j++;
/*  802 */         long l2 = (System.currentTimeMillis() - l1) / 1000L;
/*      */         
/*  804 */         if (5 < j)
/*      */         {
/*      */ 
/*  807 */           if (connectionlogger.isLoggable(Level.FINE))
/*      */           {
/*  809 */             connectionlogger.fine("Connection failed during SSL handshake. Maximum retry attempt (5) reached.  ");
/*      */           }
/*  811 */           throw localSQLServerException;
/*      */         }
/*  813 */         if (l2 >= i)
/*      */         {
/*      */ 
/*  816 */           if (connectionlogger.isLoggable(Level.FINE))
/*      */           {
/*  818 */             connectionlogger.fine("Connection failed during SSL handshake. Not retrying as timeout expired.");
/*      */           }
/*  820 */           throw localSQLServerException;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  825 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/*  827 */           connectionlogger.fine("Connection failed during SSL handshake. Retrying due to an intermittent TLS 1.2 failure issue. Retry attempt = " + j + ".");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void registerKeyStoreProviderOnConnection(String paramString1, String paramString2, String paramString3) throws SQLServerException
/*      */   {
/*      */     Object localObject1;
/*      */     Object localObject2;
/*  837 */     if (null == paramString1)
/*      */     {
/*      */ 
/*  840 */       if (null != paramString2)
/*      */       {
/*  842 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
/*  843 */         localObject2 = new Object[] { "keyStoreSecret" };
/*  844 */         throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), null);
/*      */       }
/*  846 */       if (null != paramString3)
/*      */       {
/*  848 */         localObject1 = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
/*  849 */         localObject2 = new Object[] { "keyStoreLocation" };
/*  850 */         throw new SQLServerException(((MessageFormat)localObject1).format(localObject2), null);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  855 */       localObject1 = KeyStoreAuthentication.valueOfString(paramString1);
/*  856 */       switch (localObject1)
/*      */       {
/*      */ 
/*      */       case JavaKeyStorePassword: 
/*  860 */         if ((null == paramString2) || (null == paramString3))
/*      */         {
/*  862 */           throw new SQLServerException(SQLServerException.getErrString("R_keyStoreSecretOrLocationNotSet"), null);
/*      */         }
/*      */         
/*      */ 
/*  866 */         localObject2 = new SQLServerColumnEncryptionJavaKeyStoreProvider(paramString3, paramString2.toCharArray());
/*  867 */         this.systemColumnEncryptionKeyStoreProvider.put(((SQLServerColumnEncryptionJavaKeyStoreProvider)localObject2).getName(), localObject2);
/*      */         
/*      */ 
/*      */ 
/*  871 */         break;
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Connection connectInternal(Properties paramProperties, SQLServerPooledConnection paramSQLServerPooledConnection)
/*      */     throws SQLServerException
/*      */   {
/*      */     try
/*      */     {
/*  920 */       this.activeConnectionProperties = ((Properties)paramProperties.clone());
/*      */       
/*  922 */       this.pooledConnectionParent = paramSQLServerPooledConnection;
/*      */       
/*  924 */       String str1 = null;
/*  925 */       String str2 = null;
/*      */       
/*  927 */       str1 = SQLServerDriverStringProperty.USER.toString();
/*  928 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  929 */       if (str2 == null)
/*      */       {
/*  931 */         str2 = SQLServerDriverStringProperty.USER.getDefaultValue();
/*  932 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/*  934 */       ValidateMaxSQLLoginName(str1, str2);
/*      */       
/*      */ 
/*  937 */       str1 = SQLServerDriverStringProperty.PASSWORD.toString();
/*  938 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  939 */       if (str2 == null)
/*      */       {
/*  941 */         str2 = SQLServerDriverStringProperty.PASSWORD.getDefaultValue();
/*  942 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/*  944 */       ValidateMaxSQLLoginName(str1, str2);
/*      */       
/*  946 */       str1 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/*  947 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  948 */       ValidateMaxSQLLoginName(str1, str2);
/*      */       
/*      */ 
/*  951 */       int i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  952 */       str2 = this.activeConnectionProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/*  953 */       if ((null != str2) && (str2.length() > 0))
/*      */       {
/*      */         try
/*      */         {
/*  957 */           i = Integer.parseInt(str2);
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException1)
/*      */         {
/*  961 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/*  962 */           Object[] arrayOfObject1 = { str2 };
/*  963 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject2).format(arrayOfObject1), null, false);
/*      */         }
/*      */         
/*  966 */         if ((i < 0) || (i > 65535))
/*      */         {
/*  968 */           localObject1 = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/*  969 */           localObject2 = new Object[] { str2 };
/*  970 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject1).format(localObject2), null, false);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  975 */       str1 = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString();
/*  976 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  977 */       if (str2 == null)
/*      */       {
/*  979 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue());
/*  980 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/*  982 */       this.serverNameAsACE = booleanPropertyOn(str1, str2);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  987 */       str1 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*  988 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*      */       
/*  990 */       if (str2 == null)
/*      */       {
/*  992 */         str2 = "localhost";
/*      */       }
/*      */       
/*  995 */       Object localObject1 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/*  996 */       Object localObject2 = this.activeConnectionProperties.getProperty((String)localObject1);
/*      */       
/*  998 */       int j = str2.indexOf('\\');
/*      */       
/* 1000 */       Object localObject3 = null;
/* 1001 */       Object localObject4 = null;
/*      */       
/* 1003 */       String str3 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/*      */       
/* 1005 */       if (j >= 0)
/*      */       {
/* 1007 */         localObject4 = str2.substring(j + 1, str2.length());
/* 1008 */         ValidateMaxSQLLoginName(str3, (String)localObject4);
/* 1009 */         str2 = str2.substring(0, j);
/*      */       }
/* 1011 */       this.trustedServerNameAE = str2;
/*      */       MessageFormat localMessageFormat1;
/* 1013 */       Object localObject5; if (true == this.serverNameAsACE)
/*      */       {
/*      */         try
/*      */         {
/* 1017 */           str2 = IDN.toASCII(str2);
/*      */         }
/*      */         catch (IllegalArgumentException localIllegalArgumentException)
/*      */         {
/* 1021 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/* 1022 */           localObject5 = new Object[] { "serverNameAsACE", str2 };
/* 1023 */           throw new SQLServerException(localMessageFormat1.format(localObject5), localIllegalArgumentException);
/*      */         }
/*      */       }
/* 1026 */       this.activeConnectionProperties.setProperty(str1, str2);
/*      */       
/* 1028 */       String str4 = this.activeConnectionProperties.getProperty(str3);
/*      */       
/* 1030 */       if (null != str4) {
/* 1031 */         localObject4 = str4;
/*      */       }
/* 1033 */       if (localObject4 != null)
/*      */       {
/* 1035 */         ValidateMaxSQLLoginName(str3, (String)localObject4);
/*      */         
/* 1037 */         this.activeConnectionProperties.setProperty(str3, (String)localObject4);
/* 1038 */         this.trustedServerNameAE = (this.trustedServerNameAE + "\\" + (String)localObject4);
/*      */       }
/*      */       
/* 1041 */       if (null != localObject2)
/*      */       {
/* 1043 */         this.trustedServerNameAE = (this.trustedServerNameAE + ":" + (String)localObject2);
/*      */       }
/*      */       
/* 1046 */       str1 = SQLServerDriverStringProperty.APPLICATION_NAME.toString();
/* 1047 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1048 */       if (str2 != null) {
/* 1049 */         ValidateMaxSQLLoginName(str1, str2);
/*      */       } else {
/* 1051 */         this.activeConnectionProperties.setProperty(str1, "Microsoft JDBC Driver for SQL Server");
/*      */       }
/* 1053 */       str1 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/* 1054 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1055 */       if (str2 == null)
/*      */       {
/* 1057 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
/* 1058 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/*      */       
/* 1061 */       str1 = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString();
/* 1062 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1063 */       if (null == str2)
/*      */       {
/* 1065 */         str2 = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue();
/* 1066 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/* 1068 */       this.columnEncryptionSetting = ColumnEncryptionSetting.valueOfString(str2).toString();
/*      */       
/* 1070 */       str1 = SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString();
/* 1071 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1072 */       if (null != str2)
/*      */       {
/* 1074 */         this.keyStoreAuthentication = KeyStoreAuthentication.valueOfString(str2).toString();
/*      */       }
/*      */       
/* 1077 */       str1 = SQLServerDriverStringProperty.KEY_STORE_SECRET.toString();
/* 1078 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1079 */       if (null != str2)
/*      */       {
/* 1081 */         this.keyStoreSecret = str2;
/*      */       }
/*      */       
/* 1084 */       str1 = SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString();
/* 1085 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1086 */       if (null != str2)
/*      */       {
/* 1088 */         this.keyStoreLocation = str2;
/*      */       }
/*      */       
/* 1091 */       registerKeyStoreProviderOnConnection(this.keyStoreAuthentication, this.keyStoreSecret, this.keyStoreLocation);
/*      */       
/*      */ 
/* 1094 */       str1 = SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString();
/* 1095 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1096 */       if (str2 == null)
/*      */       {
/* 1098 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
/* 1099 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/* 1101 */       this.multiSubnetFailover = booleanPropertyOn(str1, str2);
/*      */       
/* 1103 */       str1 = SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString();
/* 1104 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1105 */       if (str2 == null)
/*      */       {
/* 1107 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue());
/* 1108 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/* 1110 */       this.transparentNetworkIPResolution = booleanPropertyOn(str1, str2);
/*      */       
/* 1112 */       str1 = SQLServerDriverBooleanProperty.ENCRYPT.toString();
/* 1113 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1114 */       if (str2 == null)
/*      */       {
/* 1116 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
/* 1117 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/*      */       
/*      */ 
/* 1121 */       this.requestedEncryptionLevel = (booleanPropertyOn(str1, str2) ? 1 : 0);
/*      */       
/* 1123 */       str1 = SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString();
/* 1124 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1125 */       if (str2 == null)
/*      */       {
/* 1127 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
/* 1128 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/*      */       
/* 1131 */       this.trustServerCertificate = booleanPropertyOn(str1, str2);
/*      */       
/* 1133 */       str1 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
/* 1134 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1135 */       if (str2 == null) str2 = SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue();
/* 1136 */       if ((str2.equalsIgnoreCase("cursor")) || (str2.equalsIgnoreCase("direct")))
/*      */       {
/* 1138 */         this.activeConnectionProperties.setProperty(str1, str2.toLowerCase());
/*      */       }
/*      */       else
/*      */       {
/* 1142 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidselectMethod"));
/* 1143 */         localObject5 = new Object[] { new String(str2) };
/* 1144 */         SQLServerException.makeFromDriverError(this, this, localMessageFormat1.format(localObject5), null, false);
/*      */       }
/*      */       
/* 1147 */       str1 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/* 1148 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1149 */       if (str2 == null) str2 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue();
/* 1150 */       if ((str2.equalsIgnoreCase("full")) || (str2.equalsIgnoreCase("adaptive")))
/*      */       {
/* 1152 */         this.activeConnectionProperties.setProperty(str1, str2.toLowerCase());
/*      */       }
/*      */       else
/*      */       {
/* 1156 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
/* 1157 */         localObject5 = new Object[] { new String(str2) };
/* 1158 */         SQLServerException.makeFromDriverError(this, this, localMessageFormat1.format(localObject5), null, false);
/*      */       }
/*      */       
/*      */ 
/* 1162 */       str1 = SQLServerDriverStringProperty.APPLICATION_INTENT.toString();
/* 1163 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1164 */       if (str2 == null) str2 = SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue();
/* 1165 */       this.applicationIntent = ApplicationIntent.valueOfString(str2);
/* 1166 */       this.activeConnectionProperties.setProperty(str1, this.applicationIntent.toString());
/*      */       
/* 1168 */       str1 = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString();
/* 1169 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1170 */       if (str2 == null)
/*      */       {
/* 1172 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
/* 1173 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       }
/*      */       
/* 1176 */       this.sendTimeAsDatetime = booleanPropertyOn(str1, str2);
/*      */       
/* 1178 */       str1 = SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString();
/* 1179 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1180 */       if ((str2 != null) && 
/* 1181 */         (false == booleanPropertyOn(str1, str2)))
/*      */       {
/* 1183 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invaliddisableStatementPooling"));
/* 1184 */         localObject5 = new Object[] { new String(str2) };
/* 1185 */         SQLServerException.makeFromDriverError(this, this, localMessageFormat1.format(localObject5), null, false);
/*      */       }
/*      */       
/* 1188 */       str1 = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString();
/* 1189 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1190 */       if (str2 != null)
/*      */       {
/* 1192 */         this.integratedSecurity = booleanPropertyOn(str1, str2);
/*      */       }
/*      */       
/*      */ 
/* 1196 */       if (this.integratedSecurity)
/*      */       {
/* 1198 */         str1 = SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString();
/* 1199 */         str2 = this.activeConnectionProperties.getProperty(str1);
/* 1200 */         if (str2 != null)
/*      */         {
/* 1202 */           this.intAuthScheme = AuthenticationScheme.valueOfString(str2);
/*      */         }
/*      */       }
/*      */       
/* 1206 */       str1 = SQLServerDriverStringProperty.AUTHENTICATION.toString();
/* 1207 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1208 */       if (str2 == null)
/*      */       {
/* 1210 */         str2 = SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue();
/*      */       }
/* 1212 */       this.authenticationString = SqlAuthentication.valueOfString(str2).toString();
/*      */       
/* 1214 */       if ((true == this.integratedSecurity) && (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())))
/*      */       {
/* 1216 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetAuthenticationWhenIntegratedSecurityTrue"));
/* 1217 */         throw new SQLServerException(SQLServerException.getErrString("R_SetAuthenticationWhenIntegratedSecurityTrue"), null);
/*      */       }
/*      */       
/* 1220 */       if ((this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString())) && ((!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty()) || (!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1225 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_IntegratedAuthenticationWithUserPassword"));
/* 1226 */         throw new SQLServerException(SQLServerException.getErrString("R_IntegratedAuthenticationWithUserPassword"), null);
/*      */       }
/*      */       
/* 1229 */       if ((this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString())) && ((this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty()) || (this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())))
/*      */       {
/*      */ 
/*      */ 
/* 1233 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_NoUserPasswordForActivePassword"));
/* 1234 */         throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForActivePassword"), null);
/*      */       }
/*      */       
/* 1237 */       if ((this.authenticationString.equalsIgnoreCase(SqlAuthentication.SqlPassword.toString())) && ((this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty()) || (this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())))
/*      */       {
/*      */ 
/*      */ 
/* 1241 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_NoUserPasswordForSqlPassword"));
/* 1242 */         throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForSqlPassword"), null);
/*      */       }
/*      */       
/* 1245 */       str1 = SQLServerDriverStringProperty.ACCESS_TOKEN.toString();
/* 1246 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1247 */       Object localObject6; if (null != str2) {
/*      */         try
/*      */         {
/* 1250 */           this.accessTokenInByte = str2.getBytes("UTF-16LE");
/*      */         } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 1252 */           localObject5 = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */           
/* 1254 */           localObject6 = new Object[] { "UTF-16LE" };
/* 1255 */           throw new SQLServerException(this, ((MessageFormat)localObject5).format(localObject6), null, 0, false);
/*      */         }
/*      */       }
/*      */       
/* 1259 */       if ((null != this.accessTokenInByte) && (0 == this.accessTokenInByte.length))
/*      */       {
/* 1261 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_AccessTokenCannotBeEmpty"));
/* 1262 */         throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenCannotBeEmpty"), null);
/*      */       }
/*      */       
/* 1265 */       if ((true == this.integratedSecurity) && (null != this.accessTokenInByte))
/*      */       {
/* 1267 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetAccesstokenWhenIntegratedSecurityTrue"));
/* 1268 */         throw new SQLServerException(SQLServerException.getErrString("R_SetAccesstokenWhenIntegratedSecurityTrue"), null);
/*      */       }
/*      */       
/* 1271 */       if ((!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) && (null != this.accessTokenInByte))
/*      */       {
/*      */ 
/* 1274 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetBothAuthenticationAndAccessToken"));
/* 1275 */         throw new SQLServerException(SQLServerException.getErrString("R_SetBothAuthenticationAndAccessToken"), null);
/*      */       }
/*      */       
/* 1278 */       if ((null != this.accessTokenInByte) && ((!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty()) || (!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1283 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_AccessTokenWithUserPassword"));
/* 1284 */         throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenWithUserPassword"), null);
/*      */       }
/*      */       
/* 1287 */       if ((!System.getProperty("os.name").toLowerCase().startsWith("windows")) && ((null != this.accessTokenInByte) || (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()))))
/*      */       {
/* 1289 */         throw new SQLServerException(SQLServerException.getErrString("R_FedAuthOnNonWindows"), null);
/*      */       }
/*      */       
/* 1292 */       str1 = SQLServerDriverStringProperty.WORKSTATION_ID.toString();
/* 1293 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1294 */       ValidateMaxSQLLoginName(str1, str2);
/*      */       
/* 1296 */       int k = 0;
/* 1297 */       str1 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/*      */       try
/*      */       {
/* 1300 */         localObject5 = this.activeConnectionProperties.getProperty(str1);
/* 1301 */         if (null != localObject5)
/*      */         {
/* 1303 */           k = new Integer((String)localObject5).intValue();
/*      */           
/* 1305 */           if ((k < 0) || (k > 65535))
/*      */           {
/* 1307 */             localObject6 = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1308 */             localObject7 = new Object[] { Integer.toString(k) };
/* 1309 */             SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject6).format(localObject7), null, false);
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException localNumberFormatException2)
/*      */       {
/* 1315 */         localObject6 = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1316 */         localObject7 = new Object[] { this.activeConnectionProperties.getProperty(str1) };
/* 1317 */         SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject6).format(localObject7), null, false);
/*      */       }
/*      */       
/*      */ 
/* 1321 */       str1 = SQLServerDriverIntProperty.PACKET_SIZE.toString();
/* 1322 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1323 */       if ((null != str2) && (str2.length() > 0))
/*      */       {
/*      */         try
/*      */         {
/* 1327 */           this.requestedPacketSize = Integer.parseInt(str2);
/*      */           
/*      */ 
/* 1330 */           if (-1 == this.requestedPacketSize) {
/* 1331 */             this.requestedPacketSize = 0;
/*      */ 
/*      */           }
/* 1334 */           else if (0 == this.requestedPacketSize) {
/* 1335 */             this.requestedPacketSize = 32767;
/*      */           }
/*      */           
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException3)
/*      */         {
/* 1341 */           this.requestedPacketSize = -1;
/*      */         }
/*      */         
/* 1344 */         if (0 != this.requestedPacketSize)
/*      */         {
/*      */ 
/* 1347 */           if ((this.requestedPacketSize < 512) || (this.requestedPacketSize > 32767))
/*      */           {
/* 1349 */             MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_invalidPacketSize"));
/* 1350 */             localObject6 = new Object[] { str2 };
/* 1351 */             SQLServerException.makeFromDriverError(this, this, localMessageFormat2.format(localObject6), null, false);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1360 */       str1 = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString();
/* 1361 */       if (null == this.activeConnectionProperties.getProperty(str1))
/*      */       {
/* 1363 */         this.sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue();
/*      */       }
/*      */       else
/*      */       {
/* 1367 */         this.sendStringParametersAsUnicode = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
/*      */       }
/*      */       
/* 1370 */       str1 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/* 1371 */       this.lastUpdateCount = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
/* 1372 */       str1 = SQLServerDriverBooleanProperty.XOPEN_STATES.toString();
/* 1373 */       this.xopenStates = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
/*      */       
/* 1375 */       str1 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
/* 1376 */       this.selectMethod = null;
/* 1377 */       if ((this.activeConnectionProperties.getProperty(str1) != null) && (this.activeConnectionProperties.getProperty(str1).length() > 0))
/*      */       {
/*      */ 
/* 1380 */         this.selectMethod = this.activeConnectionProperties.getProperty(str1);
/*      */       }
/*      */       
/* 1383 */       str1 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/* 1384 */       this.responseBuffering = null;
/* 1385 */       if ((this.activeConnectionProperties.getProperty(str1) != null) && (this.activeConnectionProperties.getProperty(str1).length() > 0))
/*      */       {
/*      */ 
/* 1388 */         this.responseBuffering = this.activeConnectionProperties.getProperty(str1);
/*      */       }
/*      */       
/* 1391 */       str1 = SQLServerDriverIntProperty.LOCK_TIMEOUT.toString();
/* 1392 */       int m = SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue();
/* 1393 */       this.nLockTimeout = m;
/* 1394 */       if ((this.activeConnectionProperties.getProperty(str1) != null) && (this.activeConnectionProperties.getProperty(str1).length() > 0))
/*      */       {
/*      */         try
/*      */         {
/*      */ 
/* 1399 */           int n = new Integer(this.activeConnectionProperties.getProperty(str1)).intValue();
/* 1400 */           if (n >= m) {
/* 1401 */             this.nLockTimeout = n;
/*      */           }
/*      */           else {
/* 1404 */             localObject7 = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/* 1405 */             localObject8 = new Object[] { this.activeConnectionProperties.getProperty(str1) };
/* 1406 */             SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject7).format(localObject8), null, false);
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException4)
/*      */         {
/* 1411 */           localObject7 = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/* 1412 */           localObject8 = new Object[] { this.activeConnectionProperties.getProperty(str1) };
/* 1413 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject7).format(localObject8), null, false);
/*      */         }
/*      */       }
/* 1416 */       FailoverInfo localFailoverInfo = null;
/* 1417 */       Object localObject7 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 1418 */       Object localObject8 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/* 1419 */       String str5 = SQLServerDriverStringProperty.FAILOVER_PARTNER.toString();
/* 1420 */       String str6 = this.activeConnectionProperties.getProperty(str5);
/*      */       
/*      */ 
/* 1423 */       if ((this.multiSubnetFailover) && (str6 != null))
/*      */       {
/* 1425 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover"), null, false);
/*      */       }
/*      */       
/*      */ 
/* 1429 */       if ((this.multiSubnetFailover) || (null != str6))
/*      */       {
/* 1431 */         this.transparentNetworkIPResolution = false;
/*      */       }
/*      */       
/*      */ 
/* 1435 */       if ((this.applicationIntent != null) && (this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) && (str6 != null))
/*      */       {
/* 1437 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent"), null, false);
/*      */       }
/*      */       
/*      */ 
/* 1441 */       if (null != this.activeConnectionProperties.getProperty((String)localObject7))
/*      */       {
/*      */ 
/* 1444 */         localFailoverInfo = FailoverMapSingleton.getFailoverInfo(this, this.activeConnectionProperties.getProperty((String)localObject8), this.activeConnectionProperties.getProperty(str3), this.activeConnectionProperties.getProperty((String)localObject7));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1450 */       else if (null != str6) {
/* 1451 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_failoverPartnerWithoutDB"), null, true);
/*      */       }
/*      */       
/* 1454 */       String str7 = null;
/* 1455 */       if (null == localFailoverInfo) {
/* 1456 */         str7 = str6;
/*      */       }
/* 1458 */       long l = System.currentTimeMillis();
/* 1459 */       login(this.activeConnectionProperties.getProperty((String)localObject8), (String)localObject4, k, str7, localFailoverInfo, i, l);
/*      */       
/*      */ 
/*      */ 
/* 1463 */       if ((1 == this.negotiatedEncryptionLevel) || (3 == this.negotiatedEncryptionLevel))
/*      */       {
/*      */ 
/* 1466 */         int i1 = Util.isIBM() ? 8192 : 16384;
/*      */         
/* 1468 */         if (this.tdsPacketSize > i1)
/*      */         {
/* 1470 */           connectionlogger.finer(toString() + " Negotiated tdsPacketSize " + this.tdsPacketSize + " is too large for SSL with JRE " + Util.SYSTEM_JRE + " (max size is " + i1 + ")");
/* 1471 */           MessageFormat localMessageFormat3 = new MessageFormat(SQLServerException.getErrString("R_packetSizeTooBigForSSL"));
/* 1472 */           Object[] arrayOfObject2 = { Integer.toString(i1) };
/* 1473 */           terminate(6, localMessageFormat3.format(arrayOfObject2));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1478 */       this.state = State.Opened;
/*      */       
/*      */ 
/* 1481 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 1483 */         connectionlogger.finer(toString() + " End of connect");
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 1490 */       if (!this.state.equals(State.Opened))
/*      */       {
/*      */ 
/* 1493 */         if (!this.state.equals(State.Closed)) {
/* 1494 */           close();
/*      */         }
/*      */       }
/*      */     }
/* 1498 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void login(String paramString1, String paramString2, int paramInt1, String paramString3, FailoverInfo paramFailoverInfo, int paramInt2, long paramLong)
/*      */     throws SQLServerException
/*      */   {
/* 1512 */     int i = (null == paramString3) && (null == paramFailoverInfo) ? 0 : 1;
/* 1513 */     int j = 100;
/*      */     
/*      */ 
/* 1516 */     boolean bool1 = false;
/* 1517 */     FailoverInfo localFailoverInfo = null;
/*      */     
/* 1519 */     ServerPortPlaceHolder localServerPortPlaceHolder1 = null;
/*      */     
/* 1521 */     ServerPortPlaceHolder localServerPortPlaceHolder2 = null;
/*      */     
/* 1523 */     if (null != paramFailoverInfo)
/*      */     {
/* 1525 */       localFailoverInfo = paramFailoverInfo;
/* 1526 */       bool1 = paramFailoverInfo.getUseFailoverPartner();
/*      */ 
/*      */ 
/*      */     }
/* 1530 */     else if (i != 0)
/*      */     {
/* 1532 */       localFailoverInfo = new FailoverInfo(paramString3, this, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1538 */     boolean bool2 = getMultiSubnetFailover();
/* 1539 */     boolean bool3 = getTransparentNetworkIPResolution();
/*      */     
/*      */ 
/*      */ 
/* 1543 */     if (0 == paramInt2)
/*      */     {
/* 1545 */       paramInt2 = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*      */     }
/* 1547 */     long l3 = paramInt2 * 1000;
/* 1548 */     this.timerExpire = (paramLong + l3);
/*      */     
/*      */     long l1;
/* 1551 */     if ((i != 0) || (bool2) || (bool3))
/*      */     {
/* 1553 */       l1 = (0.08F * (float)l3);
/*      */     }
/*      */     else
/*      */     {
/* 1557 */       l1 = l3;
/*      */     }
/* 1559 */     long l2 = paramLong + l1;
/*      */     
/*      */ 
/* 1562 */     long l4 = paramLong + l3;
/*      */     
/* 1564 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 1566 */       connectionlogger.finer(toString() + " Start time: " + paramLong + " Time out time: " + this.timerExpire + " Timeout Unit Interval: " + l1);
/*      */     }
/*      */     
/*      */ 
/* 1570 */     int k = 0;
/*      */     
/*      */ 
/* 1573 */     int m = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     Object localObject3;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 1584 */       this.clientConnectionId = null;
/* 1585 */       this.state = State.Initialized;
/*      */       
/*      */       try
/*      */       {
/* 1589 */         if ((i != 0) && (bool1))
/*      */         {
/*      */ 
/* 1592 */           if (null == localServerPortPlaceHolder1)
/*      */           {
/*      */ 
/* 1595 */             localServerPortPlaceHolder1 = localFailoverInfo.failoverPermissionCheck(this, this.integratedSecurity);
/*      */           }
/* 1597 */           this.currentConnectPlaceHolder = localServerPortPlaceHolder1;
/*      */         }
/*      */         else
/*      */         {
/* 1601 */           if (this.routingInfo != null)
/*      */           {
/* 1603 */             localServerPortPlaceHolder2 = this.routingInfo;
/* 1604 */             this.routingInfo = null;
/*      */           }
/* 1606 */           else if (null == localServerPortPlaceHolder2)
/*      */           {
/* 1608 */             localServerPortPlaceHolder2 = primaryPermissionCheck(paramString1, paramString2, paramInt1);
/*      */           }
/* 1610 */           this.currentConnectPlaceHolder = localServerPortPlaceHolder2;
/*      */         }
/*      */         
/*      */ 
/* 1614 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/* 1616 */           connectionlogger.fine(toString() + " This attempt server name: " + this.currentConnectPlaceHolder.getServerName() + " port: " + this.currentConnectPlaceHolder.getPortNumber() + " InstanceName: " + this.currentConnectPlaceHolder.getInstanceName() + " useParallel: " + bool2);
/*      */           
/*      */ 
/*      */ 
/* 1620 */           connectionlogger.fine(toString() + " This attempt endtime: " + l2);
/* 1621 */           connectionlogger.fine(toString() + " This attempt No: " + k);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1628 */         connectHelper(this.currentConnectPlaceHolder, TimerRemaining(l2), paramInt2, bool2, bool3, 0 == k, TimerRemaining(l4));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1638 */         if (this.isRoutedInCurrentAttempt)
/*      */         {
/*      */           Object localObject1;
/*      */           
/* 1642 */           if (i != 0)
/*      */           {
/* 1644 */             localObject1 = SQLServerException.getErrString("R_invalidRoutingInfo");
/* 1645 */             terminate(6, (String)localObject1);
/*      */           }
/*      */           
/* 1648 */           m++;
/*      */           
/* 1650 */           if (m > 1)
/*      */           {
/* 1652 */             localObject1 = SQLServerException.getErrString("R_multipleRedirections");
/* 1653 */             terminate(6, (String)localObject1);
/*      */           }
/*      */           
/*      */ 
/* 1657 */           if (this.tdsChannel != null) {
/* 1658 */             this.tdsChannel.close();
/*      */           }
/* 1660 */           initResettableValues();
/*      */           
/*      */ 
/*      */ 
/* 1664 */           resetNonRoutingEnvchangeValues();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1670 */           k++;
/*      */           
/*      */ 
/* 1673 */           this.isRoutedInCurrentAttempt = false;
/*      */           
/*      */ 
/* 1676 */           bool2 = false;
/* 1677 */           bool3 = false;
/*      */           
/*      */ 
/* 1680 */           l2 = this.timerExpire;
/*      */           
/*      */ 
/* 1683 */           if (timerHasExpired(this.timerExpire))
/*      */           {
/* 1685 */             localObject1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 1686 */             Object[] arrayOfObject = { this.currentConnectPlaceHolder.getServerName(), Integer.toString(this.currentConnectPlaceHolder.getPortNumber()), SQLServerException.getErrString("R_timedOutBeforeRouting") };
/* 1687 */             localObject3 = ((MessageFormat)localObject1).format(arrayOfObject);
/* 1688 */             terminate(6, (String)localObject3);
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */           break;
/*      */         }
/*      */       }
/*      */       catch (SQLServerException localSQLServerException)
/*      */       {
/* 1700 */         if ((18456 == localSQLServerException.getErrorCode()) || (18488 == localSQLServerException.getErrorCode()) || (4 == localSQLServerException.getDriverErrorCode()) || (5 == localSQLServerException.getDriverErrorCode()) || (7 == localSQLServerException.getDriverErrorCode()) || (6 == localSQLServerException.getDriverErrorCode()) || (timerHasExpired(this.timerExpire)) || ((this.state.equals(State.Connected)) && (i == 0)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1713 */           close();
/* 1714 */           throw localSQLServerException;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1720 */         if (null != this.tdsChannel) {
/* 1721 */           this.tdsChannel.close();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1726 */         if ((i == 0) || (1 == k % 2))
/*      */         {
/*      */ 
/*      */ 
/* 1730 */           long l5 = TimerRemaining(this.timerExpire);
/* 1731 */           if (l5 <= j)
/*      */           {
/* 1733 */             throw localSQLServerException;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1743 */       if ((i == 0) || (1 == k % 2))
/*      */       {
/* 1745 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/* 1747 */           connectionlogger.fine(toString() + " sleeping milisec: " + j);
/*      */         }
/*      */         try
/*      */         {
/* 1751 */           Thread.sleep(j);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException) {}
/*      */         
/*      */ 
/* 1756 */         j = j < 500 ? j * 2 : 1000;
/*      */       }
/*      */       
/*      */ 
/* 1760 */       k++;
/*      */       
/* 1762 */       if ((bool2) || (bool3))
/*      */       {
/* 1764 */         l2 = System.currentTimeMillis() + l1 * (k + 1);
/*      */       }
/* 1766 */       else if (i != 0)
/*      */       {
/* 1768 */         l2 = System.currentTimeMillis() + l1 * (k / 2 + 1);
/*      */       }
/*      */       else {
/* 1771 */         l2 = this.timerExpire;
/*      */       }
/*      */       
/* 1774 */       if (l2 > this.timerExpire)
/*      */       {
/* 1776 */         l2 = this.timerExpire;
/*      */       }
/*      */       
/* 1779 */       if (i != 0) {
/* 1780 */         bool1 = !bool1;
/*      */       }
/*      */     }
/*      */     String str;
/*      */     Object localObject2;
/* 1785 */     if ((bool1) && (null == this.failoverPartnerServerProvided))
/*      */     {
/* 1787 */       str = this.currentConnectPlaceHolder.getServerName();
/* 1788 */       if (null != localServerPortPlaceHolder1.getInstanceName())
/*      */       {
/* 1790 */         str = str + "\\";
/* 1791 */         str = str + localServerPortPlaceHolder1.getInstanceName();
/*      */       }
/* 1793 */       localObject2 = new MessageFormat(SQLServerException.getErrString("R_invalidPartnerConfiguration"));
/* 1794 */       localObject3 = new Object[] { new String(this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString())), str };
/*      */       
/* 1796 */       terminate(6, ((MessageFormat)localObject2).format(localObject3));
/*      */     }
/*      */     
/* 1799 */     if (null != this.failoverPartnerServerProvided)
/*      */     {
/*      */ 
/* 1802 */       if (this.multiSubnetFailover)
/*      */       {
/* 1804 */         str = SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover");
/* 1805 */         terminate(6, str);
/*      */       }
/*      */       
/*      */ 
/* 1809 */       if ((this.applicationIntent != null) && (this.applicationIntent.equals(ApplicationIntent.READ_ONLY)))
/*      */       {
/* 1811 */         str = SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent");
/* 1812 */         terminate(6, str);
/*      */       }
/*      */       
/*      */ 
/* 1816 */       if (null == localFailoverInfo) {
/* 1817 */         localFailoverInfo = new FailoverInfo(this.failoverPartnerServerProvided, this, false);
/*      */       }
/* 1819 */       if (null != paramFailoverInfo)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1824 */         paramFailoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
/*      */       }
/*      */       else
/*      */       {
/* 1828 */         str = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 1829 */         localObject2 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/* 1830 */         localObject3 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*      */         
/* 1832 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/* 1834 */           connectionlogger.fine(toString() + " adding new failover info server: " + this.activeConnectionProperties.getProperty((String)localObject3) + " instance: " + this.activeConnectionProperties.getProperty((String)localObject2) + " database: " + this.activeConnectionProperties.getProperty(str) + " server provided failover: " + this.failoverPartnerServerProvided);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1840 */         localFailoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
/* 1841 */         FailoverMapSingleton.putFailoverInfo(this, paramString1, this.activeConnectionProperties.getProperty((String)localObject2), this.activeConnectionProperties.getProperty(str), localFailoverInfo, bool1, this.failoverPartnerServerProvided);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetNonRoutingEnvchangeValues()
/*      */   {
/* 1851 */     this.tdsPacketSize = 4096;
/* 1852 */     this.databaseCollation = null;
/* 1853 */     this.rolledBackTransaction = false;
/* 1854 */     Arrays.fill(getTransactionDescriptor(), (byte)0);
/* 1855 */     this.sCatalog = this.originalCatalog;
/* 1856 */     this.failoverPartnerServerProvided = null;
/*      */   }
/*      */   
/* 1859 */   static final int DEFAULTPORT = SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   ServerPortPlaceHolder primaryPermissionCheck(String paramString1, String paramString2, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1867 */     if (0 == paramInt)
/*      */     {
/* 1869 */       if (null != paramString2)
/*      */       {
/* 1871 */         String str = getInstancePort(paramString1, paramString2);
/* 1872 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 1873 */           connectionlogger.fine(toString() + " SQL Server port returned by SQL Browser: " + str);
/*      */         }
/*      */         try {
/* 1876 */           if (null != str)
/*      */           {
/* 1878 */             paramInt = new Integer(str).intValue();
/*      */             
/* 1880 */             if ((paramInt < 0) || (paramInt > 65535))
/*      */             {
/* 1882 */               MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1883 */               localObject = new Object[] { Integer.toString(paramInt) };
/* 1884 */               SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(localObject), null, false);
/*      */             }
/*      */           }
/*      */           else {
/* 1888 */             paramInt = DEFAULTPORT;
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException)
/*      */         {
/* 1893 */           Object localObject = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1894 */           Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 1895 */           SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject).format(arrayOfObject), null, false);
/*      */         }
/*      */       }
/*      */       else {
/* 1899 */         paramInt = DEFAULTPORT;
/*      */       }
/*      */     }
/*      */     
/* 1903 */     this.activeConnectionProperties.setProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString(), String.valueOf(paramInt));
/* 1904 */     return new ServerPortPlaceHolder(paramString1, paramInt, paramString2, this.integratedSecurity);
/*      */   }
/*      */   
/*      */   static boolean timerHasExpired(long paramLong)
/*      */   {
/* 1909 */     boolean bool = System.currentTimeMillis() > paramLong;
/* 1910 */     return bool;
/*      */   }
/*      */   
/*      */   static int TimerRemaining(long paramLong)
/*      */   {
/* 1915 */     long l1 = System.currentTimeMillis();
/* 1916 */     long l2 = paramLong - l1;
/*      */     
/* 1918 */     if (l2 > 2147483647L) {
/* 1919 */       l2 = 2147483647L;
/*      */     }
/*      */     
/* 1922 */     if (l2 <= 0L)
/* 1923 */       l2 = 1L;
/* 1924 */     return (int)l2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void connectHelper(ServerPortPlaceHolder paramServerPortPlaceHolder, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3)
/*      */     throws SQLServerException
/*      */   {
/* 1952 */     if (connectionlogger.isLoggable(Level.FINE))
/*      */     {
/* 1954 */       connectionlogger.fine(toString() + " Connecting with server: " + paramServerPortPlaceHolder.getServerName() + " port: " + paramServerPortPlaceHolder.getPortNumber() + " Timeout slice: " + paramInt1 + " Timeout Full: " + paramInt2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1959 */     this.tdsChannel = new TDSChannel(this);
/* 1960 */     if (0 == paramInt2) {
/* 1961 */       this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), 0, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
/*      */     } else {
/* 1963 */       this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), paramInt1, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
/*      */     }
/*      */     
/* 1966 */     setState(State.Connected);
/*      */     
/*      */ 
/* 1969 */     this.clientConnectionId = UUID.randomUUID();
/* 1970 */     assert (null != this.clientConnectionId);
/*      */     
/*      */ 
/* 1973 */     Prelogin(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());
/*      */     
/*      */ 
/* 1976 */     if (2 != this.negotiatedEncryptionLevel) {
/* 1977 */       this.tdsChannel.enableSSL(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());
/*      */     }
/*      */     
/*      */ 
/* 1981 */     executeCommand(new LogonCommand());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void Prelogin(String paramString, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 1990 */     if ((!this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) || (null != this.accessTokenInByte))
/*      */     {
/*      */ 
/* 1993 */       this.fedAuthRequiredByUser = true;
/*      */     }
/*      */     
/*      */     int i;
/*      */     
/*      */     int j;
/* 1999 */     if (this.fedAuthRequiredByUser)
/*      */     {
/* 2001 */       i = 73;
/* 2002 */       this.requestedEncryptionLevel = 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2007 */       j = 5;
/*      */     }
/*      */     else
/*      */     {
/* 2011 */       i = 67;
/* 2012 */       j = 0;
/*      */     }
/*      */     
/* 2015 */     byte[] arrayOfByte1 = new byte[i];
/*      */     
/* 2017 */     int k = 0;
/*      */     
/* 2019 */     byte[] arrayOfByte2 = { 18, 1, 0, i, 0, 0, 0, 0 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2029 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte1, k, arrayOfByte2.length);
/* 2030 */     k += arrayOfByte2.length;
/*      */     
/* 2032 */     byte[] arrayOfByte3 = { 0, 0, (byte)(16 + j), 0, 6, 1, 0, (byte)(22 + j), 0, 1, 5, 0, (byte)(23 + j), 0, 36 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2038 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte1, k, arrayOfByte3.length);
/* 2039 */     k += arrayOfByte3.length;
/*      */     
/* 2041 */     if (this.fedAuthRequiredByUser) {
/* 2042 */       arrayOfByte4 = new byte[] { 6, 0, 64, 0, 1 };
/*      */       
/*      */ 
/* 2045 */       System.arraycopy(arrayOfByte4, 0, arrayOfByte1, k, arrayOfByte4.length);
/* 2046 */       k += arrayOfByte4.length;
/*      */     }
/*      */     
/* 2049 */     arrayOfByte1[k] = -1;
/* 2050 */     k++;
/*      */     
/*      */ 
/* 2053 */     byte[] arrayOfByte4 = { 0, 0, 0, 0, 0, 0, this.requestedEncryptionLevel, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2065 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte1, k, arrayOfByte4.length);
/* 2066 */     k += arrayOfByte4.length;
/*      */     
/*      */ 
/*      */ 
/* 2070 */     if (this.fedAuthRequiredByUser) {
/* 2071 */       arrayOfByte1[k] = 1;
/* 2072 */       k += 1;
/*      */     }
/*      */     
/* 2075 */     byte[] arrayOfByte5 = new byte['က'];
/* 2076 */     String str = " Prelogin error: host " + paramString + " port " + paramInt;
/*      */     
/* 2078 */     ActivityId localActivityId = ActivityCorrelator.getNext();
/* 2079 */     byte[] arrayOfByte6 = Util.asGuidByteArray(localActivityId.getId());
/* 2080 */     byte[] arrayOfByte7 = Util.asGuidByteArray(this.clientConnectionId);
/*      */     
/*      */     int m;
/*      */     
/* 2084 */     if (this.fedAuthRequiredByUser) {
/* 2085 */       m = arrayOfByte1.length - 36 - 1;
/*      */     }
/*      */     else
/*      */     {
/* 2089 */       m = arrayOfByte1.length - 36;
/*      */     }
/*      */     
/*      */ 
/* 2093 */     System.arraycopy(arrayOfByte7, 0, arrayOfByte1, m, arrayOfByte7.length);
/* 2094 */     m += arrayOfByte7.length;
/*      */     
/*      */ 
/* 2097 */     System.arraycopy(arrayOfByte6, 0, arrayOfByte1, m, arrayOfByte6.length);
/* 2098 */     m += arrayOfByte6.length;
/*      */     
/* 2100 */     long l = localActivityId.getSequence();
/* 2101 */     Util.writeInt((int)l, arrayOfByte1, m);
/* 2102 */     m += 4;
/*      */     
/* 2104 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 2106 */       connectionlogger.finer(toString() + " Requesting encryption level:" + TDS.getEncryptionLevel(this.requestedEncryptionLevel));
/* 2107 */       connectionlogger.finer(toString() + " ActivityId " + localActivityId.toString());
/*      */     }
/*      */     
/*      */ 
/* 2111 */     if (this.tdsChannel.isLoggingPackets()) {
/* 2112 */       this.tdsChannel.logPacket(arrayOfByte1, 0, arrayOfByte1.length, toString() + " Prelogin request");
/*      */     }
/*      */     try
/*      */     {
/* 2116 */       this.tdsChannel.write(arrayOfByte1, 0, arrayOfByte1.length);
/* 2117 */       this.tdsChannel.flush();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException1)
/*      */     {
/* 2121 */       connectionlogger.warning(toString() + str + " Error sending prelogin request: " + localSQLServerException1.getMessage());
/* 2122 */       throw localSQLServerException1;
/*      */     }
/*      */     
/* 2125 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*      */     
/*      */ 
/* 2128 */     int n = arrayOfByte5.length;
/* 2129 */     int i1 = 0;
/* 2130 */     int i2 = 0;
/* 2131 */     while (i1 < n)
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/* 2137 */         i3 = this.tdsChannel.read(arrayOfByte5, i1, n - i1);
/*      */       }
/*      */       catch (SQLServerException localSQLServerException2)
/*      */       {
/* 2141 */         connectionlogger.warning(toString() + str + " Error reading prelogin response: " + localSQLServerException2.getMessage());
/* 2142 */         throw localSQLServerException2;
/*      */       }
/*      */       
/*      */ 
/*      */       MessageFormat localMessageFormat1;
/*      */       
/*      */       Object[] arrayOfObject1;
/*      */       
/* 2150 */       if (-1 == i3)
/*      */       {
/* 2152 */         connectionlogger.warning(toString() + str + " Unexpected end of prelogin response after " + i1 + " bytes read");
/* 2153 */         localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2154 */         arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2155 */         terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */       }
/*      */       
/*      */ 
/* 2159 */       assert (i3 >= 0);
/* 2160 */       assert (i3 <= n - i1);
/*      */       
/* 2162 */       if (this.tdsChannel.isLoggingPackets()) {
/* 2163 */         this.tdsChannel.logPacket(arrayOfByte5, i1, i3, toString() + " Prelogin response");
/*      */       }
/* 2165 */       i1 += i3;
/*      */       
/*      */ 
/*      */ 
/* 2169 */       if ((i2 == 0) && (i1 >= 8))
/*      */       {
/*      */ 
/* 2172 */         if (4 != arrayOfByte5[0])
/*      */         {
/* 2174 */           connectionlogger.warning(toString() + str + " Unexpected response type:" + arrayOfByte5[0]);
/* 2175 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2176 */           arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2177 */           terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2183 */         if (1 != (0x1 & arrayOfByte5[1]))
/*      */         {
/* 2185 */           connectionlogger.warning(toString() + str + " Unexpected response status:" + arrayOfByte5[1]);
/* 2186 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2187 */           arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2188 */           terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */         }
/*      */         
/*      */ 
/* 2192 */         n = Util.readUnsignedShortBigEndian(arrayOfByte5, 2);
/* 2193 */         assert (n >= 0);
/*      */         
/* 2195 */         if (n >= arrayOfByte5.length)
/*      */         {
/* 2197 */           connectionlogger.warning(toString() + str + " Response length:" + n + " is greater than allowed length:" + arrayOfByte5.length);
/* 2198 */           localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2199 */           arrayOfObject1 = new Object[] { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2200 */           terminate(3, localMessageFormat1.format(arrayOfObject1));
/*      */         }
/*      */         
/* 2203 */         i2 = 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2209 */     int i3 = 0;
/* 2210 */     this.negotiatedEncryptionLevel = -1;
/*      */     
/* 2212 */     int i4 = 8;
/*      */     
/*      */     for (;;)
/*      */     {
/* 2216 */       if (i4 >= n)
/*      */       {
/* 2218 */         connectionlogger.warning(toString() + " Option token not found");
/* 2219 */         throwInvalidTDS();
/*      */       }
/* 2221 */       int i5 = arrayOfByte5[(i4++)];
/*      */       
/*      */ 
/* 2224 */       if (-1 == i5) {
/*      */         break;
/*      */       }
/*      */       
/* 2228 */       if (i4 + 4 >= n)
/*      */       {
/* 2230 */         connectionlogger.warning(toString() + " Offset/Length not found for option:" + i5);
/* 2231 */         throwInvalidTDS();
/*      */       }
/*      */       
/* 2234 */       int i6 = Util.readUnsignedShortBigEndian(arrayOfByte5, i4) + 8;
/* 2235 */       i4 += 2;
/* 2236 */       assert (i6 >= 0);
/*      */       
/* 2238 */       int i7 = Util.readUnsignedShortBigEndian(arrayOfByte5, i4);
/* 2239 */       i4 += 2;
/* 2240 */       assert (i7 >= 0);
/*      */       
/* 2242 */       if (i6 + i7 > n)
/*      */       {
/* 2244 */         connectionlogger.warning(toString() + " Offset:" + i6 + " and length:" + i7 + " exceed response length:" + n);
/* 2245 */         throwInvalidTDS();
/*      */       }
/*      */       MessageFormat localMessageFormat2;
/* 2248 */       switch (i5)
/*      */       {
/*      */       case 0: 
/* 2251 */         if (i3 != 0)
/*      */         {
/* 2253 */           connectionlogger.warning(toString() + " Version option already received");
/* 2254 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 2257 */         if (6 != i7)
/*      */         {
/* 2259 */           connectionlogger.warning(toString() + " Version option length:" + i7 + " is incorrect.  Correct value is 6.");
/* 2260 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 2263 */         this.serverMajorVersion = arrayOfByte5[i6];
/* 2264 */         if (this.serverMajorVersion < 9)
/*      */         {
/* 2266 */           connectionlogger.warning(toString() + " Server major version:" + this.serverMajorVersion + " is not supported by this driver.");
/* 2267 */           localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_unsupportedServerVersion"));
/* 2268 */           Object[] arrayOfObject2 = { Integer.toString(arrayOfByte5[i6]) };
/* 2269 */           terminate(6, localMessageFormat2.format(arrayOfObject2));
/*      */         }
/*      */         
/* 2272 */         if (connectionlogger.isLoggable(Level.FINE)) {
/* 2273 */           connectionlogger.fine(toString() + " Server returned major version:" + arrayOfByte5[i6]);
/*      */         }
/* 2275 */         i3 = 1;
/* 2276 */         break;
/*      */       
/*      */       case 1: 
/* 2279 */         if (-1 != this.negotiatedEncryptionLevel)
/*      */         {
/* 2281 */           connectionlogger.warning(toString() + " Encryption option already received");
/* 2282 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 2285 */         if (1 != i7)
/*      */         {
/* 2287 */           connectionlogger.warning(toString() + " Encryption option length:" + i7 + " is incorrect.  Correct value is 1.");
/* 2288 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 2291 */         this.negotiatedEncryptionLevel = arrayOfByte5[i6];
/*      */         
/*      */ 
/* 2294 */         if ((0 != this.negotiatedEncryptionLevel) && (1 != this.negotiatedEncryptionLevel) && (3 != this.negotiatedEncryptionLevel) && (2 != this.negotiatedEncryptionLevel))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2299 */           connectionlogger.warning(toString() + " Server returned " + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
/* 2300 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 2303 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 2304 */           connectionlogger.finer(toString() + " Negotiated encryption level:" + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
/*      */         }
/*      */         
/* 2307 */         if ((1 == this.requestedEncryptionLevel) && (1 != this.negotiatedEncryptionLevel) && (3 != this.negotiatedEncryptionLevel))
/*      */         {
/*      */ 
/*      */ 
/* 2311 */           terminate(5, SQLServerException.getErrString("R_sslRequiredNoServerSupport"));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2316 */         if ((2 == this.requestedEncryptionLevel) && (2 != this.negotiatedEncryptionLevel))
/*      */         {
/*      */ 
/*      */ 
/* 2320 */           if (3 == this.negotiatedEncryptionLevel) {
/* 2321 */             terminate(5, SQLServerException.getErrString("R_sslRequiredByServer"));
/*      */           }
/* 2323 */           connectionlogger.warning(toString() + " Client requested encryption level: " + TDS.getEncryptionLevel(this.requestedEncryptionLevel) + " Server returned unexpected encryption level: " + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
/*      */           
/*      */ 
/* 2326 */           throwInvalidTDS();
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 6: 
/* 2332 */         if ((0 != arrayOfByte5[i6]) && (1 != arrayOfByte5[i6])) {
/* 2333 */           connectionlogger.severe(toString() + " Server sent an unexpected value for FedAuthRequired PreLogin Option. Value was " + arrayOfByte5[i6]);
/* 2334 */           localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_FedAuthRequiredPreLoginResponseInvalidValue"));
/* 2335 */           throw new SQLServerException(localMessageFormat2.format(new Object[] { Byte.valueOf(arrayOfByte5[i6]) }), null);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2341 */         if (((null != this.authenticationString) && (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()))) || (null != this.accessTokenInByte))
/*      */         {
/*      */ 
/*      */ 
/* 2345 */           this.fedAuthRequiredPreLoginResponse = (arrayOfByte5[i6] == 1);
/*      */         }
/*      */         
/*      */         break;
/*      */       default: 
/* 2350 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 2351 */           connectionlogger.finer(toString() + " Ignoring prelogin response option:" + i5);
/*      */         }
/*      */         break;
/*      */       }
/*      */     }
/* 2356 */     if ((i3 == 0) || (-1 == this.negotiatedEncryptionLevel))
/*      */     {
/* 2358 */       connectionlogger.warning(toString() + " Prelogin response is missing version and/or encryption option.");
/* 2359 */       throwInvalidTDS();
/*      */     }
/*      */   }
/*      */   
/*      */   final void throwInvalidTDS() throws SQLServerException
/*      */   {
/* 2365 */     terminate(4, SQLServerException.getErrString("R_invalidTDS"));
/*      */   }
/*      */   
/*      */   final void throwInvalidTDSToken(String paramString) throws SQLServerException
/*      */   {
/* 2370 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unexpectedToken"));
/* 2371 */     Object[] arrayOfObject = { paramString };
/* 2372 */     String str = SQLServerException.getErrString("R_invalidTDS") + localMessageFormat.format(arrayOfObject);
/* 2373 */     terminate(4, str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void terminate(int paramInt, String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 2384 */     terminate(paramInt, paramString, null);
/*      */   }
/*      */   
/*      */   final void terminate(int paramInt, String paramString, Throwable paramThrowable) throws SQLServerException
/*      */   {
/* 2389 */     String str = this.state.equals(State.Opened) ? "08006" : "08001";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2394 */     if (!this.xopenStates) {
/* 2395 */       str = SQLServerException.mapFromXopen(str);
/*      */     }
/* 2397 */     SQLServerException localSQLServerException = new SQLServerException(this, SQLServerException.checkAndAppendClientConnId(paramString, this), str, 0, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2405 */     if (null != paramThrowable) {
/* 2406 */       localSQLServerException.initCause(paramThrowable);
/*      */     }
/* 2408 */     localSQLServerException.setDriverErrorCode(paramInt);
/*      */     
/* 2410 */     notifyPooledConnection(localSQLServerException);
/*      */     
/* 2412 */     close();
/*      */     
/* 2414 */     throw localSQLServerException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2422 */   private final Object schedulerLock = new Object();
/*      */   volatile SQLWarning sqlWarnings;
/*      */   
/* 2425 */   boolean executeCommand(TDSCommand paramTDSCommand) throws SQLServerException { synchronized (this.schedulerLock)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2432 */       if (null != this.currentCommand)
/*      */       {
/* 2434 */         this.currentCommand.detach();
/* 2435 */         this.currentCommand = null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2442 */       boolean bool = false;
/*      */       try
/*      */       {
/* 2445 */         bool = paramTDSCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(paramTDSCommand));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2458 */         if ((!bool) && (!isSessionUnAvailable())) {
/* 2459 */           this.currentCommand = paramTDSCommand;
/*      */         }
/*      */       }
/* 2462 */       return bool;
/*      */     }
/*      */   }
/*      */   
/*      */   void resetCurrentCommand() throws SQLServerException
/*      */   {
/* 2468 */     if (null != this.currentCommand)
/*      */     {
/* 2470 */       this.currentCommand.detach();
/* 2471 */       this.currentCommand = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void connectionCommand(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/* 2500 */     executeCommand(new UninterruptableTDSCommand(paramString1)
/*      */     {
/*      */       final String sql;
/*      */       
/*      */       final boolean doExecute()
/*      */         throws SQLServerException
/*      */       {
/* 2494 */         startRequest((byte)1).writeString(this.sql);
/* 2495 */         TDSParser.parse(startResponse(), getLogContext());
/* 2496 */         return true;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sqlStatementToInitialize()
/*      */   {
/* 2508 */     String str = null;
/* 2509 */     if (this.nLockTimeout > -1)
/* 2510 */       str = " set lock_timeout " + this.nLockTimeout;
/* 2511 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setCatalogName(String paramString)
/*      */   {
/* 2521 */     if (paramString != null)
/*      */     {
/* 2523 */       if (paramString.length() > 0)
/*      */       {
/* 2525 */         this.sCatalog = paramString;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   String sqlStatementToSetTransactionIsolationLevel()
/*      */     throws SQLServerException
/*      */   {
/* 2535 */     String str = "set transaction isolation level ";
/*      */     
/* 2537 */     switch (this.transactionIsolationLevel) {
/*      */     case 1: 
/* 2539 */       str = str + " read uncommitted ";
/* 2540 */       break;
/*      */     
/*      */     case 2: 
/* 2543 */       str = str + " read committed ";
/* 2544 */       break;
/*      */     
/*      */     case 4: 
/* 2547 */       str = str + " repeatable read ";
/* 2548 */       break;
/*      */     
/*      */     case 8: 
/* 2551 */       str = str + " serializable ";
/* 2552 */       break;
/*      */     
/*      */ 
/*      */     case 4096: 
/* 2556 */       str = str + " snapshot ";
/* 2557 */       break;
/*      */     
/*      */     default: 
/* 2560 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTransactionLevel"));
/* 2561 */       Object[] arrayOfObject = { Integer.toString(this.transactionIsolationLevel) };
/* 2562 */       SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(arrayOfObject), null, false);
/*      */     }
/*      */     
/*      */     
/* 2566 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String sqlStatementToSetCommit(boolean paramBoolean)
/*      */   {
/* 2575 */     return true == paramBoolean ? "set implicit_transactions off " : "set implicit_transactions on ";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Statement createStatement()
/*      */     throws SQLServerException
/*      */   {
/* 2583 */     loggerExternal.entering(getClassNameLogging(), "createStatement");
/* 2584 */     Statement localStatement = createStatement(1003, 1007);
/* 2585 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", localStatement);
/* 2586 */     return localStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString) throws SQLServerException
/*      */   {
/* 2591 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", paramString);
/* 2592 */     PreparedStatement localPreparedStatement = prepareStatement(paramString, 1003, 1007);
/* 2593 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localPreparedStatement);
/* 2594 */     return localPreparedStatement;
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String paramString) throws SQLServerException
/*      */   {
/* 2599 */     loggerExternal.entering(getClassNameLogging(), "prepareCall", paramString);
/* 2600 */     CallableStatement localCallableStatement = prepareCall(paramString, 1003, 1007);
/* 2601 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", localCallableStatement);
/* 2602 */     return localCallableStatement;
/*      */   }
/*      */   
/*      */   public String nativeSQL(String paramString) throws SQLServerException
/*      */   {
/* 2607 */     loggerExternal.entering(getClassNameLogging(), "nativeSQL", paramString);
/* 2608 */     checkClosed();
/* 2609 */     loggerExternal.exiting(getClassNameLogging(), "nativeSQL", paramString);
/* 2610 */     return paramString;
/*      */   }
/*      */   
/*      */   public void setAutoCommit(boolean paramBoolean) throws SQLServerException
/*      */   {
/* 2615 */     if (loggerExternal.isLoggable(Level.FINER))
/*      */     {
/* 2617 */       loggerExternal.entering(getClassNameLogging(), "setAutoCommit", Boolean.valueOf(paramBoolean));
/* 2618 */       if (Util.IsActivityTraceOn())
/* 2619 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 2621 */     String str = "";
/* 2622 */     checkClosed();
/*      */     
/* 2624 */     if (paramBoolean == this.databaseAutoCommitMode) {
/* 2625 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2629 */     if (paramBoolean == true) {
/* 2630 */       str = "IF @@TRANCOUNT > 0 COMMIT TRAN ";
/*      */     }
/* 2632 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 2634 */       connectionlogger.finer(toString() + " Autocommitmode current :" + this.databaseAutoCommitMode + " new: " + paramBoolean);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2639 */     this.rolledBackTransaction = false;
/* 2640 */     connectionCommand(str + sqlStatementToSetCommit(paramBoolean), "setAutoCommit");
/* 2641 */     this.databaseAutoCommitMode = paramBoolean;
/* 2642 */     loggerExternal.exiting(getClassNameLogging(), "setAutoCommit");
/*      */   }
/*      */   
/*      */   public boolean getAutoCommit() throws SQLServerException
/*      */   {
/* 2647 */     loggerExternal.entering(getClassNameLogging(), "getAutoCommit");
/* 2648 */     checkClosed();
/* 2649 */     boolean bool = (!this.inXATransaction) && (this.databaseAutoCommitMode);
/* 2650 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2651 */       loggerExternal.exiting(getClassNameLogging(), "getAutoCommit", Boolean.valueOf(bool));
/* 2652 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */   final byte[] getTransactionDescriptor()
/*      */   {
/* 2658 */     return this.transactionDescriptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void commit()
/*      */     throws SQLServerException
/*      */   {
/* 2669 */     loggerExternal.entering(getClassNameLogging(), "commit");
/* 2670 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2672 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/* 2675 */     checkClosed();
/* 2676 */     if (!this.databaseAutoCommitMode)
/* 2677 */       connectionCommand("IF @@TRANCOUNT > 0 COMMIT TRAN", "Connection.commit");
/* 2678 */     loggerExternal.exiting(getClassNameLogging(), "commit");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLServerException
/*      */   {
/* 2688 */     loggerExternal.entering(getClassNameLogging(), "rollback");
/* 2689 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2691 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 2693 */     checkClosed();
/*      */     
/* 2695 */     if (this.databaseAutoCommitMode)
/*      */     {
/* 2697 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), null, true);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 2703 */       connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "Connection.rollback"); }
/* 2704 */     loggerExternal.exiting(getClassNameLogging(), "rollback");
/*      */   }
/*      */   
/*      */   public void abort(Executor paramExecutor) throws SQLException
/*      */   {
/* 2709 */     loggerExternal.entering(getClassNameLogging(), "abort", paramExecutor);
/*      */     
/* 2711 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/*      */ 
/* 2714 */     if (isClosed())
/*      */       return;
/*      */     Object localObject2;
/* 2717 */     if (null == paramExecutor)
/*      */     {
/* 2719 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2720 */       localObject2 = new Object[] { "executor" };
/* 2721 */       SQLServerException.makeFromDriverError(null, null, ((MessageFormat)localObject1).format(localObject2), null, false);
/*      */     }
/*      */     
/*      */ 
/* 2725 */     Object localObject1 = System.getSecurityManager();
/* 2726 */     if (localObject1 != null)
/*      */     {
/*      */       try
/*      */       {
/* 2730 */         localObject2 = new SQLPermission("callAbort");
/* 2731 */         ((SecurityManager)localObject1).checkPermission((java.security.Permission)localObject2);
/*      */       }
/*      */       catch (SecurityException localSecurityException)
/*      */       {
/* 2735 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_permissionDenied"));
/* 2736 */         Object[] arrayOfObject = { "callAbort" };
/* 2737 */         SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(arrayOfObject), null, true);
/*      */       }
/*      */     }
/*      */     
/* 2741 */     setState(State.Closed);
/*      */     
/* 2743 */     paramExecutor.execute(new Runnable()
/*      */     {
/*      */       public void run() {
/* 2746 */         if (null != SQLServerConnection.this.tdsChannel)
/*      */         {
/* 2748 */           SQLServerConnection.this.tdsChannel.close();
/*      */         }
/*      */         
/*      */       }
/* 2752 */     });
/* 2753 */     loggerExternal.exiting(getClassNameLogging(), "abort");
/*      */   }
/*      */   
/*      */   public void close() throws SQLServerException
/*      */   {
/* 2758 */     loggerExternal.entering(getClassNameLogging(), "close");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2763 */     setState(State.Closed);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2768 */     if (null != this.tdsChannel)
/*      */     {
/* 2770 */       this.tdsChannel.close();
/*      */     }
/* 2772 */     loggerExternal.exiting(getClassNameLogging(), "close");
/*      */   }
/*      */   
/*      */ 
/*      */   final void poolCloseEventNotify()
/*      */     throws SQLServerException
/*      */   {
/* 2779 */     if ((this.state.equals(State.Opened)) && (null != this.pooledConnectionParent))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2789 */       if ((!this.databaseAutoCommitMode) && (!(this.pooledConnectionParent instanceof javax.sql.XAConnection)))
/*      */       {
/* 2791 */         connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "close connection");
/*      */       }
/*      */       
/* 2794 */       notifyPooledConnection(null);
/* 2795 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 2797 */         connectionlogger.finer(toString() + " Connection closed and returned to connection pool");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isClosed()
/*      */     throws SQLServerException
/*      */   {
/* 2806 */     loggerExternal.entering(getClassNameLogging(), "isClosed");
/* 2807 */     loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(isSessionUnAvailable()));
/* 2808 */     return isSessionUnAvailable();
/*      */   }
/*      */   
/*      */   public DatabaseMetaData getMetaData() throws SQLServerException
/*      */   {
/* 2813 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/* 2814 */     checkClosed();
/* 2815 */     if (this.databaseMetaData == null)
/*      */     {
/* 2817 */       this.databaseMetaData = new SQLServerDatabaseMetaData(this);
/*      */     }
/* 2819 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.databaseMetaData);
/* 2820 */     return this.databaseMetaData;
/*      */   }
/*      */   
/*      */   public void setReadOnly(boolean paramBoolean) throws SQLServerException
/*      */   {
/* 2825 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2826 */       loggerExternal.entering(getClassNameLogging(), "setReadOnly", Boolean.valueOf(paramBoolean));
/* 2827 */     checkClosed();
/*      */     
/* 2829 */     loggerExternal.exiting(getClassNameLogging(), "setReadOnly");
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() throws SQLServerException
/*      */   {
/* 2834 */     loggerExternal.entering(getClassNameLogging(), "isReadOnly");
/* 2835 */     checkClosed();
/* 2836 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2837 */       loggerExternal.exiting(getClassNameLogging(), "isReadOnly", Boolean.valueOf(false));
/* 2838 */     return false;
/*      */   }
/*      */   
/*      */   public void setCatalog(String paramString) throws SQLServerException
/*      */   {
/* 2843 */     loggerExternal.entering(getClassNameLogging(), "setCatalog", paramString);
/* 2844 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 2846 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 2848 */     checkClosed();
/* 2849 */     if (paramString != null)
/*      */     {
/* 2851 */       connectionCommand("use " + Util.escapeSQLId(paramString), "setCatalog");
/* 2852 */       this.sCatalog = paramString;
/*      */     }
/* 2854 */     loggerExternal.exiting(getClassNameLogging(), "setCatalog");
/*      */   }
/*      */   
/*      */   public String getCatalog() throws SQLServerException
/*      */   {
/* 2859 */     loggerExternal.entering(getClassNameLogging(), "getCatalog");
/* 2860 */     checkClosed();
/* 2861 */     loggerExternal.exiting(getClassNameLogging(), "getCatalog", this.sCatalog);
/* 2862 */     return this.sCatalog;
/*      */   }
/*      */   
/*      */   public void setTransactionIsolation(int paramInt) throws SQLServerException
/*      */   {
/* 2867 */     if (loggerExternal.isLoggable(Level.FINER))
/*      */     {
/* 2869 */       loggerExternal.entering(getClassNameLogging(), "setTransactionIsolation", new Integer(paramInt));
/* 2870 */       if (Util.IsActivityTraceOn())
/*      */       {
/* 2872 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*      */     }
/*      */     
/* 2876 */     checkClosed();
/* 2877 */     if (paramInt == 0) {
/* 2878 */       return;
/*      */     }
/* 2880 */     this.transactionIsolationLevel = paramInt;
/* 2881 */     String str = sqlStatementToSetTransactionIsolationLevel();
/* 2882 */     connectionCommand(str, "setTransactionIsolation");
/* 2883 */     loggerExternal.exiting(getClassNameLogging(), "setTransactionIsolation");
/*      */   }
/*      */   
/*      */   public int getTransactionIsolation() throws SQLServerException
/*      */   {
/* 2888 */     loggerExternal.entering(getClassNameLogging(), "getTransactionIsolation");
/* 2889 */     checkClosed();
/* 2890 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2891 */       loggerExternal.exiting(getClassNameLogging(), "getTransactionIsolation", new Integer(this.transactionIsolationLevel));
/* 2892 */     return this.transactionIsolationLevel;
/*      */   }
/*      */   
/*      */ 
/* 2896 */   Integer warningSynchronization = new Integer(1);
/*      */   private static final int ENVCHANGE_DATABASE = 1;
/*      */   private static final int ENVCHANGE_LANGUAGE = 2;
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLServerException {
/* 2901 */     loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 2902 */     checkClosed();
/*      */     
/* 2904 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", this.sqlWarnings);
/* 2905 */     return this.sqlWarnings;
/*      */   }
/*      */   
/*      */ 
/*      */   private void addWarning(String paramString)
/*      */   {
/* 2911 */     synchronized (this.warningSynchronization)
/*      */     {
/* 2913 */       SQLWarning localSQLWarning = new SQLWarning(paramString);
/*      */       
/*      */ 
/* 2916 */       if (null == this.sqlWarnings)
/*      */       {
/* 2918 */         this.sqlWarnings = localSQLWarning;
/*      */       }
/*      */       else
/*      */       {
/* 2922 */         this.sqlWarnings.setNextWarning(localSQLWarning);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearWarnings() throws SQLServerException
/*      */   {
/* 2929 */     synchronized (this.warningSynchronization)
/*      */     {
/* 2931 */       loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/* 2932 */       checkClosed();
/* 2933 */       this.sqlWarnings = null;
/* 2934 */       loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */     }
/*      */   }
/*      */   
/*      */   public Statement createStatement(int paramInt1, int paramInt2)
/*      */     throws SQLServerException
/*      */   {
/* 2941 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2942 */       loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2) });
/* 2943 */     checkClosed();
/* 2944 */     SQLServerStatement localSQLServerStatement = new SQLServerStatement(this, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/* 2945 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", localSQLServerStatement);
/* 2946 */     return localSQLServerStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 2951 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2952 */       loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) });
/* 2953 */     checkClosed();
/* 2954 */     SQLServerPreparedStatement localSQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/*      */ 
/* 2957 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 2958 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   private PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*      */   {
/* 2963 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2964 */       loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2), paramSQLServerStatementColumnEncryptionSetting });
/* 2965 */     checkClosed();
/* 2966 */     SQLServerPreparedStatement localSQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*      */     
/* 2968 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 2969 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLServerException
/*      */   {
/* 2974 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2975 */       loggerExternal.entering(getClassNameLogging(), "prepareCall", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) });
/* 2976 */     checkClosed();
/* 2977 */     SQLServerCallableStatement localSQLServerCallableStatement = new SQLServerCallableStatement(this, paramString, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2983 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", localSQLServerCallableStatement);
/* 2984 */     return localSQLServerCallableStatement;
/*      */   }
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> paramMap) throws SQLServerException
/*      */   {
/* 2989 */     loggerExternal.entering(getClassNameLogging(), "setTypeMap", paramMap);
/* 2990 */     checkClosed();
/* 2991 */     if ((paramMap != null) && ((paramMap instanceof HashMap)))
/*      */     {
/*      */ 
/* 2994 */       if (paramMap.isEmpty())
/*      */       {
/* 2996 */         loggerExternal.exiting(getClassNameLogging(), "setTypeMap");
/* 2997 */         return;
/*      */       }
/*      */     }
/*      */     
/* 3001 */     NotImplemented();
/*      */   }
/*      */   
/*      */   public Map<String, Class<?>> getTypeMap() throws SQLServerException
/*      */   {
/* 3006 */     loggerExternal.entering(getClassNameLogging(), "getTypeMap");
/* 3007 */     checkClosed();
/* 3008 */     HashMap localHashMap = new HashMap();
/* 3009 */     loggerExternal.exiting(getClassNameLogging(), "getTypeMap", localHashMap);
/* 3010 */     return localHashMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int writeAEFeatureRequest(boolean paramBoolean, TDSWriter paramTDSWriter)
/*      */     throws SQLServerException
/*      */   {
/* 3018 */     int i = 6;
/*      */     
/* 3020 */     if (paramBoolean)
/*      */     {
/* 3022 */       paramTDSWriter.writeByte((byte)4);
/* 3023 */       paramTDSWriter.writeInt(1);
/* 3024 */       paramTDSWriter.writeByte((byte)1);
/*      */     }
/* 3026 */     return i;
/*      */   }
/*      */   
/*      */   int writeFedAuthFeatureRequest(boolean paramBoolean, TDSWriter paramTDSWriter, FederatedAuthenticationFeatureExtensionData paramFederatedAuthenticationFeatureExtensionData) throws SQLServerException
/*      */   {
/* 3031 */     assert ((paramFederatedAuthenticationFeatureExtensionData.libraryType == 2) || (paramFederatedAuthenticationFeatureExtensionData.libraryType == 1));
/*      */     
/* 3033 */     int i = 0;
/* 3034 */     int j = 0;
/*      */     
/*      */ 
/* 3037 */     switch (paramFederatedAuthenticationFeatureExtensionData.libraryType) {
/*      */     case 2: 
/* 3039 */       i = 2;
/* 3040 */       break;
/*      */     case 1: 
/* 3042 */       assert (null != paramFederatedAuthenticationFeatureExtensionData.accessToken);
/* 3043 */       i = 5 + paramFederatedAuthenticationFeatureExtensionData.accessToken.length;
/* 3044 */       break;
/*      */     default: 
/* 3046 */       if (!$assertionsDisabled) { throw new AssertionError();
/*      */       }
/*      */       break;
/*      */     }
/* 3050 */     j = i + 5;
/*      */     
/*      */ 
/* 3053 */     if (paramBoolean) {
/* 3054 */       paramTDSWriter.writeByte((byte)2);
/*      */       
/*      */ 
/* 3057 */       byte b1 = 0;
/*      */       
/*      */ 
/* 3060 */       switch (paramFederatedAuthenticationFeatureExtensionData.libraryType) {
/*      */       case 2: 
/* 3062 */         assert (this.federatedAuthenticationInfoRequested == true);
/* 3063 */         b1 = (byte)(b1 | 0x4);
/* 3064 */         break;
/*      */       case 1: 
/* 3066 */         assert (this.federatedAuthenticationRequested == true);
/* 3067 */         b1 = (byte)(b1 | 0x2);
/* 3068 */         break;
/*      */       default: 
/* 3070 */         if (!$assertionsDisabled) { throw new AssertionError();
/*      */         }
/*      */         break;
/*      */       }
/* 3074 */       b1 = (byte)(b1 | (byte)(paramFederatedAuthenticationFeatureExtensionData.fedAuthRequiredPreLoginResponse == true ? 1 : 0));
/*      */       
/*      */ 
/* 3077 */       paramTDSWriter.writeInt(i);
/*      */       
/*      */ 
/*      */ 
/* 3081 */       paramTDSWriter.writeByte(b1);
/*      */       
/*      */ 
/*      */ 
/* 3085 */       switch (paramFederatedAuthenticationFeatureExtensionData.libraryType) {
/*      */       case 2: 
/* 3087 */         byte b2 = 0;
/* 3088 */         switch (paramFederatedAuthenticationFeatureExtensionData.authentication) {
/*      */         case ActiveDirectoryPassword: 
/* 3090 */           b2 = 1;
/* 3091 */           break;
/*      */         case ActiveDirectoryIntegrated: 
/* 3093 */           b2 = 2;
/* 3094 */           break;
/*      */         default: 
/* 3096 */           if (!$assertionsDisabled) { throw new AssertionError();
/*      */           }
/*      */           break;
/*      */         }
/* 3100 */         paramTDSWriter.writeByte(b2);
/* 3101 */         break;
/*      */       case 1: 
/* 3103 */         paramTDSWriter.writeInt(paramFederatedAuthenticationFeatureExtensionData.accessToken.length);
/* 3104 */         paramTDSWriter.writeBytes(paramFederatedAuthenticationFeatureExtensionData.accessToken, 0, paramFederatedAuthenticationFeatureExtensionData.accessToken.length);
/* 3105 */         break;
/*      */       default: 
/* 3107 */         if (!$assertionsDisabled) throw new AssertionError();
/*      */         break;
/*      */       }
/*      */     }
/* 3111 */     return j;
/*      */   }
/*      */   
/*      */   private final class LogonCommand extends UninterruptableTDSCommand
/*      */   {
/*      */     LogonCommand()
/*      */     {
/* 3118 */       super();
/*      */     }
/*      */     
/*      */     final boolean doExecute() throws SQLServerException
/*      */     {
/* 3123 */       SQLServerConnection.this.logon(this);
/* 3124 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */   private final void logon(LogonCommand paramLogonCommand) throws SQLServerException
/*      */   {
/* 3130 */     Object localObject1 = null;
/* 3131 */     if ((this.integratedSecurity) && (AuthenticationScheme.nativeAuthentication == this.intAuthScheme))
/* 3132 */       localObject1 = new AuthenticationJNI(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber());
/* 3133 */     if ((this.integratedSecurity) && (AuthenticationScheme.javaKerberos == this.intAuthScheme)) {
/* 3134 */       localObject1 = new KerbAuthentication(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3139 */     if ((this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString())) || ((this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString())) && (this.fedAuthRequiredPreLoginResponse)))
/*      */     {
/* 3141 */       this.federatedAuthenticationInfoRequested = true;
/* 3142 */       this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(2, this.authenticationString, this.fedAuthRequiredPreLoginResponse);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3148 */     if (null != this.accessTokenInByte) {
/* 3149 */       this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(1, this.fedAuthRequiredPreLoginResponse, this.accessTokenInByte);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3155 */       this.federatedAuthenticationRequested = true;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 3160 */       sendLogon(paramLogonCommand, (SSPIAuthentication)localObject1, this.fedAuthFeatureExtensionData);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3165 */       if (!this.isRoutedInCurrentAttempt)
/*      */       {
/* 3167 */         this.originalCatalog = this.sCatalog;
/* 3168 */         String str = sqlStatementToInitialize();
/* 3169 */         if (str != null)
/*      */         {
/* 3171 */           connectionCommand(str, "Change Settings");
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 3177 */       if (this.integratedSecurity)
/*      */       {
/* 3179 */         if (null != localObject1)
/* 3180 */           ((SSPIAuthentication)localObject1).ReleaseClientContext();
/* 3181 */         localObject1 = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_CHARSET = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_PACKETSIZE = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_SORTLOCALEID = 5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final void processEnvChange(TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/* 3210 */     paramTDSReader.readUnsignedByte();
/* 3211 */     int i = paramTDSReader.readUnsignedShort();
/*      */     
/* 3213 */     TDSReaderMark localTDSReaderMark = paramTDSReader.mark();
/* 3214 */     int j = paramTDSReader.readUnsignedByte();
/* 3215 */     switch (j)
/*      */     {
/*      */ 
/*      */     case 4: 
/*      */       try
/*      */       {
/* 3221 */         this.tdsPacketSize = Integer.parseInt(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/*      */       }
/*      */       catch (NumberFormatException localNumberFormatException)
/*      */       {
/* 3225 */         paramTDSReader.throwInvalidTDS();
/*      */       }
/* 3227 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 3228 */         connectionlogger.finer(toString() + " Network packet size is " + this.tdsPacketSize + " bytes");
/*      */       }
/*      */       break;
/*      */     case 7: 
/* 3232 */       if (SQLCollation.tdsLength() != paramTDSReader.readUnsignedByte()) {
/* 3233 */         paramTDSReader.throwInvalidTDS();
/*      */       }
/*      */       try
/*      */       {
/* 3237 */         this.databaseCollation = new SQLCollation(paramTDSReader);
/*      */       }
/*      */       catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */       {
/* 3241 */         terminate(4, localUnsupportedEncodingException.getMessage(), localUnsupportedEncodingException);
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */     case 8: 
/*      */     case 11: 
/* 3248 */       this.rolledBackTransaction = false;
/* 3249 */       byte[] arrayOfByte = getTransactionDescriptor();
/*      */       
/* 3251 */       if (arrayOfByte.length != paramTDSReader.readUnsignedByte()) {
/* 3252 */         paramTDSReader.throwInvalidTDS();
/*      */       }
/* 3254 */       paramTDSReader.readBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */       
/* 3256 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/*      */         String str1;
/* 3259 */         if (8 == j) {
/* 3260 */           str1 = " started";
/*      */         } else {
/* 3262 */           str1 = " enlisted";
/*      */         }
/* 3264 */         connectionlogger.finer(toString() + str1);
/*      */       }
/* 3266 */       break;
/*      */     
/*      */ 
/*      */     case 10: 
/* 3270 */       this.rolledBackTransaction = true;
/*      */       
/* 3272 */       if (this.inXATransaction)
/*      */       {
/* 3274 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3275 */           connectionlogger.finer(toString() + " rolled back. (DTC)");
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 3284 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3285 */           connectionlogger.finer(toString() + " rolled back");
/*      */         }
/*      */         
/* 3288 */         Arrays.fill(getTransactionDescriptor(), (byte)0);
/*      */       }
/*      */       
/* 3291 */       break;
/*      */     
/*      */     case 9: 
/* 3294 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 3295 */         connectionlogger.finer(toString() + " committed");
/*      */       }
/* 3297 */       Arrays.fill(getTransactionDescriptor(), (byte)0);
/*      */       
/* 3299 */       break;
/*      */     
/*      */     case 12: 
/* 3302 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 3303 */         connectionlogger.finer(toString() + " defected");
/*      */       }
/* 3305 */       Arrays.fill(getTransactionDescriptor(), (byte)0);
/*      */       
/* 3307 */       break;
/*      */     
/*      */     case 1: 
/* 3310 */       setCatalogName(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/* 3311 */       break;
/*      */     
/*      */     case 13: 
/* 3314 */       setFailoverPartnerServerProvided(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/* 3315 */       break;
/*      */     
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 15: 
/*      */     case 16: 
/*      */     case 17: 
/*      */     case 18: 
/*      */     case 19: 
/* 3326 */       if (connectionlogger.isLoggable(Level.FINER))
/* 3327 */         connectionlogger.finer(toString() + " Ignored env change: " + j);
/*      */       break;
/*      */     case 20: 
/*      */       int i1;
/*      */       int n;
/*      */       int m;
/* 3333 */       int k = m = n = i1 = -1;
/*      */       
/* 3335 */       String str2 = null;
/*      */       
/*      */       try
/*      */       {
/* 3339 */         k = paramTDSReader.readUnsignedShort();
/* 3340 */         if (k <= 5)
/*      */         {
/* 3342 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 3345 */         m = paramTDSReader.readUnsignedByte();
/* 3346 */         if (m != 0)
/*      */         {
/* 3348 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 3351 */         n = paramTDSReader.readUnsignedShort();
/* 3352 */         if ((n <= 0) || (n > 65535))
/*      */         {
/* 3354 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 3357 */         i1 = paramTDSReader.readUnsignedShort();
/* 3358 */         if ((i1 <= 0) || (i1 > 1024))
/*      */         {
/* 3360 */           throwInvalidTDS();
/*      */         }
/*      */         
/* 3363 */         str2 = paramTDSReader.readUnicodeString(i1);
/* 3364 */         if ((!$assertionsDisabled) && (str2 == null)) { throw new AssertionError();
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 3369 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3371 */           connectionlogger.finer(toString() + " Received routing ENVCHANGE with the following values." + " routingDataValueLength:" + k + " protocol:" + m + " portNumber:" + n + " serverNameLength:" + i1 + " serverName:" + (str2 != null ? str2 : "null"));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3382 */       String str3 = this.activeConnectionProperties.getProperty("hostNameInCertificate");
/* 3383 */       if ((null != str3) && (str3.startsWith("*")) && (str2.indexOf('.') != -1))
/*      */       {
/* 3385 */         char[] arrayOfChar1 = str3.toCharArray();
/* 3386 */         char[] arrayOfChar2 = str2.toCharArray();
/* 3387 */         int i2 = 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3394 */         int i3 = str3.length() - 1; for (int i4 = str2.length() - 1; (i3 > 0) && (i4 > 0); i4--)
/*      */         {
/* 3396 */           if (arrayOfChar2[i4] != arrayOfChar1[i3])
/*      */           {
/* 3398 */             i2 = 0;
/* 3399 */             break;
/*      */           }
/* 3394 */           i3--;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3403 */         if (i2 != 0)
/*      */         {
/* 3405 */           String str4 = "*" + str2.substring(str2.indexOf('.'));
/* 3406 */           this.activeConnectionProperties.setProperty("hostNameInCertificate", str4);
/*      */           
/* 3408 */           if (connectionlogger.isLoggable(Level.FINER))
/*      */           {
/* 3410 */             connectionlogger.finer(toString() + "Using new host to validate the SSL certificate");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 3415 */       this.isRoutedInCurrentAttempt = true;
/* 3416 */       this.routingInfo = new ServerPortPlaceHolder(str2, n, null, this.integratedSecurity);
/*      */       
/* 3418 */       break;
/*      */     
/*      */     case 14: 
/*      */     default: 
/* 3422 */       connectionlogger.warning(toString() + " Unknown environment change: " + j);
/* 3423 */       throwInvalidTDS();
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/* 3429 */     paramTDSReader.reset(localTDSReaderMark);
/* 3430 */     paramTDSReader.readBytes(new byte[i], 0, i);
/*      */   }
/*      */   
/*      */   final void processFedAuthInfo(TDSReader paramTDSReader, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
/* 3434 */     SqlFedAuthInfo localSqlFedAuthInfo = new SqlFedAuthInfo();
/*      */     
/* 3436 */     paramTDSReader.readUnsignedByte();
/*      */     
/*      */ 
/* 3439 */     int i = paramTDSReader.readInt();
/*      */     
/* 3441 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 3443 */       connectionlogger.fine(toString() + " FEDAUTHINFO token stream length = " + i);
/*      */     }
/*      */     
/* 3446 */     if (i < 4)
/*      */     {
/*      */ 
/* 3449 */       connectionlogger.severe(toString() + "FEDAUTHINFO token stream length too short for CountOfInfoIDs.");
/* 3450 */       throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForCountOfInfoIds"), null);
/*      */     }
/*      */     
/*      */ 
/* 3454 */     int j = paramTDSReader.readInt();
/*      */     
/* 3456 */     i -= 4;
/*      */     
/* 3458 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 3460 */       connectionlogger.fine(toString() + " CountOfInfoIDs = " + j);
/*      */     }
/*      */     Object localObject1;
/* 3463 */     if (i > 0)
/*      */     {
/* 3465 */       localObject1 = new byte[i];
/*      */       
/* 3467 */       paramTDSReader.readBytes((byte[])localObject1, 0, i);
/*      */       
/* 3469 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 3471 */         connectionlogger.fine(toString() + " Read rest of FEDAUTHINFO token stream: " + Arrays.toString((byte[])localObject1));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3482 */       int k = j * 9;
/*      */       
/* 3484 */       for (int m = 0; m < j; m++) {
/* 3485 */         int n = m * 9;
/*      */         
/* 3487 */         int i1 = localObject1[n];
/* 3488 */         byte[] arrayOfByte1 = new byte[4];
/* 3489 */         arrayOfByte1[3] = localObject1[(n + 1)];
/* 3490 */         arrayOfByte1[2] = localObject1[(n + 2)];
/* 3491 */         arrayOfByte1[1] = localObject1[(n + 3)];
/* 3492 */         arrayOfByte1[0] = localObject1[(n + 4)];
/* 3493 */         ByteBuffer localByteBuffer = ByteBuffer.wrap(arrayOfByte1);
/* 3494 */         int i2 = localByteBuffer.getInt();
/*      */         
/* 3496 */         arrayOfByte1 = new byte[4];
/* 3497 */         arrayOfByte1[3] = localObject1[(n + 5)];
/* 3498 */         arrayOfByte1[2] = localObject1[(n + 6)];
/* 3499 */         arrayOfByte1[1] = localObject1[(n + 7)];
/* 3500 */         arrayOfByte1[0] = localObject1[(n + 8)];
/* 3501 */         localByteBuffer = ByteBuffer.wrap(arrayOfByte1);
/* 3502 */         int i3 = localByteBuffer.getInt();
/*      */         
/* 3504 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3506 */           connectionlogger.fine(toString() + " FedAuthInfoOpt: ID=" + i1 + ", DataLen=" + i2 + ", Offset=" + i3);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 3511 */         i3 -= 4;
/*      */         
/*      */ 
/* 3514 */         if ((i3 < k) || (i3 >= i)) {
/* 3515 */           connectionlogger.severe(toString() + "FedAuthInfoDataOffset points to an invalid location.");
/* 3516 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoInvalidOffset"));
/* 3517 */           throw new SQLServerException(((MessageFormat)localObject2).format(new Object[] { Integer.valueOf(i3) }), null);
/*      */         }
/*      */         
/*      */ 
/* 3521 */         Object localObject2 = null;
/*      */         try {
/* 3523 */           byte[] arrayOfByte2 = new byte[i2];
/* 3524 */           System.arraycopy(localObject1, i3, arrayOfByte2, 0, i2);
/* 3525 */           localObject2 = new String(arrayOfByte2, "UTF-16LE");
/*      */         }
/*      */         catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 3528 */           MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */           
/* 3530 */           Object[] arrayOfObject = { "UTF-16LE" };
/* 3531 */           throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */         }
/*      */         catch (Exception localException) {
/* 3534 */           connectionlogger.severe(toString() + "Failed to read FedAuthInfoData.");
/* 3535 */           throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoFailedToReadData"), null);
/*      */         }
/*      */         
/* 3538 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3540 */           connectionlogger.fine(toString() + " FedAuthInfoData: " + (String)localObject2);
/*      */         }
/*      */         
/*      */ 
/* 3544 */         switch (i1) {
/*      */         case 2: 
/* 3546 */           localSqlFedAuthInfo.spn = ((String)localObject2);
/* 3547 */           break;
/*      */         case 1: 
/* 3549 */           localSqlFedAuthInfo.stsurl = ((String)localObject2);
/* 3550 */           break;
/*      */         default: 
/* 3552 */           if (connectionlogger.isLoggable(Level.FINER))
/*      */           {
/* 3554 */             connectionlogger.fine(toString() + " Ignoring unknown federated authentication info option: " + i1);
/*      */           }
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 3561 */       connectionlogger.severe(toString() + "FEDAUTHINFO token stream is not long enough to contain the data it claims to.");
/* 3562 */       localObject1 = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForData"));
/* 3563 */       throw new SQLServerException(((MessageFormat)localObject1).format(new Object[] { Integer.valueOf(i) }), null);
/*      */     }
/*      */     
/* 3566 */     if ((null == localSqlFedAuthInfo.spn) || (null == localSqlFedAuthInfo.stsurl) || (localSqlFedAuthInfo.spn.trim().isEmpty()) || (localSqlFedAuthInfo.stsurl.trim().isEmpty()))
/*      */     {
/* 3568 */       connectionlogger.severe(toString() + "FEDAUTHINFO token stream does not contain both STSURL and SPN.");
/* 3569 */       throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoDoesNotContainStsurlAndSpn"), null);
/*      */     }
/*      */     
/* 3572 */     onFedAuthInfo(localSqlFedAuthInfo, paramTDSTokenHandler);
/*      */   }
/*      */   
/*      */   final class FedAuthTokenCommand
/*      */     extends UninterruptableTDSCommand
/*      */   {
/* 3578 */     TDSTokenHandler tdsTokenHandler = null;
/* 3579 */     SQLServerConnection.SqlFedAuthToken fedAuthToken = null;
/*      */     
/*      */     FedAuthTokenCommand(SQLServerConnection.SqlFedAuthToken paramSqlFedAuthToken, TDSTokenHandler paramTDSTokenHandler) {
/* 3582 */       super();
/* 3583 */       this.tdsTokenHandler = paramTDSTokenHandler;
/* 3584 */       this.fedAuthToken = paramSqlFedAuthToken;
/*      */     }
/*      */     
/*      */     final boolean doExecute() throws SQLServerException
/*      */     {
/* 3589 */       SQLServerConnection.this.sendFedAuthToken(this, this.fedAuthToken, this.tdsTokenHandler);
/* 3590 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void onFedAuthInfo(SqlFedAuthInfo paramSqlFedAuthInfo, TDSTokenHandler paramTDSTokenHandler)
/*      */     throws SQLServerException
/*      */   {
/* 3599 */     assert (((null != this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString())) && (null != this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()))) || ((this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString())) && (this.fedAuthRequiredPreLoginResponse)));
/*      */     
/*      */ 
/* 3602 */     assert (null != paramSqlFedAuthInfo);
/*      */     
/* 3604 */     this.attemptRefreshTokenLocked = true;
/* 3605 */     this.fedAuthToken = getFedAuthToken(paramSqlFedAuthInfo);
/* 3606 */     this.attemptRefreshTokenLocked = false;
/*      */     
/*      */ 
/* 3609 */     assert (null != this.fedAuthToken);
/*      */     
/* 3611 */     FedAuthTokenCommand localFedAuthTokenCommand = new FedAuthTokenCommand(this.fedAuthToken, paramTDSTokenHandler);
/* 3612 */     localFedAuthTokenCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(localFedAuthTokenCommand));
/*      */   }
/*      */   
/*      */   private SqlFedAuthToken getFedAuthToken(SqlFedAuthInfo paramSqlFedAuthInfo) throws SQLServerException
/*      */   {
/* 3617 */     assert (null != paramSqlFedAuthInfo);
/*      */     
/*      */ 
/* 3620 */     int i = 100;
/*      */     
/*      */ 
/* 3623 */     int j = 0;
/*      */     
/* 3625 */     FedAuthDllInfo localFedAuthDllInfo = null;
/*      */     
/* 3627 */     String str1 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString());
/* 3628 */     String str2 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString());
/*      */     
/* 3630 */     long l = 0L;
/*      */     Object localObject2;
/*      */     for (;;) {
/* 3633 */       j++;
/*      */       try
/*      */       {
/* 3636 */         if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString())) {
/* 3637 */           localFedAuthDllInfo = AuthenticationJNI.getAccessToken(str1, str2, paramSqlFedAuthInfo.stsurl, paramSqlFedAuthInfo.spn, this.clientConnectionId.toString(), "7f98cb04-cd1e-40df-9140-3bf7e2cea4db", l);
/*      */         }
/* 3639 */         else if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString())) {
/* 3640 */           localFedAuthDllInfo = AuthenticationJNI.getAccessTokenForWindowsIntegrated(paramSqlFedAuthInfo.stsurl, paramSqlFedAuthInfo.spn, this.clientConnectionId.toString(), "7f98cb04-cd1e-40df-9140-3bf7e2cea4db", l);
/*      */         }
/*      */         
/*      */ 
/* 3644 */         if ((!$assertionsDisabled) && (null == localFedAuthDllInfo.accessTokenBytes)) { throw new AssertionError();
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (DLLException localDLLException)
/*      */       {
/*      */ 
/* 3652 */         int k = localDLLException.GetCategory();
/* 3653 */         Object localObject1; if (-1 == k) {
/* 3654 */           MessageFormat localMessageFormat1 = new MessageFormat(SQLServerException.getErrString("R_UnableLoadADALSqlDll"));
/* 3655 */           localObject1 = new Object[] { Integer.toHexString(localDLLException.GetState()) };
/* 3656 */           throw new SQLServerException(localMessageFormat1.format(localObject1), null);
/*      */         }
/*      */         
/* 3659 */         int m = TimerRemaining(this.timerExpire);
/* 3660 */         if ((2 != k) || (timerHasExpired(this.timerExpire)) || (i >= m))
/*      */         {
/*      */ 
/* 3663 */           localObject1 = Integer.toHexString(localDLLException.GetStatus());
/*      */           
/* 3665 */           if (connectionlogger.isLoggable(Level.FINER))
/*      */           {
/* 3667 */             connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken.AdalException category:" + k + " error: " + (String)localObject1);
/*      */           }
/*      */           
/* 3670 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_ADALAuthenticationMiddleErrorMessage"));
/* 3671 */           String str4 = Integer.toHexString(localDLLException.GetStatus()).toUpperCase();
/* 3672 */           Object[] arrayOfObject1 = { str4, Integer.valueOf(localDLLException.GetState()) };
/* 3673 */           SQLServerException localSQLServerException = new SQLServerException(((MessageFormat)localObject2).format(arrayOfObject1), localDLLException);
/*      */           
/* 3675 */           MessageFormat localMessageFormat3 = new MessageFormat(SQLServerException.getErrString("R_ADALExecution"));
/* 3676 */           Object[] arrayOfObject2 = { str1, this.authenticationString };
/* 3677 */           throw new SQLServerException(localMessageFormat3.format(arrayOfObject2), null, 0, localSQLServerException);
/*      */         }
/*      */         
/* 3680 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3682 */           connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken sleeping: " + i + " milliseconds.");
/* 3683 */           connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken remaining: " + m + " milliseconds.");
/*      */         }
/*      */         try
/*      */         {
/* 3687 */           Thread.sleep(i);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException) {}
/*      */         
/* 3691 */         i *= 2;
/*      */       }
/*      */     }
/*      */     
/* 3695 */     byte[] arrayOfByte = localFedAuthDllInfo.accessTokenBytes;
/*      */     
/* 3697 */     String str3 = null;
/*      */     try {
/* 3699 */       str3 = new String(arrayOfByte, "UTF-16LE");
/*      */     }
/*      */     catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 3702 */       MessageFormat localMessageFormat2 = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */       
/* 3704 */       localObject2 = new Object[] { "UTF-16LE" };
/* 3705 */       throw new SQLServerException(null, localMessageFormat2.format(localObject2), null, 0, false);
/*      */     }
/*      */     
/* 3708 */     SqlFedAuthToken localSqlFedAuthToken = new SqlFedAuthToken(str3, localFedAuthDllInfo.expiresIn);
/*      */     
/* 3710 */     return localSqlFedAuthToken;
/*      */   }
/*      */   
/*      */ 
/*      */   private void sendFedAuthToken(FedAuthTokenCommand paramFedAuthTokenCommand, SqlFedAuthToken paramSqlFedAuthToken, TDSTokenHandler paramTDSTokenHandler)
/*      */     throws SQLServerException
/*      */   {
/* 3717 */     assert (null != paramSqlFedAuthToken);
/* 3718 */     assert (null != paramSqlFedAuthToken.accessToken);
/*      */     
/* 3720 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 3722 */       connectionlogger.fine(toString() + " Sending federated authentication token.");
/*      */     }
/*      */     
/* 3725 */     TDSWriter localTDSWriter = paramFedAuthTokenCommand.startRequest((byte)8);
/*      */     
/* 3727 */     byte[] arrayOfByte = null;
/*      */     try {
/* 3729 */       arrayOfByte = paramSqlFedAuthToken.accessToken.getBytes("UTF-16LE");
/*      */     } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 3731 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */       
/* 3733 */       Object[] arrayOfObject = { "UTF-16LE" };
/* 3734 */       throw new SQLServerException(this, localMessageFormat.format(arrayOfObject), null, 0, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3739 */     localTDSWriter.writeInt(arrayOfByte.length + 4);
/*      */     
/*      */ 
/* 3742 */     localTDSWriter.writeInt(arrayOfByte.length);
/*      */     
/*      */ 
/* 3745 */     localTDSWriter.writeBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */     
/*      */ 
/* 3748 */     TDSReader localTDSReader = paramFedAuthTokenCommand.startResponse();
/*      */     
/* 3750 */     this.federatedAuthenticationRequested = true;
/*      */     
/* 3752 */     TDSParser.parse(localTDSReader, paramTDSTokenHandler);
/*      */   }
/*      */   
/*      */   final void processFeatureExtAck(TDSReader paramTDSReader) throws SQLServerException
/*      */   {
/* 3757 */     paramTDSReader.readUnsignedByte();
/*      */     
/*      */     int i;
/*      */     do
/*      */     {
/* 3762 */       i = (byte)paramTDSReader.readUnsignedByte();
/*      */       
/* 3764 */       if (i != -1)
/*      */       {
/* 3766 */         int j = paramTDSReader.readInt();
/*      */         
/* 3768 */         byte[] arrayOfByte = new byte[j];
/* 3769 */         if (j > 0) {
/* 3770 */           paramTDSReader.readBytes(arrayOfByte, 0, j);
/*      */         }
/* 3772 */         onFeatureExtAck(i, arrayOfByte);
/*      */       }
/* 3774 */     } while (i != -1);
/*      */   }
/*      */   
/*      */   private void onFeatureExtAck(int paramInt, byte[] paramArrayOfByte) throws SQLServerException {
/* 3778 */     if (null != this.routingInfo) {
/* 3779 */       return;
/*      */     }
/*      */     
/* 3782 */     switch (paramInt) {
/*      */     case 2: 
/* 3784 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 3786 */         connectionlogger.fine(toString() + " Received feature extension acknowledgement for federated authentication."); }
/*      */       MessageFormat localMessageFormat;
/*      */       Object[] arrayOfObject;
/* 3789 */       if (!this.federatedAuthenticationRequested) {
/* 3790 */         connectionlogger.severe(toString() + " Did not request federated authentication.");
/* 3791 */         localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrequestedFeatureAckReceived"));
/* 3792 */         arrayOfObject = new Object[] { Integer.valueOf(paramInt) };
/* 3793 */         throw new SQLServerException(localMessageFormat.format(arrayOfObject), null);
/*      */       }
/*      */       
/*      */ 
/* 3797 */       assert (null != this.fedAuthFeatureExtensionData);
/*      */       
/* 3799 */       switch (this.fedAuthFeatureExtensionData.libraryType)
/*      */       {
/*      */       case 1: 
/*      */       case 2: 
/* 3803 */         if (0 != paramArrayOfByte.length) {
/* 3804 */           connectionlogger.severe(toString() + " Federated authentication feature extension ack for ADAL and Security Token includes extra data.");
/* 3805 */           throw new SQLServerException(SQLServerException.getErrString("R_FedAuthFeatureAckContainsExtraData"), null);
/*      */         }
/*      */         
/*      */         break;
/*      */       default: 
/* 3810 */         if (!$assertionsDisabled) throw new AssertionError();
/* 3811 */         connectionlogger.severe(toString() + " Attempting to use unknown federated authentication library.");
/* 3812 */         localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthFeatureAckUnknownLibraryType"));
/* 3813 */         arrayOfObject = new Object[] { Integer.valueOf(this.fedAuthFeatureExtensionData.libraryType) };
/* 3814 */         throw new SQLServerException(localMessageFormat.format(arrayOfObject), null);
/*      */       }
/* 3816 */       this.federatedAuthenticationAcknowledged = true;
/*      */       
/* 3818 */       break;
/*      */     
/*      */     case 4: 
/* 3821 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 3823 */         connectionlogger.fine(toString() + " Received feature extension acknowledgement for AE.");
/*      */       }
/*      */       
/* 3826 */       if (1 > paramArrayOfByte.length) {
/* 3827 */         connectionlogger.severe(toString() + " Unknown version number for AE.");
/* 3828 */         throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);
/*      */       }
/*      */       
/* 3831 */       int i = paramArrayOfByte[0];
/* 3832 */       if ((0 == i) || (i > 1)) {
/* 3833 */         connectionlogger.severe(toString() + " Invalid version number for AE.");
/* 3834 */         throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);
/*      */       }
/*      */       
/* 3837 */       assert (i == 1);
/* 3838 */       this.serverSupportsColumnEncryption = true;
/* 3839 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/* 3844 */       connectionlogger.severe(toString() + " Unknown feature ack.");
/* 3845 */       throw new SQLServerException(SQLServerException.getErrString("R_UnknownFeatureAck"), null);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_SORTFLAGS = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_SQLCOLLATION = 7;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_XACT_BEGIN = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_XACT_COMMIT = 9;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_XACT_ROLLBACK = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void executeDTCCommand(int paramInt, byte[] paramArrayOfByte, String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 3891 */     executeCommand(new UninterruptableTDSCommand(paramInt)
/*      */     {
/*      */       private final int requestType;
/*      */       private final byte[] payload;
/*      */       
/*      */       final boolean doExecute()
/*      */         throws SQLServerException
/*      */       {
/* 3872 */         TDSWriter localTDSWriter = startRequest((byte)14);
/*      */         
/* 3874 */         localTDSWriter.writeShort((short)this.requestType);
/* 3875 */         if (null == this.payload)
/*      */         {
/* 3877 */           localTDSWriter.writeShort((short)0);
/*      */         }
/*      */         else
/*      */         {
/* 3881 */           assert (this.payload.length <= 32767);
/* 3882 */           localTDSWriter.writeShort((short)this.payload.length);
/* 3883 */           localTDSWriter.writeBytes(this.payload);
/*      */         }
/*      */         
/* 3886 */         TDSParser.parse(startResponse(), getLogContext());
/* 3887 */         return true;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void JTAUnenlistConnection()
/*      */     throws SQLServerException
/*      */   {
/* 3901 */     executeDTCCommand(1, null, "MS_DTC unenlist connection");
/* 3902 */     this.inXATransaction = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void JTAEnlistConnection(byte[] paramArrayOfByte)
/*      */     throws SQLServerException
/*      */   {
/* 3913 */     executeDTCCommand(1, paramArrayOfByte, "MS_DTC enlist connection");
/*      */     
/*      */ 
/*      */ 
/* 3917 */     connectionCommand(sqlStatementToSetTransactionIsolationLevel(), "JTAEnlistConnection");
/* 3918 */     this.inXATransaction = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] toUCS16(String paramString)
/*      */     throws SQLServerException
/*      */   {
/* 3931 */     if (paramString == null)
/* 3932 */       return new byte[0];
/* 3933 */     int i = paramString.length();
/* 3934 */     byte[] arrayOfByte = new byte[i * 2];
/* 3935 */     int j = 0;
/* 3936 */     for (int k = 0; k < i; k++) {
/* 3937 */       int m = paramString.charAt(k);
/* 3938 */       int n = (byte)(m & 0xFF);
/* 3939 */       arrayOfByte[(j++)] = n;
/* 3940 */       arrayOfByte[(j++)] = ((byte)(m >> 8 & 0xFF));
/*      */     }
/* 3942 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] encryptPassword(String paramString)
/*      */   {
/* 3952 */     if (paramString == null) paramString = "";
/* 3953 */     int i = paramString.length();
/* 3954 */     byte[] arrayOfByte = new byte[i * 2];
/* 3955 */     for (int j = 0; j < i; j++) {
/* 3956 */       int k = paramString.charAt(j) ^ 0x5A5A;
/* 3957 */       k = (k & 0xF) << 4 | (k & 0xF0) >> 4 | (k & 0xF00) << 4 | (k & 0xF000) >> 4;
/* 3958 */       int m = (byte)((k & 0xFF00) >> 8);
/* 3959 */       arrayOfByte[(j * 2 + 1)] = m;
/* 3960 */       int n = (byte)(k & 0xFF);
/* 3961 */       arrayOfByte[(j * 2 + 0)] = n;
/*      */     }
/* 3963 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_DTC_ENLIST = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_DTC_DEFECT = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_CHANGE_MIRROR = 13;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_UNUSED_14 = 14;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_DTC_PROMOTE = 15;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_DTC_MGR_ADDR = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_XACT_ENDED = 17;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_RESET_COMPLETE = 18;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_USER_INFO = 19;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ENVCHANGE_ROUTING = 20;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sendLogon(LogonCommand paramLogonCommand, SSPIAuthentication paramSSPIAuthentication, FederatedAuthenticationFeatureExtensionData paramFederatedAuthenticationFeatureExtensionData)
/*      */     throws SQLServerException
/*      */   {
/* 4048 */     assert ((!this.integratedSecurity) || (!this.fedAuthRequiredPreLoginResponse));
/*      */     
/* 4050 */     assert ((!this.integratedSecurity) || ((!this.federatedAuthenticationInfoRequested) && (!this.federatedAuthenticationRequested)));
/*      */     
/* 4052 */     assert ((null == paramFederatedAuthenticationFeatureExtensionData) || (this.federatedAuthenticationInfoRequested) || (this.federatedAuthenticationRequested));
/*      */     
/* 4054 */     assert ((null != paramFederatedAuthenticationFeatureExtensionData) || ((!this.federatedAuthenticationInfoRequested) && (!this.federatedAuthenticationRequested)));
/*      */     
/* 4056 */     String str1 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
/* 4057 */     String str2 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString());
/* 4058 */     String str3 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString());
/* 4059 */     String str4 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.APPLICATION_NAME.toString());
/* 4060 */     String str5 = "Microsoft JDBC Driver 6.0";
/* 4061 */     String str6 = generateInterfaceLibVersion();
/* 4062 */     String str7 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString());
/* 4063 */     String str8 = null;
/*      */     
/* 4065 */     if (null != this.currentConnectPlaceHolder)
/*      */     {
/* 4067 */       str8 = this.currentConnectPlaceHolder.getServerName();
/*      */     }
/*      */     else
/*      */     {
/* 4071 */       str8 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString());
/*      */     }
/*      */     
/* 4074 */     if ((str8 != null) && (str8.length() > 128)) {
/* 4075 */       str8 = str8.substring(0, 128);
/*      */     }
/* 4077 */     if ((str1 == null) || (str1.length() == 0))
/*      */     {
/* 4079 */       str1 = Util.lookupHostName();
/*      */     }
/*      */     
/* 4082 */     byte[] arrayOfByte1 = new byte[0];
/* 4083 */     boolean[] arrayOfBoolean = { false };
/* 4084 */     if (null != paramSSPIAuthentication)
/*      */     {
/* 4086 */       arrayOfByte1 = paramSSPIAuthentication.GenerateClientContext(arrayOfByte1, arrayOfBoolean);
/* 4087 */       str2 = null;
/* 4088 */       str3 = null;
/*      */     }
/*      */     
/* 4091 */     byte[] arrayOfByte2 = toUCS16(str1);
/* 4092 */     byte[] arrayOfByte3 = toUCS16(str2);
/* 4093 */     byte[] arrayOfByte4 = encryptPassword(str3);
/* 4094 */     int i = arrayOfByte4 != null ? arrayOfByte4.length : 0;
/* 4095 */     byte[] arrayOfByte5 = toUCS16(str4);
/* 4096 */     byte[] arrayOfByte6 = toUCS16(str8);
/* 4097 */     byte[] arrayOfByte7 = toUCS16(str5);
/* 4098 */     byte[] arrayOfByte8 = DatatypeConverter.parseHexBinary(str6);
/* 4099 */     byte[] arrayOfByte9 = toUCS16(str7);
/* 4100 */     byte[] arrayOfByte10 = new byte[6];
/* 4101 */     int j = 0;
/* 4102 */     int k = 0;
/*      */     
/*      */ 
/*      */ 
/* 4106 */     if (this.serverMajorVersion >= 11)
/*      */     {
/* 4108 */       this.tdsVersion = 1946157060;
/*      */     }
/* 4110 */     else if (this.serverMajorVersion >= 10)
/*      */     {
/* 4112 */       this.tdsVersion = 1930100739;
/*      */ 
/*      */     }
/* 4115 */     else if (this.serverMajorVersion >= 9)
/*      */     {
/* 4117 */       this.tdsVersion = 1913192450;
/*      */ 
/*      */ 
/*      */     }
/* 4121 */     else if (!$assertionsDisabled) { throw new AssertionError("prelogin did not disconnect for the old version: " + this.serverMajorVersion);
/*      */     }
/*      */     
/* 4124 */     TDSWriter localTDSWriter = paramLogonCommand.startRequest((byte)16);
/*      */     
/* 4126 */     j = 94 + arrayOfByte2.length + arrayOfByte5.length + arrayOfByte6.length + arrayOfByte7.length + arrayOfByte9.length + arrayOfByte1.length + 4;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4136 */     if ((!this.integratedSecurity) && (!this.federatedAuthenticationInfoRequested) && (!this.federatedAuthenticationRequested)) {
/* 4137 */       j = j + i + arrayOfByte3.length;
/*      */     }
/*      */     
/* 4140 */     int m = j;
/*      */     
/* 4142 */     j += writeAEFeatureRequest(false, localTDSWriter);
/* 4143 */     if ((this.federatedAuthenticationInfoRequested) || (this.federatedAuthenticationRequested))
/*      */     {
/* 4145 */       j += writeFedAuthFeatureRequest(false, localTDSWriter, paramFederatedAuthenticationFeatureExtensionData);
/*      */     }
/*      */     
/* 4148 */     j += 1;
/*      */     
/*      */ 
/* 4151 */     localTDSWriter.writeInt(j);
/* 4152 */     localTDSWriter.writeInt(this.tdsVersion);
/* 4153 */     localTDSWriter.writeInt(this.requestedPacketSize);
/* 4154 */     localTDSWriter.writeBytes(arrayOfByte8);
/* 4155 */     localTDSWriter.writeInt(0);
/* 4156 */     localTDSWriter.writeInt(0);
/*      */     
/* 4158 */     localTDSWriter.writeByte((byte)-32);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4168 */     localTDSWriter.writeByte((byte)(0x3 | (this.integratedSecurity ? -128 : 0)));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4177 */     localTDSWriter.writeByte((byte)(0x0 | ((this.applicationIntent != null) && (this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) ? 32 : 0)));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4186 */     int n = 0;
/*      */     
/*      */ 
/* 4189 */     n = 16;
/*      */     
/* 4191 */     localTDSWriter.writeByte((byte)(0x0 | n | (this.serverMajorVersion >= 10 ? 8 : 0)));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4196 */     localTDSWriter.writeInt(0);
/* 4197 */     localTDSWriter.writeInt(0);
/*      */     
/* 4199 */     localTDSWriter.writeShort((short)94);
/*      */     
/*      */ 
/* 4202 */     localTDSWriter.writeShort((short)(str1 == null ? 0 : str1.length()));
/* 4203 */     k += arrayOfByte2.length;
/*      */     
/*      */ 
/*      */ 
/* 4207 */     if ((!this.integratedSecurity) && (!this.federatedAuthenticationInfoRequested) && (!this.federatedAuthenticationRequested))
/*      */     {
/*      */ 
/* 4210 */       localTDSWriter.writeShort((short)(94 + k));
/* 4211 */       localTDSWriter.writeShort((short)(str2 == null ? 0 : str2.length()));
/* 4212 */       k += arrayOfByte3.length;
/*      */       
/* 4214 */       localTDSWriter.writeShort((short)(94 + k));
/* 4215 */       localTDSWriter.writeShort((short)(str3 == null ? 0 : str3.length()));
/* 4216 */       k += i;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 4222 */       localTDSWriter.writeShort((short)0);
/* 4223 */       localTDSWriter.writeShort((short)0);
/* 4224 */       localTDSWriter.writeShort((short)0);
/* 4225 */       localTDSWriter.writeShort((short)0);
/*      */     }
/*      */     
/*      */ 
/* 4229 */     localTDSWriter.writeShort((short)(94 + k));
/* 4230 */     localTDSWriter.writeShort((short)(str4 == null ? 0 : str4.length()));
/* 4231 */     k += arrayOfByte5.length;
/*      */     
/*      */ 
/* 4234 */     localTDSWriter.writeShort((short)(94 + k));
/* 4235 */     localTDSWriter.writeShort((short)(str8 == null ? 0 : str8.length()));
/* 4236 */     k += arrayOfByte6.length;
/*      */     
/*      */ 
/* 4239 */     localTDSWriter.writeShort((short)(94 + k));
/*      */     
/*      */ 
/* 4242 */     localTDSWriter.writeShort((short)4);
/* 4243 */     k += 4;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4248 */     assert (null != str5);
/* 4249 */     localTDSWriter.writeShort((short)(94 + k));
/* 4250 */     localTDSWriter.writeShort((short)str5.length());
/* 4251 */     k += arrayOfByte7.length;
/*      */     
/*      */ 
/* 4254 */     localTDSWriter.writeShort((short)0);
/* 4255 */     localTDSWriter.writeShort((short)0);
/*      */     
/*      */ 
/* 4258 */     localTDSWriter.writeShort((short)(94 + k));
/* 4259 */     localTDSWriter.writeShort((short)(str7 == null ? 0 : str7.length()));
/* 4260 */     k += arrayOfByte9.length;
/*      */     
/*      */ 
/* 4263 */     localTDSWriter.writeBytes(arrayOfByte10);
/*      */     
/*      */ 
/*      */ 
/* 4267 */     if (!this.integratedSecurity)
/*      */     {
/* 4269 */       localTDSWriter.writeShort((short)0);
/* 4270 */       localTDSWriter.writeShort((short)0);
/*      */     }
/*      */     else
/*      */     {
/* 4274 */       localTDSWriter.writeShort((short)(94 + k));
/* 4275 */       if (65535 <= arrayOfByte1.length)
/*      */       {
/* 4277 */         localTDSWriter.writeShort((short)-1);
/*      */       }
/*      */       else {
/* 4280 */         localTDSWriter.writeShort((short)arrayOfByte1.length);
/*      */       }
/*      */     }
/*      */     
/* 4284 */     localTDSWriter.writeShort((short)0);
/* 4285 */     localTDSWriter.writeShort((short)0);
/*      */     
/* 4287 */     if (this.tdsVersion >= 1913192450)
/*      */     {
/*      */ 
/* 4290 */       localTDSWriter.writeShort((short)0);
/* 4291 */       localTDSWriter.writeShort((short)0);
/*      */       
/*      */ 
/* 4294 */       if (65535 <= arrayOfByte1.length) {
/* 4295 */         localTDSWriter.writeInt(arrayOfByte1.length);
/*      */       } else {
/* 4297 */         localTDSWriter.writeInt(0);
/*      */       }
/*      */     }
/* 4300 */     localTDSWriter.writeBytes(arrayOfByte2);
/*      */     
/*      */ 
/* 4303 */     localTDSWriter.setDataLoggable(false);
/*      */     
/*      */ 
/* 4306 */     if ((!this.integratedSecurity) && (!this.federatedAuthenticationInfoRequested) && (!this.federatedAuthenticationRequested))
/*      */     {
/* 4308 */       localTDSWriter.writeBytes(arrayOfByte3);
/* 4309 */       localTDSWriter.writeBytes(arrayOfByte4);
/*      */     }
/* 4311 */     localTDSWriter.setDataLoggable(true);
/*      */     
/* 4313 */     localTDSWriter.writeBytes(arrayOfByte5);
/* 4314 */     localTDSWriter.writeBytes(arrayOfByte6);
/*      */     
/*      */ 
/*      */ 
/* 4318 */     localTDSWriter.writeInt(m);
/*      */     
/*      */ 
/* 4321 */     localTDSWriter.writeBytes(arrayOfByte7);
/* 4322 */     localTDSWriter.writeBytes(arrayOfByte9);
/*      */     
/*      */ 
/* 4325 */     localTDSWriter.setDataLoggable(false);
/* 4326 */     if (this.integratedSecurity) {
/* 4327 */       localTDSWriter.writeBytes(arrayOfByte1, 0, arrayOfByte1.length);
/*      */     }
/*      */     
/*      */ 
/* 4331 */     writeAEFeatureRequest(true, localTDSWriter);
/*      */     
/*      */ 
/* 4334 */     if ((this.federatedAuthenticationInfoRequested) || (this.federatedAuthenticationRequested)) {
/* 4335 */       writeFedAuthFeatureRequest(true, localTDSWriter, paramFederatedAuthenticationFeatureExtensionData);
/*      */     }
/*      */     
/* 4338 */     localTDSWriter.writeByte((byte)-1);
/* 4339 */     localTDSWriter.setDataLoggable(true);
/*      */     
/* 4341 */     TDSTokenHandler local1LogonProcessor = new TDSTokenHandler(paramSSPIAuthentication)
/*      */     {
/*      */       private final SSPIAuthentication auth;
/* 3985 */       private byte[] secBlobOut = null;
/*      */       
/*      */ 
/*      */ 
/*      */       StreamLoginAck loginAckToken;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       boolean onSSPI(TDSReader paramAnonymousTDSReader)
/*      */         throws SQLServerException
/*      */       {
/* 3997 */         StreamSSPI localStreamSSPI = new StreamSSPI();
/* 3998 */         localStreamSSPI.setFromTDS(paramAnonymousTDSReader);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 4003 */         boolean[] arrayOfBoolean = { false };
/* 4004 */         this.secBlobOut = this.auth.GenerateClientContext(localStreamSSPI.sspiBlob, arrayOfBoolean);
/* 4005 */         return true;
/*      */       }
/*      */       
/*      */       boolean onLoginAck(TDSReader paramAnonymousTDSReader) throws SQLServerException
/*      */       {
/* 4010 */         this.loginAckToken = new StreamLoginAck();
/* 4011 */         this.loginAckToken.setFromTDS(paramAnonymousTDSReader);
/* 4012 */         SQLServerConnection.this.sqlServerVersion = this.loginAckToken.sSQLServerVersion;
/* 4013 */         SQLServerConnection.this.tdsVersion = this.loginAckToken.tdsVersion;
/* 4014 */         return true;
/*      */       }
/*      */       
/*      */       final boolean complete(SQLServerConnection.LogonCommand paramAnonymousLogonCommand, TDSReader paramAnonymousTDSReader)
/*      */         throws SQLServerException
/*      */       {
/* 4020 */         if (null != this.loginAckToken) {
/* 4021 */           return true;
/*      */         }
/*      */         
/* 4024 */         if ((null != this.secBlobOut) && (0 != this.secBlobOut.length))
/*      */         {
/*      */ 
/*      */ 
/* 4028 */           paramAnonymousLogonCommand.startRequest((byte)17).writeBytes(this.secBlobOut, 0, this.secBlobOut.length);
/* 4029 */           return false;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4038 */         paramAnonymousLogonCommand.startRequest((byte)17);
/* 4039 */         paramAnonymousLogonCommand.onRequestComplete();
/* 4040 */         SQLServerConnection.this.tdsChannel.numMsgsSent += 1;
/*      */         
/* 4042 */         TDSParser.parse(paramAnonymousTDSReader, this);
/* 4043 */         return true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4341 */     };
/* 4342 */     TDSReader localTDSReader = null;
/*      */     do
/*      */     {
/* 4345 */       localTDSReader = paramLogonCommand.startResponse();
/* 4346 */       TDSParser.parse(localTDSReader, local1LogonProcessor);
/*      */     }
/* 4348 */     while (!local1LogonProcessor.complete(paramLogonCommand, localTDSReader));
/*      */   }
/*      */   
/*      */   private String generateInterfaceLibVersion()
/*      */   {
/* 4353 */     StringBuffer localStringBuffer = new StringBuffer();
/*      */     
/*      */ 
/* 4356 */     int i = String.valueOf(8112).length();
/*      */     
/*      */ 
/* 4359 */     int j = Integer.valueOf(String.valueOf(8112).substring(0, i - 2)).intValue();
/* 4360 */     int k = Integer.valueOf(String.valueOf(8112).substring(i - 2)).intValue();
/*      */     
/*      */ 
/* 4363 */     String str1 = Integer.toHexString(6);
/* 4364 */     String str2 = Integer.toHexString(0);
/* 4365 */     String str3 = Integer.toHexString(j);
/* 4366 */     String str4 = Integer.toHexString(k);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4374 */     if (2 == str4.length()) {
/* 4375 */       localStringBuffer.append(str4);
/*      */     }
/*      */     else {
/* 4378 */       localStringBuffer.append("0");
/* 4379 */       localStringBuffer.append(str4);
/*      */     }
/* 4381 */     if (2 == str3.length()) {
/* 4382 */       localStringBuffer.append(str3);
/*      */     }
/*      */     else {
/* 4385 */       localStringBuffer.append("0");
/* 4386 */       localStringBuffer.append(str3);
/*      */     }
/* 4388 */     if (2 == str2.length()) {
/* 4389 */       localStringBuffer.append(str2);
/*      */     }
/*      */     else {
/* 4392 */       localStringBuffer.append("0");
/* 4393 */       localStringBuffer.append(str2);
/*      */     }
/* 4395 */     if (2 == str1.length()) {
/* 4396 */       localStringBuffer.append(str1);
/*      */     }
/*      */     else {
/* 4399 */       localStringBuffer.append("0");
/* 4400 */       localStringBuffer.append(str1);
/*      */     }
/*      */     
/* 4403 */     return localStringBuffer.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkValidHoldability(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 4414 */     if ((paramInt != 1) && (paramInt != 2))
/*      */     {
/*      */ 
/* 4417 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidHoldability"));
/* 4418 */       SQLServerException.makeFromDriverError(this, this, localMessageFormat.format(new Object[] { Integer.valueOf(paramInt) }), null, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkMatchesCurrentHoldability(int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 4437 */     if (paramInt != this.holdability)
/*      */     {
/* 4439 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_sqlServerHoldability"), null, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLServerException
/*      */   {
/* 4448 */     loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 4449 */     Statement localStatement = createStatement(paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/* 4450 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", localStatement);
/* 4451 */     return localStatement;
/*      */   }
/*      */   
/*      */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*      */   {
/* 4456 */     loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
/* 4457 */     checkClosed();
/* 4458 */     checkValidHoldability(paramInt3);
/* 4459 */     checkMatchesCurrentHoldability(paramInt3);
/* 4460 */     SQLServerStatement localSQLServerStatement = new SQLServerStatement(this, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/* 4461 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", localSQLServerStatement);
/* 4462 */     return localSQLServerStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*      */   {
/* 4467 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 4468 */     PreparedStatement localPreparedStatement = prepareStatement(paramString, paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4474 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localPreparedStatement);
/* 4475 */     return localPreparedStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*      */   {
/* 4480 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
/* 4481 */     checkClosed();
/* 4482 */     checkValidHoldability(paramInt3);
/* 4483 */     checkMatchesCurrentHoldability(paramInt3);
/* 4484 */     SQLServerPreparedStatement localSQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4490 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 4491 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException
/*      */   {
/* 4496 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 4497 */     CallableStatement localCallableStatement = prepareCall(paramString, paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/* 4498 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", localCallableStatement);
/* 4499 */     return localCallableStatement;
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*      */   {
/* 4504 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
/* 4505 */     checkClosed();
/* 4506 */     checkValidHoldability(paramInt3);
/* 4507 */     checkMatchesCurrentHoldability(paramInt3);
/* 4508 */     SQLServerCallableStatement localSQLServerCallableStatement = new SQLServerCallableStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4514 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", localSQLServerCallableStatement);
/* 4515 */     return localSQLServerCallableStatement;
/*      */   }
/*      */   
/*      */ 
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt)
/*      */     throws SQLServerException
/*      */   {
/* 4522 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt) });
/*      */     
/* 4524 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramInt, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/* 4526 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 4527 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*      */   {
/* 4532 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt), paramSQLServerStatementColumnEncryptionSetting });
/* 4533 */     checkClosed();
/* 4534 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
/* 4535 */     localSQLServerPreparedStatement.bRequestedGeneratedKeys = (paramInt == 1);
/* 4536 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 4537 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfInt) throws SQLServerException
/*      */   {
/* 4542 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfInt });
/* 4543 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramArrayOfInt, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/* 4545 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 4546 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*      */   {
/* 4551 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfInt, paramSQLServerStatementColumnEncryptionSetting });
/*      */     
/* 4553 */     checkClosed();
/* 4554 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length != 1)) {
/* 4555 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), null, false);
/*      */     }
/*      */     
/* 4558 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
/* 4559 */     localSQLServerPreparedStatement.bRequestedGeneratedKeys = true;
/* 4560 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 4561 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLServerException
/*      */   {
/* 4566 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfString });
/*      */     
/* 4568 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramArrayOfString, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/* 4570 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 4571 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException
/*      */   {
/* 4576 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfString, paramSQLServerStatementColumnEncryptionSetting });
/* 4577 */     checkClosed();
/* 4578 */     if ((paramArrayOfString == null) || (paramArrayOfString.length != 1))
/*      */     {
/* 4580 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), null, false);
/*      */     }
/*      */     
/* 4583 */     SQLServerPreparedStatement localSQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
/* 4584 */     localSQLServerPreparedStatement.bRequestedGeneratedKeys = true;
/* 4585 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", localSQLServerPreparedStatement);
/* 4586 */     return localSQLServerPreparedStatement;
/*      */   }
/*      */   
/*      */ 
/*      */   public void releaseSavepoint(Savepoint paramSavepoint)
/*      */     throws SQLServerException
/*      */   {
/* 4593 */     loggerExternal.entering(getClassNameLogging(), "releaseSavepoint", paramSavepoint);
/* 4594 */     NotImplemented();
/*      */   }
/*      */   
/*      */   private final Savepoint setNamedSavepoint(String paramString) throws SQLServerException
/*      */   {
/* 4599 */     if (true == this.databaseAutoCommitMode)
/*      */     {
/* 4601 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantSetSavepoint"), null, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4609 */     SQLServerSavepoint localSQLServerSavepoint = new SQLServerSavepoint(this, paramString);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4618 */     connectionCommand("IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN IF @@TRANCOUNT = 2 COMMIT TRAN END SAVE TRAN " + Util.escapeSQLId(localSQLServerSavepoint.getLabel()), "setSavepoint");
/*      */     
/*      */ 
/*      */ 
/* 4622 */     return localSQLServerSavepoint;
/*      */   }
/*      */   
/*      */   public Savepoint setSavepoint(String paramString) throws SQLServerException
/*      */   {
/* 4627 */     loggerExternal.entering(getClassNameLogging(), "setSavepoint", paramString);
/* 4628 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 4630 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4632 */     checkClosed();
/* 4633 */     Savepoint localSavepoint = setNamedSavepoint(paramString);
/* 4634 */     loggerExternal.exiting(getClassNameLogging(), "setSavepoint", localSavepoint);
/* 4635 */     return localSavepoint;
/*      */   }
/*      */   
/*      */   public Savepoint setSavepoint() throws SQLServerException
/*      */   {
/* 4640 */     loggerExternal.entering(getClassNameLogging(), "setSavepoint");
/* 4641 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 4643 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4645 */     checkClosed();
/* 4646 */     Savepoint localSavepoint = setNamedSavepoint(null);
/* 4647 */     loggerExternal.exiting(getClassNameLogging(), "setSavepoint", localSavepoint);
/* 4648 */     return localSavepoint;
/*      */   }
/*      */   
/*      */   public void rollback(Savepoint paramSavepoint) throws SQLServerException
/*      */   {
/* 4653 */     loggerExternal.entering(getClassNameLogging(), "rollback", paramSavepoint);
/* 4654 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 4656 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4658 */     checkClosed();
/* 4659 */     if (true == this.databaseAutoCommitMode)
/*      */     {
/* 4661 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), null, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4668 */     connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN " + Util.escapeSQLId(((SQLServerSavepoint)paramSavepoint).getLabel()), "rollbackSavepoint");
/*      */     
/*      */ 
/* 4671 */     loggerExternal.exiting(getClassNameLogging(), "rollback");
/*      */   }
/*      */   
/*      */   public int getHoldability() throws SQLServerException
/*      */   {
/* 4676 */     loggerExternal.entering(getClassNameLogging(), "getHoldability");
/* 4677 */     if (loggerExternal.isLoggable(Level.FINER))
/* 4678 */       loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(this.holdability));
/* 4679 */     return this.holdability;
/*      */   }
/*      */   
/*      */   public void setHoldability(int paramInt) throws SQLServerException
/*      */   {
/* 4684 */     loggerExternal.entering(getClassNameLogging(), "setHoldability", Integer.valueOf(paramInt));
/*      */     
/* 4686 */     if ((loggerExternal.isLoggable(Level.FINER)) && (Util.IsActivityTraceOn()))
/*      */     {
/* 4688 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4690 */     checkValidHoldability(paramInt);
/* 4691 */     checkClosed();
/*      */     
/* 4693 */     if (this.holdability != paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4698 */       assert ((1 == paramInt) || (2 == paramInt)) : ("invalid holdability " + paramInt);
/*      */       
/* 4700 */       connectionCommand(paramInt == 2 ? "SET CURSOR_CLOSE_ON_COMMIT ON" : "SET CURSOR_CLOSE_ON_COMMIT OFF", "setHoldability");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4706 */       this.holdability = paramInt;
/*      */     }
/*      */     
/* 4709 */     loggerExternal.exiting(getClassNameLogging(), "setHoldability");
/*      */   }
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException
/*      */   {
/* 4714 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/*      */ 
/* 4717 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */   
/*      */   public void setNetworkTimeout(Executor paramExecutor, int paramInt) throws SQLException
/*      */   {
/* 4722 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/*      */ 
/* 4725 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */   
/*      */   public String getSchema() throws SQLException
/*      */   {
/* 4730 */     loggerExternal.entering(getClassNameLogging(), "getSchema");
/*      */     
/* 4732 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/* 4734 */     checkClosed();
/*      */     
/* 4736 */     SQLServerStatement localSQLServerStatement = null;
/* 4737 */     SQLServerResultSet localSQLServerResultSet = null;
/*      */     
/*      */     try
/*      */     {
/* 4741 */       localSQLServerStatement = (SQLServerStatement)createStatement();
/* 4742 */       localSQLServerResultSet = localSQLServerStatement.executeQueryInternal("SELECT SCHEMA_NAME()");
/* 4743 */       if (localSQLServerResultSet != null)
/*      */       {
/* 4745 */         localSQLServerResultSet.next();
/* 4746 */         return localSQLServerResultSet.getString(1);
/*      */       }
/*      */       
/*      */ 
/* 4750 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), null, true);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/*      */ 
/* 4757 */       if (isSessionUnAvailable())
/*      */       {
/* 4759 */         throw localSQLException;
/*      */       }
/*      */       
/* 4762 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), null, true);
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 4768 */       if (localSQLServerResultSet != null)
/*      */       {
/* 4770 */         localSQLServerResultSet.close();
/*      */       }
/* 4772 */       if (localSQLServerStatement != null)
/*      */       {
/* 4774 */         localSQLServerStatement.close();
/*      */       }
/*      */     }
/*      */     
/* 4778 */     loggerExternal.exiting(getClassNameLogging(), "getSchema");
/* 4779 */     return null;
/*      */   }
/*      */   
/*      */   public void setSchema(String paramString) throws SQLException
/*      */   {
/* 4784 */     loggerExternal.entering(getClassNameLogging(), "setSchema", paramString);
/* 4785 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/* 4787 */     checkClosed();
/* 4788 */     addWarning(SQLServerException.getErrString("R_setSchemaWarning"));
/*      */     
/* 4790 */     loggerExternal.exiting(getClassNameLogging(), "setSchema");
/*      */   }
/*      */   
/*      */   public synchronized void setSendTimeAsDatetime(boolean paramBoolean)
/*      */   {
/* 4795 */     this.sendTimeAsDatetime = paramBoolean;
/*      */   }
/*      */   
/*      */   public java.sql.Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException
/*      */   {
/* 4800 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*      */ 
/* 4803 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */   
/*      */   public java.sql.Blob createBlob() throws SQLException
/*      */   {
/* 4808 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4809 */     checkClosed();
/* 4810 */     return new SQLServerBlob(this);
/*      */   }
/*      */   
/*      */   public Clob createClob() throws SQLException
/*      */   {
/* 4815 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4816 */     checkClosed();
/* 4817 */     return new SQLServerClob(this);
/*      */   }
/*      */   
/*      */   public NClob createNClob() throws SQLException
/*      */   {
/* 4822 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4823 */     checkClosed();
/* 4824 */     return new SQLServerNClob(this);
/*      */   }
/*      */   
/*      */   public java.sql.SQLXML createSQLXML() throws SQLException
/*      */   {
/* 4829 */     loggerExternal.entering(getClassNameLogging(), "createSQLXML");
/* 4830 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4831 */     SQLServerSQLXML localSQLServerSQLXML = null;
/* 4832 */     localSQLServerSQLXML = new SQLServerSQLXML(this);
/*      */     
/* 4834 */     if (loggerExternal.isLoggable(Level.FINER))
/* 4835 */       loggerExternal.exiting(getClassNameLogging(), "createSQLXML", localSQLServerSQLXML);
/* 4836 */     return localSQLServerSQLXML;
/*      */   }
/*      */   
/*      */   public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException
/*      */   {
/* 4841 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*      */ 
/* 4844 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */   
/*      */   String getTrustedServerNameAE() throws SQLServerException
/*      */   {
/* 4849 */     return this.trustedServerNameAE.toUpperCase();
/*      */   }
/*      */   
/*      */   public Properties getClientInfo() throws SQLException
/*      */   {
/* 4854 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4855 */     loggerExternal.entering(getClassNameLogging(), "getClientInfo");
/* 4856 */     checkClosed();
/* 4857 */     Properties localProperties = new Properties();
/* 4858 */     loggerExternal.exiting(getClassNameLogging(), "getClientInfo", localProperties);
/* 4859 */     return localProperties;
/*      */   }
/*      */   
/*      */   public String getClientInfo(String paramString) throws SQLException
/*      */   {
/* 4864 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4865 */     loggerExternal.entering(getClassNameLogging(), "getClientInfo", paramString);
/* 4866 */     checkClosed();
/* 4867 */     loggerExternal.exiting(getClassNameLogging(), "getClientInfo", null);
/* 4868 */     return null;
/*      */   }
/*      */   
/*      */   public void setClientInfo(Properties paramProperties) throws SQLClientInfoException
/*      */   {
/* 4873 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4874 */     loggerExternal.entering(getClassNameLogging(), "setClientInfo", paramProperties);
/*      */     
/*      */     Object localObject;
/*      */     try
/*      */     {
/* 4879 */       checkClosed();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException) {
/* 4882 */       localObject = new SQLClientInfoException();
/* 4883 */       ((SQLClientInfoException)localObject).initCause(localSQLServerException);
/* 4884 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 4887 */     if (!paramProperties.isEmpty())
/*      */     {
/* 4889 */       Enumeration localEnumeration = paramProperties.keys();
/* 4890 */       while (localEnumeration.hasMoreElements())
/*      */       {
/* 4892 */         localObject = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
/* 4893 */         Object[] arrayOfObject = { localEnumeration.nextElement() };
/* 4894 */         addWarning(((MessageFormat)localObject).format(arrayOfObject));
/*      */       }
/*      */     }
/* 4897 */     loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
/*      */   }
/*      */   
/*      */   public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException
/*      */   {
/* 4902 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4903 */     loggerExternal.entering(getClassNameLogging(), "setClientInfo", new Object[] { paramString1, paramString2 });
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 4908 */       checkClosed();
/*      */     }
/*      */     catch (SQLServerException localSQLServerException) {
/* 4911 */       localObject = new SQLClientInfoException();
/* 4912 */       ((SQLClientInfoException)localObject).initCause(localSQLServerException);
/* 4913 */       throw ((Throwable)localObject);
/*      */     }
/* 4915 */     MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
/* 4916 */     Object localObject = { paramString1 };
/* 4917 */     addWarning(localMessageFormat.format(localObject));
/* 4918 */     loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isValid(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4942 */     boolean bool = false;
/*      */     
/* 4944 */     loggerExternal.entering(getClassNameLogging(), "isValid", Integer.valueOf(paramInt));
/*      */     
/* 4946 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*      */     Object localObject;
/* 4949 */     if (paramInt < 0)
/*      */     {
/* 4951 */       localObject = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue"));
/* 4952 */       Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 4953 */       SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject).format(arrayOfObject), null, true);
/*      */     }
/*      */     
/*      */ 
/* 4957 */     if (isSessionUnAvailable()) {
/* 4958 */       return false;
/*      */     }
/*      */     try
/*      */     {
/* 4962 */       localObject = new SQLServerStatement(this, 1003, 1007, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4970 */       if (0 != paramInt) {
/* 4971 */         ((SQLServerStatement)localObject).setQueryTimeout(paramInt);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 4977 */       ((SQLServerStatement)localObject).executeQueryInternal("SELECT 1");
/* 4978 */       ((SQLServerStatement)localObject).close();
/* 4979 */       bool = true;
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/*      */ 
/* 4986 */       connectionlogger.fine(toString() + " Exception checking connection validity: " + localSQLException.getMessage());
/*      */     }
/*      */     
/* 4989 */     loggerExternal.exiting(getClassNameLogging(), "isValid", Boolean.valueOf(bool));
/* 4990 */     return bool;
/*      */   }
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException
/*      */   {
/* 4995 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor", paramClass);
/* 4996 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4997 */     boolean bool = paramClass.isInstance(this);
/* 4998 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/* 4999 */     return bool;
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException
/*      */   {
/* 5004 */     loggerExternal.entering(getClassNameLogging(), "unwrap", paramClass);
/* 5005 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     Object localObject;
/*      */     try {
/* 5008 */       localObject = paramClass.cast(this);
/*      */ 
/*      */     }
/*      */     catch (ClassCastException localClassCastException)
/*      */     {
/* 5013 */       SQLServerException localSQLServerException = new SQLServerException(localClassCastException.getMessage(), localClassCastException);
/* 5014 */       throw localSQLServerException;
/*      */     }
/* 5016 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", localObject);
/* 5017 */     return (T)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5028 */   static final char[] OUT = { ' ', 'O', 'U', 'T' };
/*      */   private static final int BROWSER_PORT = 1434;
/*      */   
/*      */   String replaceParameterMarkers(String paramString, Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
/* 5032 */     char[] arrayOfChar = new char[paramString.length() + paramArrayOfParameter.length * (6 + OUT.length)];
/* 5033 */     int i = 0;
/* 5034 */     int j = 0;
/* 5035 */     int k = 0;
/*      */     
/* 5037 */     int m = 0;
/*      */     for (;;)
/*      */     {
/* 5040 */       int n = ParameterUtils.scanSQLForChar('?', paramString, j);
/* 5041 */       paramString.getChars(j, n, arrayOfChar, i);
/* 5042 */       i += n - j;
/*      */       
/* 5044 */       if (paramString.length() == n) {
/*      */         break;
/*      */       }
/* 5047 */       i += makeParamName(k++, arrayOfChar, i);
/* 5048 */       j = n + 1;
/*      */       
/* 5050 */       if (paramArrayOfParameter[(m++)].isOutput())
/*      */       {
/* 5052 */         if ((!paramBoolean) || (m > 1))
/*      */         {
/* 5054 */           System.arraycopy(OUT, 0, arrayOfChar, i, OUT.length);
/* 5055 */           i += OUT.length;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 5060 */     while (i < arrayOfChar.length) {
/* 5061 */       arrayOfChar[(i++)] = ' ';
/*      */     }
/* 5063 */     return new String(arrayOfChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int makeParamName(int paramInt1, char[] paramArrayOfChar, int paramInt2)
/*      */   {
/* 5074 */     paramArrayOfChar[(paramInt2 + 0)] = '@';
/* 5075 */     paramArrayOfChar[(paramInt2 + 1)] = 'P';
/* 5076 */     if (paramInt1 < 10)
/*      */     {
/* 5078 */       paramArrayOfChar[(paramInt2 + 2)] = ((char)(48 + paramInt1));
/* 5079 */       return 3;
/*      */     }
/*      */     
/*      */ 
/* 5083 */     if (paramInt1 < 100)
/*      */     {
/* 5085 */       int i = 2;
/*      */       for (;;)
/*      */       {
/* 5088 */         if (paramInt1 < i * 10)
/*      */         {
/* 5090 */           paramArrayOfChar[(paramInt2 + 2)] = ((char)(48 + (i - 1)));
/* 5091 */           paramArrayOfChar[(paramInt2 + 3)] = ((char)(48 + (paramInt1 - (i - 1) * 10)));
/* 5092 */           return 4;
/*      */         }
/* 5094 */         i++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5099 */     String str = "" + paramInt1;
/* 5100 */     str.getChars(0, str.length(), paramArrayOfChar, paramInt2 + 2);
/* 5101 */     return 2 + str.length();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void notifyPooledConnection(SQLServerException paramSQLServerException)
/*      */   {
/* 5114 */     synchronized (this)
/*      */     {
/* 5116 */       if (null != this.pooledConnectionParent)
/*      */       {
/* 5118 */         this.pooledConnectionParent.notifyEvent(paramSQLServerException);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void DetachFromPool()
/*      */   {
/* 5127 */     synchronized (this)
/*      */     {
/* 5129 */       this.pooledConnectionParent = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getInstancePort(String paramString1, String paramString2)
/*      */     throws SQLServerException
/*      */   {
/* 5144 */     String str1 = null;
/* 5145 */     DatagramSocket localDatagramSocket = null;
/* 5146 */     String str2 = null;
/*      */     Object localObject4;
/*      */     Object localObject3;
/*      */     try {
/* 5150 */       str2 = "Failed to determine instance for the : " + paramString1 + " instance:" + paramString2;
/*      */       
/*      */ 
/* 5153 */       if (null == localDatagramSocket)
/*      */       {
/*      */         try
/*      */         {
/* 5157 */           localDatagramSocket = new DatagramSocket();
/* 5158 */           localDatagramSocket.setSoTimeout(1000);
/*      */ 
/*      */         }
/*      */         catch (SocketException localSocketException)
/*      */         {
/*      */ 
/* 5164 */           str2 = "Unable to create local datagram socket";
/* 5165 */           throw localSocketException;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5173 */       assert (null != localDatagramSocket);
/*      */       try {
/*      */         Object localObject1;
/* 5176 */         if (this.multiSubnetFailover)
/*      */         {
/*      */ 
/* 5179 */           localObject1 = InetAddress.getAllByName(paramString1);
/* 5180 */           assert (null != localObject1);
/* 5181 */           for (InetAddress localInetAddress : localObject1)
/*      */           {
/*      */             try
/*      */             {
/*      */ 
/* 5186 */               byte[] arrayOfByte2 = (" " + paramString2).getBytes();
/* 5187 */               arrayOfByte2[0] = 4;
/* 5188 */               DatagramPacket localDatagramPacket = new DatagramPacket(arrayOfByte2, arrayOfByte2.length, localInetAddress, 1434);
/* 5189 */               localDatagramSocket.send(localDatagramPacket);
/*      */             }
/*      */             catch (IOException localIOException4)
/*      */             {
/* 5193 */               str2 = "Error sending SQL Server Browser Service UDP request to address: " + localInetAddress + ", port: " + 1434;
/* 5194 */               throw localIOException4;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 5201 */           localObject1 = InetAddress.getByName(paramString1);
/*      */           
/* 5203 */           assert (null != localObject1);
/*      */           
/*      */           try
/*      */           {
/* 5207 */             ??? = (" " + paramString2).getBytes();
/* 5208 */             ???[0] = 4;
/* 5209 */             localObject4 = new DatagramPacket((byte[])???, ???.length, (InetAddress)localObject1, 1434);
/* 5210 */             localDatagramSocket.send((DatagramPacket)localObject4);
/*      */           }
/*      */           catch (IOException localIOException3)
/*      */           {
/* 5214 */             str2 = "Error sending SQL Server Browser Service UDP request to address: " + localObject1 + ", port: " + 1434;
/* 5215 */             throw localIOException3;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (UnknownHostException localUnknownHostException)
/*      */       {
/* 5221 */         str2 = "Unable to determine IP address of host: " + paramString1;
/* 5222 */         throw localUnknownHostException;
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 5228 */         byte[] arrayOfByte1 = new byte['က'];
/* 5229 */         localObject3 = new DatagramPacket(arrayOfByte1, arrayOfByte1.length);
/* 5230 */         localDatagramSocket.receive((DatagramPacket)localObject3);
/* 5231 */         str1 = new String(arrayOfByte1, 3, arrayOfByte1.length - 3);
/* 5232 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 5233 */           connectionlogger.fine(toString() + " Received SSRP UDP response from IP address: " + ((DatagramPacket)localObject3).getAddress().getHostAddress().toString());
/*      */         }
/*      */       }
/*      */       catch (IOException localIOException1)
/*      */       {
/* 5238 */         str2 = "Error receiving SQL Server Browser Service UDP response from server: " + paramString1;
/* 5239 */         throw localIOException1;
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/* 5244 */       localObject3 = new MessageFormat(SQLServerException.getErrString("R_sqlBrowserFailed"));
/* 5245 */       localObject4 = new Object[] { paramString1, paramString2, localIOException2.toString() };
/* 5246 */       connectionlogger.log(Level.FINE, toString() + " " + str2, localIOException2);
/* 5247 */       SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject3).format(localObject4), "08001", false);
/*      */     }
/*      */     finally
/*      */     {
/* 5251 */       if (null != localDatagramSocket)
/* 5252 */         localDatagramSocket.close();
/*      */     }
/* 5254 */     assert (null != str1);
/*      */     
/* 5256 */     int i = str1.indexOf("tcp;");
/* 5257 */     if (-1 == i)
/*      */     {
/* 5259 */       localObject3 = new MessageFormat(SQLServerException.getErrString("R_notConfiguredToListentcpip"));
/* 5260 */       localObject4 = new Object[] { paramString2 };
/* 5261 */       SQLServerException.makeFromDriverError(this, this, ((MessageFormat)localObject3).format(localObject4), "08001", false);
/*      */     }
/*      */     
/* 5264 */     int j = i + 4;
/* 5265 */     int m = str1.indexOf(';', j);
/* 5266 */     return str1.substring(j, m);
/*      */   }
/*      */   
/*      */   int getNextSavepointId() {
/* 5270 */     this.nNextSavePointId += 1;
/* 5271 */     return this.nNextSavePointId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void doSecurityCheck()
/*      */   {
/* 5278 */     assert (null != this.currentConnectPlaceHolder);
/* 5279 */     this.currentConnectPlaceHolder.doSecurityCheck();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 5285 */   private static long columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(2L, TimeUnit.HOURS);
/*      */   
/*      */   public static synchronized void setColumnEncryptionKeyCacheTtl(int paramInt, TimeUnit paramTimeUnit) throws SQLServerException
/*      */   {
/* 5289 */     if ((paramInt < 0) || (paramTimeUnit.equals(TimeUnit.MILLISECONDS)) || (paramTimeUnit.equals(TimeUnit.MICROSECONDS)) || (paramTimeUnit.equals(TimeUnit.NANOSECONDS)))
/*      */     {
/* 5291 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidCEKCacheTtl"), null, 0, false);
/*      */     }
/*      */     
/* 5294 */     columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(paramInt, paramTimeUnit);
/*      */   }
/*      */   
/*      */   static synchronized long getColumnEncryptionKeyCacheTtl()
/*      */   {
/* 5299 */     return columnEncryptionKeyCacheTtl;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */