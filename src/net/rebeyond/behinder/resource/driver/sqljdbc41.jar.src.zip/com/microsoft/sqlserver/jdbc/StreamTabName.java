/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamTabName
/*    */   extends StreamPacket
/*    */ {
/*    */   private TDSReader tdsReader;
/*    */   
/*    */ 
/*    */   private TDSReaderMark tableNamesMark;
/*    */   
/*    */ 
/*    */ 
/*    */   StreamTabName()
/*    */   {
/* 17 */     super(164);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 22 */     if ((164 != paramTDSReader.readUnsignedByte()) && 
/* 23 */       (!$assertionsDisabled)) { throw new AssertionError("Not a TABNAME token");
/*    */     }
/* 25 */     this.tdsReader = paramTDSReader;
/* 26 */     int i = paramTDSReader.readUnsignedShort();
/* 27 */     this.tableNamesMark = paramTDSReader.mark();
/* 28 */     paramTDSReader.skip(i);
/*    */   }
/*    */   
/*    */   void applyTo(Column[] paramArrayOfColumn, int paramInt) throws SQLServerException
/*    */   {
/* 33 */     TDSReaderMark localTDSReaderMark = this.tdsReader.mark();
/* 34 */     this.tdsReader.reset(this.tableNamesMark);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 39 */     SQLIdentifier[] arrayOfSQLIdentifier = new SQLIdentifier[paramInt];
/* 40 */     for (int i = 0; i < paramInt; i++) {
/* 41 */       arrayOfSQLIdentifier[i] = this.tdsReader.readSQLIdentifier();
/*    */     }
/*    */     
/* 44 */     for (i = 0; i < paramArrayOfColumn.length; i++)
/*    */     {
/* 46 */       Column localColumn = paramArrayOfColumn[i];
/*    */       
/* 48 */       if (localColumn.getTableNum() > 0) {
/* 49 */         localColumn.setTableName(arrayOfSQLIdentifier[(localColumn.getTableNum() - 1)]);
/*    */       }
/*    */     }
/* 52 */     this.tdsReader.reset(localTDSReaderMark);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamTabName.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */