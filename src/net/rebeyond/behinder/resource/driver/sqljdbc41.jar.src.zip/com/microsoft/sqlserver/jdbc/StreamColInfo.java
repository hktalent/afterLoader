/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamColInfo
/*    */   extends StreamPacket
/*    */ {
/*    */   private TDSReader tdsReader;
/*    */   
/*    */ 
/*    */   private TDSReaderMark colInfoMark;
/*    */   
/*    */ 
/*    */ 
/*    */   StreamColInfo()
/*    */   {
/* 17 */     super(165);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException
/*    */   {
/* 22 */     if ((165 != paramTDSReader.readUnsignedByte()) && 
/* 23 */       (!$assertionsDisabled)) { throw new AssertionError("Not a COLINFO token");
/*    */     }
/* 25 */     this.tdsReader = paramTDSReader;
/* 26 */     int i = paramTDSReader.readUnsignedShort();
/* 27 */     this.colInfoMark = paramTDSReader.mark();
/* 28 */     paramTDSReader.skip(i);
/*    */   }
/*    */   
/*    */   int applyTo(Column[] paramArrayOfColumn) throws SQLServerException
/*    */   {
/* 33 */     int i = 0;
/*    */     
/*    */ 
/* 36 */     TDSReaderMark localTDSReaderMark = this.tdsReader.mark();
/* 37 */     this.tdsReader.reset(this.colInfoMark);
/* 38 */     for (int j = 0; j < paramArrayOfColumn.length; j++)
/*    */     {
/* 40 */       Column localColumn = paramArrayOfColumn[j];
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 45 */       this.tdsReader.readUnsignedByte();
/*    */       
/*    */ 
/*    */ 
/* 49 */       localColumn.setTableNum(this.tdsReader.readUnsignedByte());
/* 50 */       if (localColumn.getTableNum() > i) {
/* 51 */         i = localColumn.getTableNum();
/*    */       }
/*    */       
/* 54 */       localColumn.setInfoStatus(this.tdsReader.readUnsignedByte());
/* 55 */       if (localColumn.hasDifferentName()) {
/* 56 */         localColumn.setBaseColumnName(this.tdsReader.readUnicodeString(this.tdsReader.readUnsignedByte()));
/*    */       }
/*    */     }
/* 59 */     this.tdsReader.reset(localTDSReaderMark);
/* 60 */     return i;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamColInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */