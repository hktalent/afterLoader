/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Vector;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.PooledConnection;
/*     */ import javax.sql.StatementEventListener;
/*     */ 
/*     */ public class SQLServerPooledConnection
/*     */   implements PooledConnection
/*     */ {
/*     */   private final Vector<ConnectionEventListener> listeners;
/*     */   private SQLServerDataSource factoryDataSource;
/*     */   private SQLServerConnection physicalConnection;
/*     */   private SQLServerConnectionPoolProxy lastProxyConnection;
/*     */   private String factoryUser;
/*     */   private String factoryPassword;
/*     */   private Logger pcLogger;
/*  23 */   private static int basePooledConnectionID = 0;
/*     */   private final String traceID;
/*     */   
/*     */   SQLServerPooledConnection(SQLServerDataSource paramSQLServerDataSource, String paramString1, String paramString2)
/*     */     throws SQLException
/*     */   {
/*  29 */     this.listeners = new Vector();
/*     */     
/*  31 */     this.pcLogger = SQLServerDataSource.dsLogger;
/*     */     
/*     */ 
/*  34 */     this.factoryDataSource = paramSQLServerDataSource;
/*  35 */     this.factoryUser = paramString1;
/*  36 */     this.factoryPassword = paramString2;
/*     */     
/*  38 */     if (this.pcLogger.isLoggable(Level.FINER)) {
/*  39 */       this.pcLogger.finer(toString() + " Start create new connection for pool.");
/*     */     }
/*  41 */     this.physicalConnection = createNewConnection();
/*  42 */     String str = getClass().getName();
/*  43 */     this.traceID = (str.substring(1 + str.lastIndexOf('.')) + ":" + nextPooledConnectionID());
/*  44 */     if (this.pcLogger.isLoggable(Level.FINE)) {
/*  45 */       this.pcLogger.fine(toString() + " created by (" + paramSQLServerDataSource.toString() + ")" + " Physical connection " + safeCID() + ", End create new connection for pool");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  53 */     return this.traceID;
/*     */   }
/*     */   
/*     */   private SQLServerConnection createNewConnection()
/*     */     throws SQLException
/*     */   {
/*  59 */     return this.factoryDataSource.getConnectionInternal(this.factoryUser, this.factoryPassword, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*  67 */     if (this.pcLogger.isLoggable(Level.FINER))
/*  68 */       this.pcLogger.finer(toString() + " user:(default).");
/*  69 */     synchronized (this)
/*     */     {
/*     */ 
/*  72 */       if (this.physicalConnection == null)
/*     */       {
/*  74 */         SQLServerException.makeFromDriverError(null, this, SQLServerException.getErrString("R_physicalConnectionIsClosed"), "", true);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */       this.physicalConnection.doSecurityCheck();
/*  82 */       if (this.pcLogger.isLoggable(Level.FINE)) {
/*  83 */         this.pcLogger.fine(toString() + " Physical connection, " + safeCID());
/*     */       }
/*  85 */       if ((null != this.physicalConnection.getAuthenticationResult()) && 
/*  86 */         (Util.checkIfNeedNewAccessToken(this.physicalConnection)))
/*     */       {
/*  88 */         this.physicalConnection = createNewConnection();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  94 */       if (null != this.lastProxyConnection)
/*     */       {
/*     */ 
/*  97 */         this.physicalConnection.resetPooledConnection();
/*  98 */         if ((this.pcLogger.isLoggable(Level.FINE)) && (!this.lastProxyConnection.isClosed())) {
/*  99 */           this.pcLogger.fine(toString() + "proxy " + this.lastProxyConnection.toString() + " is not closed before getting the connection.");
/*     */         }
/* 101 */         this.lastProxyConnection.internalClose();
/*     */       }
/*     */       
/* 104 */       this.lastProxyConnection = new SQLServerConnectionPoolProxy(this.physicalConnection);
/* 105 */       if ((this.pcLogger.isLoggable(Level.FINE)) && (!this.lastProxyConnection.isClosed())) {
/* 106 */         this.pcLogger.fine(toString() + " proxy " + this.lastProxyConnection.toString() + " is returned.");
/*     */       }
/* 108 */       return this.lastProxyConnection;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void notifyEvent(SQLServerException paramSQLServerException)
/*     */   {
/* 119 */     if (this.pcLogger.isLoggable(Level.FINER)) {
/* 120 */       this.pcLogger.finer(toString() + " Exception:" + paramSQLServerException + safeCID());
/*     */     }
/*     */     
/* 123 */     if (null != paramSQLServerException)
/*     */     {
/* 125 */       synchronized (this)
/*     */       {
/* 127 */         if (null != this.lastProxyConnection)
/*     */         {
/* 129 */           this.lastProxyConnection.internalClose();
/* 130 */           this.lastProxyConnection = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 136 */     synchronized (this.listeners)
/*     */     {
/* 138 */       for (int i = 0; i < this.listeners.size(); i++)
/*     */       {
/* 140 */         ConnectionEventListener localConnectionEventListener = (ConnectionEventListener)this.listeners.elementAt(i);
/*     */         
/* 142 */         if (localConnectionEventListener != null)
/*     */         {
/* 144 */           ConnectionEvent localConnectionEvent = new ConnectionEvent(this, paramSQLServerException);
/* 145 */           if (null == paramSQLServerException)
/*     */           {
/* 147 */             if (this.pcLogger.isLoggable(Level.FINER))
/* 148 */               this.pcLogger.finer(toString() + " notifyEvent:connectionClosed " + safeCID());
/* 149 */             localConnectionEventListener.connectionClosed(localConnectionEvent);
/*     */           }
/*     */           else
/*     */           {
/* 153 */             if (this.pcLogger.isLoggable(Level.FINER))
/* 154 */               this.pcLogger.finer(toString() + " notifyEvent:connectionErrorOccurred " + safeCID());
/* 155 */             localConnectionEventListener.connectionErrorOccurred(localConnectionEvent);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addConnectionEventListener(ConnectionEventListener paramConnectionEventListener)
/*     */   {
/* 166 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 167 */       this.pcLogger.finer(toString() + safeCID());
/* 168 */     synchronized (this.listeners)
/*     */     {
/* 170 */       this.listeners.add(paramConnectionEventListener);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 178 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 179 */       this.pcLogger.finer(toString() + " Closing physical connection, " + safeCID());
/* 180 */     synchronized (this)
/*     */     {
/*     */ 
/* 183 */       if (null != this.lastProxyConnection)
/*     */       {
/* 185 */         this.lastProxyConnection.internalClose(); }
/* 186 */       if (null != this.physicalConnection)
/*     */       {
/* 188 */         this.physicalConnection.DetachFromPool();
/* 189 */         this.physicalConnection.close();
/*     */       }
/* 191 */       this.physicalConnection = null;
/*     */     }
/* 193 */     synchronized (this.listeners)
/*     */     {
/* 195 */       this.listeners.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeConnectionEventListener(ConnectionEventListener paramConnectionEventListener)
/*     */   {
/* 204 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 205 */       this.pcLogger.finer(toString() + safeCID());
/* 206 */     synchronized (this.listeners)
/*     */     {
/* 208 */       this.listeners.remove(paramConnectionEventListener);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addStatementEventListener(StatementEventListener paramStatementEventListener)
/*     */   {
/* 214 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/*     */ 
/* 217 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */   
/*     */   public void removeStatementEventListener(StatementEventListener paramStatementEventListener)
/*     */   {
/* 222 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/*     */ 
/* 225 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */   
/*     */ 
/*     */   SQLServerConnection getPhysicalConnection()
/*     */   {
/* 231 */     return this.physicalConnection;
/*     */   }
/*     */   
/*     */ 
/*     */   private static synchronized int nextPooledConnectionID()
/*     */   {
/* 237 */     basePooledConnectionID += 1;
/* 238 */     return basePooledConnectionID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String safeCID()
/*     */   {
/* 245 */     if (null == this.physicalConnection) return " ConnectionID:(null)";
/* 246 */     return this.physicalConnection.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerPooledConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */