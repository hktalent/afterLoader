/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.Statement;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerParameterMetaData
/*     */   implements ParameterMetaData
/*     */ {
/*     */   private static final int SQL_SERVER_2012_VERSION = 11;
/*     */   private final SQLServerStatement stmtParent;
/*     */   private SQLServerConnection con;
/*     */   private Statement stmtCall;
/*     */   private SQLServerResultSet rsProcedureMeta;
/*  37 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerParameterMetaData");
/*     */   
/*     */ 
/*  40 */   private static int baseID = 0;
/*  41 */   private final String traceID = " SQLServerParameterMetaData:" + nextInstanceID();
/*     */   
/*     */   private static synchronized int nextInstanceID()
/*     */   {
/*  45 */     baseID += 1;
/*  46 */     return baseID;
/*     */   }
/*     */   
/*     */   public final String toString() {
/*  50 */     return this.traceID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String parseColumns(String paramString1, String paramString2)
/*     */   {
/*  60 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, " =?<>!", true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */     int i = 0;
/*  67 */     Object localObject = null;
/*  68 */     StringBuilder localStringBuilder = new StringBuilder();
/*     */     
/*  70 */     while (localStringTokenizer.hasMoreTokens())
/*     */     {
/*     */ 
/*  73 */       String str1 = localStringTokenizer.nextToken();
/*  74 */       if (str1.equalsIgnoreCase(paramString2))
/*     */       {
/*  76 */         i = 1;
/*     */ 
/*     */       }
/*  79 */       else if (i != 0)
/*     */       {
/*  81 */         if ((str1.charAt(0) == '=') || (str1.equalsIgnoreCase("is")) || (str1.charAt(0) == '<') || (str1.charAt(0) == '>') || (str1.equalsIgnoreCase("like")) || (str1.equalsIgnoreCase("not")) || (str1.equalsIgnoreCase("in")) || (str1.charAt(0) == '!'))
/*     */         {
/*     */ 
/*     */ 
/*  85 */           i = 2;
/*     */ 
/*     */         }
/*  88 */         else if ((str1.charAt(0) == '?') && (localObject != null))
/*     */         {
/*  90 */           if (localStringBuilder.length() != 0)
/*     */           {
/*  92 */             localStringBuilder.append(", ");
/*     */           }
/*  94 */           localStringBuilder.append((String)localObject);
/*  95 */           i = 1;
/*  96 */           localObject = null;
/*     */ 
/*     */         }
/*  99 */         else if (i == 1)
/*     */         {
/*     */ 
/* 102 */           if (!str1.equals(" "))
/*     */           {
/* 104 */             String str2 = escapeParse(localStringTokenizer, str1);
/* 105 */             if (str2.length() > 0)
/*     */             {
/* 107 */               localObject = str2; }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 112 */     return localStringBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String parseInsertColumns(String paramString1, String paramString2)
/*     */   {
/* 121 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, " (),", true);
/* 122 */     int i = 0;
/* 123 */     String str1 = null;
/* 124 */     StringBuilder localStringBuilder = new StringBuilder();
/*     */     
/* 126 */     while (localStringTokenizer.hasMoreTokens()) {
/* 127 */       String str2 = localStringTokenizer.nextToken();
/* 128 */       if (str2.equalsIgnoreCase(paramString2)) {
/* 129 */         i = 1;
/*     */ 
/*     */       }
/* 132 */       else if (i != 0)
/*     */       {
/* 134 */         if (str2.charAt(0) == '=') {
/* 135 */           i = 2;
/*     */         }
/*     */         else {
/* 138 */           if (((str2.charAt(0) == ',') || (str2.charAt(0) == ')') || (str2.charAt(0) == ' ')) && (str1 != null))
/*     */           {
/*     */ 
/* 141 */             if (localStringBuilder.length() != 0)
/* 142 */               localStringBuilder.append(", ");
/* 143 */             localStringBuilder.append(str1);
/* 144 */             i = 1;
/* 145 */             str1 = null;
/*     */           }
/* 147 */           if (str2.charAt(0) == ')') {
/* 148 */             i = 0;
/* 149 */             break;
/*     */           }
/* 151 */           if ((i == 1) && 
/* 152 */             (str2.trim().length() > 0) && 
/* 153 */             (str2.charAt(0) != ',')) {
/* 154 */             str1 = escapeParse(localStringTokenizer, str2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 159 */     return localStringBuilder.toString();
/*     */   }
/*     */   
/*     */   class QueryMeta {
/*     */     QueryMeta() {}
/*     */     
/* 165 */     String parameterClassName = null;
/* 166 */     int parameterType = 0;
/* 167 */     String parameterTypeName = null;
/* 168 */     int precision = 0;
/* 169 */     int scale = 0;
/* 170 */     int isNullable = 2;
/* 171 */     boolean isSigned = false;
/*     */      }
/* 173 */   Map<Integer, QueryMeta> queryMetaMap = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private void parseQueryMeta(ResultSet paramResultSet)
/*     */     throws SQLServerException
/*     */   {
/* 180 */     Pattern localPattern = Pattern.compile("(.*)\\((.*)(\\)|,(.*)\\))");
/*     */     try {
/* 182 */       while (paramResultSet.next())
/*     */       {
/* 184 */         QueryMeta localQueryMeta = new QueryMeta();
/* 185 */         SSType localSSType = null;
/*     */         
/* 187 */         int i = paramResultSet.getInt("parameter_ordinal");
/* 188 */         String str = paramResultSet.getString("suggested_system_type_name");
/*     */         
/* 190 */         if (null == str) {
/* 191 */           str = paramResultSet.getString("suggested_user_type_name");
/* 192 */           localObject = (SQLServerPreparedStatement)this.con.prepareCall("select max_length, precision, scale, is_nullable from sys.assembly_types where name = ?");
/* 193 */           ((SQLServerPreparedStatement)localObject).setNString(1, str);
/* 194 */           ResultSet localResultSet = ((SQLServerPreparedStatement)localObject).executeQuery();
/* 195 */           if (localResultSet.next()) {
/* 196 */             localQueryMeta.parameterTypeName = str;
/* 197 */             localQueryMeta.precision = localResultSet.getInt("max_length");
/* 198 */             localQueryMeta.scale = localResultSet.getInt("scale");
/* 199 */             localSSType = SSType.UDT;
/*     */           }
/*     */         }
/*     */         else {
/* 203 */           localQueryMeta.precision = paramResultSet.getInt("suggested_precision");
/* 204 */           localQueryMeta.scale = paramResultSet.getInt("suggested_scale");
/*     */           
/*     */ 
/* 207 */           localObject = localPattern.matcher(str);
/* 208 */           if (((Matcher)localObject).matches())
/*     */           {
/*     */ 
/* 211 */             localSSType = SSType.of(((Matcher)localObject).group(1));
/* 212 */             if ((str.equalsIgnoreCase("varchar(max)")) || (str.equalsIgnoreCase("varbinary(max)")))
/*     */             {
/*     */ 
/* 215 */               localQueryMeta.precision = Integer.MAX_VALUE;
/*     */             }
/* 217 */             else if (str.equalsIgnoreCase("nvarchar(max)"))
/*     */             {
/* 219 */               localQueryMeta.precision = 1073741823;
/*     */             }
/* 221 */             else if ((SSType.Category.CHARACTER == localSSType.category) || (SSType.Category.BINARY == localSSType.category) || (SSType.Category.NCHARACTER == localSSType.category))
/*     */             {
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/* 228 */                 localQueryMeta.precision = Integer.parseInt(((Matcher)localObject).group(2));
/*     */               }
/*     */               catch (NumberFormatException localNumberFormatException)
/*     */               {
/* 232 */                 MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
/* 233 */                 Object[] arrayOfObject = { new Integer(i) };
/* 234 */                 SQLServerException.makeFromDriverError(this.con, this.stmtParent, localMessageFormat.format(arrayOfObject) + " " + localNumberFormatException.toString(), null, false);
/*     */               }
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 240 */             localSSType = SSType.of(str);
/*     */           }
/*     */           
/* 243 */           if (SSType.FLOAT == localSSType)
/*     */           {
/*     */ 
/*     */ 
/* 247 */             localQueryMeta.precision = 15;
/*     */           }
/* 249 */           else if (SSType.REAL == localSSType)
/*     */           {
/* 251 */             localQueryMeta.precision = 7;
/*     */           }
/* 253 */           else if (SSType.TEXT == localSSType)
/*     */           {
/* 255 */             localQueryMeta.precision = Integer.MAX_VALUE;
/*     */           }
/* 257 */           else if (SSType.NTEXT == localSSType)
/*     */           {
/* 259 */             localQueryMeta.precision = 1073741823;
/*     */           }
/* 261 */           else if (SSType.IMAGE == localSSType)
/*     */           {
/* 263 */             localQueryMeta.precision = Integer.MAX_VALUE;
/*     */           }
/* 265 */           else if (SSType.GUID == localSSType)
/*     */           {
/* 267 */             localQueryMeta.precision = 36;
/*     */           }
/* 269 */           else if (SSType.TIMESTAMP == localSSType)
/*     */           {
/* 271 */             localQueryMeta.precision = 8;
/*     */           }
/* 273 */           else if (SSType.XML == localSSType)
/*     */           {
/* 275 */             localQueryMeta.precision = 1073741823;
/*     */           }
/*     */           
/* 278 */           localQueryMeta.parameterTypeName = localSSType.toString();
/*     */         }
/*     */         
/*     */ 
/* 282 */         if (null == localSSType)
/*     */         {
/* 284 */           throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), null);
/*     */         }
/*     */         
/* 287 */         Object localObject = localSSType.getJDBCType();
/* 288 */         localQueryMeta.parameterClassName = ((JDBCType)localObject).className();
/* 289 */         localQueryMeta.parameterType = ((JDBCType)localObject).getIntValue();
/*     */         
/* 291 */         localQueryMeta.isSigned = ((SSType.Category.NUMERIC == localSSType.category) && (SSType.BIT != localSSType) && (SSType.TINYINT != localSSType));
/* 292 */         this.queryMetaMap.put(Integer.valueOf(i), localQueryMeta);
/*     */       }
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 297 */       throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), localSQLException);
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseQueryMetaFor2008(ResultSet paramResultSet)
/*     */     throws SQLServerException
/*     */   {
/*     */     try
/*     */     {
/* 306 */       ResultSetMetaData localResultSetMetaData = paramResultSet.getMetaData();
/*     */       
/* 308 */       for (int i = 1; i <= localResultSetMetaData.getColumnCount(); i++) {
/* 309 */         QueryMeta localQueryMeta = new QueryMeta();
/*     */         
/* 311 */         localQueryMeta.parameterClassName = localResultSetMetaData.getColumnClassName(i);
/* 312 */         localQueryMeta.parameterType = localResultSetMetaData.getColumnType(i);
/* 313 */         localQueryMeta.parameterTypeName = localResultSetMetaData.getColumnTypeName(i);
/* 314 */         localQueryMeta.precision = localResultSetMetaData.getPrecision(i);
/* 315 */         localQueryMeta.scale = localResultSetMetaData.getScale(i);
/* 316 */         localQueryMeta.isNullable = localResultSetMetaData.isNullable(i);
/* 317 */         localQueryMeta.isSigned = localResultSetMetaData.isSigned(i);
/*     */         
/* 319 */         this.queryMetaMap.put(Integer.valueOf(i), localQueryMeta);
/*     */       }
/*     */     }
/*     */     catch (SQLException localSQLException) {
/* 323 */       throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), localSQLException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String escapeParse(StringTokenizer paramStringTokenizer, String paramString)
/*     */   {
/* 337 */     String str1 = paramString;
/*     */     
/* 339 */     while ((str1.equals(" ")) && (paramStringTokenizer.hasMoreTokens()))
/*     */     {
/* 341 */       str1 = paramStringTokenizer.nextToken();
/*     */     }
/* 343 */     String str2 = str1;
/* 344 */     if ((str1.charAt(0) == '[') && (str1.charAt(str1.length() - 1) != ']'))
/*     */     {
/* 346 */       while (paramStringTokenizer.hasMoreTokens())
/*     */       {
/* 348 */         str1 = paramStringTokenizer.nextToken();
/* 349 */         str2 = str2.concat(str1);
/* 350 */         if (str1.charAt(str1.length() - 1) == ']') {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 357 */     str2 = str2.trim();
/* 358 */     return str2;
/*     */   }
/*     */   
/*     */   private class MetaInfo
/*     */   {
/*     */     String table;
/*     */     String fields;
/*     */     
/*     */     MetaInfo(String paramString1, String paramString2)
/*     */     {
/* 368 */       this.table = paramString1;
/* 369 */       this.fields = paramString2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MetaInfo parseStatement(String paramString1, String paramString2)
/*     */   {
/* 380 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, " ,", true);
/*     */     
/*     */ 
/*     */ 
/* 384 */     String str1 = null;
/* 385 */     String str2 = "";
/* 386 */     while (localStringTokenizer.hasMoreTokens())
/*     */     {
/* 388 */       String str3 = localStringTokenizer.nextToken().trim();
/*     */       
/* 390 */       if (str3.equalsIgnoreCase(paramString2))
/*     */       {
/* 392 */         if (localStringTokenizer.hasMoreTokens())
/*     */         {
/* 394 */           str1 = escapeParse(localStringTokenizer, localStringTokenizer.nextToken());
/* 395 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 400 */     if (null != str1)
/*     */     {
/* 402 */       if (paramString2.equalsIgnoreCase("UPDATE")) {
/* 403 */         str2 = parseColumns(paramString1, "SET");
/* 404 */       } else if (paramString2.equalsIgnoreCase("INTO")) {
/* 405 */         str2 = parseInsertColumns(paramString1, "(");
/*     */       } else {
/* 407 */         str2 = parseColumns(paramString1, "WHERE");
/*     */       }
/* 409 */       return new MetaInfo(str1, str2);
/*     */     }
/*     */     
/* 412 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MetaInfo parseStatement(String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 422 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " ");
/* 423 */     if (localStringTokenizer.hasMoreTokens())
/*     */     {
/* 425 */       String str = localStringTokenizer.nextToken().trim();
/*     */       
/* 427 */       if (str.equalsIgnoreCase("INSERT")) {
/* 428 */         return parseStatement(paramString, "INTO");
/*     */       }
/* 430 */       if (str.equalsIgnoreCase("UPDATE")) {
/* 431 */         return parseStatement(paramString, "UPDATE");
/*     */       }
/* 433 */       if (str.equalsIgnoreCase("SELECT")) {
/* 434 */         return parseStatement(paramString, "FROM");
/*     */       }
/* 436 */       if (str.equalsIgnoreCase("DELETE")) {
/* 437 */         return parseStatement(paramString, "FROM");
/*     */       }
/*     */     }
/* 440 */     return null;
/*     */   }
/*     */   
/*     */   String parseThreePartNames(String paramString) throws SQLServerException
/*     */   {
/* 445 */     int i = 0;
/* 446 */     Object localObject1 = null;
/* 447 */     Object localObject2 = null;
/* 448 */     Object localObject3 = null;
/* 449 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ".", true);
/*     */     
/*     */ 
/*     */ 
/* 453 */     while (localStringTokenizer.hasMoreTokens())
/*     */     {
/* 455 */       localObject4 = localStringTokenizer.nextToken();
/* 456 */       String str = escapeParse(localStringTokenizer, (String)localObject4);
/* 457 */       if (!str.equals("."))
/*     */       {
/* 459 */         switch (i)
/*     */         {
/*     */         case 2: 
/* 462 */           localObject3 = localObject2;
/* 463 */           localObject2 = localObject1;
/* 464 */           localObject1 = str;
/* 465 */           i++;
/* 466 */           break;
/*     */         case 1: 
/* 468 */           localObject2 = localObject1;
/* 469 */           localObject1 = str;
/* 470 */           i++;
/* 471 */           break;
/*     */         case 0: 
/* 473 */           localObject1 = str;
/* 474 */           i++;
/* 475 */           break;
/*     */         default: 
/* 477 */           i++;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 482 */     Object localObject4 = new StringBuilder(100);
/*     */     
/* 484 */     if ((i > 3) && (1 < i)) {
/* 485 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
/*     */     }
/* 487 */     switch (i)
/*     */     {
/*     */     case 3: 
/* 490 */       ((StringBuilder)localObject4).append("@procedure_qualifier =");
/* 491 */       ((StringBuilder)localObject4).append((String)localObject3);
/* 492 */       ((StringBuilder)localObject4).append(", ");
/* 493 */       ((StringBuilder)localObject4).append("@procedure_owner =");
/* 494 */       ((StringBuilder)localObject4).append((String)localObject2);
/* 495 */       ((StringBuilder)localObject4).append(", ");
/* 496 */       ((StringBuilder)localObject4).append("@procedure_name =");
/* 497 */       ((StringBuilder)localObject4).append((String)localObject1);
/* 498 */       ((StringBuilder)localObject4).append(", ");
/* 499 */       break;
/*     */     
/*     */     case 2: 
/* 502 */       ((StringBuilder)localObject4).append("@procedure_owner =");
/* 503 */       ((StringBuilder)localObject4).append((String)localObject2);
/* 504 */       ((StringBuilder)localObject4).append(", ");
/* 505 */       ((StringBuilder)localObject4).append("@procedure_name =");
/* 506 */       ((StringBuilder)localObject4).append((String)localObject1);
/* 507 */       ((StringBuilder)localObject4).append(", ");
/* 508 */       break;
/*     */     case 1: 
/* 510 */       ((StringBuilder)localObject4).append("@procedure_name =");
/* 511 */       ((StringBuilder)localObject4).append((String)localObject1);
/* 512 */       ((StringBuilder)localObject4).append(", ");
/* 513 */       break;
/*     */     }
/*     */     
/*     */     
/* 517 */     return ((StringBuilder)localObject4).toString();
/*     */   }
/*     */   
/*     */   private void checkClosed()
/*     */     throws SQLServerException
/*     */   {
/* 523 */     this.stmtParent.checkClosed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLServerParameterMetaData(SQLServerStatement paramSQLServerStatement, String paramString)
/*     */     throws SQLServerException
/*     */   {
/* 535 */     assert (null != paramSQLServerStatement);
/* 536 */     this.stmtParent = paramSQLServerStatement;
/* 537 */     this.con = paramSQLServerStatement.connection;
/* 538 */     if (logger.isLoggable(Level.FINE))
/*     */     {
/* 540 */       logger.fine(toString() + " created by (" + paramSQLServerStatement.toString() + ")");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*     */       Object localObject1;
/*     */       Object localObject2;
/* 547 */       if (null != paramSQLServerStatement.procedureName)
/*     */       {
/* 549 */         localObject1 = (SQLServerStatement)this.con.createStatement(1004, 1007);
/* 550 */         localObject2 = parseThreePartNames(paramSQLServerStatement.procedureName);
/* 551 */         if (this.con.isKatmaiOrLater()) {
/* 552 */           this.rsProcedureMeta = ((SQLServerStatement)localObject1).executeQueryInternal("exec sp_sproc_columns_100 " + (String)localObject2 + " @ODBCVer=3");
/*     */         } else {
/* 554 */           this.rsProcedureMeta = ((SQLServerStatement)localObject1).executeQueryInternal("exec sp_sproc_columns " + (String)localObject2 + " @ODBCVer=3");
/*     */         }
/* 556 */         this.rsProcedureMeta.getColumn(6).setFilter(new DataTypeFilter());
/* 557 */         if (this.con.isKatmaiOrLater())
/*     */         {
/* 559 */           this.rsProcedureMeta.getColumn(8).setFilter(new ZeroFixupFilter());
/* 560 */           this.rsProcedureMeta.getColumn(9).setFilter(new ZeroFixupFilter());
/* 561 */           this.rsProcedureMeta.getColumn(17).setFilter(new ZeroFixupFilter());
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 571 */         this.queryMetaMap = new HashMap();
/*     */         
/* 573 */         if (this.con.getServerMajorVersion() >= 11)
/*     */         {
/* 575 */           localObject1 = this.con.replaceParameterMarkers(((SQLServerPreparedStatement)this.stmtParent).userSQL, ((SQLServerPreparedStatement)this.stmtParent).inOutParam, ((SQLServerPreparedStatement)this.stmtParent).bReturnValueSyntax);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 580 */           localObject2 = (SQLServerCallableStatement)this.con.prepareCall("exec sp_describe_undeclared_parameters ?");
/* 581 */           ((SQLServerCallableStatement)localObject2).setNString(1, (String)localObject1);
/* 582 */           parseQueryMeta(((SQLServerCallableStatement)localObject2).executeQueryInternal());
/* 583 */           ((SQLServerCallableStatement)localObject2).close();
/*     */         }
/*     */         else
/*     */         {
/* 587 */           localObject1 = parseStatement(paramString);
/* 588 */           if (null == localObject1)
/*     */           {
/* 590 */             localObject2 = new MessageFormat(SQLServerException.getErrString("R_cantIdentifyTableMetadata"));
/* 591 */             localObject3 = new Object[] { new String(paramString) };
/* 592 */             SQLServerException.makeFromDriverError(this.con, this.stmtParent, ((MessageFormat)localObject2).format(localObject3), null, false);
/*     */           }
/*     */           
/* 595 */           if (((MetaInfo)localObject1).fields.length() <= 0) {
/* 596 */             return;
/*     */           }
/* 598 */           localObject2 = this.con.createStatement();
/* 599 */           Object localObject3 = "sp_executesql N'SET FMTONLY ON SELECT " + ((MetaInfo)localObject1).fields + " FROM " + ((MetaInfo)localObject1).table + " WHERE 1 = 2'";
/* 600 */           ResultSet localResultSet = ((Statement)localObject2).executeQuery((String)localObject3);
/* 601 */           parseQueryMetaFor2008(localResultSet);
/* 602 */           ((Statement)localObject2).close();
/* 603 */           localResultSet.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 609 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException
/*     */   {
/* 615 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 617 */     return false;
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException
/*     */   {
/* 622 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 623 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */   
/*     */   private void verifyParameterPosition(int paramInt) throws SQLServerException
/*     */   {
/* 628 */     boolean bool = false;
/*     */     Object localObject;
/* 630 */     try { bool = this.rsProcedureMeta.absolute(paramInt + 1);
/*     */     }
/*     */     catch (SQLException localSQLException) {
/* 633 */       localObject = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
/* 634 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 635 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, ((MessageFormat)localObject).format(arrayOfObject) + " " + localSQLException.toString(), null, false);
/*     */     }
/*     */     
/* 638 */     if (!bool) {
/* 639 */       MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidParameterNumber"));
/* 640 */       localObject = new Object[] { new Integer(paramInt) };
/* 641 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localMessageFormat.format(localObject), null, false);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkParam(int paramInt) throws SQLServerException
/*     */   {
/* 647 */     if (!this.queryMetaMap.containsKey(Integer.valueOf(paramInt)))
/*     */     {
/* 649 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getParameterClassName(int paramInt) throws SQLServerException {
/* 654 */     checkClosed();
/*     */     try {
/* 656 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 658 */         checkParam(paramInt);
/* 659 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterClassName;
/*     */       }
/*     */       
/* 662 */       verifyParameterPosition(paramInt);
/* 663 */       JDBCType localJDBCType = JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE"));
/* 664 */       return localJDBCType.className();
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 668 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 669 */     return null;
/*     */   }
/*     */   
/*     */   public int getParameterCount() throws SQLServerException
/*     */   {
/* 674 */     checkClosed();
/*     */     try {
/* 676 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 678 */         return this.queryMetaMap.size();
/*     */       }
/*     */       
/* 681 */       this.rsProcedureMeta.last();
/* 682 */       int i = this.rsProcedureMeta.getRow() - 1;
/* 683 */       if (i < 0) {}
/* 684 */       return 0;
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 689 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 690 */     return 0;
/*     */   }
/*     */   
/*     */   public int getParameterMode(int paramInt) throws SQLServerException
/*     */   {
/* 695 */     checkClosed();
/*     */     try {
/* 697 */       if (this.rsProcedureMeta == null) {
/* 698 */         checkParam(paramInt);
/*     */         
/* 700 */         return 1;
/*     */       }
/*     */       
/* 703 */       verifyParameterPosition(paramInt);
/* 704 */       int i = this.rsProcedureMeta.getInt("COLUMN_TYPE");
/* 705 */       switch (i) {
/*     */       case 1: 
/* 707 */         return 1;
/*     */       case 2: 
/* 709 */         return 4;
/*     */       }
/* 711 */       return 0;
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 716 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 717 */     return 0;
/*     */   }
/*     */   
/*     */   public int getParameterType(int paramInt) throws SQLServerException
/*     */   {
/* 722 */     checkClosed();
/*     */     try
/*     */     {
/*     */       int i;
/* 726 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 728 */         checkParam(paramInt);
/* 729 */         i = ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterType;
/*     */       }
/*     */       else {
/* 732 */         verifyParameterPosition(paramInt);
/* 733 */         i = this.rsProcedureMeta.getShort("DATA_TYPE");
/*     */       }
/*     */       
/* 736 */       switch (i)
/*     */       {
/*     */       case -151: 
/*     */       case -150: 
/* 740 */         i = SSType.DATETIME2.getJDBCType().asJavaSqlType();
/* 741 */         break;
/*     */       case -148: 
/*     */       case -146: 
/* 744 */         i = SSType.DECIMAL.getJDBCType().asJavaSqlType();
/* 745 */         break;
/*     */       }
/* 747 */       return SSType.CHAR.getJDBCType().asJavaSqlType();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/*     */ 
/* 754 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 755 */     return 0;
/*     */   }
/*     */   
/*     */   public String getParameterTypeName(int paramInt) throws SQLServerException
/*     */   {
/* 760 */     checkClosed();
/*     */     try {
/* 762 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 764 */         checkParam(paramInt);
/* 765 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterTypeName;
/*     */       }
/*     */       
/* 768 */       verifyParameterPosition(paramInt);
/* 769 */       return this.rsProcedureMeta.getString("TYPE_NAME");
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 773 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 774 */     return null;
/*     */   }
/*     */   
/*     */   public int getPrecision(int paramInt) throws SQLServerException
/*     */   {
/* 779 */     checkClosed();
/*     */     try {
/* 781 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 783 */         checkParam(paramInt);
/* 784 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).precision;
/*     */       }
/*     */       
/* 787 */       verifyParameterPosition(paramInt);
/* 788 */       return this.rsProcedureMeta.getInt("PRECISION");
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 793 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 794 */     return 0;
/*     */   }
/*     */   
/*     */   public int getScale(int paramInt) throws SQLServerException
/*     */   {
/* 799 */     checkClosed();
/*     */     try {
/* 801 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 803 */         checkParam(paramInt);
/* 804 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).scale;
/*     */       }
/*     */       
/* 807 */       verifyParameterPosition(paramInt);
/* 808 */       return this.rsProcedureMeta.getInt("SCALE");
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 813 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 814 */     return 0;
/*     */   }
/*     */   
/*     */   public int isNullable(int paramInt) throws SQLServerException
/*     */   {
/* 819 */     checkClosed();
/*     */     try {
/* 821 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 823 */         checkParam(paramInt);
/* 824 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).isNullable;
/*     */       }
/*     */       
/* 827 */       verifyParameterPosition(paramInt);
/* 828 */       int i = this.rsProcedureMeta.getInt("NULLABLE");
/* 829 */       if (i == 1)
/* 830 */         return 1;
/* 831 */       if (i == 0)
/* 832 */         return 0;
/* 833 */       return 2;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 837 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 838 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSigned(int paramInt)
/*     */     throws SQLServerException
/*     */   {
/* 849 */     checkClosed();
/*     */     try {
/* 851 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 853 */         checkParam(paramInt);
/* 854 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).isSigned;
/*     */       }
/*     */       
/* 857 */       verifyParameterPosition(paramInt);
/* 858 */       return JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE")).isSigned();
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 862 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, localSQLException.toString(), null, false); }
/* 863 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerParameterMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */