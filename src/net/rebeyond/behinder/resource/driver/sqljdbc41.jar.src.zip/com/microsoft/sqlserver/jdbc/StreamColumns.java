/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StreamColumns
/*     */   extends StreamPacket
/*     */ {
/*     */   private Column[] columns;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  17 */   private CekTable cekTable = null;
/*     */   
/*  19 */   private boolean shouldHonorAEForRead = false;
/*     */   
/*     */ 
/*     */   CekTable getCekTable()
/*     */   {
/*  24 */     return this.cekTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   StreamColumns()
/*     */   {
/*  31 */     super(129);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   StreamColumns(boolean paramBoolean)
/*     */   {
/*  38 */     super(129);
/*  39 */     this.shouldHonorAEForRead = paramBoolean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CekTableEntry readCEKTableEntry(TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/*  50 */     int i = paramTDSReader.readInt();
/*     */     
/*     */ 
/*  53 */     int j = paramTDSReader.readInt();
/*     */     
/*     */ 
/*  56 */     int k = paramTDSReader.readInt();
/*     */     
/*     */ 
/*  59 */     byte[] arrayOfByte1 = new byte[8];
/*  60 */     paramTDSReader.readBytes(arrayOfByte1, 0, 8);
/*     */     
/*     */ 
/*  63 */     int m = paramTDSReader.readUnsignedByte();
/*     */     
/*  65 */     CekTableEntry localCekTableEntry = new CekTableEntry(m);
/*     */     
/*  67 */     for (int n = 0; n < m; n++)
/*     */     {
/*  69 */       int i1 = paramTDSReader.readShort();
/*     */       
/*  71 */       byte[] arrayOfByte2 = new byte[i1];
/*     */       
/*     */ 
/*  74 */       paramTDSReader.readBytes(arrayOfByte2, 0, i1);
/*     */       
/*     */ 
/*  77 */       int i2 = paramTDSReader.readUnsignedByte();
/*     */       
/*     */ 
/*  80 */       String str1 = paramTDSReader.readUnicodeString(i2);
/*     */       
/*     */ 
/*  83 */       int i3 = paramTDSReader.readShort();
/*     */       
/*     */ 
/*  86 */       String str2 = paramTDSReader.readUnicodeString(i3);
/*     */       
/*     */ 
/*  89 */       int i4 = paramTDSReader.readUnsignedByte();
/*     */       
/*     */ 
/*  92 */       String str3 = paramTDSReader.readUnicodeString(i4);
/*     */       
/*     */ 
/*  95 */       localCekTableEntry.add(arrayOfByte2, i, j, k, arrayOfByte1, str2, str1, str3);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */     return localCekTableEntry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void readCEKTable(TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 116 */     int i = paramTDSReader.readShort();
/*     */     
/*     */ 
/*     */ 
/* 120 */     if (0 != i) {
/* 121 */       this.cekTable = new CekTable(i);
/*     */       
/*     */ 
/* 124 */       for (int j = 0; j < i; j++)
/*     */       {
/* 126 */         this.cekTable.setCekTableEntry(j, readCEKTableEntry(paramTDSReader));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CryptoMetadata readCryptoMetadata(TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 139 */     short s = 0;
/*     */     
/* 141 */     if (null != this.cekTable)
/*     */     {
/* 143 */       s = paramTDSReader.readShort();
/*     */     }
/*     */     
/* 146 */     TypeInfo localTypeInfo = TypeInfo.getInstance(paramTDSReader, false);
/*     */     
/*     */ 
/* 149 */     byte b1 = (byte)paramTDSReader.readUnsignedByte();
/*     */     
/* 151 */     String str = null;
/* 152 */     if (0 == b1)
/*     */     {
/* 154 */       i = paramTDSReader.readUnsignedByte();
/* 155 */       str = paramTDSReader.readUnicodeString(i);
/*     */     }
/*     */     
/*     */ 
/* 159 */     int i = (byte)paramTDSReader.readUnsignedByte();
/*     */     
/*     */ 
/* 162 */     byte b2 = (byte)paramTDSReader.readUnsignedByte();
/*     */     
/* 164 */     CryptoMetadata localCryptoMetadata = new CryptoMetadata(this.cekTable == null ? null : this.cekTable.getCekTableEntry(s), s, b1, str, i, b2);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 171 */     localCryptoMetadata.setBaseTypeInfo(localTypeInfo);
/*     */     
/* 173 */     return localCryptoMetadata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setFromTDS(TDSReader paramTDSReader)
/*     */     throws SQLServerException
/*     */   {
/* 183 */     if ((129 != paramTDSReader.readUnsignedByte()) && (!$assertionsDisabled)) { throw new AssertionError();
/*     */     }
/* 185 */     int i = paramTDSReader.readUnsignedShort();
/*     */     
/*     */ 
/* 188 */     if (65535 == i) {
/* 189 */       return;
/*     */     }
/* 191 */     if (paramTDSReader.getServerSupportsColumnEncryption())
/*     */     {
/* 193 */       readCEKTable(paramTDSReader);
/*     */     }
/*     */     
/* 196 */     this.columns = new Column[i];
/*     */     
/* 198 */     for (int j = 0; j < i; j++)
/*     */     {
/*     */ 
/* 201 */       TypeInfo localTypeInfo = TypeInfo.getInstance(paramTDSReader, true);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */       SQLIdentifier localSQLIdentifier = new SQLIdentifier();
/* 208 */       if ((SSType.TEXT == localTypeInfo.getSSType()) || (SSType.NTEXT == localTypeInfo.getSSType()) || (SSType.IMAGE == localTypeInfo.getSSType()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 213 */         localSQLIdentifier = paramTDSReader.readSQLIdentifier();
/*     */       }
/*     */       
/* 216 */       CryptoMetadata localCryptoMetadata = null;
/* 217 */       if ((paramTDSReader.getServerSupportsColumnEncryption()) && (localTypeInfo.isEncrypted()))
/*     */       {
/* 219 */         localCryptoMetadata = readCryptoMetadata(paramTDSReader);
/* 220 */         localCryptoMetadata.baseTypeInfo.setFlags(Short.valueOf(localTypeInfo.getFlagsAsShort()));
/* 221 */         localTypeInfo.setSQLCollation(localCryptoMetadata.baseTypeInfo.getSQLCollation());
/*     */       }
/*     */       
/*     */ 
/* 225 */       String str = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/*     */       
/* 227 */       if (this.shouldHonorAEForRead)
/*     */       {
/* 229 */         this.columns[j] = new Column(localTypeInfo, str, localSQLIdentifier, localCryptoMetadata);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 234 */         this.columns[j] = new Column(localTypeInfo, str, localSQLIdentifier, null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Column[] buildColumns(StreamColInfo paramStreamColInfo, StreamTabName paramStreamTabName)
/*     */     throws SQLServerException
/*     */   {
/* 246 */     if ((null != paramStreamColInfo) && (null != paramStreamTabName)) {
/* 247 */       paramStreamTabName.applyTo(this.columns, paramStreamColInfo.applyTo(this.columns));
/*     */     }
/* 249 */     return this.columns;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamColumns.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */