/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.MathContext;
/*      */ import java.math.RoundingMode;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.charset.Charset;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.TimeZone;
/*      */ import java.util.UUID;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DTV
/*      */ {
/*   85 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.DTV");
/*      */   private DTVImpl impl;
/*      */   CryptoMetadata cryptoMeta;
/*      */   JDBCType jdbcTypeSetByUser;
/*      */   int valueLength;
/*      */   
/*   91 */   DTV() { this.cryptoMeta = null;
/*   92 */     this.jdbcTypeSetByUser = null;
/*   93 */     this.valueLength = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setValue(SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean)
/*      */     throws SQLServerException
/*      */   {
/*  112 */     if (null == this.impl) {
/*  113 */       this.impl = new AppDTVImpl();
/*      */     }
/*  115 */     this.impl.setValue(this, paramSQLCollation, paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection, paramBoolean);
/*      */   }
/*      */   
/*      */   final void setValue(Object paramObject, JavaType paramJavaType)
/*      */   {
/*  120 */     this.impl.setValue(paramObject, paramJavaType);
/*      */   }
/*      */   
/*  123 */   final void clear() { this.impl = null; }
/*      */   
/*      */   final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException
/*      */   {
/*  127 */     if (null == this.impl) {
/*  128 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  130 */     this.impl.skipValue(paramTypeInfo, paramTDSReader, paramBoolean);
/*      */   }
/*      */   
/*      */   final void initFromCompressedNull()
/*      */   {
/*  135 */     if (null == this.impl) {
/*  136 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  138 */     this.impl.initFromCompressedNull();
/*      */   }
/*      */   
/*      */   final void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs)
/*      */   {
/*  143 */     this.impl.setStreamSetterArgs(paramStreamSetterArgs);
/*      */   }
/*      */   
/*      */   final void setCalendar(Calendar paramCalendar)
/*      */   {
/*  148 */     this.impl.setCalendar(paramCalendar);
/*      */   }
/*      */   
/*      */   final void setScale(Integer paramInteger)
/*      */   {
/*  153 */     this.impl.setScale(paramInteger);
/*      */   }
/*      */   
/*      */   final void setForceEncrypt(boolean paramBoolean)
/*      */   {
/*  158 */     this.impl.setForceEncrypt(paramBoolean);
/*      */   }
/*      */   
/*  161 */   StreamSetterArgs getStreamSetterArgs() { return this.impl.getStreamSetterArgs(); }
/*  162 */   Calendar getCalendar() { return this.impl.getCalendar(); }
/*  163 */   Integer getScale() { return this.impl.getScale(); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isNull()
/*      */   {
/*  170 */     return (null == this.impl) || (this.impl.isNull());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final boolean isInitialized()
/*      */   {
/*  179 */     return null != this.impl;
/*      */   }
/*      */   
/*      */   final void setJdbcType(JDBCType paramJDBCType)
/*      */   {
/*  184 */     if (null == this.impl) {
/*  185 */       this.impl = new AppDTVImpl();
/*      */     }
/*  187 */     this.impl.setJdbcType(paramJDBCType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final JDBCType getJdbcType()
/*      */   {
/*  195 */     assert (null != this.impl);
/*  196 */     return this.impl.getJdbcType();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   final JavaType getJavaType()
/*      */   {
/*  204 */     assert (null != this.impl);
/*  205 */     return this.impl.getJavaType();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getValue(JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader)
/*      */     throws SQLServerException
/*      */   {
/*  224 */     if (null == this.impl)
/*  225 */       this.impl = new ServerDTVImpl();
/*  226 */     return this.impl.getValue(this, paramJDBCType, paramInt, paramInputStreamGetterArgs, paramCalendar, paramTypeInfo, paramCryptoMetadata, paramTDSReader);
/*      */   }
/*      */   
/*      */   Object getSetterValue()
/*      */   {
/*  231 */     return this.impl.getSetterValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setImpl(DTVImpl paramDTVImpl)
/*      */   {
/*  240 */     this.impl = paramDTVImpl;
/*      */   }
/*      */   
/*      */ 
/*      */   final class SendByRPCOp
/*      */     extends DTVExecuteOp
/*      */   {
/*      */     private final String name;
/*      */     
/*      */     private final TypeInfo typeInfo;
/*      */     
/*      */     private final SQLCollation collation;
/*      */     
/*      */     private final int precision;
/*      */     
/*      */     private final int outScale;
/*      */     
/*      */     private final boolean isOutParam;
/*      */     
/*      */     private final TDSWriter tdsWriter;
/*      */     private final SQLServerConnection conn;
/*      */     
/*      */     SendByRPCOp(String paramString, TypeInfo paramTypeInfo, SQLCollation paramSQLCollation, int paramInt1, int paramInt2, boolean paramBoolean, TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection)
/*      */     {
/*  264 */       this.name = paramString;
/*  265 */       this.typeInfo = paramTypeInfo;
/*  266 */       this.collation = paramSQLCollation;
/*  267 */       this.precision = paramInt1;
/*  268 */       this.outScale = paramInt2;
/*  269 */       this.isOutParam = paramBoolean;
/*  270 */       this.tdsWriter = paramTDSWriter;
/*  271 */       this.conn = paramSQLServerConnection;
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, String paramString) throws SQLServerException
/*      */     {
/*  276 */       this.tdsWriter.writeRPCStringUnicode(this.name, paramString, this.isOutParam, this.collation);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Clob paramClob)
/*      */       throws SQLServerException
/*      */     {
/*  282 */       assert (null != paramClob);
/*      */       
/*  284 */       long l = 0L;
/*  285 */       Reader localReader = null;
/*      */       
/*      */       try
/*      */       {
/*  289 */         l = DataTypes.getCheckedLength(this.conn, paramDTV.getJdbcType(), paramClob.length(), false);
/*  290 */         localReader = paramClob.getCharacterStream();
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/*  294 */         SQLServerException.makeFromDriverError(this.conn, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */       
/*      */ 
/*  298 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*  299 */       if ((null != this.collation) && ((JDBCType.CHAR == localJDBCType) || (JDBCType.VARCHAR == localJDBCType) || (JDBCType.LONGVARCHAR == localJDBCType) || (JDBCType.CLOB == localJDBCType)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  305 */         if (null == localReader)
/*      */         {
/*  307 */           this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, localJDBCType, this.collation);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*  316 */           ReaderInputStream localReaderInputStream = null;
/*      */           
/*      */           try
/*      */           {
/*  320 */             localReaderInputStream = new ReaderInputStream(localReader, this.collation.getCharset(), l);
/*      */ 
/*      */ 
/*      */           }
/*      */           catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */           {
/*      */ 
/*  327 */             MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/*  328 */             Object[] arrayOfObject = { new String(localUnsupportedEncodingException.getMessage()) };
/*  329 */             SQLServerException.makeFromDriverError(this.conn, null, localMessageFormat.format(arrayOfObject), null, true);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  337 */           this.tdsWriter.writeRPCInputStream(this.name, localReaderInputStream, -1L, this.isOutParam, localJDBCType, this.collation);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  348 */       else if (null == localReader)
/*      */       {
/*  350 */         this.tdsWriter.writeRPCStringUnicode(this.name, null, this.isOutParam, this.collation);
/*      */       }
/*      */       else
/*      */       {
/*  354 */         this.tdsWriter.writeRPCReaderUnicode(this.name, localReader, l, this.isOutParam, this.collation);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, Byte paramByte)
/*      */       throws SQLServerException
/*      */     {
/*  366 */       this.tdsWriter.writeRPCByte(this.name, paramByte, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Integer paramInteger) throws SQLServerException
/*      */     {
/*  371 */       this.tdsWriter.writeRPCInt(this.name, paramInteger, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Time paramTime) throws SQLServerException
/*      */     {
/*  376 */       sendTemporal(paramDTV, JavaType.TIME, paramTime);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, java.sql.Date paramDate)
/*      */       throws SQLServerException
/*      */     {
/*  384 */       sendTemporal(paramDTV, JavaType.DATE, paramDate);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, Timestamp paramTimestamp)
/*      */       throws SQLServerException
/*      */     {
/*  392 */       sendTemporal(paramDTV, JavaType.TIMESTAMP, paramTimestamp);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, java.util.Date paramDate)
/*      */       throws SQLServerException
/*      */     {
/*  400 */       sendTemporal(paramDTV, JavaType.UTILDATE, paramDate);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, Calendar paramCalendar)
/*      */       throws SQLServerException
/*      */     {
/*  408 */       sendTemporal(paramDTV, JavaType.CALENDAR, paramCalendar);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, LocalDate paramLocalDate)
/*      */       throws SQLServerException
/*      */     {
/*  416 */       sendTemporal(paramDTV, JavaType.LOCALDATE, paramLocalDate);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, LocalTime paramLocalTime)
/*      */       throws SQLServerException
/*      */     {
/*  424 */       sendTemporal(paramDTV, JavaType.LOCALTIME, paramLocalTime);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, LocalDateTime paramLocalDateTime)
/*      */       throws SQLServerException
/*      */     {
/*  432 */       sendTemporal(paramDTV, JavaType.LOCALDATETIME, paramLocalDateTime);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, OffsetTime paramOffsetTime)
/*      */       throws SQLServerException
/*      */     {
/*  440 */       sendTemporal(paramDTV, JavaType.OFFSETTIME, paramOffsetTime);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, OffsetDateTime paramOffsetDateTime)
/*      */       throws SQLServerException
/*      */     {
/*  448 */       sendTemporal(paramDTV, JavaType.OFFSETDATETIME, paramOffsetDateTime);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset)
/*      */       throws SQLServerException
/*      */     {
/*  456 */       sendTemporal(paramDTV, JavaType.DATETIMEOFFSET, paramDateTimeOffset);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, TVP paramTVP)
/*      */       throws SQLServerException
/*      */     {
/*  465 */       this.tdsWriter.writeTVP(paramTVP);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void clearSetCalendar(Calendar paramCalendar, boolean paramBoolean, Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, Integer paramInteger4, Integer paramInteger5, Integer paramInteger6)
/*      */     {
/*  476 */       paramCalendar.clear();
/*  477 */       paramCalendar.setLenient(paramBoolean);
/*  478 */       if (null != paramInteger1)
/*      */       {
/*  480 */         paramCalendar.set(1, paramInteger1.intValue());
/*      */       }
/*  482 */       if (null != paramInteger2)
/*      */       {
/*  484 */         paramCalendar.set(2, paramInteger2.intValue());
/*      */       }
/*  486 */       if (null != paramInteger3)
/*      */       {
/*  488 */         paramCalendar.set(5, paramInteger3.intValue());
/*      */       }
/*  490 */       if (null != paramInteger4)
/*      */       {
/*  492 */         paramCalendar.set(11, paramInteger4.intValue());
/*      */       }
/*  494 */       if (null != paramInteger5)
/*      */       {
/*  496 */         paramCalendar.set(12, paramInteger5.intValue());
/*      */       }
/*  498 */       if (null != paramInteger6)
/*      */       {
/*  500 */         paramCalendar.set(13, paramInteger6.intValue());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void sendTemporal(DTV paramDTV, JavaType paramJavaType, Object paramObject)
/*      */       throws SQLServerException
/*      */     {
/*  522 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*  523 */       GregorianCalendar localGregorianCalendar = null;
/*  524 */       int i = 0;
/*  525 */       int j = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  551 */       if (null != paramObject)
/*      */       {
/*  553 */         Object localObject1 = TimeZone.getDefault();
/*  554 */         long l = 0L;
/*      */         
/*      */         Object localObject2;
/*  557 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JavaType[paramJavaType.ordinal()])
/*      */         {
/*      */ 
/*      */ 
/*      */         case 1: 
/*  562 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */           
/*      */ 
/*  565 */           l = ((Time)paramObject).getTime();
/*  566 */           i = 1000000 * (int)(l % 1000L);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  575 */           if (i < 0) {
/*  576 */             i += 1000000000;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 2: 
/*  584 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */           
/*      */ 
/*  587 */           l = ((java.sql.Date)paramObject).getTime();
/*  588 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         case 3: 
/*  594 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */           
/*      */ 
/*  597 */           localObject2 = (Timestamp)paramObject;
/*  598 */           l = ((Timestamp)localObject2).getTime();
/*  599 */           i = ((Timestamp)localObject2).getNanos();
/*  600 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case 4: 
/*  608 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */           
/*      */ 
/*  611 */           l = ((java.util.Date)paramObject).getTime();
/*      */           
/*      */ 
/*      */ 
/*  615 */           i = 1000000 * (int)(l % 1000L);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  624 */           if (i < 0) {
/*  625 */             i += 1000000000;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 5: 
/*  634 */           localObject1 = null != paramDTV.getCalendar() ? paramDTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */           
/*      */ 
/*  637 */           l = ((Calendar)paramObject).getTimeInMillis();
/*      */           
/*      */ 
/*      */ 
/*  641 */           i = 1000000 * (int)(l % 1000L);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  650 */           if (i < 0) {
/*  651 */             i += 1000000000;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 6: 
/*  657 */           localGregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */           
/*      */ 
/*  660 */           clearSetCalendar(localGregorianCalendar, true, Integer.valueOf(((LocalDate)paramObject).getYear()), Integer.valueOf(((LocalDate)paramObject).getMonthValue() - 1), Integer.valueOf(((LocalDate)paramObject).getDayOfMonth()), null, null, null);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  665 */           break;
/*      */         
/*      */ 
/*      */         case 7: 
/*  669 */           localGregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */           
/*      */ 
/*  672 */           localObject2 = (LocalTime)paramObject;
/*  673 */           clearSetCalendar(localGregorianCalendar, true, Integer.valueOf(this.conn.baseYear()), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(((LocalTime)localObject2).getHour()), Integer.valueOf(((LocalTime)localObject2).getMinute()), Integer.valueOf(((LocalTime)localObject2).getSecond()));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  678 */           i = ((LocalTime)localObject2).getNano();
/*      */           
/*      */ 
/*      */ 
/*  682 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 8: 
/*  687 */           localGregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */           
/*  689 */           LocalDateTime localLocalDateTime = (LocalDateTime)paramObject;
/*  690 */           clearSetCalendar(localGregorianCalendar, true, Integer.valueOf(localLocalDateTime.getYear()), Integer.valueOf(localLocalDateTime.getMonthValue() - 1), Integer.valueOf(localLocalDateTime.getDayOfMonth()), Integer.valueOf(localLocalDateTime.getHour()), Integer.valueOf(localLocalDateTime.getMinute()), Integer.valueOf(localLocalDateTime.getSecond()));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  697 */           i = localLocalDateTime.getNano();
/*      */           
/*      */ 
/*      */ 
/*  701 */           break;
/*      */         
/*      */         case 9: 
/*  704 */           OffsetTime localOffsetTime = (OffsetTime)paramObject;
/*      */           
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/*  710 */             j = localOffsetTime.getOffset().getTotalSeconds() / 60;
/*      */           }
/*      */           catch (Exception localException1)
/*      */           {
/*  714 */             throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  720 */           i = localOffsetTime.getNano();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  727 */           localObject1 = (JDBCType.TIME_WITH_TIMEZONE == localJDBCType) && ((null == this.typeInfo) || (SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  735 */           String str1 = this.conn.baseYear() + "-01-01" + ' ' + localOffsetTime.getHour() + ':' + localOffsetTime.getMinute() + ':' + localOffsetTime.getSecond();
/*      */           
/*      */ 
/*      */ 
/*  739 */           l = Timestamp.valueOf(str1).getTime();
/*  740 */           break;
/*      */         
/*      */         case 10: 
/*  743 */           OffsetDateTime localOffsetDateTime = (OffsetDateTime)paramObject;
/*      */           
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/*  749 */             j = localOffsetDateTime.getOffset().getTotalSeconds() / 60;
/*      */           }
/*      */           catch (Exception localException2)
/*      */           {
/*  753 */             throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  760 */           i = localOffsetDateTime.getNano();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  767 */           localObject1 = ((JDBCType.TIMESTAMP_WITH_TIMEZONE == localJDBCType) || (JDBCType.TIME_WITH_TIMEZONE == localJDBCType)) && ((null == this.typeInfo) || (SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  775 */           String str2 = String.format("%04d", new Object[] { Integer.valueOf(localOffsetDateTime.getYear()) }) + '-' + localOffsetDateTime.getMonthValue() + '-' + localOffsetDateTime.getDayOfMonth() + ' ' + localOffsetDateTime.getHour() + ':' + localOffsetDateTime.getMinute() + ':' + localOffsetDateTime.getSecond();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  781 */           l = Timestamp.valueOf(str2).getTime();
/*  782 */           break;
/*      */         
/*      */ 
/*      */         case 11: 
/*  786 */           DateTimeOffset localDateTimeOffset = (DateTimeOffset)paramObject;
/*      */           
/*  788 */           l = localDateTimeOffset.getTimestamp().getTime();
/*  789 */           i = localDateTimeOffset.getTimestamp().getNanos();
/*  790 */           j = localDateTimeOffset.getMinutesOffset();
/*      */           
/*      */ 
/*      */ 
/*  794 */           assert (null == paramDTV.getCalendar());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  801 */           localObject1 = (JDBCType.DATETIMEOFFSET == localJDBCType) && ((null == this.typeInfo) || (SSType.DATETIMEOFFSET == this.typeInfo.getSSType()) || (SSType.VARBINARY == this.typeInfo.getSSType()) || (SSType.VARBINARYMAX == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  808 */           break;
/*      */         
/*      */ 
/*      */         default: 
/*  812 */           throw new AssertionError("Unexpected JavaType: " + paramJavaType);
/*      */         }
/*      */         
/*      */         
/*  816 */         if (null == localGregorianCalendar)
/*      */         {
/*      */ 
/*      */ 
/*  820 */           localGregorianCalendar = new GregorianCalendar((TimeZone)localObject1, Locale.US);
/*      */           
/*      */ 
/*      */ 
/*  824 */           localGregorianCalendar.setLenient(true);
/*      */           
/*      */ 
/*      */ 
/*  828 */           localGregorianCalendar.clear();
/*      */           
/*      */ 
/*  831 */           localGregorianCalendar.setTimeInMillis(l);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  839 */       if (null != this.typeInfo)
/*      */       {
/*  841 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$SSType[this.typeInfo.getSSType().ordinal()])
/*      */         {
/*      */ 
/*      */         case 1: 
/*  845 */           this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, this.typeInfo.getScale(), this.isOutParam);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  852 */           break;
/*      */         
/*      */         case 2: 
/*  855 */           this.tdsWriter.writeRPCDate(this.name, localGregorianCalendar, this.isOutParam);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  860 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*  864 */           this.tdsWriter.writeRPCTime(this.name, localGregorianCalendar, i, this.typeInfo.getScale(), this.isOutParam);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  871 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         case 4: 
/*  877 */           if (JavaType.DATETIMEOFFSET != paramJavaType)
/*      */           {
/*  879 */             localGregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(localGregorianCalendar), paramJavaType, this.conn.baseYear());
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  885 */             j = 0;
/*      */           }
/*      */           
/*  888 */           this.tdsWriter.writeRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, this.typeInfo.getScale(), this.isOutParam);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  896 */           break;
/*      */         
/*      */         case 5: 
/*      */         case 6: 
/*  900 */           this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, this.isOutParam);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  905 */           break;
/*      */         
/*      */         case 7: 
/*      */         case 8: 
/*  909 */           switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[localJDBCType.ordinal()])
/*      */           {
/*      */           case 1: 
/*      */           case 2: 
/*  913 */             this.tdsWriter.writeEncryptedRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, this.isOutParam, localJDBCType);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  919 */             break;
/*      */           
/*      */           case 3: 
/*  922 */             assert (null != DTV.this.cryptoMeta);
/*  923 */             this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, DTV.this.valueLength, this.isOutParam);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  929 */             break;
/*      */           
/*      */ 
/*      */           case 4: 
/*  933 */             assert (null != DTV.this.cryptoMeta);
/*  934 */             this.tdsWriter.writeEncryptedRPCTime(this.name, localGregorianCalendar, i, DTV.this.valueLength, this.isOutParam);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  939 */             break;
/*      */           
/*      */           case 5: 
/*  942 */             assert (null != DTV.this.cryptoMeta);
/*  943 */             this.tdsWriter.writeEncryptedRPCDate(this.name, localGregorianCalendar, this.isOutParam);
/*  944 */             break;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */           case 6: 
/*      */           case 7: 
/*  951 */             if ((JavaType.DATETIMEOFFSET != paramJavaType) && (JavaType.OFFSETDATETIME != paramJavaType))
/*      */             {
/*      */ 
/*  954 */               localGregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(localGregorianCalendar), paramJavaType, this.conn.baseYear());
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  960 */               j = 0;
/*      */             }
/*      */             
/*  963 */             assert (null != DTV.this.cryptoMeta);
/*  964 */             this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, DTV.this.valueLength, this.isOutParam);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  971 */             break;
/*      */           
/*      */           default: 
/*  974 */             if ($assertionsDisabled) break; throw new AssertionError("Unexpected JDBCType: " + localJDBCType);
/*      */           }
/*      */           
/*      */           break;
/*      */         default: 
/*  979 */           if ($assertionsDisabled) break; throw new AssertionError("Unexpected SSType: " + this.typeInfo.getSSType());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*  993 */       else if (this.conn.isKatmaiOrLater())
/*      */       {
/*  995 */         if ((DTV.aeLogger.isLoggable(Level.FINE)) && (null != DTV.this.cryptoMeta))
/*      */         {
/*  997 */           DTV.aeLogger.fine("Encrypting temporal data type.");
/*      */         }
/*      */         
/* 1000 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JDBCType[localJDBCType.ordinal()])
/*      */         {
/*      */         case 1: 
/*      */         case 2: 
/*      */         case 3: 
/* 1005 */           if (null != DTV.this.cryptoMeta)
/*      */           {
/* 1007 */             if ((JDBCType.DATETIME == localJDBCType) || (JDBCType.SMALLDATETIME == localJDBCType))
/*      */             {
/* 1009 */               this.tdsWriter.writeEncryptedRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, this.isOutParam, localJDBCType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/* 1016 */             else if (0 == DTV.this.valueLength)
/*      */             {
/* 1018 */               this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, this.outScale, this.isOutParam);
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*      */ 
/* 1027 */               this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, DTV.this.valueLength, this.isOutParam);
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1036 */             this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, this.conn.baseYear()), i, 7, this.isOutParam);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1043 */           break;
/*      */         
/*      */ 
/*      */         case 4: 
/* 1047 */           if (null != DTV.this.cryptoMeta)
/*      */           {
/* 1049 */             if (0 == DTV.this.valueLength) {
/* 1050 */               this.tdsWriter.writeEncryptedRPCTime(this.name, localGregorianCalendar, i, this.outScale, this.isOutParam);
/*      */ 
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/* 1057 */               this.tdsWriter.writeEncryptedRPCTime(this.name, localGregorianCalendar, i, DTV.this.valueLength, this.isOutParam);
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/* 1067 */           else if (this.conn.getSendTimeAsDatetime())
/*      */           {
/* 1069 */             this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, JavaType.TIME, 1970), i, this.isOutParam);
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 1076 */             this.tdsWriter.writeRPCTime(this.name, localGregorianCalendar, i, 7, this.isOutParam);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1085 */           break;
/*      */         
/*      */         case 5: 
/* 1088 */           if (null != DTV.this.cryptoMeta) {
/* 1089 */             this.tdsWriter.writeEncryptedRPCDate(this.name, localGregorianCalendar, this.isOutParam);
/*      */           } else {
/* 1091 */             this.tdsWriter.writeRPCDate(this.name, localGregorianCalendar, this.isOutParam);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1096 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         case 8: 
/* 1102 */           if ((JavaType.OFFSETDATETIME != paramJavaType) && (JavaType.OFFSETTIME != paramJavaType))
/*      */           {
/*      */ 
/* 1105 */             localGregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(localGregorianCalendar), paramJavaType, this.conn.baseYear());
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1111 */             j = 0;
/*      */           }
/*      */           
/* 1114 */           this.tdsWriter.writeRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, 7, this.isOutParam);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1122 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         case 6: 
/*      */         case 7: 
/* 1129 */           if ((JavaType.DATETIMEOFFSET != paramJavaType) && (JavaType.OFFSETDATETIME != paramJavaType))
/*      */           {
/*      */ 
/* 1132 */             localGregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(localGregorianCalendar), paramJavaType, this.conn.baseYear());
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1138 */             j = 0;
/*      */           }
/*      */           
/* 1141 */           if (null != DTV.this.cryptoMeta)
/*      */           {
/* 1143 */             if (0 == DTV.this.valueLength) {
/* 1144 */               this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, this.outScale, this.isOutParam);
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*      */ 
/* 1153 */               this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, 0 == DTV.this.valueLength ? 7 : DTV.this.valueLength, this.isOutParam);
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 1163 */             this.tdsWriter.writeRPCDateTimeOffset(this.name, localGregorianCalendar, j, i, 7, this.isOutParam);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1171 */           break;
/*      */         
/*      */         default: 
/* 1174 */           if ($assertionsDisabled) break; throw new AssertionError("Unexpected JDBCType: " + localJDBCType);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1193 */         assert ((JDBCType.TIME == localJDBCType) || (JDBCType.DATE == localJDBCType) || (JDBCType.TIMESTAMP == localJDBCType)) : ("Unexpected JDBCType: " + localJDBCType);
/*      */         
/* 1195 */         this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(localGregorianCalendar, paramJavaType, 1970), i, this.isOutParam);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private GregorianCalendar timestampNormalizedCalendar(GregorianCalendar paramGregorianCalendar, JavaType paramJavaType, int paramInt)
/*      */     {
/* 1222 */       if (null != paramGregorianCalendar)
/*      */       {
/* 1224 */         switch (DTV.1.$SwitchMap$com$microsoft$sqlserver$jdbc$JavaType[paramJavaType.ordinal()])
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */         case 2: 
/*      */         case 6: 
/* 1231 */           paramGregorianCalendar.set(11, 0);
/* 1232 */           paramGregorianCalendar.set(12, 0);
/* 1233 */           paramGregorianCalendar.set(13, 0);
/* 1234 */           paramGregorianCalendar.set(14, 0);
/* 1235 */           break;
/*      */         
/*      */         case 1: 
/*      */         case 7: 
/*      */         case 9: 
/* 1240 */           assert ((1970 == paramInt) || (1900 == paramInt));
/* 1241 */           paramGregorianCalendar.set(paramInt, 0, 1);
/* 1242 */           break;
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1249 */       return paramGregorianCalendar;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private GregorianCalendar localCalendarAsUTC(GregorianCalendar paramGregorianCalendar)
/*      */     {
/* 1260 */       if (null == paramGregorianCalendar) {
/* 1261 */         return null;
/*      */       }
/*      */       
/* 1264 */       int i = paramGregorianCalendar.get(1);
/* 1265 */       int j = paramGregorianCalendar.get(2);
/* 1266 */       int k = paramGregorianCalendar.get(5);
/* 1267 */       int m = paramGregorianCalendar.get(11);
/* 1268 */       int n = paramGregorianCalendar.get(12);
/* 1269 */       int i1 = paramGregorianCalendar.get(13);
/* 1270 */       int i2 = paramGregorianCalendar.get(14);
/*      */       
/* 1272 */       paramGregorianCalendar.setTimeZone(UTC.timeZone);
/* 1273 */       paramGregorianCalendar.set(i, j, k, m, n, i1);
/* 1274 */       paramGregorianCalendar.set(14, i2);
/* 1275 */       return paramGregorianCalendar;
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Float paramFloat) throws SQLServerException
/*      */     {
/* 1280 */       if (JDBCType.REAL == paramDTV.getJdbcType())
/*      */       {
/* 1282 */         this.tdsWriter.writeRPCReal(this.name, paramFloat, this.isOutParam);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1292 */         Double localDouble = null == paramFloat ? null : new Double(paramFloat.floatValue());
/* 1293 */         this.tdsWriter.writeRPCDouble(this.name, localDouble, this.isOutParam);
/*      */       }
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Double paramDouble) throws SQLServerException
/*      */     {
/* 1299 */       this.tdsWriter.writeRPCDouble(this.name, paramDouble, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, BigDecimal paramBigDecimal) throws SQLServerException
/*      */     {
/* 1304 */       if (DDC.exceedsMaxRPCDecimalPrecisionOrScale(paramBigDecimal))
/*      */       {
/* 1306 */         String str = paramBigDecimal.toString();
/* 1307 */         this.tdsWriter.writeRPCStringUnicode(this.name, str, this.isOutParam, this.collation);
/*      */       }
/*      */       else
/*      */       {
/* 1311 */         this.tdsWriter.writeRPCBigDecimal(this.name, paramBigDecimal, this.outScale, this.isOutParam);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, Long paramLong)
/*      */       throws SQLServerException
/*      */     {
/* 1321 */       this.tdsWriter.writeRPCLong(this.name, paramLong, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, BigInteger paramBigInteger) throws SQLServerException
/*      */     {
/* 1326 */       this.tdsWriter.writeRPCLong(this.name, Long.valueOf(paramBigInteger.longValue()), this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Short paramShort) throws SQLServerException
/*      */     {
/* 1331 */       this.tdsWriter.writeRPCShort(this.name, paramShort, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Boolean paramBoolean) throws SQLServerException
/*      */     {
/* 1336 */       this.tdsWriter.writeRPCBit(this.name, paramBoolean, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, byte[] paramArrayOfByte) throws SQLServerException
/*      */     {
/* 1341 */       if (null != DTV.this.cryptoMeta)
/*      */       {
/* 1343 */         this.tdsWriter.writeRPCNameValType(this.name, this.isOutParam, TDSType.BIGVARBINARY);
/* 1344 */         if (null != paramArrayOfByte)
/*      */         {
/* 1346 */           paramArrayOfByte = SQLServerSecurityUtility.encryptWithKey(paramArrayOfByte, DTV.this.cryptoMeta, this.conn);
/* 1347 */           this.tdsWriter.writeEncryptedRPCByteArray(paramArrayOfByte);
/* 1348 */           writeEncryptData(paramDTV, false);
/*      */         }
/*      */         else
/*      */         {
/* 1352 */           this.tdsWriter.writeEncryptedRPCByteArray(paramArrayOfByte);
/* 1353 */           writeEncryptData(paramDTV, true);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1358 */         this.tdsWriter.writeRPCByteArray(this.name, paramArrayOfByte, this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void writeEncryptData(DTV paramDTV, boolean paramBoolean)
/*      */       throws SQLServerException
/*      */     {
/* 1369 */       JDBCType localJDBCType = null == DTV.this.jdbcTypeSetByUser ? paramDTV.getJdbcType() : DTV.this.jdbcTypeSetByUser;
/*      */       
/* 1371 */       switch (localJDBCType.getIntValue())
/*      */       {
/*      */       case 4: 
/* 1374 */         this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1375 */         this.tdsWriter.writeByte((byte)4);
/* 1376 */         break;
/*      */       
/*      */       case -5: 
/* 1379 */         this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1380 */         this.tdsWriter.writeByte((byte)8);
/* 1381 */         break;
/*      */       
/*      */       case -7: 
/* 1384 */         this.tdsWriter.writeByte(TDSType.BITN.byteValue());
/* 1385 */         this.tdsWriter.writeByte((byte)1);
/* 1386 */         break;
/*      */       
/*      */       case 5: 
/* 1389 */         this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1390 */         this.tdsWriter.writeByte((byte)2);
/* 1391 */         break;
/*      */       
/*      */       case -6: 
/* 1394 */         this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1395 */         this.tdsWriter.writeByte((byte)1);
/* 1396 */         break;
/*      */       
/*      */       case 8: 
/* 1399 */         this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1400 */         this.tdsWriter.writeByte((byte)8);
/* 1401 */         break;
/*      */       
/*      */       case 7: 
/* 1404 */         this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1405 */         this.tdsWriter.writeByte((byte)4);
/* 1406 */         break;
/*      */       
/*      */ 
/*      */       case -148: 
/*      */       case -146: 
/*      */       case 2: 
/*      */       case 3: 
/* 1413 */         if ((JDBCType.MONEY == localJDBCType) || (JDBCType.SMALLMONEY == localJDBCType))
/*      */         {
/* 1415 */           this.tdsWriter.writeByte(TDSType.MONEYN.byteValue());
/* 1416 */           this.tdsWriter.writeByte((byte)(JDBCType.MONEY == localJDBCType ? 8 : 4));
/*      */         }
/*      */         else
/*      */         {
/* 1420 */           this.tdsWriter.writeByte(TDSType.NUMERICN.byteValue());
/* 1421 */           if (paramBoolean) {
/* 1422 */             this.tdsWriter.writeByte((byte)17);
/*      */             
/* 1424 */             if ((null != DTV.this.cryptoMeta) && (null != DTV.this.cryptoMeta.getBaseTypeInfo())) {
/* 1425 */               this.tdsWriter.writeByte((byte)(0 != DTV.this.valueLength ? DTV.this.valueLength : DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision()));
/*      */             }
/*      */             else {
/* 1428 */               this.tdsWriter.writeByte((byte)(0 != DTV.this.valueLength ? DTV.this.valueLength : 18));
/*      */             }
/*      */             
/* 1431 */             this.tdsWriter.writeByte((byte)(0 != this.outScale ? this.outScale : 0));
/*      */           }
/*      */           else
/*      */           {
/* 1435 */             this.tdsWriter.writeByte((byte)17);
/*      */             
/* 1437 */             if ((null != DTV.this.cryptoMeta) && (null != DTV.this.cryptoMeta.getBaseTypeInfo())) {
/* 1438 */               this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision());
/*      */             }
/*      */             else {
/* 1441 */               this.tdsWriter.writeByte((byte)(0 != DTV.this.valueLength ? DTV.this.valueLength : 18));
/*      */             }
/*      */             
/* 1444 */             if ((null != DTV.this.cryptoMeta) && (null != DTV.this.cryptoMeta.getBaseTypeInfo())) {
/* 1445 */               this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getScale());
/*      */             }
/*      */             else {
/* 1448 */               this.tdsWriter.writeByte((byte)(null != paramDTV.getScale() ? paramDTV.getScale().intValue() : 0));
/*      */             }
/*      */           }
/*      */         }
/* 1452 */         break;
/*      */       
/*      */       case -145: 
/* 1455 */         this.tdsWriter.writeByte(TDSType.GUID.byteValue());
/* 1456 */         if (paramBoolean) {
/* 1457 */           this.tdsWriter.writeByte((byte)(0 != DTV.this.valueLength ? DTV.this.valueLength : 1));
/*      */         } else
/* 1459 */           this.tdsWriter.writeByte((byte)16);
/* 1460 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/* 1464 */         this.tdsWriter.writeByte(TDSType.BIGCHAR.byteValue());
/*      */         
/* 1466 */         if (paramBoolean) {
/* 1467 */           this.tdsWriter.writeShort((short)(0 != DTV.this.valueLength ? DTV.this.valueLength : 1));
/*      */         } else {
/* 1469 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */         }
/* 1471 */         if (null != this.collation) {
/* 1472 */           this.collation.writeCollation(this.tdsWriter);
/*      */         } else
/* 1474 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/* 1475 */         break;
/*      */       
/*      */       case -15: 
/* 1478 */         this.tdsWriter.writeByte(TDSType.NCHAR.byteValue());
/* 1479 */         if (paramBoolean) {
/* 1480 */           this.tdsWriter.writeShort((short)(0 != DTV.this.valueLength ? DTV.this.valueLength * 2 : 1));
/*      */         }
/* 1482 */         else if (this.isOutParam) {
/* 1483 */           this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
/*      */         }
/*      */         else {
/* 1486 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */         }
/*      */         
/* 1489 */         if (null != this.collation) {
/* 1490 */           this.collation.writeCollation(this.tdsWriter);
/*      */         } else
/* 1492 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/* 1493 */         break;
/*      */       
/*      */ 
/*      */       case -1: 
/*      */       case 12: 
/* 1498 */         this.tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1499 */         if (paramBoolean) {
/* 1500 */           if (paramDTV.jdbcTypeSetByUser.getIntValue() == -1) {
/* 1501 */             this.tdsWriter.writeShort((short)-1);
/*      */           }
/*      */           else {
/* 1504 */             this.tdsWriter.writeShort((short)(0 != DTV.this.valueLength ? DTV.this.valueLength : 1));
/*      */           }
/*      */           
/*      */ 
/*      */         }
/* 1509 */         else if ((paramDTV.getJdbcType().getIntValue() == -1) || (paramDTV.getJdbcType().getIntValue() == -16))
/*      */         {
/*      */ 
/*      */ 
/* 1513 */           this.tdsWriter.writeShort((short)1);
/*      */ 
/*      */         }
/* 1516 */         else if (paramDTV.jdbcTypeSetByUser.getIntValue() == -1) {
/* 1517 */           this.tdsWriter.writeShort((short)-1);
/*      */         }
/*      */         else {
/* 1520 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1525 */         if (null != this.collation) {
/* 1526 */           this.collation.writeCollation(this.tdsWriter);
/*      */         } else
/* 1528 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/* 1529 */         break;
/*      */       
/*      */       case -16: 
/*      */       case -9: 
/* 1533 */         this.tdsWriter.writeByte(TDSType.NVARCHAR.byteValue());
/* 1534 */         if (paramBoolean) {
/* 1535 */           if (paramDTV.jdbcTypeSetByUser.getIntValue() == -16) {
/* 1536 */             this.tdsWriter.writeShort((short)-1);
/*      */           }
/*      */           else {
/* 1539 */             this.tdsWriter.writeShort((short)(0 != DTV.this.valueLength ? DTV.this.valueLength * 2 : 1));
/*      */           }
/*      */           
/*      */         }
/* 1543 */         else if (this.isOutParam)
/*      */         {
/*      */ 
/*      */ 
/* 1547 */           if (paramDTV.jdbcTypeSetByUser.getIntValue() == -16) {
/* 1548 */             this.tdsWriter.writeShort((short)-1);
/*      */           }
/*      */           else {
/* 1551 */             this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
/*      */           }
/*      */         }
/*      */         else {
/* 1555 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */         }
/*      */         
/*      */ 
/* 1559 */         if (null != this.collation) {
/* 1560 */           this.collation.writeCollation(this.tdsWriter);
/*      */         } else
/* 1562 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/* 1563 */         break;
/*      */       
/*      */       case -2: 
/* 1566 */         this.tdsWriter.writeByte(TDSType.BIGBINARY.byteValue());
/* 1567 */         if (paramBoolean) {
/* 1568 */           this.tdsWriter.writeShort((short)(0 != DTV.this.valueLength ? DTV.this.valueLength : 1));
/*      */         } else
/* 1570 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/* 1571 */         break;
/*      */       
/*      */ 
/*      */       case -4: 
/*      */       case -3: 
/* 1576 */         this.tdsWriter.writeByte(TDSType.BIGVARBINARY.byteValue());
/* 1577 */         if (paramBoolean) {
/* 1578 */           if (paramDTV.jdbcTypeSetByUser.getIntValue() == -4) {
/* 1579 */             this.tdsWriter.writeShort((short)-1);
/*      */           }
/*      */           else {
/* 1582 */             this.tdsWriter.writeShort((short)(0 != DTV.this.valueLength ? DTV.this.valueLength : 1));
/*      */           }
/*      */           
/*      */         }
/* 1586 */         else if (paramDTV.jdbcTypeSetByUser.getIntValue() == -4) {
/* 1587 */           this.tdsWriter.writeShort((short)-1);
/*      */         }
/*      */         else {
/* 1590 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */         }
/*      */         
/* 1593 */         break;
/*      */       default: 
/* 1595 */         MessageFormat localMessageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 1596 */         throw new SQLServerException(localMessageFormat.format(new Object[] { localJDBCType }), null, 0, null);
/*      */       }
/*      */       
/* 1599 */       this.tdsWriter.writeCryptoMetaData();
/*      */     }
/*      */     
/*      */     void execute(DTV paramDTV, Blob paramBlob) throws SQLServerException
/*      */     {
/* 1604 */       assert (null != paramBlob);
/*      */       
/* 1606 */       long l = 0L;
/* 1607 */       InputStream localInputStream = null;
/*      */       
/*      */       try
/*      */       {
/* 1611 */         l = DataTypes.getCheckedLength(this.conn, paramDTV.getJdbcType(), paramBlob.length(), false);
/* 1612 */         localInputStream = paramBlob.getBinaryStream();
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 1616 */         SQLServerException.makeFromDriverError(this.conn, null, localSQLException.getMessage(), null, false);
/*      */       }
/*      */       
/* 1619 */       if (null == localInputStream)
/*      */       {
/* 1621 */         this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/* 1630 */         this.tdsWriter.writeRPCInputStream(this.name, localInputStream, l, this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML)
/*      */       throws SQLServerException
/*      */     {
/* 1642 */       InputStream localInputStream = null == paramSQLServerSQLXML ? null : paramSQLServerSQLXML.getValue();
/* 1643 */       this.tdsWriter.writeRPCXML(this.name, localInputStream, null == localInputStream ? 0L : paramDTV.getStreamSetterArgs().getLength(), this.isOutParam);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, InputStream paramInputStream)
/*      */       throws SQLServerException
/*      */     {
/* 1651 */       this.tdsWriter.writeRPCInputStream(this.name, paramInputStream, null == paramInputStream ? 0L : paramDTV.getStreamSetterArgs().getLength(), this.isOutParam, paramDTV.getJdbcType(), this.collation);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void execute(DTV paramDTV, Reader paramReader)
/*      */       throws SQLServerException
/*      */     {
/* 1662 */       JDBCType localJDBCType = paramDTV.getJdbcType();
/*      */       
/*      */ 
/* 1665 */       assert (null != paramReader);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1672 */       assert ((JDBCType.NCHAR == localJDBCType) || (JDBCType.NVARCHAR == localJDBCType) || (JDBCType.LONGNVARCHAR == localJDBCType) || (JDBCType.NCLOB == localJDBCType)) : ("SendByRPCOp(Reader): Unexpected JDBC type " + localJDBCType);
/*      */       
/*      */ 
/* 1675 */       this.tdsWriter.writeRPCReaderUnicode(this.name, paramReader, paramDTV.getStreamSetterArgs().getLength(), this.isOutParam, this.collation);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void executeOp(DTVExecuteOp paramDTVExecuteOp)
/*      */     throws SQLServerException
/*      */   {
/* 1691 */     JDBCType localJDBCType = getJdbcType();
/* 1692 */     Object localObject1 = getSetterValue();
/* 1693 */     JavaType localJavaType = getJavaType();
/* 1694 */     int i = 0;
/* 1695 */     byte[] arrayOfByte = null;
/*      */     Object localObject2;
/* 1697 */     Object localObject3; if ((null != this.cryptoMeta) && (!JavaType.SetterConversionAE.converts(localJavaType, localJDBCType)))
/*      */     {
/* 1699 */       localObject2 = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionAE"));
/* 1700 */       localObject3 = new Object[] { localJavaType.toString().toLowerCase(Locale.ENGLISH), localJDBCType.toString().toLowerCase(Locale.ENGLISH) };
/* 1701 */       throw new SQLServerException(((MessageFormat)localObject2).format(localObject3), null);
/*      */     }
/*      */     Object localObject4;
/* 1704 */     if (null == localObject1)
/*      */     {
/*      */ 
/* 1707 */       switch (localJDBCType)
/*      */       {
/*      */       case NCHAR: 
/*      */       case NVARCHAR: 
/*      */       case LONGNVARCHAR: 
/*      */       case NCLOB: 
/* 1713 */         if (null != this.cryptoMeta) {
/* 1714 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1716 */           paramDTVExecuteOp.execute(this, (String)null);
/* 1717 */         break;
/*      */       
/*      */       case INTEGER: 
/* 1720 */         if (null != this.cryptoMeta) {
/* 1721 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1723 */           paramDTVExecuteOp.execute(this, (Integer)null);
/* 1724 */         break;
/*      */       
/*      */       case DATE: 
/* 1727 */         paramDTVExecuteOp.execute(this, (java.sql.Date)null);
/* 1728 */         break;
/*      */       
/*      */       case TIME: 
/* 1731 */         paramDTVExecuteOp.execute(this, (Time)null);
/* 1732 */         break;
/*      */       
/*      */       case DATETIME: 
/*      */       case SMALLDATETIME: 
/*      */       case TIMESTAMP: 
/* 1737 */         paramDTVExecuteOp.execute(this, (Timestamp)null);
/* 1738 */         break;
/*      */       
/*      */       case TIMESTAMP_WITH_TIMEZONE: 
/*      */       case DATETIMEOFFSET: 
/*      */       case TIME_WITH_TIMEZONE: 
/* 1743 */         paramDTVExecuteOp.execute(this, (DateTimeOffset)null);
/* 1744 */         break;
/*      */       
/*      */       case FLOAT: 
/*      */       case REAL: 
/* 1748 */         if (null != this.cryptoMeta) {
/* 1749 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1751 */           paramDTVExecuteOp.execute(this, (Float)null);
/* 1752 */         break;
/*      */       
/*      */       case NUMERIC: 
/*      */       case DECIMAL: 
/*      */       case MONEY: 
/*      */       case SMALLMONEY: 
/* 1758 */         if (null != this.cryptoMeta) {
/* 1759 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1761 */           paramDTVExecuteOp.execute(this, (BigDecimal)null);
/* 1762 */         break;
/*      */       
/*      */       case BINARY: 
/*      */       case VARBINARY: 
/*      */       case LONGVARBINARY: 
/*      */       case BLOB: 
/*      */       case CHAR: 
/*      */       case VARCHAR: 
/*      */       case LONGVARCHAR: 
/*      */       case CLOB: 
/*      */       case GUID: 
/* 1773 */         if (null != this.cryptoMeta) {
/* 1774 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1776 */           paramDTVExecuteOp.execute(this, (byte[])null);
/* 1777 */         break;
/*      */       
/*      */       case TINYINT: 
/* 1780 */         if (null != this.cryptoMeta) {
/* 1781 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1783 */           paramDTVExecuteOp.execute(this, (Byte)null);
/* 1784 */         break;
/*      */       
/*      */       case BIGINT: 
/* 1787 */         if (null != this.cryptoMeta) {
/* 1788 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1790 */           paramDTVExecuteOp.execute(this, (Long)null);
/* 1791 */         break;
/*      */       
/*      */       case DOUBLE: 
/* 1794 */         if (null != this.cryptoMeta) {
/* 1795 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1797 */           paramDTVExecuteOp.execute(this, (Double)null);
/* 1798 */         break;
/*      */       
/*      */       case SMALLINT: 
/* 1801 */         if (null != this.cryptoMeta) {
/* 1802 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1804 */           paramDTVExecuteOp.execute(this, (Short)null);
/* 1805 */         break;
/*      */       
/*      */       case BIT: 
/*      */       case BOOLEAN: 
/* 1809 */         if (null != this.cryptoMeta) {
/* 1810 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */         } else
/* 1812 */           paramDTVExecuteOp.execute(this, (Boolean)null);
/* 1813 */         break;
/*      */       
/*      */       case SQLXML: 
/* 1816 */         paramDTVExecuteOp.execute(this, (SQLServerSQLXML)null);
/* 1817 */         break;
/*      */       
/*      */       case ARRAY: 
/*      */       case DATALINK: 
/*      */       case DISTINCT: 
/*      */       case JAVA_OBJECT: 
/*      */       case NULL: 
/*      */       case OTHER: 
/*      */       case REF: 
/*      */       case ROWID: 
/*      */       case STRUCT: 
/* 1828 */         i = 1;
/* 1829 */         break;
/*      */       
/*      */       case UNKNOWN: 
/*      */       default: 
/* 1833 */         if (!$assertionsDisabled) throw new AssertionError("Unexpected JDBCType: " + localJDBCType);
/* 1834 */         i = 1;
/* 1835 */         break;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1840 */       if ((aeLogger.isLoggable(Level.FINE)) && (null != this.cryptoMeta))
/*      */       {
/* 1842 */         aeLogger.fine("Encrypting java data type: " + localJavaType);
/*      */       }
/*      */       
/* 1845 */       switch (localJavaType)
/*      */       {
/*      */       case STRING: 
/* 1848 */         if (JDBCType.GUID == localJDBCType)
/*      */         {
/* 1850 */           if ((localObject1 instanceof String))
/* 1851 */             localObject1 = UUID.fromString((String)localObject1);
/* 1852 */           localObject2 = Util.asGuidByteArray((UUID)localObject1);
/* 1853 */           paramDTVExecuteOp.execute(this, (byte[])localObject2);
/*      */ 
/*      */         }
/* 1856 */         else if (null != this.cryptoMeta)
/*      */         {
/*      */ 
/*      */ 
/* 1860 */           if ((localJDBCType == JDBCType.LONGNVARCHAR) && (JDBCType.VARCHAR == this.jdbcTypeSetByUser) && (Integer.MAX_VALUE < this.valueLength))
/*      */           {
/*      */ 
/*      */ 
/* 1864 */             localObject2 = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 1865 */             localObject3 = new Object[] { Integer.valueOf(Integer.MAX_VALUE), JDBCType.LONGVARCHAR };
/* 1866 */             throw new SQLServerException(this, ((MessageFormat)localObject2).format(localObject3), null, 0, false);
/*      */           }
/* 1868 */           if ((JDBCType.NVARCHAR == this.jdbcTypeSetByUser) && (1073741823 < this.valueLength))
/*      */           {
/*      */ 
/* 1871 */             localObject2 = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 1872 */             localObject3 = new Object[] { Integer.valueOf(1073741823), JDBCType.LONGNVARCHAR };
/* 1873 */             throw new SQLServerException(this, ((MessageFormat)localObject2).format(localObject3), null, 0, false);
/*      */           }
/*      */           
/* 1876 */           if ((JDBCType.NVARCHAR == this.jdbcTypeSetByUser) || (JDBCType.NCHAR == this.jdbcTypeSetByUser) || (JDBCType.LONGNVARCHAR == this.jdbcTypeSetByUser))
/*      */           {
/* 1878 */             arrayOfByte = ((String)localObject1).getBytes(Charset.forName("UTF-16LE"));
/*      */ 
/*      */           }
/* 1881 */           else if ((JDBCType.VARCHAR == this.jdbcTypeSetByUser) || (JDBCType.CHAR == this.jdbcTypeSetByUser) || (JDBCType.LONGVARCHAR == this.jdbcTypeSetByUser))
/*      */           {
/* 1883 */             arrayOfByte = ((String)localObject1).getBytes();
/*      */           }
/*      */           
/* 1886 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 1889 */           paramDTVExecuteOp.execute(this, (String)localObject1);
/*      */         }
/* 1891 */         break;
/*      */       
/*      */       case INTEGER: 
/* 1894 */         if (null != this.cryptoMeta)
/*      */         {
/* 1896 */           arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Integer)localObject1).longValue()).array();
/* 1897 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 1900 */           paramDTVExecuteOp.execute(this, (Integer)localObject1); }
/* 1901 */         break;
/*      */       
/*      */       case DATE: 
/* 1904 */         paramDTVExecuteOp.execute(this, (java.sql.Date)localObject1);
/* 1905 */         break;
/*      */       
/*      */       case TIME: 
/* 1908 */         paramDTVExecuteOp.execute(this, (Time)localObject1);
/* 1909 */         break;
/*      */       
/*      */       case TIMESTAMP: 
/* 1912 */         if (JDBCType.SMALLDATETIME == localJDBCType)
/*      */         {
/* 1914 */           localObject2 = (Timestamp)localObject1;
/* 1915 */           if ((((Timestamp)localObject2).after(TDS.MAX_TIMESTAMP)) || (((Timestamp)localObject2).before(TDS.MIN_TIMESTAMP)))
/*      */           {
/* 1917 */             localObject3 = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1918 */             throw new SQLServerException(((MessageFormat)localObject3).format(new Object[] { localJDBCType }), null, 0, null);
/*      */           }
/*      */         }
/* 1921 */         paramDTVExecuteOp.execute(this, (Timestamp)localObject1);
/* 1922 */         break;
/*      */       
/*      */       case TVP: 
/* 1925 */         paramDTVExecuteOp.execute(this, (TVP)localObject1);
/* 1926 */         break;
/*      */       
/*      */       case UTILDATE: 
/* 1929 */         paramDTVExecuteOp.execute(this, (java.util.Date)localObject1);
/* 1930 */         break;
/*      */       
/*      */       case CALENDAR: 
/* 1933 */         paramDTVExecuteOp.execute(this, (Calendar)localObject1);
/* 1934 */         break;
/*      */       
/*      */       case LOCALDATE: 
/* 1937 */         paramDTVExecuteOp.execute(this, (LocalDate)localObject1);
/* 1938 */         break;
/*      */       
/*      */       case LOCALTIME: 
/* 1941 */         paramDTVExecuteOp.execute(this, (LocalTime)localObject1);
/* 1942 */         break;
/*      */       
/*      */       case LOCALDATETIME: 
/* 1945 */         paramDTVExecuteOp.execute(this, (LocalDateTime)localObject1);
/* 1946 */         break;
/*      */       
/*      */       case OFFSETTIME: 
/* 1949 */         paramDTVExecuteOp.execute(this, (OffsetTime)localObject1);
/* 1950 */         break;
/*      */       
/*      */       case OFFSETDATETIME: 
/* 1953 */         paramDTVExecuteOp.execute(this, (OffsetDateTime)localObject1);
/* 1954 */         break;
/*      */       
/*      */       case DATETIMEOFFSET: 
/* 1957 */         paramDTVExecuteOp.execute(this, (DateTimeOffset)localObject1);
/* 1958 */         break;
/*      */       
/*      */       case FLOAT: 
/* 1961 */         if (null != this.cryptoMeta)
/*      */         {
/* 1963 */           if (Float.isInfinite(((Float)localObject1).floatValue()))
/*      */           {
/* 1965 */             localObject2 = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1966 */             throw new SQLServerException(((MessageFormat)localObject2).format(new Object[] { localJDBCType }), null, 0, null);
/*      */           }
/*      */           
/* 1969 */           arrayOfByte = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(((Float)localObject1).floatValue()).array();
/* 1970 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 1973 */           paramDTVExecuteOp.execute(this, (Float)localObject1); }
/* 1974 */         break;
/*      */       
/*      */       case BIGDECIMAL: 
/* 1977 */         if (null != this.cryptoMeta)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1983 */           if ((JDBCType.MONEY == localJDBCType) || (JDBCType.SMALLMONEY == localJDBCType))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1988 */             localObject2 = (BigDecimal)localObject1;
/*      */             
/* 1990 */             Util.validateMoneyRange((BigDecimal)localObject2, localJDBCType);
/*      */             
/*      */ 
/*      */ 
/* 1994 */             int j = Math.max(((BigDecimal)localObject2).precision() - ((BigDecimal)localObject2).scale(), 0) + 4;
/*      */             
/* 1996 */             long l = ((BigDecimal)localObject1).multiply(new BigDecimal(10000), new MathContext(j, RoundingMode.HALF_UP)).longValue();
/* 1997 */             ByteBuffer localByteBuffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
/* 1998 */             localByteBuffer.putInt((int)(l >> 32)).array();
/* 1999 */             localByteBuffer.putInt((int)l).array();
/* 2000 */             paramDTVExecuteOp.execute(this, (byte[])localByteBuffer.array());
/*      */           }
/*      */           else
/*      */           {
/* 2004 */             localObject2 = (BigDecimal)localObject1;
/* 2005 */             localObject4 = DDC.convertBigDecimalToBytes((BigDecimal)localObject2, ((BigDecimal)localObject2).scale());
/* 2006 */             arrayOfByte = new byte[16];
/*      */             
/* 2008 */             System.arraycopy(localObject4, 2, arrayOfByte, 0, localObject4.length - 2);
/* 2009 */             setScale(Integer.valueOf(((BigDecimal)localObject2).scale()));
/* 2010 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */           }
/*      */         }
/*      */         else
/* 2014 */           paramDTVExecuteOp.execute(this, (BigDecimal)localObject1);
/* 2015 */         break;
/*      */       
/*      */       case BYTEARRAY: 
/* 2018 */         if ((null != this.cryptoMeta) && (Integer.MAX_VALUE < this.valueLength))
/*      */         {
/* 2020 */           localObject2 = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 2021 */           localObject4 = new Object[] { Integer.valueOf(Integer.MAX_VALUE), JDBCType.BINARY };
/* 2022 */           throw new SQLServerException(this, ((MessageFormat)localObject2).format(localObject4), null, 0, false);
/*      */         }
/*      */         
/* 2025 */         paramDTVExecuteOp.execute(this, (byte[])localObject1);
/* 2026 */         break;
/*      */       
/*      */ 
/*      */       case BYTE: 
/* 2030 */         if (null != this.cryptoMeta)
/*      */         {
/* 2032 */           arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Byte)localObject1).byteValue() & 0xFF).array();
/* 2033 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 2036 */           paramDTVExecuteOp.execute(this, (Byte)localObject1); }
/* 2037 */         break;
/*      */       
/*      */       case LONG: 
/* 2040 */         if (null != this.cryptoMeta)
/*      */         {
/* 2042 */           arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Long)localObject1).longValue()).array();
/* 2043 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 2046 */           paramDTVExecuteOp.execute(this, (Long)localObject1); }
/* 2047 */         break;
/*      */       
/*      */       case BIGINTEGER: 
/* 2050 */         paramDTVExecuteOp.execute(this, (BigInteger)localObject1);
/* 2051 */         break;
/*      */       
/*      */       case DOUBLE: 
/* 2054 */         if (null != this.cryptoMeta)
/*      */         {
/* 2056 */           if (Double.isInfinite(((Double)localObject1).doubleValue()))
/*      */           {
/* 2058 */             localObject2 = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 2059 */             throw new SQLServerException(((MessageFormat)localObject2).format(new Object[] { localJDBCType }), null, 0, null);
/*      */           }
/* 2061 */           arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(((Double)localObject1).doubleValue()).array();
/* 2062 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 2065 */           paramDTVExecuteOp.execute(this, (Double)localObject1); }
/* 2066 */         break;
/*      */       
/*      */       case SHORT: 
/* 2069 */         if (null != this.cryptoMeta)
/*      */         {
/* 2071 */           arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Short)localObject1).shortValue()).array();
/* 2072 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 2075 */           paramDTVExecuteOp.execute(this, (Short)localObject1); }
/* 2076 */         break;
/*      */       
/*      */       case BOOLEAN: 
/* 2079 */         if (null != this.cryptoMeta)
/*      */         {
/* 2081 */           arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Boolean)localObject1).booleanValue() ? 1L : 0L).array();
/* 2082 */           paramDTVExecuteOp.execute(this, (byte[])arrayOfByte);
/*      */         }
/*      */         else {
/* 2085 */           paramDTVExecuteOp.execute(this, (Boolean)localObject1); }
/* 2086 */         break;
/*      */       
/*      */       case BLOB: 
/* 2089 */         paramDTVExecuteOp.execute(this, (Blob)localObject1);
/* 2090 */         break;
/*      */       
/*      */       case CLOB: 
/*      */       case NCLOB: 
/* 2094 */         paramDTVExecuteOp.execute(this, (Clob)localObject1);
/* 2095 */         break;
/*      */       
/*      */       case INPUTSTREAM: 
/* 2098 */         paramDTVExecuteOp.execute(this, (InputStream)localObject1);
/* 2099 */         break;
/*      */       
/*      */       case READER: 
/* 2102 */         paramDTVExecuteOp.execute(this, (Reader)localObject1);
/* 2103 */         break;
/*      */       
/*      */       case SQLXML: 
/* 2106 */         paramDTVExecuteOp.execute(this, (SQLServerSQLXML)localObject1);
/* 2107 */         break;
/*      */       
/*      */       default: 
/* 2110 */         if (!$assertionsDisabled) throw new AssertionError("Unexpected JavaType: " + localJavaType);
/* 2111 */         i = 1;
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 2116 */     if (i != 0)
/*      */     {
/* 2118 */       localObject2 = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/* 2119 */       localObject4 = new Object[] { localJavaType, localJDBCType };
/* 2120 */       throw new SQLServerException(((MessageFormat)localObject2).format(localObject4), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void sendCryptoMetaData(CryptoMetadata paramCryptoMetadata, TDSWriter paramTDSWriter)
/*      */   {
/* 2130 */     this.cryptoMeta = paramCryptoMetadata;
/* 2131 */     paramTDSWriter.setCryptoMetaData(paramCryptoMetadata);
/*      */   }
/*      */   
/*      */   void jdbcTypeSetByUser(JDBCType paramJDBCType, int paramInt)
/*      */   {
/* 2136 */     this.jdbcTypeSetByUser = paramJDBCType;
/* 2137 */     this.valueLength = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void sendByRPC(String paramString, TypeInfo paramTypeInfo, SQLCollation paramSQLCollation, int paramInt1, int paramInt2, boolean paramBoolean, TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection)
/*      */     throws SQLServerException
/*      */   {
/* 2154 */     executeOp(new SendByRPCOp(paramString, paramTypeInfo, paramSQLCollation, paramInt1, paramInt2, paramBoolean, paramTDSWriter, paramSQLServerConnection));
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/DTV.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */