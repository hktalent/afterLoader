/*      */ package oracle.jdbc.rowset;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import javax.sql.RowSet;
/*      */ import javax.sql.rowset.JdbcRowSet;
/*      */ import javax.sql.rowset.RowSetWarning;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.OracleSavepoint;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.driver.OracleDriver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleJDBCRowSet
/*      */   extends OracleRowSet
/*      */   implements RowSet, JdbcRowSet
/*      */ {
/*      */   private Connection connection;
/*      */   private static boolean driverManagerInitialized;
/*      */   private PreparedStatement preparedStatement;
/*      */   private ResultSet resultSet;
/*      */   
/*      */   public OracleJDBCRowSet()
/*      */     throws SQLException
/*      */   {
/*  173 */     driverManagerInitialized = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleJDBCRowSet(Connection paramConnection)
/*      */     throws SQLException
/*      */   {
/*  188 */     this();
/*      */     
/*      */ 
/*      */ 
/*  192 */     this.connection = paramConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void execute()
/*      */     throws SQLException
/*      */   {
/*  202 */     this.connection = getConnection(this);
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  208 */       this.connection.setTransactionIsolation(getTransactionIsolation());
/*      */     }
/*      */     catch (Exception localException) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  215 */     this.connection.setTypeMap(getTypeMap());
/*      */     
/*  217 */     if (this.preparedStatement == null) {
/*  218 */       this.preparedStatement = this.connection.prepareStatement(getCommand(), getType(), getConcurrency());
/*      */     }
/*  220 */     this.preparedStatement.setFetchSize(getFetchSize());
/*  221 */     this.preparedStatement.setFetchDirection(getFetchDirection());
/*  222 */     this.preparedStatement.setMaxFieldSize(getMaxFieldSize());
/*  223 */     this.preparedStatement.setMaxRows(getMaxRows());
/*  224 */     this.preparedStatement.setQueryTimeout(getQueryTimeout());
/*  225 */     this.preparedStatement.setEscapeProcessing(getEscapeProcessing());
/*      */     
/*      */ 
/*      */ 
/*  229 */     this.resultSet = this.preparedStatement.executeQuery();
/*  230 */     notifyRowSetChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  242 */     if (this.resultSet != null) {
/*  243 */       this.resultSet.close();
/*      */     }
/*  245 */     if (this.preparedStatement != null) {
/*  246 */       this.preparedStatement.close();
/*      */     }
/*  248 */     if ((this.connection != null) && (!this.connection.isClosed()))
/*      */     {
/*  250 */       this.connection.commit();
/*  251 */       this.connection.close();
/*      */     }
/*  253 */     notifyRowSetChanged();
/*      */     
/*  255 */     this.isClosed = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Connection getConnection(RowSet paramRowSet)
/*      */     throws SQLException
/*      */   {
/*  273 */     Connection localConnection = null;
/*      */     
/*      */ 
/*      */ 
/*  277 */     if ((this.connection != null) && (!this.connection.isClosed()))
/*      */     {
/*  279 */       localConnection = this.connection;
/*      */     } else { Object localObject;
/*  281 */       if (paramRowSet.getDataSourceName() != null)
/*      */       {
/*      */         try
/*      */         {
/*  285 */           InitialContext localInitialContext = new InitialContext();
/*  286 */           localObject = (DataSource)localInitialContext.lookup(paramRowSet.getDataSourceName());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  291 */           if ((paramRowSet.getUsername() == null) || (paramRowSet.getPassword() == null))
/*      */           {
/*      */ 
/*  294 */             localConnection = ((DataSource)localObject).getConnection();
/*      */           }
/*      */           else
/*      */           {
/*  298 */             localConnection = ((DataSource)localObject).getConnection(paramRowSet.getUsername(), paramRowSet.getPassword());
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         catch (NamingException localNamingException)
/*      */         {
/*  305 */           localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 300, localNamingException.getMessage());
/*  306 */           ((SQLException)localObject).fillInStackTrace();
/*  307 */           throw ((Throwable)localObject);
/*      */         }
/*      */         
/*      */       }
/*  311 */       else if (paramRowSet.getUrl() != null)
/*      */       {
/*  313 */         if (!driverManagerInitialized)
/*      */         {
/*  315 */           DriverManager.registerDriver(new OracleDriver());
/*  316 */           driverManagerInitialized = true;
/*      */         }
/*  318 */         String str1 = paramRowSet.getUrl();
/*  319 */         localObject = paramRowSet.getUsername();
/*  320 */         String str2 = paramRowSet.getPassword();
/*      */         
/*      */ 
/*      */ 
/*  324 */         if ((str1.equals("")) || (((String)localObject).equals("")) || (str2.equals("")))
/*      */         {
/*      */ 
/*  327 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
/*  328 */           localSQLException.fillInStackTrace();
/*  329 */           throw localSQLException;
/*      */         }
/*      */         
/*  332 */         localConnection = DriverManager.getConnection(str1, (String)localObject, str2);
/*      */       }
/*      */     }
/*  335 */     return localConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  348 */     return this.resultSet.wasNull();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  357 */     return this.resultSet.getWarnings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  366 */     this.resultSet.clearWarnings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/*  376 */     return this.resultSet.getCursorName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  385 */     return new OracleRowSetMetaData(this.resultSet.getMetaData());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int findColumn(String paramString)
/*      */     throws SQLException
/*      */   {
/*  394 */     return this.resultSet.findColumn(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  403 */     this.preparedStatement.clearParameters();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Statement getStatement()
/*      */     throws SQLException
/*      */   {
/*  418 */     return this.resultSet.getStatement();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCommand(String paramString)
/*      */     throws SQLException
/*      */   {
/*  433 */     super.setCommand(paramString);
/*      */     
/*  435 */     if ((this.connection == null) || (this.connection.isClosed())) {
/*  436 */       this.connection = getConnection(this);
/*      */     }
/*  438 */     if (this.preparedStatement != null)
/*      */     {
/*      */       try
/*      */       {
/*  442 */         this.preparedStatement.close();
/*  443 */         this.preparedStatement = null;
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */     }
/*  447 */     this.preparedStatement = this.connection.prepareStatement(paramString, getType(), getConcurrency());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadOnly(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  457 */     super.setReadOnly(paramBoolean);
/*      */     
/*  459 */     if (this.connection != null)
/*      */     {
/*  461 */       this.connection.setReadOnly(paramBoolean);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  466 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 302);
/*  467 */       localSQLException.fillInStackTrace();
/*  468 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  480 */     super.setFetchDirection(paramInt);
/*      */     
/*  482 */     this.resultSet.setFetchDirection(this.fetchDirection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShowDeleted(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  492 */     if (paramBoolean)
/*      */     {
/*      */ 
/*  495 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 303);
/*  496 */       localSQLException.fillInStackTrace();
/*  497 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  502 */     super.setShowDeleted(paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/*  517 */     boolean bool = this.resultSet.next();
/*      */     
/*      */ 
/*      */ 
/*  521 */     if (bool) {
/*  522 */       notifyCursorMoved();
/*      */     }
/*  524 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/*  533 */     boolean bool = this.resultSet.previous();
/*      */     
/*      */ 
/*      */ 
/*  537 */     if (bool) {
/*  538 */       notifyCursorMoved();
/*      */     }
/*  540 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  549 */     if (!isBeforeFirst())
/*      */     {
/*  551 */       this.resultSet.beforeFirst();
/*  552 */       notifyCursorMoved();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void afterLast()
/*      */     throws SQLException
/*      */   {
/*  563 */     if (!isAfterLast())
/*      */     {
/*  565 */       this.resultSet.afterLast();
/*  566 */       notifyCursorMoved();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean first()
/*      */     throws SQLException
/*      */   {
/*  577 */     boolean bool = this.resultSet.first();
/*      */     
/*      */ 
/*      */ 
/*  581 */     if (bool) {
/*  582 */       notifyCursorMoved();
/*      */     }
/*  584 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/*  593 */     boolean bool = this.resultSet.last();
/*      */     
/*      */ 
/*      */ 
/*  597 */     if (bool) {
/*  598 */       notifyCursorMoved();
/*      */     }
/*  600 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean absolute(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  610 */     boolean bool = this.resultSet.absolute(paramInt);
/*      */     
/*      */ 
/*      */ 
/*  614 */     if (bool) {
/*  615 */       notifyCursorMoved();
/*      */     }
/*  617 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean relative(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  626 */     boolean bool = this.resultSet.relative(paramInt);
/*      */     
/*      */ 
/*      */ 
/*  630 */     if (bool) {
/*  631 */       notifyCursorMoved();
/*      */     }
/*  633 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  642 */     return this.resultSet.isBeforeFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  651 */     return this.resultSet.isAfterLast();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  660 */     return this.resultSet.isFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  669 */     return this.resultSet.isLast();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/*  683 */     if (isReadOnly())
/*      */     {
/*  685 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/*  686 */       localSQLException.fillInStackTrace();
/*  687 */       throw localSQLException;
/*      */     }
/*      */     
/*  690 */     this.resultSet.insertRow();
/*  691 */     notifyRowChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/*  701 */     if (isReadOnly())
/*      */     {
/*  703 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/*  704 */       localSQLException.fillInStackTrace();
/*  705 */       throw localSQLException;
/*      */     }
/*      */     
/*  708 */     this.resultSet.updateRow();
/*  709 */     notifyRowChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/*  719 */     if (isReadOnly())
/*      */     {
/*  721 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/*  722 */       localSQLException.fillInStackTrace();
/*  723 */       throw localSQLException;
/*      */     }
/*      */     
/*  726 */     this.resultSet.deleteRow();
/*  727 */     notifyRowChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/*  737 */     this.resultSet.refreshRow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/*  747 */     this.resultSet.cancelRowUpdates();
/*  748 */     notifyRowChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/*  758 */     if (isReadOnly())
/*      */     {
/*  760 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/*  761 */       localSQLException.fillInStackTrace();
/*  762 */       throw localSQLException;
/*      */     }
/*      */     
/*  765 */     this.resultSet.moveToInsertRow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/*  775 */     if (isReadOnly())
/*      */     {
/*  777 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/*  778 */       localSQLException.fillInStackTrace();
/*  779 */       throw localSQLException;
/*      */     }
/*      */     
/*  782 */     this.resultSet.moveToCurrentRow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/*  792 */     return this.resultSet.getRow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/*  801 */     return this.resultSet.rowUpdated();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/*  810 */     return this.resultSet.rowInserted();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/*  819 */     return this.resultSet.rowDeleted();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  833 */     this.preparedStatement.setNull(paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/*  843 */     this.preparedStatement.setNull(paramInt1, paramInt2, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  853 */     this.preparedStatement.setBoolean(paramInt, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/*  863 */     this.preparedStatement.setByte(paramInt, paramByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/*  873 */     this.preparedStatement.setShort(paramInt, paramShort);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  883 */     this.preparedStatement.setInt(paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/*  893 */     this.preparedStatement.setLong(paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/*  903 */     this.preparedStatement.setFloat(paramInt, paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/*  913 */     this.preparedStatement.setDouble(paramInt, paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/*  923 */     this.preparedStatement.setBigDecimal(paramInt, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/*  933 */     this.preparedStatement.setString(paramInt, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/*  943 */     this.preparedStatement.setBytes(paramInt, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int paramInt, Date paramDate)
/*      */     throws SQLException
/*      */   {
/*  953 */     this.preparedStatement.setDate(paramInt, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/*  963 */     this.preparedStatement.setTime(paramInt, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/*  973 */     this.preparedStatement.setObject(paramInt, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/*  983 */     this.preparedStatement.setRef(paramInt, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/*  993 */     this.preparedStatement.setBlob(paramInt, paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 1003 */     this.preparedStatement.setClob(paramInt, paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 1013 */     this.preparedStatement.setArray(paramInt, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1024 */     this.preparedStatement.setBinaryStream(paramInt1, paramInputStream, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1034 */     this.preparedStatement.setTime(paramInt, paramTime, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1045 */     this.preparedStatement.setTimestamp(paramInt, paramTimestamp, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 1055 */     this.preparedStatement.setTimestamp(paramInt, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1066 */     this.preparedStatement.setAsciiStream(paramInt1, paramInputStream, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1077 */     this.preparedStatement.setCharacterStream(paramInt1, paramReader, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 1088 */     this.preparedStatement.setObject(paramInt1, paramObject, paramInt2, paramInt3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1098 */     this.preparedStatement.setObject(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1108 */     this.preparedStatement.setDate(paramInt, paramDate, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1122 */     return this.resultSet.getObject(paramInt, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1131 */     return this.resultSet.getBigDecimal(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1140 */     return this.resultSet.getRef(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1149 */     return this.resultSet.getBlob(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1158 */     return this.resultSet.getClob(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1167 */     return this.resultSet.getArray(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1176 */     return this.resultSet.getDate(paramInt, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1185 */     return this.resultSet.getCharacterStream(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1194 */     return this.resultSet.getTime(paramInt, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1203 */     return this.resultSet.getBinaryStream(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1212 */     return this.resultSet.getTimestamp(paramInt, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1220 */     return this.resultSet.getString(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1229 */     return this.resultSet.getBoolean(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1238 */     return this.resultSet.getByte(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1247 */     return this.resultSet.getShort(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1256 */     return this.resultSet.getLong(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1265 */     return this.resultSet.getFloat(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1274 */     return this.resultSet.getDouble(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1283 */     return this.resultSet.getBigDecimal(paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1292 */     return this.resultSet.getBytes(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1301 */     return this.resultSet.getDate(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1310 */     return this.resultSet.getTime(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1319 */     return this.resultSet.getTimestamp(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1328 */     return this.resultSet.getAsciiStream(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1337 */     return this.resultSet.getUnicodeStream(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1346 */     return this.resultSet.getInt(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1356 */     return this.resultSet.getObject(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1370 */     return this.resultSet.getInt(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1379 */     return this.resultSet.getLong(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1388 */     return this.resultSet.getFloat(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1397 */     return this.resultSet.getDouble(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1406 */     return this.resultSet.getBigDecimal(paramString, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1415 */     return this.resultSet.getBytes(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1424 */     return this.resultSet.getDate(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1433 */     return this.resultSet.getTime(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1442 */     return this.resultSet.getTimestamp(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1451 */     return this.resultSet.getAsciiStream(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1460 */     return this.resultSet.getUnicodeStream(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1469 */     return this.resultSet.getObject(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1478 */     return this.resultSet.getCharacterStream(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String paramString, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1488 */     return this.resultSet.getObject(paramString, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1497 */     return this.resultSet.getRef(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1506 */     return this.resultSet.getBlob(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1515 */     return this.resultSet.getClob(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1524 */     return this.resultSet.getArray(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1533 */     return this.resultSet.getBigDecimal(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1542 */     return this.resultSet.getDate(paramString, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1551 */     return this.resultSet.getTime(paramString, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1560 */     return this.resultSet.getBinaryStream(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1569 */     return this.resultSet.getTimestamp(paramString, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getString(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1577 */     return this.resultSet.getString(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1586 */     return this.resultSet.getBoolean(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1595 */     return this.resultSet.getByte(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1604 */     return this.resultSet.getShort(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1618 */     if (isReadOnly())
/*      */     {
/* 1620 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1621 */       localSQLException.fillInStackTrace();
/* 1622 */       throw localSQLException;
/*      */     }
/*      */     
/* 1625 */     this.resultSet.updateNull(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1636 */     if (isReadOnly())
/*      */     {
/* 1638 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1639 */       localSQLException.fillInStackTrace();
/* 1640 */       throw localSQLException;
/*      */     }
/*      */     
/* 1643 */     this.resultSet.updateCharacterStream(paramInt1, paramReader, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 1653 */     if (isReadOnly())
/*      */     {
/* 1655 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1656 */       localSQLException.fillInStackTrace();
/* 1657 */       throw localSQLException;
/*      */     }
/*      */     
/* 1660 */     this.resultSet.updateTimestamp(paramInt, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1671 */     if (isReadOnly())
/*      */     {
/* 1673 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1674 */       localSQLException.fillInStackTrace();
/* 1675 */       throw localSQLException;
/*      */     }
/*      */     
/* 1678 */     this.resultSet.updateBinaryStream(paramInt1, paramInputStream, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1689 */     if (isReadOnly())
/*      */     {
/* 1691 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1692 */       localSQLException.fillInStackTrace();
/* 1693 */       throw localSQLException;
/*      */     }
/*      */     
/* 1696 */     this.resultSet.updateAsciiStream(paramInt1, paramInputStream, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1706 */     if (isReadOnly())
/*      */     {
/* 1708 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1709 */       localSQLException.fillInStackTrace();
/* 1710 */       throw localSQLException;
/*      */     }
/*      */     
/* 1713 */     this.resultSet.updateBoolean(paramInt, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 1723 */     if (isReadOnly())
/*      */     {
/* 1725 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1726 */       localSQLException.fillInStackTrace();
/* 1727 */       throw localSQLException;
/*      */     }
/*      */     
/* 1730 */     this.resultSet.updateByte(paramInt, paramByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 1740 */     if (isReadOnly())
/*      */     {
/* 1742 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1743 */       localSQLException.fillInStackTrace();
/* 1744 */       throw localSQLException;
/*      */     }
/*      */     
/* 1747 */     this.resultSet.updateShort(paramInt, paramShort);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1757 */     if (isReadOnly())
/*      */     {
/* 1759 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1760 */       localSQLException.fillInStackTrace();
/* 1761 */       throw localSQLException;
/*      */     }
/*      */     
/* 1764 */     this.resultSet.updateInt(paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1774 */     if (isReadOnly())
/*      */     {
/* 1776 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1777 */       localSQLException.fillInStackTrace();
/* 1778 */       throw localSQLException;
/*      */     }
/*      */     
/* 1781 */     this.resultSet.updateLong(paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 1791 */     if (isReadOnly())
/*      */     {
/* 1793 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1794 */       localSQLException.fillInStackTrace();
/* 1795 */       throw localSQLException;
/*      */     }
/*      */     
/* 1798 */     this.resultSet.updateFloat(paramInt, paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 1808 */     if (isReadOnly())
/*      */     {
/* 1810 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1811 */       localSQLException.fillInStackTrace();
/* 1812 */       throw localSQLException;
/*      */     }
/*      */     
/* 1815 */     this.resultSet.updateDouble(paramInt, paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 1825 */     if (isReadOnly())
/*      */     {
/* 1827 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1828 */       localSQLException.fillInStackTrace();
/* 1829 */       throw localSQLException;
/*      */     }
/*      */     
/* 1832 */     this.resultSet.updateBigDecimal(paramInt, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 1842 */     if (isReadOnly())
/*      */     {
/* 1844 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1845 */       localSQLException.fillInStackTrace();
/* 1846 */       throw localSQLException;
/*      */     }
/*      */     
/* 1849 */     this.resultSet.updateString(paramInt, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1859 */     if (isReadOnly())
/*      */     {
/* 1861 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1862 */       localSQLException.fillInStackTrace();
/* 1863 */       throw localSQLException;
/*      */     }
/*      */     
/* 1866 */     this.resultSet.updateBytes(paramInt, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(int paramInt, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 1876 */     if (isReadOnly())
/*      */     {
/* 1878 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1879 */       localSQLException.fillInStackTrace();
/* 1880 */       throw localSQLException;
/*      */     }
/*      */     
/* 1883 */     this.resultSet.updateDate(paramInt, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 1893 */     if (isReadOnly())
/*      */     {
/* 1895 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1896 */       localSQLException.fillInStackTrace();
/* 1897 */       throw localSQLException;
/*      */     }
/*      */     
/* 1900 */     this.resultSet.updateTime(paramInt, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 1910 */     if (isReadOnly())
/*      */     {
/* 1912 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1913 */       localSQLException.fillInStackTrace();
/* 1914 */       throw localSQLException;
/*      */     }
/*      */     
/* 1917 */     this.resultSet.updateObject(paramInt, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1927 */     if (isReadOnly())
/*      */     {
/* 1929 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1930 */       localSQLException.fillInStackTrace();
/* 1931 */       throw localSQLException;
/*      */     }
/*      */     
/* 1934 */     this.resultSet.updateObject(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1949 */     if (isReadOnly())
/*      */     {
/* 1951 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1952 */       localSQLException.fillInStackTrace();
/* 1953 */       throw localSQLException;
/*      */     }
/*      */     
/* 1956 */     this.resultSet.updateNull(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1966 */     if (isReadOnly())
/*      */     {
/* 1968 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1969 */       localSQLException.fillInStackTrace();
/* 1970 */       throw localSQLException;
/*      */     }
/*      */     
/* 1973 */     this.resultSet.updateBoolean(paramString, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(String paramString, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 1983 */     if (isReadOnly())
/*      */     {
/* 1985 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 1986 */       localSQLException.fillInStackTrace();
/* 1987 */       throw localSQLException;
/*      */     }
/*      */     
/* 1990 */     this.resultSet.updateByte(paramString, paramByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(String paramString, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2000 */     if (isReadOnly())
/*      */     {
/* 2002 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2003 */       localSQLException.fillInStackTrace();
/* 2004 */       throw localSQLException;
/*      */     }
/*      */     
/* 2007 */     this.resultSet.updateShort(paramString, paramShort);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2017 */     if (isReadOnly())
/*      */     {
/* 2019 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2020 */       localSQLException.fillInStackTrace();
/* 2021 */       throw localSQLException;
/*      */     }
/*      */     
/* 2024 */     this.resultSet.updateInt(paramString, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(String paramString, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2034 */     if (isReadOnly())
/*      */     {
/* 2036 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2037 */       localSQLException.fillInStackTrace();
/* 2038 */       throw localSQLException;
/*      */     }
/*      */     
/* 2041 */     this.resultSet.updateLong(paramString, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(String paramString, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 2051 */     if (isReadOnly())
/*      */     {
/* 2053 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2054 */       localSQLException.fillInStackTrace();
/* 2055 */       throw localSQLException;
/*      */     }
/*      */     
/* 2058 */     this.resultSet.updateFloat(paramString, paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(String paramString, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 2068 */     if (isReadOnly())
/*      */     {
/* 2070 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2071 */       localSQLException.fillInStackTrace();
/* 2072 */       throw localSQLException;
/*      */     }
/*      */     
/* 2075 */     this.resultSet.updateDouble(paramString, paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 2085 */     if (isReadOnly())
/*      */     {
/* 2087 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2088 */       localSQLException.fillInStackTrace();
/* 2089 */       throw localSQLException;
/*      */     }
/*      */     
/* 2092 */     this.resultSet.updateBigDecimal(paramString, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 2102 */     if (isReadOnly())
/*      */     {
/* 2104 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2105 */       localSQLException.fillInStackTrace();
/* 2106 */       throw localSQLException;
/*      */     }
/*      */     
/* 2109 */     this.resultSet.updateString(paramString1, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(String paramString, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2119 */     if (isReadOnly())
/*      */     {
/* 2121 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2122 */       localSQLException.fillInStackTrace();
/* 2123 */       throw localSQLException;
/*      */     }
/*      */     
/* 2126 */     this.resultSet.updateBytes(paramString, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(String paramString, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 2136 */     if (isReadOnly())
/*      */     {
/* 2138 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2139 */       localSQLException.fillInStackTrace();
/* 2140 */       throw localSQLException;
/*      */     }
/*      */     
/* 2143 */     this.resultSet.updateDate(paramString, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(String paramString, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 2153 */     if (isReadOnly())
/*      */     {
/* 2155 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2156 */       localSQLException.fillInStackTrace();
/* 2157 */       throw localSQLException;
/*      */     }
/*      */     
/* 2160 */     this.resultSet.updateTime(paramString, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String paramString, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 2170 */     if (isReadOnly())
/*      */     {
/* 2172 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2173 */       localSQLException.fillInStackTrace();
/* 2174 */       throw localSQLException;
/*      */     }
/*      */     
/* 2177 */     this.resultSet.updateObject(paramString, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2187 */     if (isReadOnly())
/*      */     {
/* 2189 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2190 */       localSQLException.fillInStackTrace();
/* 2191 */       throw localSQLException;
/*      */     }
/*      */     
/* 2194 */     this.resultSet.updateObject(paramString, paramObject, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2205 */     if (isReadOnly())
/*      */     {
/* 2207 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2208 */       localSQLException.fillInStackTrace();
/* 2209 */       throw localSQLException;
/*      */     }
/*      */     
/* 2212 */     this.resultSet.updateBinaryStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2223 */     if (isReadOnly())
/*      */     {
/* 2225 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2226 */       localSQLException.fillInStackTrace();
/* 2227 */       throw localSQLException;
/*      */     }
/*      */     
/* 2230 */     this.resultSet.updateAsciiStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 2240 */     if (isReadOnly())
/*      */     {
/* 2242 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2243 */       localSQLException.fillInStackTrace();
/* 2244 */       throw localSQLException;
/*      */     }
/*      */     
/* 2247 */     this.resultSet.updateTimestamp(paramString, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2258 */     if (isReadOnly())
/*      */     {
/* 2260 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2261 */       localSQLException.fillInStackTrace();
/* 2262 */       throw localSQLException;
/*      */     }
/*      */     
/* 2265 */     this.resultSet.updateCharacterStream(paramString, paramReader, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2293 */     return ((OracleResultSet)this.resultSet).getURL(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(String paramString)
/*      */     throws SQLException
/*      */   {
/* 2317 */     return ((OracleResultSet)this.resultSet).getURL(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 2340 */     if (isReadOnly())
/*      */     {
/* 2342 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2343 */       localSQLException.fillInStackTrace();
/* 2344 */       throw localSQLException;
/*      */     }
/*      */     
/* 2347 */     ((OracleResultSet)this.resultSet).updateRef(paramInt, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRef(String paramString, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 2371 */     if (isReadOnly())
/*      */     {
/* 2373 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2374 */       localSQLException.fillInStackTrace();
/* 2375 */       throw localSQLException;
/*      */     }
/*      */     
/* 2378 */     ((OracleResultSet)this.resultSet).updateRef(paramString, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 2402 */     if (isReadOnly())
/*      */     {
/* 2404 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2405 */       localSQLException.fillInStackTrace();
/* 2406 */       throw localSQLException;
/*      */     }
/*      */     
/* 2409 */     ((OracleResultSet)this.resultSet).updateBlob(paramInt, paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBlob(String paramString, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 2433 */     if (isReadOnly())
/*      */     {
/* 2435 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2436 */       localSQLException.fillInStackTrace();
/* 2437 */       throw localSQLException;
/*      */     }
/*      */     
/* 2440 */     ((OracleResultSet)this.resultSet).updateBlob(paramString, paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 2464 */     if (isReadOnly())
/*      */     {
/* 2466 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2467 */       localSQLException.fillInStackTrace();
/* 2468 */       throw localSQLException;
/*      */     }
/*      */     
/* 2471 */     ((OracleResultSet)this.resultSet).updateClob(paramInt, paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateClob(String paramString, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 2495 */     if (isReadOnly())
/*      */     {
/* 2497 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2498 */       localSQLException.fillInStackTrace();
/* 2499 */       throw localSQLException;
/*      */     }
/*      */     
/* 2502 */     ((OracleResultSet)this.resultSet).updateClob(paramString, paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 2526 */     if (isReadOnly())
/*      */     {
/* 2528 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2529 */       localSQLException.fillInStackTrace();
/* 2530 */       throw localSQLException;
/*      */     }
/*      */     
/* 2533 */     ((OracleResultSet)this.resultSet).updateArray(paramInt, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateArray(String paramString, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 2557 */     if (isReadOnly())
/*      */     {
/* 2559 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2560 */       localSQLException.fillInStackTrace();
/* 2561 */       throw localSQLException;
/*      */     }
/*      */     
/* 2564 */     ((OracleResultSet)this.resultSet).updateArray(paramString, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void commit()
/*      */     throws SQLException
/*      */   {
/* 2589 */     if (this.connection != null)
/*      */     {
/* 2591 */       this.connection.commit();
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2596 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 302);
/* 2597 */       localSQLException.fillInStackTrace();
/* 2598 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLException
/*      */   {
/* 2622 */     if (this.connection != null)
/*      */     {
/* 2624 */       this.connection.rollback();
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2629 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 302);
/* 2630 */       localSQLException.fillInStackTrace();
/* 2631 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback(Savepoint paramSavepoint)
/*      */     throws SQLException
/*      */   {
/* 2657 */     if (this.connection != null)
/*      */     {
/* 2659 */       this.connection.rollback(paramSavepoint);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2664 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 302);
/* 2665 */       localSQLException.fillInStackTrace();
/* 2666 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void oracleRollback(OracleSavepoint paramOracleSavepoint)
/*      */     throws SQLException
/*      */   {
/* 2694 */     if (this.connection != null)
/*      */     {
/* 2696 */       ((oracle.jdbc.OracleConnection)this.connection).oracleRollback(paramOracleSavepoint);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2701 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 302);
/* 2702 */       localSQLException.fillInStackTrace();
/* 2703 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAutoCommit()
/*      */     throws SQLException
/*      */   {
/* 2725 */     if (this.connection != null)
/*      */     {
/* 2727 */       return this.connection.getAutoCommit();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2732 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 302);
/* 2733 */     localSQLException.fillInStackTrace();
/* 2734 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoCommit(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2760 */     if (this.connection != null)
/*      */     {
/* 2762 */       this.connection.setAutoCommit(paramBoolean);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2767 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 302);
/* 2768 */       localSQLException.fillInStackTrace();
/* 2769 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowSetWarning getRowSetWarnings()
/*      */     throws SQLException
/*      */   {
/* 2786 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getTableName()
/*      */     throws SQLException
/*      */   {
/* 2799 */     return getMetaData().getTableName(getMatchColumnIndexes()[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/*      */     try
/*      */     {
/* 2821 */       return (oracle.jdbc.internal.OracleConnection)this.connection;
/*      */     }
/*      */     catch (Exception localException) {}
/*      */     
/* 2825 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2832 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/rowset/OracleJDBCRowSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */