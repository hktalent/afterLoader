/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleDataFactory;
/*     */ import oracle.jdbc.oracore.OracleType;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.ArrayDescriptor;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.JAVA_STRUCT;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NamedTypeAccessor
/*     */   extends TypeAccessor
/*     */ {
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean)
/*     */     throws SQLException
/*     */   {
/*  38 */     init(paramOracleStatement, 109, 109, paramShort, paramBoolean);
/*  39 */     initForDataAccess(paramInt, 0, paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString)
/*     */     throws SQLException
/*     */   {
/*  49 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*  50 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*  52 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType)
/*     */     throws SQLException
/*     */   {
/*  62 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*     */     
/*  64 */     this.describeOtype = paramOracleType;
/*     */     
/*  66 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*     */ 
/*  69 */     this.internalOtype = paramOracleType;
/*     */     
/*  71 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */   
/*     */ 
/*     */   OracleType otypeFromName(String paramString)
/*     */     throws SQLException
/*     */   {
/*  78 */     if (!this.outBind) {
/*  79 */       return TypeDescriptor.getTypeDescriptor(paramString, this.statement.connection).getPickler();
/*     */     }
/*  81 */     if (this.externalType == 2003) {
/*  82 */       return ArrayDescriptor.createDescriptor(paramString, this.statement.connection).getOracleTypeCOLLECTION();
/*     */     }
/*  84 */     if (this.externalType == 2007)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  89 */       return OpaqueDescriptor.createDescriptor(paramString, this.statement.connection).getPickler();
/*     */     }
/*     */     
/*  92 */     return StructDescriptor.createDescriptor(paramString, this.statement.connection).getOracleTypeADT();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString)
/*     */     throws SQLException
/*     */   {
/* 101 */     super.initForDataAccess(paramInt1, paramInt2, paramString);
/*     */     
/* 103 */     this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 119 */     return getObject(paramInt, this.statement.connection.getTypeMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory)
/*     */     throws SQLException
/*     */   {
/* 135 */     return paramOracleDataFactory.create(getObject(paramInt, this.statement.connection.getTypeMap()), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt, Map paramMap)
/*     */     throws SQLException
/*     */   {
/*     */     Object localObject1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 151 */     if (this.rowSpaceIndicator == null)
/*     */     {
/* 153 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 154 */       ((SQLException)localObject1).fillInStackTrace();
/* 155 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 161 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*     */     {
/*     */ 
/*     */ 
/* 165 */       if (this.externalType == 0)
/*     */       {
/* 167 */         localObject1 = getOracleObject(paramInt);
/*     */         
/*     */ 
/*     */ 
/* 171 */         if (localObject1 == null) {
/* 172 */           return null;
/*     */         }
/* 174 */         if ((localObject1 instanceof STRUCT)) {
/* 175 */           return ((STRUCT)localObject1).toJdbc(paramMap);
/*     */         }
/* 177 */         if ((localObject1 instanceof OPAQUE)) {
/* 178 */           localObject2 = ((OPAQUE)localObject1).toJdbc(paramMap);
/* 179 */           return localObject2;
/*     */         }
/*     */         
/* 182 */         return ((Datum)localObject1).toJdbc();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 187 */       switch (this.externalType)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */       case 2008: 
/* 193 */         paramMap = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       case 2000: 
/*     */       case 2002: 
/*     */       case 2003: 
/*     */       case 2007: 
/* 202 */         localObject1 = getOracleObject(paramInt);
/*     */         
/*     */ 
/*     */ 
/* 206 */         if (localObject1 == null) {
/* 207 */           return null;
/*     */         }
/* 209 */         if ((localObject1 instanceof STRUCT)) {
/* 210 */           return ((STRUCT)localObject1).toJdbc(paramMap);
/*     */         }
/* 212 */         return ((Datum)localObject1).toJdbc();
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 221 */       Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 222 */       ((SQLException)localObject2).fillInStackTrace();
/* 223 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Datum getOracleObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 246 */     Object localObject1 = null;
/*     */     
/*     */ 
/* 249 */     if (this.rowSpaceIndicator == null)
/*     */     {
/* 251 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 252 */       ((SQLException)localObject2).fillInStackTrace();
/* 253 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 260 */     Object localObject2 = pickledBytes(paramInt);
/*     */     
/* 262 */     if ((localObject2 == null) || (localObject2.length == 0))
/*     */     {
/* 264 */       return null;
/*     */     }
/*     */     
/* 267 */     PhysicalConnection localPhysicalConnection = this.statement.connection;
/* 268 */     OracleTypeADT localOracleTypeADT = (OracleTypeADT)this.internalOtype;
/* 269 */     TypeDescriptor localTypeDescriptor = TypeDescriptor.getTypeDescriptor(localOracleTypeADT.getFullName(), localPhysicalConnection, (byte[])localObject2, 0L);
/*     */     
/*     */ 
/* 272 */     switch (localTypeDescriptor.getTypeCode())
/*     */     {
/*     */ 
/*     */     case 2003: 
/* 276 */       localObject1 = new ARRAY((ArrayDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 278 */       break;
/*     */     
/*     */     case 2002: 
/* 281 */       localObject1 = new STRUCT((StructDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 283 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 2007: 
/* 290 */       localObject1 = new OPAQUE((OpaqueDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 292 */       break;
/*     */     
/*     */     case 2008: 
/* 295 */       localObject1 = new JAVA_STRUCT((StructDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 297 */       break;
/*     */     
/*     */     case 2004: 
/*     */     case 2005: 
/*     */     case 2006: 
/*     */     default: 
/* 303 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/* 304 */       localSQLException.fillInStackTrace();
/* 305 */       throw localSQLException;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 312 */     return (Datum)localObject1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ARRAY getARRAY(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 328 */     return (ARRAY)getOracleObject(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   STRUCT getSTRUCT(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 344 */     return (STRUCT)getOracleObject(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OPAQUE getOPAQUE(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 360 */     return (OPAQUE)getOracleObject(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */   boolean isNull(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 367 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 371 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 372 */       ((SQLException)localObject).fillInStackTrace();
/* 373 */       throw ((Throwable)localObject);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 378 */     Object localObject = pickledBytes(paramInt);
/* 379 */     return (localObject == null) || (localObject.length == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 389 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/NamedTypeAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */