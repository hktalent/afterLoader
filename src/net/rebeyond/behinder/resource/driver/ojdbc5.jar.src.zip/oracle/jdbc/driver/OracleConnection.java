/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnectionWrapper;
/*     */ import oracle.jdbc.internal.ClientDataSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OracleConnection
/*     */   extends OracleConnectionWrapper
/*     */   implements oracle.jdbc.internal.OracleConnection, ClientDataSupport
/*     */ {
/*  40 */   static int DEFAULT_ROW_PREFETCH = 10;
/*     */   
/*     */   static final String svptPrefix = "ORACLE_SVPT_";
/*     */   
/*     */   static final int BINARYSTREAM = 0;
/*     */   
/*     */   static final int ASCIISTREAM = 1;
/*     */   
/*     */   static final int UNICODESTREAM = 2;
/*     */   
/*     */   static final int EOJ_NON = 0;
/*     */   
/*     */   static final int EOJ_B_TO_A = 1;
/*     */   
/*     */   static final int EOJ_B_TO_U = 2;
/*     */   
/*     */   static final int EOJ_A_TO_U = 3;
/*     */   
/*     */   static final int EOJ_8_TO_A = 4;
/*     */   
/*     */   static final int EOJ_8_TO_U = 5;
/*     */   
/*     */   static final int EOJ_U_TO_A = 6;
/*     */   
/*     */   static final int ASCII_CHARSET = 0;
/*     */   
/*     */   static final int NLS_CHARSET = 1;
/*     */   
/*     */   static final int CHAR_TO_ASCII = 0;
/*     */   
/*     */   static final int CHAR_TO_UNICODE = 1;
/*     */   
/*     */   static final int RAW_TO_ASCII = 2;
/*     */   
/*     */   static final int RAW_TO_UNICODE = 3;
/*     */   
/*     */   static final int UNICODE_TO_CHAR = 4;
/*     */   
/*     */   static final int ASCII_TO_CHAR = 5;
/*     */   
/*     */   static final int NONE = 6;
/*     */   
/*     */   static final int JAVACHAR_TO_CHAR = 7;
/*     */   
/*     */   static final int RAW_TO_JAVACHAR = 8;
/*     */   
/*     */   static final int CHAR_TO_JAVACHAR = 9;
/*     */   
/*     */   static final int JAVACHAR_TO_ASCII = 10;
/*     */   
/*     */   static final int JAVACHAR_TO_UNICODE = 11;
/*     */   
/*     */   static final int UNICODE_TO_ASCII = 12;
/*     */   
/*     */   public static final int KOLBLLENB = 0;
/*     */   
/*     */   public static final int KOLBLVSNB = 2;
/*     */   
/*     */   public static final byte KOLL1FLG = 4;
/*     */   
/*     */   public static final byte KOLL2FLG = 5;
/*     */   
/*     */   public static final byte KOLL3FLG = 6;
/*     */   
/*     */   public static final byte KOLL4FLG = 7;
/*     */   
/*     */   public static final int KOLBLCIDB = 32;
/*     */   
/*     */   static final byte ALLFLAGS = -1;
/*     */   
/*     */   public static final int KOLBLIMRLL = 86;
/*     */   
/*     */   public static final byte KOLBLBLOB = 1;
/*     */   
/*     */   public static final byte KOLBLCLOB = 2;
/*     */   
/*     */   public static final byte KOLBLNLOB = 4;
/*     */   
/*     */   public static final byte KOLBLBFIL = 8;
/*     */   
/*     */   public static final byte KOLBLCFIL = 16;
/*     */   
/*     */   public static final byte KOLBLNFIL = 32;
/*     */   
/*     */   public static final byte KOLBLABS = 64;
/*     */   
/*     */   public static final byte KOLBLPXY = -128;
/*     */   
/*     */   public static final byte KOLBLPKEY = 1;
/*     */   
/*     */   public static final byte KOLBLIMP = 2;
/*     */   
/*     */   public static final byte KOLBLIDX = 4;
/*     */   
/*     */   public static final byte KOLBLINI = 8;
/*     */   
/*     */   public static final byte KOLBLEMP = 16;
/*     */   
/*     */   public static final byte KOLBLVIEW = 32;
/*     */   
/*     */   public static final byte KOLBL0FRM = 64;
/*     */   
/*     */   public static final byte KOLBL1FRM = -128;
/*     */   
/*     */   public static final byte KOLBLRDO = 1;
/*     */   
/*     */   public static final byte KOLBLPART = 2;
/*     */   
/*     */   public static final byte KOLBLCPD = 4;
/*     */   
/*     */   public static final byte KOLBLDIL = 8;
/*     */   
/*     */   public static final byte KOLBLBUF = 16;
/*     */   
/*     */   public static final byte KOLBLBPS = 32;
/*     */   
/*     */   public static final byte KOLBLMOD = 64;
/*     */   
/*     */   public static final byte KOLBLVAR = -128;
/*     */   
/*     */   public static final byte KOLBLTMP = 1;
/*     */   
/*     */   public static final byte KOLBLCACHE = 2;
/*     */   
/*     */   public static final byte KOLBLOPEN = 8;
/*     */   
/*     */   public static final byte KOLBLRDWR = 16;
/*     */   public static final byte KOLBLCLI = 32;
/*     */   public static final byte KOLBLVLE = 64;
/*     */   public static final byte KOLBLLCL = -128;
/*     */   static final int KOLBLLIDB = 10;
/*     */   static final int KOLBLPREL = 2;
/*     */   static final int KOLBLLIDL = 10;
/*     */   static final int KOLBLTLMXL = 40;
/*     */   
/*     */   static boolean containsKey(Map paramMap, Object paramObject)
/*     */   {
/* 177 */     return paramMap.get(paramObject) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getClientData(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object setClientData(Object paramObject1, Object paramObject2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object removeClientData(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public abstract void setClientIdentifier(String paramString)
/*     */     throws SQLException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public abstract void clearClientIdentifier(String paramString)
/*     */     throws SQLException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling()
/*     */   {
/* 225 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class getClassForType(String paramString, Map<String, Class> paramMap)
/*     */   {
/* 242 */     Class localClass = (Class)paramMap.get(paramString);
/*     */     
/* 244 */     if (localClass == null)
/*     */     {
/* 246 */       ClassRef localClassRef = (ClassRef)OracleDriver.systemTypeMap.get(paramString);
/* 247 */       if (localClassRef != null) { localClass = localClassRef.get();
/*     */       }
/*     */     }
/* 250 */     return localClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 255 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OracleConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */