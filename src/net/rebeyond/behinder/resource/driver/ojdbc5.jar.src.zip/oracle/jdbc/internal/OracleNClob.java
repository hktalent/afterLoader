package oracle.jdbc.internal;

public abstract interface OracleNClob
  extends OracleDatumWithConnection, oracle.jdbc.OracleNClob, OracleClob
{}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/internal/OracleNClob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */