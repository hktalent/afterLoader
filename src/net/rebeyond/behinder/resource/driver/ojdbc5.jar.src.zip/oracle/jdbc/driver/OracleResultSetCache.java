package oracle.jdbc.driver;

public abstract interface OracleResultSetCache
  extends oracle.jdbc.internal.OracleResultSetCache
{}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OracleResultSetCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */