/*    */ package oracle.jdbc.oci;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleOCIConnection
/*    */   extends oracle.jdbc.driver.OracleOCIConnection
/*    */ {
/*    */   public OracleOCIConnection(String paramString, Properties paramProperties, Object paramObject)
/*    */     throws SQLException
/*    */   {
/* 35 */     super(paramString, paramProperties, paramObject);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/oci/OracleOCIConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */