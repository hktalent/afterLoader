package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

abstract interface ScrollRsetStatement
{
  public abstract Connection getConnection()
    throws SQLException;
  
  public abstract void notifyCloseRset()
    throws SQLException;
  
  public abstract int copyBinds(Statement paramStatement, int paramInt)
    throws SQLException;
  
  public abstract String getOriginalSql()
    throws SQLException;
  
  public abstract OracleResultSetCache getResultSetCache()
    throws SQLException;
  
  public abstract int getMaxFieldSize()
    throws SQLException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/ScrollRsetStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */