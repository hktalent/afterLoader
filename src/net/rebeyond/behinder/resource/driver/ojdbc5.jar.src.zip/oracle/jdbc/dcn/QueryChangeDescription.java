/*    */ package oracle.jdbc.dcn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface QueryChangeDescription
/*    */ {
/*    */   public abstract long getQueryId();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract QueryChangeEventType getQueryChangeEventType();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract TableChangeDescription[] getTableChangeDescription();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static enum QueryChangeEventType
/*    */   {
/* 56 */     DEREG(DatabaseChangeEvent.EventType.DEREG.getCode()), 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 61 */     QUERYCHANGE(DatabaseChangeEvent.EventType.QUERYCHANGE.getCode());
/*    */     
/*    */     private final int code;
/*    */     
/* 65 */     private QueryChangeEventType(int paramInt) { this.code = paramInt; }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     public final int getCode()
/*    */     {
/* 73 */       return this.code;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */     public static final QueryChangeEventType getQueryChangeEventType(int paramInt)
/*    */     {
/* 80 */       if (paramInt == DEREG.getCode()) {
/* 81 */         return DEREG;
/*    */       }
/* 83 */       return QUERYCHANGE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/dcn/QueryChangeDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */