/*    */ package oracle.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LargeObjectAccessMode
/*    */ {
/* 21 */   MODE_READONLY(0), 
/* 22 */   MODE_READWRITE(1);
/*    */   
/*    */ 
/* 25 */   private LargeObjectAccessMode(int paramInt) { this.code = paramInt; }
/*    */   
/*    */   private final int code;
/* 28 */   public int getCode() { return this.code; }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/LargeObjectAccessMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */