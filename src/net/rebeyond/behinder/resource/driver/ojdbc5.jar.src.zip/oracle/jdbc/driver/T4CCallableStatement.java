/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CCallableStatement
/*      */   extends OracleCallableStatement
/*      */ {
/*      */   T4CCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*   29 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/*   31 */     this.t4Connection = ((T4CConnection)paramPhysicalConnection);
/*   32 */     this.nbPostPonedColumns = new int[1];
/*   33 */     this.nbPostPonedColumns[0] = 0;
/*   34 */     this.indexOfPostPonedColumn = new int[1][3];
/*      */     
/*   36 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   37 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   38 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   39 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   45 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CConnection t4Connection;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
/*      */     throws SQLException, IOException
/*      */   {
/*   65 */     if ((paramBoolean1) || (paramBoolean4) || (!paramBoolean2)) {
/*   66 */       this.oacdefSent = null;
/*      */     }
/*   68 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.doOall8");
/*      */     
/*   70 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED)
/*      */     {
/*      */ 
/*      */ 
/*   74 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   75 */       localSQLException1.fillInStackTrace();
/*   76 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*   80 */     if (paramBoolean3) {
/*   81 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   83 */     int i = this.numberOfDefinePositions;
/*      */     
/*   85 */     if (this.sqlKind.isDML()) {
/*   86 */       i = 0;
/*      */     }
/*      */     int j;
/*   89 */     if (this.accessors != null)
/*   90 */       for (j = 0; j < this.accessors.length; j++)
/*   91 */         if (this.accessors[j] != null)
/*   92 */           this.accessors[j].lastRowProcessed = 0;
/*   93 */     if (this.outBindAccessors != null)
/*   94 */       for (j = 0; j < this.outBindAccessors.length; j++)
/*   95 */         if (this.outBindAccessors[j] != null)
/*   96 */           this.outBindAccessors[j].lastRowProcessed = 0;
/*   97 */     if (this.returnParamAccessors != null) {
/*   98 */       for (j = 0; j < this.returnParamAccessors.length; j++) {
/*   99 */         if (this.returnParamAccessors[j] != null) {
/*  100 */           this.returnParamAccessors[j].lastRowProcessed = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     int i1;
/*      */     int i2;
/*  107 */     if (this.bindIndicators != null)
/*      */     {
/*  109 */       j = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */       
/*      */ 
/*  112 */       int k = 0;
/*      */       
/*  114 */       if (this.ibtBindChars != null) {
/*  115 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  117 */       for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */       {
/*  119 */         int n = this.bindIndicatorSubRange + 5 + 10 * m;
/*      */         
/*      */ 
/*      */ 
/*  123 */         i1 = this.bindIndicators[(n + 2)] & 0xFFFF;
/*      */         
/*      */ 
/*      */ 
/*  127 */         if (i1 != 0)
/*      */         {
/*      */ 
/*  130 */           i2 = this.bindIndicators[(n + 9)] & 0xFFFF;
/*      */           
/*      */ 
/*      */ 
/*  134 */           if (i2 == 2)
/*      */           {
/*  136 */             k = Math.max(i1 * this.connection.conversion.maxNCharSize, k);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  141 */             k = Math.max(i1 * this.connection.conversion.cMaxCharSize, k);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  147 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  149 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  151 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  153 */         this.tmpBindsByteArray = null;
/*  154 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  166 */       this.tmpBindsByteArray = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  171 */     int[] arrayOfInt1 = this.definedColumnType;
/*  172 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  173 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */     if ((paramBoolean5) && (paramBoolean4) && (this.sqlObject.includeRowid))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  184 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  185 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  186 */       arrayOfInt1[0] = -8;
/*  187 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  188 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  189 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  190 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  196 */     allocateTmpByteArray();
/*      */     
/*  198 */     T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */     
/*  200 */     this.t4Connection.sendPiggyBackedMessages();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  205 */       localT4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  217 */       i1 = localT4C8Oall.getCursorId();
/*  218 */       if (i1 != 0) {
/*  219 */         this.cursorId = i1;
/*      */       }
/*  221 */       this.oacdefSent = localT4C8Oall.oacdefBindsSent;
/*      */     }
/*      */     catch (SQLException localSQLException2)
/*      */     {
/*  225 */       i2 = localT4C8Oall.getCursorId();
/*  226 */       if (i2 != 0) {
/*  227 */         this.cursorId = i2;
/*      */       }
/*  229 */       if (localSQLException2.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/*  232 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  237 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray()
/*      */   {
/*  247 */     if (this.tmpByteArray == null)
/*      */     {
/*      */ 
/*  250 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  252 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length)
/*      */     {
/*      */ 
/*      */ 
/*  256 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/*  268 */     super.releaseBuffers();
/*  269 */     this.tmpByteArray = null;
/*  270 */     this.tmpBindsByteArray = null;
/*      */     
/*  272 */     this.t4Connection.all8.bindChars = null;
/*  273 */     this.t4Connection.all8.bindBytes = null;
/*  274 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */   
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/*  281 */     this.accessors[0] = new T4CRowidAccessor(this, 128, 1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {
/*  294 */     this.needToParse = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/*  305 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*  316 */     if (paramInt1 < 1)
/*      */     {
/*  318 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  319 */       localSQLException.fillInStackTrace();
/*  320 */       throw localSQLException;
/*      */     }
/*  322 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*  326 */       if ((paramInt2 == 1) || (paramInt2 == 12))
/*      */       {
/*      */ 
/*      */ 
/*  330 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*  336 */     else if (paramInt3 < 0)
/*      */     {
/*  338 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  339 */       localSQLException.fillInStackTrace();
/*  340 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  344 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed))
/*      */     {
/*  346 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  347 */       localSQLException.fillInStackTrace();
/*  348 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  355 */     int i = paramInt1 - 1;
/*      */     int[] arrayOfInt;
/*  357 */     if ((this.definedColumnType == null) || (this.definedColumnType.length <= i))
/*      */     {
/*  359 */       if (this.definedColumnType == null)
/*      */       {
/*  361 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  373 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  375 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */         
/*      */ 
/*  378 */         this.definedColumnType = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  384 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  386 */     if ((this.definedColumnSize == null) || (this.definedColumnSize.length <= i))
/*      */     {
/*  388 */       if (this.definedColumnSize == null) {
/*  389 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  392 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  394 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */         
/*      */ 
/*  397 */         this.definedColumnSize = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  401 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  403 */     if ((this.definedColumnFormOfUse == null) || (this.definedColumnFormOfUse.length <= i))
/*      */     {
/*  405 */       if (this.definedColumnFormOfUse == null) {
/*  406 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  409 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  411 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */         
/*      */ 
/*  414 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  418 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  420 */     if ((this.accessors != null) && (i < this.accessors.length) && (this.accessors[i] != null))
/*      */     {
/*  422 */       this.accessors[i].definedColumnSize = paramInt3;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  427 */       if (((this.accessors[i].internalType == 96) || (this.accessors[i].internalType == 1)) && ((paramInt2 == 1) || (paramInt2 == 12)))
/*      */       {
/*      */ 
/*      */ 
/*  431 */         if (paramInt3 <= this.accessors[i].oacmxl)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  437 */           this.needToPrepareDefineBuffer = true;
/*  438 */           this.columnsDefinedByUser = true;
/*      */           
/*  440 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  441 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearDefines()
/*      */     throws SQLException
/*      */   {
/*  450 */     synchronized (this.connection)
/*      */     {
/*  452 */       super.clearDefines();
/*  453 */       this.definedColumnType = null;
/*  454 */       this.definedColumnSize = null;
/*  455 */       this.definedColumnFormOfUse = null;
/*  456 */       this.t4Connection.all8.definesAccessors = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  474 */     int i = this.rowPrefetchInLastFetch < this.rowPrefetch ? 1 : 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  503 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  512 */       paramArrayOfShort = new short[this.defineIndicators.length];
/*  513 */       j = this.accessors[0].lengthIndexLastRow;
/*  514 */       int k = this.accessors[0].indicatorIndexLastRow;
/*      */       
/*  516 */       int i1 = i != 0 ? this.accessors.length : 1;
/*  517 */       for (; i != 0 ? i1 >= 1 : i1 <= this.accessors.length; 
/*  518 */           i1 += (i != 0 ? -1 : 1))
/*      */       {
/*  520 */         int m = j + this.rowPrefetchInLastFetch * i1 - 1;
/*  521 */         int n = k + this.rowPrefetchInLastFetch * i1 - 1;
/*  522 */         paramArrayOfShort[n] = this.defineIndicators[n];
/*  523 */         paramArrayOfShort[m] = this.defineIndicators[m];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  530 */     int j = i != 0 ? this.accessors.length - 1 : 0;
/*  531 */     for (; i != 0 ? j > -1 : j < this.accessors.length; 
/*  532 */         j += (i != 0 ? -1 : 1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  539 */       this.accessors[j].saveDataFromOldDefineBuffers(paramArrayOfByte, paramArrayOfChar, paramArrayOfShort, this.rowPrefetchInLastFetch != -1 ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  546 */     super.saveDefineBuffersIfRequired(paramArrayOfChar, paramArrayOfByte, paramArrayOfShort, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doSetSnapshotSCN(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  556 */     this.inScn = paramLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  576 */     Object localObject = null;
/*      */     SQLException localSQLException;
/*  578 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/*  582 */       localObject = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  585 */       break;
/*      */     
/*      */     case 8: 
/*  588 */       if (!paramBoolean)
/*      */       {
/*  590 */         localObject = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  593 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/*  598 */       localObject = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  601 */       break;
/*      */     
/*      */     case 2: 
/*  604 */       localObject = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  607 */       break;
/*      */     
/*      */     case 6: 
/*  610 */       localObject = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  613 */       break;
/*      */     
/*      */     case 24: 
/*  616 */       if (!paramBoolean)
/*      */       {
/*  618 */         localObject = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  621 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/*  626 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/*  628 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  629 */         localSQLException.fillInStackTrace();
/*  630 */         throw localSQLException;
/*      */       }
/*      */       
/*  633 */       if (paramBoolean) {
/*  634 */         localObject = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       else {
/*  637 */         localObject = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*  640 */       break;
/*      */     
/*      */     case 100: 
/*  643 */       localObject = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  646 */       break;
/*      */     
/*      */     case 101: 
/*  649 */       localObject = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  652 */       break;
/*      */     
/*      */     case 104: 
/*  655 */       if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  661 */         localObject = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         
/*      */ 
/*      */ 
/*  665 */         ((Accessor)localObject).definedColumnType = -8;
/*      */       }
/*      */       else {
/*  668 */         localObject = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*      */ 
/*  672 */       break;
/*      */     
/*      */     case 102: 
/*  675 */       localObject = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  678 */       break;
/*      */     
/*      */     case 12: 
/*  681 */       localObject = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  684 */       break;
/*      */     
/*      */     case 113: 
/*  687 */       localObject = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  690 */       break;
/*      */     
/*      */     case 112: 
/*  693 */       localObject = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  696 */       break;
/*      */     
/*      */     case 114: 
/*  699 */       localObject = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  702 */       break;
/*      */     
/*      */     case 109: 
/*  705 */       localObject = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  708 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  710 */       break;
/*      */     
/*      */     case 111: 
/*  713 */       localObject = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  716 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  718 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 180: 
/*  723 */       localObject = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  726 */       break;
/*      */     
/*      */     case 181: 
/*  729 */       localObject = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  732 */       break;
/*      */     
/*      */     case 231: 
/*  735 */       localObject = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  738 */       break;
/*      */     
/*      */     case 182: 
/*  741 */       localObject = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  744 */       break;
/*      */     
/*      */     case 183: 
/*  747 */       localObject = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  750 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/*  763 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  764 */       localSQLException.fillInStackTrace();
/*  765 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*  769 */     return (Accessor)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doDescribe(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  796 */     if (!this.isOpen)
/*      */     {
/*      */ 
/*  799 */       this.connection.open(this);
/*  800 */       this.isOpen = true;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  806 */       this.t4Connection.needLine();
/*  807 */       this.t4Connection.sendPiggyBackedMessages();
/*  808 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  809 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  811 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  813 */       for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  814 */         this.accessors[i].initMetadata();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {
/*  818 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*      */ 
/*  821 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  822 */       localSQLException.fillInStackTrace();
/*  823 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  827 */     this.describedWithNames = true;
/*  828 */     this.described = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForDescribe()
/*      */     throws SQLException
/*      */   {
/*  863 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.execute_for_describe");
/*      */     try
/*      */     {
/*  866 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  872 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  876 */         doOall8(true, true, false, true, this.definedColumnType != null);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/*  882 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  886 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*  888 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  889 */       localSQLException2.fillInStackTrace();
/*  890 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  895 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  896 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     
/*  899 */     this.needToParse = false;
/*      */     
/*      */ 
/*  902 */     if (this.connection.calculateChecksum) {
/*  903 */       if (this.validRows > 0) {
/*  904 */         calculateCheckSum();
/*  905 */       } else if (this.rowsProcessed > 0) {
/*  906 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  908 */         this.checkSum = l;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  918 */     if (this.definedColumnType == null) {
/*  919 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  921 */     this.aFetchWasDoneDuringDescribe = false;
/*  922 */     if (this.t4Connection.all8.aFetchWasDone)
/*      */     {
/*  924 */       this.aFetchWasDoneDuringDescribe = true;
/*  925 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*      */     
/*      */ 
/*  929 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  930 */       this.accessors[i].initMetadata();
/*      */     }
/*  932 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForRows(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  974 */         boolean bool = false;
/*  975 */         if (this.columnsDefinedByUser) {
/*  976 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  996 */         else if ((this.t4Connection.useLobPrefetch) && (this.accessors != null) && (this.defaultLobPrefetchSize != -1) && (!this.implicitDefineForLobPrefetchDone) && (!this.aFetchWasDoneDuringDescribe) && (this.definedColumnType == null))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1004 */           int i = 0;
/* 1005 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1006 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1008 */           for (int j = 0; j < this.accessors.length; j++)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1013 */             arrayOfInt1[j] = getJDBCType(this.accessors[j].internalType);
/* 1014 */             if ((this.accessors[j].internalType == 113) || (this.accessors[j].internalType == 112) || (this.accessors[j].internalType == 114))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1020 */               i = 1;
/* 1021 */               this.accessors[j].lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1022 */               arrayOfInt2[j] = this.defaultLobPrefetchSize;
/*      */             }
/*      */           }
/*      */           
/* 1026 */           if (i != 0)
/*      */           {
/* 1028 */             this.definedColumnType = arrayOfInt1;
/* 1029 */             this.definedColumnSize = arrayOfInt2;
/* 1030 */             bool = true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1036 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1038 */         this.needToParse = false;
/* 1039 */         if (bool) {
/* 1040 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       }
/*      */       finally {
/* 1044 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1049 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1053 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/* 1054 */       calculateCheckSum();
/*      */       
/* 1056 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1057 */       localSQLException2.fillInStackTrace();
/* 1058 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetch()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1085 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1089 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1093 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException1)
/*      */         {
/* 1097 */           ((T4CConnection)this.connection).handleIOException(localIOException1);
/*      */           
/* 1099 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/* 1100 */           localSQLException.fillInStackTrace();
/* 1101 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1105 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1111 */       doOall8(false, false, true, false, false);
/*      */       
/* 1113 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/* 1117 */       ((T4CConnection)this.connection).handleIOException(localIOException2);
/*      */       
/* 1119 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/* 1120 */       localSQLException.fillInStackTrace();
/* 1121 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1127 */     calculateCheckSum();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1142 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1144 */         T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */         
/* 1146 */         localT4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1151 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1153 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1154 */       localSQLException2.fillInStackTrace();
/* 1155 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1160 */       if (localSQLException1.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/* 1163 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1168 */         throw localSQLException1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doClose()
/*      */     throws SQLException
/*      */   {
/* 1192 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.do_close");
/*      */     
/* 1194 */     if (this.cursorId != 0) {
/* 1195 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1198 */     this.tmpByteArray = null;
/* 1199 */     this.tmpBindsByteArray = null;
/* 1200 */     this.definedColumnType = null;
/* 1201 */     this.definedColumnSize = null;
/* 1202 */     this.definedColumnFormOfUse = null;
/* 1203 */     this.oacdefSent = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeQuery()
/*      */     throws SQLException
/*      */   {
/* 1223 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.closeQuery");
/*      */     
/* 1225 */     if (this.streamList != null)
/*      */     {
/* 1227 */       while (this.nextStream != null) {
/*      */         try {
/* 1229 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException) {
/* 1232 */           ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */           
/* 1234 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1235 */           localSQLException.fillInStackTrace();
/* 1236 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1240 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Binder getRowidNullBinder(int paramInt)
/*      */   {
/* 1253 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */     {
/*      */ 
/* 1256 */       this.currentRowCharLens[paramInt] = 1;
/* 1257 */       return this.theVarcharNullBinder;
/*      */     }
/*      */     
/* 1260 */     return this.theRowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1274 */     return new T4CPlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean, this.t4Connection.mare);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1284 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/T4CCallableStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */