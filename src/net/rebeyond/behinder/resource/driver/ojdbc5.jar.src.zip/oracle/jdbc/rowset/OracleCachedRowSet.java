/*      */ package oracle.jdbc.rowset;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PipedInputStream;
/*      */ import java.io.PipedOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringBufferInputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ import java.util.Vector;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import javax.sql.RowSet;
/*      */ import javax.sql.RowSetEvent;
/*      */ import javax.sql.RowSetInternal;
/*      */ import javax.sql.RowSetMetaData;
/*      */ import javax.sql.RowSetReader;
/*      */ import javax.sql.RowSetWriter;
/*      */ import javax.sql.rowset.CachedRowSet;
/*      */ import javax.sql.rowset.RowSetWarning;
/*      */ import javax.sql.rowset.spi.SyncFactory;
/*      */ import javax.sql.rowset.spi.SyncFactoryException;
/*      */ import javax.sql.rowset.spi.SyncProvider;
/*      */ import javax.sql.rowset.spi.SyncProviderException;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.OracleSavepoint;
/*      */ import oracle.jdbc.driver.DBConversion;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.driver.OracleDriver;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleCachedRowSet
/*      */   extends OracleRowSet
/*      */   implements RowSet, RowSetInternal, Serializable, Cloneable, CachedRowSet
/*      */ {
/*      */   static final long serialVersionUID = -2066958142885801470L;
/*      */   private SQLWarning sqlWarning;
/*      */   private RowSetWarning rowsetWarning;
/*      */   protected int presentRow;
/*      */   private int currentPage;
/*      */   private boolean isPopulateDone;
/*      */   private boolean previousColumnWasNull;
/*      */   private OracleRow insertRow;
/*      */   private int insertRowPosition;
/*      */   private boolean insertRowFlag;
/*      */   private int updateRowPosition;
/*      */   private boolean updateRowFlag;
/*      */   protected ResultSetMetaData rowsetMetaData;
/*      */   private transient ResultSet resultSet;
/*      */   private transient Connection connection;
/*  312 */   private transient boolean isConnectionStayingOpenForTxnControl = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  317 */   private transient OracleSqlForRowSet osql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Vector rows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Vector param;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] metaData;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int colCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int rowCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private RowSetReader reader;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private RowSetWriter writer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] keyColumns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int pageSize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SyncProvider syncProvider;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String DEFAULT_SYNCPROVIDER = "com.sun.rowset.providers.RIOptimisticProvider";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String tableName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  401 */   private boolean executeCalled = false;
/*      */   
/*  403 */   private boolean driverManagerInitialized = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAX_CHAR_BUFFER_SIZE = 1024;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAX_BYTE_BUFFER_SIZE = 1024;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleCachedRowSet()
/*      */     throws SQLException
/*      */   {
/*  427 */     this.insertRowFlag = false;
/*  428 */     this.updateRowFlag = false;
/*      */     
/*  430 */     this.presentRow = 0;
/*  431 */     this.previousColumnWasNull = false;
/*      */     
/*  433 */     this.param = new Vector();
/*      */     
/*  435 */     this.rows = new Vector();
/*      */     
/*  437 */     this.sqlWarning = new SQLWarning();
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  443 */       this.syncProvider = SyncFactory.getInstance("com.sun.rowset.providers.RIOptimisticProvider");
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (SyncFactoryException localSyncFactoryException)
/*      */     {
/*      */ 
/*      */ 
/*  451 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 304);
/*  452 */       localSQLException.fillInStackTrace();
/*  453 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  458 */     setReader(new OracleCachedRowSetReader());
/*  459 */     setWriter(new OracleCachedRowSetWriter());
/*      */     
/*  461 */     this.currentPage = 0;
/*  462 */     this.pageSize = 0;
/*  463 */     this.isPopulateDone = false;
/*      */     
/*  465 */     this.keyColumns = null;
/*  466 */     this.tableName = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/*  481 */     return getConnectionInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   Connection getConnectionInternal()
/*      */     throws SQLException
/*      */   {
/*  490 */     if ((this.connection == null) || (this.connection.isClosed()))
/*      */     {
/*  492 */       String str1 = getUsername();
/*  493 */       String str2 = getPassword();
/*  494 */       Object localObject2; if (getDataSourceName() != null)
/*      */       {
/*      */         try
/*      */         {
/*  498 */           InitialContext localInitialContext = null;
/*      */           
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/*  504 */             Properties localProperties = System.getProperties();
/*  505 */             localInitialContext = new InitialContext(localProperties);
/*      */           }
/*      */           catch (SecurityException localSecurityException) {}
/*      */           
/*      */ 
/*  510 */           if (localInitialContext == null)
/*  511 */             localInitialContext = new InitialContext();
/*  512 */           localObject2 = (DataSource)localInitialContext.lookup(getDataSourceName());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  517 */           if ((this.username == null) || (str2 == null)) {
/*  518 */             this.connection = ((DataSource)localObject2).getConnection();
/*      */           } else {
/*  520 */             this.connection = ((DataSource)localObject2).getConnection(this.username, str2);
/*      */           }
/*      */         }
/*      */         catch (NamingException localNamingException)
/*      */         {
/*  525 */           localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 300, localNamingException.getMessage());
/*  526 */           ((SQLException)localObject2).fillInStackTrace();
/*  527 */           throw ((Throwable)localObject2);
/*      */         }
/*      */       } else {
/*      */         Object localObject1;
/*  531 */         if (getUrl() != null)
/*      */         {
/*  533 */           if (!this.driverManagerInitialized)
/*      */           {
/*  535 */             DriverManager.registerDriver(new OracleDriver());
/*  536 */             this.driverManagerInitialized = true;
/*      */           }
/*  538 */           localObject1 = getUrl();
/*      */           
/*      */ 
/*      */ 
/*  542 */           if ((((String)localObject1).equals("")) || (str1.equals("")) || (str2.equals("")))
/*      */           {
/*      */ 
/*  545 */             localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
/*  546 */             ((SQLException)localObject2).fillInStackTrace();
/*  547 */             throw ((Throwable)localObject2);
/*      */           }
/*      */           
/*  550 */           this.connection = DriverManager.getConnection((String)localObject1, str1, str2);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  555 */           localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
/*  556 */           ((SQLException)localObject1).fillInStackTrace();
/*  557 */           throw ((Throwable)localObject1);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  562 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Statement getStatement()
/*      */     throws SQLException
/*      */   {
/*  573 */     if (this.resultSet == null)
/*      */     {
/*      */ 
/*      */ 
/*  577 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 305);
/*  578 */       localSQLException.fillInStackTrace();
/*  579 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  583 */     return this.resultSet.getStatement();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowSetReader getReader()
/*      */   {
/*  591 */     return this.reader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowSetWriter getWriter()
/*      */   {
/*  599 */     return this.writer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  632 */     if (this.rowsetType == 1005)
/*      */     {
/*  634 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 306);
/*  635 */       localSQLException.fillInStackTrace();
/*  636 */       throw localSQLException;
/*      */     }
/*      */     
/*  639 */     switch (paramInt)
/*      */     {
/*      */     case 1000: 
/*      */     case 1002: 
/*  643 */       this.presentRow = 0;
/*  644 */       break;
/*      */     case 1001: 
/*  646 */       if (this.rowsetType == 1003)
/*      */       {
/*  648 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 307);
/*  649 */         localSQLException.fillInStackTrace();
/*  650 */         throw localSQLException;
/*      */       }
/*  652 */       this.presentRow = (this.rowCount + 1);
/*  653 */       break;
/*      */     
/*      */     default: 
/*  656 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 308);
/*  657 */       localSQLException.fillInStackTrace();
/*  658 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  663 */     super.setFetchDirection(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCommand(String paramString)
/*      */     throws SQLException
/*      */   {
/*  673 */     super.setCommand(paramString);
/*  674 */     if ((paramString == null) || (paramString.equals(""))) {
/*  675 */       this.osql = null;
/*      */     } else {
/*  677 */       this.osql = new OracleSqlForRowSet(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReader(RowSetReader paramRowSetReader)
/*      */   {
/*  686 */     this.reader = paramRowSetReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWriter(RowSetWriter paramRowSetWriter)
/*      */   {
/*  695 */     this.writer = paramRowSetWriter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int getColumnIndex(String paramString)
/*      */     throws SQLException
/*      */   {
/*  718 */     if ((paramString == null) || (paramString.equals("")))
/*      */     {
/*  720 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, paramString);
/*  721 */       localSQLException1.fillInStackTrace();
/*  722 */       throw localSQLException1;
/*      */     }
/*      */     
/*  725 */     paramString = paramString.toUpperCase();
/*  726 */     for (int i = 0; 
/*  727 */         i < this.metaData.length; i++)
/*      */     {
/*  729 */       if (paramString.equals(this.metaData[i])) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  735 */     if (i >= this.metaData.length)
/*      */     {
/*  737 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, paramString);
/*  738 */       localSQLException2.fillInStackTrace();
/*  739 */       throw localSQLException2;
/*      */     }
/*      */     
/*  742 */     return i + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void checkColumnIndex(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  757 */     if (this.readOnly)
/*      */     {
/*  759 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/*  760 */       localSQLException.fillInStackTrace();
/*  761 */       throw localSQLException;
/*      */     }
/*  763 */     if ((paramInt < 1) || (paramInt > this.colCount))
/*      */     {
/*  765 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
/*  766 */       localSQLException.fillInStackTrace();
/*  767 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean isUpdated(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  786 */     if ((paramInt < 1) || (paramInt > this.colCount))
/*      */     {
/*  788 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
/*  789 */       localSQLException.fillInStackTrace();
/*  790 */       throw localSQLException;
/*      */     }
/*      */     
/*  793 */     return getCurrentRow().isColumnChanged(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void checkParamIndex(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  807 */     if (paramInt < 1)
/*      */     {
/*  809 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 310, "" + paramInt);
/*  810 */       localSQLException.fillInStackTrace();
/*  811 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void populateInit(ResultSet paramResultSet)
/*      */     throws SQLException
/*      */   {
/*  828 */     this.resultSet = paramResultSet;
/*  829 */     Statement localStatement = paramResultSet.getStatement();
/*      */     
/*      */ 
/*      */ 
/*  833 */     this.maxFieldSize = localStatement.getMaxFieldSize();
/*      */     
/*      */ 
/*  836 */     this.fetchSize = localStatement.getFetchSize();
/*  837 */     this.queryTimeout = localStatement.getQueryTimeout();
/*      */     
/*  839 */     this.connection = localStatement.getConnection();
/*      */     
/*      */ 
/*      */ 
/*  843 */     this.transactionIsolation = this.connection.getTransactionIsolation();
/*      */     
/*      */ 
/*      */ 
/*  847 */     this.typeMap = this.connection.getTypeMap();
/*  848 */     DatabaseMetaData localDatabaseMetaData = this.connection.getMetaData();
/*      */     
/*      */ 
/*      */ 
/*  852 */     this.url = localDatabaseMetaData.getURL();
/*  853 */     this.username = localDatabaseMetaData.getUserName();
/*      */     
/*      */ 
/*      */ 
/*  857 */     this.presentRow = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized InputStream getStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  874 */     Object localObject1 = getObject(paramInt);
/*      */     
/*      */ 
/*      */ 
/*  878 */     if (localObject1 == null) {
/*  879 */       return null;
/*      */     }
/*  881 */     if ((localObject1 instanceof InputStream)) {
/*  882 */       return (InputStream)localObject1;
/*      */     }
/*  884 */     if ((localObject1 instanceof String))
/*      */     {
/*  886 */       return new ByteArrayInputStream(((String)localObject1).getBytes());
/*      */     }
/*  888 */     if ((localObject1 instanceof byte[]))
/*      */     {
/*  890 */       return new ByteArrayInputStream((byte[])localObject1);
/*      */     }
/*  892 */     if ((localObject1 instanceof OracleSerialClob))
/*  893 */       return ((OracleSerialClob)localObject1).getAsciiStream();
/*  894 */     if ((localObject1 instanceof OracleSerialBlob))
/*  895 */       return ((OracleSerialBlob)localObject1).getBinaryStream();
/*  896 */     if ((localObject1 instanceof Reader))
/*      */     {
/*  898 */       localObject2 = null;
/*  899 */       PipedOutputStream localPipedOutputStream = null;
/*      */       try
/*      */       {
/*  902 */         localObject2 = new BufferedReader((Reader)localObject1);
/*  903 */         int i = 0;
/*  904 */         localObject3 = new PipedInputStream();
/*  905 */         localPipedOutputStream = new PipedOutputStream((PipedInputStream)localObject3);
/*  906 */         while ((i = ((Reader)localObject2).read()) != -1)
/*  907 */           localPipedOutputStream.write(i);
/*  908 */         return (InputStream)localObject3;
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException1)
/*      */       {
/*  913 */         Object localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 311, localIOException1.getMessage());
/*  914 */         ((SQLException)localObject3).fillInStackTrace();
/*  915 */         throw ((Throwable)localObject3);
/*      */       }
/*      */       finally {
/*      */         SQLException localSQLException;
/*      */         try {
/*  920 */           if (localObject2 != null) {
/*  921 */             ((Reader)localObject2).close();
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException2) {
/*  925 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 311, localIOException2.getMessage());
/*  926 */           localSQLException.fillInStackTrace();
/*  927 */           throw localSQLException;
/*      */         }
/*      */         try
/*      */         {
/*  931 */           if (localPipedOutputStream != null) {
/*  932 */             localPipedOutputStream.close();
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException3) {
/*  936 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 311, localIOException3.getMessage());
/*  937 */           localSQLException.fillInStackTrace();
/*  938 */           throw localSQLException;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  945 */     Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 312);
/*  946 */     ((SQLException)localObject2).fillInStackTrace();
/*  947 */     throw ((Throwable)localObject2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final Calendar getSessionCalendar(Connection paramConnection)
/*      */   {
/*  954 */     String str = ((OracleConnection)paramConnection).getSessionTimeZone();
/*      */     
/*      */     Calendar localCalendar;
/*  957 */     if (str == null) {
/*  958 */       localCalendar = Calendar.getInstance();
/*      */     }
/*      */     else {
/*  961 */       TimeZone localTimeZone = TimeZone.getDefault();
/*  962 */       localTimeZone.setID(str);
/*  963 */       localCalendar = Calendar.getInstance(localTimeZone);
/*      */     }
/*      */     
/*  966 */     return localCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isStreamType(int paramInt)
/*      */   {
/*  972 */     return (paramInt == 2004) || (paramInt == 2005) || (paramInt == -4) || (paramInt == -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void notifyCursorMoved()
/*      */   {
/* 1002 */     if (this.insertRowFlag)
/*      */     {
/* 1004 */       this.insertRowFlag = false;
/* 1005 */       this.insertRow.setRowUpdated(false);
/* 1006 */       this.sqlWarning.setNextWarning(new SQLWarning("Cancelling insertion, due to cursor movement."));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/* 1014 */     else if (this.updateRowFlag)
/*      */     {
/*      */       try
/*      */       {
/* 1018 */         this.updateRowFlag = false;
/* 1019 */         int i = this.presentRow;
/* 1020 */         this.presentRow = this.updateRowPosition;
/* 1021 */         getCurrentRow().setRowUpdated(false);
/* 1022 */         this.presentRow = i;
/* 1023 */         this.sqlWarning.setNextWarning(new SQLWarning("Cancelling all updates, due to cursor movement."));
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1033 */     super.notifyCursorMoved();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkAndFilterObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleRow getCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 1063 */     int i = this.presentRow - 1;
/*      */     
/*      */ 
/*      */ 
/* 1067 */     if ((this.presentRow < 1) || (this.presentRow > this.rowCount))
/*      */     {
/* 1069 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 313);
/* 1070 */       localSQLException.fillInStackTrace();
/* 1071 */       throw localSQLException;
/*      */     }
/*      */     
/* 1074 */     return (OracleRow)this.rows.elementAt(this.presentRow - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isExecuteCalled()
/*      */   {
/* 1084 */     return this.executeCalled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getCurrentPage()
/*      */   {
/* 1093 */     return this.currentPage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isConnectionStayingOpen()
/*      */   {
/* 1102 */     return this.isConnectionStayingOpenForTxnControl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setOriginal()
/*      */     throws SQLException
/*      */   {
/* 1114 */     int i = 1;
/*      */     
/*      */     do
/*      */     {
/* 1118 */       boolean bool = setOriginalRowInternal(i);
/*      */       
/* 1120 */       if (!bool)
/*      */       {
/* 1122 */         i++;
/*      */       }
/*      */       
/* 1125 */     } while (i <= this.rowCount);
/*      */     
/* 1127 */     notifyRowSetChanged();
/*      */     
/*      */ 
/*      */ 
/* 1131 */     this.presentRow = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean setOriginalRowInternal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1144 */     if ((paramInt < 1) || (paramInt > this.rowCount))
/*      */     {
/* 1146 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 313);
/* 1147 */       localSQLException.fillInStackTrace();
/* 1148 */       throw localSQLException;
/*      */     }
/*      */     
/* 1151 */     boolean bool = false;
/*      */     
/* 1153 */     OracleRow localOracleRow = (OracleRow)this.rows.elementAt(paramInt - 1);
/*      */     
/* 1155 */     if (localOracleRow.isRowDeleted())
/*      */     {
/* 1157 */       this.rows.remove(paramInt - 1);
/* 1158 */       this.rowCount -= 1;
/* 1159 */       bool = true;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1164 */       if (localOracleRow.isRowInserted())
/*      */       {
/* 1166 */         localOracleRow.setInsertedFlag(false);
/*      */       }
/*      */       
/* 1169 */       if (localOracleRow.isRowUpdated())
/*      */       {
/* 1171 */         localOracleRow.makeUpdatesOriginal();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1178 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/* 1220 */     if (this.rowCount < 0)
/*      */     {
/* 1222 */       return false;
/*      */     }
/*      */     
/* 1225 */     if ((this.fetchDirection == 1000) || (this.fetchDirection == 1002))
/*      */     {
/* 1227 */       if (this.presentRow + 1 <= this.rowCount)
/*      */       {
/* 1229 */         this.presentRow += 1;
/* 1230 */         if ((!this.showDeleted) && (getCurrentRow().isRowDeleted())) {
/* 1231 */           return next();
/*      */         }
/* 1233 */         notifyCursorMoved();
/* 1234 */         return true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1241 */       this.presentRow = (this.rowCount + 1);
/* 1242 */       return false;
/*      */     }
/*      */     
/* 1245 */     if (this.fetchDirection == 1001)
/*      */     {
/* 1247 */       if (this.presentRow - 1 > 0)
/*      */       {
/* 1249 */         this.presentRow -= 1;
/* 1250 */         if ((!this.showDeleted) && (getCurrentRow().isRowDeleted())) {
/* 1251 */           return next();
/*      */         }
/* 1253 */         notifyCursorMoved();
/* 1254 */         return true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1261 */       this.presentRow = 0;
/* 1262 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1268 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/* 1283 */     if (this.rowCount < 0)
/*      */     {
/* 1285 */       return false;
/*      */     }
/*      */     
/* 1288 */     if (this.fetchDirection == 1001)
/*      */     {
/* 1290 */       if (this.presentRow + 1 <= this.rowCount)
/*      */       {
/* 1292 */         this.presentRow += 1;
/* 1293 */         if ((!this.showDeleted) && (getCurrentRow().isRowDeleted())) {
/* 1294 */           return previous();
/*      */         }
/* 1296 */         notifyCursorMoved();
/* 1297 */         return true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1304 */       this.presentRow = (this.rowCount + 1);
/* 1305 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1309 */     if ((this.fetchDirection == 1000) || (this.fetchDirection == 1002))
/*      */     {
/* 1311 */       if (this.presentRow - 1 > 0)
/*      */       {
/* 1313 */         this.presentRow -= 1;
/* 1314 */         if ((!this.showDeleted) && (getCurrentRow().isRowDeleted())) {
/* 1315 */           return previous();
/*      */         }
/* 1317 */         notifyCursorMoved();
/* 1318 */         return true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1325 */       this.presentRow = 0;
/* 1326 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1332 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/* 1344 */     return (this.rowCount > 0) && (this.presentRow == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/* 1355 */     return (this.rowCount > 0) && (this.presentRow == this.rowCount + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/* 1364 */     return this.presentRow == 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/* 1375 */     return this.presentRow == this.rowCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/* 1383 */     this.presentRow = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void afterLast()
/*      */     throws SQLException
/*      */   {
/* 1392 */     this.presentRow = (this.rowCount + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean first()
/*      */     throws SQLException
/*      */   {
/* 1403 */     return absolute(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/* 1412 */     return absolute(-1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean absolute(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1429 */     if (this.rowsetType == 1003)
/*      */     {
/* 1431 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 314);
/* 1432 */       localSQLException.fillInStackTrace();
/* 1433 */       throw localSQLException;
/*      */     }
/* 1435 */     if ((paramInt == 0) || (Math.abs(paramInt) > this.rowCount))
/* 1436 */       return false;
/* 1437 */     this.presentRow = (paramInt < 0 ? this.rowCount + paramInt + 1 : paramInt);
/* 1438 */     notifyCursorMoved();
/*      */     
/* 1440 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean relative(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1453 */     return absolute(this.presentRow + paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void populate(ResultSet paramResultSet)
/*      */     throws SQLException
/*      */   {
/* 1490 */     if (this.rows == null)
/*      */     {
/*      */ 
/* 1493 */       this.rows = new Vector(50, 10);
/*      */     }
/*      */     else
/* 1496 */       this.rows.clear();
/* 1497 */     this.rowsetMetaData = new OracleRowSetMetaData(paramResultSet.getMetaData());
/* 1498 */     this.metaData = new String[this.colCount = this.rowsetMetaData.getColumnCount()];
/* 1499 */     for (int i = 0; i < this.colCount; i++) {
/* 1500 */       this.metaData[i] = this.rowsetMetaData.getColumnName(i + 1);
/*      */     }
/*      */     
/*      */ 
/* 1504 */     if (!(paramResultSet instanceof OracleCachedRowSet)) {
/* 1505 */       populateInit(paramResultSet);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1515 */     i = (this.fetchDirection == 1000) || (this.fetchDirection == 1002) ? 1 : 0;
/*      */     
/*      */ 
/* 1518 */     this.rowCount = 0;
/* 1519 */     OracleRow localOracleRow = null;
/*      */     
/*      */ 
/*      */     int j;
/*      */     
/*      */ 
/* 1525 */     if ((this.maxRows == 0) && (this.pageSize == 0))
/*      */     {
/* 1527 */       j = Integer.MAX_VALUE;
/*      */     }
/* 1529 */     else if ((this.maxRows == 0) || (this.pageSize == 0))
/*      */     {
/* 1531 */       j = Math.max(this.maxRows, this.pageSize);
/*      */     }
/*      */     else
/*      */     {
/* 1535 */       j = Math.min(this.maxRows, this.pageSize);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1545 */     if ((paramResultSet.getType() != 1003) && (this.rows.size() == 0))
/*      */     {
/* 1547 */       if (i == 0)
/*      */       {
/* 1549 */         paramResultSet.afterLast();
/*      */       }
/*      */     }
/*      */     
/* 1553 */     int k = 0;
/*      */     
/* 1555 */     while (this.rowCount < j)
/*      */     {
/* 1557 */       if (i != 0)
/*      */       {
/* 1559 */         if (!paramResultSet.next())
/*      */         {
/* 1561 */           k = 1;
/* 1562 */           break;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1567 */       else if (!paramResultSet.previous())
/*      */       {
/* 1569 */         k = 1;
/* 1570 */         break;
/*      */       }
/*      */       
/*      */ 
/* 1574 */       localOracleRow = new OracleRow(this.colCount);
/* 1575 */       for (int m = 1; m <= this.colCount; m++)
/*      */       {
/* 1577 */         Object localObject = null;
/*      */         try
/*      */         {
/* 1580 */           localObject = paramResultSet.getObject(m, this.typeMap);
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/* 1584 */           localObject = paramResultSet.getObject(m);
/*      */         }
/*      */         catch (AbstractMethodError localAbstractMethodError)
/*      */         {
/* 1588 */           localObject = paramResultSet.getObject(m);
/*      */         }
/*      */         
/*      */ 
/* 1592 */         if (((localObject instanceof Clob)) || ((localObject instanceof CLOB))) {
/* 1593 */           localOracleRow.setColumnValue(m, new OracleSerialClob((Clob)localObject));
/*      */         }
/* 1595 */         else if (((localObject instanceof Blob)) || ((localObject instanceof BLOB))) {
/* 1596 */           localOracleRow.setColumnValue(m, new OracleSerialBlob((Blob)localObject));
/*      */         }
/*      */         else {
/* 1599 */           localOracleRow.setColumnValue(m, localObject);
/*      */         }
/* 1601 */         localOracleRow.markOriginalNull(m, paramResultSet.wasNull());
/*      */       }
/*      */       
/* 1604 */       if (i != 0)
/*      */       {
/* 1606 */         this.rows.add(localOracleRow);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1611 */         this.rows.add(1, localOracleRow);
/*      */       }
/*      */       
/* 1614 */       this.rowCount += 1;
/*      */     }
/*      */     
/* 1617 */     if ((k != 0) || ((i != 0) && (paramResultSet.isAfterLast())) || ((i == 0) && (paramResultSet.isBeforeFirst())))
/*      */     {
/*      */ 
/*      */ 
/* 1621 */       this.isPopulateDone = true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1628 */     this.connection = null;
/*      */     
/* 1630 */     notifyRowSetChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/* 1641 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1642 */     localSQLException.fillInStackTrace();
/* 1643 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearParameters()
/*      */     throws SQLException
/*      */   {
/* 1653 */     this.param = null;
/* 1654 */     this.param = new Vector();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/* 1663 */     return this.previousColumnWasNull;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/* 1676 */     release();
/*      */     
/* 1678 */     this.isClosed = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 1688 */     return this.sqlWarning;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/* 1697 */     this.sqlWarning = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 1707 */     return this.rowsetMetaData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int findColumn(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1716 */     return getColumnIndex(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object[] getParams()
/*      */     throws SQLException
/*      */   {
/* 1725 */     return this.param.toArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMetaData(RowSetMetaData paramRowSetMetaData)
/*      */     throws SQLException
/*      */   {
/* 1734 */     this.rowsetMetaData = paramRowSetMetaData;
/*      */     
/*      */ 
/*      */ 
/* 1738 */     if (paramRowSetMetaData != null)
/*      */     {
/* 1740 */       this.colCount = paramRowSetMetaData.getColumnCount();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void execute()
/*      */     throws SQLException
/*      */   {
/* 1752 */     this.isConnectionStayingOpenForTxnControl = false;
/* 1753 */     getReader().readData(this);
/*      */     
/* 1755 */     this.executeCalled = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void acceptChanges()
/*      */     throws SyncProviderException
/*      */   {
/*      */     try
/*      */     {
/* 1772 */       getWriter().writeData(this);
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/* 1776 */       throw new SyncProviderException(localSQLException.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void acceptChanges(Connection paramConnection)
/*      */     throws SyncProviderException
/*      */   {
/* 1787 */     this.connection = paramConnection;
/*      */     
/*      */ 
/*      */ 
/* 1791 */     this.isConnectionStayingOpenForTxnControl = true;
/* 1792 */     acceptChanges();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object clone()
/*      */     throws CloneNotSupportedException
/*      */   {
/*      */     try
/*      */     {
/* 1806 */       return createCopy();
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/* 1810 */       throw new CloneNotSupportedException("SQL Error occured while cloning: " + localSQLException.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public CachedRowSet createCopy()
/*      */     throws SQLException
/*      */   {
/* 1820 */     OracleCachedRowSet localOracleCachedRowSet = (OracleCachedRowSet)createShared();
/* 1821 */     int i = this.rows.size();
/* 1822 */     localOracleCachedRowSet.rows = new Vector(i);
/* 1823 */     for (int j = 0; j < i; j++) {
/* 1824 */       localOracleCachedRowSet.rows.add(((OracleRow)this.rows.elementAt(j)).createCopy());
/*      */     }
/* 1826 */     return localOracleCachedRowSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowSet createShared()
/*      */     throws SQLException
/*      */   {
/* 1835 */     OracleCachedRowSet localOracleCachedRowSet = new OracleCachedRowSet();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1840 */     localOracleCachedRowSet.rows = this.rows;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1846 */     localOracleCachedRowSet.setDataSource(getDataSource());
/* 1847 */     localOracleCachedRowSet.setDataSourceName(getDataSourceName());
/* 1848 */     localOracleCachedRowSet.setUsername(getUsername());
/* 1849 */     localOracleCachedRowSet.setPassword(getPassword());
/* 1850 */     localOracleCachedRowSet.setUrl(getUrl());
/* 1851 */     localOracleCachedRowSet.setTypeMap(getTypeMap());
/* 1852 */     localOracleCachedRowSet.setMaxFieldSize(getMaxFieldSize());
/* 1853 */     localOracleCachedRowSet.setMaxRows(getMaxRows());
/* 1854 */     localOracleCachedRowSet.setQueryTimeout(getQueryTimeout());
/* 1855 */     localOracleCachedRowSet.setFetchSize(getFetchSize());
/* 1856 */     localOracleCachedRowSet.setEscapeProcessing(getEscapeProcessing());
/* 1857 */     localOracleCachedRowSet.setConcurrency(getConcurrency());
/* 1858 */     localOracleCachedRowSet.setReadOnly(this.readOnly);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1863 */     this.rowsetType = getType();
/* 1864 */     this.fetchDirection = getFetchDirection();
/* 1865 */     localOracleCachedRowSet.setCommand(getCommand());
/* 1866 */     localOracleCachedRowSet.setTransactionIsolation(getTransactionIsolation());
/*      */     
/*      */ 
/* 1869 */     localOracleCachedRowSet.presentRow = this.presentRow;
/* 1870 */     localOracleCachedRowSet.colCount = this.colCount;
/* 1871 */     localOracleCachedRowSet.rowCount = this.rowCount;
/* 1872 */     localOracleCachedRowSet.showDeleted = this.showDeleted;
/*      */     
/* 1874 */     localOracleCachedRowSet.syncProvider = this.syncProvider;
/* 1875 */     localOracleCachedRowSet.currentPage = this.currentPage;
/* 1876 */     localOracleCachedRowSet.pageSize = this.pageSize;
/* 1877 */     localOracleCachedRowSet.tableName = (this.tableName == null ? null : this.tableName);
/* 1878 */     localOracleCachedRowSet.keyColumns = (this.keyColumns == null ? null : (int[])this.keyColumns.clone());
/*      */     
/* 1880 */     int i = this.listener.size();
/* 1881 */     for (int j = 0; j < i; j++) {
/* 1882 */       localOracleCachedRowSet.listener.add(this.listener.elementAt(j));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1891 */     localOracleCachedRowSet.rowsetMetaData = new OracleRowSetMetaData(this.rowsetMetaData);
/*      */     
/* 1893 */     i = this.param.size();
/* 1894 */     for (j = 0; j < i; j++) {
/* 1895 */       localOracleCachedRowSet.param.add(this.param.elementAt(j));
/*      */     }
/* 1897 */     localOracleCachedRowSet.metaData = new String[this.metaData.length];
/* 1898 */     System.arraycopy(this.metaData, 0, localOracleCachedRowSet.metaData, 0, this.metaData.length);
/*      */     
/*      */ 
/*      */ 
/* 1902 */     return localOracleCachedRowSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void release()
/*      */     throws SQLException
/*      */   {
/* 1911 */     this.rows = null;
/* 1912 */     this.rows = new Vector();
/* 1913 */     if ((this.connection != null) && (!this.connection.isClosed()))
/* 1914 */       this.connection.close();
/* 1915 */     this.rowCount = 0;
/* 1916 */     this.presentRow = 0;
/* 1917 */     notifyRowSetChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void restoreOriginal()
/*      */     throws SQLException
/*      */   {
/* 1927 */     int i = 0;
/* 1928 */     for (int j = 0; j < this.rowCount; j++)
/*      */     {
/* 1930 */       OracleRow localOracleRow = (OracleRow)this.rows.elementAt(j);
/* 1931 */       if (localOracleRow.isRowInserted())
/*      */       {
/* 1933 */         this.rows.remove(j);
/* 1934 */         this.rowCount -= 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1939 */         j--;
/* 1940 */         i = 1;
/*      */       }
/* 1942 */       else if (localOracleRow.isRowUpdated())
/*      */       {
/* 1944 */         localOracleRow.setRowUpdated(false);
/* 1945 */         i = 1;
/*      */       }
/* 1947 */       else if (localOracleRow.isRowDeleted())
/*      */       {
/* 1949 */         localOracleRow.setRowDeleted(false);
/* 1950 */         i = 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1956 */     if (i == 0)
/*      */     {
/* 1958 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 315);
/* 1959 */       localSQLException.fillInStackTrace();
/* 1960 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1964 */     notifyRowSetChanged();
/*      */     
/*      */ 
/* 1967 */     this.presentRow = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection toCollection()
/*      */     throws SQLException
/*      */   {
/* 1978 */     Map localMap = Collections.synchronizedMap(new TreeMap());
/*      */     
/*      */     try
/*      */     {
/* 1982 */       for (int i = 0; i < this.rowCount; i++)
/*      */       {
/* 1984 */         localMap.put(Integer.valueOf(i), ((OracleRow)this.rows.elementAt(i)).toCollection());
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (Exception localException)
/*      */     {
/* 1991 */       localMap = null;
/*      */       
/* 1993 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 316);
/* 1994 */       localSQLException.fillInStackTrace();
/* 1995 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2000 */     return localMap.values();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection toCollection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2009 */     if ((paramInt < 1) || (paramInt > this.colCount))
/*      */     {
/* 2011 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
/* 2012 */       ((SQLException)localObject1).fillInStackTrace();
/* 2013 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/* 2016 */     Object localObject1 = new Vector(this.rowCount);
/* 2017 */     for (int i = 0; i < this.rowCount; i++)
/*      */     {
/* 2019 */       OracleRow localOracleRow = (OracleRow)this.rows.elementAt(i);
/* 2020 */       Object localObject2 = localOracleRow.isColumnChanged(paramInt) ? localOracleRow.getModifiedColumn(paramInt) : localOracleRow.getColumn(paramInt);
/*      */       
/*      */ 
/* 2023 */       ((Vector)localObject1).add(localObject2);
/*      */     }
/*      */     
/* 2026 */     return (Collection)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection toCollection(String paramString)
/*      */     throws SQLException
/*      */   {
/* 2035 */     return toCollection(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/* 2053 */     if (this.presentRow > this.rowCount) {
/* 2054 */       return this.rowCount;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2062 */     return this.presentRow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancelRowInsert()
/*      */     throws SQLException
/*      */   {
/* 2071 */     if (getCurrentRow().isRowInserted())
/*      */     {
/* 2073 */       this.rows.remove(--this.presentRow);
/* 2074 */       this.rowCount -= 1;
/* 2075 */       notifyRowChanged();
/*      */     }
/*      */     else
/*      */     {
/* 2079 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 317);
/* 2080 */       localSQLException.fillInStackTrace();
/* 2081 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancelRowDelete()
/*      */     throws SQLException
/*      */   {
/* 2092 */     if (getCurrentRow().isRowDeleted())
/*      */     {
/* 2094 */       getCurrentRow().setRowDeleted(false);
/* 2095 */       notifyRowChanged();
/*      */     }
/*      */     else
/*      */     {
/* 2099 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 318);
/* 2100 */       localSQLException.fillInStackTrace();
/* 2101 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/* 2112 */     if (getCurrentRow().isRowUpdated())
/*      */     {
/* 2114 */       this.updateRowFlag = false;
/* 2115 */       getCurrentRow().setRowUpdated(false);
/* 2116 */       notifyRowChanged();
/*      */     }
/*      */     else
/*      */     {
/* 2120 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 319);
/* 2121 */       localSQLException.fillInStackTrace();
/* 2122 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/* 2135 */     if (isReadOnly())
/*      */     {
/* 2137 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2138 */       localSQLException.fillInStackTrace();
/* 2139 */       throw localSQLException;
/*      */     }
/*      */     
/* 2142 */     if (!this.insertRowFlag)
/*      */     {
/* 2144 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 317);
/* 2145 */       localSQLException.fillInStackTrace();
/* 2146 */       throw localSQLException;
/*      */     }
/*      */     
/* 2149 */     if (!this.insertRow.isRowFullyPopulated())
/*      */     {
/* 2151 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 320);
/* 2152 */       localSQLException.fillInStackTrace();
/* 2153 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2159 */     this.insertRow.insertRow();
/* 2160 */     this.rows.insertElementAt(this.insertRow, this.insertRowPosition - 1);
/* 2161 */     this.insertRowFlag = false;
/* 2162 */     this.rowCount += 1;
/* 2163 */     notifyRowChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/* 2175 */     if (isReadOnly())
/*      */     {
/* 2177 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2178 */       localSQLException.fillInStackTrace();
/* 2179 */       throw localSQLException;
/*      */     }
/*      */     
/* 2182 */     if (this.updateRowFlag)
/*      */     {
/* 2184 */       this.updateRowFlag = false;
/* 2185 */       getCurrentRow().setRowUpdated(true);
/* 2186 */       notifyRowChanged();
/*      */     }
/*      */     else
/*      */     {
/* 2190 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 319);
/* 2191 */       localSQLException.fillInStackTrace();
/* 2192 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/* 2203 */     if (isReadOnly())
/*      */     {
/* 2205 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2206 */       localSQLException.fillInStackTrace();
/* 2207 */       throw localSQLException;
/*      */     }
/*      */     
/* 2210 */     getCurrentRow().setRowDeleted(true);
/* 2211 */     notifyRowChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 2221 */     OracleRow localOracleRow = getCurrentRow();
/* 2222 */     if (localOracleRow.isRowUpdated()) {
/* 2223 */       localOracleRow.cancelRowUpdates();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 2235 */     if (isReadOnly())
/*      */     {
/* 2237 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2238 */       localSQLException.fillInStackTrace();
/* 2239 */       throw localSQLException;
/*      */     }
/*      */     
/* 2242 */     this.insertRow = new OracleRow(this.colCount, true);
/* 2243 */     this.insertRowFlag = true;
/*      */     
/* 2245 */     if (isAfterLast()) {
/* 2246 */       this.insertRowPosition = this.presentRow;
/*      */     } else {
/* 2248 */       this.insertRowPosition = (this.presentRow + 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 2260 */     if (isReadOnly())
/*      */     {
/* 2262 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2263 */       localSQLException.fillInStackTrace();
/* 2264 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2271 */     this.insertRowFlag = false;
/* 2272 */     this.updateRowFlag = false;
/* 2273 */     absolute(this.presentRow);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 2283 */     return getCurrentRow().isRowUpdated();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 2292 */     return getCurrentRow().isRowInserted();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 2301 */     return getCurrentRow().isRowDeleted();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getOriginalRow()
/*      */     throws SQLException
/*      */   {
/* 2313 */     OracleCachedRowSet localOracleCachedRowSet = new OracleCachedRowSet();
/* 2314 */     localOracleCachedRowSet.rowsetMetaData = this.rowsetMetaData;
/* 2315 */     localOracleCachedRowSet.rowCount = 1;
/* 2316 */     localOracleCachedRowSet.colCount = this.colCount;
/* 2317 */     localOracleCachedRowSet.presentRow = 0;
/* 2318 */     localOracleCachedRowSet.setReader(null);
/* 2319 */     localOracleCachedRowSet.setWriter(null);
/* 2320 */     OracleRow localOracleRow = new OracleRow(this.rowsetMetaData.getColumnCount(), getCurrentRow().getOriginalRow());
/*      */     
/*      */ 
/* 2323 */     localOracleCachedRowSet.rows.add(localOracleRow);
/*      */     
/* 2325 */     return localOracleCachedRowSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getOriginal()
/*      */     throws SQLException
/*      */   {
/* 2337 */     OracleCachedRowSet localOracleCachedRowSet = new OracleCachedRowSet();
/* 2338 */     localOracleCachedRowSet.rowsetMetaData = this.rowsetMetaData;
/* 2339 */     localOracleCachedRowSet.rowCount = this.rowCount;
/* 2340 */     localOracleCachedRowSet.colCount = this.colCount;
/*      */     
/*      */ 
/* 2343 */     localOracleCachedRowSet.presentRow = 0;
/*      */     
/*      */ 
/* 2346 */     localOracleCachedRowSet.setType(1004);
/* 2347 */     localOracleCachedRowSet.setConcurrency(1008);
/*      */     
/* 2349 */     localOracleCachedRowSet.setReader(null);
/* 2350 */     localOracleCachedRowSet.setWriter(null);
/* 2351 */     int i = this.rowsetMetaData.getColumnCount();
/* 2352 */     OracleRow localOracleRow = null;
/*      */     
/* 2354 */     Iterator localIterator = this.rows.iterator();
/* 2355 */     for (; localIterator.hasNext(); 
/* 2356 */         localOracleCachedRowSet.rows.add(localOracleRow)) {
/* 2357 */       localOracleRow = new OracleRow(i, ((OracleRow)localIterator.next()).getOriginalRow());
/*      */     }
/* 2359 */     return localOracleCachedRowSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2373 */     checkParamIndex(paramInt1);
/*      */     
/* 2375 */     this.param.add(paramInt1 - 1, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2385 */     checkParamIndex(paramInt1);
/* 2386 */     Object[] arrayOfObject = { Integer.valueOf(paramInt2), paramString };
/* 2387 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2397 */     checkParamIndex(paramInt);
/* 2398 */     this.param.add(paramInt - 1, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 2408 */     checkParamIndex(paramInt);
/* 2409 */     this.param.add(paramInt - 1, new Byte(paramByte));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2419 */     checkParamIndex(paramInt);
/* 2420 */     this.param.add(paramInt - 1, Short.valueOf(paramShort));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2430 */     checkParamIndex(paramInt1);
/* 2431 */     this.param.add(paramInt1 - 1, Integer.valueOf(paramInt2));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2441 */     checkParamIndex(paramInt);
/* 2442 */     this.param.add(paramInt - 1, Long.valueOf(paramLong));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 2452 */     checkParamIndex(paramInt);
/* 2453 */     this.param.add(paramInt - 1, Float.valueOf(paramFloat));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 2463 */     checkParamIndex(paramInt);
/* 2464 */     this.param.add(paramInt - 1, Double.valueOf(paramDouble));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 2474 */     checkParamIndex(paramInt);
/* 2475 */     this.param.add(paramInt - 1, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2485 */     checkParamIndex(paramInt);
/* 2486 */     this.param.add(paramInt - 1, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2496 */     checkParamIndex(paramInt);
/* 2497 */     this.param.add(paramInt - 1, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int paramInt, java.sql.Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 2507 */     checkParamIndex(paramInt);
/* 2508 */     this.param.add(paramInt - 1, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 2518 */     checkParamIndex(paramInt);
/* 2519 */     this.param.add(paramInt - 1, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 2529 */     checkParamIndex(paramInt);
/* 2530 */     this.param.add(paramInt - 1, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 2540 */     checkParamIndex(paramInt);
/* 2541 */     this.param.add(paramInt - 1, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 2551 */     checkParamIndex(paramInt);
/* 2552 */     this.param.add(paramInt - 1, paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 2562 */     checkParamIndex(paramInt);
/* 2563 */     this.param.add(paramInt - 1, paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 2573 */     checkParamIndex(paramInt);
/* 2574 */     this.param.add(paramInt - 1, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2585 */     checkParamIndex(paramInt1);
/* 2586 */     Object[] arrayOfObject = { paramInputStream, Integer.valueOf(paramInt2), Integer.valueOf(2) };
/*      */     
/* 2588 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2598 */     checkParamIndex(paramInt);
/* 2599 */     Object[] arrayOfObject = { paramTime, paramCalendar };
/* 2600 */     this.param.add(paramInt - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2610 */     checkParamIndex(paramInt);
/* 2611 */     Object[] arrayOfObject = { paramTimestamp, paramCalendar };
/* 2612 */     this.param.add(paramInt - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 2621 */     checkParamIndex(paramInt);
/* 2622 */     this.param.add(paramInt - 1, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2632 */     checkParamIndex(paramInt1);
/* 2633 */     Object[] arrayOfObject = { paramInputStream, Integer.valueOf(paramInt2), Integer.valueOf(3) };
/*      */     
/* 2635 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2645 */     checkParamIndex(paramInt1);
/* 2646 */     Object[] arrayOfObject = { paramInputStream, Integer.valueOf(paramInt2), Integer.valueOf(1) };
/*      */     
/* 2648 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2658 */     checkParamIndex(paramInt1);
/* 2659 */     Object[] arrayOfObject = { paramReader, Integer.valueOf(paramInt2), Integer.valueOf(4) };
/*      */     
/* 2661 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2671 */     checkParamIndex(paramInt1);
/* 2672 */     Object[] arrayOfObject = { paramObject, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) };
/* 2673 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2683 */     checkParamIndex(paramInt1);
/* 2684 */     Object[] arrayOfObject = { paramObject, Integer.valueOf(paramInt2) };
/* 2685 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int paramInt, java.sql.Date paramDate, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2695 */     checkParamIndex(paramInt);
/* 2696 */     Object[] arrayOfObject = { paramDate, paramCalendar };
/* 2697 */     this.param.add(paramInt - 1, arrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setURL(int paramInt, URL paramURL)
/*      */     throws SQLException
/*      */   {
/* 2707 */     checkParamIndex(paramInt);
/* 2708 */     this.param.add(paramInt - 1, paramURL.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2728 */     int i = this.presentRow * this.colCount + paramInt - 1;
/* 2729 */     Object localObject = null;
/*      */     
/* 2731 */     if (!isUpdated(paramInt)) {
/* 2732 */       localObject = getCurrentRow().getColumn(paramInt);
/*      */     } else
/* 2734 */       localObject = getCurrentRow().getModifiedColumn(paramInt);
/* 2735 */     this.previousColumnWasNull = (localObject == null);
/*      */     
/* 2737 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized Number getNumber(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2747 */     Object localObject = getObject(paramInt);
/*      */     
/* 2749 */     if ((localObject == null) || ((localObject instanceof BigDecimal)) || ((localObject instanceof Number)))
/*      */     {
/*      */ 
/* 2752 */       return (Number)localObject;
/*      */     }
/* 2754 */     if ((localObject instanceof Boolean)) {
/* 2755 */       return Integer.valueOf(((Boolean)localObject).booleanValue() ? 1 : 0);
/*      */     }
/* 2757 */     if ((localObject instanceof String))
/*      */     {
/*      */       try
/*      */       {
/* 2761 */         return new BigDecimal((String)localObject);
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException localNumberFormatException)
/*      */       {
/* 2766 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2767 */         localSQLException2.fillInStackTrace();
/* 2768 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2775 */     SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2776 */     localSQLException1.fillInStackTrace();
/* 2777 */     throw localSQLException1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 2789 */     return getObject(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2798 */     Object localObject = getObject(paramInt);
/*      */     
/* 2800 */     if (localObject == null) {
/* 2801 */       return false;
/*      */     }
/* 2803 */     if ((localObject instanceof Boolean)) {
/* 2804 */       return ((Boolean)localObject).booleanValue();
/*      */     }
/* 2806 */     if ((localObject instanceof Number)) {
/* 2807 */       return ((Number)localObject).doubleValue() != 0.0D;
/*      */     }
/*      */     
/*      */ 
/* 2811 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2812 */     localSQLException.fillInStackTrace();
/* 2813 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2828 */     Object localObject1 = getObject(paramInt);
/*      */     
/* 2830 */     if (localObject1 == null) {
/* 2831 */       return 0;
/*      */     }
/* 2833 */     if ((localObject1 instanceof BigDecimal))
/*      */     {
/* 2835 */       localObject2 = (BigDecimal)localObject1;
/* 2836 */       if ((((BigDecimal)localObject2).compareTo(new BigDecimal(127)) == 1) || (((BigDecimal)localObject2).compareTo(new BigDecimal(-128)) == -1))
/*      */       {
/*      */ 
/* 2839 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26);
/* 2840 */         localSQLException.fillInStackTrace();
/* 2841 */         throw localSQLException;
/*      */       }
/*      */       
/* 2844 */       return ((BigDecimal)localObject2).byteValue();
/*      */     }
/*      */     
/* 2847 */     if ((localObject1 instanceof Number)) {
/* 2848 */       return ((Number)localObject1).byteValue();
/*      */     }
/* 2850 */     if ((localObject1 instanceof String)) {
/* 2851 */       return ((String)localObject1).getBytes()[0];
/*      */     }
/* 2853 */     if ((localObject1 instanceof OracleSerialBlob))
/*      */     {
/* 2855 */       localObject2 = (OracleSerialBlob)localObject1;
/* 2856 */       return localObject2.getBytes(1L, 1)[0];
/*      */     }
/* 2858 */     if ((localObject1 instanceof OracleSerialClob))
/*      */     {
/* 2860 */       localObject2 = (OracleSerialClob)localObject1;
/* 2861 */       return localObject2.getSubString(1L, 1).getBytes()[0];
/*      */     }
/*      */     
/*      */ 
/* 2865 */     Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2866 */     ((SQLException)localObject2).fillInStackTrace();
/* 2867 */     throw ((Throwable)localObject2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2878 */     Number localNumber = getNumber(paramInt);
/*      */     
/* 2880 */     return localNumber == null ? 0 : localNumber.shortValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2889 */     Number localNumber = getNumber(paramInt);
/*      */     
/* 2891 */     return localNumber == null ? 0 : localNumber.intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2900 */     Number localNumber = getNumber(paramInt);
/*      */     
/* 2902 */     return localNumber == null ? 0L : localNumber.longValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2911 */     Number localNumber = getNumber(paramInt);
/*      */     
/* 2913 */     return localNumber == null ? 0.0F : localNumber.floatValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2922 */     Number localNumber = getNumber(paramInt);
/*      */     
/* 2924 */     return localNumber == null ? 0.0D : localNumber.doubleValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2933 */     Number localNumber = getNumber(paramInt);
/*      */     
/* 2935 */     if ((localNumber == null) || ((localNumber instanceof BigDecimal))) {
/* 2936 */       return (BigDecimal)localNumber;
/*      */     }
/* 2938 */     return new BigDecimal(localNumber.doubleValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2948 */     return getBigDecimal(paramInt1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2957 */     Object localObject1 = getObject(paramInt);
/*      */     
/* 2959 */     if (localObject1 == null) {
/* 2960 */       return (java.sql.Date)localObject1;
/*      */     }
/* 2962 */     if ((localObject1 instanceof Time))
/*      */     {
/* 2964 */       localObject2 = (Time)localObject1;
/* 2965 */       return new java.sql.Date(((Time)localObject2).getTime());
/*      */     }
/*      */     
/* 2968 */     if ((localObject1 instanceof java.util.Date))
/*      */     {
/* 2970 */       localObject2 = (java.util.Date)localObject1;
/* 2971 */       return new java.sql.Date(((java.util.Date)localObject2).getYear(), ((java.util.Date)localObject2).getMonth(), ((java.util.Date)localObject2).getDate());
/*      */     }
/*      */     
/* 2974 */     if ((localObject1 instanceof TIMESTAMP)) {
/* 2975 */       return ((TIMESTAMP)localObject1).dateValue();
/*      */     }
/* 2977 */     if ((localObject1 instanceof TIMESTAMPTZ)) {
/* 2978 */       return ((TIMESTAMPTZ)localObject1).dateValue(getConnectionInternal());
/*      */     }
/* 2980 */     if ((localObject1 instanceof TIMESTAMPLTZ))
/*      */     {
/* 2982 */       localObject2 = getConnectionInternal();
/*      */       
/* 2984 */       return ((TIMESTAMPLTZ)localObject1).dateValue((Connection)localObject2, getSessionCalendar((Connection)localObject2));
/*      */     }
/*      */     
/*      */ 
/* 2988 */     Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2989 */     ((SQLException)localObject2).fillInStackTrace();
/* 2990 */     throw ((Throwable)localObject2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 3001 */     return getDate(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3011 */     Object localObject1 = getObject(paramInt);
/*      */     
/* 3013 */     if (localObject1 == null) {
/* 3014 */       return (Time)localObject1;
/*      */     }
/* 3016 */     if ((localObject1 instanceof java.util.Date))
/*      */     {
/* 3018 */       localObject2 = (java.util.Date)localObject1;
/* 3019 */       return new Time(((java.util.Date)localObject2).getHours(), ((java.util.Date)localObject2).getMinutes(), ((java.util.Date)localObject2).getSeconds());
/*      */     }
/*      */     
/*      */ 
/* 3023 */     if ((localObject1 instanceof TIMESTAMP)) {
/* 3024 */       return ((TIMESTAMP)localObject1).timeValue();
/*      */     }
/* 3026 */     if ((localObject1 instanceof TIMESTAMPTZ)) {
/* 3027 */       return ((TIMESTAMPTZ)localObject1).timeValue(getConnectionInternal());
/*      */     }
/* 3029 */     if ((localObject1 instanceof TIMESTAMPLTZ))
/*      */     {
/* 3031 */       localObject2 = getConnectionInternal();
/*      */       
/* 3033 */       return ((TIMESTAMPLTZ)localObject1).timeValue((Connection)localObject2, getSessionCalendar((Connection)localObject2));
/*      */     }
/*      */     
/*      */ 
/* 3037 */     Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3038 */     ((SQLException)localObject2).fillInStackTrace();
/* 3039 */     throw ((Throwable)localObject2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 3050 */     return getTime(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3059 */     Object localObject1 = getObject(paramInt);
/*      */     
/* 3061 */     if ((localObject1 == null) || ((localObject1 instanceof Timestamp))) {
/* 3062 */       return (Timestamp)localObject1;
/*      */     }
/* 3064 */     if ((localObject1 instanceof java.util.Date)) {
/* 3065 */       return new Timestamp(((java.util.Date)localObject1).getTime());
/*      */     }
/* 3067 */     if ((localObject1 instanceof TIMESTAMP)) {
/* 3068 */       return ((TIMESTAMP)localObject1).timestampValue();
/*      */     }
/* 3070 */     if ((localObject1 instanceof TIMESTAMPTZ)) {
/* 3071 */       return ((TIMESTAMPTZ)localObject1).timestampValue(getConnectionInternal());
/*      */     }
/* 3073 */     if ((localObject1 instanceof TIMESTAMPLTZ))
/*      */     {
/* 3075 */       localObject2 = getConnectionInternal();
/*      */       
/* 3077 */       return ((TIMESTAMPLTZ)localObject1).timestampValue((Connection)localObject2, getSessionCalendar((Connection)localObject2));
/*      */     }
/*      */     
/*      */ 
/* 3081 */     Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3082 */     ((SQLException)localObject2).fillInStackTrace();
/* 3083 */     throw ((Throwable)localObject2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 3094 */     return getTimestamp(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3103 */     Object localObject1 = getObject(paramInt);
/*      */     
/* 3105 */     if (localObject1 == null) {
/* 3106 */       return (byte[])localObject1;
/*      */     }
/* 3108 */     if ((localObject1 instanceof byte[])) {
/* 3109 */       return (byte[])localObject1;
/*      */     }
/* 3111 */     if ((localObject1 instanceof String)) {
/* 3112 */       return (byte[])((String)localObject1).getBytes();
/*      */     }
/* 3114 */     if ((localObject1 instanceof Number)) {
/* 3115 */       return (byte[])((Number)localObject1).toString().getBytes();
/*      */     }
/* 3117 */     if ((localObject1 instanceof BigDecimal)) {
/* 3118 */       return (byte[])((BigDecimal)localObject1).toString().getBytes();
/*      */     }
/* 3120 */     if ((localObject1 instanceof OracleSerialBlob))
/*      */     {
/* 3122 */       localObject2 = (OracleSerialBlob)localObject1;
/* 3123 */       return ((OracleSerialBlob)localObject2).getBytes(1L, (int)((OracleSerialBlob)localObject2).length());
/*      */     }
/* 3125 */     if ((localObject1 instanceof OracleSerialClob))
/*      */     {
/* 3127 */       localObject2 = (OracleSerialClob)localObject1;
/* 3128 */       return ((OracleSerialClob)localObject2).getSubString(1L, (int)((OracleSerialClob)localObject2).length()).getBytes();
/*      */     }
/*      */     
/*      */ 
/* 3132 */     Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 3133 */     ((SQLException)localObject2).fillInStackTrace();
/* 3134 */     throw ((Throwable)localObject2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3145 */     Object localObject = getObject(paramInt);
/*      */     
/* 3147 */     if ((localObject == null) || ((localObject instanceof Ref))) {
/* 3148 */       return (Ref)localObject;
/*      */     }
/*      */     
/* 3151 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3152 */     localSQLException.fillInStackTrace();
/* 3153 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3164 */     Object localObject = getObject(paramInt);
/*      */     
/* 3166 */     if ((localObject == null) || ((localObject instanceof OracleSerialBlob))) {
/* 3167 */       return (Blob)localObject;
/*      */     }
/*      */     
/* 3170 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3171 */     localSQLException.fillInStackTrace();
/* 3172 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3183 */     Object localObject = getObject(paramInt);
/*      */     
/* 3185 */     if ((localObject == null) || ((localObject instanceof OracleSerialClob))) {
/* 3186 */       return (Clob)localObject;
/*      */     }
/*      */     
/* 3189 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3190 */     localSQLException.fillInStackTrace();
/* 3191 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3202 */     Object localObject = getObject(paramInt);
/*      */     
/* 3204 */     if ((localObject == null) || ((localObject instanceof Array))) {
/* 3205 */       return (Array)localObject;
/*      */     }
/*      */     
/* 3208 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3209 */     localSQLException.fillInStackTrace();
/* 3210 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3220 */     Object localObject1 = getObject(paramInt);
/*      */     
/* 3222 */     if (localObject1 == null) {
/* 3223 */       return (String)localObject1;
/*      */     }
/* 3225 */     if ((localObject1 instanceof String)) {
/* 3226 */       return (String)localObject1;
/*      */     }
/* 3228 */     if (((localObject1 instanceof Number)) || ((localObject1 instanceof BigDecimal))) {
/* 3229 */       return localObject1.toString();
/*      */     }
/* 3231 */     if ((localObject1 instanceof java.sql.Date)) {
/* 3232 */       return localObject1.toString();
/*      */     }
/* 3234 */     if ((localObject1 instanceof Timestamp)) {
/* 3235 */       return localObject1.toString();
/*      */     }
/* 3237 */     if ((localObject1 instanceof byte[]))
/* 3238 */       return new String((byte[])localObject1);
/*      */     Object localObject2;
/* 3240 */     if ((localObject1 instanceof OracleSerialClob))
/*      */     {
/* 3242 */       localObject2 = (OracleSerialClob)localObject1;
/* 3243 */       return ((OracleSerialClob)localObject2).getSubString(1L, (int)((OracleSerialClob)localObject2).length());
/*      */     }
/*      */     
/* 3246 */     if ((localObject1 instanceof OracleSerialBlob))
/*      */     {
/* 3248 */       localObject2 = (OracleSerialBlob)localObject1;
/* 3249 */       return new String(((OracleSerialBlob)localObject2).getBytes(1L, (int)((OracleSerialBlob)localObject2).length()));
/*      */     }
/*      */     
/*      */ 
/* 3253 */     if ((localObject1 instanceof URL)) {
/* 3254 */       return ((URL)localObject1).toString();
/*      */     }
/* 3256 */     if ((localObject1 instanceof ROWID)) {
/* 3257 */       return ((ROWID)localObject1).stringValue();
/*      */     }
/* 3259 */     if ((localObject1 instanceof Reader))
/*      */     {
/*      */       try
/*      */       {
/* 3263 */         localObject2 = (Reader)localObject1;
/* 3264 */         localObject3 = new char['Ѐ'];
/* 3265 */         int i = 0;
/* 3266 */         StringBuffer localStringBuffer = new StringBuffer(1024);
/* 3267 */         while ((i = ((Reader)localObject2).read((char[])localObject3)) > 0)
/* 3268 */           localStringBuffer.append((char[])localObject3, 0, i);
/* 3269 */         return localStringBuffer.substring(0, localStringBuffer.length());
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 3274 */         Object localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 321, localIOException.getMessage());
/* 3275 */         ((SQLException)localObject3).fillInStackTrace();
/* 3276 */         throw ((Throwable)localObject3);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3282 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 3283 */     localSQLException.fillInStackTrace();
/* 3284 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3295 */     InputStream localInputStream = getStream(paramInt);
/*      */     
/* 3297 */     return localInputStream == null ? null : localInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3306 */     Object localObject = getObject(paramInt);
/*      */     
/* 3308 */     if (localObject == null) {
/* 3309 */       return (InputStream)localObject;
/*      */     }
/*      */     
/* 3312 */     if ((localObject instanceof String)) {
/* 3313 */       return new StringBufferInputStream((String)localObject);
/*      */     }
/*      */     
/* 3316 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 3317 */     localSQLException.fillInStackTrace();
/* 3318 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3330 */     InputStream localInputStream = getStream(paramInt);
/*      */     
/* 3332 */     return localInputStream == null ? null : localInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3344 */       InputStream localInputStream = getAsciiStream(paramInt);
/*      */       
/* 3346 */       if (localInputStream == null) {
/* 3347 */         return null;
/*      */       }
/* 3349 */       localObject = new StringBuffer();
/* 3350 */       int i = 0;
/* 3351 */       while ((i = localInputStream.read()) != -1) {
/* 3352 */         ((StringBuffer)localObject).append((char)i);
/*      */       }
/*      */       
/*      */ 
/* 3356 */       char[] arrayOfChar = new char[((StringBuffer)localObject).length()];
/* 3357 */       ((StringBuffer)localObject).getChars(0, ((StringBuffer)localObject).length(), arrayOfChar, 0);
/* 3358 */       CharArrayReader localCharArrayReader = new CharArrayReader(arrayOfChar);
/* 3359 */       arrayOfChar = null;
/*      */       
/* 3361 */       return localCharArrayReader;
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3366 */       Object localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 322);
/* 3367 */       ((SQLException)localObject).fillInStackTrace();
/* 3368 */       throw ((Throwable)localObject);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Object getObject(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3385 */     return getObject(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3394 */     return getBoolean(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3403 */     return getByte(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3412 */     return getShort(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3421 */     return getInt(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3430 */     return getLong(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3439 */     return getFloat(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3448 */     return getDouble(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3457 */     return getBigDecimal(getColumnIndex(paramString), paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3466 */     return getBytes(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Date getDate(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3475 */     return getDate(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3484 */     return getTime(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3493 */     return getTimestamp(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 3502 */     return getTime(getColumnIndex(paramString), paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Date getDate(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 3511 */     return getDate(getColumnIndex(paramString), paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3520 */     return getAsciiStream(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3529 */     return getUnicodeStream(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3538 */     return getString(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3547 */     return getBinaryStream(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3556 */     return getCharacterStream(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3565 */     return getBigDecimal(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 3574 */     return getTimestamp(getColumnIndex(paramString), paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(String paramString, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 3582 */     return getObject(getColumnIndex(paramString), paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3591 */     return getRef(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3600 */     return getBlob(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3609 */     return getClob(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3618 */     return getArray(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 3632 */     updateObject(paramInt, paramObject, (int[])null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void updateObject(int paramInt, Object paramObject, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 3650 */     checkColumnIndex(paramInt);
/* 3651 */     if (this.insertRowFlag)
/*      */     {
/* 3653 */       checkAndFilterObject(paramInt, paramObject);
/* 3654 */       this.insertRow.updateObject(paramInt, paramObject, paramArrayOfInt);
/*      */     }
/* 3656 */     else if ((!isBeforeFirst()) && (!isAfterLast()))
/*      */     {
/*      */ 
/*      */ 
/* 3660 */       this.updateRowFlag = true;
/* 3661 */       this.updateRowPosition = this.presentRow;
/* 3662 */       getCurrentRow().updateObject(paramInt, paramObject, paramArrayOfInt);
/*      */     }
/*      */     else {
/* 3665 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 3666 */       localSQLException.fillInStackTrace();
/* 3667 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3678 */     updateObject(paramInt, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3689 */     updateCharacterStreamInternal(paramInt1, paramReader, paramInt2, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3700 */     checkColumnIndex(paramInt1);
/*      */     
/* 3702 */     if (paramInt2 < 0)
/*      */     {
/* 3704 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3705 */       localSQLException.fillInStackTrace();
/* 3706 */       throw localSQLException;
/*      */     }
/*      */     
/* 3709 */     int i = getMetaData().getColumnType(paramInt1);
/* 3710 */     if (!isStreamType(i))
/*      */     {
/*      */       try
/*      */       {
/* 3714 */         int j = 0;
/* 3715 */         int m = paramInt2;
/* 3716 */         char[] arrayOfChar = new char['Ѐ'];
/* 3717 */         StringBuilder localStringBuilder = new StringBuilder(1024);
/*      */         
/* 3719 */         while (m > 0)
/*      */         {
/* 3721 */           if (m >= 1024) {
/* 3722 */             j = paramReader.read(arrayOfChar);
/*      */           } else {
/* 3724 */             j = paramReader.read(arrayOfChar, 0, m);
/*      */           }
/*      */           
/*      */ 
/* 3728 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3731 */           localStringBuilder.append(arrayOfChar, 0, j);
/* 3732 */           m -= j;
/*      */         }
/*      */         
/* 3735 */         paramReader.close();
/* 3736 */         if (m == paramInt2)
/*      */         {
/* 3738 */           updateNull(paramInt1);
/* 3739 */           return;
/*      */         }
/*      */         
/* 3742 */         updateString(paramInt1, localStringBuilder.toString());
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 3747 */         localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3748 */         ((SQLException)localObject).fillInStackTrace();
/* 3749 */         throw ((Throwable)localObject);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3755 */     int k = paramBoolean ? 4 : 3;
/*      */     
/*      */ 
/* 3758 */     Object localObject = { paramInt2, k };
/*      */     
/* 3760 */     updateObject(paramInt1, paramReader, (int[])localObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3771 */     updateCharacterStream(getColumnIndex(paramString), paramReader, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 3781 */     updateTimestamp(getColumnIndex(paramString), paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3791 */     updateBinaryStream(getColumnIndex(paramString), paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3802 */     checkColumnIndex(paramInt1);
/*      */     
/* 3804 */     if (paramInt2 < 0)
/*      */     {
/* 3806 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3807 */       localSQLException1.fillInStackTrace();
/* 3808 */       throw localSQLException1;
/*      */     }
/*      */     
/* 3811 */     int i = getMetaData().getColumnType(paramInt1);
/* 3812 */     if (!isStreamType(i))
/*      */     {
/*      */       try
/*      */       {
/* 3816 */         int j = 0;
/* 3817 */         int k = paramInt2;
/* 3818 */         byte[] arrayOfByte = new byte['Ѐ'];
/* 3819 */         ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(1024);
/*      */         
/*      */ 
/* 3822 */         while (k > 0)
/*      */         {
/* 3824 */           if (k >= 1024) {
/* 3825 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 3827 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           }
/*      */           
/*      */ 
/* 3831 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3834 */           localByteArrayOutputStream.write(arrayOfByte, 0, j);
/* 3835 */           k -= j;
/*      */         }
/*      */         
/* 3838 */         paramInputStream.close();
/* 3839 */         if (k == paramInt2)
/*      */         {
/* 3841 */           updateNull(paramInt1);
/* 3842 */           return;
/*      */         }
/*      */         
/* 3845 */         updateBytes(paramInt1, localByteArrayOutputStream.toByteArray());
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 3850 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3851 */         localSQLException2.fillInStackTrace();
/* 3852 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3858 */     int[] arrayOfInt = { paramInt2, 2 };
/*      */     
/* 3860 */     updateObject(paramInt1, paramInputStream, arrayOfInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3871 */     checkColumnIndex(paramInt1);
/*      */     
/* 3873 */     if (paramInt2 < 0)
/*      */     {
/* 3875 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3876 */       localSQLException1.fillInStackTrace();
/* 3877 */       throw localSQLException1;
/*      */     }
/*      */     
/* 3880 */     int i = getMetaData().getColumnType(paramInt1);
/* 3881 */     if (!isStreamType(i))
/*      */     {
/*      */       try
/*      */       {
/* 3885 */         int j = 0;
/* 3886 */         int k = paramInt2;
/* 3887 */         byte[] arrayOfByte = new byte['Ѐ'];
/* 3888 */         char[] arrayOfChar = new char['Ѐ'];
/* 3889 */         StringBuilder localStringBuilder = new StringBuilder(1024);
/*      */         
/* 3891 */         while (k > 0)
/*      */         {
/* 3893 */           if (k >= 1024) {
/* 3894 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 3896 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           }
/*      */           
/*      */ 
/* 3900 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3903 */           DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*      */           
/* 3905 */           localStringBuilder.append(arrayOfChar, 0, j);
/* 3906 */           k -= j;
/*      */         }
/*      */         
/* 3909 */         paramInputStream.close();
/* 3910 */         if (k == paramInt2)
/*      */         {
/* 3912 */           updateNull(paramInt1);
/* 3913 */           return;
/*      */         }
/*      */         
/* 3916 */         updateString(paramInt1, localStringBuilder.toString());
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 3921 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3922 */         localSQLException2.fillInStackTrace();
/* 3923 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3929 */     int[] arrayOfInt = { paramInt2, 1 };
/*      */     
/* 3931 */     updateObject(paramInt1, paramInputStream, arrayOfInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 3942 */     updateObject(paramInt, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3952 */     updateObject(paramInt, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 3962 */     updateObject(paramInt, new Byte(paramByte));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 3972 */     updateObject(paramInt, Short.valueOf(paramShort));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3982 */     updateObject(paramInt1, Integer.valueOf(paramInt2));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3992 */     updateObject(paramInt, Long.valueOf(paramLong));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 4002 */     updateObject(paramInt, Float.valueOf(paramFloat));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 4012 */     updateObject(paramInt, Double.valueOf(paramDouble));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 4022 */     updateObject(paramInt, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 4032 */     updateObject(paramInt, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 4042 */     updateObject(paramInt, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(int paramInt, java.sql.Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 4052 */     updateObject(paramInt, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 4062 */     updateObject(paramInt, new Timestamp(0, 0, 0, paramTime.getHours(), paramTime.getMinutes(), paramTime.getSeconds(), 0));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 4074 */     if (!(paramObject instanceof Number))
/*      */     {
/* 4076 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 4077 */       localSQLException.fillInStackTrace();
/* 4078 */       throw localSQLException;
/*      */     }
/*      */     
/* 4081 */     updateObject(paramInt1, new BigDecimal(new BigInteger(((Number)paramObject).toString()), paramInt2));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4097 */     updateNull(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4107 */     updateAsciiStream(getColumnIndex(paramString), paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 4117 */     updateBoolean(getColumnIndex(paramString), paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(String paramString, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 4127 */     updateByte(getColumnIndex(paramString), paramByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(String paramString, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 4137 */     updateShort(getColumnIndex(paramString), paramShort);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4147 */     updateInt(getColumnIndex(paramString), paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(String paramString, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 4157 */     updateLong(getColumnIndex(paramString), paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(String paramString, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 4167 */     updateFloat(getColumnIndex(paramString), paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(String paramString, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 4177 */     updateDouble(getColumnIndex(paramString), paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 4187 */     updateBigDecimal(getColumnIndex(paramString), paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 4197 */     updateString(getColumnIndex(paramString1), paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(String paramString, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 4207 */     updateBytes(getColumnIndex(paramString), paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(String paramString, java.sql.Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 4217 */     updateDate(getColumnIndex(paramString), paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(String paramString, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 4227 */     updateTime(getColumnIndex(paramString), paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String paramString, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 4238 */     updateObject(getColumnIndex(paramString), paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4248 */     updateObject(getColumnIndex(paramString), paramObject, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4275 */     Object localObject = getObject(paramInt);
/*      */     
/* 4277 */     if (localObject == null) {
/* 4278 */       return (URL)localObject;
/*      */     }
/* 4280 */     if ((localObject instanceof URL)) {
/* 4281 */       return (URL)localObject;
/*      */     }
/* 4283 */     if ((localObject instanceof String))
/*      */     {
/*      */       try
/*      */       {
/* 4287 */         return new URL((String)localObject);
/*      */ 
/*      */       }
/*      */       catch (MalformedURLException localMalformedURLException)
/*      */       {
/* 4292 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 4293 */         localSQLException2.fillInStackTrace();
/* 4294 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4300 */     SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 4301 */     localSQLException1.fillInStackTrace();
/* 4302 */     throw localSQLException1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4328 */     return getURL(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 4351 */     updateObject(paramInt, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRef(String paramString, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 4375 */     updateRef(getColumnIndex(paramString), paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 4399 */     updateObject(paramInt, paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBlob(String paramString, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 4423 */     updateBlob(getColumnIndex(paramString), paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 4447 */     updateObject(paramInt, paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateClob(String paramString, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 4471 */     updateClob(getColumnIndex(paramString), paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 4495 */     updateObject(paramInt, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateArray(String paramString, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 4519 */     updateArray(getColumnIndex(paramString), paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getKeyColumns()
/*      */     throws SQLException
/*      */   {
/* 4545 */     return this.keyColumns;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setKeyColumns(int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 4570 */     int i = 0;
/*      */     
/* 4572 */     if (this.rowsetMetaData != null)
/*      */     {
/* 4574 */       i = this.rowsetMetaData.getColumnCount();
/* 4575 */       if ((paramArrayOfInt == null) || (paramArrayOfInt.length > i))
/*      */       {
/*      */ 
/* 4578 */         SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 324);
/* 4579 */         localSQLException1.fillInStackTrace();
/* 4580 */         throw localSQLException1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4585 */     int j = paramArrayOfInt.length;
/* 4586 */     this.keyColumns = new int[j];
/*      */     
/* 4588 */     for (int k = 0; k < j; k++)
/*      */     {
/* 4590 */       if ((paramArrayOfInt[k] <= 0) || (paramArrayOfInt[k] > i))
/*      */       {
/*      */ 
/* 4593 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramArrayOfInt[k]);
/* 4594 */         localSQLException2.fillInStackTrace();
/* 4595 */         throw localSQLException2;
/*      */       }
/*      */       
/*      */ 
/* 4599 */       this.keyColumns[k] = paramArrayOfInt[k];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPageSize()
/*      */   {
/* 4614 */     return this.pageSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4634 */     if ((paramInt < 0) || ((this.maxRows > 0) && (paramInt > this.maxRows)))
/*      */     {
/*      */ 
/*      */ 
/* 4638 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 325);
/* 4639 */       localSQLException.fillInStackTrace();
/* 4640 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 4644 */     this.pageSize = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SyncProvider getSyncProvider()
/*      */     throws SQLException
/*      */   {
/* 4662 */     return this.syncProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSyncProvider(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4680 */     this.syncProvider = SyncFactory.getInstance(paramString);
/* 4681 */     this.reader = this.syncProvider.getRowSetReader();
/* 4682 */     this.writer = this.syncProvider.getRowSetWriter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTableName()
/*      */     throws SQLException
/*      */   {
/* 4702 */     return this.tableName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTableName(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4721 */     this.tableName = paramString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CachedRowSet createCopyNoConstraints()
/*      */     throws SQLException
/*      */   {
/* 4749 */     OracleCachedRowSet localOracleCachedRowSet = (OracleCachedRowSet)createCopy();
/*      */     
/*      */ 
/*      */ 
/* 4753 */     localOracleCachedRowSet.initializeProperties();
/*      */     
/*      */ 
/* 4756 */     localOracleCachedRowSet.listener = new Vector();
/*      */     
/*      */     try
/*      */     {
/* 4760 */       localOracleCachedRowSet.unsetMatchColumn(localOracleCachedRowSet.getMatchColumnIndexes());
/* 4761 */       localOracleCachedRowSet.unsetMatchColumn(localOracleCachedRowSet.getMatchColumnNames());
/*      */     }
/*      */     catch (SQLException localSQLException) {}
/*      */     
/*      */ 
/*      */ 
/* 4767 */     return localOracleCachedRowSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CachedRowSet createCopySchema()
/*      */     throws SQLException
/*      */   {
/* 4790 */     OracleCachedRowSet localOracleCachedRowSet = (OracleCachedRowSet)createCopy();
/*      */     
/*      */ 
/* 4793 */     localOracleCachedRowSet.rows = null;
/* 4794 */     localOracleCachedRowSet.rowCount = 0;
/* 4795 */     localOracleCachedRowSet.currentPage = 0;
/*      */     
/* 4797 */     return localOracleCachedRowSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean columnUpdated(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4816 */     if (this.insertRowFlag)
/*      */     {
/*      */ 
/* 4819 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 326);
/* 4820 */       localSQLException.fillInStackTrace();
/* 4821 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 4825 */     return getCurrentRow().isColumnChanged(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean columnUpdated(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4844 */     return columnUpdated(getColumnIndex(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void execute(Connection paramConnection)
/*      */     throws SQLException
/*      */   {
/* 4876 */     this.connection = paramConnection;
/* 4877 */     execute();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void commit()
/*      */     throws SQLException
/*      */   {
/* 4905 */     getConnectionInternal().commit();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLException
/*      */   {
/* 4925 */     getConnectionInternal().rollback();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rollback(Savepoint paramSavepoint)
/*      */     throws SQLException
/*      */   {
/* 4948 */     Connection localConnection = getConnectionInternal();
/* 4949 */     boolean bool = localConnection.getAutoCommit();
/*      */     try
/*      */     {
/* 4952 */       localConnection.setAutoCommit(false);
/* 4953 */       localConnection.rollback(paramSavepoint);
/*      */     }
/*      */     finally {
/* 4956 */       localConnection.setAutoCommit(bool);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void oracleRollback(OracleSavepoint paramOracleSavepoint)
/*      */     throws SQLException
/*      */   {
/* 4982 */     ((OracleConnection)getConnectionInternal()).oracleRollback(paramOracleSavepoint);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOriginalRow()
/*      */     throws SQLException
/*      */   {
/* 5004 */     if (this.insertRowFlag)
/*      */     {
/*      */ 
/* 5007 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 327);
/* 5008 */       localSQLException.fillInStackTrace();
/* 5009 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5014 */     setOriginalRowInternal(this.presentRow);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/* 5029 */     return this.rowCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nextPage()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5050 */     if ((this.fetchDirection == 1001) && (this.resultSet != null) && (this.resultSet.getType() == 1003))
/*      */     {
/*      */ 
/* 5053 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 328);
/* 5054 */       localSQLException.fillInStackTrace();
/* 5055 */       throw localSQLException;
/*      */     }
/*      */     
/* 5058 */     if ((this.rows.size() == 0) && (!this.isPopulateDone))
/*      */     {
/* 5060 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 329);
/* 5061 */       localSQLException.fillInStackTrace();
/* 5062 */       throw localSQLException;
/*      */     }
/*      */     
/* 5065 */     if (((isExecuteCalled()) || (this.isPopulateDone)) && (this.rowCount < this.pageSize)) {
/* 5066 */       return false;
/*      */     }
/* 5068 */     if (isExecuteCalled())
/*      */     {
/* 5070 */       this.currentPage += 1;
/* 5071 */       execute();
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 5076 */       populate(this.resultSet);
/* 5077 */       this.currentPage += 1;
/*      */     }
/*      */     
/* 5080 */     return !this.isPopulateDone;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean previousPage()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5101 */     if ((this.resultSet != null) && (this.resultSet.getType() == 1003))
/*      */     {
/* 5103 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 328);
/* 5104 */       localSQLException.fillInStackTrace();
/* 5105 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 5109 */     if ((this.rows.size() == 0) && (!this.isPopulateDone))
/*      */     {
/* 5111 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 329);
/* 5112 */       localSQLException.fillInStackTrace();
/* 5113 */       throw localSQLException;
/*      */     }
/*      */     
/* 5116 */     if (this.currentPage == 0) {
/* 5117 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 5121 */     if (this.fetchDirection == 1001)
/*      */     {
/* 5123 */       this.resultSet.relative(this.pageSize * 2);
/*      */     }
/*      */     else
/*      */     {
/* 5127 */       this.resultSet.relative(-2 * this.pageSize);
/*      */     }
/*      */     
/* 5130 */     populate(this.resultSet);
/*      */     
/* 5132 */     if (this.currentPage > 0)
/*      */     {
/* 5134 */       this.currentPage -= 1;
/*      */     }
/*      */     
/* 5137 */     return this.currentPage != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void rowSetPopulated(RowSetEvent paramRowSetEvent, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5146 */     if ((paramInt <= 0) || (paramInt < this.fetchSize))
/*      */     {
/*      */ 
/* 5149 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 330);
/* 5150 */       localSQLException.fillInStackTrace();
/* 5151 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 5155 */     if (this.rowCount % paramInt == 0)
/*      */     {
/* 5157 */       this.rowsetEvent = new RowSetEvent(this);
/* 5158 */       notifyRowSetChanged();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowSetWarning getRowSetWarnings()
/*      */     throws SQLException
/*      */   {
/* 5169 */     return this.rowsetWarning;
/*      */   }
/*      */   
/*      */ 
/*      */   public void populate(ResultSet paramResultSet, int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException1;
/*      */     
/* 5178 */     if (paramInt < 0)
/*      */     {
/* 5180 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 331);
/* 5181 */       localSQLException1.fillInStackTrace();
/* 5182 */       throw localSQLException1;
/*      */     }
/*      */     
/* 5185 */     if (paramResultSet == null)
/*      */     {
/* 5187 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 332);
/* 5188 */       localSQLException1.fillInStackTrace();
/* 5189 */       throw localSQLException1;
/*      */     }
/*      */     
/* 5192 */     int i = paramResultSet.getType();
/*      */     
/* 5194 */     if (i == 1003)
/*      */     {
/* 5196 */       int j = 0;
/* 5197 */       int k = 0;
/* 5198 */       while (j < paramInt)
/*      */       {
/* 5200 */         if (!paramResultSet.next())
/*      */         {
/* 5202 */           k = 1;
/* 5203 */           break;
/*      */         }
/* 5205 */         j++;
/*      */       }
/*      */       
/* 5208 */       if ((j < paramInt) && (paramInt > 0) && (k != 0))
/*      */       {
/* 5210 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 333);
/* 5211 */         localSQLException2.fillInStackTrace();
/* 5212 */         throw localSQLException2;
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 5217 */     else if (paramInt == 0) {
/* 5218 */       paramResultSet.beforeFirst();
/*      */     } else {
/* 5220 */       paramResultSet.absolute(paramInt);
/*      */     }
/*      */     
/* 5223 */     populate(paramResultSet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void undoDelete()
/*      */     throws SQLException
/*      */   {
/* 5233 */     cancelRowDelete();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void undoInsert()
/*      */     throws SQLException
/*      */   {
/* 5243 */     cancelRowInsert();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void undoUpdate()
/*      */     throws SQLException
/*      */   {
/* 5253 */     cancelRowUpdates();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5263 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/rowset/OracleCachedRowSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */