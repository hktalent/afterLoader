/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet.AuthorizationIndicator;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleResultSetImpl
/*      */   extends BaseResultSet
/*      */ {
/*      */   PhysicalConnection connection;
/*      */   OracleStatement statement;
/*      */   boolean explicitly_closed;
/*      */   boolean m_emptyRset;
/*   64 */   boolean isServerCursorPeeked = false;
/*      */   
/*      */ 
/*      */   OracleResultSetImpl(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement)
/*      */     throws SQLException
/*      */   {
/*   70 */     this.connection = paramPhysicalConnection;
/*   71 */     this.statement = paramOracleStatement;
/*   72 */     this.close_statement_on_close = false;
/*   73 */     this.explicitly_closed = false;
/*   74 */     this.m_emptyRset = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/*   84 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*   87 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/*   88 */       localSQLException.fillInStackTrace();
/*   89 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  101 */     synchronized (this.connection)
/*      */     {
/*  103 */       internal_close(false);
/*  104 */       this.statement.totalRowsVisited = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  111 */       this.statement.closeCursorOnPlainStatement();
/*      */       
/*      */ 
/*  114 */       if (this.close_statement_on_close)
/*      */       {
/*      */         try
/*      */         {
/*  118 */           this.statement.close();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  125 */       this.explicitly_closed = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  132 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException;
/*  135 */       if (this.explicitly_closed)
/*      */       {
/*  137 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "wasNull");
/*  138 */         localSQLException.fillInStackTrace();
/*  139 */         throw localSQLException;
/*      */       }
/*      */       
/*  142 */       if (this.statement.closed)
/*      */       {
/*  144 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "wasNull");
/*  145 */         localSQLException.fillInStackTrace();
/*  146 */         throw localSQLException;
/*      */       }
/*      */       
/*  149 */       return this.statement.wasNullValue();
/*      */     }
/*      */   }
/*      */   
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  156 */     synchronized (this.connection) {
/*      */       SQLException localSQLException;
/*  158 */       if (this.explicitly_closed)
/*      */       {
/*  160 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
/*  161 */         localSQLException.fillInStackTrace();
/*  162 */         throw localSQLException;
/*      */       }
/*      */       
/*  165 */       if (this.statement.closed)
/*      */       {
/*  167 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getMetaData");
/*  168 */         localSQLException.fillInStackTrace();
/*  169 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  175 */       if (!this.statement.isOpen)
/*      */       {
/*  177 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144, "getMetaData");
/*  178 */         localSQLException.fillInStackTrace();
/*  179 */         throw localSQLException;
/*      */       }
/*      */       
/*  182 */       return new OracleResultSetMetaData(this.connection, this.statement);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Statement getStatement()
/*      */     throws SQLException
/*      */   {
/*  190 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*  194 */       return this.statement.wrapper == null ? this.statement : this.statement.wrapper;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   OracleStatement getOracleStatement()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 3	oracle/jdbc/driver/OracleResultSetImpl:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 4	oracle/jdbc/driver/OracleResultSetImpl:statement	Loracle/jdbc/driver/OracleStatement;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #205	-> byte code offset #0
/*      */     //   Java source line #207	-> byte code offset #7
/*      */     //   Java source line #209	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleResultSetImpl
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/*  226 */     synchronized (this.connection)
/*      */     {
/*  228 */       boolean bool = true;
/*      */       
/*  230 */       this.isServerCursorPeeked = true;
/*      */       
/*      */ 
/*  233 */       PhysicalConnection localPhysicalConnection = this.statement.connection;
/*      */       SQLException localSQLException;
/*  235 */       if (this.explicitly_closed)
/*      */       {
/*  237 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
/*  238 */         localSQLException.fillInStackTrace();
/*  239 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  244 */       if ((localPhysicalConnection == null) || (localPhysicalConnection.lifecycle != 1))
/*      */       {
/*  246 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "next");
/*  247 */         localSQLException.fillInStackTrace();
/*  248 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  253 */       if (this.statement.closed)
/*      */       {
/*  255 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "next");
/*  256 */         localSQLException.fillInStackTrace();
/*  257 */         throw localSQLException;
/*      */       }
/*      */       
/*  260 */       if (this.statement.sqlKind.isPlsqlOrCall())
/*      */       {
/*  262 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 166, "next");
/*  263 */         localSQLException.fillInStackTrace();
/*  264 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  269 */       if (this.closed) {
/*  270 */         return false;
/*      */       }
/*  272 */       this.statement.currentRow += 1;
/*  273 */       this.statement.totalRowsVisited += 1;
/*      */       
/*  275 */       if ((this.statement.maxRows != 0) && (this.statement.totalRowsVisited > this.statement.maxRows))
/*      */       {
/*      */ 
/*  278 */         internal_close(false);
/*  279 */         this.statement.currentRow -= 1;
/*  280 */         this.statement.totalRowsVisited = 0;
/*      */         
/*  282 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 275);
/*      */         
/*  284 */         return false;
/*      */       }
/*      */       
/*  287 */       if (this.statement.currentRow >= this.statement.validRows) {
/*  288 */         bool = close_or_fetch_from_next(false);
/*      */       }
/*  290 */       if ((bool) && (localPhysicalConnection.useFetchSizeWithLongColumn)) {
/*  291 */         this.statement.reopenStreams();
/*      */       }
/*  293 */       if (!bool)
/*      */       {
/*  295 */         this.statement.currentRow -= 1;
/*  296 */         this.statement.totalRowsVisited = 0;
/*      */       }
/*      */       
/*  299 */       return bool;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean close_or_fetch_from_next(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  310 */     if (paramBoolean)
/*      */     {
/*  312 */       internal_close(false);
/*      */       
/*  314 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  321 */     if (this.statement.gotLastBatch)
/*      */     {
/*  323 */       internal_close(false);
/*      */       
/*  325 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  332 */     this.statement.check_row_prefetch_changed();
/*      */     
/*  334 */     PhysicalConnection localPhysicalConnection = this.statement.connection;
/*      */     
/*  336 */     if (localPhysicalConnection.protocolId == 3) {
/*  337 */       this.sqlWarning = null;
/*      */     }
/*      */     else
/*      */     {
/*  341 */       if (this.statement.streamList != null)
/*      */       {
/*      */ 
/*      */ 
/*  345 */         while (this.statement.nextStream != null)
/*      */         {
/*      */           try
/*      */           {
/*  349 */             this.statement.nextStream.close();
/*      */ 
/*      */           }
/*      */           catch (IOException localIOException)
/*      */           {
/*  354 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  355 */             localSQLException.fillInStackTrace();
/*  356 */             throw localSQLException;
/*      */           }
/*      */           
/*      */ 
/*  360 */           this.statement.nextStream = this.statement.nextStream.nextStream;
/*      */         }
/*      */       }
/*      */       
/*  364 */       clearWarnings();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  373 */       localPhysicalConnection.registerHeartbeat();
/*      */       
/*  375 */       localPhysicalConnection.needLine();
/*      */     }
/*      */     
/*      */ 
/*  379 */     synchronized (localPhysicalConnection)
/*      */     {
/*      */       try
/*      */       {
/*  383 */         this.statement.cancelLock.enterExecuting();
/*  384 */         this.statement.fetch();
/*      */       }
/*      */       finally {
/*  387 */         this.statement.cancelLock.exitExecuting();
/*      */       }
/*      */     }
/*      */     
/*  391 */     if (this.statement.validRows == 0)
/*      */     {
/*  393 */       internal_close(false);
/*      */       
/*  395 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  399 */     this.statement.currentRow = 0;
/*      */     
/*  401 */     this.statement.checkValidRowsStatus();
/*      */     
/*  403 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*  415 */     if (this.explicitly_closed)
/*      */     {
/*  417 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  418 */       localSQLException.fillInStackTrace();
/*  419 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  423 */     if ((this.statement.connection.protocolId == 3) && (this.statement.serverCursor))
/*      */     {
/*  425 */       localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  426 */       localSQLException.fillInStackTrace();
/*  427 */       throw localSQLException;
/*      */     }
/*      */     
/*  430 */     return (!isEmptyResultSet()) && (this.statement.currentRow == -1) && (!this.closed);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  437 */     if (this.explicitly_closed)
/*      */     {
/*  439 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  440 */       localSQLException.fillInStackTrace();
/*  441 */       throw localSQLException;
/*      */     }
/*      */     
/*  444 */     return (!isEmptyResultSet()) && (this.closed);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  451 */     if (this.explicitly_closed)
/*      */     {
/*  453 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  454 */       localSQLException.fillInStackTrace();
/*  455 */       throw localSQLException;
/*      */     }
/*  457 */     return getRow() == 1;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  464 */     if (this.explicitly_closed)
/*      */     {
/*  466 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  467 */       localSQLException.fillInStackTrace();
/*  468 */       throw localSQLException;
/*      */     }
/*      */     
/*  471 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "isLast");
/*  472 */     localSQLException.fillInStackTrace();
/*  473 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/*  481 */     if (this.explicitly_closed)
/*      */     {
/*  483 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  484 */       localSQLException.fillInStackTrace();
/*  485 */       throw localSQLException;
/*      */     }
/*  487 */     return this.statement.totalRowsVisited;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 3	oracle/jdbc/driver/OracleResultSetImpl:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 62	oracle/jdbc/driver/OracleResultSetImpl:getARRAY	(I)Loracle/sql/ARRAY;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #505	-> byte code offset #0
/*      */     //   Java source line #507	-> byte code offset #7
/*      */     //   Java source line #509	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleResultSetImpl
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  515 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  518 */       if (this.closed)
/*      */       {
/*  520 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  521 */         localSQLException1.fillInStackTrace();
/*  522 */         throw localSQLException1;
/*      */       }
/*      */       
/*  525 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  527 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  528 */         localSQLException1.fillInStackTrace();
/*  529 */         throw localSQLException1;
/*      */       }
/*      */       
/*  532 */       int i = this.statement.currentRow;
/*      */       
/*  534 */       if (i < 0)
/*      */       {
/*  536 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  537 */         localSQLException2.fillInStackTrace();
/*  538 */         throw localSQLException2;
/*      */       }
/*      */       
/*  541 */       this.statement.lastIndex = paramInt;
/*      */       
/*  543 */       if (this.statement.streamList != null)
/*      */       {
/*  545 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  548 */       return this.statement.accessors[(paramInt - 1)].getBigDecimal(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  556 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  559 */       if (this.closed)
/*      */       {
/*  561 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  562 */         localSQLException1.fillInStackTrace();
/*  563 */         throw localSQLException1;
/*      */       }
/*      */       
/*  566 */       if ((paramInt1 <= 0) || (paramInt1 > this.statement.numberOfDefinePositions))
/*      */       {
/*  568 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  569 */         localSQLException1.fillInStackTrace();
/*  570 */         throw localSQLException1;
/*      */       }
/*      */       
/*  573 */       int i = this.statement.currentRow;
/*      */       
/*  575 */       if (i < 0)
/*      */       {
/*  577 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  578 */         localSQLException2.fillInStackTrace();
/*  579 */         throw localSQLException2;
/*      */       }
/*      */       
/*  582 */       this.statement.lastIndex = paramInt1;
/*      */       
/*  584 */       if (this.statement.streamList != null)
/*      */       {
/*  586 */         this.statement.closeUsedStreams(paramInt1);
/*      */       }
/*      */       
/*  589 */       return this.statement.accessors[(paramInt1 - 1)].getBigDecimal(i, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 3	oracle/jdbc/driver/OracleResultSetImpl:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 69	oracle/jdbc/driver/OracleResultSetImpl:getBLOB	(I)Loracle/sql/BLOB;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #597	-> byte code offset #0
/*      */     //   Java source line #599	-> byte code offset #7
/*      */     //   Java source line #601	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleResultSetImpl
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  607 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  610 */       if (this.closed)
/*      */       {
/*  612 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  613 */         localSQLException1.fillInStackTrace();
/*  614 */         throw localSQLException1;
/*      */       }
/*      */       
/*  617 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  619 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  620 */         localSQLException1.fillInStackTrace();
/*  621 */         throw localSQLException1;
/*      */       }
/*      */       
/*  624 */       int i = this.statement.currentRow;
/*      */       
/*  626 */       if (i < 0)
/*      */       {
/*  628 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  629 */         localSQLException2.fillInStackTrace();
/*  630 */         throw localSQLException2;
/*      */       }
/*      */       
/*  633 */       this.statement.lastIndex = paramInt;
/*      */       
/*  635 */       if (this.statement.streamList != null)
/*      */       {
/*  637 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  640 */       return this.statement.accessors[(paramInt - 1)].getBoolean(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  648 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  651 */       if (this.closed)
/*      */       {
/*  653 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  654 */         localSQLException1.fillInStackTrace();
/*  655 */         throw localSQLException1;
/*      */       }
/*      */       
/*  658 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  660 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  661 */         localSQLException1.fillInStackTrace();
/*  662 */         throw localSQLException1;
/*      */       }
/*      */       
/*  665 */       int i = this.statement.currentRow;
/*      */       
/*  667 */       if (i < 0)
/*      */       {
/*  669 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  670 */         localSQLException2.fillInStackTrace();
/*  671 */         throw localSQLException2;
/*      */       }
/*      */       
/*  674 */       this.statement.lastIndex = paramInt;
/*      */       
/*  676 */       if (this.statement.streamList != null)
/*      */       {
/*  678 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  681 */       return this.statement.accessors[(paramInt - 1)].getByte(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  689 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  692 */       if (this.closed)
/*      */       {
/*  694 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  695 */         localSQLException1.fillInStackTrace();
/*  696 */         throw localSQLException1;
/*      */       }
/*      */       
/*  699 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  701 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  702 */         localSQLException1.fillInStackTrace();
/*  703 */         throw localSQLException1;
/*      */       }
/*      */       
/*  706 */       int i = this.statement.currentRow;
/*      */       
/*  708 */       if (i < 0)
/*      */       {
/*  710 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  711 */         localSQLException2.fillInStackTrace();
/*  712 */         throw localSQLException2;
/*      */       }
/*      */       
/*  715 */       this.statement.lastIndex = paramInt;
/*      */       
/*  717 */       if (this.statement.streamList != null)
/*      */       {
/*  719 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  722 */       return this.statement.accessors[(paramInt - 1)].getBytes(i);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 3	oracle/jdbc/driver/OracleResultSetImpl:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 73	oracle/jdbc/driver/OracleResultSetImpl:getCLOB	(I)Loracle/sql/CLOB;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #730	-> byte code offset #0
/*      */     //   Java source line #732	-> byte code offset #7
/*      */     //   Java source line #734	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleResultSetImpl
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  740 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  743 */       if (this.closed)
/*      */       {
/*  745 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  746 */         localSQLException1.fillInStackTrace();
/*  747 */         throw localSQLException1;
/*      */       }
/*      */       
/*  750 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  752 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  753 */         localSQLException1.fillInStackTrace();
/*  754 */         throw localSQLException1;
/*      */       }
/*      */       
/*  757 */       int i = this.statement.currentRow;
/*      */       
/*  759 */       if (i < 0)
/*      */       {
/*  761 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  762 */         localSQLException2.fillInStackTrace();
/*  763 */         throw localSQLException2;
/*      */       }
/*      */       
/*  766 */       this.statement.lastIndex = paramInt;
/*      */       
/*  768 */       if (this.statement.streamList != null)
/*      */       {
/*  770 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  773 */       return this.statement.accessors[(paramInt - 1)].getDate(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/*  781 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  784 */       if (this.closed)
/*      */       {
/*  786 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  787 */         localSQLException1.fillInStackTrace();
/*  788 */         throw localSQLException1;
/*      */       }
/*      */       
/*  791 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  793 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  794 */         localSQLException1.fillInStackTrace();
/*  795 */         throw localSQLException1;
/*      */       }
/*      */       
/*  798 */       int i = this.statement.currentRow;
/*      */       
/*  800 */       if (i < 0)
/*      */       {
/*  802 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  803 */         localSQLException2.fillInStackTrace();
/*  804 */         throw localSQLException2;
/*      */       }
/*      */       
/*  807 */       this.statement.lastIndex = paramInt;
/*      */       
/*  809 */       if (this.statement.streamList != null)
/*      */       {
/*  811 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  814 */       return this.statement.accessors[(paramInt - 1)].getDate(i, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  822 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  825 */       if (this.closed)
/*      */       {
/*  827 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  828 */         localSQLException1.fillInStackTrace();
/*  829 */         throw localSQLException1;
/*      */       }
/*      */       
/*  832 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  834 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  835 */         localSQLException1.fillInStackTrace();
/*  836 */         throw localSQLException1;
/*      */       }
/*      */       
/*  839 */       int i = this.statement.currentRow;
/*      */       
/*  841 */       if (i < 0)
/*      */       {
/*  843 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  844 */         localSQLException2.fillInStackTrace();
/*  845 */         throw localSQLException2;
/*      */       }
/*      */       
/*  848 */       this.statement.lastIndex = paramInt;
/*      */       
/*  850 */       if (this.statement.streamList != null)
/*      */       {
/*  852 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  855 */       return this.statement.accessors[(paramInt - 1)].getDouble(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  863 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  866 */       if (this.closed)
/*      */       {
/*  868 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  869 */         localSQLException1.fillInStackTrace();
/*  870 */         throw localSQLException1;
/*      */       }
/*      */       
/*  873 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  875 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  876 */         localSQLException1.fillInStackTrace();
/*  877 */         throw localSQLException1;
/*      */       }
/*      */       
/*  880 */       int i = this.statement.currentRow;
/*      */       
/*  882 */       if (i < 0)
/*      */       {
/*  884 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  885 */         localSQLException2.fillInStackTrace();
/*  886 */         throw localSQLException2;
/*      */       }
/*      */       
/*  889 */       this.statement.lastIndex = paramInt;
/*      */       
/*  891 */       if (this.statement.streamList != null)
/*      */       {
/*  893 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  896 */       return this.statement.accessors[(paramInt - 1)].getFloat(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  909 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  912 */       if (this.closed)
/*      */       {
/*  914 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  915 */         localSQLException1.fillInStackTrace();
/*  916 */         throw localSQLException1;
/*      */       }
/*      */       
/*  919 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  921 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  922 */         localSQLException1.fillInStackTrace();
/*  923 */         throw localSQLException1;
/*      */       }
/*      */       
/*  926 */       int i = this.statement.currentRow;
/*      */       
/*  928 */       if (i < 0)
/*      */       {
/*  930 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  931 */         localSQLException2.fillInStackTrace();
/*  932 */         throw localSQLException2;
/*      */       }
/*      */       
/*  935 */       this.statement.lastIndex = paramInt;
/*      */       
/*  937 */       if (this.statement.streamList != null)
/*      */       {
/*  939 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  942 */       return this.statement.accessors[(paramInt - 1)].getInt(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  952 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  955 */       if (this.closed)
/*      */       {
/*  957 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  958 */         localSQLException1.fillInStackTrace();
/*  959 */         throw localSQLException1;
/*      */       }
/*      */       
/*  962 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/*  964 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  965 */         localSQLException1.fillInStackTrace();
/*  966 */         throw localSQLException1;
/*      */       }
/*      */       
/*  969 */       int i = this.statement.currentRow;
/*      */       
/*  971 */       if (i < 0)
/*      */       {
/*  973 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  974 */         localSQLException2.fillInStackTrace();
/*  975 */         throw localSQLException2;
/*      */       }
/*      */       
/*  978 */       this.statement.lastIndex = paramInt;
/*      */       
/*  980 */       if (this.statement.streamList != null)
/*      */       {
/*  982 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  985 */       return this.statement.accessors[(paramInt - 1)].getLong(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  993 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/*  996 */       if (this.closed)
/*      */       {
/*  998 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  999 */         localSQLException1.fillInStackTrace();
/* 1000 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1003 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1005 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1006 */         localSQLException1.fillInStackTrace();
/* 1007 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1010 */       int i = this.statement.currentRow;
/*      */       
/* 1012 */       if (i < 0)
/*      */       {
/* 1014 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1015 */         localSQLException2.fillInStackTrace();
/* 1016 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1019 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1021 */       if (this.statement.streamList != null)
/*      */       {
/* 1023 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1026 */       return this.statement.accessors[(paramInt - 1)].getObject(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1034 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1037 */       if (this.closed)
/*      */       {
/* 1039 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1040 */         localSQLException1.fillInStackTrace();
/* 1041 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1044 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1046 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1047 */         localSQLException1.fillInStackTrace();
/* 1048 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1051 */       int i = this.statement.currentRow;
/*      */       
/* 1053 */       if (i < 0)
/*      */       {
/* 1055 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1056 */         localSQLException2.fillInStackTrace();
/* 1057 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1060 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1062 */       if (this.statement.streamList != null)
/*      */       {
/* 1064 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1067 */       return this.statement.accessors[(paramInt - 1)].getObject(i, paramMap);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 3	oracle/jdbc/driver/OracleResultSetImpl:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 82	oracle/jdbc/driver/OracleResultSetImpl:getREF	(I)Loracle/sql/REF;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1075	-> byte code offset #0
/*      */     //   Java source line #1077	-> byte code offset #7
/*      */     //   Java source line #1079	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleResultSetImpl
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1085 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1088 */       if (this.closed)
/*      */       {
/* 1090 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1091 */         localSQLException1.fillInStackTrace();
/* 1092 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1095 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1097 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1098 */         localSQLException1.fillInStackTrace();
/* 1099 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1102 */       int i = this.statement.currentRow;
/*      */       
/* 1104 */       if (i < 0)
/*      */       {
/* 1106 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1107 */         localSQLException2.fillInStackTrace();
/* 1108 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1111 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1113 */       if (this.statement.streamList != null)
/*      */       {
/* 1115 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1118 */       return this.statement.accessors[(paramInt - 1)].getShort(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1131 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1134 */       if (this.closed)
/*      */       {
/* 1136 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1137 */         localSQLException1.fillInStackTrace();
/* 1138 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1141 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1143 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1144 */         localSQLException1.fillInStackTrace();
/* 1145 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1148 */       int i = this.statement.currentRow;
/*      */       
/* 1150 */       if (i < 0)
/*      */       {
/* 1152 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1153 */         localSQLException2.fillInStackTrace();
/* 1154 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1157 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1159 */       if (this.statement.streamList != null)
/*      */       {
/* 1161 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1164 */       return this.statement.accessors[(paramInt - 1)].getString(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1174 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1177 */       if (this.closed)
/*      */       {
/* 1179 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1180 */         localSQLException1.fillInStackTrace();
/* 1181 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1184 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1186 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1187 */         localSQLException1.fillInStackTrace();
/* 1188 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1191 */       int i = this.statement.currentRow;
/*      */       
/* 1193 */       if (i < 0)
/*      */       {
/* 1195 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1196 */         localSQLException2.fillInStackTrace();
/* 1197 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1200 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1202 */       if (this.statement.streamList != null)
/*      */       {
/* 1204 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1207 */       return this.statement.accessors[(paramInt - 1)].getTime(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1215 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1218 */       if (this.closed)
/*      */       {
/* 1220 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1221 */         localSQLException1.fillInStackTrace();
/* 1222 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1225 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1227 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1228 */         localSQLException1.fillInStackTrace();
/* 1229 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1232 */       int i = this.statement.currentRow;
/*      */       
/* 1234 */       if (i < 0)
/*      */       {
/* 1236 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1237 */         localSQLException2.fillInStackTrace();
/* 1238 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1241 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1243 */       if (this.statement.streamList != null)
/*      */       {
/* 1245 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1248 */       return this.statement.accessors[(paramInt - 1)].getTime(i, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1256 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1259 */       if (this.closed)
/*      */       {
/* 1261 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1262 */         localSQLException1.fillInStackTrace();
/* 1263 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1266 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1268 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1269 */         localSQLException1.fillInStackTrace();
/* 1270 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1273 */       int i = this.statement.currentRow;
/*      */       
/* 1275 */       if (i < 0)
/*      */       {
/* 1277 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1278 */         localSQLException2.fillInStackTrace();
/* 1279 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1282 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1284 */       if (this.statement.streamList != null)
/*      */       {
/* 1286 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1289 */       return this.statement.accessors[(paramInt - 1)].getTimestamp(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1297 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1300 */       if (this.closed)
/*      */       {
/* 1302 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1303 */         localSQLException1.fillInStackTrace();
/* 1304 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1307 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1309 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1310 */         localSQLException1.fillInStackTrace();
/* 1311 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1314 */       int i = this.statement.currentRow;
/*      */       
/* 1316 */       if (i < 0)
/*      */       {
/* 1318 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1319 */         localSQLException2.fillInStackTrace();
/* 1320 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1323 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1325 */       if (this.statement.streamList != null)
/*      */       {
/* 1327 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1330 */       return this.statement.accessors[(paramInt - 1)].getTimestamp(i, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1338 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1341 */       if (this.closed)
/*      */       {
/* 1343 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1344 */         localSQLException1.fillInStackTrace();
/* 1345 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1348 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1350 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1351 */         localSQLException1.fillInStackTrace();
/* 1352 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1355 */       int i = this.statement.currentRow;
/*      */       
/* 1357 */       if (i < 0)
/*      */       {
/* 1359 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1360 */         localSQLException2.fillInStackTrace();
/* 1361 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1364 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1366 */       if (this.statement.streamList != null)
/*      */       {
/* 1368 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1371 */       return this.statement.accessors[(paramInt - 1)].getURL(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ARRAY getARRAY(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1379 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1382 */       if (this.closed)
/*      */       {
/* 1384 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1385 */         localSQLException1.fillInStackTrace();
/* 1386 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1389 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1391 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1392 */         localSQLException1.fillInStackTrace();
/* 1393 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1396 */       int i = this.statement.currentRow;
/*      */       
/* 1398 */       if (i < 0)
/*      */       {
/* 1400 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1401 */         localSQLException2.fillInStackTrace();
/* 1402 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1405 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1407 */       if (this.statement.streamList != null)
/*      */       {
/* 1409 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1412 */       return this.statement.accessors[(paramInt - 1)].getARRAY(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BFILE getBFILE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1420 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1423 */       if (this.closed)
/*      */       {
/* 1425 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1426 */         localSQLException1.fillInStackTrace();
/* 1427 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1430 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1432 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1433 */         localSQLException1.fillInStackTrace();
/* 1434 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1437 */       int i = this.statement.currentRow;
/*      */       
/* 1439 */       if (i < 0)
/*      */       {
/* 1441 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1442 */         localSQLException2.fillInStackTrace();
/* 1443 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1446 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1448 */       if (this.statement.streamList != null)
/*      */       {
/* 1450 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1453 */       return this.statement.accessors[(paramInt - 1)].getBFILE(i);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public BFILE getBfile(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 3	oracle/jdbc/driver/OracleResultSetImpl:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 92	oracle/jdbc/driver/OracleResultSetImpl:getBFILE	(I)Loracle/sql/BFILE;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1461	-> byte code offset #0
/*      */     //   Java source line #1463	-> byte code offset #7
/*      */     //   Java source line #1465	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleResultSetImpl
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public BLOB getBLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1471 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1474 */       if (this.closed)
/*      */       {
/* 1476 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1477 */         localSQLException1.fillInStackTrace();
/* 1478 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1481 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1483 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1484 */         localSQLException1.fillInStackTrace();
/* 1485 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1488 */       int i = this.statement.currentRow;
/*      */       
/* 1490 */       if (i < 0)
/*      */       {
/* 1492 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1493 */         localSQLException2.fillInStackTrace();
/* 1494 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1497 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1499 */       if (this.statement.streamList != null)
/*      */       {
/* 1501 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1504 */       return this.statement.accessors[(paramInt - 1)].getBLOB(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CHAR getCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1512 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1515 */       if (this.closed)
/*      */       {
/* 1517 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1518 */         localSQLException1.fillInStackTrace();
/* 1519 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1522 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1524 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1525 */         localSQLException1.fillInStackTrace();
/* 1526 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1529 */       int i = this.statement.currentRow;
/*      */       
/* 1531 */       if (i < 0)
/*      */       {
/* 1533 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1534 */         localSQLException2.fillInStackTrace();
/* 1535 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1538 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1540 */       if (this.statement.streamList != null)
/*      */       {
/* 1542 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1545 */       return this.statement.accessors[(paramInt - 1)].getCHAR(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CLOB getCLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1553 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1556 */       if (this.closed)
/*      */       {
/* 1558 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1559 */         localSQLException1.fillInStackTrace();
/* 1560 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1563 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1565 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1566 */         localSQLException1.fillInStackTrace();
/* 1567 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1570 */       int i = this.statement.currentRow;
/*      */       
/* 1572 */       if (i < 0)
/*      */       {
/* 1574 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1575 */         localSQLException2.fillInStackTrace();
/* 1576 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1579 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1581 */       if (this.statement.streamList != null)
/*      */       {
/* 1583 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1586 */       return this.statement.accessors[(paramInt - 1)].getCLOB(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getCursor(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1594 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1597 */       if (this.closed)
/*      */       {
/* 1599 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1600 */         localSQLException1.fillInStackTrace();
/* 1601 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1604 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1606 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1607 */         localSQLException1.fillInStackTrace();
/* 1608 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1611 */       int i = this.statement.currentRow;
/*      */       
/* 1613 */       if (i < 0)
/*      */       {
/* 1615 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1616 */         localSQLException2.fillInStackTrace();
/* 1617 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1620 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1622 */       if (this.statement.streamList != null)
/*      */       {
/* 1624 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1627 */       return this.statement.accessors[(paramInt - 1)].getCursor(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/* 1635 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1638 */       if (this.closed)
/*      */       {
/* 1640 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1641 */         localSQLException1.fillInStackTrace();
/* 1642 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1645 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1647 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1648 */         localSQLException1.fillInStackTrace();
/* 1649 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1652 */       int i = this.statement.currentRow;
/*      */       
/* 1654 */       if (i < 0)
/*      */       {
/* 1656 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1657 */         localSQLException2.fillInStackTrace();
/* 1658 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1661 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1663 */       if (this.statement.streamList != null)
/*      */       {
/* 1665 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1668 */       return this.statement.accessors[(paramInt - 1)].getCustomDatum(i, paramCustomDatumFactory);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1676 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1679 */       if (this.closed)
/*      */       {
/* 1681 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1682 */         localSQLException1.fillInStackTrace();
/* 1683 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1686 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1688 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1689 */         localSQLException1.fillInStackTrace();
/* 1690 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1693 */       int i = this.statement.currentRow;
/*      */       
/* 1695 */       if (i < 0)
/*      */       {
/* 1697 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1698 */         localSQLException2.fillInStackTrace();
/* 1699 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1702 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1704 */       if (this.statement.streamList != null)
/*      */       {
/* 1706 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1709 */       return this.statement.accessors[(paramInt - 1)].getDATE(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALDS getINTERVALDS(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1717 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1720 */       if (this.closed)
/*      */       {
/* 1722 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1723 */         localSQLException1.fillInStackTrace();
/* 1724 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1727 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1729 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1730 */         localSQLException1.fillInStackTrace();
/* 1731 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1734 */       int i = this.statement.currentRow;
/*      */       
/* 1736 */       if (i < 0)
/*      */       {
/* 1738 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1739 */         localSQLException2.fillInStackTrace();
/* 1740 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1743 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1745 */       if (this.statement.streamList != null)
/*      */       {
/* 1747 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1750 */       return this.statement.accessors[(paramInt - 1)].getINTERVALDS(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALYM getINTERVALYM(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1758 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1761 */       if (this.closed)
/*      */       {
/* 1763 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1764 */         localSQLException1.fillInStackTrace();
/* 1765 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1768 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1770 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1771 */         localSQLException1.fillInStackTrace();
/* 1772 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1775 */       int i = this.statement.currentRow;
/*      */       
/* 1777 */       if (i < 0)
/*      */       {
/* 1779 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1780 */         localSQLException2.fillInStackTrace();
/* 1781 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1784 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1786 */       if (this.statement.streamList != null)
/*      */       {
/* 1788 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1791 */       return this.statement.accessors[(paramInt - 1)].getINTERVALYM(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1799 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1802 */       if (this.closed)
/*      */       {
/* 1804 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1805 */         localSQLException1.fillInStackTrace();
/* 1806 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1809 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1811 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1812 */         localSQLException1.fillInStackTrace();
/* 1813 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1816 */       int i = this.statement.currentRow;
/*      */       
/* 1818 */       if (i < 0)
/*      */       {
/* 1820 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1821 */         localSQLException2.fillInStackTrace();
/* 1822 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1825 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1827 */       if (this.statement.streamList != null)
/*      */       {
/* 1829 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1832 */       return this.statement.accessors[(paramInt - 1)].getNUMBER(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public OPAQUE getOPAQUE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1840 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1843 */       if (this.closed)
/*      */       {
/* 1845 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1846 */         localSQLException1.fillInStackTrace();
/* 1847 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1850 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1852 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1853 */         localSQLException1.fillInStackTrace();
/* 1854 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1857 */       int i = this.statement.currentRow;
/*      */       
/* 1859 */       if (i < 0)
/*      */       {
/* 1861 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1862 */         localSQLException2.fillInStackTrace();
/* 1863 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1866 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1868 */       if (this.statement.streamList != null)
/*      */       {
/* 1870 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1873 */       return this.statement.accessors[(paramInt - 1)].getOPAQUE(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1881 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1884 */       if (this.closed)
/*      */       {
/* 1886 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1887 */         localSQLException1.fillInStackTrace();
/* 1888 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1891 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1893 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1894 */         localSQLException1.fillInStackTrace();
/* 1895 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1898 */       int i = this.statement.currentRow;
/*      */       
/* 1900 */       if (i < 0)
/*      */       {
/* 1902 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1903 */         localSQLException2.fillInStackTrace();
/* 1904 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1907 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1909 */       if (this.statement.streamList != null)
/*      */       {
/* 1911 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1914 */       return this.statement.accessors[(paramInt - 1)].getOracleObject(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/* 1922 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1925 */       if (this.closed)
/*      */       {
/* 1927 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1928 */         localSQLException1.fillInStackTrace();
/* 1929 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1932 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1934 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1935 */         localSQLException1.fillInStackTrace();
/* 1936 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1939 */       int i = this.statement.currentRow;
/*      */       
/* 1941 */       if (i < 0)
/*      */       {
/* 1943 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1944 */         localSQLException2.fillInStackTrace();
/* 1945 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1948 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1950 */       if (this.statement.streamList != null)
/*      */       {
/* 1952 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1955 */       return this.statement.accessors[(paramInt - 1)].getORAData(i, paramORADataFactory);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory)
/*      */     throws SQLException
/*      */   {
/* 1963 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 1966 */       if (this.closed)
/*      */       {
/* 1968 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1969 */         localSQLException1.fillInStackTrace();
/* 1970 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1973 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 1975 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1976 */         localSQLException1.fillInStackTrace();
/* 1977 */         throw localSQLException1;
/*      */       }
/*      */       
/* 1980 */       int i = this.statement.currentRow;
/*      */       
/* 1982 */       if (i < 0)
/*      */       {
/* 1984 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1985 */         localSQLException2.fillInStackTrace();
/* 1986 */         throw localSQLException2;
/*      */       }
/*      */       
/* 1989 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1991 */       if (this.statement.streamList != null)
/*      */       {
/* 1993 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1996 */       return this.statement.accessors[(paramInt - 1)].getObject(i, paramOracleDataFactory);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2004 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2007 */       if (this.closed)
/*      */       {
/* 2009 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2010 */         localSQLException1.fillInStackTrace();
/* 2011 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2014 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2016 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2017 */         localSQLException1.fillInStackTrace();
/* 2018 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2021 */       int i = this.statement.currentRow;
/*      */       
/* 2023 */       if (i < 0)
/*      */       {
/* 2025 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2026 */         localSQLException2.fillInStackTrace();
/* 2027 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2030 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2032 */       if (this.statement.streamList != null)
/*      */       {
/* 2034 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2037 */       return this.statement.accessors[(paramInt - 1)].getRAW(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public REF getREF(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2045 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2048 */       if (this.closed)
/*      */       {
/* 2050 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2051 */         localSQLException1.fillInStackTrace();
/* 2052 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2055 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2057 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2058 */         localSQLException1.fillInStackTrace();
/* 2059 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2062 */       int i = this.statement.currentRow;
/*      */       
/* 2064 */       if (i < 0)
/*      */       {
/* 2066 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2067 */         localSQLException2.fillInStackTrace();
/* 2068 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2071 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2073 */       if (this.statement.streamList != null)
/*      */       {
/* 2075 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2078 */       return this.statement.accessors[(paramInt - 1)].getREF(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ROWID getROWID(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2086 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2089 */       if (this.closed)
/*      */       {
/* 2091 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2092 */         localSQLException1.fillInStackTrace();
/* 2093 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2096 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2098 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2099 */         localSQLException1.fillInStackTrace();
/* 2100 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2103 */       int i = this.statement.currentRow;
/*      */       
/* 2105 */       if (i < 0)
/*      */       {
/* 2107 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2108 */         localSQLException2.fillInStackTrace();
/* 2109 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2112 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2114 */       if (this.statement.streamList != null)
/*      */       {
/* 2116 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2119 */       return this.statement.accessors[(paramInt - 1)].getROWID(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public STRUCT getSTRUCT(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2127 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2130 */       if (this.closed)
/*      */       {
/* 2132 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2133 */         localSQLException1.fillInStackTrace();
/* 2134 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2137 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2139 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2140 */         localSQLException1.fillInStackTrace();
/* 2141 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2144 */       int i = this.statement.currentRow;
/*      */       
/* 2146 */       if (i < 0)
/*      */       {
/* 2148 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2149 */         localSQLException2.fillInStackTrace();
/* 2150 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2153 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2155 */       if (this.statement.streamList != null)
/*      */       {
/* 2157 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2160 */       return this.statement.accessors[(paramInt - 1)].getSTRUCT(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2168 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2171 */       if (this.closed)
/*      */       {
/* 2173 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2174 */         localSQLException1.fillInStackTrace();
/* 2175 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2178 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2180 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2181 */         localSQLException1.fillInStackTrace();
/* 2182 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2185 */       int i = this.statement.currentRow;
/*      */       
/* 2187 */       if (i < 0)
/*      */       {
/* 2189 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2190 */         localSQLException2.fillInStackTrace();
/* 2191 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2194 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2196 */       if (this.statement.streamList != null)
/*      */       {
/* 2198 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2201 */       return this.statement.accessors[(paramInt - 1)].getTIMESTAMPLTZ(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2209 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2212 */       if (this.closed)
/*      */       {
/* 2214 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2215 */         localSQLException1.fillInStackTrace();
/* 2216 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2219 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2221 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2222 */         localSQLException1.fillInStackTrace();
/* 2223 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2226 */       int i = this.statement.currentRow;
/*      */       
/* 2228 */       if (i < 0)
/*      */       {
/* 2230 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2231 */         localSQLException2.fillInStackTrace();
/* 2232 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2235 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2237 */       if (this.statement.streamList != null)
/*      */       {
/* 2239 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2242 */       return this.statement.accessors[(paramInt - 1)].getTIMESTAMPTZ(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2250 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2253 */       if (this.closed)
/*      */       {
/* 2255 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2256 */         localSQLException1.fillInStackTrace();
/* 2257 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2260 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2262 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2263 */         localSQLException1.fillInStackTrace();
/* 2264 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2267 */       int i = this.statement.currentRow;
/*      */       
/* 2269 */       if (i < 0)
/*      */       {
/* 2271 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2272 */         localSQLException2.fillInStackTrace();
/* 2273 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2276 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2278 */       if (this.statement.streamList != null)
/*      */       {
/* 2280 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2283 */       return this.statement.accessors[(paramInt - 1)].getTIMESTAMP(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2291 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2294 */       if (this.closed)
/*      */       {
/* 2296 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2297 */         localSQLException1.fillInStackTrace();
/* 2298 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2301 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2303 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2304 */         localSQLException1.fillInStackTrace();
/* 2305 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2308 */       int i = this.statement.currentRow;
/*      */       
/* 2310 */       if (i < 0)
/*      */       {
/* 2312 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2313 */         localSQLException2.fillInStackTrace();
/* 2314 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2317 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2319 */       if (this.statement.streamList != null)
/*      */       {
/* 2321 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2324 */       return this.statement.accessors[(paramInt - 1)].getAsciiStream(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2332 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2335 */       if (this.closed)
/*      */       {
/* 2337 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2338 */         localSQLException1.fillInStackTrace();
/* 2339 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2342 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2344 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2345 */         localSQLException1.fillInStackTrace();
/* 2346 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2349 */       int i = this.statement.currentRow;
/*      */       
/* 2351 */       if (i < 0)
/*      */       {
/* 2353 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2354 */         localSQLException2.fillInStackTrace();
/* 2355 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2358 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2360 */       if (this.statement.streamList != null)
/*      */       {
/* 2362 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2365 */       return this.statement.accessors[(paramInt - 1)].getBinaryStream(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2373 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2376 */       if (this.closed)
/*      */       {
/* 2378 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2379 */         localSQLException1.fillInStackTrace();
/* 2380 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2383 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2385 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2386 */         localSQLException1.fillInStackTrace();
/* 2387 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2390 */       int i = this.statement.currentRow;
/*      */       
/* 2392 */       if (i < 0)
/*      */       {
/* 2394 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2395 */         localSQLException2.fillInStackTrace();
/* 2396 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2399 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2401 */       if (this.statement.streamList != null)
/*      */       {
/* 2403 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2406 */       return this.statement.accessors[(paramInt - 1)].getCharacterStream(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2414 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException1;
/* 2417 */       if (this.closed)
/*      */       {
/* 2419 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2420 */         localSQLException1.fillInStackTrace();
/* 2421 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2424 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2426 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2427 */         localSQLException1.fillInStackTrace();
/* 2428 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2431 */       int i = this.statement.currentRow;
/*      */       
/* 2433 */       if (i < 0)
/*      */       {
/* 2435 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2436 */         localSQLException2.fillInStackTrace();
/* 2437 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2440 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2442 */       if (this.statement.streamList != null)
/*      */       {
/* 2444 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2447 */       return this.statement.accessors[(paramInt - 1)].getUnicodeStream(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2459 */     synchronized (this.connection) {
/*      */       SQLException localSQLException1;
/* 2461 */       if (this.closed)
/*      */       {
/* 2463 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2464 */         localSQLException1.fillInStackTrace();
/* 2465 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2468 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2470 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2471 */         localSQLException1.fillInStackTrace();
/* 2472 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2475 */       int i = this.statement.currentRow;
/*      */       
/* 2477 */       if (i < 0)
/*      */       {
/* 2479 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2480 */         localSQLException2.fillInStackTrace();
/* 2481 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2484 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2486 */       if (this.statement.streamList != null)
/*      */       {
/* 2488 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/* 2490 */       return this.statement.accessors[(paramInt - 1)].getAuthorizationIndicator(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[] privateGetBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2507 */     synchronized (this.connection) {
/*      */       SQLException localSQLException1;
/* 2509 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2511 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2512 */         localSQLException1.fillInStackTrace();
/* 2513 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2516 */       if (this.closed)
/*      */       {
/* 2518 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2519 */         localSQLException1.fillInStackTrace();
/* 2520 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2523 */       if ((paramInt <= 0) || (paramInt > this.statement.numberOfDefinePositions))
/*      */       {
/* 2525 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2526 */         localSQLException1.fillInStackTrace();
/* 2527 */         throw localSQLException1;
/*      */       }
/*      */       
/* 2530 */       int i = this.statement.currentRow;
/*      */       
/* 2532 */       if (i < 0)
/*      */       {
/* 2534 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2535 */         localSQLException2.fillInStackTrace();
/* 2536 */         throw localSQLException2;
/*      */       }
/*      */       
/* 2539 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2541 */       if (this.statement.streamList != null)
/*      */       {
/* 2543 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*      */ 
/* 2547 */       return this.statement.accessors[(paramInt - 1)].privateGetBytes(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2561 */     this.statement.setPrefetchInternal(paramInt, false, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 2569 */     return this.statement.getPrefetchInternal(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void internal_close(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2580 */     if (this.closed) { return;
/*      */     }
/* 2582 */     super.close();
/*      */     
/* 2584 */     if ((this.statement.gotLastBatch) && (this.statement.validRows == 0)) {
/* 2585 */       this.m_emptyRset = true;
/*      */     }
/*      */     
/* 2588 */     PhysicalConnection localPhysicalConnection = this.statement.connection;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 2599 */       localPhysicalConnection.registerHeartbeat();
/*      */       
/*      */ 
/* 2602 */       localPhysicalConnection.needLine();
/*      */       
/* 2604 */       synchronized (localPhysicalConnection)
/*      */       {
/*      */ 
/* 2607 */         this.statement.closeQuery();
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2616 */     this.statement.endOfResultSet(paramBoolean);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int findColumn(String paramString)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 3	oracle/jdbc/driver/OracleResultSetImpl:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 4	oracle/jdbc/driver/OracleResultSetImpl:statement	Loracle/jdbc/driver/OracleStatement;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 124	oracle/jdbc/driver/OracleStatement:getColumnIndex	(Ljava/lang/String;)I
/*      */     //   15: aload_2
/*      */     //   16: monitorexit
/*      */     //   17: ireturn
/*      */     //   18: astore_3
/*      */     //   19: aload_2
/*      */     //   20: monitorexit
/*      */     //   21: aload_3
/*      */     //   22: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2623	-> byte code offset #0
/*      */     //   Java source line #2625	-> byte code offset #7
/*      */     //   Java source line #2627	-> byte code offset #18
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	23	0	this	OracleResultSetImpl
/*      */     //   0	23	1	paramString	String
/*      */     //   5	15	2	Ljava/lang/Object;	Object
/*      */     //   18	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	17	18	finally
/*      */     //   18	21	18	finally
/*      */   }
/*      */   
/*      */   boolean isEmptyResultSet()
/*      */     throws SQLException
/*      */   {
/* 2642 */     if ((this.statement != null) && (!this.statement.closed) && (this.statement.serverCursor) && (this.statement.connection.protocolId != 3) && (!this.isServerCursorPeeked) && (!this.closed))
/*      */     {
/*      */ 
/*      */ 
/* 2646 */       close_or_fetch_from_next(false);
/*      */       
/* 2648 */       if (this.statement.validRows > 0) {
/* 2649 */         this.statement.currentRow = -1;
/*      */       } else {
/* 2651 */         this.m_emptyRset = true;
/*      */       }
/* 2653 */       this.isServerCursorPeeked = true;
/*      */     }
/*      */     
/* 2656 */     return (this.m_emptyRset) || ((!this.m_emptyRset) && (this.statement.gotLastBatch) && (this.statement.validRows == 0));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getValidRows()
/*      */   {
/* 2665 */     return this.statement.validRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 2680 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2685 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OracleResultSetImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */