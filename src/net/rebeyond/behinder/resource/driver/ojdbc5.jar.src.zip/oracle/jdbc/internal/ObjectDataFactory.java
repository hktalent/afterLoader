package oracle.jdbc.internal;

public abstract interface ObjectDataFactory {}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/internal/ObjectDataFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */