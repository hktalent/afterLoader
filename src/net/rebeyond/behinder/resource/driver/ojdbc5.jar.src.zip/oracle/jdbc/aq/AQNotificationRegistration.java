package oracle.jdbc.aq;

import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;

public abstract interface AQNotificationRegistration
  extends NotificationRegistration
{
  public abstract void addListener(AQNotificationListener paramAQNotificationListener)
    throws SQLException;
  
  public abstract void addListener(AQNotificationListener paramAQNotificationListener, Executor paramExecutor)
    throws SQLException;
  
  public abstract void removeListener(AQNotificationListener paramAQNotificationListener)
    throws SQLException;
  
  public abstract String getQueueName();
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/aq/AQNotificationRegistration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */