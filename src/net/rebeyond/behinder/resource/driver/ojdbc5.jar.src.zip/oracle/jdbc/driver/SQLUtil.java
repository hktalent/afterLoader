/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleData;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.oracore.OracleNamedType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ import oracle.jdbc.oracore.OracleTypeCOLLECTION;
/*      */ import oracle.jdbc.oracore.OracleTypeOPAQUE;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.ArrayDescriptor;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CharacterSet;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.JAVA_STRUCT;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.OpaqueDescriptor;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLUtil
/*      */ {
/*      */   public static Object SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt, String paramString, Class paramClass, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*   87 */     Datum localDatum = makeDatum(paramOracleConnection, paramArrayOfByte, paramInt, paramString, 0);
/*   88 */     Object localObject = SQLToJava(paramOracleConnection, localDatum, paramClass, paramMap);
/*      */     
/*   90 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static CustomDatum SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt, String paramString, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/*  128 */     Datum localDatum = makeDatum(paramOracleConnection, paramArrayOfByte, paramInt, paramString, 0);
/*  129 */     CustomDatum localCustomDatum = paramCustomDatumFactory.create(localDatum, paramInt);
/*      */     
/*  131 */     return localCustomDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ORAData SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt, String paramString, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/*  169 */     Datum localDatum = makeDatum(paramOracleConnection, paramArrayOfByte, paramInt, paramString, 0);
/*  170 */     ORAData localORAData = paramORADataFactory.create(localDatum, paramInt);
/*      */     
/*  172 */     return localORAData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static OracleData SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt, String paramString, OracleDataFactory paramOracleDataFactory)
/*      */     throws SQLException
/*      */   {
/*  210 */     Datum localDatum = makeDatum(paramOracleConnection, paramArrayOfByte, paramInt, paramString, 0);
/*  211 */     OracleData localOracleData = paramOracleDataFactory.create(localDatum.toJdbc(), paramInt);
/*      */     
/*  213 */     return localOracleData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object SQLToJava(OracleConnection paramOracleConnection, Datum paramDatum, Class paramClass, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  253 */     Object localObject = null;
/*      */     
/*  255 */     if ((paramDatum instanceof STRUCT))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  261 */       if (paramClass == null)
/*      */       {
/*  263 */         localObject = paramMap != null ? ((STRUCT)paramDatum).toJdbc(paramMap) : paramDatum.toJdbc();
/*      */       }
/*      */       else
/*      */       {
/*  267 */         localObject = paramMap != null ? ((STRUCT)paramDatum).toClass(paramClass, paramMap) : ((STRUCT)paramDatum).toClass(paramClass);
/*      */       }
/*      */       
/*      */     }
/*  271 */     else if (paramClass == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  277 */       localObject = paramDatum.toJdbc();
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  285 */       int i = classNumber(paramClass);
/*      */       
/*  287 */       switch (i)
/*      */       {
/*      */ 
/*      */       case 0: 
/*  291 */         localObject = paramDatum.stringValue();
/*      */         
/*  293 */         break;
/*      */       
/*      */       case 1: 
/*  296 */         localObject = Boolean.valueOf(paramDatum.longValue() != 0L);
/*      */         
/*  298 */         break;
/*      */       
/*      */       case 2: 
/*  301 */         localObject = Integer.valueOf((int)paramDatum.longValue());
/*      */         
/*  303 */         break;
/*      */       
/*      */       case 3: 
/*  306 */         localObject = Long.valueOf(paramDatum.longValue());
/*      */         
/*  308 */         break;
/*      */       
/*      */       case 4: 
/*  311 */         localObject = Float.valueOf(paramDatum.bigDecimalValue().floatValue());
/*      */         
/*  313 */         break;
/*      */       
/*      */       case 5: 
/*  316 */         localObject = Double.valueOf(paramDatum.bigDecimalValue().doubleValue());
/*      */         
/*  318 */         break;
/*      */       
/*      */       case 6: 
/*  321 */         localObject = paramDatum.bigDecimalValue();
/*      */         
/*  323 */         break;
/*      */       
/*      */       case 7: 
/*  326 */         localObject = paramDatum.dateValue();
/*      */         
/*  328 */         break;
/*      */       
/*      */       case 8: 
/*  331 */         localObject = paramDatum.timeValue();
/*      */         
/*  333 */         break;
/*      */       
/*      */       case 9: 
/*  336 */         localObject = paramDatum.timestampValue();
/*      */         
/*  338 */         break;
/*      */       
/*      */ 
/*      */       case -1: 
/*      */       default: 
/*  343 */         localObject = paramDatum.toJdbc();
/*      */         
/*  345 */         if (!paramClass.isInstance(localObject))
/*      */         {
/*      */ 
/*      */ 
/*  349 */           SQLException localSQLException = DatabaseError.createSqlException(null, 59, "invalid data conversion");
/*  350 */           localSQLException.fillInStackTrace();
/*  351 */           throw localSQLException;
/*      */         }
/*      */         
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*  359 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] JavaToSQL(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/*  397 */     if (paramObject == null)
/*      */     {
/*      */ 
/*  400 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  408 */     Object localObject = null;
/*      */     
/*  410 */     if ((paramObject instanceof Datum))
/*      */     {
/*  412 */       localObject = (Datum)paramObject;
/*      */     }
/*  414 */     else if ((paramObject instanceof ORAData))
/*      */     {
/*  416 */       localObject = ((ORAData)paramObject).toDatum(paramOracleConnection);
/*      */     }
/*  418 */     else if ((paramObject instanceof CustomDatum))
/*      */     {
/*  420 */       localObject = paramOracleConnection.toDatum((CustomDatum)paramObject);
/*      */     }
/*  422 */     else if ((paramObject instanceof SQLData))
/*      */     {
/*  424 */       localObject = STRUCT.toSTRUCT(paramObject, paramOracleConnection);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  431 */     if (localObject != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  441 */       if (!checkDatumType((Datum)localObject, paramInt, paramString))
/*      */       {
/*  443 */         localObject = null;
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  456 */       localObject = makeDatum(paramOracleConnection, paramObject, paramInt, paramString);
/*      */     }
/*      */     
/*  459 */     byte[] arrayOfByte = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  464 */     if (localObject != null)
/*      */     {
/*  466 */       if ((localObject instanceof STRUCT)) {
/*  467 */         arrayOfByte = ((STRUCT)localObject).toBytes();
/*  468 */       } else if ((localObject instanceof ARRAY)) {
/*  469 */         arrayOfByte = ((ARRAY)localObject).toBytes();
/*  470 */       } else if ((localObject instanceof OPAQUE)) {
/*  471 */         arrayOfByte = ((OPAQUE)localObject).toBytes();
/*      */       } else {
/*  473 */         arrayOfByte = ((Datum)localObject).shareBytes();
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  479 */       SQLException localSQLException = DatabaseError.createSqlException(null, 1, "attempt to convert a Datum to incompatible SQL type");
/*  480 */       localSQLException.fillInStackTrace();
/*  481 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  485 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt1, String paramString, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  527 */     Object localObject1 = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  542 */     int i = paramOracleConnection.getDbCsId();
/*  543 */     int j = paramOracleConnection.getJdbcCsId();
/*  544 */     int k = CharacterSetMetaData.getRatio(j, i);
/*      */     Object localObject2;
/*  546 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 96: 
/*  555 */       if ((paramInt2 != 0) && (paramInt2 < paramArrayOfByte.length) && (k == 1))
/*      */       {
/*  557 */         localObject1 = new CHAR(paramArrayOfByte, 0, paramInt2, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  562 */         localObject1 = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */       }
/*      */       
/*  565 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*  572 */       localObject1 = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */       
/*      */ 
/*  575 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 6: 
/*  580 */       localObject1 = new NUMBER(paramArrayOfByte);
/*      */       
/*  582 */       break;
/*      */     
/*      */     case 100: 
/*  585 */       localObject1 = new BINARY_FLOAT(paramArrayOfByte);
/*      */       
/*  587 */       break;
/*      */     
/*      */     case 101: 
/*  590 */       localObject1 = new BINARY_DOUBLE(paramArrayOfByte);
/*      */       
/*  592 */       break;
/*      */     
/*      */ 
/*      */     case 23: 
/*      */     case 24: 
/*  597 */       localObject1 = new RAW(paramArrayOfByte);
/*      */       
/*  599 */       break;
/*      */     
/*      */     case 104: 
/*  602 */       localObject1 = new ROWID(paramArrayOfByte);
/*      */       
/*  604 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 102: 
/*  612 */       localObject2 = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet?");
/*  613 */       ((SQLException)localObject2).fillInStackTrace();
/*  614 */       throw ((Throwable)localObject2);
/*      */     
/*      */ 
/*      */     case 12: 
/*  618 */       localObject1 = new DATE(paramArrayOfByte);
/*      */       
/*  620 */       break;
/*      */     
/*      */     case 182: 
/*  623 */       localObject1 = new INTERVALYM(paramArrayOfByte);
/*      */       
/*  625 */       break;
/*      */     
/*      */     case 183: 
/*  628 */       localObject1 = new INTERVALDS(paramArrayOfByte);
/*      */       
/*  630 */       break;
/*      */     
/*      */     case 180: 
/*  633 */       localObject1 = new TIMESTAMP(paramArrayOfByte);
/*      */       
/*  635 */       break;
/*      */     
/*      */     case 181: 
/*  638 */       localObject1 = new TIMESTAMPTZ(paramArrayOfByte);
/*      */       
/*  640 */       break;
/*      */     
/*      */     case 231: 
/*  643 */       localObject1 = new TIMESTAMPLTZ(paramArrayOfByte);
/*      */       
/*  645 */       break;
/*      */     
/*      */     case 113: 
/*  648 */       localObject1 = paramOracleConnection.createBlob(paramArrayOfByte);
/*      */       
/*  650 */       break;
/*      */     
/*      */     case 112: 
/*  653 */       localObject1 = paramOracleConnection.createClob(paramArrayOfByte);
/*      */       
/*  655 */       break;
/*      */     
/*      */     case 114: 
/*  658 */       localObject1 = paramOracleConnection.createBfile(paramArrayOfByte);
/*      */       
/*  660 */       break;
/*      */     
/*      */ 
/*      */     case 109: 
/*  664 */       localObject2 = TypeDescriptor.getTypeDescriptor(paramString, paramOracleConnection, paramArrayOfByte, 0L);
/*      */       
/*      */ 
/*  667 */       switch (((TypeDescriptor)localObject2).getTypeCode())
/*      */       {
/*      */       case 2002: 
/*  670 */         localObject1 = new STRUCT((StructDescriptor)localObject2, paramArrayOfByte, paramOracleConnection);
/*      */         
/*  672 */         break;
/*      */       
/*      */       case 2008: 
/*  675 */         localObject1 = new JAVA_STRUCT((StructDescriptor)localObject2, paramArrayOfByte, paramOracleConnection);
/*      */         
/*  677 */         break;
/*      */       
/*      */       case 2003: 
/*  680 */         localObject1 = new ARRAY((ArrayDescriptor)localObject2, paramArrayOfByte, paramOracleConnection);
/*      */         
/*  682 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2007: 
/*  689 */         localObject1 = new OPAQUE((OpaqueDescriptor)localObject2, paramArrayOfByte, paramOracleConnection);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*  695 */       break;
/*      */     
/*      */ 
/*      */     case 111: 
/*  699 */       localObject2 = getTypeDescriptor(paramString, paramOracleConnection);
/*      */       
/*  701 */       if ((localObject2 instanceof StructDescriptor))
/*      */       {
/*  703 */         localObject1 = new REF((StructDescriptor)localObject2, paramOracleConnection, paramArrayOfByte);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  709 */         SQLException localSQLException = DatabaseError.createSqlException(null, 1, "program error: REF points to a non-STRUCT");
/*  710 */         localSQLException.fillInStackTrace();
/*  711 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  716 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/*  721 */       localObject2 = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
/*  722 */       ((SQLException)localObject2).fillInStackTrace();
/*  723 */       throw ((Throwable)localObject2);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  728 */     return (Datum)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeNDatum(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt1, String paramString, short paramShort, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  744 */     Object localObject = null;
/*      */     
/*  746 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 96: 
/*  754 */       int i = paramInt2 * CharacterSetMetaData.getRatio(paramOracleConnection.getNCharSet(), 1);
/*      */       
/*      */ 
/*      */ 
/*  758 */       if ((paramInt2 != 0) && (i < paramArrayOfByte.length)) {
/*  759 */         localObject = new CHAR(paramArrayOfByte, 0, paramInt2, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */       }
/*      */       else {
/*  762 */         localObject = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */       }
/*      */       
/*  765 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*  772 */       localObject = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */       
/*      */ 
/*  775 */       break;
/*      */     
/*      */     case 112: 
/*  778 */       localObject = paramOracleConnection.createClob(paramArrayOfByte, paramShort);
/*      */       
/*  780 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/*  785 */       SQLException localSQLException = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
/*  786 */       localSQLException.fillInStackTrace();
/*  787 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  792 */     return (Datum)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/*  826 */     return makeDatum(paramOracleConnection, paramObject, paramInt, paramString, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  840 */     Object localObject1 = null;
/*      */     Object localObject2;
/*  842 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*      */     case 96: 
/*  852 */       localObject1 = new CHAR(paramObject, CharacterSet.make(paramBoolean ? paramOracleConnection.getNCharSet() : paramOracleConnection.getJdbcCsId()));
/*      */       
/*      */ 
/*  855 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 6: 
/*  860 */       localObject1 = new NUMBER(paramObject);
/*      */       
/*  862 */       break;
/*      */     
/*      */     case 100: 
/*  865 */       if ((paramObject instanceof String)) {
/*  866 */         localObject1 = new BINARY_FLOAT((String)paramObject);
/*  867 */       } else if ((paramObject instanceof Boolean)) {
/*  868 */         localObject1 = new BINARY_FLOAT((Boolean)paramObject);
/*      */       } else {
/*  870 */         localObject1 = new BINARY_FLOAT((Float)paramObject);
/*      */       }
/*  872 */       break;
/*      */     
/*      */     case 101: 
/*  875 */       if ((paramObject instanceof String)) {
/*  876 */         localObject1 = new BINARY_DOUBLE((String)paramObject);
/*  877 */       } else if ((paramObject instanceof Boolean)) {
/*  878 */         localObject1 = new BINARY_DOUBLE((Boolean)paramObject);
/*      */       } else {
/*  880 */         localObject1 = new BINARY_DOUBLE((Double)paramObject);
/*      */       }
/*  882 */       break;
/*      */     
/*      */ 
/*      */     case 23: 
/*      */     case 24: 
/*  887 */       localObject1 = new RAW(paramObject);
/*      */       
/*  889 */       break;
/*      */     
/*      */     case 104: 
/*  892 */       if ((paramObject instanceof String)) {
/*  893 */         localObject1 = new ROWID((String)paramObject);
/*  894 */       } else if ((paramObject instanceof byte[])) {
/*  895 */         localObject1 = new ROWID((byte[])paramObject);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 102: 
/*  905 */       localObject2 = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet");
/*  906 */       ((SQLException)localObject2).fillInStackTrace();
/*  907 */       throw ((Throwable)localObject2);
/*      */     
/*      */ 
/*      */     case 12: 
/*  911 */       localObject1 = new DATE(paramObject);
/*      */       
/*  913 */       break;
/*      */     
/*      */     case 180: 
/*  916 */       if ((paramObject instanceof TIMESTAMP))
/*      */       {
/*  918 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  920 */       else if ((paramObject instanceof Timestamp)) {
/*  921 */         localObject1 = new TIMESTAMP((Timestamp)paramObject);
/*  922 */       } else if ((paramObject instanceof Date)) {
/*  923 */         localObject1 = new TIMESTAMP((Date)paramObject);
/*  924 */       } else if ((paramObject instanceof Time)) {
/*  925 */         localObject1 = new TIMESTAMP((Time)paramObject);
/*  926 */       } else if ((paramObject instanceof DATE)) {
/*  927 */         localObject1 = new TIMESTAMP((DATE)paramObject);
/*  928 */       } else if ((paramObject instanceof String)) {
/*  929 */         localObject1 = new TIMESTAMP((String)paramObject);
/*  930 */       } else if ((paramObject instanceof byte[])) {
/*  931 */         localObject1 = new TIMESTAMP((byte[])paramObject);
/*      */       }
/*      */       
/*      */       break;
/*      */     case 181: 
/*  936 */       if ((paramObject instanceof TIMESTAMPTZ))
/*      */       {
/*  938 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  940 */       else if ((paramObject instanceof Timestamp)) {
/*  941 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (Timestamp)paramObject);
/*  942 */       } else if ((paramObject instanceof Date)) {
/*  943 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (Date)paramObject);
/*  944 */       } else if ((paramObject instanceof Time)) {
/*  945 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (Time)paramObject);
/*  946 */       } else if ((paramObject instanceof DATE)) {
/*  947 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (DATE)paramObject);
/*  948 */       } else if ((paramObject instanceof String)) {
/*  949 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (String)paramObject);
/*  950 */       } else if ((paramObject instanceof byte[])) {
/*  951 */         localObject1 = new TIMESTAMPTZ((byte[])paramObject);
/*      */       }
/*      */       
/*      */       break;
/*      */     case 231: 
/*  956 */       if ((paramObject instanceof TIMESTAMPLTZ))
/*      */       {
/*  958 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  960 */       else if ((paramObject instanceof Timestamp)) {
/*  961 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (Timestamp)paramObject);
/*  962 */       } else if ((paramObject instanceof Date)) {
/*  963 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (Date)paramObject);
/*  964 */       } else if ((paramObject instanceof Time)) {
/*  965 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (Time)paramObject);
/*  966 */       } else if ((paramObject instanceof DATE)) {
/*  967 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (DATE)paramObject);
/*  968 */       } else if ((paramObject instanceof String)) {
/*  969 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (String)paramObject);
/*  970 */       } else if ((paramObject instanceof byte[])) {
/*  971 */         localObject1 = new TIMESTAMPLTZ((byte[])paramObject);
/*      */       }
/*      */       
/*      */       break;
/*      */     case 113: 
/*  976 */       if ((paramObject instanceof BLOB))
/*      */       {
/*  978 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  980 */       if ((paramObject instanceof byte[]))
/*      */       {
/*  982 */         localObject1 = new RAW((byte[])paramObject);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 112: 
/*  988 */       if ((paramObject instanceof CLOB))
/*      */       {
/*  990 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*  993 */       if ((paramObject instanceof String))
/*      */       {
/*  995 */         localObject2 = CharacterSet.make(paramBoolean ? paramOracleConnection.getNCharSet() : paramOracleConnection.getJdbcCsId());
/*  996 */         localObject1 = new CHAR((String)paramObject, (CharacterSet)localObject2); }
/*  997 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 114: 
/* 1002 */       if ((paramObject instanceof BFILE))
/*      */       {
/* 1004 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 109: 
/* 1010 */       if (((paramObject instanceof STRUCT)) || ((paramObject instanceof ARRAY)) || ((paramObject instanceof OPAQUE)))
/*      */       {
/*      */ 
/* 1013 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 111: 
/* 1019 */       if ((paramObject instanceof REF))
/*      */       {
/* 1021 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 1030 */     if (localObject1 == null)
/*      */     {
/*      */ 
/*      */ 
/* 1034 */       localObject2 = DatabaseError.createSqlException(null, 1, "Unable to construct a Datum from the specified input");
/* 1035 */       ((SQLException)localObject2).fillInStackTrace();
/* 1036 */       throw ((Throwable)localObject2);
/*      */     }
/*      */     
/*      */ 
/* 1040 */     return (Datum)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int classNumber(Class paramClass)
/*      */   {
/* 1057 */     int i = -1;
/* 1058 */     Integer localInteger = (Integer)classTable.get(paramClass);
/*      */     
/* 1060 */     if (localInteger != null)
/*      */     {
/* 1062 */       i = localInteger.intValue();
/*      */     }
/*      */     
/* 1065 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getTypeDescriptor(String paramString, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/* 1099 */     Object localObject = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1104 */     SQLName localSQLName = new SQLName(paramString, paramOracleConnection);
/* 1105 */     String str = localSQLName.getName();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1110 */     localObject = paramOracleConnection.getDescriptor(str);
/*      */     
/* 1112 */     if (localObject != null)
/*      */     {
/*      */ 
/* 1115 */       return localObject;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1121 */     OracleTypeADT localOracleTypeADT = new OracleTypeADT(str, paramOracleConnection);
/* 1122 */     localOracleTypeADT.init(paramOracleConnection);
/*      */     
/* 1124 */     OracleNamedType localOracleNamedType = localOracleTypeADT.cleanup();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1129 */     switch (localOracleNamedType.getTypeCode())
/*      */     {
/*      */ 
/*      */ 
/*      */     case 2003: 
/* 1134 */       localObject = new ArrayDescriptor(localSQLName, (OracleTypeCOLLECTION)localOracleNamedType, paramOracleConnection);
/*      */       
/*      */ 
/*      */ 
/* 1138 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 2002: 
/*      */     case 2008: 
/* 1144 */       localObject = new StructDescriptor(localSQLName, (OracleTypeADT)localOracleNamedType, paramOracleConnection);
/*      */       
/*      */ 
/*      */ 
/* 1148 */       break;
/*      */     
/*      */ 
/*      */     case 2007: 
/* 1152 */       localObject = new OpaqueDescriptor(localSQLName, (OracleTypeOPAQUE)localOracleNamedType, paramOracleConnection);
/*      */       
/*      */ 
/*      */ 
/* 1156 */       break;
/*      */     case 2004: 
/*      */     case 2005: 
/*      */     case 2006: 
/*      */     default: 
/* 1161 */       SQLException localSQLException = DatabaseError.createSqlException(null, 1, "Unrecognized type code");
/* 1162 */       localSQLException.fillInStackTrace();
/* 1163 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1170 */     paramOracleConnection.putDescriptor(str, localObject);
/*      */     
/* 1172 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean checkDatumType(Datum paramDatum, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 1202 */     boolean bool = false;
/*      */     
/* 1204 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*      */     case 96: 
/* 1212 */       bool = paramDatum instanceof CHAR;
/*      */       
/* 1214 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 6: 
/* 1219 */       bool = paramDatum instanceof NUMBER;
/*      */       
/* 1221 */       break;
/*      */     
/*      */     case 100: 
/* 1224 */       bool = paramDatum instanceof BINARY_FLOAT;
/*      */       
/* 1226 */       break;
/*      */     
/*      */     case 101: 
/* 1229 */       bool = paramDatum instanceof BINARY_DOUBLE;
/*      */       
/* 1231 */       break;
/*      */     
/*      */ 
/*      */     case 23: 
/*      */     case 24: 
/* 1236 */       bool = paramDatum instanceof RAW;
/*      */       
/* 1238 */       break;
/*      */     
/*      */     case 104: 
/* 1241 */       bool = paramDatum instanceof ROWID;
/*      */       
/* 1243 */       break;
/*      */     
/*      */     case 12: 
/* 1246 */       bool = paramDatum instanceof DATE;
/*      */       
/* 1248 */       break;
/*      */     
/*      */     case 180: 
/* 1251 */       bool = paramDatum instanceof TIMESTAMP;
/*      */       
/* 1253 */       break;
/*      */     
/*      */     case 181: 
/* 1256 */       bool = paramDatum instanceof TIMESTAMPTZ;
/*      */       
/* 1258 */       break;
/*      */     
/*      */     case 231: 
/* 1261 */       bool = paramDatum instanceof TIMESTAMPLTZ;
/*      */       
/* 1263 */       break;
/*      */     
/*      */     case 113: 
/* 1266 */       bool = paramDatum instanceof BLOB;
/*      */       
/* 1268 */       break;
/*      */     
/*      */     case 112: 
/* 1271 */       bool = paramDatum instanceof CLOB;
/*      */       
/* 1273 */       break;
/*      */     
/*      */     case 114: 
/* 1276 */       bool = paramDatum instanceof BFILE;
/*      */       
/* 1278 */       break;
/*      */     
/*      */     case 111: 
/* 1281 */       bool = ((paramDatum instanceof REF)) && (((REF)paramDatum).getBaseTypeName().equals(paramString));
/*      */       
/*      */ 
/* 1284 */       break;
/*      */     
/*      */     case 109: 
/* 1287 */       if ((paramDatum instanceof STRUCT))
/*      */       {
/* 1289 */         bool = ((STRUCT)paramDatum).isInHierarchyOf(paramString);
/*      */       }
/* 1291 */       else if ((paramDatum instanceof ARRAY))
/*      */       {
/* 1293 */         bool = ((ARRAY)paramDatum).getSQLTypeName().equals(paramString);
/*      */       }
/* 1295 */       else if ((paramDatum instanceof OPAQUE))
/*      */       {
/* 1297 */         bool = ((OPAQUE)paramDatum).getSQLTypeName().equals(paramString);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 102: 
/*      */     default: 
/* 1305 */       bool = false;
/*      */     }
/*      */     
/* 1308 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean implementsInterface(Class paramClass1, Class paramClass2)
/*      */   {
/* 1328 */     if (paramClass1 == null)
/*      */     {
/* 1330 */       return false;
/*      */     }
/*      */     
/* 1333 */     if (paramClass1 == paramClass2)
/*      */     {
/* 1335 */       return true;
/*      */     }
/*      */     
/* 1338 */     Class[] arrayOfClass = paramClass1.getInterfaces();
/*      */     
/* 1340 */     for (int i = 0; i < arrayOfClass.length; i++)
/*      */     {
/* 1342 */       if (implementsInterface(arrayOfClass[i], paramClass2))
/*      */       {
/* 1344 */         return true;
/*      */       }
/*      */     }
/*      */     
/* 1348 */     return implementsInterface(paramClass1.getSuperclass(), paramClass2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeOracleDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 1379 */     return makeOracleDatum(paramOracleConnection, paramObject, paramInt, paramString, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeOracleDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1394 */     Datum localDatum = makeDatum(paramOracleConnection, paramObject, getInternalType(paramInt), paramString, paramBoolean);
/*      */     
/*      */ 
/* 1397 */     return localDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static int getInternalType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1405 */     int i = 0;
/*      */     
/* 1407 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 1429 */       i = 6;
/*      */       
/* 1431 */       break;
/*      */     
/*      */     case 100: 
/* 1434 */       i = 100;
/*      */       
/* 1436 */       break;
/*      */     
/*      */     case 101: 
/* 1439 */       i = 101;
/*      */       
/* 1441 */       break;
/*      */     
/*      */     case 999: 
/* 1444 */       i = 999;
/*      */       
/* 1446 */       break;
/*      */     
/*      */     case 1: 
/* 1449 */       i = 96;
/*      */       
/* 1451 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 1458 */       i = 1;
/*      */       
/* 1460 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -1: 
/* 1467 */       i = 8;
/*      */       
/* 1469 */       break;
/*      */     
/*      */ 
/*      */     case 91: 
/*      */     case 92: 
/* 1474 */       i = 12;
/*      */       
/* 1476 */       break;
/*      */     
/*      */ 
/*      */     case -100: 
/*      */     case 93: 
/* 1481 */       i = 180;
/*      */       
/* 1483 */       break;
/*      */     
/*      */     case -101: 
/* 1486 */       i = 181;
/*      */       
/* 1488 */       break;
/*      */     
/*      */     case -102: 
/* 1491 */       i = 231;
/*      */       
/* 1493 */       break;
/*      */     
/*      */     case -104: 
/* 1496 */       i = 183;
/*      */       
/* 1498 */       break;
/*      */     
/*      */     case -103: 
/* 1501 */       i = 182;
/*      */       
/* 1503 */       break;
/*      */     
/*      */ 
/*      */     case -3: 
/*      */     case -2: 
/* 1508 */       i = 23;
/*      */       
/* 1510 */       break;
/*      */     
/*      */     case -4: 
/* 1513 */       i = 24;
/*      */       
/* 1515 */       break;
/*      */     
/*      */     case -8: 
/* 1518 */       i = 104;
/*      */       
/* 1520 */       break;
/*      */     
/*      */     case 2004: 
/* 1523 */       i = 113;
/*      */       
/* 1525 */       break;
/*      */     
/*      */     case 2005: 
/* 1528 */       i = 112;
/*      */       
/* 1530 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -13: 
/* 1537 */       i = 114;
/*      */       
/* 1539 */       break;
/*      */     
/*      */     case -10: 
/* 1542 */       i = 102;
/*      */       
/* 1544 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2002: 
/*      */     case 2003: 
/*      */     case 2007: 
/*      */     case 2008: 
/* 1553 */       i = 109;
/*      */       
/* 1555 */       break;
/*      */     
/*      */     case 2006: 
/* 1558 */       i = 111;
/*      */       
/* 1560 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/* 1565 */       SQLException localSQLException = DatabaseError.createSqlException(null, 4, "get_internal_type");
/* 1566 */       localSQLException.fillInStackTrace();
/* 1567 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/* 1571 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 1586 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1766 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   private static final int CLASS_NOT_FOUND = -1;
/*      */   
/*      */   private static final int CLASS_STRING = 0;
/*      */   
/*      */   private static final int CLASS_BOOLEAN = 1;
/*      */   
/*      */   private static final int CLASS_INTEGER = 2;
/*      */   
/*      */   private static final int CLASS_LONG = 3;
/*      */   
/*      */   private static final int CLASS_FLOAT = 4;
/*      */   
/*      */   private static final int CLASS_DOUBLE = 5;
/*      */   private static final int CLASS_BIGDECIMAL = 6;
/*      */   private static final int CLASS_DATE = 7;
/*      */   private static final int CLASS_TIME = 8;
/*      */   private static final int CLASS_TIMESTAMP = 9;
/*      */   private static final int TOTAL_CLASSES = 10;
/* 1788 */   private static Hashtable classTable = new Hashtable(10);
/*      */   
/*      */   static {
/*      */     try {
/* 1792 */       classTable.put(Class.forName("java.lang.String"), Integer.valueOf(0));
/*      */       
/* 1794 */       classTable.put(Class.forName("java.lang.Boolean"), Integer.valueOf(1));
/*      */       
/* 1796 */       classTable.put(Class.forName("java.lang.Integer"), Integer.valueOf(2));
/*      */       
/* 1798 */       classTable.put(Class.forName("java.lang.Long"), Integer.valueOf(3));
/* 1799 */       classTable.put(Class.forName("java.lang.Float"), Integer.valueOf(4));
/*      */       
/* 1801 */       classTable.put(Class.forName("java.lang.Double"), Integer.valueOf(5));
/*      */       
/* 1803 */       classTable.put(Class.forName("java.math.BigDecimal"), Integer.valueOf(6));
/*      */       
/* 1805 */       classTable.put(Class.forName("java.sql.Date"), Integer.valueOf(7));
/* 1806 */       classTable.put(Class.forName("java.sql.Time"), Integer.valueOf(8));
/* 1807 */       classTable.put(Class.forName("java.sql.Timestamp"), Integer.valueOf(9));
/*      */     }
/*      */     catch (ClassNotFoundException localClassNotFoundException) {}
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/SQLUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */