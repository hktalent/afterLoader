/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.sql.ANYDATA;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleCallableStatement
/*      */   extends OraclePreparedStatement
/*      */   implements oracle.jdbc.internal.OracleCallableStatement
/*      */ {
/*   52 */   boolean atLeastOneOrdinalParameter = false;
/*   53 */   boolean atLeastOneNamedParameter = false;
/*      */   
/*      */ 
/*   56 */   String[] namedParameters = new String[8];
/*      */   
/*      */ 
/*   59 */   int parameterCount = 0;
/*      */   
/*      */ 
/*   62 */   final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*   83 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  101 */     super(paramPhysicalConnection, paramString, 1, paramInt2, paramInt3, paramInt4);
/*      */     
/*      */ 
/*  104 */     this.statementType = 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*      */     throws SQLException
/*      */   {
/*  117 */     int i = paramInt1 - 1;
/*  118 */     SQLException localSQLException; if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*      */     {
/*  120 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  121 */       localSQLException.fillInStackTrace();
/*  122 */       throw localSQLException;
/*      */     }
/*      */     
/*  125 */     if (paramInt2 == 0)
/*      */     {
/*  127 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  128 */       localSQLException.fillInStackTrace();
/*  129 */       throw localSQLException;
/*      */     }
/*  131 */     int j = getInternalType(paramInt2);
/*      */     
/*  133 */     resetBatch();
/*  134 */     this.currentRowNeedToPrepareBinds = true;
/*      */     
/*  136 */     if (this.currentRowBindAccessors == null) {
/*  137 */       this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/*      */     
/*  140 */     switch (paramInt2)
/*      */     {
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 12: 
/*      */     case 70: 
/*      */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     default: 
/*  154 */       paramInt4 = 0;
/*      */     }
/*      */     
/*      */     
/*  158 */     this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, i + 1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/*  192 */     if ((paramString == null) || (paramString.length() == 0))
/*      */     {
/*  194 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
/*  195 */       localSQLException.fillInStackTrace();
/*  196 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  202 */     synchronized (this.connection) {
/*  203 */       registerOutParameterInternal(paramInt1, paramInt2, 0, 0, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  232 */     synchronized (this.connection)
/*      */     {
/*  234 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  263 */     synchronized (this.connection)
/*      */     {
/*  265 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  282 */     synchronized (this.connection)
/*      */     {
/*  284 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  301 */     synchronized (this.connection)
/*      */     {
/*  303 */       registerOutParameterInternal(paramString, paramInt1, paramInt2, paramInt3, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isOracleBatchStyle()
/*      */   {
/*  312 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetBatch()
/*      */   {
/*  322 */     this.batch = 1;
/*      */   }
/*      */   
/*      */   public void setExecuteBatch(int paramInt)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   /* Error */
/*      */   public int sendBatch()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 25	oracle/jdbc/driver/OracleCallableStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 29	oracle/jdbc/driver/OracleCallableStatement:validRows	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #351	-> byte code offset #0
/*      */     //   Java source line #354	-> byte code offset #7
/*      */     //   Java source line #356	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleCallableStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  373 */     registerOutParameter(paramInt1, paramInt2, 0, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  385 */     registerOutParameter(paramInt1, paramInt2, paramInt3, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  393 */     return wasNullValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  403 */     if (this.closed)
/*      */     {
/*  405 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  406 */       ((SQLException)localObject).fillInStackTrace();
/*  407 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  410 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  413 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  414 */       ((SQLException)localObject).fillInStackTrace();
/*  415 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  419 */     Object localObject = null;
/*  420 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  425 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  426 */       localSQLException.fillInStackTrace();
/*  427 */       throw localSQLException;
/*      */     }
/*      */     
/*  430 */     this.lastIndex = paramInt;
/*      */     
/*  432 */     if (this.streamList != null) {
/*  433 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  436 */     return ((Accessor)localObject).getString(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  446 */     if (this.closed)
/*      */     {
/*  448 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  449 */       ((SQLException)localObject).fillInStackTrace();
/*  450 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  453 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  456 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  457 */       ((SQLException)localObject).fillInStackTrace();
/*  458 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  462 */     Object localObject = null;
/*  463 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  468 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  469 */       localSQLException.fillInStackTrace();
/*  470 */       throw localSQLException;
/*      */     }
/*      */     
/*  473 */     this.lastIndex = paramInt;
/*      */     
/*  475 */     if (this.streamList != null) {
/*  476 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  479 */     return ((Accessor)localObject).getOracleObject(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ROWID getROWID(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  489 */     if (this.closed)
/*      */     {
/*  491 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  492 */       ((SQLException)localObject).fillInStackTrace();
/*  493 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  496 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  499 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  500 */       ((SQLException)localObject).fillInStackTrace();
/*  501 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  505 */     Object localObject = null;
/*  506 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  511 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  512 */       localSQLException.fillInStackTrace();
/*  513 */       throw localSQLException;
/*      */     }
/*      */     
/*  516 */     this.lastIndex = paramInt;
/*      */     
/*  518 */     if (this.streamList != null) {
/*  519 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  522 */     return ((Accessor)localObject).getROWID(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  532 */     if (this.closed)
/*      */     {
/*  534 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  535 */       ((SQLException)localObject).fillInStackTrace();
/*  536 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  539 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  542 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  543 */       ((SQLException)localObject).fillInStackTrace();
/*  544 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  548 */     Object localObject = null;
/*  549 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  554 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  555 */       localSQLException.fillInStackTrace();
/*  556 */       throw localSQLException;
/*      */     }
/*      */     
/*  559 */     this.lastIndex = paramInt;
/*      */     
/*  561 */     if (this.streamList != null) {
/*  562 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  565 */     return ((Accessor)localObject).getNUMBER(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  575 */     if (this.closed)
/*      */     {
/*  577 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  578 */       ((SQLException)localObject).fillInStackTrace();
/*  579 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  582 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  585 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  586 */       ((SQLException)localObject).fillInStackTrace();
/*  587 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  591 */     Object localObject = null;
/*  592 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  597 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  598 */       localSQLException.fillInStackTrace();
/*  599 */       throw localSQLException;
/*      */     }
/*      */     
/*  602 */     this.lastIndex = paramInt;
/*      */     
/*  604 */     if (this.streamList != null) {
/*  605 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  608 */     return ((Accessor)localObject).getDATE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public INTERVALYM getINTERVALYM(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  618 */     if (this.closed)
/*      */     {
/*  620 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  621 */       ((SQLException)localObject).fillInStackTrace();
/*  622 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  625 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  628 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  629 */       ((SQLException)localObject).fillInStackTrace();
/*  630 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  634 */     Object localObject = null;
/*  635 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  640 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  641 */       localSQLException.fillInStackTrace();
/*  642 */       throw localSQLException;
/*      */     }
/*      */     
/*  645 */     this.lastIndex = paramInt;
/*      */     
/*  647 */     if (this.streamList != null) {
/*  648 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  651 */     return ((Accessor)localObject).getINTERVALYM(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public INTERVALDS getINTERVALDS(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  661 */     if (this.closed)
/*      */     {
/*  663 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  664 */       ((SQLException)localObject).fillInStackTrace();
/*  665 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  668 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  671 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  672 */       ((SQLException)localObject).fillInStackTrace();
/*  673 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  677 */     Object localObject = null;
/*  678 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  683 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  684 */       localSQLException.fillInStackTrace();
/*  685 */       throw localSQLException;
/*      */     }
/*      */     
/*  688 */     this.lastIndex = paramInt;
/*      */     
/*  690 */     if (this.streamList != null) {
/*  691 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  694 */     return ((Accessor)localObject).getINTERVALDS(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  704 */     if (this.closed)
/*      */     {
/*  706 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  707 */       ((SQLException)localObject).fillInStackTrace();
/*  708 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  711 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  714 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  715 */       ((SQLException)localObject).fillInStackTrace();
/*  716 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  720 */     Object localObject = null;
/*  721 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  726 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  727 */       localSQLException.fillInStackTrace();
/*  728 */       throw localSQLException;
/*      */     }
/*      */     
/*  731 */     this.lastIndex = paramInt;
/*      */     
/*  733 */     if (this.streamList != null) {
/*  734 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  737 */     return ((Accessor)localObject).getTIMESTAMP(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  747 */     if (this.closed)
/*      */     {
/*  749 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  750 */       ((SQLException)localObject).fillInStackTrace();
/*  751 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  754 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  757 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  758 */       ((SQLException)localObject).fillInStackTrace();
/*  759 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  763 */     Object localObject = null;
/*  764 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  769 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  770 */       localSQLException.fillInStackTrace();
/*  771 */       throw localSQLException;
/*      */     }
/*      */     
/*  774 */     this.lastIndex = paramInt;
/*      */     
/*  776 */     if (this.streamList != null) {
/*  777 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  780 */     return ((Accessor)localObject).getTIMESTAMPTZ(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  790 */     if (this.closed)
/*      */     {
/*  792 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  793 */       ((SQLException)localObject).fillInStackTrace();
/*  794 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  797 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  800 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  801 */       ((SQLException)localObject).fillInStackTrace();
/*  802 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  806 */     Object localObject = null;
/*  807 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  812 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  813 */       localSQLException.fillInStackTrace();
/*  814 */       throw localSQLException;
/*      */     }
/*      */     
/*  817 */     this.lastIndex = paramInt;
/*      */     
/*  819 */     if (this.streamList != null) {
/*  820 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  823 */     return ((Accessor)localObject).getTIMESTAMPLTZ(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public REF getREF(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  833 */     if (this.closed)
/*      */     {
/*  835 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  836 */       ((SQLException)localObject).fillInStackTrace();
/*  837 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  840 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  843 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  844 */       ((SQLException)localObject).fillInStackTrace();
/*  845 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  849 */     Object localObject = null;
/*  850 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  855 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  856 */       localSQLException.fillInStackTrace();
/*  857 */       throw localSQLException;
/*      */     }
/*      */     
/*  860 */     this.lastIndex = paramInt;
/*      */     
/*  862 */     if (this.streamList != null) {
/*  863 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  866 */     return ((Accessor)localObject).getREF(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ARRAY getARRAY(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  876 */     if (this.closed)
/*      */     {
/*  878 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  879 */       ((SQLException)localObject).fillInStackTrace();
/*  880 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  883 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  886 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  887 */       ((SQLException)localObject).fillInStackTrace();
/*  888 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  892 */     Object localObject = null;
/*  893 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  898 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  899 */       localSQLException.fillInStackTrace();
/*  900 */       throw localSQLException;
/*      */     }
/*      */     
/*  903 */     this.lastIndex = paramInt;
/*      */     
/*  905 */     if (this.streamList != null) {
/*  906 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  909 */     return ((Accessor)localObject).getARRAY(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public STRUCT getSTRUCT(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  919 */     if (this.closed)
/*      */     {
/*  921 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  922 */       ((SQLException)localObject).fillInStackTrace();
/*  923 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  926 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  929 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  930 */       ((SQLException)localObject).fillInStackTrace();
/*  931 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  935 */     Object localObject = null;
/*  936 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  941 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  942 */       localSQLException.fillInStackTrace();
/*  943 */       throw localSQLException;
/*      */     }
/*      */     
/*  946 */     this.lastIndex = paramInt;
/*      */     
/*  948 */     if (this.streamList != null) {
/*  949 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  952 */     return ((Accessor)localObject).getSTRUCT(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OPAQUE getOPAQUE(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  962 */     if (this.closed)
/*      */     {
/*  964 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  965 */       ((SQLException)localObject).fillInStackTrace();
/*  966 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  969 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  972 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  973 */       ((SQLException)localObject).fillInStackTrace();
/*  974 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  978 */     Object localObject = null;
/*  979 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  984 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  985 */       localSQLException.fillInStackTrace();
/*  986 */       throw localSQLException;
/*      */     }
/*      */     
/*  989 */     this.lastIndex = paramInt;
/*      */     
/*  991 */     if (this.streamList != null) {
/*  992 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  995 */     return ((Accessor)localObject).getOPAQUE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CHAR getCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1005 */     if (this.closed)
/*      */     {
/* 1007 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1008 */       ((SQLException)localObject).fillInStackTrace();
/* 1009 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1012 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1015 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1016 */       ((SQLException)localObject).fillInStackTrace();
/* 1017 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1021 */     Object localObject = null;
/* 1022 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1027 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1028 */       localSQLException.fillInStackTrace();
/* 1029 */       throw localSQLException;
/*      */     }
/*      */     
/* 1032 */     this.lastIndex = paramInt;
/*      */     
/* 1034 */     if (this.streamList != null) {
/* 1035 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1038 */     return ((Accessor)localObject).getCHAR(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1049 */     if (this.closed)
/*      */     {
/* 1051 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1052 */       ((SQLException)localObject).fillInStackTrace();
/* 1053 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1056 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1059 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1060 */       ((SQLException)localObject).fillInStackTrace();
/* 1061 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1065 */     Object localObject = null;
/* 1066 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1071 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1072 */       localSQLException.fillInStackTrace();
/* 1073 */       throw localSQLException;
/*      */     }
/*      */     
/* 1076 */     this.lastIndex = paramInt;
/*      */     
/* 1078 */     if (this.streamList != null) {
/* 1079 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1082 */     return ((Accessor)localObject).getCharacterStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1092 */     if (this.closed)
/*      */     {
/* 1094 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1095 */       ((SQLException)localObject).fillInStackTrace();
/* 1096 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1099 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1102 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1103 */       ((SQLException)localObject).fillInStackTrace();
/* 1104 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1108 */     Object localObject = null;
/* 1109 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1114 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1115 */       localSQLException.fillInStackTrace();
/* 1116 */       throw localSQLException;
/*      */     }
/*      */     
/* 1119 */     this.lastIndex = paramInt;
/*      */     
/* 1121 */     if (this.streamList != null) {
/* 1122 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1125 */     return ((Accessor)localObject).getRAW(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BLOB getBLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1136 */     if (this.closed)
/*      */     {
/* 1138 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1139 */       ((SQLException)localObject).fillInStackTrace();
/* 1140 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1143 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1146 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1147 */       ((SQLException)localObject).fillInStackTrace();
/* 1148 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1152 */     Object localObject = null;
/* 1153 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1158 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1159 */       localSQLException.fillInStackTrace();
/* 1160 */       throw localSQLException;
/*      */     }
/*      */     
/* 1163 */     this.lastIndex = paramInt;
/*      */     
/* 1165 */     if (this.streamList != null) {
/* 1166 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1169 */     return ((Accessor)localObject).getBLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CLOB getCLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1179 */     if (this.closed)
/*      */     {
/* 1181 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1182 */       ((SQLException)localObject).fillInStackTrace();
/* 1183 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1186 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1189 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1190 */       ((SQLException)localObject).fillInStackTrace();
/* 1191 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1195 */     Object localObject = null;
/* 1196 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1201 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1202 */       localSQLException.fillInStackTrace();
/* 1203 */       throw localSQLException;
/*      */     }
/*      */     
/* 1206 */     this.lastIndex = paramInt;
/*      */     
/* 1208 */     if (this.streamList != null) {
/* 1209 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1212 */     return ((Accessor)localObject).getCLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BFILE getBFILE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1222 */     if (this.closed)
/*      */     {
/* 1224 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1225 */       ((SQLException)localObject).fillInStackTrace();
/* 1226 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1229 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1232 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1233 */       ((SQLException)localObject).fillInStackTrace();
/* 1234 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1238 */     Object localObject = null;
/* 1239 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1244 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1245 */       localSQLException.fillInStackTrace();
/* 1246 */       throw localSQLException;
/*      */     }
/*      */     
/* 1249 */     this.lastIndex = paramInt;
/*      */     
/* 1251 */     if (this.streamList != null) {
/* 1252 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1255 */     return ((Accessor)localObject).getBFILE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BFILE getBfile(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1265 */     if (this.closed)
/*      */     {
/* 1267 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1268 */       ((SQLException)localObject).fillInStackTrace();
/* 1269 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1272 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1275 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1276 */       ((SQLException)localObject).fillInStackTrace();
/* 1277 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1281 */     Object localObject = null;
/* 1282 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1287 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1288 */       localSQLException.fillInStackTrace();
/* 1289 */       throw localSQLException;
/*      */     }
/*      */     
/* 1292 */     this.lastIndex = paramInt;
/*      */     
/* 1294 */     if (this.streamList != null) {
/* 1295 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1298 */     return ((Accessor)localObject).getBFILE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1308 */     if (this.closed)
/*      */     {
/* 1310 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1311 */       ((SQLException)localObject).fillInStackTrace();
/* 1312 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1315 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1318 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1319 */       ((SQLException)localObject).fillInStackTrace();
/* 1320 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1324 */     Object localObject = null;
/* 1325 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1330 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1331 */       localSQLException.fillInStackTrace();
/* 1332 */       throw localSQLException;
/*      */     }
/*      */     
/* 1335 */     this.lastIndex = paramInt;
/*      */     
/* 1337 */     if (this.streamList != null) {
/* 1338 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1341 */     return ((Accessor)localObject).getBoolean(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1351 */     if (this.closed)
/*      */     {
/* 1353 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1354 */       ((SQLException)localObject).fillInStackTrace();
/* 1355 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1358 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1361 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1362 */       ((SQLException)localObject).fillInStackTrace();
/* 1363 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1367 */     Object localObject = null;
/* 1368 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1373 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1374 */       localSQLException.fillInStackTrace();
/* 1375 */       throw localSQLException;
/*      */     }
/*      */     
/* 1378 */     this.lastIndex = paramInt;
/*      */     
/* 1380 */     if (this.streamList != null) {
/* 1381 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1384 */     return ((Accessor)localObject).getByte(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1394 */     if (this.closed)
/*      */     {
/* 1396 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1397 */       ((SQLException)localObject).fillInStackTrace();
/* 1398 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1401 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1404 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1405 */       ((SQLException)localObject).fillInStackTrace();
/* 1406 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1410 */     Object localObject = null;
/* 1411 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1416 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1417 */       localSQLException.fillInStackTrace();
/* 1418 */       throw localSQLException;
/*      */     }
/*      */     
/* 1421 */     this.lastIndex = paramInt;
/*      */     
/* 1423 */     if (this.streamList != null) {
/* 1424 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1427 */     return ((Accessor)localObject).getShort(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1437 */     if (this.closed)
/*      */     {
/* 1439 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1440 */       ((SQLException)localObject).fillInStackTrace();
/* 1441 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1444 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1447 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1448 */       ((SQLException)localObject).fillInStackTrace();
/* 1449 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1453 */     Object localObject = null;
/* 1454 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1459 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1460 */       localSQLException.fillInStackTrace();
/* 1461 */       throw localSQLException;
/*      */     }
/*      */     
/* 1464 */     this.lastIndex = paramInt;
/*      */     
/* 1466 */     if (this.streamList != null) {
/* 1467 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1470 */     return ((Accessor)localObject).getInt(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1480 */     if (this.closed)
/*      */     {
/* 1482 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1483 */       ((SQLException)localObject).fillInStackTrace();
/* 1484 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1487 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1490 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1491 */       ((SQLException)localObject).fillInStackTrace();
/* 1492 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1496 */     Object localObject = null;
/* 1497 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1502 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1503 */       localSQLException.fillInStackTrace();
/* 1504 */       throw localSQLException;
/*      */     }
/*      */     
/* 1507 */     this.lastIndex = paramInt;
/*      */     
/* 1509 */     if (this.streamList != null) {
/* 1510 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1513 */     return ((Accessor)localObject).getLong(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1523 */     if (this.closed)
/*      */     {
/* 1525 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1526 */       ((SQLException)localObject).fillInStackTrace();
/* 1527 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1530 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1533 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1534 */       ((SQLException)localObject).fillInStackTrace();
/* 1535 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1539 */     Object localObject = null;
/* 1540 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1545 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1546 */       localSQLException.fillInStackTrace();
/* 1547 */       throw localSQLException;
/*      */     }
/*      */     
/* 1550 */     this.lastIndex = paramInt;
/*      */     
/* 1552 */     if (this.streamList != null) {
/* 1553 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1556 */     return ((Accessor)localObject).getFloat(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1566 */     if (this.closed)
/*      */     {
/* 1568 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1569 */       ((SQLException)localObject).fillInStackTrace();
/* 1570 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1573 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1576 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1577 */       ((SQLException)localObject).fillInStackTrace();
/* 1578 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1582 */     Object localObject = null;
/* 1583 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1588 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1589 */       localSQLException.fillInStackTrace();
/* 1590 */       throw localSQLException;
/*      */     }
/*      */     
/* 1593 */     this.lastIndex = paramInt;
/*      */     
/* 1595 */     if (this.streamList != null) {
/* 1596 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1599 */     return ((Accessor)localObject).getDouble(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1609 */     if (this.closed)
/*      */     {
/* 1611 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1612 */       ((SQLException)localObject).fillInStackTrace();
/* 1613 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1616 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1619 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1620 */       ((SQLException)localObject).fillInStackTrace();
/* 1621 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1625 */     Object localObject = null;
/* 1626 */     if ((paramInt1 <= 0) || (paramInt1 > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt1 - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1631 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1632 */       localSQLException.fillInStackTrace();
/* 1633 */       throw localSQLException;
/*      */     }
/*      */     
/* 1636 */     this.lastIndex = paramInt1;
/*      */     
/* 1638 */     if (this.streamList != null) {
/* 1639 */       closeUsedStreams(paramInt1);
/*      */     }
/*      */     
/* 1642 */     return ((Accessor)localObject).getBigDecimal(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1652 */     if (this.closed)
/*      */     {
/* 1654 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1655 */       ((SQLException)localObject).fillInStackTrace();
/* 1656 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1659 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1662 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1663 */       ((SQLException)localObject).fillInStackTrace();
/* 1664 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1668 */     Object localObject = null;
/* 1669 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1674 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1675 */       localSQLException.fillInStackTrace();
/* 1676 */       throw localSQLException;
/*      */     }
/*      */     
/* 1679 */     this.lastIndex = paramInt;
/*      */     
/* 1681 */     if (this.streamList != null) {
/* 1682 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1685 */     return ((Accessor)localObject).getBytes(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] privateGetBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1695 */     if (this.closed)
/*      */     {
/* 1697 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1698 */       ((SQLException)localObject).fillInStackTrace();
/* 1699 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1702 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1705 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1706 */       ((SQLException)localObject).fillInStackTrace();
/* 1707 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1711 */     Object localObject = null;
/* 1712 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1717 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1718 */       localSQLException.fillInStackTrace();
/* 1719 */       throw localSQLException;
/*      */     }
/*      */     
/* 1722 */     this.lastIndex = paramInt;
/*      */     
/* 1724 */     if (this.streamList != null) {
/* 1725 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1728 */     return ((Accessor)localObject).privateGetBytes(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1738 */     if (this.closed)
/*      */     {
/* 1740 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1741 */       ((SQLException)localObject).fillInStackTrace();
/* 1742 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1745 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1748 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1749 */       ((SQLException)localObject).fillInStackTrace();
/* 1750 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1754 */     Object localObject = null;
/* 1755 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1760 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1761 */       localSQLException.fillInStackTrace();
/* 1762 */       throw localSQLException;
/*      */     }
/*      */     
/* 1765 */     this.lastIndex = paramInt;
/*      */     
/* 1767 */     if (this.streamList != null) {
/* 1768 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1771 */     return ((Accessor)localObject).getDate(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1781 */     if (this.closed)
/*      */     {
/* 1783 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1784 */       ((SQLException)localObject).fillInStackTrace();
/* 1785 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1788 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1791 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1792 */       ((SQLException)localObject).fillInStackTrace();
/* 1793 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1797 */     Object localObject = null;
/* 1798 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1803 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1804 */       localSQLException.fillInStackTrace();
/* 1805 */       throw localSQLException;
/*      */     }
/*      */     
/* 1808 */     this.lastIndex = paramInt;
/*      */     
/* 1810 */     if (this.streamList != null) {
/* 1811 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1814 */     return ((Accessor)localObject).getTime(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1824 */     if (this.closed)
/*      */     {
/* 1826 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1827 */       ((SQLException)localObject).fillInStackTrace();
/* 1828 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1831 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1834 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1835 */       ((SQLException)localObject).fillInStackTrace();
/* 1836 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1840 */     Object localObject = null;
/* 1841 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1846 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1847 */       localSQLException.fillInStackTrace();
/* 1848 */       throw localSQLException;
/*      */     }
/*      */     
/* 1851 */     this.lastIndex = paramInt;
/*      */     
/* 1853 */     if (this.streamList != null) {
/* 1854 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1857 */     return ((Accessor)localObject).getTimestamp(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1867 */     if (this.closed)
/*      */     {
/* 1869 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1870 */       ((SQLException)localObject).fillInStackTrace();
/* 1871 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1874 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1877 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1878 */       ((SQLException)localObject).fillInStackTrace();
/* 1879 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1883 */     Object localObject = null;
/* 1884 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1889 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1890 */       localSQLException.fillInStackTrace();
/* 1891 */       throw localSQLException;
/*      */     }
/*      */     
/* 1894 */     this.lastIndex = paramInt;
/*      */     
/* 1896 */     if (this.streamList != null) {
/* 1897 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1900 */     return ((Accessor)localObject).getAsciiStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1910 */     if (this.closed)
/*      */     {
/* 1912 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1913 */       ((SQLException)localObject).fillInStackTrace();
/* 1914 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1917 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1920 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1921 */       ((SQLException)localObject).fillInStackTrace();
/* 1922 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1926 */     Object localObject = null;
/* 1927 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1932 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1933 */       localSQLException.fillInStackTrace();
/* 1934 */       throw localSQLException;
/*      */     }
/*      */     
/* 1937 */     this.lastIndex = paramInt;
/*      */     
/* 1939 */     if (this.streamList != null) {
/* 1940 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1943 */     return ((Accessor)localObject).getUnicodeStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1953 */     if (this.closed)
/*      */     {
/* 1955 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1956 */       ((SQLException)localObject).fillInStackTrace();
/* 1957 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1960 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1963 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1964 */       ((SQLException)localObject).fillInStackTrace();
/* 1965 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1969 */     Object localObject = null;
/* 1970 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1975 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1976 */       localSQLException.fillInStackTrace();
/* 1977 */       throw localSQLException;
/*      */     }
/*      */     
/* 1980 */     this.lastIndex = paramInt;
/*      */     
/* 1982 */     if (this.streamList != null) {
/* 1983 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1986 */     return ((Accessor)localObject).getBinaryStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1996 */     if (this.closed)
/*      */     {
/* 1998 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1999 */       ((SQLException)localObject).fillInStackTrace();
/* 2000 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2003 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2006 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2007 */       ((SQLException)localObject).fillInStackTrace();
/* 2008 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2012 */     Object localObject = null;
/* 2013 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2018 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2019 */       localSQLException.fillInStackTrace();
/* 2020 */       throw localSQLException;
/*      */     }
/*      */     
/* 2023 */     this.lastIndex = paramInt;
/*      */     
/* 2025 */     if (this.streamList != null) {
/* 2026 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2029 */     return ((Accessor)localObject).getObject(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAnyDataEmbeddedObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2038 */     Object localObject1 = null;
/* 2039 */     Object localObject2 = getObject(paramInt);
/* 2040 */     if ((localObject2 instanceof ANYDATA))
/*      */     {
/* 2042 */       Datum localDatum = ((ANYDATA)localObject2).accessDatum();
/* 2043 */       if (localDatum != null) localObject1 = localDatum.toJdbc();
/*      */     }
/* 2045 */     return localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/* 2055 */     if (this.closed)
/*      */     {
/* 2057 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2058 */       ((SQLException)localObject).fillInStackTrace();
/* 2059 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2062 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2065 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2066 */       ((SQLException)localObject).fillInStackTrace();
/* 2067 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2071 */     Object localObject = null;
/* 2072 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2077 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2078 */       localSQLException.fillInStackTrace();
/* 2079 */       throw localSQLException;
/*      */     }
/*      */     
/* 2082 */     this.lastIndex = paramInt;
/*      */     
/* 2084 */     if (this.streamList != null) {
/* 2085 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2088 */     return ((Accessor)localObject).getCustomDatum(this.currentRank, paramCustomDatumFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory)
/*      */     throws SQLException
/*      */   {
/* 2097 */     if (this.closed)
/*      */     {
/* 2099 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2100 */       ((SQLException)localObject).fillInStackTrace();
/* 2101 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2104 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2107 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2108 */       ((SQLException)localObject).fillInStackTrace();
/* 2109 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2113 */     Object localObject = null;
/* 2114 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2119 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2120 */       localSQLException.fillInStackTrace();
/* 2121 */       throw localSQLException;
/*      */     }
/*      */     
/* 2124 */     this.lastIndex = paramInt;
/*      */     
/* 2126 */     if (this.streamList != null) {
/* 2127 */       closeUsedStreams(paramInt);
/*      */     }
/* 2129 */     return ((Accessor)localObject).getObject(this.currentRank, paramOracleDataFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/* 2139 */     if (this.closed)
/*      */     {
/* 2141 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2142 */       ((SQLException)localObject).fillInStackTrace();
/* 2143 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2146 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2149 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2150 */       ((SQLException)localObject).fillInStackTrace();
/* 2151 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2155 */     Object localObject = null;
/* 2156 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2161 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2162 */       localSQLException.fillInStackTrace();
/* 2163 */       throw localSQLException;
/*      */     }
/*      */     
/* 2166 */     this.lastIndex = paramInt;
/*      */     
/* 2168 */     if (this.streamList != null) {
/* 2169 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2172 */     return ((Accessor)localObject).getORAData(this.currentRank, paramORADataFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCursor(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2182 */     if (this.closed)
/*      */     {
/* 2184 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2185 */       ((SQLException)localObject).fillInStackTrace();
/* 2186 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2189 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2192 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2193 */       ((SQLException)localObject).fillInStackTrace();
/* 2194 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2198 */     Object localObject = null;
/* 2199 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2204 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2205 */       localSQLException.fillInStackTrace();
/* 2206 */       throw localSQLException;
/*      */     }
/*      */     
/* 2209 */     this.lastIndex = paramInt;
/*      */     
/* 2211 */     if (this.streamList != null) {
/* 2212 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2215 */     return ((Accessor)localObject).getCursor(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/* 2222 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2225 */       super.clearParameters();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 2246 */     if (this.closed)
/*      */     {
/* 2248 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2249 */       ((SQLException)localObject).fillInStackTrace();
/* 2250 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2253 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2256 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2257 */       ((SQLException)localObject).fillInStackTrace();
/* 2258 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2262 */     Object localObject = null;
/* 2263 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2268 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2269 */       localSQLException.fillInStackTrace();
/* 2270 */       throw localSQLException;
/*      */     }
/*      */     
/* 2273 */     this.lastIndex = paramInt;
/*      */     
/* 2275 */     if (this.streamList != null) {
/* 2276 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2279 */     return ((Accessor)localObject).getObject(this.currentRank, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2289 */     if (this.closed)
/*      */     {
/* 2291 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2292 */       ((SQLException)localObject).fillInStackTrace();
/* 2293 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2296 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2299 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2300 */       ((SQLException)localObject).fillInStackTrace();
/* 2301 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2305 */     Object localObject = null;
/* 2306 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2311 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2312 */       localSQLException.fillInStackTrace();
/* 2313 */       throw localSQLException;
/*      */     }
/*      */     
/* 2316 */     this.lastIndex = paramInt;
/*      */     
/* 2318 */     if (this.streamList != null) {
/* 2319 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2322 */     return ((Accessor)localObject).getREF(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2332 */     if (this.closed)
/*      */     {
/* 2334 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2335 */       ((SQLException)localObject).fillInStackTrace();
/* 2336 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2339 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2342 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2343 */       ((SQLException)localObject).fillInStackTrace();
/* 2344 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2348 */     Object localObject = null;
/* 2349 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2354 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2355 */       localSQLException.fillInStackTrace();
/* 2356 */       throw localSQLException;
/*      */     }
/*      */     
/* 2359 */     this.lastIndex = paramInt;
/*      */     
/* 2361 */     if (this.streamList != null) {
/* 2362 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2365 */     return ((Accessor)localObject).getBLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2375 */     if (this.closed)
/*      */     {
/* 2377 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2378 */       ((SQLException)localObject).fillInStackTrace();
/* 2379 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2382 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2385 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2386 */       ((SQLException)localObject).fillInStackTrace();
/* 2387 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2391 */     Object localObject = null;
/* 2392 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2397 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2398 */       localSQLException.fillInStackTrace();
/* 2399 */       throw localSQLException;
/*      */     }
/*      */     
/* 2402 */     this.lastIndex = paramInt;
/*      */     
/* 2404 */     if (this.streamList != null) {
/* 2405 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2408 */     return ((Accessor)localObject).getCLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2418 */     if (this.closed)
/*      */     {
/* 2420 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2421 */       ((SQLException)localObject).fillInStackTrace();
/* 2422 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2425 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2428 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2429 */       ((SQLException)localObject).fillInStackTrace();
/* 2430 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2434 */     Object localObject = null;
/* 2435 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2440 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2441 */       localSQLException.fillInStackTrace();
/* 2442 */       throw localSQLException;
/*      */     }
/*      */     
/* 2445 */     this.lastIndex = paramInt;
/*      */     
/* 2447 */     if (this.streamList != null) {
/* 2448 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2451 */     return ((Accessor)localObject).getARRAY(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2461 */     if (this.closed)
/*      */     {
/* 2463 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2464 */       ((SQLException)localObject).fillInStackTrace();
/* 2465 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2468 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2471 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2472 */       ((SQLException)localObject).fillInStackTrace();
/* 2473 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2477 */     Object localObject = null;
/* 2478 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2483 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2484 */       localSQLException.fillInStackTrace();
/* 2485 */       throw localSQLException;
/*      */     }
/*      */     
/* 2488 */     this.lastIndex = paramInt;
/*      */     
/* 2490 */     if (this.streamList != null) {
/* 2491 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2494 */     return ((Accessor)localObject).getBigDecimal(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2504 */     if (this.closed)
/*      */     {
/* 2506 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2507 */       ((SQLException)localObject).fillInStackTrace();
/* 2508 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2511 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2514 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2515 */       ((SQLException)localObject).fillInStackTrace();
/* 2516 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2520 */     Object localObject = null;
/* 2521 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2526 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2527 */       localSQLException.fillInStackTrace();
/* 2528 */       throw localSQLException;
/*      */     }
/*      */     
/* 2531 */     this.lastIndex = paramInt;
/*      */     
/* 2533 */     if (this.streamList != null) {
/* 2534 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2537 */     return ((Accessor)localObject).getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2547 */     if (this.closed)
/*      */     {
/* 2549 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2550 */       ((SQLException)localObject).fillInStackTrace();
/* 2551 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2554 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2557 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2558 */       ((SQLException)localObject).fillInStackTrace();
/* 2559 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2563 */     Object localObject = null;
/* 2564 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2569 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2570 */       localSQLException.fillInStackTrace();
/* 2571 */       throw localSQLException;
/*      */     }
/*      */     
/* 2574 */     this.lastIndex = paramInt;
/*      */     
/* 2576 */     if (this.streamList != null) {
/* 2577 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2580 */     return ((Accessor)localObject).getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2590 */     if (this.closed)
/*      */     {
/* 2592 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2593 */       ((SQLException)localObject).fillInStackTrace();
/* 2594 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2597 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2600 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2601 */       ((SQLException)localObject).fillInStackTrace();
/* 2602 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2606 */     Object localObject = null;
/* 2607 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2612 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2613 */       localSQLException.fillInStackTrace();
/* 2614 */       throw localSQLException;
/*      */     }
/*      */     
/* 2617 */     this.lastIndex = paramInt;
/*      */     
/* 2619 */     if (this.streamList != null) {
/* 2620 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2623 */     return ((Accessor)localObject).getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/* 2669 */     if (this.currentRowBindAccessors != null)
/*      */     {
/*      */ 
/* 2672 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
/* 2673 */       localSQLException.fillInStackTrace();
/* 2674 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 2678 */     super.addBatch();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void alwaysOnClose()
/*      */     throws SQLException
/*      */   {
/* 2688 */     this.sqlObject.resetNamedParameters();
/*      */     
/*      */ 
/* 2691 */     this.namedParameters = new String[8];
/* 2692 */     this.parameterCount = 0;
/* 2693 */     this.atLeastOneOrdinalParameter = false;
/* 2694 */     this.atLeastOneNamedParameter = false;
/*      */     
/* 2696 */     super.alwaysOnClose();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2733 */     registerOutParameterInternal(paramString, paramInt, 0, -1, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2766 */     registerOutParameterInternal(paramString, paramInt1, paramInt2, -1, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 2811 */     registerOutParameterInternal(paramString1, paramInt, 0, -1, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void registerOutParameterInternal(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 2819 */     int i = addNamedPara(paramString1);
/* 2820 */     registerOutParameterInternal(i, paramInt1, paramInt2, paramInt3, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2845 */     if (this.closed)
/*      */     {
/* 2847 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2848 */       ((SQLException)localObject).fillInStackTrace();
/* 2849 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2852 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2855 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2856 */       ((SQLException)localObject).fillInStackTrace();
/* 2857 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2861 */     Object localObject = null;
/* 2862 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2867 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2868 */       localSQLException.fillInStackTrace();
/* 2869 */       throw localSQLException;
/*      */     }
/*      */     
/* 2872 */     this.lastIndex = paramInt;
/*      */     
/* 2874 */     if (this.streamList != null) {
/* 2875 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2878 */     return ((Accessor)localObject).getURL(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStringForClob(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 2905 */     int i = addNamedPara(paramString1);
/* 2906 */     if ((paramString2 == null) || (paramString2.length() == 0))
/*      */     {
/* 2908 */       setNull(i, 2005);
/* 2909 */       return;
/*      */     }
/* 2911 */     setStringForClob(i, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStringForClob(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2930 */     if ((paramString == null) || (paramString.length() == 0))
/*      */     {
/* 2932 */       setNull(paramInt, 2005);
/* 2933 */       return;
/*      */     }
/* 2935 */     synchronized (this.connection) {
/* 2936 */       setStringForClobCritical(paramInt, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2961 */     int i = addNamedPara(paramString);
/* 2962 */     setBytesForBlob(i, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2980 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0))
/*      */     {
/* 2982 */       setNull(paramInt, 2004);
/* 2983 */       return;
/*      */     }
/* 2985 */     synchronized (this.connection) {
/* 2986 */       setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3015 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3018 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3019 */       ((SQLException)localObject).fillInStackTrace();
/* 3020 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3024 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3027 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3029 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3032 */     i++;
/*      */     
/* 3034 */     Accessor localAccessor = null;
/* 3035 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3040 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3041 */       localSQLException.fillInStackTrace();
/* 3042 */       throw localSQLException;
/*      */     }
/*      */     
/* 3045 */     this.lastIndex = i;
/*      */     
/* 3047 */     if (this.streamList != null) {
/* 3048 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3051 */     return localAccessor.getString(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3072 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3075 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3076 */       ((SQLException)localObject).fillInStackTrace();
/* 3077 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3081 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3084 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3086 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3089 */     i++;
/*      */     
/* 3091 */     Accessor localAccessor = null;
/* 3092 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3097 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3098 */       localSQLException.fillInStackTrace();
/* 3099 */       throw localSQLException;
/*      */     }
/*      */     
/* 3102 */     this.lastIndex = i;
/*      */     
/* 3104 */     if (this.streamList != null) {
/* 3105 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3108 */     return localAccessor.getBoolean(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3129 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3132 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3133 */       ((SQLException)localObject).fillInStackTrace();
/* 3134 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3138 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3141 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3143 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3146 */     i++;
/*      */     
/* 3148 */     Accessor localAccessor = null;
/* 3149 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3154 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3155 */       localSQLException.fillInStackTrace();
/* 3156 */       throw localSQLException;
/*      */     }
/*      */     
/* 3159 */     this.lastIndex = i;
/*      */     
/* 3161 */     if (this.streamList != null) {
/* 3162 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3165 */     return localAccessor.getByte(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3186 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3189 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3190 */       ((SQLException)localObject).fillInStackTrace();
/* 3191 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3195 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3198 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3200 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3203 */     i++;
/*      */     
/* 3205 */     Accessor localAccessor = null;
/* 3206 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3211 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3212 */       localSQLException.fillInStackTrace();
/* 3213 */       throw localSQLException;
/*      */     }
/*      */     
/* 3216 */     this.lastIndex = i;
/*      */     
/* 3218 */     if (this.streamList != null) {
/* 3219 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3222 */     return localAccessor.getShort(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3244 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3247 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3248 */       ((SQLException)localObject).fillInStackTrace();
/* 3249 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3253 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3256 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3258 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3261 */     i++;
/*      */     
/* 3263 */     Accessor localAccessor = null;
/* 3264 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3269 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3270 */       localSQLException.fillInStackTrace();
/* 3271 */       throw localSQLException;
/*      */     }
/*      */     
/* 3274 */     this.lastIndex = i;
/*      */     
/* 3276 */     if (this.streamList != null) {
/* 3277 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3280 */     return localAccessor.getInt(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3302 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3305 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3306 */       ((SQLException)localObject).fillInStackTrace();
/* 3307 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3311 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3314 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3316 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3319 */     i++;
/*      */     
/* 3321 */     Accessor localAccessor = null;
/* 3322 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3327 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3328 */       localSQLException.fillInStackTrace();
/* 3329 */       throw localSQLException;
/*      */     }
/*      */     
/* 3332 */     this.lastIndex = i;
/*      */     
/* 3334 */     if (this.streamList != null) {
/* 3335 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3338 */     return localAccessor.getLong(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3359 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3362 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3363 */       ((SQLException)localObject).fillInStackTrace();
/* 3364 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3368 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3371 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3373 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3376 */     i++;
/*      */     
/* 3378 */     Accessor localAccessor = null;
/* 3379 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3384 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3385 */       localSQLException.fillInStackTrace();
/* 3386 */       throw localSQLException;
/*      */     }
/*      */     
/* 3389 */     this.lastIndex = i;
/*      */     
/* 3391 */     if (this.streamList != null) {
/* 3392 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3395 */     return localAccessor.getFloat(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3416 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3419 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3420 */       ((SQLException)localObject).fillInStackTrace();
/* 3421 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3425 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3428 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3430 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3433 */     i++;
/*      */     
/* 3435 */     Accessor localAccessor = null;
/* 3436 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3441 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3442 */       localSQLException.fillInStackTrace();
/* 3443 */       throw localSQLException;
/*      */     }
/*      */     
/* 3446 */     this.lastIndex = i;
/*      */     
/* 3448 */     if (this.streamList != null) {
/* 3449 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3452 */     return localAccessor.getDouble(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3474 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3477 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3478 */       ((SQLException)localObject).fillInStackTrace();
/* 3479 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3483 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3486 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3488 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3491 */     i++;
/*      */     
/* 3493 */     Accessor localAccessor = null;
/* 3494 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3499 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3500 */       localSQLException.fillInStackTrace();
/* 3501 */       throw localSQLException;
/*      */     }
/*      */     
/* 3504 */     this.lastIndex = i;
/*      */     
/* 3506 */     if (this.streamList != null) {
/* 3507 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3510 */     return localAccessor.getBytes(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3531 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3534 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3535 */       ((SQLException)localObject).fillInStackTrace();
/* 3536 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3540 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3543 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3545 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3548 */     i++;
/*      */     
/* 3550 */     Accessor localAccessor = null;
/* 3551 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3556 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3557 */       localSQLException.fillInStackTrace();
/* 3558 */       throw localSQLException;
/*      */     }
/*      */     
/* 3561 */     this.lastIndex = i;
/*      */     
/* 3563 */     if (this.streamList != null) {
/* 3564 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3567 */     return localAccessor.getDate(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3588 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3591 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3592 */       ((SQLException)localObject).fillInStackTrace();
/* 3593 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3597 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3600 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3602 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3605 */     i++;
/*      */     
/* 3607 */     Accessor localAccessor = null;
/* 3608 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3613 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3614 */       localSQLException.fillInStackTrace();
/* 3615 */       throw localSQLException;
/*      */     }
/*      */     
/* 3618 */     this.lastIndex = i;
/*      */     
/* 3620 */     if (this.streamList != null) {
/* 3621 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3624 */     return localAccessor.getTime(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3645 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3648 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3649 */       ((SQLException)localObject).fillInStackTrace();
/* 3650 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3654 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3657 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3659 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3662 */     i++;
/*      */     
/* 3664 */     Accessor localAccessor = null;
/* 3665 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3670 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3671 */       localSQLException.fillInStackTrace();
/* 3672 */       throw localSQLException;
/*      */     }
/*      */     
/* 3675 */     this.lastIndex = i;
/*      */     
/* 3677 */     if (this.streamList != null) {
/* 3678 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3681 */     return localAccessor.getTimestamp(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3709 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3712 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3713 */       ((SQLException)localObject).fillInStackTrace();
/* 3714 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3718 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3721 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3723 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3726 */     i++;
/*      */     
/* 3728 */     Accessor localAccessor = null;
/* 3729 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3734 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3735 */       localSQLException.fillInStackTrace();
/* 3736 */       throw localSQLException;
/*      */     }
/*      */     
/* 3739 */     this.lastIndex = i;
/*      */     
/* 3741 */     if (this.streamList != null) {
/* 3742 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3745 */     return localAccessor.getObject(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3767 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3770 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3771 */       ((SQLException)localObject).fillInStackTrace();
/* 3772 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3776 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3779 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3781 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3784 */     i++;
/*      */     
/* 3786 */     Accessor localAccessor = null;
/* 3787 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3792 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3793 */       localSQLException.fillInStackTrace();
/* 3794 */       throw localSQLException;
/*      */     }
/*      */     
/* 3797 */     this.lastIndex = i;
/*      */     
/* 3799 */     if (this.streamList != null) {
/* 3800 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3803 */     return localAccessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3812 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3815 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3816 */       ((SQLException)localObject).fillInStackTrace();
/* 3817 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3821 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3824 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3826 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3829 */     i++;
/*      */     
/* 3831 */     Accessor localAccessor = null;
/* 3832 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3837 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3838 */       localSQLException.fillInStackTrace();
/* 3839 */       throw localSQLException;
/*      */     }
/*      */     
/* 3842 */     this.lastIndex = i;
/*      */     
/* 3844 */     if (this.streamList != null) {
/* 3845 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3848 */     return localAccessor.getBigDecimal(this.currentRank, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String paramString, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 3876 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3879 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3880 */       ((SQLException)localObject).fillInStackTrace();
/* 3881 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3885 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3888 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3890 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3893 */     i++;
/*      */     
/* 3895 */     Accessor localAccessor = null;
/* 3896 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3901 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3902 */       localSQLException.fillInStackTrace();
/* 3903 */       throw localSQLException;
/*      */     }
/*      */     
/* 3906 */     this.lastIndex = i;
/*      */     
/* 3908 */     if (this.streamList != null) {
/* 3909 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3912 */     return localAccessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3934 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3937 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3938 */       ((SQLException)localObject).fillInStackTrace();
/* 3939 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3943 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3946 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3948 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3951 */     i++;
/*      */     
/* 3953 */     Accessor localAccessor = null;
/* 3954 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3959 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3960 */       localSQLException.fillInStackTrace();
/* 3961 */       throw localSQLException;
/*      */     }
/*      */     
/* 3964 */     this.lastIndex = i;
/*      */     
/* 3966 */     if (this.streamList != null) {
/* 3967 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3970 */     return localAccessor.getREF(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3992 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3995 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3996 */       ((SQLException)localObject).fillInStackTrace();
/* 3997 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4001 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4004 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4006 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4009 */     i++;
/*      */     
/* 4011 */     Accessor localAccessor = null;
/* 4012 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4017 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4018 */       localSQLException.fillInStackTrace();
/* 4019 */       throw localSQLException;
/*      */     }
/*      */     
/* 4022 */     this.lastIndex = i;
/*      */     
/* 4024 */     if (this.streamList != null) {
/* 4025 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4028 */     return localAccessor.getBLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4049 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4052 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4053 */       ((SQLException)localObject).fillInStackTrace();
/* 4054 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4058 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4061 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4063 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4066 */     i++;
/*      */     
/* 4068 */     Accessor localAccessor = null;
/* 4069 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4074 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4075 */       localSQLException.fillInStackTrace();
/* 4076 */       throw localSQLException;
/*      */     }
/*      */     
/* 4079 */     this.lastIndex = i;
/*      */     
/* 4081 */     if (this.streamList != null) {
/* 4082 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4085 */     return localAccessor.getCLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4107 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4110 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4111 */       ((SQLException)localObject).fillInStackTrace();
/* 4112 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4116 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4119 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4121 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4124 */     i++;
/*      */     
/* 4126 */     Accessor localAccessor = null;
/* 4127 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4132 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4133 */       localSQLException.fillInStackTrace();
/* 4134 */       throw localSQLException;
/*      */     }
/*      */     
/* 4137 */     this.lastIndex = i;
/*      */     
/* 4139 */     if (this.streamList != null) {
/* 4140 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4143 */     return localAccessor.getARRAY(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4173 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4176 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4177 */       ((SQLException)localObject).fillInStackTrace();
/* 4178 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4182 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4185 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4187 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4190 */     i++;
/*      */     
/* 4192 */     Accessor localAccessor = null;
/* 4193 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4198 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4199 */       localSQLException.fillInStackTrace();
/* 4200 */       throw localSQLException;
/*      */     }
/*      */     
/* 4203 */     this.lastIndex = i;
/*      */     
/* 4205 */     if (this.streamList != null) {
/* 4206 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4209 */     return localAccessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4239 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4242 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4243 */       ((SQLException)localObject).fillInStackTrace();
/* 4244 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4248 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4251 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4253 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4256 */     i++;
/*      */     
/* 4258 */     Accessor localAccessor = null;
/* 4259 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4264 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4265 */       localSQLException.fillInStackTrace();
/* 4266 */       throw localSQLException;
/*      */     }
/*      */     
/* 4269 */     this.lastIndex = i;
/*      */     
/* 4271 */     if (this.streamList != null) {
/* 4272 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4275 */     return localAccessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4306 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4309 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4310 */       ((SQLException)localObject).fillInStackTrace();
/* 4311 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4315 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4318 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4320 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4323 */     i++;
/*      */     
/* 4325 */     Accessor localAccessor = null;
/* 4326 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4331 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4332 */       localSQLException.fillInStackTrace();
/* 4333 */       throw localSQLException;
/*      */     }
/*      */     
/* 4336 */     this.lastIndex = i;
/*      */     
/* 4338 */     if (this.streamList != null) {
/* 4339 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4342 */     return localAccessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4366 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4369 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4370 */       ((SQLException)localObject).fillInStackTrace();
/* 4371 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4375 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4378 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4380 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4383 */     i++;
/*      */     
/* 4385 */     Accessor localAccessor = null;
/* 4386 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4391 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4392 */       localSQLException.fillInStackTrace();
/* 4393 */       throw localSQLException;
/*      */     }
/*      */     
/* 4396 */     this.lastIndex = i;
/*      */     
/* 4398 */     if (this.streamList != null) {
/* 4399 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4402 */     return localAccessor.getURL(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public InputStream getAsciiStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4412 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 4413 */     localSQLException.fillInStackTrace();
/* 4414 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/* 4453 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 4456 */       int i = paramInt1 - 1;
/* 4457 */       if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*      */       {
/* 4459 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4460 */         localSQLException.fillInStackTrace();
/* 4461 */         throw localSQLException;
/*      */       }
/*      */       
/* 4464 */       int j = getInternalType(paramInt3);
/*      */       
/* 4466 */       resetBatch();
/* 4467 */       this.currentRowNeedToPrepareBinds = true;
/*      */       
/* 4469 */       if (this.currentRowBindAccessors == null) {
/* 4470 */         this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */       }
/* 4472 */       this.currentRowBindAccessors[i] = allocateIndexTableAccessor(paramInt3, j, paramInt4, paramInt2, this.currentRowFormOfUse[i], true);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4480 */       this.hasIbtBind = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 4497 */     return new PlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getPlsqlIndexTable(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4521 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 4524 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4526 */       PlsqlIndexTableAccessor localPlsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[(paramInt - 1)];
/*      */       
/*      */ 
/* 4529 */       int i = localPlsqlIndexTableAccessor.elementInternalType;
/*      */       
/* 4531 */       Object localObject1 = null;
/*      */       
/* 4533 */       switch (i)
/*      */       {
/*      */       case 9: 
/* 4536 */         localObject1 = new String[arrayOfDatum.length];
/* 4537 */         break;
/*      */       case 6: 
/* 4539 */         localObject1 = new BigDecimal[arrayOfDatum.length];
/* 4540 */         break;
/*      */       
/*      */       default: 
/* 4543 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
/* 4544 */         localSQLException.fillInStackTrace();
/* 4545 */         throw localSQLException;
/*      */       }
/*      */       
/*      */       
/* 4549 */       for (int j = 0; j < localObject1.length; j++) {
/* 4550 */         localObject1[j] = ((arrayOfDatum[j] != null) && (arrayOfDatum[j].getLength() != 0L) ? arrayOfDatum[j].toJdbc() : null);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4555 */       return localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass)
/*      */     throws SQLException
/*      */   {
/* 4575 */     synchronized (this.connection)
/*      */     {
/* 4577 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4579 */       if ((paramClass == null) || (!paramClass.isPrimitive()))
/*      */       {
/* 4581 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4582 */         ((SQLException)localObject1).fillInStackTrace();
/* 4583 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 4586 */       Object localObject1 = paramClass.getName();
/*      */       int i;
/* 4588 */       if (((String)localObject1).equals("byte"))
/*      */       {
/* 4590 */         localObject2 = new byte[arrayOfDatum.length];
/* 4591 */         for (i = 0; i < arrayOfDatum.length; i++)
/* 4592 */           localObject2[i] = (arrayOfDatum[i] != null ? arrayOfDatum[i].byteValue() : 0);
/* 4593 */         return localObject2;
/*      */       }
/* 4595 */       if (((String)localObject1).equals("char"))
/*      */       {
/* 4597 */         localObject2 = new char[arrayOfDatum.length];
/* 4598 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4599 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? (char)arrayOfDatum[i].intValue() : 0);
/*      */         }
/* 4601 */         return localObject2;
/*      */       }
/* 4603 */       if (((String)localObject1).equals("double"))
/*      */       {
/* 4605 */         localObject2 = new double[arrayOfDatum.length];
/* 4606 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4607 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].doubleValue() : 0.0D);
/*      */         }
/* 4609 */         return localObject2;
/*      */       }
/* 4611 */       if (((String)localObject1).equals("float"))
/*      */       {
/* 4613 */         localObject2 = new float[arrayOfDatum.length];
/* 4614 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4615 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].floatValue() : 0.0F);
/*      */         }
/* 4617 */         return localObject2;
/*      */       }
/* 4619 */       if (((String)localObject1).equals("int"))
/*      */       {
/* 4621 */         localObject2 = new int[arrayOfDatum.length];
/* 4622 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4623 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].intValue() : 0);
/*      */         }
/* 4625 */         return localObject2;
/*      */       }
/* 4627 */       if (((String)localObject1).equals("long"))
/*      */       {
/* 4629 */         localObject2 = new long[arrayOfDatum.length];
/* 4630 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4631 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].longValue() : 0L);
/*      */         }
/* 4633 */         return localObject2;
/*      */       }
/* 4635 */       if (((String)localObject1).equals("short"))
/*      */       {
/* 4637 */         localObject2 = new short[arrayOfDatum.length];
/* 4638 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4639 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? (short)arrayOfDatum[i].intValue() : 0);
/*      */         }
/* 4641 */         return localObject2;
/*      */       }
/* 4643 */       if (((String)localObject1).equals("boolean"))
/*      */       {
/* 4645 */         localObject2 = new boolean[arrayOfDatum.length];
/* 4646 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4647 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].booleanValue() : 0);
/*      */         }
/* 4649 */         return localObject2;
/*      */       }
/*      */       
/*      */ 
/* 4653 */       Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4654 */       ((SQLException)localObject2).fillInStackTrace();
/* 4655 */       throw ((Throwable)localObject2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4673 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4677 */       if (this.closed)
/*      */       {
/* 4679 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4680 */         ((SQLException)localObject1).fillInStackTrace();
/* 4681 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 4684 */       if (this.atLeastOneNamedParameter)
/*      */       {
/*      */ 
/* 4687 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4688 */         ((SQLException)localObject1).fillInStackTrace();
/* 4689 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*      */ 
/* 4693 */       Object localObject1 = null;
/* 4694 */       if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject1 = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 4699 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4700 */         localSQLException.fillInStackTrace();
/* 4701 */         throw localSQLException;
/*      */       }
/*      */       
/* 4704 */       this.lastIndex = paramInt;
/*      */       
/* 4706 */       if (this.streamList != null) {
/* 4707 */         closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 4710 */       return ((Accessor)localObject1).getOraclePlsqlIndexTable(this.currentRank);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/* 4725 */     synchronized (this.connection) {
/* 4726 */       ensureOpen();
/* 4727 */       if ((this.atLeastOneNamedParameter) && (this.atLeastOneOrdinalParameter))
/*      */       {
/* 4729 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4730 */         localSQLException.fillInStackTrace();
/* 4731 */         throw localSQLException;
/*      */       }
/* 4733 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4734 */         this.needToParse = true;
/* 4735 */       return super.execute();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/* 4749 */     synchronized (this.connection)
/*      */     {
/* 4751 */       ensureOpen();
/* 4752 */       if ((this.atLeastOneNamedParameter) && (this.atLeastOneOrdinalParameter))
/*      */       {
/* 4754 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4755 */         localSQLException.fillInStackTrace();
/* 4756 */         throw localSQLException;
/*      */       }
/* 4758 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4759 */         this.needToParse = true;
/* 4760 */       return super.executeUpdate();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/* 4767 */     if (this.outBindAccessors != null)
/*      */     {
/* 4769 */       int i = this.outBindAccessors.length;
/*      */       
/* 4771 */       for (int j = 0; j < i; j++)
/*      */       {
/* 4773 */         if (this.outBindAccessors[j] != null)
/*      */         {
/* 4775 */           this.outBindAccessors[j].rowSpaceByte = null;
/* 4776 */           this.outBindAccessors[j].rowSpaceChar = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4781 */     super.releaseBuffers();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void doLocalInitialization()
/*      */   {
/* 4788 */     if (this.outBindAccessors != null)
/*      */     {
/* 4790 */       int i = this.outBindAccessors.length;
/*      */       
/* 4792 */       for (int j = 0; j < i; j++)
/*      */       {
/* 4794 */         if (this.outBindAccessors[j] != null)
/*      */         {
/* 4796 */           this.outBindAccessors[j].rowSpaceByte = this.bindBytes;
/* 4797 */           this.outBindAccessors[j].rowSpaceChar = this.bindChars;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 4812 */     this.atLeastOneOrdinalParameter = true;
/* 4813 */     setArrayInternal(paramInt, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 4820 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4824 */       this.atLeastOneOrdinalParameter = true;
/* 4825 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 4833 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4837 */       this.atLeastOneOrdinalParameter = true;
/* 4838 */       setBlobInternal(paramInt, paramBlob);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 4846 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4850 */       this.atLeastOneOrdinalParameter = true;
/* 4851 */       setBooleanInternal(paramInt, paramBoolean);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 4859 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4863 */       this.atLeastOneOrdinalParameter = true;
/* 4864 */       setByteInternal(paramInt, paramByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 4872 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4876 */       this.atLeastOneOrdinalParameter = true;
/* 4877 */       setBytesInternal(paramInt, paramArrayOfByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 4885 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4889 */       this.atLeastOneOrdinalParameter = true;
/* 4890 */       setClobInternal(paramInt, paramClob);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDate(int paramInt, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 4898 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4902 */       this.atLeastOneOrdinalParameter = true;
/* 4903 */       setDateInternal(paramInt, paramDate);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4911 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4915 */       this.atLeastOneOrdinalParameter = true;
/* 4916 */       setDateInternal(paramInt, paramDate, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 4924 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4928 */       this.atLeastOneOrdinalParameter = true;
/* 4929 */       setDoubleInternal(paramInt, paramDouble);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 4937 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4941 */       this.atLeastOneOrdinalParameter = true;
/* 4942 */       setFloatInternal(paramInt, paramFloat);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 4950 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4954 */       this.atLeastOneOrdinalParameter = true;
/* 4955 */       setIntInternal(paramInt1, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 4963 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4967 */       this.atLeastOneOrdinalParameter = true;
/* 4968 */       setLongInternal(paramInt, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 4977 */     this.atLeastOneOrdinalParameter = true;
/* 4978 */     setObjectInternal(paramInt, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 4986 */     this.atLeastOneOrdinalParameter = true;
/* 4987 */     setObjectInternal(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 4995 */     this.atLeastOneOrdinalParameter = true;
/* 4996 */     setRefInternal(paramInt, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 5003 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5007 */       this.atLeastOneOrdinalParameter = true;
/* 5008 */       setShortInternal(paramInt, paramShort);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 5016 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5020 */       this.atLeastOneOrdinalParameter = true;
/* 5021 */       setStringInternal(paramInt, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 5029 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5033 */       this.atLeastOneOrdinalParameter = true;
/* 5034 */       setTimeInternal(paramInt, paramTime);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5042 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5046 */       this.atLeastOneOrdinalParameter = true;
/* 5047 */       setTimeInternal(paramInt, paramTime, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 5055 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5059 */       this.atLeastOneOrdinalParameter = true;
/* 5060 */       setTimestampInternal(paramInt, paramTimestamp);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5068 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5072 */       this.atLeastOneOrdinalParameter = true;
/* 5073 */       setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setURL(int paramInt, URL paramURL)
/*      */     throws SQLException
/*      */   {
/* 5081 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5085 */       this.atLeastOneOrdinalParameter = true;
/* 5086 */       setURLInternal(paramInt, paramURL);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY)
/*      */     throws SQLException
/*      */   {
/* 5095 */     this.atLeastOneOrdinalParameter = true;
/* 5096 */     setARRAYInternal(paramInt, paramARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 5103 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5107 */       this.atLeastOneOrdinalParameter = true;
/* 5108 */       setBFILEInternal(paramInt, paramBFILE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBfile(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 5116 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5120 */       this.atLeastOneOrdinalParameter = true;
/* 5121 */       setBfileInternal(paramInt, paramBFILE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 5129 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5133 */       this.atLeastOneOrdinalParameter = true;
/* 5134 */       setBinaryFloatInternal(paramInt, paramFloat);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT)
/*      */     throws SQLException
/*      */   {
/* 5142 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5146 */       this.atLeastOneOrdinalParameter = true;
/* 5147 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 5155 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5159 */       this.atLeastOneOrdinalParameter = true;
/* 5160 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE)
/*      */     throws SQLException
/*      */   {
/* 5168 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5172 */       this.atLeastOneOrdinalParameter = true;
/* 5173 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 5181 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5185 */       this.atLeastOneOrdinalParameter = true;
/* 5186 */       setBLOBInternal(paramInt, paramBLOB);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR)
/*      */     throws SQLException
/*      */   {
/* 5194 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5198 */       this.atLeastOneOrdinalParameter = true;
/* 5199 */       setCHARInternal(paramInt, paramCHAR);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 5207 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5211 */       this.atLeastOneOrdinalParameter = true;
/* 5212 */       setCLOBInternal(paramInt, paramCLOB);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet)
/*      */     throws SQLException
/*      */   {
/* 5220 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5224 */       this.atLeastOneOrdinalParameter = true;
/* 5225 */       setCursorInternal(paramInt, paramResultSet);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum)
/*      */     throws SQLException
/*      */   {
/* 5234 */     this.atLeastOneOrdinalParameter = true;
/* 5235 */     setCustomDatumInternal(paramInt, paramCustomDatum);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDATE(int paramInt, DATE paramDATE)
/*      */     throws SQLException
/*      */   {
/* 5242 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5246 */       this.atLeastOneOrdinalParameter = true;
/* 5247 */       setDATEInternal(paramInt, paramDATE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFixedCHAR(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 5255 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5259 */       this.atLeastOneOrdinalParameter = true;
/* 5260 */       setFixedCHARInternal(paramInt, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS)
/*      */     throws SQLException
/*      */   {
/* 5268 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5272 */       this.atLeastOneOrdinalParameter = true;
/* 5273 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM)
/*      */     throws SQLException
/*      */   {
/* 5281 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5285 */       this.atLeastOneOrdinalParameter = true;
/* 5286 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER)
/*      */     throws SQLException
/*      */   {
/* 5294 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5298 */       this.atLeastOneOrdinalParameter = true;
/* 5299 */       setNUMBERInternal(paramInt, paramNUMBER);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE)
/*      */     throws SQLException
/*      */   {
/* 5308 */     this.atLeastOneOrdinalParameter = true;
/* 5309 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOracleObject(int paramInt, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 5317 */     this.atLeastOneOrdinalParameter = true;
/* 5318 */     setOracleObjectInternal(paramInt, paramDatum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setORAData(int paramInt, ORAData paramORAData)
/*      */     throws SQLException
/*      */   {
/* 5326 */     this.atLeastOneOrdinalParameter = true;
/* 5327 */     setORADataInternal(paramInt, paramORAData);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setRAW(int paramInt, RAW paramRAW)
/*      */     throws SQLException
/*      */   {
/* 5334 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5338 */       this.atLeastOneOrdinalParameter = true;
/* 5339 */       setRAWInternal(paramInt, paramRAW);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setREF(int paramInt, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 5348 */     this.atLeastOneOrdinalParameter = true;
/* 5349 */     setREFInternal(paramInt, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRefType(int paramInt, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 5357 */     this.atLeastOneOrdinalParameter = true;
/* 5358 */     setRefTypeInternal(paramInt, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setROWID(int paramInt, ROWID paramROWID)
/*      */     throws SQLException
/*      */   {
/* 5365 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5369 */       this.atLeastOneOrdinalParameter = true;
/* 5370 */       setROWIDInternal(paramInt, paramROWID);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT)
/*      */     throws SQLException
/*      */   {
/* 5379 */     this.atLeastOneOrdinalParameter = true;
/* 5380 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*      */     throws SQLException
/*      */   {
/* 5387 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5391 */       this.atLeastOneOrdinalParameter = true;
/* 5392 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*      */     throws SQLException
/*      */   {
/* 5400 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5404 */       this.atLeastOneOrdinalParameter = true;
/* 5405 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP)
/*      */     throws SQLException
/*      */   {
/* 5413 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5417 */       this.atLeastOneOrdinalParameter = true;
/* 5418 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5426 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5430 */       this.atLeastOneOrdinalParameter = true;
/* 5431 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5439 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5443 */       this.atLeastOneOrdinalParameter = true;
/* 5444 */       setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5452 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5456 */       this.atLeastOneOrdinalParameter = true;
/* 5457 */       setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5465 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5469 */       this.atLeastOneOrdinalParameter = true;
/* 5470 */       setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(String paramString, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 5482 */     int i = addNamedPara(paramString);
/* 5483 */     setArrayInternal(i, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 5493 */     int i = addNamedPara(paramString);
/* 5494 */     setBigDecimalInternal(i, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(String paramString, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 5504 */     int i = addNamedPara(paramString);
/* 5505 */     setBlobInternal(i, paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBoolean(String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 5515 */     int i = addNamedPara(paramString);
/* 5516 */     setBooleanInternal(i, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setByte(String paramString, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 5526 */     int i = addNamedPara(paramString);
/* 5527 */     setByteInternal(i, paramByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytes(String paramString, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 5537 */     int i = addNamedPara(paramString);
/* 5538 */     setBytesInternal(i, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClob(String paramString, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 5548 */     int i = addNamedPara(paramString);
/* 5549 */     setClobInternal(i, paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(String paramString, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 5559 */     int i = addNamedPara(paramString);
/* 5560 */     setDateInternal(i, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5570 */     int i = addNamedPara(paramString);
/* 5571 */     setDateInternal(i, paramDate, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDouble(String paramString, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 5581 */     int i = addNamedPara(paramString);
/* 5582 */     setDoubleInternal(i, paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFloat(String paramString, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 5592 */     int i = addNamedPara(paramString);
/* 5593 */     setFloatInternal(i, paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInt(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5603 */     int i = addNamedPara(paramString);
/* 5604 */     setIntInternal(i, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLong(String paramString, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5614 */     int i = addNamedPara(paramString);
/* 5615 */     setLongInternal(i, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 5625 */     int i = addNamedPara(paramString);
/* 5626 */     setObjectInternal(i, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5636 */     int i = addNamedPara(paramString);
/* 5637 */     setObjectInternal(i, paramObject, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRef(String paramString, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 5647 */     int i = addNamedPara(paramString);
/* 5648 */     setRefInternal(i, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShort(String paramString, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 5658 */     int i = addNamedPara(paramString);
/* 5659 */     setShortInternal(i, paramShort);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setString(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 5669 */     int i = addNamedPara(paramString1);
/* 5670 */     setStringInternal(i, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(String paramString, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 5680 */     int i = addNamedPara(paramString);
/* 5681 */     setTimeInternal(i, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5691 */     int i = addNamedPara(paramString);
/* 5692 */     setTimeInternal(i, paramTime, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 5702 */     int i = addNamedPara(paramString);
/* 5703 */     setTimestampInternal(i, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5713 */     int i = addNamedPara(paramString);
/* 5714 */     setTimestampInternal(i, paramTimestamp, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setURL(String paramString, URL paramURL)
/*      */     throws SQLException
/*      */   {
/* 5724 */     int i = addNamedPara(paramString);
/* 5725 */     setURLInternal(i, paramURL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY)
/*      */     throws SQLException
/*      */   {
/* 5735 */     int i = addNamedPara(paramString);
/* 5736 */     setARRAYInternal(i, paramARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBFILE(String paramString, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 5746 */     int i = addNamedPara(paramString);
/* 5747 */     setBFILEInternal(i, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBfile(String paramString, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 5757 */     int i = addNamedPara(paramString);
/* 5758 */     setBfileInternal(i, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryFloat(String paramString, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 5768 */     int i = addNamedPara(paramString);
/* 5769 */     setBinaryFloatInternal(i, paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT)
/*      */     throws SQLException
/*      */   {
/* 5779 */     int i = addNamedPara(paramString);
/* 5780 */     setBinaryFloatInternal(i, paramBINARY_FLOAT);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryDouble(String paramString, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 5790 */     int i = addNamedPara(paramString);
/* 5791 */     setBinaryDoubleInternal(i, paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE)
/*      */     throws SQLException
/*      */   {
/* 5801 */     int i = addNamedPara(paramString);
/* 5802 */     setBinaryDoubleInternal(i, paramBINARY_DOUBLE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBLOB(String paramString, BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 5812 */     int i = addNamedPara(paramString);
/* 5813 */     setBLOBInternal(i, paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCHAR(String paramString, CHAR paramCHAR)
/*      */     throws SQLException
/*      */   {
/* 5823 */     int i = addNamedPara(paramString);
/* 5824 */     setCHARInternal(i, paramCHAR);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCLOB(String paramString, CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 5834 */     int i = addNamedPara(paramString);
/* 5835 */     setCLOBInternal(i, paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursor(String paramString, ResultSet paramResultSet)
/*      */     throws SQLException
/*      */   {
/* 5845 */     int i = addNamedPara(paramString);
/* 5846 */     setCursorInternal(i, paramResultSet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum)
/*      */     throws SQLException
/*      */   {
/* 5856 */     int i = addNamedPara(paramString);
/* 5857 */     setCustomDatumInternal(i, paramCustomDatum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDATE(String paramString, DATE paramDATE)
/*      */     throws SQLException
/*      */   {
/* 5867 */     int i = addNamedPara(paramString);
/* 5868 */     setDATEInternal(i, paramDATE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFixedCHAR(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 5878 */     int i = addNamedPara(paramString1);
/* 5879 */     setFixedCHARInternal(i, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS)
/*      */     throws SQLException
/*      */   {
/* 5889 */     int i = addNamedPara(paramString);
/* 5890 */     setINTERVALDSInternal(i, paramINTERVALDS);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM)
/*      */     throws SQLException
/*      */   {
/* 5900 */     int i = addNamedPara(paramString);
/* 5901 */     setINTERVALYMInternal(i, paramINTERVALYM);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER)
/*      */     throws SQLException
/*      */   {
/* 5911 */     int i = addNamedPara(paramString);
/* 5912 */     setNUMBERInternal(i, paramNUMBER);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE)
/*      */     throws SQLException
/*      */   {
/* 5922 */     int i = addNamedPara(paramString);
/* 5923 */     setOPAQUEInternal(i, paramOPAQUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOracleObject(String paramString, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 5933 */     int i = addNamedPara(paramString);
/* 5934 */     setOracleObjectInternal(i, paramDatum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setORAData(String paramString, ORAData paramORAData)
/*      */     throws SQLException
/*      */   {
/* 5944 */     int i = addNamedPara(paramString);
/* 5945 */     setORADataInternal(i, paramORAData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRAW(String paramString, RAW paramRAW)
/*      */     throws SQLException
/*      */   {
/* 5955 */     int i = addNamedPara(paramString);
/* 5956 */     setRAWInternal(i, paramRAW);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setREF(String paramString, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 5966 */     int i = addNamedPara(paramString);
/* 5967 */     setREFInternal(i, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRefType(String paramString, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 5977 */     int i = addNamedPara(paramString);
/* 5978 */     setRefTypeInternal(i, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setROWID(String paramString, ROWID paramROWID)
/*      */     throws SQLException
/*      */   {
/* 5988 */     int i = addNamedPara(paramString);
/* 5989 */     setROWIDInternal(i, paramROWID);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT)
/*      */     throws SQLException
/*      */   {
/* 5999 */     int i = addNamedPara(paramString);
/* 6000 */     setSTRUCTInternal(i, paramSTRUCT);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*      */     throws SQLException
/*      */   {
/* 6010 */     int i = addNamedPara(paramString);
/* 6011 */     setTIMESTAMPLTZInternal(i, paramTIMESTAMPLTZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ)
/*      */     throws SQLException
/*      */   {
/* 6021 */     int i = addNamedPara(paramString);
/* 6022 */     setTIMESTAMPTZInternal(i, paramTIMESTAMPTZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP)
/*      */     throws SQLException
/*      */   {
/* 6032 */     int i = addNamedPara(paramString);
/* 6033 */     setTIMESTAMPInternal(i, paramTIMESTAMP);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6043 */     int i = addNamedPara(paramString);
/* 6044 */     setAsciiStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6054 */     int i = addNamedPara(paramString);
/* 6055 */     setBinaryStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6065 */     int i = addNamedPara(paramString);
/* 6066 */     setCharacterStreamInternal(i, paramReader, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6076 */     int i = addNamedPara(paramString);
/* 6077 */     setUnicodeStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(String paramString1, int paramInt, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 6088 */     int i = addNamedPara(paramString1);
/* 6089 */     setNullInternal(i, paramInt, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6100 */     int i = addNamedPara(paramString);
/* 6101 */     setNullInternal(i, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor)
/*      */     throws SQLException
/*      */   {
/* 6110 */     int i = addNamedPara(paramString);
/* 6111 */     setStructDescriptorInternal(i, paramStructDescriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 6122 */     int i = addNamedPara(paramString);
/* 6123 */     setObjectInternal(i, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */     throws SQLException
/*      */   {
/* 6135 */     synchronized (this.connection)
/*      */     {
/* 6137 */       this.atLeastOneOrdinalParameter = true;
/* 6138 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int addNamedPara(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6156 */     if (this.closed)
/*      */     {
/* 6158 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6159 */       ((SQLException)localObject).fillInStackTrace();
/* 6160 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 6163 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/* 6165 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6167 */       if (localObject == this.namedParameters[i]) {
/* 6168 */         return i + 1;
/*      */       }
/*      */     }
/* 6171 */     if (this.parameterCount >= this.namedParameters.length)
/*      */     {
/* 6173 */       String[] arrayOfString = new String[this.namedParameters.length * 2];
/* 6174 */       System.arraycopy(this.namedParameters, 0, arrayOfString, 0, this.namedParameters.length);
/* 6175 */       this.namedParameters = arrayOfString;
/*      */     }
/*      */     
/* 6178 */     this.namedParameters[(this.parameterCount++)] = localObject;
/*      */     
/* 6180 */     this.atLeastOneNamedParameter = true;
/* 6181 */     return this.parameterCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6191 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6194 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6195 */       ((SQLException)localObject).fillInStackTrace();
/* 6196 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6200 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6203 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6205 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6208 */     i++;
/*      */     
/* 6210 */     Accessor localAccessor = null;
/* 6211 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6216 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6217 */       localSQLException.fillInStackTrace();
/* 6218 */       throw localSQLException;
/*      */     }
/*      */     
/* 6221 */     this.lastIndex = i;
/*      */     
/* 6223 */     if (this.streamList != null) {
/* 6224 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6227 */     return localAccessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6235 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6238 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6239 */       ((SQLException)localObject).fillInStackTrace();
/* 6240 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6244 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6247 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6249 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6252 */     i++;
/*      */     
/* 6254 */     Accessor localAccessor = null;
/* 6255 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6260 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6261 */       localSQLException.fillInStackTrace();
/* 6262 */       throw localSQLException;
/*      */     }
/*      */     
/* 6265 */     this.lastIndex = i;
/*      */     
/* 6267 */     if (this.streamList != null) {
/* 6268 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6271 */     return localAccessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6279 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6282 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6283 */       ((SQLException)localObject).fillInStackTrace();
/* 6284 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6288 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6291 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6293 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6296 */     i++;
/*      */     
/* 6298 */     Accessor localAccessor = null;
/* 6299 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6304 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6305 */       localSQLException.fillInStackTrace();
/* 6306 */       throw localSQLException;
/*      */     }
/*      */     
/* 6309 */     this.lastIndex = i;
/*      */     
/* 6311 */     if (this.streamList != null) {
/* 6312 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6315 */     return localAccessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6324 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OracleCallableStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */