/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleSqlReadOnly
/*      */ {
/*      */   private static final int BASE = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int BASE_1 = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int BASE_2 = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_STRING = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_NAME = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_C_COMMENT = 5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_C_COMMENT_1 = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_COMMENT = 7;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int PARAMETER = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int TOKEN = 9;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_EGIN = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int BE_GIN = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int BEG_IN = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int BEGI_N = 13;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int BEGIN_ = 14;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int C_ALL = 15;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int CA_LL = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int CAL_L = 17;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int CALL_ = 18;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int D_Eetc = 19;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DE_etc = 20;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DEC_LARE = 21;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DECL_ARE = 22;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DECLA_RE = 23;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DECLAR_E = 24;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DECLARE_ = 25;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DEL_ETE = 26;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DELE_TE = 27;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DELET_E = 28;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DELETE_ = 29;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int I_NSERT = 30;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int IN_SERT = 31;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INS_ERT = 32;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INSE_RT = 33;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INSER_T = 34;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INSERT_ = 35;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int S_ELECT = 36;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int SE_LECT = 37;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int SEL_ECT = 38;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int SELE_CT = 39;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int SELEC_T = 40;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int SELECT_ = 41;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int U_PDATE = 42;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int UP_DATE = 43;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int UPD_ATE = 44;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int UPDA_TE = 45;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int UPDAT_E = 46;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int UPDATE_ = 47;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int M_ERGE = 48;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ME_RGE = 49;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MER_GE = 50;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MERG_E = 51;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MERGE_ = 52;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int W_ITH = 53;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int WI_TH = 54;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int WIT_H = 55;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int WITH_ = 56;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int KNOW_KIND = 57;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int KNOW_KIND_1 = 58;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int KNOW_KIND_2 = 59;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_STRING = 60;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_NAME = 61;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_C_COMMENT = 62;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_C_COMMENT_1 = 63;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_COMMENT = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_PARAMETER = 65;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int TOKEN_KK = 66;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int W_HERE = 67;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int WH_ERE = 68;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int WHE_RE = 69;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int WHER_E = 70;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int WHERE_ = 71;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int O_RDER_BY = 72;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int OR_DER_BY = 73;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORD_ER_BY = 74;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDE_R_BY = 75;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER__BY = 76;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_xBY = 77;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_B_Y = 78;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_BY_ = 79;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_xBY_CC_1 = 80;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_xBY_CC_2 = 81;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_xBY_CC_3 = 82;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_xBY_C_1 = 83;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ORDER_xBY_C_2 = 84;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int F_OR_UPDATE = 85;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FO_R_UPDATE = 86;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR__UPDATE = 87;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_xUPDATE = 88;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_U_PDATE = 89;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_UP_DATE = 90;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_UPD_ATE = 91;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_UPDA_TE = 92;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_UPDAT_E = 93;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_UPDATE_ = 94;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_xUPDATE_CC_1 = 95;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_xUPDATE_CC_2 = 96;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_xUPDATE_CC_3 = 97;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_xUPDATE_C_1 = 98;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FOR_xUPDATE_C_2 = 99;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_N_tick = 100;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_NCHAR = 101;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_N_tick = 102;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_NCHAR = 103;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_NCHAR_tick = 104;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_Q_tickDelimiterCharDelimiterTick = 105;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_QTick_delimiterCharDelimiterTick = 106;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_QTickDelimiter_charDelimiterTick = 107;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_QTickDelimiterChar_delimiterTick = 108;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int B_QTickDelimiterCharDelimiter_tick = 109;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_Q_tickDelimiterCharDelimiterTick = 110;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_QTick_delimiterCharDelimiterTick = 111;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_QTickDelimiter_charDelimiterTick = 112;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_QTickDelimiterChar_delimiterTick = 113;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_QTickDelimiterCharDelimiter_tick = 114;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscEtc = 115;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscQuestion = 116;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscC_ALL = 117;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscCA_LL = 118;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscCAL_L = 119;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscCALL_ = 120;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscT = 121;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscTS_ = 122;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscD_ = 123;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscE_SCAPE = 124;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscES_CAPE = 125;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscESC_APE = 126;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscESCA_PE = 127;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscESCAP_E = 128;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscESCAPE_ = 129;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscF_N = 130;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscFN_ = 131;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscO_J = 132;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int K_EscOJ_ = 133;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int SKIP_PARAMETER_WHITESPACE = 134;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int A_LTER_SESSION = 135;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int AL_TER_SESSION = 136;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALT_ER_SESSION = 137;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTE_R_SESSION = 138;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER__SESSION = 139;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_xSESSION = 140;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_S_ESSION = 141;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_SE_SSION = 142;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_SES_SION = 143;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_SESS_ION = 144;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_SESSI_ON = 145;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_SESSIO_N = 146;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_SESSION_ = 147;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_xSESSION_CC_1 = 148;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_xSESSION_CC_2 = 149;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_xSESSION_CC_3 = 150;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_xSESSION_C_1 = 151;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int ALTER_xSESSION_C_2 = 152;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int R_ETURNING = 153;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RE_TURNING = 154;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RET_URNING = 155;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RETU_RNING = 156;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RETUR_NING = 157;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RETURN_ING = 158;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RETURNI_NG = 159;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RETURNIN_G = 160;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int RETURNING_ = 161;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int I_NTO = 162;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int IN_TO = 163;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INT_O = 164;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INTO_ = 165;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int LAST_STATE = 166;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int EOKTSS_LAST_STATE = 166;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2315 */   public static final String[] PARSER_STATE_NAME = { "BASE", "BASE_1", "BASE_2", "B_STRING", "B_NAME", "B_C_COMMENT", "B_C_COMMENT_1", "B_COMMENT", "PARAMETER", "TOKEN", "B_EGIN", "BE_GIN", "BEG_IN", "BEGI_N", "BEGIN_", "C_ALL", "CA_LL", "CAL_L", "CALL_", "D_Eetc", "DE_etc", "DEC_LARE", "DECL_ARE", "DECLA_RE", "DECLAR_E", "DECLARE_", "DEL_ETE", "DELE_TE", "DELET_E", "DELETE_", "I_NSERT", "IN_SERT", "INS_ERT", "INSE_RT", "INSER_T", "INSERT_", "S_ELECT", "SE_LECT", "SEL_ECT", "SELE_CT", "SELEC_T", "SELECT_", "U_PDATE", "UP_DATE", "UPD_ATE", "UPDA_TE", "UPDAT_E", "UPDATE_", "M_ERGE", "ME_RGE", "MER_GE", "MERG_E", "MERGE_", "W_ITH", "WI_TH", "WIT_H", "WITH_", "KNOW_KIND", "KNOW_KIND_1", "KNOW_KIND_2", "K_STRING", "K_NAME", "K_C_COMMENT", "K_C_COMMENT_1", "K_COMMENT", "K_PARAMETER", "TOKEN_KK", "W_HERE", "WH_ERE", "WHE_RE", "WHER_E", "WHERE_", "O_RDER_BY", "OR_DER_BY", "ORD_ER_BY", "ORDE_R_BY", "ORDER__BY", "ORDER_xBY", "ORDER_B_Y", "ORDER_BY_", "ORDER_xBY_CC_1", "ORDER_xBY_CC_2", "ORDER_xBY_CC_3", "ORDER_xBY_C_1 ", "ORDER_xBY_C_2 ", "F_OR_UPDATE", "FO_R_UPDATE", "FOR__UPDATE", "FOR_xUPDATE", "FOR_U_PDATE", "FOR_UP_DATE", "FOR_UPD_ATE", "FOR_UPDA_TE", "FOR_UPDAT_E", "FOR_UPDATE_", "FOR_xUPDATE_CC_1", "FOR_xUPDATE_CC_2", "FOR_xUPDATE_CC_3", "FOR_xUPDATE_C_1 ", "FOR_xUPDATE_C_2 ", "B_N_tick", "B_NCHAR", "K_N_tick", "K_NCHAR", "K_NCHAR_tick", "B_Q_tickDelimiterCharDelimiterTick", "B_QTick_delimiterCharDelimiterTick", "B_QTickDelimiter_charDelimiterTick", "B_QTickDelimiterChar_delimiterTick", "B_QTickDelimiterCharDelimiter_tick", "K_Q_tickDelimiterCharDelimiterTick", "K_QTick_delimiterCharDelimiterTick", "K_QTickDelimiter_charDelimiterTick", "K_QTickDelimiterChar_delimiterTick", "K_QTickDelimiterCharDelimiter_tick", "K_EscEtc", "K_EscQuestion", "K_EscC_ALL", "K_EscCA_LL", "K_EscCAL_L", "K_EscCALL_", "K_EscT", "K_EscTS_", "K_EscD_", "K_EscE_SCAPE", "K_EscES_CAPE", "K_EscESC_APE", "K_EscESCA_PE", "K_EscESCAP_E", "K_EscESCAPE_", "K_EscF_N", "K_EscFN_", "K_EscO_J", "K_EscOJ_", "SKIP_PARAMETER_WHITESPACE", "A_LTER_SESSION", "AL_TER_SESSION", "ALT_ER_SESSION", "ALTE_R_SESSION", "ALTER__SESSION", "ALTER_xSESSION", "ALTER_S_ESSION", "ALTER_SE_SSION", "ALTER_SES_SION", "ALTER_SESS_ION", "ALTER_SESSI_ON", "ALTER_SESSIO_N", "ALTER_SESSION_", "ALTER_xSESSION_CC_1", "ALTER_xSESSION_CC_2", "ALTER_xSESSION_CC_3", "ALTER_xSESSION_C_1 ", "ALTER_xSESSION_C_2 ", "R_ETURNING", "RE_TURNING", "RET_URNING", "RETU_RNING", "RETUR_NING", "RETURN_ING", "RETURNI_NG", "RETURNIN_G", "RETURNING_", "I_NTO", "IN_TO", "INT_O", "INTO_", "LAST_STATE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2507 */   static final int[][] TRANSITION = new int['¦'][];
/*      */   
/*      */   static final int NO_ACTION = 0;
/*      */   
/*      */   static final int DELETE_ACTION = 1;
/*      */   static final int INSERT_ACTION = 2;
/*      */   static final int MERGE_ACTION = 3;
/*      */   static final int UPDATE_ACTION = 4;
/*      */   static final int PLSQL_ACTION = 5;
/*      */   static final int CALL_ACTION = 6;
/*      */   static final int SELECT_ACTION = 7;
/*      */   static final int OTHER_ACTION = 8;
/*      */   static final int WHERE_ACTION = 9;
/*      */   static final int ORDER_ACTION = 10;
/*      */   static final int ORDER_BY_ACTION = 11;
/*      */   static final int FOR_ACTION = 12;
/*      */   static final int FOR_UPDATE_ACTION = 13;
/*      */   static final int QUESTION_ACTION = 14;
/*      */   static final int PARAMETER_ACTION = 15;
/*      */   static final int END_PARAMETER_ACTION = 16;
/*      */   static final int START_NCHAR_LITERAL_ACTION = 17;
/*      */   static final int END_NCHAR_LITERAL_ACTION = 18;
/*      */   static final int SAVE_DELIMITER_ACTION = 19;
/*      */   static final int LOOK_FOR_DELIMITER_ACTION = 20;
/*      */   static final int ALTER_SESSION_ACTION = 21;
/*      */   static final int RETURNING_ACTION = 22;
/*      */   static final int INTO_ACTION = 23;
/* 2534 */   public static final String[] CBI_ACTION_NAME = { "NO_ACTION", "DELETE_ACTION", "INSERT_ACTION", "MERGE_ACTION", "UPDATE_ACTION", "PLSQL_ACTION", "CALL_ACTION", "SELECT_ACTION", "OTHER_ACTION", "WHERE_ACTION", "ORDER_ACTION", "ORDER_BY_ACTION", "FOR_ACTION", "FOR_UPDATE_ACTION", "QUESTION_ACTION", "PARAMETER_ACTION", "END_PARAMETER_ACTION", "START_NCHAR_LITERAL_ACTION", "END_NCHAR_LITERAL_ACTION", "SAVE_DELIMITER_ACTION", "LOOK_FOR_DELIMITER_ACTION", "ALTER_SESSION_ACTION", "RETURNING_ACTION", "INTO_ACTION" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2566 */   static final int[][] ACTION = new int['¦'][];
/*      */   
/*      */ 
/*      */   static final int INITIAL_STATE = 0;
/*      */   
/*      */   static final int RESTART_STATE = 66;
/*      */   
/*      */ 
/*      */   static enum ODBCAction
/*      */   {
/* 2576 */     NONE, 
/* 2577 */     COPY, 
/* 2578 */     QUESTION, 
/* 2579 */     SAVE_DELIMITER, 
/* 2580 */     LOOK_FOR_DELIMITER, 
/* 2581 */     FUNCTION, 
/* 2582 */     CALL, 
/* 2583 */     TIME, 
/* 2584 */     TIMESTAMP, 
/* 2585 */     DATE, 
/* 2586 */     ESCAPE, 
/* 2587 */     SCALAR_FUNCTION, 
/* 2588 */     OUTER_JOIN, 
/* 2589 */     UNKNOWN_ESCAPE, 
/* 2590 */     END_ODBC_ESCAPE, 
/* 2591 */     COMMA, 
/* 2592 */     OPEN_PAREN, 
/* 2593 */     CLOSE_PAREN, 
/* 2594 */     BEGIN;
/*      */     
/*      */     private ODBCAction() {} }
/* 2597 */   static final ODBCAction[][] ODBC_ACTION = new ODBCAction['¦'][];
/*      */   static final int cMax = 127;
/*      */   private static final int cMaxLength = 128;
/*      */   
/*      */   private static final int[] copy(int[] paramArrayOfInt) {
/* 2602 */     int[] arrayOfInt = new int[paramArrayOfInt.length];
/* 2603 */     System.arraycopy(paramArrayOfInt, 0, arrayOfInt, 0, paramArrayOfInt.length);
/* 2604 */     return arrayOfInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final ODBCAction[] copy(ODBCAction[] paramArrayOfODBCAction)
/*      */   {
/* 2611 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramArrayOfODBCAction.length];
/* 2612 */     System.arraycopy(paramArrayOfODBCAction, 0, arrayOfODBCAction, 0, paramArrayOfODBCAction.length);
/* 2613 */     return arrayOfODBCAction;
/*      */   }
/*      */   
/*      */ 
/*      */   private static final int[] newArray(int paramInt1, int paramInt2)
/*      */   {
/* 2619 */     int[] arrayOfInt = new int[paramInt1];
/*      */     
/* 2621 */     for (int i = 0; i < paramInt1; i++) {
/* 2622 */       arrayOfInt[i] = paramInt2;
/*      */     }
/* 2624 */     return arrayOfInt;
/*      */   }
/*      */   
/*      */ 
/*      */   private static final ODBCAction[] newArray(int paramInt, ODBCAction paramODBCAction)
/*      */   {
/* 2630 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramInt];
/*      */     
/* 2632 */     for (int i = 0; i < paramInt; i++) {
/* 2633 */       arrayOfODBCAction[i] = paramODBCAction;
/*      */     }
/* 2635 */     return arrayOfODBCAction;
/*      */   }
/*      */   
/*      */   private static final int[] copyReplacing(int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*      */   {
/* 2640 */     int[] arrayOfInt = new int[paramArrayOfInt.length];
/*      */     
/* 2642 */     for (int i = 0; i < arrayOfInt.length; i++)
/*      */     {
/* 2644 */       int j = paramArrayOfInt[i];
/*      */       
/* 2646 */       if (j == paramInt1) {
/* 2647 */         arrayOfInt[i] = paramInt2;
/*      */       } else {
/* 2649 */         arrayOfInt[i] = j;
/*      */       }
/*      */     }
/* 2652 */     return arrayOfInt;
/*      */   }
/*      */   
/*      */   private static final ODBCAction[] copyReplacing(ODBCAction[] paramArrayOfODBCAction, ODBCAction paramODBCAction1, ODBCAction paramODBCAction2)
/*      */   {
/* 2657 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramArrayOfODBCAction.length];
/*      */     
/* 2659 */     for (int i = 0; i < arrayOfODBCAction.length; i++)
/*      */     {
/* 2661 */       ODBCAction localODBCAction = paramArrayOfODBCAction[i];
/*      */       
/* 2663 */       if (localODBCAction == paramODBCAction1) {
/* 2664 */         arrayOfODBCAction[i] = paramODBCAction2;
/*      */       } else {
/* 2666 */         arrayOfODBCAction[i] = localODBCAction;
/*      */       }
/*      */     }
/* 2669 */     return arrayOfODBCAction;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/* 2684 */       int[] arrayOfInt1 = { 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 9, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57 };
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2721 */       int[] arrayOfInt2 = copy(arrayOfInt1);
/* 2722 */       arrayOfInt2[34] = 4;
/* 2723 */       arrayOfInt2[39] = 3;
/* 2724 */       arrayOfInt2[45] = 2;
/* 2725 */       arrayOfInt2[47] = 1;
/* 2726 */       arrayOfInt2[58] = 8;
/* 2727 */       arrayOfInt2[123] = 115;
/*      */       
/*      */ 
/*      */ 
/* 2731 */       int[] arrayOfInt3 = copyReplacing(arrayOfInt2, 57, 0);
/* 2732 */       arrayOfInt3[65] = 135;
/* 2733 */       arrayOfInt3[97] = 135;
/* 2734 */       arrayOfInt3[66] = 10;
/* 2735 */       arrayOfInt3[98] = 10;
/* 2736 */       arrayOfInt3[67] = 15;
/* 2737 */       arrayOfInt3[99] = 15;
/* 2738 */       arrayOfInt3[68] = 19;
/* 2739 */       arrayOfInt3[100] = 19;
/* 2740 */       arrayOfInt3[73] = 30;
/* 2741 */       arrayOfInt3[105] = 30;
/* 2742 */       arrayOfInt3[109] = 48;
/* 2743 */       arrayOfInt3[77] = 48;
/* 2744 */       arrayOfInt3[78] = 100;
/* 2745 */       arrayOfInt3[110] = 100;
/* 2746 */       arrayOfInt3[81] = 105;
/* 2747 */       arrayOfInt3[113] = 105;
/* 2748 */       arrayOfInt3[83] = 36;
/* 2749 */       arrayOfInt3[115] = 36;
/* 2750 */       arrayOfInt3[85] = 42;
/* 2751 */       arrayOfInt3[117] = 42;
/* 2752 */       arrayOfInt3[87] = 53;
/* 2753 */       arrayOfInt3[119] = 53;
/*      */       
/*      */ 
/* 2756 */       int[] arrayOfInt4 = copyReplacing(arrayOfInt2, 9, 66);
/* 2757 */       arrayOfInt4[34] = 61;
/* 2758 */       arrayOfInt4[39] = 60;
/* 2759 */       arrayOfInt4[45] = 59;
/* 2760 */       arrayOfInt4[47] = 58;
/* 2761 */       arrayOfInt4[58] = 134;
/* 2762 */       arrayOfInt4[32] = 57;
/* 2763 */       arrayOfInt4[32] = 57;
/* 2764 */       arrayOfInt4[9] = 57;
/* 2765 */       arrayOfInt4[10] = 57;
/* 2766 */       arrayOfInt4[13] = 57;
/* 2767 */       arrayOfInt4[61] = 57;
/*      */       
/*      */ 
/* 2770 */       int[] arrayOfInt5 = copyReplacing(arrayOfInt4, 9, 66);
/* 2771 */       arrayOfInt5[78] = 102;
/* 2772 */       arrayOfInt5[110] = 102;
/* 2773 */       arrayOfInt5[81] = 110;
/* 2774 */       arrayOfInt5[113] = 110;
/* 2775 */       arrayOfInt5[87] = 67;
/* 2776 */       arrayOfInt5[119] = 67;
/* 2777 */       arrayOfInt5[79] = 72;
/* 2778 */       arrayOfInt5[111] = 72;
/* 2779 */       arrayOfInt5[70] = 85;
/* 2780 */       arrayOfInt5[102] = 85;
/* 2781 */       arrayOfInt5[82] = 153;
/* 2782 */       arrayOfInt5[114] = 153;
/* 2783 */       arrayOfInt5[73] = 162;
/* 2784 */       arrayOfInt5[105] = 162;
/*      */       
/*      */ 
/*      */ 
/* 2788 */       int[] arrayOfInt6 = copyReplacing(arrayOfInt5, 57, 115);
/*      */       
/* 2790 */       arrayOfInt6[63] = 116;
/* 2791 */       arrayOfInt6[99] = 117;
/* 2792 */       arrayOfInt6[67] = 117;
/* 2793 */       arrayOfInt6[116] = 121;
/* 2794 */       arrayOfInt6[84] = 121;
/* 2795 */       arrayOfInt6[100] = 123;
/* 2796 */       arrayOfInt6[68] = 123;
/* 2797 */       arrayOfInt6[101] = 124;
/* 2798 */       arrayOfInt6[69] = 124;
/* 2799 */       arrayOfInt6[102] = 130;
/* 2800 */       arrayOfInt6[70] = 130;
/* 2801 */       arrayOfInt6[111] = 132;
/* 2802 */       arrayOfInt6[79] = 132;
/*      */       
/*      */ 
/*      */ 
/* 2806 */       TRANSITION[0] = arrayOfInt3;
/* 2807 */       TRANSITION[1] = copy(arrayOfInt3);
/* 2808 */       TRANSITION[1][42] = 5;
/* 2809 */       TRANSITION[2] = copy(arrayOfInt3);
/* 2810 */       TRANSITION[2][45] = 7;
/* 2811 */       TRANSITION[3] = newArray(128, 3);
/* 2812 */       TRANSITION[3][39] = 0;
/* 2813 */       TRANSITION[100] = copy(arrayOfInt2);
/* 2814 */       TRANSITION[100][39] = 101;
/* 2815 */       TRANSITION[101] = newArray(128, 101);
/* 2816 */       TRANSITION[101][39] = 0;
/*      */       
/* 2818 */       TRANSITION[105] = copy(arrayOfInt2);
/* 2819 */       TRANSITION[105][39] = 106;
/* 2820 */       TRANSITION[106] = newArray(128, 107);
/* 2821 */       TRANSITION[107] = newArray(128, 107);
/*      */       
/* 2823 */       TRANSITION[108] = newArray(128, 109);
/* 2824 */       TRANSITION[109] = newArray(128, 107);
/* 2825 */       TRANSITION[109][39] = 0;
/*      */       
/*      */ 
/* 2828 */       TRANSITION[4] = newArray(128, 4);
/* 2829 */       TRANSITION[4][34] = 0;
/* 2830 */       TRANSITION[5] = newArray(128, 5);
/* 2831 */       TRANSITION[5][42] = 6;
/* 2832 */       TRANSITION[6] = newArray(128, 5);
/* 2833 */       TRANSITION[6][42] = 6;
/* 2834 */       TRANSITION[6][47] = 0;
/* 2835 */       TRANSITION[7] = newArray(128, 7);
/* 2836 */       TRANSITION[7][10] = 0;
/* 2837 */       TRANSITION[8] = copyReplacing(arrayOfInt2, 9, 8);
/* 2838 */       TRANSITION[9] = arrayOfInt2;
/* 2839 */       TRANSITION[10] = copy(arrayOfInt2);
/* 2840 */       TRANSITION[10][69] = 11;
/* 2841 */       TRANSITION[10][101] = 11;
/* 2842 */       TRANSITION[11] = copy(arrayOfInt2);
/* 2843 */       TRANSITION[11][71] = 12;
/* 2844 */       TRANSITION[11][103] = 12;
/* 2845 */       TRANSITION[12] = copy(arrayOfInt2);
/* 2846 */       TRANSITION[12][73] = 13;
/* 2847 */       TRANSITION[12][105] = 13;
/* 2848 */       TRANSITION[13] = copy(arrayOfInt2);
/* 2849 */       TRANSITION[13][78] = 14;
/* 2850 */       TRANSITION[13][110] = 14;
/* 2851 */       TRANSITION[14] = arrayOfInt5;
/* 2852 */       TRANSITION[15] = copy(arrayOfInt2);
/* 2853 */       TRANSITION[15][65] = 16;
/* 2854 */       TRANSITION[15][97] = 16;
/* 2855 */       TRANSITION[16] = copy(arrayOfInt2);
/* 2856 */       TRANSITION[16][76] = 17;
/* 2857 */       TRANSITION[16][108] = 17;
/* 2858 */       TRANSITION[17] = copy(arrayOfInt2);
/* 2859 */       TRANSITION[17][76] = 18;
/* 2860 */       TRANSITION[17][108] = 18;
/* 2861 */       TRANSITION[18] = arrayOfInt5;
/* 2862 */       TRANSITION[19] = copy(arrayOfInt2);
/* 2863 */       TRANSITION[19][69] = 20;
/* 2864 */       TRANSITION[19][101] = 20;
/* 2865 */       TRANSITION[20] = copy(arrayOfInt2);
/* 2866 */       TRANSITION[20][67] = 21;
/* 2867 */       TRANSITION[20][99] = 21;
/* 2868 */       TRANSITION[20][76] = 26;
/* 2869 */       TRANSITION[20][108] = 26;
/* 2870 */       TRANSITION[21] = copy(arrayOfInt2);
/* 2871 */       TRANSITION[21][76] = 22;
/* 2872 */       TRANSITION[21][108] = 22;
/* 2873 */       TRANSITION[22] = copy(arrayOfInt2);
/* 2874 */       TRANSITION[22][65] = 23;
/* 2875 */       TRANSITION[22][97] = 23;
/* 2876 */       TRANSITION[23] = copy(arrayOfInt2);
/* 2877 */       TRANSITION[23][82] = 24;
/* 2878 */       TRANSITION[23][114] = 24;
/* 2879 */       TRANSITION[24] = copy(arrayOfInt2);
/* 2880 */       TRANSITION[24][69] = 25;
/* 2881 */       TRANSITION[24][101] = 25;
/* 2882 */       TRANSITION[25] = arrayOfInt5;
/* 2883 */       TRANSITION[26] = copy(arrayOfInt2);
/* 2884 */       TRANSITION[26][69] = 27;
/* 2885 */       TRANSITION[26][101] = 27;
/* 2886 */       TRANSITION[27] = copy(arrayOfInt2);
/* 2887 */       TRANSITION[27][84] = 28;
/* 2888 */       TRANSITION[27][116] = 28;
/* 2889 */       TRANSITION[28] = copy(arrayOfInt2);
/* 2890 */       TRANSITION[28][69] = 29;
/* 2891 */       TRANSITION[28][101] = 29;
/* 2892 */       TRANSITION[29] = arrayOfInt5;
/* 2893 */       TRANSITION[30] = copy(arrayOfInt2);
/* 2894 */       TRANSITION[30][78] = 31;
/* 2895 */       TRANSITION[30][110] = 31;
/* 2896 */       TRANSITION[31] = copy(arrayOfInt2);
/* 2897 */       TRANSITION[31][83] = 32;
/* 2898 */       TRANSITION[31][115] = 32;
/* 2899 */       TRANSITION[32] = copy(arrayOfInt2);
/* 2900 */       TRANSITION[32][69] = 33;
/* 2901 */       TRANSITION[32][101] = 33;
/* 2902 */       TRANSITION[33] = copy(arrayOfInt2);
/* 2903 */       TRANSITION[33][82] = 34;
/* 2904 */       TRANSITION[33][114] = 34;
/* 2905 */       TRANSITION[34] = copy(arrayOfInt2);
/* 2906 */       TRANSITION[34][84] = 35;
/* 2907 */       TRANSITION[34][116] = 35;
/* 2908 */       TRANSITION[35] = arrayOfInt5;
/* 2909 */       TRANSITION[36] = copy(arrayOfInt2);
/* 2910 */       TRANSITION[36][69] = 37;
/* 2911 */       TRANSITION[36][101] = 37;
/* 2912 */       TRANSITION[37] = copy(arrayOfInt2);
/* 2913 */       TRANSITION[37][76] = 38;
/* 2914 */       TRANSITION[37][108] = 38;
/* 2915 */       TRANSITION[38] = copy(arrayOfInt2);
/* 2916 */       TRANSITION[38][69] = 39;
/* 2917 */       TRANSITION[38][101] = 39;
/* 2918 */       TRANSITION[39] = copy(arrayOfInt2);
/* 2919 */       TRANSITION[39][67] = 40;
/* 2920 */       TRANSITION[39][99] = 40;
/* 2921 */       TRANSITION[40] = copy(arrayOfInt2);
/* 2922 */       TRANSITION[40][84] = 41;
/* 2923 */       TRANSITION[40][116] = 41;
/* 2924 */       TRANSITION[41] = arrayOfInt5;
/* 2925 */       TRANSITION[42] = copy(arrayOfInt2);
/* 2926 */       TRANSITION[42][80] = 43;
/* 2927 */       TRANSITION[42][112] = 43;
/* 2928 */       TRANSITION[43] = copy(arrayOfInt2);
/* 2929 */       TRANSITION[43][68] = 44;
/* 2930 */       TRANSITION[43][100] = 44;
/* 2931 */       TRANSITION[44] = copy(arrayOfInt2);
/* 2932 */       TRANSITION[44][65] = 45;
/* 2933 */       TRANSITION[44][97] = 45;
/* 2934 */       TRANSITION[45] = copy(arrayOfInt2);
/* 2935 */       TRANSITION[45][84] = 46;
/* 2936 */       TRANSITION[45][116] = 46;
/* 2937 */       TRANSITION[46] = copy(arrayOfInt2);
/* 2938 */       TRANSITION[46][69] = 47;
/* 2939 */       TRANSITION[46][101] = 47;
/* 2940 */       TRANSITION[47] = arrayOfInt5;
/* 2941 */       TRANSITION[48] = copy(arrayOfInt2);
/* 2942 */       TRANSITION[48][69] = 49;
/* 2943 */       TRANSITION[48][101] = 49;
/* 2944 */       TRANSITION[49] = copy(arrayOfInt2);
/* 2945 */       TRANSITION[49][82] = 50;
/* 2946 */       TRANSITION[49][114] = 50;
/* 2947 */       TRANSITION[50] = copy(arrayOfInt2);
/* 2948 */       TRANSITION[50][71] = 51;
/* 2949 */       TRANSITION[50][103] = 51;
/* 2950 */       TRANSITION[51] = copy(arrayOfInt2);
/* 2951 */       TRANSITION[51][69] = 52;
/* 2952 */       TRANSITION[51][101] = 52;
/* 2953 */       TRANSITION[52] = arrayOfInt5;
/* 2954 */       TRANSITION[53] = copy(arrayOfInt2);
/* 2955 */       TRANSITION[53][73] = 54;
/* 2956 */       TRANSITION[53][105] = 54;
/* 2957 */       TRANSITION[54] = copy(arrayOfInt2);
/* 2958 */       TRANSITION[54][84] = 55;
/* 2959 */       TRANSITION[54][116] = 55;
/* 2960 */       TRANSITION[55] = copy(arrayOfInt2);
/* 2961 */       TRANSITION[55][72] = 56;
/* 2962 */       TRANSITION[55][104] = 56;
/* 2963 */       TRANSITION[56] = arrayOfInt5;
/* 2964 */       TRANSITION[66] = arrayOfInt4;
/* 2965 */       TRANSITION[58] = copy(arrayOfInt5);
/* 2966 */       TRANSITION[58][42] = 62;
/* 2967 */       TRANSITION[59] = copy(arrayOfInt5);
/* 2968 */       TRANSITION[59][45] = 64;
/* 2969 */       TRANSITION[62] = newArray(128, 62);
/* 2970 */       TRANSITION[62][42] = 63;
/* 2971 */       TRANSITION[63] = newArray(128, 62);
/* 2972 */       TRANSITION[63][42] = 63;
/* 2973 */       TRANSITION[63][47] = 57;
/* 2974 */       TRANSITION[64] = newArray(128, 64);
/* 2975 */       TRANSITION[64][10] = 57;
/* 2976 */       TRANSITION[61] = newArray(128, 61);
/* 2977 */       TRANSITION[61][34] = 57;
/* 2978 */       TRANSITION[60] = newArray(128, 60);
/* 2979 */       TRANSITION[60][39] = 57;
/* 2980 */       TRANSITION[65] = copyReplacing(arrayOfInt4, 66, 65);
/* 2981 */       TRANSITION[''] = copyReplacing(arrayOfInt4, 66, 65);
/* 2982 */       TRANSITION[''][32] = '';
/* 2983 */       TRANSITION[''][10] = '';
/* 2984 */       TRANSITION[''][13] = '';
/* 2985 */       TRANSITION[''][9] = '';
/*      */       
/*      */ 
/* 2988 */       TRANSITION[57] = arrayOfInt5;
/* 2989 */       TRANSITION[67] = copy(arrayOfInt4);
/* 2990 */       TRANSITION[67][72] = 68;
/* 2991 */       TRANSITION[67][104] = 68;
/* 2992 */       TRANSITION[68] = copy(arrayOfInt4);
/* 2993 */       TRANSITION[68][69] = 69;
/* 2994 */       TRANSITION[68][101] = 69;
/* 2995 */       TRANSITION[69] = copy(arrayOfInt4);
/* 2996 */       TRANSITION[69][82] = 70;
/* 2997 */       TRANSITION[69][114] = 70;
/* 2998 */       TRANSITION[70] = copy(arrayOfInt4);
/* 2999 */       TRANSITION[70][69] = 71;
/* 3000 */       TRANSITION[70][101] = 71;
/* 3001 */       TRANSITION[71] = arrayOfInt5;
/*      */       
/* 3003 */       TRANSITION[72] = copy(arrayOfInt4);
/* 3004 */       TRANSITION[72][82] = 73;
/* 3005 */       TRANSITION[72][114] = 73;
/* 3006 */       TRANSITION[73] = copy(arrayOfInt4);
/* 3007 */       TRANSITION[73][68] = 74;
/* 3008 */       TRANSITION[73][100] = 74;
/* 3009 */       TRANSITION[74] = copy(arrayOfInt4);
/* 3010 */       TRANSITION[74][69] = 75;
/* 3011 */       TRANSITION[74][101] = 75;
/* 3012 */       TRANSITION[75] = copy(arrayOfInt4);
/* 3013 */       TRANSITION[75][82] = 76;
/* 3014 */       TRANSITION[75][114] = 76;
/* 3015 */       TRANSITION[76] = copyReplacing(arrayOfInt5, 57, 77);
/* 3016 */       TRANSITION[76][47] = 80;
/* 3017 */       TRANSITION[76][45] = 83;
/*      */       
/* 3019 */       TRANSITION[77] = copyReplacing(arrayOfInt5, 57, 77);
/* 3020 */       TRANSITION[77][47] = 80;
/* 3021 */       TRANSITION[80] = copy(arrayOfInt5);
/* 3022 */       TRANSITION[80][42] = 81;
/* 3023 */       TRANSITION[81] = newArray(128, 81);
/* 3024 */       TRANSITION[81][42] = 82;
/* 3025 */       TRANSITION[82] = newArray(128, 81);
/* 3026 */       TRANSITION[82][47] = 77;
/*      */       
/* 3028 */       TRANSITION[77][45] = 83;
/* 3029 */       TRANSITION[83] = copy(arrayOfInt5);
/* 3030 */       TRANSITION[83][45] = 84;
/* 3031 */       TRANSITION[84] = newArray(128, 84);
/* 3032 */       TRANSITION[84][10] = 77;
/*      */       
/*      */ 
/* 3035 */       TRANSITION[77][66] = 78;
/* 3036 */       TRANSITION[77][98] = 78;
/* 3037 */       TRANSITION[78] = copy(arrayOfInt4);
/* 3038 */       TRANSITION[78][89] = 79;
/* 3039 */       TRANSITION[78][121] = 79;
/* 3040 */       TRANSITION[79] = arrayOfInt5;
/*      */       
/* 3042 */       TRANSITION[85] = copy(arrayOfInt5);
/* 3043 */       TRANSITION[85][79] = 86;
/* 3044 */       TRANSITION[85][111] = 86;
/* 3045 */       TRANSITION[86] = copy(arrayOfInt5);
/* 3046 */       TRANSITION[86][82] = 87;
/* 3047 */       TRANSITION[86][114] = 87;
/* 3048 */       TRANSITION[87] = copyReplacing(arrayOfInt4, 57, 88);
/* 3049 */       TRANSITION[87][47] = 95;
/* 3050 */       TRANSITION[87][45] = 98;
/*      */       
/* 3052 */       TRANSITION[88] = copyReplacing(arrayOfInt4, 57, 88);
/* 3053 */       TRANSITION[88][47] = 95;
/* 3054 */       TRANSITION[95] = copy(arrayOfInt5);
/* 3055 */       TRANSITION[95][42] = 96;
/* 3056 */       TRANSITION[96] = newArray(128, 96);
/* 3057 */       TRANSITION[96][42] = 97;
/* 3058 */       TRANSITION[97] = newArray(128, 96);
/* 3059 */       TRANSITION[97][47] = 88;
/*      */       
/* 3061 */       TRANSITION[88][45] = 98;
/* 3062 */       TRANSITION[98] = copy(arrayOfInt5);
/* 3063 */       TRANSITION[98][45] = 99;
/* 3064 */       TRANSITION[99] = newArray(128, 99);
/* 3065 */       TRANSITION[99][10] = 88;
/*      */       
/*      */ 
/* 3068 */       TRANSITION[88][85] = 89;
/* 3069 */       TRANSITION[88][117] = 89;
/* 3070 */       TRANSITION[89] = copy(arrayOfInt5);
/* 3071 */       TRANSITION[89][80] = 90;
/* 3072 */       TRANSITION[89][112] = 90;
/* 3073 */       TRANSITION[90] = copy(arrayOfInt5);
/* 3074 */       TRANSITION[90][68] = 91;
/* 3075 */       TRANSITION[90][100] = 91;
/* 3076 */       TRANSITION[91] = copy(arrayOfInt5);
/* 3077 */       TRANSITION[91][65] = 92;
/* 3078 */       TRANSITION[91][97] = 92;
/* 3079 */       TRANSITION[92] = copy(arrayOfInt5);
/* 3080 */       TRANSITION[92][84] = 93;
/* 3081 */       TRANSITION[92][116] = 93;
/* 3082 */       TRANSITION[93] = copy(arrayOfInt5);
/* 3083 */       TRANSITION[93][69] = 94;
/* 3084 */       TRANSITION[93][101] = 94;
/* 3085 */       TRANSITION[94] = arrayOfInt5;
/*      */       
/* 3087 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3088 */       TRANSITION[''][69] = '';
/* 3089 */       TRANSITION[''][101] = '';
/* 3090 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3091 */       TRANSITION[''][84] = '';
/* 3092 */       TRANSITION[''][116] = '';
/* 3093 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3094 */       TRANSITION[''][85] = '';
/* 3095 */       TRANSITION[''][117] = '';
/* 3096 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3097 */       TRANSITION[''][82] = '';
/* 3098 */       TRANSITION[''][114] = '';
/* 3099 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3100 */       TRANSITION[''][78] = '';
/* 3101 */       TRANSITION[''][110] = '';
/* 3102 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3103 */       TRANSITION[''][73] = '';
/* 3104 */       TRANSITION[''][105] = '';
/* 3105 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3106 */       TRANSITION[''][78] = ' ';
/* 3107 */       TRANSITION[''][110] = ' ';
/* 3108 */       TRANSITION[' '] = copy(arrayOfInt5);
/* 3109 */       TRANSITION[' '][71] = '¡';
/* 3110 */       TRANSITION[' '][103] = '¡';
/* 3111 */       TRANSITION['¡'] = arrayOfInt5;
/*      */       
/* 3113 */       TRANSITION['¢'] = copy(arrayOfInt5);
/* 3114 */       TRANSITION['¢'][78] = '£';
/* 3115 */       TRANSITION['¢'][110] = '£';
/* 3116 */       TRANSITION['£'] = copy(arrayOfInt5);
/* 3117 */       TRANSITION['£'][84] = '¤';
/* 3118 */       TRANSITION['£'][116] = '¤';
/* 3119 */       TRANSITION['¤'] = copy(arrayOfInt5);
/* 3120 */       TRANSITION['¤'][79] = '¥';
/* 3121 */       TRANSITION['¤'][111] = '¥';
/* 3122 */       TRANSITION['¥'] = copy(arrayOfInt5);
/*      */       
/*      */ 
/* 3125 */       TRANSITION[102] = copy(arrayOfInt4);
/* 3126 */       TRANSITION[102][39] = 103;
/* 3127 */       TRANSITION[103] = newArray(128, 103);
/* 3128 */       TRANSITION[103][39] = 104;
/*      */       
/* 3130 */       TRANSITION[104] = newArray(128, 57);
/* 3131 */       TRANSITION[104][39] = 103;
/*      */       
/* 3133 */       TRANSITION[110] = copy(arrayOfInt5);
/* 3134 */       TRANSITION[110][39] = 111;
/* 3135 */       TRANSITION[111] = newArray(128, 112);
/* 3136 */       TRANSITION[112] = newArray(128, 112);
/*      */       
/* 3138 */       TRANSITION[113] = newArray(128, 114);
/* 3139 */       TRANSITION[114] = newArray(128, 112);
/* 3140 */       TRANSITION[114][39] = 57;
/*      */       
/*      */ 
/* 3143 */       TRANSITION[115] = arrayOfInt6;
/* 3144 */       TRANSITION[116] = arrayOfInt5;
/* 3145 */       TRANSITION[117] = copy(arrayOfInt5);
/* 3146 */       TRANSITION[117][97] = 118;
/* 3147 */       TRANSITION[117][65] = 118;
/* 3148 */       TRANSITION[118] = copy(arrayOfInt5);
/* 3149 */       TRANSITION[118][108] = 119;
/* 3150 */       TRANSITION[118][76] = 119;
/* 3151 */       TRANSITION[119] = copy(arrayOfInt5);
/* 3152 */       TRANSITION[119][108] = 120;
/* 3153 */       TRANSITION[119][76] = 120;
/* 3154 */       TRANSITION[120] = arrayOfInt5;
/* 3155 */       TRANSITION[121] = copy(arrayOfInt5);
/* 3156 */       TRANSITION[121][115] = 122;
/* 3157 */       TRANSITION[121][83] = 122;
/* 3158 */       TRANSITION[122] = arrayOfInt5;
/* 3159 */       TRANSITION[123] = arrayOfInt5;
/* 3160 */       TRANSITION[124] = copy(arrayOfInt5);
/* 3161 */       TRANSITION[124][115] = 125;
/* 3162 */       TRANSITION[124][83] = 125;
/* 3163 */       TRANSITION[125] = copy(arrayOfInt5);
/* 3164 */       TRANSITION[125][99] = 126;
/* 3165 */       TRANSITION[125][67] = 126;
/* 3166 */       TRANSITION[126] = copy(arrayOfInt5);
/* 3167 */       TRANSITION[126][97] = 127;
/* 3168 */       TRANSITION[126][65] = 127;
/* 3169 */       TRANSITION[127] = copy(arrayOfInt5);
/* 3170 */       TRANSITION[127][112] = '';
/* 3171 */       TRANSITION[127][80] = '';
/* 3172 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3173 */       TRANSITION[''][101] = '';
/* 3174 */       TRANSITION[''][69] = '';
/* 3175 */       TRANSITION[''] = arrayOfInt5;
/* 3176 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3177 */       TRANSITION[''][110] = '';
/* 3178 */       TRANSITION[''][78] = '';
/* 3179 */       TRANSITION[''] = arrayOfInt5;
/* 3180 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3181 */       TRANSITION[''][106] = '';
/* 3182 */       TRANSITION[''][74] = '';
/* 3183 */       TRANSITION[''] = arrayOfInt5;
/* 3184 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3185 */       TRANSITION[''][76] = '';
/* 3186 */       TRANSITION[''][108] = '';
/* 3187 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3188 */       TRANSITION[''][84] = '';
/* 3189 */       TRANSITION[''][116] = '';
/* 3190 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3191 */       TRANSITION[''][69] = '';
/* 3192 */       TRANSITION[''][101] = '';
/* 3193 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3194 */       TRANSITION[''][82] = '';
/* 3195 */       TRANSITION[''][114] = '';
/* 3196 */       TRANSITION[''] = copyReplacing(arrayOfInt4, 57, 140);
/* 3197 */       TRANSITION[''][47] = '';
/* 3198 */       TRANSITION[''][45] = '';
/*      */       
/* 3200 */       TRANSITION[''] = copyReplacing(arrayOfInt4, 57, 140);
/* 3201 */       TRANSITION[''][47] = '';
/* 3202 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3203 */       TRANSITION[''][42] = '';
/* 3204 */       TRANSITION[''] = newArray(128, 149);
/* 3205 */       TRANSITION[''][42] = '';
/* 3206 */       TRANSITION[''] = newArray(128, 149);
/* 3207 */       TRANSITION[''][47] = '';
/*      */       
/* 3209 */       TRANSITION[''][45] = '';
/* 3210 */       TRANSITION[''] = copy(arrayOfInt5);
/* 3211 */       TRANSITION[''][45] = '';
/* 3212 */       TRANSITION[''] = newArray(128, 152);
/* 3213 */       TRANSITION[''][10] = '';
/* 3214 */       TRANSITION[''][83] = '';
/* 3215 */       TRANSITION[''][115] = '';
/*      */       
/* 3217 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3218 */       TRANSITION[''][69] = '';
/* 3219 */       TRANSITION[''][101] = '';
/* 3220 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3221 */       TRANSITION[''][83] = '';
/* 3222 */       TRANSITION[''][115] = '';
/* 3223 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3224 */       TRANSITION[''][83] = '';
/* 3225 */       TRANSITION[''][115] = '';
/* 3226 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3227 */       TRANSITION[''][73] = '';
/* 3228 */       TRANSITION[''][105] = '';
/* 3229 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3230 */       TRANSITION[''][79] = '';
/* 3231 */       TRANSITION[''][111] = '';
/* 3232 */       TRANSITION[''] = copy(arrayOfInt2);
/* 3233 */       TRANSITION[''][78] = '';
/* 3234 */       TRANSITION[''][110] = '';
/* 3235 */       TRANSITION[''] = arrayOfInt5;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3242 */       Object localObject1 = newArray(128, 0);
/*      */       
/* 3244 */       Object localObject2 = copy((int[])localObject1);
/* 3245 */       localObject2[63] = 14;
/*      */       
/* 3247 */       Object localObject3 = copy((int[])localObject2);
/* 3248 */       localObject3[123] = 5;
/*      */       
/* 3250 */       Object localObject4 = new int[''];
/*      */       
/* 3252 */       for (int i = 0; i < localObject4.length; i++) {
/* 3253 */         if (TRANSITION[8][i] == 8) {
/* 3254 */           localObject4[i] = 15;
/*      */         } else
/* 3256 */           localObject4[i] = 16;
/*      */       }
/* 3258 */       Object localObject5 = new int[''];
/*      */       
/* 3260 */       for (int j = 0; j < localObject5.length; j++) {
/* 3261 */         if (TRANSITION[65][j] == 65) {
/* 3262 */           localObject5[j] = 15;
/*      */         } else
/* 3264 */           localObject5[j] = 16;
/*      */       }
/* 3266 */       Object localObject6 = copy((int[])localObject5);
/* 3267 */       localObject6[32] = 0;
/* 3268 */       localObject6[10] = 0;
/* 3269 */       localObject6[9] = 0;
/* 3270 */       localObject6[13] = 0;
/*      */       
/* 3272 */       Object localObject7 = copy((int[])localObject1);
/*      */       
/* 3274 */       for (int k = 0; k < localObject7.length; k++) {
/* 3275 */         if (arrayOfInt4[k] != 66)
/* 3276 */           localObject7[k] = 5;
/*      */       }
/* 3278 */       Object localObject8 = copyReplacing((int[])localObject7, 5, 6);
/* 3279 */       int[] arrayOfInt7 = copyReplacing((int[])localObject7, 5, 1);
/* 3280 */       int[] arrayOfInt8 = copyReplacing((int[])localObject7, 5, 2);
/* 3281 */       int[] arrayOfInt9 = copyReplacing((int[])localObject7, 5, 3);
/* 3282 */       int[] arrayOfInt10 = copyReplacing((int[])localObject7, 5, 4);
/* 3283 */       int[] arrayOfInt11 = copyReplacing((int[])localObject7, 5, 7);
/* 3284 */       int[] arrayOfInt12 = copyReplacing((int[])localObject7, 5, 8);
/* 3285 */       arrayOfInt12[123] = 6;
/*      */       
/* 3287 */       int[] arrayOfInt13 = copyReplacing((int[])localObject7, 5, 10);
/*      */       
/* 3289 */       for (int i1 = 0; i1 < arrayOfInt13.length; i1++) {
/* 3290 */         if (arrayOfInt13[i1] == 8) {
/* 3291 */           arrayOfInt13[i1] = 0;
/*      */         }
/*      */       }
/* 3294 */       int[] arrayOfInt14 = copyReplacing(arrayOfInt13, 10, 11);
/* 3295 */       int[] arrayOfInt15 = copyReplacing(arrayOfInt13, 10, 9);
/* 3296 */       int[] arrayOfInt16 = copyReplacing(arrayOfInt13, 10, 12);
/* 3297 */       int[] arrayOfInt17 = copyReplacing(arrayOfInt13, 10, 13);
/* 3298 */       int[] arrayOfInt18 = copyReplacing(arrayOfInt13, 10, 21);
/* 3299 */       int[] arrayOfInt19 = copyReplacing(arrayOfInt13, 10, 22);
/* 3300 */       int[] arrayOfInt20 = copyReplacing(arrayOfInt13, 10, 23);
/*      */       
/* 3302 */       int[] arrayOfInt21 = copy((int[])localObject1);
/* 3303 */       arrayOfInt21[39] = 17;
/*      */       
/* 3305 */       int[] arrayOfInt22 = copyReplacing((int[])localObject1, 0, 18);
/* 3306 */       arrayOfInt22[39] = 0;
/*      */       
/* 3308 */       int[] arrayOfInt23 = copyReplacing((int[])localObject1, 0, 19);
/*      */       
/* 3310 */       int[] arrayOfInt24 = copyReplacing((int[])localObject1, 0, 20);
/*      */       
/* 3312 */       int[] arrayOfInt25 = copy(arrayOfInt24);
/* 3313 */       arrayOfInt25[39] = 0;
/*      */       
/* 3315 */       ACTION[0] = localObject3;
/* 3316 */       ACTION[1] = localObject3;
/* 3317 */       ACTION[2] = localObject3;
/* 3318 */       ACTION[3] = localObject1;
/* 3319 */       ACTION[4] = localObject1;
/* 3320 */       ACTION[5] = localObject1;
/* 3321 */       ACTION[6] = localObject1;
/* 3322 */       ACTION[7] = localObject1;
/* 3323 */       ACTION[8] = localObject4;
/* 3324 */       ACTION[''] = localObject6;
/* 3325 */       ACTION[100] = arrayOfInt21;
/* 3326 */       ACTION[101] = arrayOfInt22;
/* 3327 */       ACTION[105] = localObject1;
/* 3328 */       ACTION[106] = arrayOfInt23;
/* 3329 */       ACTION[107] = arrayOfInt24;
/* 3330 */       ACTION[108] = null;
/* 3331 */       ACTION[109] = arrayOfInt25;
/* 3332 */       ACTION[9] = arrayOfInt12;
/* 3333 */       ACTION[10] = arrayOfInt12;
/* 3334 */       ACTION[11] = arrayOfInt12;
/* 3335 */       ACTION[12] = arrayOfInt12;
/* 3336 */       ACTION[13] = arrayOfInt12;
/* 3337 */       ACTION[14] = localObject7;
/* 3338 */       ACTION[15] = arrayOfInt12;
/* 3339 */       ACTION[16] = arrayOfInt12;
/* 3340 */       ACTION[17] = arrayOfInt12;
/* 3341 */       ACTION[18] = localObject8;
/* 3342 */       ACTION[19] = arrayOfInt12;
/* 3343 */       ACTION[20] = arrayOfInt12;
/* 3344 */       ACTION[21] = arrayOfInt12;
/* 3345 */       ACTION[22] = arrayOfInt12;
/* 3346 */       ACTION[23] = arrayOfInt12;
/* 3347 */       ACTION[24] = arrayOfInt12;
/* 3348 */       ACTION[25] = localObject7;
/* 3349 */       ACTION[26] = arrayOfInt12;
/* 3350 */       ACTION[27] = arrayOfInt12;
/* 3351 */       ACTION[28] = arrayOfInt12;
/* 3352 */       ACTION[29] = arrayOfInt7;
/* 3353 */       ACTION[30] = arrayOfInt12;
/* 3354 */       ACTION[31] = arrayOfInt12;
/* 3355 */       ACTION[32] = arrayOfInt12;
/* 3356 */       ACTION[33] = arrayOfInt12;
/* 3357 */       ACTION[34] = arrayOfInt12;
/* 3358 */       ACTION[35] = arrayOfInt8;
/* 3359 */       ACTION[36] = arrayOfInt12;
/* 3360 */       ACTION[37] = arrayOfInt12;
/* 3361 */       ACTION[38] = arrayOfInt12;
/* 3362 */       ACTION[39] = arrayOfInt12;
/* 3363 */       ACTION[40] = arrayOfInt12;
/* 3364 */       ACTION[41] = arrayOfInt11;
/* 3365 */       ACTION[42] = arrayOfInt12;
/* 3366 */       ACTION[43] = arrayOfInt12;
/* 3367 */       ACTION[44] = arrayOfInt12;
/* 3368 */       ACTION[45] = arrayOfInt12;
/* 3369 */       ACTION[46] = arrayOfInt12;
/* 3370 */       ACTION[47] = arrayOfInt10;
/* 3371 */       ACTION[48] = arrayOfInt12;
/* 3372 */       ACTION[49] = arrayOfInt12;
/* 3373 */       ACTION[50] = arrayOfInt12;
/* 3374 */       ACTION[51] = arrayOfInt12;
/* 3375 */       ACTION[52] = arrayOfInt9;
/* 3376 */       ACTION[53] = arrayOfInt12;
/* 3377 */       ACTION[54] = arrayOfInt12;
/* 3378 */       ACTION[55] = arrayOfInt12;
/* 3379 */       ACTION[56] = arrayOfInt11;
/* 3380 */       ACTION[66] = localObject2;
/* 3381 */       ACTION[58] = localObject2;
/* 3382 */       ACTION[59] = localObject2;
/* 3383 */       ACTION[60] = localObject1;
/* 3384 */       ACTION[61] = localObject1;
/* 3385 */       ACTION[62] = localObject1;
/* 3386 */       ACTION[63] = localObject1;
/* 3387 */       ACTION[64] = localObject1;
/* 3388 */       ACTION[65] = localObject5;
/* 3389 */       ACTION[102] = arrayOfInt21;
/* 3390 */       ACTION[103] = localObject1;
/* 3391 */       ACTION[104] = arrayOfInt22;
/* 3392 */       ACTION[110] = localObject1;
/* 3393 */       ACTION[111] = arrayOfInt23;
/* 3394 */       ACTION[112] = arrayOfInt24;
/* 3395 */       ACTION[113] = null;
/* 3396 */       ACTION[114] = arrayOfInt25;
/*      */       
/* 3398 */       ACTION[57] = localObject2;
/*      */       
/* 3400 */       ACTION[67] = localObject1;
/* 3401 */       ACTION[68] = localObject1;
/* 3402 */       ACTION[69] = localObject1;
/* 3403 */       ACTION[70] = localObject1;
/* 3404 */       ACTION[71] = arrayOfInt15;
/*      */       
/* 3406 */       ACTION[72] = localObject1;
/* 3407 */       ACTION[73] = localObject1;
/* 3408 */       ACTION[74] = localObject1;
/* 3409 */       ACTION[75] = localObject1;
/* 3410 */       ACTION[76] = arrayOfInt13;
/*      */       
/* 3412 */       ACTION[77] = localObject1;
/* 3413 */       ACTION[78] = localObject1;
/* 3414 */       ACTION[79] = arrayOfInt14;
/*      */       
/* 3416 */       ACTION[80] = localObject1;
/* 3417 */       ACTION[81] = localObject1;
/* 3418 */       ACTION[82] = localObject1;
/* 3419 */       ACTION[83] = localObject1;
/* 3420 */       ACTION[84] = localObject1;
/*      */       
/* 3422 */       ACTION[85] = localObject1;
/* 3423 */       ACTION[86] = localObject1;
/* 3424 */       ACTION[87] = arrayOfInt16;
/*      */       
/* 3426 */       ACTION[88] = localObject2;
/* 3427 */       ACTION[89] = localObject1;
/* 3428 */       ACTION[90] = localObject1;
/* 3429 */       ACTION[91] = localObject1;
/* 3430 */       ACTION[92] = localObject1;
/* 3431 */       ACTION[93] = localObject1;
/* 3432 */       ACTION[94] = arrayOfInt17;
/*      */       
/* 3434 */       ACTION[95] = localObject1;
/* 3435 */       ACTION[96] = localObject1;
/* 3436 */       ACTION[97] = localObject1;
/* 3437 */       ACTION[98] = localObject1;
/* 3438 */       ACTION[99] = localObject1;
/*      */       
/* 3440 */       ACTION[115] = copy((int[])localObject1);
/* 3441 */       ACTION[115][63] = 14;
/* 3442 */       ACTION[116] = localObject1;
/* 3443 */       ACTION[117] = localObject1;
/* 3444 */       ACTION[118] = localObject1;
/* 3445 */       ACTION[119] = localObject1;
/* 3446 */       ACTION[120] = localObject1;
/* 3447 */       ACTION[121] = localObject1;
/* 3448 */       ACTION[122] = localObject1;
/* 3449 */       ACTION[123] = localObject1;
/* 3450 */       ACTION[124] = localObject1;
/* 3451 */       ACTION[125] = localObject1;
/* 3452 */       ACTION[126] = localObject1;
/* 3453 */       ACTION[127] = localObject1;
/* 3454 */       ACTION[''] = localObject1;
/* 3455 */       ACTION[''] = localObject1;
/* 3456 */       ACTION[''] = localObject1;
/* 3457 */       ACTION[''] = localObject1;
/* 3458 */       ACTION[''] = localObject1;
/* 3459 */       ACTION[''] = localObject1;
/*      */       
/* 3461 */       ACTION[''] = localObject1;
/* 3462 */       ACTION[''] = localObject1;
/* 3463 */       ACTION[''] = localObject1;
/* 3464 */       ACTION[''] = localObject1;
/* 3465 */       ACTION[''] = arrayOfInt12;
/*      */       
/* 3467 */       ACTION[''] = localObject2;
/* 3468 */       ACTION[''] = localObject1;
/* 3469 */       ACTION[''] = localObject1;
/* 3470 */       ACTION[''] = localObject1;
/* 3471 */       ACTION[''] = localObject1;
/* 3472 */       ACTION[''] = localObject1;
/* 3473 */       ACTION[''] = localObject1;
/* 3474 */       ACTION[''] = arrayOfInt18;
/*      */       
/* 3476 */       ACTION[''] = localObject1;
/* 3477 */       ACTION[''] = localObject1;
/* 3478 */       ACTION[''] = localObject1;
/* 3479 */       ACTION[''] = localObject1;
/* 3480 */       ACTION[''] = localObject1;
/*      */       
/* 3482 */       ACTION[''] = localObject1;
/* 3483 */       ACTION[''] = localObject1;
/* 3484 */       ACTION[''] = localObject1;
/* 3485 */       ACTION[''] = localObject1;
/* 3486 */       ACTION[''] = localObject1;
/* 3487 */       ACTION[''] = localObject1;
/* 3488 */       ACTION[''] = localObject1;
/* 3489 */       ACTION[' '] = localObject1;
/* 3490 */       ACTION['¡'] = arrayOfInt19;
/*      */       
/* 3492 */       ACTION['¢'] = localObject1;
/* 3493 */       ACTION['£'] = localObject1;
/* 3494 */       ACTION['¤'] = localObject1;
/* 3495 */       ACTION['¥'] = arrayOfInt20;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3503 */       localObject1 = newArray(128, ODBCAction.NONE);
/*      */       
/* 3505 */       localObject2 = newArray(128, ODBCAction.COPY);
/*      */       
/* 3507 */       localObject3 = copy((ODBCAction[])localObject2);
/* 3508 */       localObject3[123] = ODBCAction.NONE;
/* 3509 */       localObject3[63] = ODBCAction.QUESTION;
/* 3510 */       localObject3[125] = ODBCAction.END_ODBC_ESCAPE;
/* 3511 */       localObject3[44] = ODBCAction.COMMA;
/* 3512 */       localObject3[40] = ODBCAction.OPEN_PAREN;
/* 3513 */       localObject3[41] = ODBCAction.CLOSE_PAREN;
/*      */       
/* 3515 */       localObject4 = copyReplacing((ODBCAction[])localObject2, ODBCAction.COPY, ODBCAction.SAVE_DELIMITER);
/*      */       
/* 3517 */       localObject5 = copyReplacing((ODBCAction[])localObject2, ODBCAction.COPY, ODBCAction.LOOK_FOR_DELIMITER);
/*      */       
/* 3519 */       localObject6 = copy((ODBCAction[])localObject5);
/* 3520 */       localObject6[39] = ODBCAction.COPY;
/*      */       
/* 3522 */       localObject7 = newArray(128, ODBCAction.UNKNOWN_ESCAPE);
/*      */       
/* 3524 */       localObject8 = copy((ODBCAction[])localObject1);
/* 3525 */       for (int m = 0; m < arrayOfInt1.length; m++) {
/* 3526 */         if (arrayOfInt1[m] == 9) { localObject8[m] = ODBCAction.UNKNOWN_ESCAPE;
/*      */         }
/*      */       }
/* 3529 */       ODBCAction[] arrayOfODBCAction = copy((ODBCAction[])localObject3);
/* 3530 */       for (int n = 0; n < arrayOfInt1.length; n++) {
/* 3531 */         if (arrayOfInt1[n] != 9) { arrayOfODBCAction[n] = ODBCAction.BEGIN;
/*      */         }
/*      */       }
/* 3534 */       ODBC_ACTION[0] = localObject3;
/* 3535 */       ODBC_ACTION[1] = localObject3;
/* 3536 */       ODBC_ACTION[2] = localObject3;
/* 3537 */       ODBC_ACTION[3] = localObject2;
/* 3538 */       ODBC_ACTION[4] = localObject3;
/* 3539 */       ODBC_ACTION[5] = localObject2;
/* 3540 */       ODBC_ACTION[6] = localObject2;
/* 3541 */       ODBC_ACTION[7] = localObject2;
/* 3542 */       ODBC_ACTION[8] = localObject3;
/* 3543 */       ODBC_ACTION[''] = localObject3;
/* 3544 */       ODBC_ACTION[100] = localObject2;
/* 3545 */       ODBC_ACTION[101] = localObject2;
/* 3546 */       ODBC_ACTION[105] = localObject2;
/* 3547 */       ODBC_ACTION[106] = localObject4;
/* 3548 */       ODBC_ACTION[107] = localObject5;
/* 3549 */       ODBC_ACTION[108] = null;
/* 3550 */       ODBC_ACTION[109] = localObject6;
/* 3551 */       ODBC_ACTION[9] = localObject3;
/* 3552 */       ODBC_ACTION[10] = localObject3;
/* 3553 */       ODBC_ACTION[11] = localObject3;
/* 3554 */       ODBC_ACTION[12] = localObject3;
/* 3555 */       ODBC_ACTION[13] = localObject3;
/* 3556 */       ODBC_ACTION[14] = arrayOfODBCAction;
/* 3557 */       ODBC_ACTION[15] = localObject3;
/* 3558 */       ODBC_ACTION[16] = localObject3;
/* 3559 */       ODBC_ACTION[17] = localObject3;
/* 3560 */       ODBC_ACTION[18] = localObject3;
/* 3561 */       ODBC_ACTION[19] = localObject3;
/* 3562 */       ODBC_ACTION[20] = localObject3;
/* 3563 */       ODBC_ACTION[21] = localObject3;
/* 3564 */       ODBC_ACTION[22] = localObject3;
/* 3565 */       ODBC_ACTION[23] = localObject3;
/* 3566 */       ODBC_ACTION[24] = localObject3;
/* 3567 */       ODBC_ACTION[25] = localObject3;
/* 3568 */       ODBC_ACTION[26] = localObject3;
/* 3569 */       ODBC_ACTION[27] = localObject3;
/* 3570 */       ODBC_ACTION[28] = localObject3;
/* 3571 */       ODBC_ACTION[29] = localObject3;
/* 3572 */       ODBC_ACTION[30] = localObject3;
/* 3573 */       ODBC_ACTION[31] = localObject3;
/* 3574 */       ODBC_ACTION[32] = localObject3;
/* 3575 */       ODBC_ACTION[33] = localObject3;
/* 3576 */       ODBC_ACTION[34] = localObject3;
/* 3577 */       ODBC_ACTION[35] = localObject3;
/* 3578 */       ODBC_ACTION[36] = localObject3;
/* 3579 */       ODBC_ACTION[37] = localObject3;
/* 3580 */       ODBC_ACTION[38] = localObject3;
/* 3581 */       ODBC_ACTION[39] = localObject3;
/* 3582 */       ODBC_ACTION[40] = localObject3;
/* 3583 */       ODBC_ACTION[41] = localObject3;
/* 3584 */       ODBC_ACTION[42] = localObject3;
/* 3585 */       ODBC_ACTION[43] = localObject3;
/* 3586 */       ODBC_ACTION[44] = localObject3;
/* 3587 */       ODBC_ACTION[45] = localObject3;
/* 3588 */       ODBC_ACTION[46] = localObject3;
/* 3589 */       ODBC_ACTION[47] = localObject3;
/* 3590 */       ODBC_ACTION[48] = localObject3;
/* 3591 */       ODBC_ACTION[49] = localObject3;
/* 3592 */       ODBC_ACTION[50] = localObject3;
/* 3593 */       ODBC_ACTION[51] = localObject3;
/* 3594 */       ODBC_ACTION[52] = localObject3;
/* 3595 */       ODBC_ACTION[53] = localObject3;
/* 3596 */       ODBC_ACTION[54] = localObject3;
/* 3597 */       ODBC_ACTION[55] = localObject3;
/* 3598 */       ODBC_ACTION[56] = localObject3;
/* 3599 */       ODBC_ACTION[66] = localObject3;
/* 3600 */       ODBC_ACTION[58] = localObject3;
/* 3601 */       ODBC_ACTION[59] = localObject3;
/* 3602 */       ODBC_ACTION[60] = localObject2;
/* 3603 */       ODBC_ACTION[61] = localObject2;
/* 3604 */       ODBC_ACTION[62] = localObject2;
/* 3605 */       ODBC_ACTION[63] = localObject2;
/* 3606 */       ODBC_ACTION[64] = localObject2;
/* 3607 */       ODBC_ACTION[65] = localObject3;
/* 3608 */       ODBC_ACTION[102] = localObject2;
/* 3609 */       ODBC_ACTION[103] = localObject2;
/* 3610 */       ODBC_ACTION[104] = localObject2;
/* 3611 */       ODBC_ACTION[110] = localObject2;
/* 3612 */       ODBC_ACTION[111] = localObject4;
/* 3613 */       ODBC_ACTION[112] = localObject5;
/* 3614 */       ODBC_ACTION[113] = null;
/* 3615 */       ODBC_ACTION[114] = localObject6;
/*      */       
/* 3617 */       ODBC_ACTION[57] = localObject3;
/*      */       
/* 3619 */       ODBC_ACTION[67] = localObject3;
/* 3620 */       ODBC_ACTION[68] = localObject3;
/* 3621 */       ODBC_ACTION[69] = localObject3;
/* 3622 */       ODBC_ACTION[70] = localObject3;
/* 3623 */       ODBC_ACTION[71] = localObject3;
/*      */       
/* 3625 */       ODBC_ACTION[72] = localObject3;
/* 3626 */       ODBC_ACTION[73] = localObject3;
/* 3627 */       ODBC_ACTION[74] = localObject3;
/* 3628 */       ODBC_ACTION[75] = localObject3;
/* 3629 */       ODBC_ACTION[76] = localObject3;
/*      */       
/* 3631 */       ODBC_ACTION[77] = localObject3;
/* 3632 */       ODBC_ACTION[78] = localObject3;
/* 3633 */       ODBC_ACTION[79] = localObject3;
/*      */       
/* 3635 */       ODBC_ACTION[80] = localObject3;
/* 3636 */       ODBC_ACTION[81] = localObject3;
/* 3637 */       ODBC_ACTION[82] = localObject3;
/* 3638 */       ODBC_ACTION[83] = localObject3;
/* 3639 */       ODBC_ACTION[84] = localObject3;
/*      */       
/* 3641 */       ODBC_ACTION[85] = localObject3;
/* 3642 */       ODBC_ACTION[86] = localObject3;
/* 3643 */       ODBC_ACTION[87] = localObject3;
/*      */       
/* 3645 */       ODBC_ACTION[88] = localObject3;
/* 3646 */       ODBC_ACTION[89] = localObject3;
/* 3647 */       ODBC_ACTION[90] = localObject3;
/* 3648 */       ODBC_ACTION[91] = localObject3;
/* 3649 */       ODBC_ACTION[92] = localObject3;
/* 3650 */       ODBC_ACTION[93] = localObject3;
/* 3651 */       ODBC_ACTION[94] = localObject3;
/*      */       
/* 3653 */       ODBC_ACTION[95] = localObject3;
/* 3654 */       ODBC_ACTION[96] = localObject3;
/* 3655 */       ODBC_ACTION[97] = localObject3;
/* 3656 */       ODBC_ACTION[98] = localObject3;
/* 3657 */       ODBC_ACTION[99] = localObject3;
/*      */       
/* 3659 */       ODBC_ACTION[115] = copy((ODBCAction[])localObject8);
/* 3660 */       ODBC_ACTION[115][63] = ODBCAction.NONE;
/* 3661 */       ODBC_ACTION[115][99] = ODBCAction.NONE;
/* 3662 */       ODBC_ACTION[115][67] = ODBCAction.NONE;
/* 3663 */       ODBC_ACTION[115][116] = ODBCAction.NONE;
/* 3664 */       ODBC_ACTION[115][84] = ODBCAction.NONE;
/* 3665 */       ODBC_ACTION[115][100] = ODBCAction.NONE;
/* 3666 */       ODBC_ACTION[115][68] = ODBCAction.NONE;
/* 3667 */       ODBC_ACTION[115][101] = ODBCAction.NONE;
/* 3668 */       ODBC_ACTION[115][69] = ODBCAction.NONE;
/* 3669 */       ODBC_ACTION[115][102] = ODBCAction.NONE;
/* 3670 */       ODBC_ACTION[115][70] = ODBCAction.NONE;
/* 3671 */       ODBC_ACTION[115][111] = ODBCAction.NONE;
/* 3672 */       ODBC_ACTION[115][79] = ODBCAction.NONE;
/* 3673 */       ODBC_ACTION[116] = newArray(128, ODBCAction.FUNCTION);
/* 3674 */       ODBC_ACTION[117] = copy((ODBCAction[])localObject7);
/* 3675 */       ODBC_ACTION[117][97] = ODBCAction.NONE;
/* 3676 */       ODBC_ACTION[117][65] = ODBCAction.NONE;
/* 3677 */       ODBC_ACTION[118] = copy((ODBCAction[])localObject7);
/* 3678 */       ODBC_ACTION[118][108] = ODBCAction.NONE;
/* 3679 */       ODBC_ACTION[118][76] = ODBCAction.NONE;
/* 3680 */       ODBC_ACTION[119] = copy((ODBCAction[])localObject7);
/* 3681 */       ODBC_ACTION[119][108] = ODBCAction.NONE;
/* 3682 */       ODBC_ACTION[119][76] = ODBCAction.NONE;
/* 3683 */       ODBC_ACTION[120] = copyReplacing((ODBCAction[])localObject8, ODBCAction.NONE, ODBCAction.CALL);
/* 3684 */       ODBC_ACTION[121] = copyReplacing((ODBCAction[])localObject8, ODBCAction.NONE, ODBCAction.TIME);
/* 3685 */       ODBC_ACTION[121][115] = ODBCAction.NONE;
/* 3686 */       ODBC_ACTION[121][83] = ODBCAction.NONE;
/* 3687 */       ODBC_ACTION[122] = copyReplacing((ODBCAction[])localObject8, ODBCAction.NONE, ODBCAction.TIMESTAMP);
/* 3688 */       ODBC_ACTION[123] = copyReplacing((ODBCAction[])localObject8, ODBCAction.NONE, ODBCAction.DATE);
/* 3689 */       ODBC_ACTION[124] = copy((ODBCAction[])localObject7);
/* 3690 */       ODBC_ACTION[124][115] = ODBCAction.NONE;
/* 3691 */       ODBC_ACTION[124][83] = ODBCAction.NONE;
/* 3692 */       ODBC_ACTION[125] = copy((ODBCAction[])localObject7);
/* 3693 */       ODBC_ACTION[125][99] = ODBCAction.NONE;
/* 3694 */       ODBC_ACTION[125][67] = ODBCAction.NONE;
/* 3695 */       ODBC_ACTION[126] = copy((ODBCAction[])localObject7);
/* 3696 */       ODBC_ACTION[126][97] = ODBCAction.NONE;
/* 3697 */       ODBC_ACTION[126][65] = ODBCAction.NONE;
/* 3698 */       ODBC_ACTION[127] = copy((ODBCAction[])localObject7);
/* 3699 */       ODBC_ACTION[127][112] = ODBCAction.NONE;
/* 3700 */       ODBC_ACTION[127][80] = ODBCAction.NONE;
/* 3701 */       ODBC_ACTION[''] = copy((ODBCAction[])localObject7);
/* 3702 */       ODBC_ACTION[''][101] = ODBCAction.NONE;
/* 3703 */       ODBC_ACTION[''][69] = ODBCAction.NONE;
/* 3704 */       ODBC_ACTION[''] = copyReplacing((ODBCAction[])localObject8, ODBCAction.NONE, ODBCAction.ESCAPE);
/* 3705 */       ODBC_ACTION[''] = copy((ODBCAction[])localObject7);
/* 3706 */       ODBC_ACTION[''][110] = ODBCAction.NONE;
/* 3707 */       ODBC_ACTION[''][78] = ODBCAction.NONE;
/* 3708 */       ODBC_ACTION[''] = copyReplacing((ODBCAction[])localObject8, ODBCAction.NONE, ODBCAction.SCALAR_FUNCTION);
/* 3709 */       ODBC_ACTION[''] = copy((ODBCAction[])localObject7);
/* 3710 */       ODBC_ACTION[''][106] = ODBCAction.NONE;
/* 3711 */       ODBC_ACTION[''][74] = ODBCAction.NONE;
/* 3712 */       ODBC_ACTION[''] = copyReplacing((ODBCAction[])localObject8, ODBCAction.NONE, ODBCAction.OUTER_JOIN);
/*      */       
/* 3714 */       ODBC_ACTION[''] = localObject3;
/* 3715 */       ODBC_ACTION[''] = localObject3;
/* 3716 */       ODBC_ACTION[''] = localObject3;
/* 3717 */       ODBC_ACTION[''] = localObject3;
/* 3718 */       ODBC_ACTION[''] = localObject3;
/*      */       
/* 3720 */       ODBC_ACTION[''] = localObject3;
/* 3721 */       ODBC_ACTION[''] = localObject3;
/* 3722 */       ODBC_ACTION[''] = localObject3;
/* 3723 */       ODBC_ACTION[''] = localObject3;
/* 3724 */       ODBC_ACTION[''] = localObject3;
/* 3725 */       ODBC_ACTION[''] = localObject3;
/* 3726 */       ODBC_ACTION[''] = localObject3;
/* 3727 */       ODBC_ACTION[''] = localObject3;
/*      */       
/* 3729 */       ODBC_ACTION[''] = localObject3;
/* 3730 */       ODBC_ACTION[''] = localObject3;
/* 3731 */       ODBC_ACTION[''] = localObject3;
/* 3732 */       ODBC_ACTION[''] = localObject3;
/* 3733 */       ODBC_ACTION[''] = localObject3;
/*      */       
/* 3735 */       ODBC_ACTION[''] = localObject3;
/* 3736 */       ODBC_ACTION[''] = localObject3;
/* 3737 */       ODBC_ACTION[''] = localObject3;
/* 3738 */       ODBC_ACTION[''] = localObject3;
/* 3739 */       ODBC_ACTION[''] = localObject3;
/* 3740 */       ODBC_ACTION[''] = localObject3;
/* 3741 */       ODBC_ACTION[''] = localObject3;
/* 3742 */       ODBC_ACTION[' '] = localObject3;
/* 3743 */       ODBC_ACTION['¡'] = localObject3;
/*      */       
/* 3745 */       ODBC_ACTION['¢'] = localObject3;
/* 3746 */       ODBC_ACTION['£'] = localObject3;
/* 3747 */       ODBC_ACTION['¤'] = localObject3;
/* 3748 */       ODBC_ACTION['¥'] = localObject3;
/*      */     } catch (Throwable localThrowable) {
/* 3750 */       localThrowable.printStackTrace();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OracleSqlReadOnly.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */