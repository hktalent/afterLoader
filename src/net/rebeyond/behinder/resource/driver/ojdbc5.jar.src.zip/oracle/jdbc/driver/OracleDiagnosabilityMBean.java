/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.StandardMBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleDiagnosabilityMBean
/*     */   extends StandardMBean
/*     */   implements DiagnosabilityMXBean
/*     */ {
/*     */   OracleDiagnosabilityMBean()
/*     */     throws NotCompliantMBeanException
/*     */   {
/*  36 */     super(DiagnosabilityMXBean.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getLoggingEnabled()
/*     */   {
/*  52 */     return OracleLog.isEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoggingEnabled(boolean paramBoolean)
/*     */   {
/*  68 */     OracleLog.setTrace(paramBoolean);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean stateManageable()
/*     */   {
/*  79 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean statisticsProvider()
/*     */   {
/*  90 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanInfo paramMBeanInfo)
/*     */   {
/*  98 */     return DatabaseError.findMessage("DiagnosabilityMBeanDescription", this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanConstructorInfo paramMBeanConstructorInfo)
/*     */   {
/* 107 */     return DatabaseError.findMessage("DiagnosabilityMBeanConstructor()", this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanAttributeInfo paramMBeanAttributeInfo)
/*     */   {
/* 115 */     String str = paramMBeanAttributeInfo.getName();
/* 116 */     if (str.equals("LoggingEnabled")) {
/* 117 */       return DatabaseError.findMessage("DiagnosabilityMBeanLoggingEnabledDescription", this);
/*     */     }
/* 119 */     if (str.equals("stateManageable")) {
/* 120 */       return DatabaseError.findMessage("DiagnosabilityMBeanStateManageableDescription", this);
/*     */     }
/* 122 */     if (str.equals("statisticsProvider")) {
/* 123 */       return DatabaseError.findMessage("DiagnosabilityMBeanStatisticsProviderDescription", this);
/*     */     }
/*     */     
/* 126 */     Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "Got a request to describe an unexpected  Attribute: " + str);
/*     */     
/*     */ 
/* 129 */     return super.getDescription(paramMBeanAttributeInfo);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OracleDiagnosabilityMBean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */