package oracle.jdbc.rowset;

import javax.sql.rowset.spi.XmlReader;

public abstract interface OracleWebRowSetXmlReader
  extends XmlReader
{}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/rowset/OracleWebRowSetXmlReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */