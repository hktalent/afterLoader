/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSEvent
/*    */   extends EventObject
/*    */ {
/*    */   protected XSEvent(Object paramObject)
/*    */   {
/* 39 */     super(paramObject);
/*    */   }
/*    */   
/*    */   public abstract byte[] getSessionId();
/*    */   
/*    */   public abstract KeywordValueLong[] getDetails();
/*    */   
/*    */   public abstract int getFlags();
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/internal/XSEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */