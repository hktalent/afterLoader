/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleData;
/*      */ import oracle.jdbc.OracleResultSet.AuthorizationIndicator;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class UpdatableResultSet
/*      */   extends BaseResultSet
/*      */ {
/*      */   static final int concurrencyType = 1008;
/*      */   static final int BEGIN_COLUMN_INDEX = 1;
/*      */   static final int MAX_CHAR_BUFFER_SIZE = 1024;
/*      */   static final int MAX_BYTE_BUFFER_SIZE = 1024;
/*      */   PhysicalConnection connection;
/*      */   OracleResultSet resultSet;
/*      */   boolean isCachedRset;
/*      */   ScrollRsetStatement scrollStmt;
/*      */   ResultSetMetaData rsetMetaData;
/*      */   private int rsetType;
/*      */   private int columnCount;
/*      */   private OraclePreparedStatement deleteStmt;
/*      */   private OraclePreparedStatement insertStmt;
/*      */   private OraclePreparedStatement updateStmt;
/*      */   private int[] indexColsChanged;
/*      */   private Object[] rowBuffer;
/*      */   private boolean[] m_nullIndicator;
/*      */   private int[][] typeInfo;
/*      */   private boolean isInserting;
/*      */   private boolean isUpdating;
/*      */   private int wasNull;
/*      */   private static final int VALUE_NULL = 1;
/*      */   private static final int VALUE_NOT_NULL = 2;
/*      */   private static final int VALUE_UNKNOWN = 3;
/*      */   private static final int VALUE_IN_RSET = 4;
/*      */   private static final int ASCII_STREAM = 1;
/*      */   private static final int BINARY_STREAM = 2;
/*      */   private static final int UNICODE_STREAM = 3;
/*   99 */   private static int _MIN_STREAM_SIZE = 4000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   UpdatableResultSet(ScrollRsetStatement paramScrollRsetStatement, ScrollableResultSet paramScrollableResultSet, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  112 */     init(paramScrollRsetStatement, paramScrollableResultSet, paramInt1, paramInt2);
/*      */     
/*      */ 
/*  115 */     paramScrollableResultSet.resetBeginColumnIndex();
/*  116 */     getInternalMetadata();
/*      */     
/*  118 */     this.isCachedRset = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   UpdatableResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  129 */     init(paramScrollRsetStatement, paramOracleResultSetImpl, paramInt1, paramInt2);
/*  130 */     getInternalMetadata();
/*      */     
/*  132 */     this.isCachedRset = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void init(ScrollRsetStatement paramScrollRsetStatement, OracleResultSet paramOracleResultSet, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  144 */     if ((paramScrollRsetStatement == null) || (paramOracleResultSet == null) || (paramInt2 != 1008))
/*      */     {
/*  146 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  147 */       localSQLException.fillInStackTrace();
/*  148 */       throw localSQLException;
/*      */     }
/*      */     
/*  151 */     this.connection = ((OracleStatement)paramScrollRsetStatement).connection;
/*  152 */     this.resultSet = paramOracleResultSet;
/*  153 */     this.scrollStmt = paramScrollRsetStatement;
/*  154 */     this.rsetType = paramInt1;
/*  155 */     this.deleteStmt = null;
/*  156 */     this.insertStmt = null;
/*  157 */     this.updateStmt = null;
/*  158 */     this.indexColsChanged = null;
/*  159 */     this.rowBuffer = null;
/*  160 */     this.m_nullIndicator = null;
/*  161 */     this.typeInfo = ((int[][])null);
/*  162 */     this.isInserting = false;
/*  163 */     this.isUpdating = false;
/*  164 */     this.wasNull = -1;
/*  165 */     this.rsetMetaData = null;
/*  166 */     this.columnCount = 0;
/*      */   }
/*      */   
/*      */   void ensureOpen() throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*  172 */     if (this.closed)
/*      */     {
/*  174 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  175 */       localSQLException.fillInStackTrace();
/*  176 */       throw localSQLException;
/*      */     }
/*      */     
/*  179 */     if ((this.resultSet == null) || (this.scrollStmt == null) || (((OracleStatement)this.scrollStmt).closed))
/*      */     {
/*      */ 
/*  182 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  183 */       localSQLException.fillInStackTrace();
/*  184 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  198 */     if (this.closed) return;
/*  199 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  202 */       super.close();
/*      */       
/*  204 */       if (this.resultSet != null)
/*  205 */         this.resultSet.close();
/*  206 */       if (this.insertStmt != null)
/*  207 */         this.insertStmt.close();
/*  208 */       if (this.updateStmt != null)
/*  209 */         this.updateStmt.close();
/*  210 */       if (this.deleteStmt != null)
/*  211 */         this.deleteStmt.close();
/*  212 */       if (this.scrollStmt != null) {
/*  213 */         this.scrollStmt.notifyCloseRset();
/*      */       }
/*  215 */       cancelRowInserts();
/*      */       
/*  217 */       this.connection = LogicalConnection.closedConnection;
/*  218 */       this.resultSet = null;
/*  219 */       this.scrollStmt = null;
/*  220 */       this.rsetMetaData = null;
/*  221 */       this.scrollStmt = null;
/*  222 */       this.deleteStmt = null;
/*  223 */       this.insertStmt = null;
/*  224 */       this.updateStmt = null;
/*  225 */       this.indexColsChanged = null;
/*  226 */       this.rowBuffer = null;
/*  227 */       this.m_nullIndicator = null;
/*  228 */       this.typeInfo = ((int[][])null);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  235 */     synchronized (this.connection)
/*      */     {
/*  237 */       ensureOpen();
/*  238 */       switch (this.wasNull)
/*      */       {
/*      */ 
/*      */       case 1: 
/*  242 */         return true;
/*      */       
/*      */       case 2: 
/*  245 */         return false;
/*      */       
/*      */       case 4: 
/*  248 */         return this.resultSet.wasNull();
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*  254 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/*  255 */       localSQLException.fillInStackTrace();
/*  256 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getFirstUserColumnIndex()
/*      */   {
/*  275 */     return 1;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Statement getStatement()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 13	oracle/jdbc/driver/UpdatableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 15	oracle/jdbc/driver/UpdatableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   11: checkcast 40	java/sql/Statement
/*      */     //   14: aload_1
/*      */     //   15: monitorexit
/*      */     //   16: areturn
/*      */     //   17: astore_2
/*      */     //   18: aload_1
/*      */     //   19: monitorexit
/*      */     //   20: aload_2
/*      */     //   21: athrow
/*      */     // Line number table:
/*      */     //   Java source line #282	-> byte code offset #0
/*      */     //   Java source line #284	-> byte code offset #7
/*      */     //   Java source line #286	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	22	0	this	UpdatableResultSet
/*      */     //   5	14	1	Ljava/lang/Object;	Object
/*      */     //   17	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	16	17	finally
/*      */     //   17	20	17	finally
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  292 */     SQLWarning localSQLWarning1 = this.resultSet.getWarnings();
/*      */     
/*  294 */     if (this.sqlWarning == null) {
/*  295 */       return localSQLWarning1;
/*      */     }
/*      */     
/*  298 */     SQLWarning localSQLWarning2 = this.sqlWarning;
/*      */     
/*  300 */     while (localSQLWarning2.getNextWarning() != null) {
/*  301 */       localSQLWarning2 = localSQLWarning2.getNextWarning();
/*      */     }
/*  303 */     localSQLWarning2.setNextWarning(localSQLWarning1);
/*      */     
/*      */ 
/*  306 */     return this.sqlWarning;
/*      */   }
/*      */   
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  313 */     this.sqlWarning = null;
/*      */     
/*  315 */     this.resultSet.clearWarnings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/*  325 */     synchronized (this.connection)
/*      */     {
/*  327 */       ensureOpen();
/*  328 */       cancelRowChanges();
/*      */       
/*  330 */       return this.resultSet.next();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  337 */     synchronized (this.connection)
/*      */     {
/*  339 */       ensureOpen();
/*  340 */       return this.resultSet.isBeforeFirst();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  347 */     synchronized (this.connection)
/*      */     {
/*  349 */       ensureOpen();
/*  350 */       return this.resultSet.isAfterLast();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  357 */     synchronized (this.connection)
/*      */     {
/*  359 */       ensureOpen();
/*  360 */       return this.resultSet.isFirst();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  367 */     synchronized (this.connection)
/*      */     {
/*  369 */       ensureOpen();
/*  370 */       return this.resultSet.isLast();
/*      */     }
/*      */   }
/*      */   
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  377 */     synchronized (this.connection)
/*      */     {
/*  379 */       ensureOpen();
/*  380 */       cancelRowChanges();
/*  381 */       this.resultSet.beforeFirst();
/*      */     }
/*      */   }
/*      */   
/*      */   public void afterLast()
/*      */     throws SQLException
/*      */   {
/*  388 */     synchronized (this.connection)
/*      */     {
/*  390 */       ensureOpen();
/*  391 */       cancelRowChanges();
/*  392 */       this.resultSet.afterLast();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean first()
/*      */     throws SQLException
/*      */   {
/*  399 */     synchronized (this.connection)
/*      */     {
/*  401 */       ensureOpen();
/*  402 */       cancelRowChanges();
/*      */       
/*  404 */       return this.resultSet.first();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/*  411 */     synchronized (this.connection)
/*      */     {
/*  413 */       ensureOpen();
/*  414 */       cancelRowChanges();
/*      */       
/*  416 */       return this.resultSet.last();
/*      */     }
/*      */   }
/*      */   
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/*  423 */     synchronized (this.connection)
/*      */     {
/*  425 */       ensureOpen();
/*  426 */       return this.resultSet.getRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean absolute(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  433 */     synchronized (this.connection)
/*      */     {
/*  435 */       cancelRowChanges();
/*      */       
/*  437 */       return this.resultSet.absolute(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean relative(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  444 */     synchronized (this.connection)
/*      */     {
/*  446 */       ensureOpen();
/*  447 */       cancelRowChanges();
/*      */       
/*  449 */       return this.resultSet.relative(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/*  456 */     synchronized (this.connection)
/*      */     {
/*  458 */       ensureOpen();
/*  459 */       cancelRowChanges();
/*      */       
/*  461 */       return this.resultSet.previous();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  472 */     synchronized (this.connection)
/*      */     {
/*  474 */       ensureOpen();
/*  475 */       Datum localDatum = null;
/*      */       
/*  477 */       setIsNull(3);
/*      */       
/*  479 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  482 */         setIsNull(localDatum == null);
/*      */         
/*  484 */         localDatum = getRowBufferDatumAt(paramInt);
/*      */       }
/*      */       else
/*      */       {
/*  488 */         setIsNull(4);
/*      */         
/*  490 */         localDatum = this.resultSet.getOracleObject(paramInt + 1);
/*      */       }
/*      */       
/*  493 */       return localDatum;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  500 */     synchronized (this.connection)
/*      */     {
/*  502 */       ensureOpen();
/*  503 */       String str = null;
/*      */       
/*  505 */       setIsNull(3);
/*      */       
/*  507 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  510 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  512 */         setIsNull(localDatum == null);
/*      */         
/*  514 */         if (localDatum != null) {
/*  515 */           str = localDatum.stringValue(this.connection);
/*      */         }
/*      */       }
/*      */       else {
/*  519 */         setIsNull(4);
/*      */         
/*  521 */         str = this.resultSet.getString(paramInt + 1);
/*      */       }
/*      */       
/*  524 */       return str;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  531 */     synchronized (this.connection)
/*      */     {
/*  533 */       ensureOpen();
/*  534 */       boolean bool = false;
/*      */       
/*  536 */       setIsNull(3);
/*      */       
/*  538 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  541 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  543 */         setIsNull(localDatum == null);
/*      */         
/*  545 */         if (localDatum != null) {
/*  546 */           bool = localDatum.booleanValue();
/*      */         }
/*      */       }
/*      */       else {
/*  550 */         setIsNull(4);
/*      */         
/*  552 */         bool = this.resultSet.getBoolean(paramInt + 1);
/*      */       }
/*      */       
/*  555 */       return bool;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  563 */     return this.resultSet.getAuthorizationIndicator(paramInt + 1);
/*      */   }
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException
/*      */   {
/*  568 */     synchronized (this.connection)
/*      */     {
/*  570 */       ensureOpen();
/*  571 */       byte b = 0;
/*      */       
/*  573 */       setIsNull(3);
/*      */       
/*  575 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  578 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  580 */         setIsNull(localDatum == null);
/*      */         
/*  582 */         if (localDatum != null) {
/*  583 */           b = localDatum.byteValue();
/*      */         }
/*      */       }
/*      */       else {
/*  587 */         setIsNull(4);
/*      */         
/*  589 */         b = this.resultSet.getByte(paramInt + 1);
/*      */       }
/*      */       
/*  592 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  599 */     synchronized (this.connection)
/*      */     {
/*  601 */       ensureOpen();
/*  602 */       short s = 0;
/*      */       
/*  604 */       setIsNull(3);
/*      */       
/*  606 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  609 */         long l = getLong(paramInt);
/*      */         
/*  611 */         if ((l > 65537L) || (l < -65538L))
/*      */         {
/*  613 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/*  614 */           localSQLException.fillInStackTrace();
/*  615 */           throw localSQLException;
/*      */         }
/*      */         
/*  618 */         s = (short)(int)l;
/*      */       }
/*      */       else
/*      */       {
/*  622 */         setIsNull(4);
/*      */         
/*  624 */         s = this.resultSet.getShort(paramInt + 1);
/*      */       }
/*      */       
/*  627 */       return s;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  634 */     synchronized (this.connection)
/*      */     {
/*  636 */       ensureOpen();
/*  637 */       int i = 0;
/*      */       
/*  639 */       setIsNull(3);
/*      */       
/*  641 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  644 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  646 */         setIsNull(localDatum == null);
/*      */         
/*  648 */         if (localDatum != null) {
/*  649 */           i = localDatum.intValue();
/*      */         }
/*      */       }
/*      */       else {
/*  653 */         setIsNull(4);
/*      */         
/*  655 */         i = this.resultSet.getInt(paramInt + 1);
/*      */       }
/*      */       
/*  658 */       return i;
/*      */     }
/*      */   }
/*      */   
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  665 */     synchronized (this.connection)
/*      */     {
/*  667 */       ensureOpen();
/*  668 */       long l = 0L;
/*      */       
/*  670 */       setIsNull(3);
/*      */       
/*  672 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  675 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  677 */         setIsNull(localDatum == null);
/*      */         
/*  679 */         if (localDatum != null) {
/*  680 */           l = localDatum.longValue();
/*      */         }
/*      */       }
/*      */       else {
/*  684 */         setIsNull(4);
/*      */         
/*  686 */         l = this.resultSet.getLong(paramInt + 1);
/*      */       }
/*      */       
/*  689 */       return l;
/*      */     }
/*      */   }
/*      */   
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  696 */     synchronized (this.connection)
/*      */     {
/*  698 */       ensureOpen();
/*  699 */       float f = 0.0F;
/*      */       
/*  701 */       setIsNull(3);
/*      */       
/*  703 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  706 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  708 */         setIsNull(localDatum == null);
/*      */         
/*  710 */         if (localDatum != null) {
/*  711 */           f = localDatum.floatValue();
/*      */         }
/*      */       }
/*      */       else {
/*  715 */         setIsNull(4);
/*      */         
/*  717 */         f = this.resultSet.getFloat(paramInt + 1);
/*      */       }
/*      */       
/*  720 */       return f;
/*      */     }
/*      */   }
/*      */   
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  727 */     synchronized (this.connection)
/*      */     {
/*  729 */       ensureOpen();
/*  730 */       double d = 0.0D;
/*      */       
/*  732 */       setIsNull(3);
/*      */       
/*  734 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  737 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  739 */         setIsNull(localDatum == null);
/*      */         
/*  741 */         if (localDatum != null) {
/*  742 */           d = localDatum.doubleValue();
/*      */         }
/*      */       }
/*      */       else {
/*  746 */         setIsNull(4);
/*      */         
/*  748 */         d = this.resultSet.getDouble(paramInt + 1);
/*      */       }
/*      */       
/*  751 */       return d;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  759 */     synchronized (this.connection)
/*      */     {
/*  761 */       ensureOpen();
/*  762 */       BigDecimal localBigDecimal = null;
/*      */       
/*  764 */       setIsNull(3);
/*      */       
/*  766 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt1))))
/*      */       {
/*      */ 
/*  769 */         Datum localDatum = getRowBufferDatumAt(paramInt1);
/*      */         
/*  771 */         setIsNull(localDatum == null);
/*      */         
/*  773 */         if (localDatum != null) {
/*  774 */           localBigDecimal = localDatum.bigDecimalValue();
/*      */         }
/*      */       }
/*      */       else {
/*  778 */         setIsNull(4);
/*      */         
/*  780 */         localBigDecimal = this.resultSet.getBigDecimal(paramInt1 + 1);
/*      */       }
/*      */       
/*  783 */       return localBigDecimal;
/*      */     }
/*      */   }
/*      */   
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  790 */     synchronized (this.connection)
/*      */     {
/*  792 */       ensureOpen();
/*  793 */       byte[] arrayOfByte = null;
/*      */       
/*  795 */       setIsNull(3);
/*      */       
/*  797 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  800 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  802 */         setIsNull(localDatum == null);
/*      */         
/*  804 */         if (localDatum != null) {
/*  805 */           arrayOfByte = localDatum.getBytes();
/*      */         }
/*      */       }
/*      */       else {
/*  809 */         setIsNull(4);
/*      */         
/*  811 */         arrayOfByte = this.resultSet.getBytes(paramInt + 1);
/*      */       }
/*      */       
/*  814 */       return arrayOfByte;
/*      */     }
/*      */   }
/*      */   
/*      */   public Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  821 */     synchronized (this.connection)
/*      */     {
/*  823 */       ensureOpen();
/*  824 */       Date localDate = null;
/*      */       
/*  826 */       setIsNull(3);
/*      */       
/*  828 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  831 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  833 */         setIsNull(localDatum == null);
/*      */         
/*  835 */         if (localDatum != null) {
/*  836 */           localDate = localDatum.dateValue();
/*      */         }
/*      */       }
/*      */       else {
/*  840 */         setIsNull(4);
/*      */         
/*  842 */         localDate = this.resultSet.getDate(paramInt + 1);
/*      */       }
/*      */       
/*  845 */       return localDate;
/*      */     }
/*      */   }
/*      */   
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  852 */     synchronized (this.connection)
/*      */     {
/*  854 */       ensureOpen();
/*  855 */       Time localTime = null;
/*      */       
/*  857 */       setIsNull(3);
/*      */       
/*  859 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  862 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  864 */         setIsNull(localDatum == null);
/*      */         
/*  866 */         if (localDatum != null) {
/*  867 */           localTime = localDatum.timeValue();
/*      */         }
/*      */       }
/*      */       else {
/*  871 */         setIsNull(4);
/*      */         
/*  873 */         localTime = this.resultSet.getTime(paramInt + 1);
/*      */       }
/*      */       
/*  876 */       return localTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  884 */     synchronized (this.connection)
/*      */     {
/*  886 */       ensureOpen();
/*  887 */       Timestamp localTimestamp = null;
/*      */       
/*  889 */       setIsNull(3);
/*      */       
/*  891 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  894 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  896 */         setIsNull(localDatum == null);
/*      */         
/*  898 */         if (localDatum != null) {
/*  899 */           localTimestamp = localDatum.timestampValue();
/*      */         }
/*      */       }
/*      */       else {
/*  903 */         setIsNull(4);
/*      */         
/*  905 */         localTimestamp = this.resultSet.getTimestamp(paramInt + 1);
/*      */       }
/*      */       
/*  908 */       return localTimestamp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  916 */     synchronized (this.connection)
/*      */     {
/*  918 */       ensureOpen();
/*  919 */       InputStream localInputStream = null;
/*      */       
/*  921 */       setIsNull(3);
/*      */       
/*  923 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  926 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/*  928 */         setIsNull(localObject1 == null);
/*      */         
/*  930 */         if (localObject1 != null)
/*      */         {
/*  932 */           if ((localObject1 instanceof InputStream))
/*      */           {
/*  934 */             localInputStream = (InputStream)localObject1;
/*      */           }
/*      */           else
/*      */           {
/*  938 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */             
/*  940 */             localInputStream = localDatum.asciiStreamValue();
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  946 */         setIsNull(4);
/*      */         
/*  948 */         localInputStream = this.resultSet.getAsciiStream(paramInt + 1);
/*      */       }
/*      */       
/*  951 */       return localInputStream;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  959 */     synchronized (this.connection)
/*      */     {
/*  961 */       ensureOpen();
/*  962 */       InputStream localInputStream = null;
/*      */       
/*  964 */       setIsNull(3);
/*      */       
/*  966 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  969 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/*  971 */         setIsNull(localObject1 == null);
/*      */         
/*  973 */         if (localObject1 != null)
/*      */         {
/*  975 */           if ((localObject1 instanceof InputStream))
/*      */           {
/*  977 */             localInputStream = (InputStream)localObject1;
/*      */           }
/*      */           else
/*      */           {
/*  981 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*  982 */             DBConversion localDBConversion = this.connection.conversion;
/*  983 */             byte[] arrayOfByte = localDatum.shareBytes();
/*      */             
/*  985 */             if ((localDatum instanceof RAW))
/*      */             {
/*  987 */               localInputStream = localDBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */ 
/*      */             }
/*  990 */             else if ((localDatum instanceof CHAR))
/*      */             {
/*  992 */               localInputStream = localDBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  997 */               SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/*  998 */               localSQLException.fillInStackTrace();
/*  999 */               throw localSQLException;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1006 */         setIsNull(4);
/*      */         
/* 1008 */         localInputStream = this.resultSet.getUnicodeStream(paramInt + 1);
/*      */       }
/*      */       
/* 1011 */       return localInputStream;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1019 */     synchronized (this.connection)
/*      */     {
/* 1021 */       ensureOpen();
/* 1022 */       InputStream localInputStream = null;
/*      */       
/* 1024 */       setIsNull(3);
/*      */       
/* 1026 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1029 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/* 1031 */         setIsNull(localObject1 == null);
/*      */         
/* 1033 */         if (localObject1 != null)
/*      */         {
/* 1035 */           if ((localObject1 instanceof InputStream))
/*      */           {
/* 1037 */             localInputStream = (InputStream)localObject1;
/*      */           }
/*      */           else
/*      */           {
/* 1041 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */             
/* 1043 */             localInputStream = localDatum.binaryStreamValue();
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1049 */         setIsNull(4);
/*      */         
/* 1051 */         localInputStream = this.resultSet.getBinaryStream(paramInt + 1);
/*      */       }
/*      */       
/* 1054 */       return localInputStream;
/*      */     }
/*      */   }
/*      */   
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1061 */     synchronized (this.connection)
/*      */     {
/* 1063 */       ensureOpen();
/* 1064 */       Object localObject1 = null;
/*      */       
/* 1066 */       setIsNull(3);
/*      */       
/* 1068 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1071 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1073 */         setIsNull(localDatum == null);
/*      */         
/* 1075 */         if (localDatum != null) {
/* 1076 */           localObject1 = localDatum.toJdbc();
/*      */         }
/*      */       }
/*      */       else {
/* 1080 */         setIsNull(4);
/*      */         
/* 1082 */         localObject1 = this.resultSet.getObject(paramInt + 1);
/*      */       }
/*      */       
/* 1085 */       return localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Object getObject(int paramInt, oracle.jdbc.OracleDataFactory paramOracleDataFactory)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 13	oracle/jdbc/driver/UpdatableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_3
/*      */     //   6: monitorenter
/*      */     //   7: aload_2
/*      */     //   8: aload_0
/*      */     //   9: iload_1
/*      */     //   10: invokevirtual 118	oracle/jdbc/driver/UpdatableResultSet:getObject	(I)Ljava/lang/Object;
/*      */     //   13: iconst_0
/*      */     //   14: invokeinterface 119 3 0
/*      */     //   19: aload_3
/*      */     //   20: monitorexit
/*      */     //   21: areturn
/*      */     //   22: astore 4
/*      */     //   24: aload_3
/*      */     //   25: monitorexit
/*      */     //   26: aload 4
/*      */     //   28: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1093	-> byte code offset #0
/*      */     //   Java source line #1096	-> byte code offset #7
/*      */     //   Java source line #1098	-> byte code offset #22
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	29	0	this	UpdatableResultSet
/*      */     //   0	29	1	paramInt	int
/*      */     //   0	29	2	paramOracleDataFactory	oracle.jdbc.OracleDataFactory
/*      */     //   5	20	3	Ljava/lang/Object;	Object
/*      */     //   22	5	4	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	21	22	finally
/*      */     //   22	26	22	finally
/*      */   }
/*      */   
/*      */   public Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1106 */     synchronized (this.connection)
/*      */     {
/* 1108 */       ensureOpen();
/* 1109 */       Reader localReader = null;
/*      */       
/* 1111 */       setIsNull(3);
/*      */       
/* 1113 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1116 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/* 1118 */         setIsNull(localObject1 == null);
/*      */         
/* 1120 */         if (localObject1 != null)
/*      */         {
/* 1122 */           if ((localObject1 instanceof Reader))
/*      */           {
/* 1124 */             localReader = (Reader)localObject1;
/*      */           }
/*      */           else
/*      */           {
/* 1128 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */             
/* 1130 */             localReader = localDatum.characterStreamValue();
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1136 */         setIsNull(4);
/*      */         
/* 1138 */         localReader = this.resultSet.getCharacterStream(paramInt + 1);
/*      */       }
/*      */       
/* 1141 */       return localReader;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1150 */     synchronized (this.connection)
/*      */     {
/* 1152 */       ensureOpen();
/* 1153 */       BigDecimal localBigDecimal = null;
/*      */       
/* 1155 */       setIsNull(3);
/*      */       
/* 1157 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1160 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1162 */         setIsNull(localDatum == null);
/*      */         
/* 1164 */         if (localDatum != null) {
/* 1165 */           localBigDecimal = localDatum.bigDecimalValue();
/*      */         }
/*      */       }
/*      */       else {
/* 1169 */         setIsNull(4);
/*      */         
/* 1171 */         localBigDecimal = this.resultSet.getBigDecimal(paramInt + 1);
/*      */       }
/*      */       
/* 1174 */       return localBigDecimal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1183 */     synchronized (this.connection)
/*      */     {
/* 1185 */       ensureOpen();
/* 1186 */       Object localObject1 = null;
/*      */       
/* 1188 */       setIsNull(3);
/*      */       
/* 1190 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1193 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1195 */         setIsNull(localDatum == null);
/*      */         
/* 1197 */         if (localDatum != null)
/*      */         {
/* 1199 */           if ((localDatum instanceof STRUCT)) {
/* 1200 */             localObject1 = ((STRUCT)localDatum).toJdbc(paramMap);
/*      */           } else {
/* 1202 */             localObject1 = localDatum.toJdbc();
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1207 */         setIsNull(4);
/*      */         
/* 1209 */         localObject1 = this.resultSet.getObject(paramInt + 1, paramMap);
/*      */       }
/*      */       
/* 1212 */       return localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1220 */     synchronized (this.connection)
/*      */     {
/* 1222 */       ensureOpen();
/* 1223 */       return getREF(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1231 */     synchronized (this.connection)
/*      */     {
/* 1233 */       ensureOpen();
/* 1234 */       return getBLOB(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1242 */     synchronized (this.connection)
/*      */     {
/* 1244 */       ensureOpen();
/* 1245 */       return getCLOB(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1254 */     synchronized (this.connection)
/*      */     {
/* 1256 */       ensureOpen();
/* 1257 */       return getARRAY(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1266 */     synchronized (this.connection)
/*      */     {
/* 1268 */       ensureOpen();
/* 1269 */       Date localDate = null;
/*      */       
/* 1271 */       setIsNull(3);
/*      */       
/* 1273 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1276 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1278 */         setIsNull(localDatum == null);
/*      */         
/* 1280 */         if (localDatum != null)
/*      */         {
/* 1282 */           if ((localDatum instanceof DATE)) {
/* 1283 */             localDate = ((DATE)localDatum).dateValue(paramCalendar); } else { Object localObject1;
/* 1284 */             if ((localDatum instanceof TIMESTAMP))
/*      */             {
/* 1286 */               localObject1 = ((TIMESTAMP)localDatum).timestampValue(paramCalendar);
/* 1287 */               long l = ((Timestamp)localObject1).getTime();
/* 1288 */               localDate = new Date(l);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/* 1294 */               localObject1 = new DATE(localDatum.stringValue(this.connection));
/*      */               
/* 1296 */               if (localObject1 != null) {
/* 1297 */                 localDate = ((DATE)localObject1).dateValue(paramCalendar);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 1303 */         setIsNull(4);
/*      */         
/* 1305 */         localDate = this.resultSet.getDate(paramInt + 1, paramCalendar);
/*      */       }
/*      */       
/* 1308 */       return localDate;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1317 */     synchronized (this.connection)
/*      */     {
/* 1319 */       ensureOpen();
/* 1320 */       Time localTime = null;
/*      */       
/* 1322 */       setIsNull(3);
/*      */       
/* 1324 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1327 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1329 */         setIsNull(localDatum == null);
/*      */         
/* 1331 */         if (localDatum != null)
/*      */         {
/* 1333 */           if ((localDatum instanceof DATE)) {
/* 1334 */             localTime = ((DATE)localDatum).timeValue(paramCalendar); } else { Object localObject1;
/* 1335 */             if ((localDatum instanceof TIMESTAMP))
/*      */             {
/* 1337 */               localObject1 = ((TIMESTAMP)localDatum).timestampValue(paramCalendar);
/* 1338 */               long l = ((Timestamp)localObject1).getTime();
/* 1339 */               localTime = new Time(l);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1344 */               localObject1 = new DATE(localDatum.stringValue(this.connection));
/*      */               
/* 1346 */               if (localObject1 != null) {
/* 1347 */                 localTime = ((DATE)localObject1).timeValue(paramCalendar);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 1353 */         setIsNull(4);
/*      */         
/* 1355 */         localTime = this.resultSet.getTime(paramInt + 1, paramCalendar);
/*      */       }
/*      */       
/* 1358 */       return localTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1367 */     synchronized (this.connection)
/*      */     {
/* 1369 */       ensureOpen();
/* 1370 */       Timestamp localTimestamp = null;
/*      */       
/* 1372 */       setIsNull(3);
/*      */       
/* 1374 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1377 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1379 */         setIsNull(localDatum == null);
/*      */         
/* 1381 */         if (localDatum != null)
/*      */         {
/* 1383 */           if ((localDatum instanceof DATE)) {
/* 1384 */             localTimestamp = ((DATE)localDatum).timestampValue(paramCalendar);
/* 1385 */           } else if ((localDatum instanceof TIMESTAMP)) {
/* 1386 */             localTimestamp = ((TIMESTAMP)localDatum).timestampValue(paramCalendar);
/*      */           }
/*      */           else {
/* 1389 */             DATE localDATE = new DATE(localDatum.stringValue(this.connection));
/*      */             
/* 1391 */             if (localDATE != null) {
/* 1392 */               localTimestamp = localDATE.timestampValue(paramCalendar);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1398 */         setIsNull(4);
/*      */         
/* 1400 */         localTimestamp = this.resultSet.getTimestamp(paramInt + 1, paramCalendar);
/*      */       }
/*      */       
/* 1403 */       return localTimestamp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1411 */     synchronized (this.connection)
/*      */     {
/* 1413 */       ensureOpen();
/*      */       
/* 1415 */       URL localURL = null;
/*      */       
/* 1417 */       int i = getInternalMetadata().getColumnType(paramInt + 1);
/* 1418 */       int j = SQLUtil.getInternalType(i);
/*      */       
/*      */ 
/* 1421 */       if ((j == 96) || (j == 1) || (j == 8))
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/* 1426 */           String str = getString(paramInt);
/* 1427 */           if (str == null) localURL = null; else {
/* 1428 */             localURL = new URL(str);
/*      */           }
/*      */         }
/*      */         catch (MalformedURLException localMalformedURLException)
/*      */         {
/* 1433 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 1434 */           localSQLException2.fillInStackTrace();
/* 1435 */           throw localSQLException2;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1442 */         SQLException localSQLException1 = DatabaseError.createUnsupportedFeatureSqlException();
/* 1443 */         localSQLException1.fillInStackTrace();
/* 1444 */         throw localSQLException1;
/*      */       }
/*      */       
/*      */ 
/* 1448 */       return localURL;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getCursor(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1456 */     synchronized (this.connection)
/*      */     {
/* 1458 */       ensureOpen();
/* 1459 */       ResultSet localResultSet = null;
/*      */       
/* 1461 */       setIsNull(3);
/*      */       
/* 1463 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1466 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1468 */         setIsNull(localDatum == null);
/*      */         
/* 1470 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/* 1471 */         localSQLException.fillInStackTrace();
/* 1472 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1477 */       setIsNull(4);
/*      */       
/* 1479 */       localResultSet = this.resultSet.getCursor(paramInt + 1);
/*      */       
/*      */ 
/* 1482 */       return localResultSet;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ROWID getROWID(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1490 */     synchronized (this.connection)
/*      */     {
/* 1492 */       ensureOpen();
/* 1493 */       ROWID localROWID = null;
/*      */       
/* 1495 */       setIsNull(3);
/*      */       
/* 1497 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1500 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1502 */         setIsNull(localDatum == null);
/*      */         
/* 1504 */         if ((localDatum != null) && (!(localDatum instanceof ROWID)))
/*      */         {
/* 1506 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/* 1507 */           localSQLException.fillInStackTrace();
/* 1508 */           throw localSQLException;
/*      */         }
/*      */         
/* 1511 */         localROWID = (ROWID)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1515 */         setIsNull(4);
/*      */         
/* 1517 */         localROWID = this.resultSet.getROWID(paramInt + 1);
/*      */       }
/*      */       
/* 1520 */       return localROWID;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1528 */     synchronized (this.connection)
/*      */     {
/* 1530 */       ensureOpen();
/* 1531 */       NUMBER localNUMBER = null;
/*      */       
/* 1533 */       setIsNull(3);
/*      */       
/* 1535 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1538 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1540 */         setIsNull(localDatum == null);
/*      */         
/* 1542 */         if ((localDatum != null) && (!(localDatum instanceof NUMBER)))
/*      */         {
/* 1544 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/* 1545 */           localSQLException.fillInStackTrace();
/* 1546 */           throw localSQLException;
/*      */         }
/*      */         
/* 1549 */         localNUMBER = (NUMBER)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1553 */         setIsNull(4);
/*      */         
/* 1555 */         localNUMBER = this.resultSet.getNUMBER(paramInt + 1);
/*      */       }
/*      */       
/* 1558 */       return localNUMBER;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1566 */     synchronized (this.connection)
/*      */     {
/* 1568 */       ensureOpen();
/* 1569 */       DATE localDATE = null;
/*      */       
/* 1571 */       setIsNull(3);
/*      */       
/* 1573 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1576 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1578 */         if (localDatum != null)
/*      */         {
/* 1580 */           if ((localDatum instanceof DATE)) { localDATE = (DATE)localDatum; } else { Object localObject1;
/* 1581 */             if ((localDatum instanceof TIMESTAMP))
/*      */             {
/* 1583 */               localObject1 = ((TIMESTAMP)localDatum).timestampValue();
/* 1584 */               localDATE = new DATE((Timestamp)localObject1);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1589 */               localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/* 1590 */               ((SQLException)localObject1).fillInStackTrace();
/* 1591 */               throw ((Throwable)localObject1);
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */         else {
/* 1597 */           setIsNull(localDatum == null);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1603 */         setIsNull(4);
/*      */         
/* 1605 */         localDATE = this.resultSet.getDATE(paramInt + 1);
/*      */       }
/*      */       
/* 1608 */       return localDATE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1616 */     synchronized (this.connection)
/*      */     {
/* 1618 */       ensureOpen();
/* 1619 */       TIMESTAMP localTIMESTAMP = null;
/*      */       
/* 1621 */       setIsNull(3);
/*      */       
/* 1623 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1626 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1628 */         setIsNull(localDatum == null);
/*      */         
/* 1630 */         if ((localDatum != null) && (!(localDatum instanceof TIMESTAMP)))
/*      */         {
/* 1632 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/* 1633 */           localSQLException.fillInStackTrace();
/* 1634 */           throw localSQLException;
/*      */         }
/*      */         
/* 1637 */         localTIMESTAMP = (TIMESTAMP)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1641 */         setIsNull(4);
/*      */         
/* 1643 */         localTIMESTAMP = this.resultSet.getTIMESTAMP(paramInt + 1);
/*      */       }
/*      */       
/* 1646 */       return localTIMESTAMP;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1654 */     synchronized (this.connection)
/*      */     {
/* 1656 */       ensureOpen();
/* 1657 */       TIMESTAMPTZ localTIMESTAMPTZ = null;
/*      */       
/* 1659 */       setIsNull(3);
/*      */       
/* 1661 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1664 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1666 */         setIsNull(localDatum == null);
/*      */         
/* 1668 */         if ((localDatum != null) && (!(localDatum instanceof TIMESTAMPTZ)))
/*      */         {
/* 1670 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/* 1671 */           localSQLException.fillInStackTrace();
/* 1672 */           throw localSQLException;
/*      */         }
/*      */         
/* 1675 */         localTIMESTAMPTZ = (TIMESTAMPTZ)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1679 */         setIsNull(4);
/*      */         
/* 1681 */         localTIMESTAMPTZ = this.resultSet.getTIMESTAMPTZ(paramInt + 1);
/*      */       }
/*      */       
/* 1684 */       return localTIMESTAMPTZ;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1692 */     synchronized (this.connection)
/*      */     {
/* 1694 */       ensureOpen();
/* 1695 */       TIMESTAMPLTZ localTIMESTAMPLTZ = null;
/*      */       
/* 1697 */       setIsNull(3);
/*      */       
/* 1699 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1702 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1704 */         setIsNull(localDatum == null);
/*      */         
/* 1706 */         if ((localDatum != null) && (!(localDatum instanceof TIMESTAMPLTZ)))
/*      */         {
/* 1708 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/* 1709 */           localSQLException.fillInStackTrace();
/* 1710 */           throw localSQLException;
/*      */         }
/*      */         
/* 1713 */         localTIMESTAMPLTZ = (TIMESTAMPLTZ)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1717 */         setIsNull(4);
/*      */         
/* 1719 */         localTIMESTAMPLTZ = this.resultSet.getTIMESTAMPLTZ(paramInt + 1);
/*      */       }
/*      */       
/* 1722 */       return localTIMESTAMPLTZ;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALDS getINTERVALDS(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1730 */     synchronized (this.connection)
/*      */     {
/* 1732 */       ensureOpen();
/* 1733 */       INTERVALDS localINTERVALDS = null;
/*      */       
/* 1735 */       setIsNull(3);
/*      */       
/* 1737 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1740 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1742 */         setIsNull(localDatum == null);
/*      */         
/* 1744 */         if ((localDatum != null) && (!(localDatum instanceof INTERVALDS)))
/*      */         {
/* 1746 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
/* 1747 */           localSQLException.fillInStackTrace();
/* 1748 */           throw localSQLException;
/*      */         }
/*      */         
/* 1751 */         localINTERVALDS = (INTERVALDS)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1755 */         setIsNull(4);
/*      */         
/* 1757 */         localINTERVALDS = this.resultSet.getINTERVALDS(paramInt + 1);
/*      */       }
/*      */       
/* 1760 */       return localINTERVALDS;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALYM getINTERVALYM(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1768 */     synchronized (this.connection)
/*      */     {
/* 1770 */       ensureOpen();
/* 1771 */       INTERVALYM localINTERVALYM = null;
/*      */       
/* 1773 */       setIsNull(3);
/*      */       
/* 1775 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1778 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1780 */         setIsNull(localDatum == null);
/*      */         
/* 1782 */         if ((localDatum != null) && (!(localDatum instanceof INTERVALYM)))
/*      */         {
/* 1784 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
/* 1785 */           localSQLException.fillInStackTrace();
/* 1786 */           throw localSQLException;
/*      */         }
/*      */         
/* 1789 */         localINTERVALYM = (INTERVALYM)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1793 */         setIsNull(4);
/*      */         
/* 1795 */         localINTERVALYM = this.resultSet.getINTERVALYM(paramInt + 1);
/*      */       }
/*      */       
/* 1798 */       return localINTERVALYM;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ARRAY getARRAY(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1806 */     synchronized (this.connection)
/*      */     {
/* 1808 */       ensureOpen();
/* 1809 */       ARRAY localARRAY = null;
/*      */       
/* 1811 */       setIsNull(3);
/*      */       
/* 1813 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1816 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1818 */         setIsNull(localDatum == null);
/*      */         
/* 1820 */         if ((localDatum != null) && (!(localDatum instanceof ARRAY)))
/*      */         {
/* 1822 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/* 1823 */           localSQLException.fillInStackTrace();
/* 1824 */           throw localSQLException;
/*      */         }
/*      */         
/* 1827 */         localARRAY = (ARRAY)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1831 */         setIsNull(4);
/*      */         
/* 1833 */         localARRAY = this.resultSet.getARRAY(paramInt + 1);
/*      */       }
/*      */       
/* 1836 */       return localARRAY;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public STRUCT getSTRUCT(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1844 */     synchronized (this.connection)
/*      */     {
/* 1846 */       ensureOpen();
/* 1847 */       STRUCT localSTRUCT = null;
/*      */       
/* 1849 */       setIsNull(3);
/*      */       
/* 1851 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1854 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1856 */         setIsNull(localDatum == null);
/*      */         
/* 1858 */         if ((localDatum != null) && (!(localDatum instanceof STRUCT)))
/*      */         {
/* 1860 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/* 1861 */           localSQLException.fillInStackTrace();
/* 1862 */           throw localSQLException;
/*      */         }
/*      */         
/* 1865 */         localSTRUCT = (STRUCT)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1869 */         setIsNull(4);
/*      */         
/* 1871 */         localSTRUCT = this.resultSet.getSTRUCT(paramInt + 1);
/*      */       }
/*      */       
/* 1874 */       return localSTRUCT;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public OPAQUE getOPAQUE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1882 */     synchronized (this.connection)
/*      */     {
/* 1884 */       ensureOpen();
/* 1885 */       OPAQUE localOPAQUE = null;
/*      */       
/* 1887 */       setIsNull(3);
/*      */       
/* 1889 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1892 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1894 */         setIsNull(localDatum == null);
/*      */         
/* 1896 */         if ((localDatum != null) && (!(localDatum instanceof OPAQUE)))
/*      */         {
/* 1898 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/* 1899 */           localSQLException.fillInStackTrace();
/* 1900 */           throw localSQLException;
/*      */         }
/*      */         
/* 1903 */         localOPAQUE = (OPAQUE)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1907 */         setIsNull(4);
/*      */         
/* 1909 */         localOPAQUE = this.resultSet.getOPAQUE(paramInt + 1);
/*      */       }
/*      */       
/* 1912 */       return localOPAQUE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public REF getREF(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1920 */     synchronized (this.connection)
/*      */     {
/* 1922 */       ensureOpen();
/* 1923 */       REF localREF = null;
/*      */       
/* 1925 */       setIsNull(3);
/*      */       
/* 1927 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1930 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1932 */         setIsNull(localDatum == null);
/*      */         
/* 1934 */         if ((localDatum != null) && (!(localDatum instanceof REF)))
/*      */         {
/* 1936 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/* 1937 */           localSQLException.fillInStackTrace();
/* 1938 */           throw localSQLException;
/*      */         }
/*      */         
/* 1941 */         localREF = (REF)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1945 */         setIsNull(4);
/*      */         
/* 1947 */         localREF = this.resultSet.getREF(paramInt + 1);
/*      */       }
/*      */       
/* 1950 */       return localREF;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CHAR getCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1958 */     synchronized (this.connection)
/*      */     {
/* 1960 */       ensureOpen();
/* 1961 */       CHAR localCHAR = null;
/*      */       
/* 1963 */       setIsNull(3);
/*      */       
/* 1965 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1968 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1970 */         setIsNull(localDatum == null);
/*      */         
/* 1972 */         if ((localDatum != null) && (!(localDatum instanceof CHAR)))
/*      */         {
/* 1974 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/* 1975 */           localSQLException.fillInStackTrace();
/* 1976 */           throw localSQLException;
/*      */         }
/*      */         
/* 1979 */         localCHAR = (CHAR)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1983 */         setIsNull(4);
/*      */         
/* 1985 */         localCHAR = this.resultSet.getCHAR(paramInt + 1);
/*      */       }
/*      */       
/* 1988 */       return localCHAR;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1996 */     synchronized (this.connection)
/*      */     {
/* 1998 */       ensureOpen();
/* 1999 */       RAW localRAW = null;
/*      */       
/* 2001 */       setIsNull(3);
/*      */       
/* 2003 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2006 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2008 */         setIsNull(localDatum == null);
/*      */         
/* 2010 */         if ((localDatum != null) && (!(localDatum instanceof RAW)))
/*      */         {
/* 2012 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/* 2013 */           localSQLException.fillInStackTrace();
/* 2014 */           throw localSQLException;
/*      */         }
/*      */         
/* 2017 */         localRAW = (RAW)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2021 */         setIsNull(4);
/*      */         
/* 2023 */         localRAW = this.resultSet.getRAW(paramInt + 1);
/*      */       }
/*      */       
/* 2026 */       return localRAW;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BLOB getBLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2034 */     synchronized (this.connection)
/*      */     {
/* 2036 */       ensureOpen();
/* 2037 */       BLOB localBLOB = null;
/*      */       
/* 2039 */       setIsNull(3);
/*      */       
/* 2041 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2044 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2046 */         setIsNull(localDatum == null);
/*      */         
/* 2048 */         if ((localDatum != null) && (!(localDatum instanceof BLOB)))
/*      */         {
/* 2050 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/* 2051 */           localSQLException.fillInStackTrace();
/* 2052 */           throw localSQLException;
/*      */         }
/*      */         
/* 2055 */         localBLOB = (BLOB)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2059 */         setIsNull(4);
/*      */         
/* 2061 */         localBLOB = this.resultSet.getBLOB(paramInt + 1);
/*      */       }
/*      */       
/* 2064 */       return localBLOB;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CLOB getCLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2075 */     synchronized (this.connection)
/*      */     {
/* 2077 */       ensureOpen();
/* 2078 */       CLOB localCLOB = null;
/*      */       
/* 2080 */       setIsNull(3);
/*      */       
/* 2082 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2085 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2087 */         setIsNull(localDatum == null);
/*      */         
/* 2089 */         if ((localDatum != null) && (!(localDatum instanceof CLOB)))
/*      */         {
/* 2091 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 2092 */           localSQLException.fillInStackTrace();
/* 2093 */           throw localSQLException;
/*      */         }
/*      */         
/* 2096 */         localCLOB = (CLOB)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2100 */         setIsNull(4);
/*      */         
/* 2102 */         localCLOB = this.resultSet.getCLOB(paramInt + 1);
/*      */       }
/*      */       
/* 2105 */       return localCLOB;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BFILE getBFILE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2113 */     synchronized (this.connection)
/*      */     {
/* 2115 */       ensureOpen();
/* 2116 */       BFILE localBFILE = null;
/*      */       
/* 2118 */       setIsNull(3);
/*      */       
/* 2120 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2123 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2125 */         setIsNull(localDatum == null);
/*      */         
/* 2127 */         if ((localDatum != null) && (!(localDatum instanceof BFILE)))
/*      */         {
/* 2129 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/* 2130 */           localSQLException.fillInStackTrace();
/* 2131 */           throw localSQLException;
/*      */         }
/*      */         
/* 2134 */         localBFILE = (BFILE)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2138 */         setIsNull(4);
/*      */         
/* 2140 */         localBFILE = this.resultSet.getBFILE(paramInt + 1);
/*      */       }
/*      */       
/* 2143 */       return localBFILE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BFILE getBfile(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2151 */     synchronized (this.connection)
/*      */     {
/* 2153 */       ensureOpen();
/* 2154 */       return getBFILE(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/* 2163 */     synchronized (this.connection)
/*      */     {
/* 2165 */       ensureOpen();
/* 2166 */       if (paramCustomDatumFactory == null)
/*      */       {
/* 2168 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2169 */         ((SQLException)localObject1).fillInStackTrace();
/* 2170 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 2173 */       Object localObject1 = null;
/*      */       
/* 2175 */       setIsNull(3);
/*      */       
/* 2177 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2180 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2182 */         setIsNull(localDatum == null);
/*      */         
/* 2184 */         localObject1 = paramCustomDatumFactory.create(localDatum, 0);
/*      */       }
/*      */       else
/*      */       {
/* 2188 */         setIsNull(4);
/*      */         
/* 2190 */         localObject1 = this.resultSet.getCustomDatum(paramInt + 1, paramCustomDatumFactory);
/*      */       }
/*      */       
/* 2193 */       return (CustomDatum)localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/* 2202 */     synchronized (this.connection)
/*      */     {
/* 2204 */       ensureOpen();
/* 2205 */       if (paramORADataFactory == null)
/*      */       {
/* 2207 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2208 */         ((SQLException)localObject1).fillInStackTrace();
/* 2209 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 2212 */       Object localObject1 = null;
/*      */       
/* 2214 */       setIsNull(3);
/*      */       
/* 2216 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2219 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2221 */         setIsNull(localDatum == null);
/*      */         
/* 2223 */         localObject1 = paramORADataFactory.create(localDatum, 0);
/*      */       }
/*      */       else
/*      */       {
/* 2227 */         setIsNull(4);
/*      */         
/* 2229 */         localObject1 = this.resultSet.getORAData(paramInt + 1, paramORADataFactory);
/*      */       }
/*      */       
/* 2232 */       return (ORAData)localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateBlob(int paramInt, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2247 */     BLOB localBLOB = BLOB.createTemporary(this.connection, true, 10);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2253 */     addToTempLobsToFree(localBLOB);
/* 2254 */     int i = ((BLOB)localBLOB).getBufferSize();
/* 2255 */     OutputStream localOutputStream = localBLOB.setBinaryStream(1L);
/* 2256 */     byte[] arrayOfByte = new byte[i];
/* 2257 */     long l = paramLong;
/*      */     try
/*      */     {
/* 2260 */       while (l > 0L)
/*      */       {
/* 2262 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2263 */         if (j == -1) break;
/* 2264 */         localOutputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2266 */         l -= j;
/*      */       }
/* 2268 */       localOutputStream.close();
/* 2269 */       updateBlob(paramInt, localBLOB);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2273 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2274 */       localSQLException.fillInStackTrace();
/* 2275 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateClob(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2287 */     updateClob(paramInt, paramReader, paramLong, (short)1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void updateClob(int paramInt, Reader paramReader, long paramLong, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2295 */     CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, paramShort);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2301 */     addToTempLobsToFree(localCLOB);
/* 2302 */     int i = ((CLOB)localCLOB).getBufferSize();
/* 2303 */     Writer localWriter = localCLOB.setCharacterStream(1L);
/* 2304 */     char[] arrayOfChar = new char[i];
/* 2305 */     long l = paramLong;
/*      */     try
/*      */     {
/* 2308 */       while (l > 0L)
/*      */       {
/* 2310 */         int j = paramReader.read(arrayOfChar, 0, Math.min(i, (int)l));
/* 2311 */         if (j == -1) break;
/* 2312 */         localWriter.write(arrayOfChar, 0, j);
/*      */         
/* 2314 */         l -= j;
/*      */       }
/* 2316 */       localWriter.close();
/* 2317 */       updateClob(paramInt, localCLOB);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2321 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2322 */       localSQLException.fillInStackTrace();
/* 2323 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2337 */     updateClob(paramInt1, paramInputStream, paramInt2, (short)1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2347 */     CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, paramShort);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2353 */     addToTempLobsToFree(localCLOB);
/* 2354 */     int i = ((CLOB)localCLOB).getBufferSize();
/* 2355 */     OutputStream localOutputStream = localCLOB.setAsciiStream(1L);
/* 2356 */     byte[] arrayOfByte = new byte[i];
/* 2357 */     long l = paramInt2;
/*      */     try
/*      */     {
/* 2360 */       while (l > 0L)
/*      */       {
/* 2362 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2363 */         if (j == -1) break;
/* 2364 */         localOutputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2366 */         l -= j;
/*      */       }
/* 2368 */       localOutputStream.close();
/* 2369 */       updateClob(paramInt1, localCLOB);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2373 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2374 */       localSQLException.fillInStackTrace();
/* 2375 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2384 */   ArrayList tempClobsToFree = null;
/* 2385 */   ArrayList tempBlobsToFree = null;
/*      */   
/*      */ 
/*      */   void addToTempLobsToFree(Clob paramClob)
/*      */   {
/* 2390 */     if (this.tempClobsToFree == null)
/* 2391 */       this.tempClobsToFree = new ArrayList();
/* 2392 */     this.tempClobsToFree.add(paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToTempLobsToFree(Blob paramBlob)
/*      */   {
/* 2399 */     if (this.tempBlobsToFree == null)
/* 2400 */       this.tempBlobsToFree = new ArrayList();
/* 2401 */     this.tempBlobsToFree.add(paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanTempLobs()
/*      */   {
/* 2408 */     cleanTempClobs(this.tempClobsToFree);
/* 2409 */     cleanTempBlobs(this.tempBlobsToFree);
/* 2410 */     this.tempClobsToFree = null;
/* 2411 */     this.tempBlobsToFree = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanTempBlobs(ArrayList paramArrayList)
/*      */   {
/* 2418 */     if (paramArrayList != null)
/*      */     {
/* 2420 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 2422 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 2426 */           ((BLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void cleanTempClobs(ArrayList paramArrayList)
/*      */   {
/* 2440 */     if (paramArrayList != null)
/*      */     {
/* 2442 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 2444 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 2448 */           ((CLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 15	oracle/jdbc/driver/UpdatableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   4: checkcast 11	oracle/jdbc/driver/OracleStatement
/*      */     //   7: getfield 31	oracle/jdbc/driver/OracleStatement:closed	Z
/*      */     //   10: ifeq +22 -> 32
/*      */     //   13: aload_0
/*      */     //   14: invokevirtual 8	oracle/jdbc/driver/UpdatableResultSet:getConnectionDuringExceptionHandling	()Loracle/jdbc/internal/OracleConnection;
/*      */     //   17: bipush 9
/*      */     //   19: ldc -16
/*      */     //   21: invokestatic 80	oracle/jdbc/driver/DatabaseError:createSqlException	(Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*      */     //   24: astore_1
/*      */     //   25: aload_1
/*      */     //   26: invokevirtual 10	java/sql/SQLException:fillInStackTrace	()Ljava/lang/Throwable;
/*      */     //   29: pop
/*      */     //   30: aload_1
/*      */     //   31: athrow
/*      */     //   32: aload_0
/*      */     //   33: getfield 13	oracle/jdbc/driver/UpdatableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   36: dup
/*      */     //   37: astore_1
/*      */     //   38: monitorenter
/*      */     //   39: new 241	oracle/jdbc/driver/OracleResultSetMetaData
/*      */     //   42: dup
/*      */     //   43: aload_0
/*      */     //   44: getfield 13	oracle/jdbc/driver/UpdatableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   47: aload_0
/*      */     //   48: getfield 15	oracle/jdbc/driver/UpdatableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   51: checkcast 11	oracle/jdbc/driver/OracleStatement
/*      */     //   54: iconst_1
/*      */     //   55: invokespecial 242	oracle/jdbc/driver/OracleResultSetMetaData:<init>	(Loracle/jdbc/driver/PhysicalConnection;Loracle/jdbc/driver/OracleStatement;I)V
/*      */     //   58: aload_1
/*      */     //   59: monitorexit
/*      */     //   60: areturn
/*      */     //   61: astore_2
/*      */     //   62: aload_1
/*      */     //   63: monitorexit
/*      */     //   64: aload_2
/*      */     //   65: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2466	-> byte code offset #0
/*      */     //   Java source line #2468	-> byte code offset #13
/*      */     //   Java source line #2469	-> byte code offset #25
/*      */     //   Java source line #2470	-> byte code offset #30
/*      */     //   Java source line #2473	-> byte code offset #32
/*      */     //   Java source line #2474	-> byte code offset #39
/*      */     //   Java source line #2477	-> byte code offset #61
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	66	0	this	UpdatableResultSet
/*      */     //   24	7	1	localSQLException	SQLException
/*      */     //   37	26	1	Ljava/lang/Object;	Object
/*      */     //   61	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   39	60	61	finally
/*      */     //   61	64	61	finally
/*      */   }
/*      */   
/*      */   public int findColumn(String paramString)
/*      */     throws SQLException
/*      */   {
/* 2483 */     synchronized (this.connection)
/*      */     {
/* 2485 */       ensureOpen();
/* 2486 */       return this.resultSet.findColumn(paramString) - 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2497 */     synchronized (this.connection)
/*      */     {
/* 2499 */       ensureOpen();
/* 2500 */       this.resultSet.setFetchDirection(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 2507 */     synchronized (this.connection)
/*      */     {
/* 2509 */       ensureOpen();
/* 2510 */       return this.resultSet.getFetchDirection();
/*      */     }
/*      */   }
/*      */   
/*      */   public void setFetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2517 */     synchronized (this.connection)
/*      */     {
/* 2519 */       ensureOpen();
/* 2520 */       this.resultSet.setFetchSize(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 2527 */     synchronized (this.connection)
/*      */     {
/* 2529 */       ensureOpen();
/* 2530 */       return this.resultSet.getFetchSize();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getType()
/*      */     throws SQLException
/*      */   {
/* 2538 */     return this.rsetType;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/* 2545 */     return 1008;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 2556 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 2563 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 2570 */     return false;
/*      */   }
/*      */   
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/* 2576 */     synchronized (this.connection)
/*      */     {
/* 2578 */       ensureOpen();
/* 2579 */       if (!isOnInsertRow())
/*      */       {
/* 2581 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 83);
/* 2582 */         localSQLException.fillInStackTrace();
/* 2583 */         throw localSQLException;
/*      */       }
/*      */       
/* 2586 */       prepareInsertRowStatement();
/* 2587 */       prepareInsertRowBinds();
/* 2588 */       executeInsertRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/* 2595 */     synchronized (this.connection)
/*      */     {
/* 2597 */       ensureOpen();
/*      */       
/*      */ 
/* 2600 */       if (isOnInsertRow())
/*      */       {
/* 2602 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2603 */         localSQLException.fillInStackTrace();
/* 2604 */         throw localSQLException;
/*      */       }
/*      */       
/* 2607 */       int i = getNumColumnsChanged();
/*      */       
/* 2609 */       if (i > 0)
/*      */       {
/* 2611 */         prepareUpdateRowStatement(i);
/* 2612 */         prepareUpdateRowBinds(i);
/* 2613 */         executeUpdateRow();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/* 2621 */     synchronized (this.connection)
/*      */     {
/* 2623 */       ensureOpen();
/*      */       
/*      */ 
/* 2626 */       if (isOnInsertRow())
/*      */       {
/* 2628 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2629 */         localSQLException.fillInStackTrace();
/* 2630 */         throw localSQLException;
/*      */       }
/*      */       
/* 2633 */       prepareDeleteRowStatement();
/* 2634 */       prepareDeleteRowBinds();
/* 2635 */       executeDeleteRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 2642 */     synchronized (this.connection)
/*      */     {
/* 2644 */       ensureOpen();
/*      */       
/* 2646 */       if (isOnInsertRow())
/*      */       {
/* 2648 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2649 */         localSQLException.fillInStackTrace();
/* 2650 */         throw localSQLException;
/*      */       }
/*      */       
/* 2653 */       this.resultSet.refreshRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/* 2660 */     synchronized (this.connection)
/*      */     {
/* 2662 */       ensureOpen();
/* 2663 */       if (this.isUpdating)
/*      */       {
/* 2665 */         this.isUpdating = false;
/*      */         
/* 2667 */         clearRowBuffer();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 2675 */     synchronized (this.connection)
/*      */     {
/* 2677 */       ensureOpen();
/* 2678 */       if (isOnInsertRow()) {
/* 2679 */         return;
/*      */       }
/* 2681 */       this.isInserting = true;
/*      */       
/*      */ 
/* 2684 */       if (this.rowBuffer == null) {
/* 2685 */         this.rowBuffer = new Object[getColumnCount()];
/*      */       }
/* 2687 */       if (this.m_nullIndicator == null) {
/* 2688 */         this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       }
/* 2690 */       clearRowBuffer();
/*      */     }
/*      */   }
/*      */   
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 2697 */     synchronized (this.connection)
/*      */     {
/* 2699 */       ensureOpen();
/* 2700 */       cancelRowInserts();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2708 */     synchronized (this.connection)
/*      */     {
/* 2710 */       if ((paramString == null) || (paramString.length() == 0)) {
/* 2711 */         updateNull(paramInt);
/*      */       } else {
/* 2713 */         updateObject(paramInt, paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLException
/*      */   {
/* 2720 */     synchronized (this.connection)
/*      */     {
/* 2722 */       setRowBufferAt(paramInt, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2730 */     updateObject(paramInt, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 2737 */     updateObject(paramInt, Integer.valueOf(paramByte));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2744 */     updateObject(paramInt, Integer.valueOf(paramShort));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2751 */     updateObject(paramInt1, Integer.valueOf(paramInt2));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2758 */     updateObject(paramInt, Long.valueOf(paramLong));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 2765 */     updateObject(paramInt, Float.valueOf(paramFloat));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 2772 */     updateObject(paramInt, Double.valueOf(paramDouble));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 2780 */     updateObject(paramInt, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2787 */     updateObject(paramInt, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateDate(int paramInt, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 2794 */     updateObject(paramInt, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 2801 */     updateObject(paramInt, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 2809 */     updateObject(paramInt, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2818 */     ensureOpen();
/* 2819 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 2820 */     int i = localOracleResultSetMetaData.getColumnType(1 + paramInt1);
/*      */     
/* 2822 */     if ((paramInputStream != null) && (paramInt2 > 0))
/*      */     {
/* 2824 */       switch (i)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2005: 
/* 2830 */         if (localOracleResultSetMetaData.isNCHAR(1 + paramInt1))
/*      */         {
/* 2832 */           updateClob(paramInt1, paramInputStream, paramInt2, (short)2);
/*      */         }
/*      */         else
/* 2835 */           updateClob(paramInt1, paramInputStream, paramInt2);
/* 2836 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2004: 
/* 2843 */         updateBlob(paramInt1, paramInputStream, paramInt2);
/* 2844 */         break;
/*      */       
/*      */       case -1: 
/* 2847 */         int[] arrayOfInt = { paramInt2, 1 };
/*      */         
/*      */ 
/*      */ 
/* 2851 */         setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/* 2852 */         break;
/*      */       
/*      */       default: 
/*      */         try
/*      */         {
/* 2857 */           int j = 0;
/* 2858 */           int k = paramInt2;
/* 2859 */           byte[] arrayOfByte = new byte['Ѐ'];
/* 2860 */           char[] arrayOfChar = new char['Ѐ'];
/* 2861 */           StringBuilder localStringBuilder = new StringBuilder(1024);
/*      */           
/* 2863 */           while (k > 0)
/*      */           {
/* 2865 */             if (k >= 1024) {
/* 2866 */               j = paramInputStream.read(arrayOfByte);
/*      */             } else {
/* 2868 */               j = paramInputStream.read(arrayOfByte, 0, k);
/*      */             }
/*      */             
/*      */ 
/* 2872 */             if (j == -1) {
/*      */               break;
/*      */             }
/* 2875 */             DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*      */             
/* 2877 */             localStringBuilder.append(arrayOfChar, 0, j);
/* 2878 */             k -= j;
/*      */           }
/*      */           
/* 2881 */           paramInputStream.close();
/* 2882 */           if (k == paramInt2)
/*      */           {
/* 2884 */             updateNull(paramInt1);
/* 2885 */             return;
/*      */           }
/*      */           
/* 2888 */           updateString(paramInt1, localStringBuilder.toString());
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 2893 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2894 */           localSQLException.fillInStackTrace();
/* 2895 */           throw localSQLException;
/*      */         }
/*      */       
/*      */ 
/*      */       }
/*      */       
/*      */     } else {
/* 2902 */       setRowBufferAt(paramInt1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2911 */     ensureOpen();
/* 2912 */     int i = getInternalMetadata().getColumnType(1 + paramInt1);
/*      */     
/* 2914 */     if ((paramInputStream != null) && (paramInt2 > 0))
/*      */     {
/* 2916 */       switch (i)
/*      */       {
/*      */       case 2004: 
/* 2919 */         updateBlob(paramInt1, paramInputStream, paramInt2);
/* 2920 */         break;
/*      */       
/*      */       case -4: 
/* 2923 */         int[] arrayOfInt = { paramInt2, 2 };
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2928 */         setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/* 2929 */         break;
/*      */       
/*      */       default: 
/*      */         try
/*      */         {
/* 2934 */           int j = 0;
/* 2935 */           int k = paramInt2;
/* 2936 */           byte[] arrayOfByte = new byte['Ѐ'];
/* 2937 */           ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(1024);
/*      */           
/*      */ 
/* 2940 */           while (k > 0)
/*      */           {
/* 2942 */             if (k >= 1024) {
/* 2943 */               j = paramInputStream.read(arrayOfByte);
/*      */             } else {
/* 2945 */               j = paramInputStream.read(arrayOfByte, 0, k);
/*      */             }
/*      */             
/*      */ 
/* 2949 */             if (j == -1) {
/*      */               break;
/*      */             }
/* 2952 */             localByteArrayOutputStream.write(arrayOfByte, 0, j);
/* 2953 */             k -= j;
/*      */           }
/*      */           
/* 2956 */           paramInputStream.close();
/* 2957 */           if (k == paramInt2)
/*      */           {
/* 2959 */             updateNull(paramInt1);
/* 2960 */             return;
/*      */           }
/*      */           
/* 2963 */           updateBytes(paramInt1, localByteArrayOutputStream.toByteArray());
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 2968 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2969 */           localSQLException.fillInStackTrace();
/* 2970 */           throw localSQLException;
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */     } else {
/* 2980 */       setRowBufferAt(paramInt1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2988 */     int i = 0;int j = paramInt2;
/*      */     
/*      */ 
/* 2991 */     ensureOpen();
/* 2992 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 2993 */     int k = localOracleResultSetMetaData.getColumnType(1 + paramInt1);
/*      */     
/* 2995 */     if ((paramReader != null) && (paramInt2 > 0))
/*      */     {
/* 2997 */       switch (k)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2005: 
/* 3003 */         if (localOracleResultSetMetaData.isNCHAR(1 + paramInt1))
/*      */         {
/* 3005 */           updateClob(paramInt1, paramReader, paramInt2, (short)2);
/*      */         }
/*      */         else
/* 3008 */           updateClob(paramInt1, paramReader, paramInt2);
/* 3009 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -1: 
/* 3016 */         int[] arrayOfInt = { paramInt2 };
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3021 */         setRowBufferAt(paramInt1, paramReader, arrayOfInt);
/* 3022 */         break;
/*      */       
/*      */       default: 
/*      */         try
/*      */         {
/* 3027 */           char[] arrayOfChar = new char['Ѐ'];
/* 3028 */           localObject = new StringBuilder(1024);
/*      */           
/* 3030 */           while (j > 0)
/*      */           {
/* 3032 */             if (j >= 1024) {
/* 3033 */               i = paramReader.read(arrayOfChar);
/*      */             } else {
/* 3035 */               i = paramReader.read(arrayOfChar, 0, j);
/*      */             }
/*      */             
/*      */ 
/* 3039 */             if (i == -1) {
/*      */               break;
/*      */             }
/* 3042 */             ((StringBuilder)localObject).append(arrayOfChar, 0, i);
/* 3043 */             j -= i;
/*      */           }
/*      */           
/* 3046 */           paramReader.close();
/* 3047 */           if (j == paramInt2)
/*      */           {
/* 3049 */             updateNull(paramInt1);
/* 3050 */             return;
/*      */           }
/*      */           
/* 3053 */           updateString(paramInt1, ((StringBuilder)localObject).toString());
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3058 */           Object localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3059 */           ((SQLException)localObject).fillInStackTrace();
/* 3060 */           throw ((Throwable)localObject);
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */     } else {
/* 3068 */       setRowBufferAt(paramInt1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3077 */     updateObject(paramInt1, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 3084 */     synchronized (this.connection)
/*      */     {
/* 3086 */       ensureOpen();
/* 3087 */       Datum localDatum = null;
/* 3088 */       if (paramObject != null) {
/*      */         Object localObject1;
/* 3090 */         if ((paramObject instanceof OracleData))
/*      */         {
/* 3092 */           localObject1 = ((OracleData)paramObject).toJDBCObject(this.connection);
/*      */           
/*      */ 
/*      */ 
/* 3096 */           paramObject = localObject1;
/*      */         }
/* 3098 */         if ((paramObject instanceof Datum))
/*      */         {
/* 3100 */           localDatum = (Datum)paramObject;
/*      */         }
/*      */         else
/*      */         {
/* 3104 */           localObject1 = (OracleResultSetMetaData)getInternalMetadata();
/* 3105 */           int i = paramInt + 1;
/* 3106 */           if (((OracleResultSetMetaData)localObject1).getColumnType(i) == 96) {
/* 3107 */             int j = ((OracleResultSetMetaData)localObject1).getColumnDisplaySize(i);
/* 3108 */             String str = (String)paramObject;
/* 3109 */             for (int k = str.length(); k < j; k++) str = str + " ";
/*      */           }
/* 3111 */           localDatum = SQLUtil.makeOracleDatum(this.connection, paramObject, ((OracleResultSetMetaData)localObject1).getColumnType(i), null, ((OracleResultSetMetaData)localObject1).isNCHAR(i));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 3116 */       setRowBufferAt(paramInt, localDatum);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateOracleObject(int paramInt, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 3124 */     synchronized (this.connection)
/*      */     {
/* 3126 */       setRowBufferAt(paramInt, paramDatum);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateROWID(int paramInt, ROWID paramROWID)
/*      */     throws SQLException
/*      */   {
/* 3134 */     updateOracleObject(paramInt, paramROWID);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateNUMBER(int paramInt, NUMBER paramNUMBER)
/*      */     throws SQLException
/*      */   {
/* 3141 */     updateOracleObject(paramInt, paramNUMBER);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateDATE(int paramInt, DATE paramDATE)
/*      */     throws SQLException
/*      */   {
/* 3148 */     updateOracleObject(paramInt, paramDATE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM)
/*      */     throws SQLException
/*      */   {
/* 3156 */     updateOracleObject(paramInt, paramINTERVALYM);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS)
/*      */     throws SQLException
/*      */   {
/* 3164 */     updateOracleObject(paramInt, paramINTERVALDS);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP)
/*      */     throws SQLException
/*      */   {
/* 3171 */     updateOracleObject(paramInt, paramTIMESTAMP);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*      */     throws SQLException
/*      */   {
/* 3179 */     updateOracleObject(paramInt, paramTIMESTAMPTZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*      */     throws SQLException
/*      */   {
/* 3187 */     updateOracleObject(paramInt, paramTIMESTAMPLTZ);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateARRAY(int paramInt, ARRAY paramARRAY)
/*      */     throws SQLException
/*      */   {
/* 3194 */     updateOracleObject(paramInt, paramARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateSTRUCT(int paramInt, STRUCT paramSTRUCT)
/*      */     throws SQLException
/*      */   {
/* 3201 */     updateOracleObject(paramInt, paramSTRUCT);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE)
/*      */     throws SQLException
/*      */   {
/* 3208 */     updateOracleObject(paramInt, paramOPAQUE);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateREF(int paramInt, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 3215 */     updateOracleObject(paramInt, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCHAR(int paramInt, CHAR paramCHAR)
/*      */     throws SQLException
/*      */   {
/* 3222 */     updateOracleObject(paramInt, paramCHAR);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRAW(int paramInt, RAW paramRAW)
/*      */     throws SQLException
/*      */   {
/* 3229 */     updateOracleObject(paramInt, paramRAW);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBLOB(int paramInt, BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 3236 */     updateOracleObject(paramInt, paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCLOB(int paramInt, CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 3243 */     updateOracleObject(paramInt, paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBFILE(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 3250 */     updateOracleObject(paramInt, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBfile(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 3257 */     updateOracleObject(paramInt, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum)
/*      */     throws SQLException
/*      */   {
/* 3265 */     throw new Error("wanna do datum = ((CustomDatum) x).toDatum(m_comm)");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateORAData(int paramInt, ORAData paramORAData)
/*      */     throws SQLException
/*      */   {
/* 3275 */     Datum localDatum = paramORAData.toDatum(this.connection);
/*      */     
/* 3277 */     updateOracleObject(paramInt, localDatum);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 3284 */     updateREF(paramInt, (REF)paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 3291 */     updateBLOB(paramInt, (BLOB)paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 3298 */     updateCLOB(paramInt, (CLOB)paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 3305 */     updateARRAY(paramInt, (ARRAY)paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getColumnCount()
/*      */     throws SQLException
/*      */   {
/* 3319 */     if (this.columnCount == 0)
/*      */     {
/* 3321 */       if ((this.resultSet instanceof OracleResultSetImpl))
/*      */       {
/* 3323 */         if (((OracleResultSetImpl)this.resultSet).statement.accessors != null) {
/* 3324 */           this.columnCount = ((OracleResultSetImpl)this.resultSet).statement.numberOfDefinePositions;
/*      */         }
/*      */         else {
/* 3327 */           this.columnCount = getInternalMetadata().getColumnCount();
/*      */         }
/*      */       } else {
/* 3330 */         this.columnCount = ((ScrollableResultSet)this.resultSet).getColumnCount();
/*      */       }
/*      */     }
/* 3333 */     return this.columnCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ResultSetMetaData getInternalMetadata()
/*      */     throws SQLException
/*      */   {
/* 3343 */     if (this.rsetMetaData == null) {
/* 3344 */       this.rsetMetaData = this.resultSet.getMetaData();
/*      */     }
/* 3346 */     return this.rsetMetaData;
/*      */   }
/*      */   
/*      */   private void cancelRowChanges()
/*      */     throws SQLException
/*      */   {
/* 3352 */     synchronized (this.connection)
/*      */     {
/* 3354 */       if (this.isInserting) {
/* 3355 */         cancelRowInserts();
/*      */       }
/* 3357 */       if (this.isUpdating) {
/* 3358 */         cancelRowUpdates();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isOnInsertRow()
/*      */   {
/* 3369 */     return this.isInserting;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cancelRowInserts()
/*      */   {
/* 3379 */     if (this.isInserting)
/*      */     {
/* 3381 */       this.isInserting = false;
/*      */       
/* 3383 */       clearRowBuffer();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isUpdatingRow()
/*      */   {
/* 3394 */     return this.isUpdating;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void clearRowBuffer()
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/* 3404 */     if (this.rowBuffer != null)
/*      */     {
/* 3406 */       for (i = 0; i < this.rowBuffer.length; i++) {
/* 3407 */         this.rowBuffer[i] = null;
/*      */       }
/*      */     }
/* 3410 */     if (this.m_nullIndicator != null)
/*      */     {
/* 3412 */       for (i = 0; i < this.m_nullIndicator.length; i++) {
/* 3413 */         this.m_nullIndicator[i] = false;
/*      */       }
/*      */     }
/* 3416 */     if (this.typeInfo != null)
/*      */     {
/* 3418 */       for (i = 0; i < this.typeInfo.length; i++) {
/* 3419 */         if (this.typeInfo[i] != null) {
/* 3420 */           for (int j = 0; j < this.typeInfo[i].length; j++) {
/* 3421 */             this.typeInfo[i][j] = 0;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setRowBufferAt(int paramInt, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 3436 */     setRowBufferAt(paramInt, paramDatum, (int[])null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void setRowBufferAt(int paramInt, Object paramObject, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/* 3447 */     if (!this.isInserting)
/*      */     {
/* 3449 */       if ((isBeforeFirst()) || (isAfterLast()) || (getRow() == 0))
/*      */       {
/* 3451 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 3452 */         localSQLException.fillInStackTrace();
/* 3453 */         throw localSQLException;
/*      */       }
/*      */       
/* 3456 */       this.isUpdating = true;
/*      */     }
/*      */     
/* 3459 */     if ((paramInt < 1) || (paramInt > getColumnCount() - 1))
/*      */     {
/* 3461 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setRowBufferAt");
/* 3462 */       localSQLException.fillInStackTrace();
/* 3463 */       throw localSQLException;
/*      */     }
/*      */     
/* 3466 */     if (this.rowBuffer == null) {
/* 3467 */       this.rowBuffer = new Object[getColumnCount()];
/*      */     }
/* 3469 */     if (this.m_nullIndicator == null)
/*      */     {
/* 3471 */       this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       
/* 3473 */       for (int i = 0; i < getColumnCount(); i++) {
/* 3474 */         this.m_nullIndicator[i] = false;
/*      */       }
/*      */     }
/* 3477 */     if (paramArrayOfInt != null)
/*      */     {
/* 3479 */       if (this.typeInfo == null)
/*      */       {
/* 3481 */         this.typeInfo = new int[getColumnCount()][];
/*      */       }
/*      */       
/* 3484 */       this.typeInfo[paramInt] = paramArrayOfInt;
/*      */     }
/*      */     
/* 3487 */     this.rowBuffer[paramInt] = paramObject;
/* 3488 */     this.m_nullIndicator[paramInt] = (paramObject == null ? 1 : false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Datum getRowBufferDatumAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3498 */     if ((paramInt < 1) || (paramInt > getColumnCount() - 1))
/*      */     {
/* 3500 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 3501 */       ((SQLException)localObject1).fillInStackTrace();
/* 3502 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/* 3505 */     Object localObject1 = null;
/*      */     
/* 3507 */     if (this.rowBuffer != null)
/*      */     {
/* 3509 */       Object localObject2 = this.rowBuffer[paramInt];
/*      */       
/* 3511 */       if (localObject2 != null)
/*      */       {
/* 3513 */         if ((localObject2 instanceof Datum))
/*      */         {
/* 3515 */           localObject1 = (Datum)localObject2;
/*      */         }
/*      */         else
/*      */         {
/* 3519 */           OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3520 */           int i = paramInt + 1;
/* 3521 */           localObject1 = SQLUtil.makeOracleDatum(this.connection, localObject2, localOracleResultSetMetaData.getColumnType(i), null, localOracleResultSetMetaData.isNCHAR(i));
/*      */           
/*      */ 
/*      */ 
/* 3525 */           this.rowBuffer[paramInt] = localObject1;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3530 */     return (Datum)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Object getRowBufferAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3540 */     if ((paramInt < 1) || (paramInt > getColumnCount() - 1))
/*      */     {
/* 3542 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 3543 */       localSQLException.fillInStackTrace();
/* 3544 */       throw localSQLException;
/*      */     }
/*      */     
/* 3547 */     if (this.rowBuffer != null)
/*      */     {
/* 3549 */       return this.rowBuffer[paramInt];
/*      */     }
/*      */     
/* 3552 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean isRowBufferUpdatedAt(int paramInt)
/*      */   {
/* 3559 */     if (this.rowBuffer == null) {
/* 3560 */       return false;
/*      */     }
/* 3562 */     return (this.rowBuffer[paramInt] != null) || (this.m_nullIndicator[paramInt] != 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareInsertRowStatement()
/*      */     throws SQLException
/*      */   {
/* 3572 */     if (this.insertStmt == null)
/*      */     {
/*      */ 
/* 3575 */       PreparedStatement localPreparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getInsertSqlForUpdatableResultSet(this));
/*      */       
/*      */ 
/*      */ 
/* 3579 */       this.insertStmt = ((OraclePreparedStatement)((OraclePreparedStatementWrapper)localPreparedStatement).preparedStatement);
/* 3580 */       this.insertStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 3581 */       if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 3582 */         this.insertStmt.setEscapeProcessing(true);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareInsertRowBinds()
/*      */     throws SQLException
/*      */   {
/* 3594 */     int i = 1;
/*      */     
/*      */ 
/* 3597 */     i = prepareSubqueryBinds(this.insertStmt, i);
/*      */     
/* 3599 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 3601 */     for (int j = 1; j < getColumnCount(); j++)
/*      */     {
/* 3603 */       Object localObject = getRowBufferAt(j);
/*      */       
/* 3605 */       if (localObject != null)
/*      */       {
/* 3607 */         if ((localObject instanceof Reader))
/*      */         {
/* 3609 */           if (localOracleResultSetMetaData.isNCHAR(j + 1))
/* 3610 */             this.insertStmt.setFormOfUse(i, (short)2);
/* 3611 */           this.insertStmt.setCharacterStream(i + j - 1, (Reader)localObject, this.typeInfo[j][0]);
/*      */ 
/*      */         }
/* 3614 */         else if ((localObject instanceof InputStream))
/*      */         {
/* 3616 */           if (this.typeInfo[j][1] == 2) {
/* 3617 */             this.insertStmt.setBinaryStream(i + j - 1, (InputStream)localObject, this.typeInfo[j][0]);
/*      */ 
/*      */           }
/* 3620 */           else if (this.typeInfo[j][1] == 1) {
/* 3621 */             this.insertStmt.setAsciiStream(i + j - 1, (InputStream)localObject, this.typeInfo[j][0]);
/*      */           }
/*      */           
/*      */         }
/*      */         else
/*      */         {
/* 3627 */           Datum localDatum = getRowBufferDatumAt(j);
/*      */           
/* 3629 */           if (localOracleResultSetMetaData.isNCHAR(j + 1))
/* 3630 */             this.insertStmt.setFormOfUse(i + j - 1, (short)2);
/* 3631 */           this.insertStmt.setOracleObject(i + j - 1, localDatum);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 3637 */         int k = getInternalMetadata().getColumnType(j + 1);
/*      */         
/* 3639 */         if ((k == 2006) || (k == 2002) || (k == 2008) || (k == 2007) || (k == 2003))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3647 */           this.insertStmt.setNull(i + j - 1, k, getInternalMetadata().getColumnTypeName(j + 1));
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 3652 */           this.insertStmt.setNull(i + j - 1, k);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void executeInsertRow()
/*      */     throws SQLException
/*      */   {
/* 3665 */     if (this.insertStmt.executeUpdate() != 1)
/*      */     {
/* 3667 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 3668 */       localSQLException.fillInStackTrace();
/* 3669 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getNumColumnsChanged()
/*      */     throws SQLException
/*      */   {
/* 3682 */     int i = 0;
/*      */     
/* 3684 */     if (this.indexColsChanged == null) {
/* 3685 */       this.indexColsChanged = new int[getColumnCount()];
/*      */     }
/* 3687 */     if (this.rowBuffer != null)
/*      */     {
/* 3689 */       for (int j = 1; j < getColumnCount(); j++)
/*      */       {
/* 3691 */         if ((this.rowBuffer[j] != null) || ((this.rowBuffer[j] == null) && (this.m_nullIndicator[j] != 0)))
/*      */         {
/*      */ 
/* 3694 */           this.indexColsChanged[(i++)] = j;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3699 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareUpdateRowStatement(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3713 */     if (this.updateStmt != null) {
/* 3714 */       this.updateStmt.close();
/*      */     }
/* 3716 */     PreparedStatement localPreparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getUpdateSqlForUpdatableResultSet(this, paramInt, this.rowBuffer, this.indexColsChanged));
/*      */     
/*      */ 
/*      */ 
/* 3720 */     this.updateStmt = ((OraclePreparedStatement)((OraclePreparedStatementWrapper)localPreparedStatement).preparedStatement);
/* 3721 */     this.updateStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 3722 */     if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 3723 */       this.updateStmt.setEscapeProcessing(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareUpdateRowBinds(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3733 */     int i = 1;
/*      */     
/*      */ 
/* 3736 */     i = prepareSubqueryBinds(this.updateStmt, i);
/*      */     
/* 3738 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 3740 */     for (int j = 0; j < paramInt; j++)
/*      */     {
/* 3742 */       int k = this.indexColsChanged[j];
/* 3743 */       Object localObject = getRowBufferAt(k);
/*      */       
/* 3745 */       if (localObject != null)
/*      */       {
/* 3747 */         if ((localObject instanceof Reader))
/*      */         {
/* 3749 */           if (localOracleResultSetMetaData.isNCHAR(k + 1))
/* 3750 */             this.updateStmt.setFormOfUse(i, (short)2);
/* 3751 */           this.updateStmt.setCharacterStream(i++, (Reader)localObject, this.typeInfo[k][0]);
/*      */ 
/*      */         }
/* 3754 */         else if ((localObject instanceof InputStream))
/*      */         {
/* 3756 */           if (this.typeInfo[k][1] == 2)
/*      */           {
/*      */ 
/* 3759 */             this.updateStmt.setBinaryStream(i++, (InputStream)localObject, this.typeInfo[k][0]);
/*      */           }
/* 3761 */           else if (this.typeInfo[k][1] == 1)
/*      */           {
/* 3763 */             this.updateStmt.setAsciiStream(i++, (InputStream)localObject, this.typeInfo[k][0]);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 3768 */           Datum localDatum = getRowBufferDatumAt(k);
/*      */           
/* 3770 */           if (localOracleResultSetMetaData.isNCHAR(k + 1))
/* 3771 */             this.updateStmt.setFormOfUse(i, (short)2);
/* 3772 */           this.updateStmt.setOracleObject(i++, localDatum);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 3778 */         int m = getInternalMetadata().getColumnType(k + 1);
/*      */         
/* 3780 */         if ((m == 2006) || (m == 2002) || (m == 2008) || (m == 2007) || (m == 2003))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3787 */           this.updateStmt.setNull(i++, m, getInternalMetadata().getColumnTypeName(k + 1));
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 3792 */           if (localOracleResultSetMetaData.isNCHAR(k + 1))
/* 3793 */             this.updateStmt.setFormOfUse(i, (short)2);
/* 3794 */           this.updateStmt.setNull(i++, m);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3800 */     prepareCompareSelfBinds(this.updateStmt, i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void executeUpdateRow()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3812 */       if (this.updateStmt.executeUpdate() == 0)
/*      */       {
/* 3814 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 3815 */         localSQLException.fillInStackTrace();
/* 3816 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3821 */       if (this.isCachedRset)
/*      */       {
/*      */ 
/* 3824 */         ((ScrollableResultSet)this.resultSet).refreshRowsInCache(getRow(), 1, 1000);
/*      */         
/* 3826 */         cancelRowUpdates();
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 3836 */       if (this.updateStmt != null)
/*      */       {
/* 3838 */         this.updateStmt.close();
/*      */         
/* 3840 */         this.updateStmt = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareDeleteRowStatement()
/*      */     throws SQLException
/*      */   {
/* 3852 */     if (this.deleteStmt == null)
/*      */     {
/* 3854 */       PreparedStatement localPreparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getDeleteSqlForUpdatableResultSet(this));
/*      */       
/*      */ 
/* 3857 */       this.deleteStmt = ((OraclePreparedStatement)((OraclePreparedStatementWrapper)localPreparedStatement).preparedStatement);
/* 3858 */       this.deleteStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 3859 */       if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 3860 */         this.deleteStmt.setEscapeProcessing(true);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareDeleteRowBinds()
/*      */     throws SQLException
/*      */   {
/* 3871 */     int i = 1;
/*      */     
/*      */ 
/* 3874 */     i = prepareSubqueryBinds(this.deleteStmt, i);
/*      */     
/*      */ 
/* 3877 */     prepareCompareSelfBinds(this.deleteStmt, i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void executeDeleteRow()
/*      */     throws SQLException
/*      */   {
/* 3889 */     if (this.deleteStmt.executeUpdate() == 0)
/*      */     {
/* 3891 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 3892 */       localSQLException.fillInStackTrace();
/* 3893 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3898 */     if (this.isCachedRset) {
/* 3899 */       ((ScrollableResultSet)this.resultSet).removeRowInCache(getRow());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int prepareCompareSelfBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3908 */     paramOraclePreparedStatement.setOracleObject(paramInt, this.resultSet.getOracleObject(1));
/*      */     
/* 3910 */     return paramInt + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int prepareSubqueryBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3918 */     int i = this.scrollStmt.copyBinds(paramOraclePreparedStatement, paramInt - 1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3933 */     return i + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void setIsNull(int paramInt)
/*      */   {
/* 3940 */     this.wasNull = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void setIsNull(boolean paramBoolean)
/*      */   {
/* 3947 */     if (paramBoolean) {
/* 3948 */       this.wasNull = 1;
/*      */     } else {
/* 3950 */       this.wasNull = 2;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getCursorName() throws SQLException
/*      */   {
/* 3956 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3959 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 3960 */       localSQLException.fillInStackTrace();
/* 3961 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 3978 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement getOracleStatement()
/*      */     throws SQLException
/*      */   {
/* 3989 */     return this.resultSet == null ? null : this.resultSet.getOracleStatement();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 3994 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/UpdatableResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */