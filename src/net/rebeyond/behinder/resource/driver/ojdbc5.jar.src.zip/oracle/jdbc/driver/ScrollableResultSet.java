/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.OracleResultSet.AuthorizationIndicator;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ScrollableResultSet
/*      */   extends BaseResultSet
/*      */ {
/*      */   PhysicalConnection connection;
/*      */   OracleResultSetImpl resultSet;
/*      */   ScrollRsetStatement scrollStmt;
/*      */   ResultSetMetaData metadata;
/*      */   private int rsetType;
/*      */   private int rsetConcurency;
/*      */   private int beginColumnIndex;
/*      */   private int columnCount;
/*      */   private int wasNull;
/*      */   OracleResultSetCache rsetCache;
/*      */   int currentRow;
/*      */   private int numRowsCached;
/*      */   private boolean allRowsCached;
/*      */   private int lastRefetchSz;
/*      */   private Vector refetchRowids;
/*      */   private OraclePreparedStatement refetchStmt;
/*      */   private int usrFetchDirection;
/*      */   
/*      */   ScrollableResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*   77 */     this.connection = ((OracleStatement)paramScrollRsetStatement).connection;
/*   78 */     this.resultSet = paramOracleResultSetImpl;
/*   79 */     this.metadata = null;
/*   80 */     this.scrollStmt = paramScrollRsetStatement;
/*   81 */     this.rsetType = paramInt1;
/*   82 */     this.rsetConcurency = paramInt2;
/*   83 */     this.beginColumnIndex = (needIdentifier(paramInt1, paramInt2) ? 1 : 0);
/*   84 */     this.columnCount = 0;
/*   85 */     this.wasNull = -1;
/*   86 */     this.rsetCache = paramScrollRsetStatement.getResultSetCache();
/*      */     
/*   88 */     if (this.rsetCache == null)
/*      */     {
/*   90 */       this.rsetCache = new OracleResultSetCacheImpl();
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/*   96 */         this.rsetCache.clear();
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*  101 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  102 */         localSQLException.fillInStackTrace();
/*  103 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  108 */     this.currentRow = 0;
/*  109 */     this.numRowsCached = 0;
/*  110 */     this.allRowsCached = false;
/*  111 */     this.lastRefetchSz = 0;
/*  112 */     this.refetchRowids = null;
/*  113 */     this.refetchStmt = null;
/*  114 */     this.usrFetchDirection = 1000;
/*  115 */     getInternalMetadata();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  128 */     synchronized (this.connection)
/*      */     {
/*  130 */       if (this.closed) return;
/*  131 */       super.close();
/*  132 */       if (this.resultSet != null)
/*  133 */         this.resultSet.close();
/*  134 */       if (this.refetchStmt != null)
/*  135 */         this.refetchStmt.close();
/*  136 */       if (this.scrollStmt != null)
/*  137 */         this.scrollStmt.notifyCloseRset();
/*  138 */       if (this.refetchRowids != null) {
/*  139 */         this.refetchRowids.removeAllElements();
/*      */       }
/*  141 */       this.resultSet = null;
/*  142 */       this.scrollStmt = null;
/*  143 */       this.refetchStmt = null;
/*  144 */       this.refetchRowids = null;
/*  145 */       this.metadata = null;
/*      */       
/*      */       try
/*      */       {
/*  149 */         if (this.rsetCache != null)
/*      */         {
/*  151 */           this.rsetCache.clear();
/*  152 */           this.rsetCache.close();
/*      */         }
/*      */         
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*  158 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  159 */         localSQLException.fillInStackTrace();
/*  160 */         throw localSQLException;
/*      */       }
/*      */       finally
/*      */       {
/*  164 */         this.rsetCache = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  172 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  175 */       if (this.wasNull == -1)
/*      */       {
/*  177 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/*  178 */         localSQLException.fillInStackTrace();
/*  179 */         throw localSQLException;
/*      */       }
/*      */       
/*  182 */       return this.wasNull == 1;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Statement getStatement()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 7	oracle/jdbc/driver/ScrollableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   11: checkcast 39	java/sql/Statement
/*      */     //   14: aload_1
/*      */     //   15: monitorexit
/*      */     //   16: areturn
/*      */     //   17: astore_2
/*      */     //   18: aload_1
/*      */     //   19: monitorexit
/*      */     //   20: aload_2
/*      */     //   21: athrow
/*      */     // Line number table:
/*      */     //   Java source line #190	-> byte code offset #0
/*      */     //   Java source line #193	-> byte code offset #7
/*      */     //   Java source line #195	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	22	0	this	ScrollableResultSet
/*      */     //   5	14	1	Ljava/lang/Object;	Object
/*      */     //   17	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	16	17	finally
/*      */     //   17	20	17	finally
/*      */   }
/*      */   
/*      */   void resetBeginColumnIndex()
/*      */   {
/*  203 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  206 */       this.beginColumnIndex = 0;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   ResultSet getResultSet()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 5	oracle/jdbc/driver/ScrollableResultSet:resultSet	Loracle/jdbc/driver/OracleResultSetImpl;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #216	-> byte code offset #0
/*      */     //   Java source line #219	-> byte code offset #7
/*      */     //   Java source line #221	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	ScrollableResultSet
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   int removeRowInCache(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  226 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  229 */       if ((!isEmptyResultSet()) && (isValidRow(paramInt)))
/*      */       {
/*  231 */         removeCachedRowAt(paramInt);
/*      */         
/*  233 */         this.numRowsCached -= 1;
/*      */         
/*  235 */         if (paramInt >= this.currentRow) {
/*  236 */           this.currentRow -= 1;
/*      */         }
/*  238 */         return 1;
/*      */       }
/*      */       
/*  241 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int refreshRowsInCache(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  252 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  255 */       OracleResultSetImpl localOracleResultSetImpl = null;
/*  256 */       int i = 0;
/*      */       
/*      */ 
/*  259 */       i = get_refetch_size(paramInt1, paramInt2, paramInt3);
/*      */       
/*      */       try
/*      */       {
/*  263 */         if (i > 0)
/*      */         {
/*      */ 
/*      */ 
/*  267 */           if (i != this.lastRefetchSz)
/*      */           {
/*  269 */             if (this.refetchStmt != null) {
/*  270 */               this.refetchStmt.close();
/*      */             }
/*  272 */             this.refetchStmt = prepare_refetch_statement(i);
/*  273 */             this.refetchStmt.setQueryTimeout(((OracleStatement)this.scrollStmt).getQueryTimeout());
/*  274 */             this.lastRefetchSz = i;
/*      */           }
/*      */           
/*      */ 
/*  278 */           prepare_refetch_binds(this.refetchStmt, i);
/*      */           
/*      */ 
/*  281 */           localOracleResultSetImpl = (OracleResultSetImpl)this.refetchStmt.executeQuery();
/*      */           
/*      */ 
/*  284 */           save_refetch_results(localOracleResultSetImpl, paramInt1, i, paramInt3);
/*      */         }
/*      */         
/*      */       }
/*      */       finally
/*      */       {
/*  290 */         if (localOracleResultSetImpl != null) {
/*  291 */           localOracleResultSetImpl.close();
/*      */         }
/*      */       }
/*  294 */       return i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/*  305 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  308 */       if (this.closed)
/*      */       {
/*  310 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  311 */         localSQLException.fillInStackTrace();
/*  312 */         throw localSQLException;
/*      */       }
/*      */       
/*  315 */       if (isEmptyResultSet())
/*      */       {
/*  317 */         return false;
/*      */       }
/*      */       
/*      */ 
/*  321 */       if (this.currentRow < 1)
/*      */       {
/*  323 */         this.currentRow = 1;
/*      */       }
/*      */       else
/*      */       {
/*  327 */         this.currentRow += 1;
/*      */       }
/*      */       
/*  330 */       return isValidRow(this.currentRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  338 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  341 */       if (this.closed)
/*      */       {
/*  343 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  344 */         localSQLException.fillInStackTrace();
/*  345 */         throw localSQLException;
/*      */       }
/*  347 */       return (!isEmptyResultSet()) && (this.currentRow < 1);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  354 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  357 */       if (this.closed)
/*      */       {
/*  359 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  360 */         localSQLException.fillInStackTrace();
/*  361 */         throw localSQLException;
/*      */       }
/*  363 */       return (!isEmptyResultSet()) && (this.currentRow > 0) && (!isValidRow(this.currentRow));
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  370 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  373 */       if (this.closed)
/*      */       {
/*  375 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  376 */         localSQLException.fillInStackTrace();
/*  377 */         throw localSQLException;
/*      */       }
/*  379 */       return this.currentRow == 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  386 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  389 */       if (this.closed)
/*      */       {
/*  391 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  392 */         localSQLException.fillInStackTrace();
/*  393 */         throw localSQLException;
/*      */       }
/*  395 */       return (!isEmptyResultSet()) && (isValidRow(this.currentRow)) && (!isValidRow(this.currentRow + 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  403 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  406 */       if (this.closed)
/*      */       {
/*  408 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  409 */         localSQLException.fillInStackTrace();
/*  410 */         throw localSQLException;
/*      */       }
/*  412 */       if (!isEmptyResultSet()) {
/*  413 */         this.currentRow = 0;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void afterLast() throws SQLException
/*      */   {
/*  420 */     synchronized (this.connection) {
/*  421 */       if (this.closed)
/*      */       {
/*  423 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  424 */         localSQLException.fillInStackTrace();
/*  425 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*  429 */       if (!isEmptyResultSet()) {
/*  430 */         this.currentRow = (getLastRow() + 1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean first() throws SQLException
/*      */   {
/*  437 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  440 */       if (this.closed)
/*      */       {
/*  442 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  443 */         localSQLException.fillInStackTrace();
/*  444 */         throw localSQLException;
/*      */       }
/*  446 */       if (isEmptyResultSet())
/*      */       {
/*  448 */         return false;
/*      */       }
/*      */       
/*      */ 
/*  452 */       this.currentRow = 1;
/*      */       
/*  454 */       return isValidRow(this.currentRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/*  462 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  465 */       if (this.closed)
/*      */       {
/*  467 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  468 */         localSQLException.fillInStackTrace();
/*  469 */         throw localSQLException;
/*      */       }
/*  471 */       if (isEmptyResultSet())
/*      */       {
/*  473 */         return false;
/*      */       }
/*      */       
/*      */ 
/*  477 */       this.currentRow = getLastRow();
/*      */       
/*  479 */       return isValidRow(this.currentRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/*  487 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  490 */       if (this.closed)
/*      */       {
/*  492 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  493 */         localSQLException.fillInStackTrace();
/*  494 */         throw localSQLException;
/*      */       }
/*  496 */       if (isValidRow(this.currentRow)) {
/*  497 */         return this.currentRow;
/*      */       }
/*  499 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean absolute(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  506 */     synchronized (this.connection)
/*      */     {
/*      */       SQLException localSQLException;
/*  509 */       if (this.closed)
/*      */       {
/*  511 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  512 */         localSQLException.fillInStackTrace();
/*  513 */         throw localSQLException;
/*      */       }
/*  515 */       if (paramInt == 0)
/*      */       {
/*  517 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "absolute(" + paramInt + ")");
/*  518 */         localSQLException.fillInStackTrace();
/*  519 */         throw localSQLException;
/*      */       }
/*      */       
/*  522 */       if (isEmptyResultSet())
/*      */       {
/*  524 */         return false;
/*      */       }
/*  526 */       if (paramInt > 0)
/*      */       {
/*  528 */         this.currentRow = paramInt;
/*      */       }
/*  530 */       else if (paramInt < 0)
/*      */       {
/*  532 */         this.currentRow = (getLastRow() + 1 + paramInt);
/*      */       }
/*      */       
/*  535 */       return isValidRow(this.currentRow);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean relative(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  542 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  545 */       if (this.closed)
/*      */       {
/*  547 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  548 */         localSQLException.fillInStackTrace();
/*  549 */         throw localSQLException;
/*      */       }
/*  551 */       if (isEmptyResultSet())
/*      */       {
/*  553 */         return false;
/*      */       }
/*  555 */       if (isValidRow(this.currentRow))
/*      */       {
/*  557 */         this.currentRow += paramInt;
/*      */         
/*  559 */         return isValidRow(this.currentRow);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  564 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "relative");
/*  565 */       localSQLException.fillInStackTrace();
/*  566 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/*  575 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  578 */       if (this.closed)
/*      */       {
/*  580 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  581 */         localSQLException.fillInStackTrace();
/*  582 */         throw localSQLException;
/*      */       }
/*  584 */       if (isEmptyResultSet())
/*      */       {
/*  586 */         return false;
/*      */       }
/*  588 */       if (isAfterLast())
/*      */       {
/*  590 */         this.currentRow = getLastRow();
/*      */       }
/*      */       else
/*      */       {
/*  594 */         this.currentRow -= 1;
/*      */       }
/*      */       
/*  597 */       return isValidRow(this.currentRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  608 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  611 */       if (this.closed)
/*      */       {
/*  613 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  614 */         ((SQLException)localObject1).fillInStackTrace();
/*  615 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*  618 */       this.wasNull = -1;
/*      */       
/*  620 */       if (!isValidRow(this.currentRow))
/*      */       {
/*  622 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  623 */         ((SQLException)localObject1).fillInStackTrace();
/*  624 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*  627 */       if ((paramInt < 1) || (paramInt > getColumnCount()))
/*      */       {
/*  629 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  630 */         ((SQLException)localObject1).fillInStackTrace();
/*  631 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*  634 */       Object localObject1 = getCachedDatumValueAt(this.currentRow, paramInt + this.beginColumnIndex);
/*      */       
/*      */ 
/*  637 */       this.wasNull = (localObject1 == null ? 1 : 0);
/*      */       
/*  639 */       return (Datum)localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  646 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  649 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  651 */       if (localDatum != null)
/*      */       {
/*  653 */         switch (getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case 2005: 
/*  661 */           CLOB localCLOB = (CLOB)localDatum;
/*  662 */           return localCLOB.getSubString(1L, (int)localCLOB.length());
/*      */         
/*      */ 
/*      */ 
/*      */         case 91: 
/*  667 */           if (this.connection.mapDateToTimestamp) {
/*  668 */             return localDatum.toJdbc().toString();
/*      */           }
/*  670 */           return localDatum.dateValue().toString();
/*      */         
/*      */ 
/*      */ 
/*      */         case 93: 
/*  675 */           if ((localDatum instanceof DATE))
/*      */           {
/*  677 */             if (this.connection.mapDateToTimestamp) {
/*  678 */               return localDatum.toJdbc().toString();
/*      */             }
/*  680 */             return localDatum.dateValue().toString();
/*      */           }
/*      */           
/*      */ 
/*  684 */           if (this.connection.j2ee13Compliant)
/*      */           {
/*      */ 
/*  687 */             return localDatum.toJdbc().toString();
/*      */           }
/*      */           
/*      */ 
/*  691 */           return localDatum.stringValue(this.connection);
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  698 */         return localDatum.stringValue(this.connection);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  703 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  710 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  713 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  715 */       if (localDatum != null)
/*      */       {
/*  717 */         return localDatum.booleanValue();
/*      */       }
/*      */       
/*  720 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  727 */     synchronized (this.connection)
/*      */     {
/*  729 */       if (!isValidRow(this.currentRow))
/*      */       {
/*  731 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  732 */         ((SQLException)localObject1).fillInStackTrace();
/*  733 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*  736 */       if ((paramInt < 1) || (paramInt > getColumnCount()))
/*      */       {
/*  738 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  739 */         ((SQLException)localObject1).fillInStackTrace();
/*  740 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*  743 */       Object localObject1 = null;
/*  744 */       OracleResultSet.AuthorizationIndicator localAuthorizationIndicator = null;
/*      */       
/*      */       try
/*      */       {
/*  748 */         localObject1 = (CachedRowElement)this.rsetCache.get(this.currentRow, paramInt);
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*  753 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  754 */         localSQLException.fillInStackTrace();
/*  755 */         throw localSQLException;
/*      */       }
/*      */       
/*  758 */       if (localObject1 != null) {
/*  759 */         localAuthorizationIndicator = ((CachedRowElement)localObject1).getIndicator();
/*      */       }
/*  761 */       return localAuthorizationIndicator;
/*      */     }
/*      */   }
/*      */   
/*      */   public byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  768 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  771 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  773 */       if (localDatum != null) {
/*  774 */         return localDatum.byteValue();
/*      */       }
/*  776 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  783 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  786 */       long l = getLong(paramInt);
/*      */       
/*  788 */       if ((l > 65537L) || (l < -65538L))
/*      */       {
/*  790 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/*  791 */         localSQLException.fillInStackTrace();
/*  792 */         throw localSQLException;
/*      */       }
/*      */       
/*  795 */       return (short)(int)l;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  802 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  805 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  807 */       if (localDatum != null)
/*      */       {
/*  809 */         return localDatum.intValue();
/*      */       }
/*      */       
/*  812 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  819 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  822 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  824 */       if (localDatum != null)
/*      */       {
/*  826 */         return localDatum.longValue();
/*      */       }
/*      */       
/*  829 */       return 0L;
/*      */     }
/*      */   }
/*      */   
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  836 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  839 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  841 */       if (localDatum != null)
/*      */       {
/*  843 */         return localDatum.floatValue();
/*      */       }
/*      */       
/*  846 */       return 0.0F;
/*      */     }
/*      */   }
/*      */   
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  853 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  856 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  858 */       if (localDatum != null)
/*      */       {
/*  860 */         return localDatum.doubleValue();
/*      */       }
/*      */       
/*  863 */       return 0.0D;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  871 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  874 */       Datum localDatum = getOracleObject(paramInt1);
/*      */       
/*  876 */       if (localDatum != null)
/*      */       {
/*  878 */         return localDatum.bigDecimalValue();
/*      */       }
/*      */       
/*  881 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  888 */     synchronized (this.connection)
/*      */     {
/*  890 */       byte[] arrayOfByte = null;
/*  891 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*  893 */       if (localDatum != null)
/*      */       {
/*  895 */         if ((localDatum instanceof RAW)) {
/*  896 */           arrayOfByte = ((RAW)localDatum).shareBytes();
/*  897 */         } else if ((localDatum instanceof BLOB))
/*      */         {
/*  899 */           BLOB localBLOB = (BLOB)localDatum;
/*  900 */           long l = localBLOB.length();
/*  901 */           if (l > 2147483647L)
/*      */           {
/*      */ 
/*  904 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/*  905 */             localSQLException.fillInStackTrace();
/*  906 */             throw localSQLException;
/*      */           }
/*      */           
/*  909 */           arrayOfByte = localBLOB.getBytes(1L, (int)l);
/*  910 */           if (localBLOB.isTemporary()) this.resultSet.statement.addToTempLobsToFree(localBLOB);
/*      */         }
/*      */         else
/*      */         {
/*  914 */           arrayOfByte = localDatum.getBytes();
/*      */         }
/*      */       }
/*  917 */       return arrayOfByte;
/*      */     }
/*      */   }
/*      */   
/*      */   public Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  924 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  927 */       Datum localDatum = getOracleObject(paramInt);
/*  928 */       Date localDate = null;
/*      */       
/*  930 */       if (localDatum != null)
/*      */       {
/*  932 */         ResultSetMetaData localResultSetMetaData = getInternalMetadata();
/*  933 */         switch (localResultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         {
/*      */ 
/*      */ 
/*      */         case -101: 
/*  938 */           localDate = ((TIMESTAMPTZ)localDatum).dateValue(this.connection);
/*  939 */           break;
/*      */         
/*      */         case -102: 
/*  942 */           localDate = ((TIMESTAMPLTZ)localDatum).dateValue(this.connection);
/*  943 */           break;
/*      */         
/*      */         default: 
/*  946 */           localDate = localDatum.dateValue();
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  951 */       return localDate;
/*      */     }
/*      */   }
/*      */   
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  958 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  961 */       Datum localDatum = getOracleObject(paramInt);
/*  962 */       Time localTime = null;
/*      */       
/*  964 */       if (localDatum != null)
/*      */       {
/*  966 */         ResultSetMetaData localResultSetMetaData = getInternalMetadata();
/*  967 */         switch (localResultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         {
/*      */         case -101: 
/*  970 */           localTime = ((TIMESTAMPTZ)localDatum).timeValue(this.connection);
/*  971 */           break;
/*      */         
/*      */         case -102: 
/*  974 */           localTime = ((TIMESTAMPLTZ)localDatum).timeValue(this.connection, this.connection.getDbTzCalendar());
/*      */           
/*  976 */           break;
/*      */         
/*      */         default: 
/*  979 */           localTime = localDatum.timeValue();
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  984 */       return localTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  992 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  995 */       Datum localDatum = getOracleObject(paramInt);
/*  996 */       Timestamp localTimestamp = null;
/*      */       
/*  998 */       if (localDatum != null)
/*      */       {
/* 1000 */         ResultSetMetaData localResultSetMetaData = getInternalMetadata();
/* 1001 */         switch (localResultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         {
/*      */         case -101: 
/* 1004 */           localTimestamp = ((TIMESTAMPTZ)localDatum).timestampValue(this.connection);
/* 1005 */           break;
/*      */         
/*      */         case -102: 
/* 1008 */           localTimestamp = ((TIMESTAMPLTZ)localDatum).timestampValue(this.connection, this.connection.getDbTzCalendar());
/*      */           
/* 1010 */           break;
/*      */         
/*      */         default: 
/* 1013 */           localTimestamp = localDatum.timestampValue();
/*      */         }
/*      */         
/*      */       }
/*      */       
/* 1018 */       return localTimestamp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1026 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1029 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1031 */       if (localDatum != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1036 */         return localDatum.asciiStreamValue();
/*      */       }
/*      */       
/* 1039 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1047 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1050 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1052 */       if (localDatum != null)
/*      */       {
/* 1054 */         DBConversion localDBConversion = this.connection.conversion;
/* 1055 */         byte[] arrayOfByte = localDatum.shareBytes();
/*      */         
/* 1057 */         if ((localDatum instanceof RAW))
/*      */         {
/* 1059 */           return localDBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */         }
/*      */         
/* 1062 */         if ((localDatum instanceof CHAR))
/*      */         {
/* 1064 */           return localDBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1069 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/* 1070 */         localSQLException.fillInStackTrace();
/* 1071 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1075 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1083 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1086 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1088 */       if (localDatum != null)
/*      */       {
/* 1090 */         return localDatum.binaryStreamValue();
/*      */       }
/*      */       
/* 1093 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1103 */     return getObject(paramInt, this.connection.getTypeMap());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1111 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1114 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1116 */       if (localDatum != null)
/*      */       {
/* 1118 */         return localDatum.characterStreamValue();
/*      */       }
/*      */       
/* 1121 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1131 */     return getBigDecimal(paramInt, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1143 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1146 */       Object localObject1 = null;
/* 1147 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1149 */       if (localDatum != null)
/*      */       {
/* 1151 */         int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
/*      */         
/* 1153 */         switch (i)
/*      */         {
/*      */         case 2002: 
/* 1156 */           localObject1 = ((STRUCT)localDatum).toJdbc(paramMap);
/* 1157 */           break;
/*      */         
/*      */         case 91: 
/* 1160 */           if (this.connection.mapDateToTimestamp) {
/* 1161 */             localObject1 = localDatum.toJdbc();
/*      */           } else
/* 1163 */             localObject1 = localDatum.dateValue();
/* 1164 */           break;
/*      */         case 93: 
/* 1166 */           if ((localDatum instanceof DATE))
/*      */           {
/* 1168 */             if (this.connection.mapDateToTimestamp) {
/* 1169 */               localObject1 = localDatum.toJdbc();
/*      */             } else {
/* 1171 */               localObject1 = localDatum.dateValue();
/*      */             }
/*      */             
/*      */           }
/* 1175 */           else if (this.connection.j2ee13Compliant)
/*      */           {
/*      */ 
/* 1178 */             localObject1 = localDatum.toJdbc();
/*      */           }
/*      */           else
/*      */           {
/* 1182 */             localObject1 = localDatum;
/*      */           }
/*      */           
/* 1185 */           break;
/*      */         case -102: 
/*      */         case -101: 
/* 1188 */           localObject1 = localDatum;
/* 1189 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         default: 
/* 1194 */           localObject1 = localDatum.toJdbc();
/*      */         }
/*      */         
/*      */       }
/* 1198 */       return localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 130	oracle/jdbc/driver/ScrollableResultSet:getREF	(I)Loracle/sql/REF;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1206	-> byte code offset #0
/*      */     //   Java source line #1209	-> byte code offset #7
/*      */     //   Java source line #1211	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	ScrollableResultSet
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 131	oracle/jdbc/driver/ScrollableResultSet:getBLOB	(I)Loracle/sql/BLOB;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1217	-> byte code offset #0
/*      */     //   Java source line #1220	-> byte code offset #7
/*      */     //   Java source line #1222	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	ScrollableResultSet
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 132	oracle/jdbc/driver/ScrollableResultSet:getCLOB	(I)Loracle/sql/CLOB;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1228	-> byte code offset #0
/*      */     //   Java source line #1231	-> byte code offset #7
/*      */     //   Java source line #1233	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	ScrollableResultSet
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public java.sql.Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 133	oracle/jdbc/driver/ScrollableResultSet:getARRAY	(I)Loracle/sql/ARRAY;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1240	-> byte code offset #0
/*      */     //   Java source line #1243	-> byte code offset #7
/*      */     //   Java source line #1245	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	ScrollableResultSet
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1252 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1255 */       Datum localDatum = getOracleObject(paramInt);
/* 1256 */       Date localDate = null;
/*      */       
/* 1258 */       if (localDatum != null)
/*      */       {
/* 1260 */         ResultSetMetaData localResultSetMetaData = getInternalMetadata();
/* 1261 */         switch (localResultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         {
/*      */         case -101: 
/* 1264 */           localDate = new Date(((TIMESTAMPTZ)localDatum).timestampValue(this.connection).getTime());
/*      */           
/* 1266 */           break;
/*      */         
/*      */         case -102: 
/* 1269 */           Calendar localCalendar = this.connection.getDbTzCalendar();
/*      */           
/* 1271 */           localDate = new Date(((TIMESTAMPLTZ)localDatum).timestampValue(this.connection, localCalendar == null ? paramCalendar : localCalendar).getTime());
/*      */           
/*      */ 
/* 1274 */           break;
/*      */         
/*      */         default: 
/* 1277 */           localDate = new Date(localDatum.timestampValue(paramCalendar).getTime());
/*      */         }
/*      */         
/*      */       }
/* 1281 */       return localDate;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1290 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1293 */       Datum localDatum = getOracleObject(paramInt);
/* 1294 */       Time localTime = null;
/*      */       
/* 1296 */       if (localDatum != null)
/*      */       {
/* 1298 */         ResultSetMetaData localResultSetMetaData = getInternalMetadata();
/* 1299 */         switch (localResultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         {
/*      */         case -101: 
/* 1302 */           localTime = new Time(((TIMESTAMPTZ)localDatum).timestampValue(this.connection).getTime());
/* 1303 */           break;
/*      */         
/*      */         case -102: 
/* 1306 */           Calendar localCalendar = this.connection.getDbTzCalendar();
/* 1307 */           localTime = new Time(((TIMESTAMPLTZ)localDatum).timestampValue(this.connection, localCalendar == null ? paramCalendar : localCalendar).getTime());
/*      */           
/* 1309 */           break;
/*      */         
/*      */         default: 
/* 1312 */           localTime = new Time(localDatum.timestampValue(paramCalendar).getTime());
/*      */         }
/*      */         
/*      */       }
/* 1316 */       return localTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1325 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1328 */       Datum localDatum = getOracleObject(paramInt);
/* 1329 */       Timestamp localTimestamp = null;
/*      */       
/* 1331 */       if (localDatum != null)
/*      */       {
/* 1333 */         ResultSetMetaData localResultSetMetaData = getInternalMetadata();
/* 1334 */         switch (localResultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         {
/*      */         case -101: 
/* 1337 */           localTimestamp = ((TIMESTAMPTZ)localDatum).timestampValue(this.connection);
/* 1338 */           break;
/*      */         
/*      */         case -102: 
/* 1341 */           Calendar localCalendar = this.connection.getDbTzCalendar();
/* 1342 */           localTimestamp = ((TIMESTAMPLTZ)localDatum).timestampValue(this.connection, localCalendar == null ? paramCalendar : localCalendar);
/*      */           
/* 1344 */           break;
/*      */         
/*      */         default: 
/* 1347 */           localTimestamp = localDatum.timestampValue(paramCalendar);
/*      */         }
/*      */         
/*      */       }
/* 1351 */       return localTimestamp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1359 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1362 */       URL localURL = null;
/*      */       
/* 1364 */       int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
/* 1365 */       int j = SQLUtil.getInternalType(i);
/*      */       
/*      */ 
/* 1368 */       if ((j == 96) || (j == 1) || (j == 8))
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/* 1373 */           String str = getString(paramInt);
/* 1374 */           if (str == null) localURL = null; else {
/* 1375 */             localURL = new URL(str);
/*      */           }
/*      */         }
/*      */         catch (MalformedURLException localMalformedURLException)
/*      */         {
/* 1380 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 1381 */           localSQLException2.fillInStackTrace();
/* 1382 */           throw localSQLException2;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1389 */         SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Conversion to java.net.URL not supported.");
/* 1390 */         localSQLException1.fillInStackTrace();
/* 1391 */         throw localSQLException1;
/*      */       }
/*      */       
/*      */ 
/* 1395 */       return localURL;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getCursor(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1403 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 1407 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/* 1408 */       localSQLException.fillInStackTrace();
/* 1409 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ROWID getROWID(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1419 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1422 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1424 */       if (localDatum != null)
/*      */       {
/* 1426 */         if ((localDatum instanceof ROWID)) {
/* 1427 */           return (ROWID)localDatum;
/*      */         }
/*      */         
/* 1430 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/* 1431 */         localSQLException.fillInStackTrace();
/* 1432 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1436 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1444 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1447 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1449 */       if (localDatum != null)
/*      */       {
/* 1451 */         if ((localDatum instanceof NUMBER)) {
/* 1452 */           return (NUMBER)localDatum;
/*      */         }
/*      */         
/* 1455 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/* 1456 */         localSQLException.fillInStackTrace();
/* 1457 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1461 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1469 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1472 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1474 */       if (localDatum != null)
/*      */       {
/* 1476 */         if ((localDatum instanceof DATE))
/* 1477 */           return (DATE)localDatum;
/* 1478 */         if ((localDatum instanceof TIMESTAMP))
/* 1479 */           return TIMESTAMP.toDATE(localDatum.getBytes());
/* 1480 */         if ((localDatum instanceof TIMESTAMPLTZ))
/* 1481 */           return TIMESTAMPLTZ.toDATE(this.connection, localDatum.getBytes());
/* 1482 */         if ((localDatum instanceof TIMESTAMPTZ)) {
/* 1483 */           return TIMESTAMPTZ.toDATE(this.connection, localDatum.getBytes());
/*      */         }
/*      */         
/* 1486 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/* 1487 */         localSQLException.fillInStackTrace();
/* 1488 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1492 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1500 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1503 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1505 */       if (localDatum != null)
/*      */       {
/* 1507 */         if ((localDatum instanceof TIMESTAMP))
/* 1508 */           return (TIMESTAMP)localDatum;
/* 1509 */         if ((localDatum instanceof TIMESTAMPLTZ))
/* 1510 */           return TIMESTAMPLTZ.toTIMESTAMP(this.connection, localDatum.getBytes());
/* 1511 */         if ((localDatum instanceof TIMESTAMPTZ))
/* 1512 */           return TIMESTAMPTZ.toTIMESTAMP(this.connection, localDatum.getBytes());
/* 1513 */         if ((localDatum instanceof DATE)) {
/* 1514 */           return new TIMESTAMP((DATE)localDatum);
/*      */         }
/*      */         
/* 1517 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/* 1518 */         localSQLException.fillInStackTrace();
/* 1519 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1523 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1531 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1534 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1536 */       if (localDatum != null)
/*      */       {
/* 1538 */         if ((localDatum instanceof TIMESTAMPTZ))
/* 1539 */           return (TIMESTAMPTZ)localDatum;
/* 1540 */         if ((localDatum instanceof TIMESTAMPLTZ)) {
/* 1541 */           return TIMESTAMPLTZ.toTIMESTAMPTZ(this.connection, localDatum.getBytes());
/*      */         }
/*      */         
/* 1544 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/* 1545 */         localSQLException.fillInStackTrace();
/* 1546 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1550 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1558 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1561 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1563 */       if (localDatum != null)
/*      */       {
/* 1565 */         if ((localDatum instanceof TIMESTAMPLTZ)) {
/* 1566 */           return (TIMESTAMPLTZ)localDatum;
/*      */         }
/*      */         
/* 1569 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/* 1570 */         localSQLException.fillInStackTrace();
/* 1571 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1575 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALDS getINTERVALDS(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1583 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1586 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1588 */       if (localDatum != null)
/*      */       {
/* 1590 */         if ((localDatum instanceof INTERVALDS)) {
/* 1591 */           return (INTERVALDS)localDatum;
/*      */         }
/*      */         
/* 1594 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
/* 1595 */         localSQLException.fillInStackTrace();
/* 1596 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1600 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALYM getINTERVALYM(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1608 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1611 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1613 */       if (localDatum != null)
/*      */       {
/* 1615 */         if ((localDatum instanceof INTERVALYM)) {
/* 1616 */           return (INTERVALYM)localDatum;
/*      */         }
/*      */         
/* 1619 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
/* 1620 */         localSQLException.fillInStackTrace();
/* 1621 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1625 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ARRAY getARRAY(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1633 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1636 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1638 */       if (localDatum != null)
/*      */       {
/* 1640 */         if ((localDatum instanceof ARRAY)) {
/* 1641 */           return (ARRAY)localDatum;
/*      */         }
/*      */         
/* 1644 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/* 1645 */         localSQLException.fillInStackTrace();
/* 1646 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1650 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public STRUCT getSTRUCT(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1658 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1661 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1663 */       if (localDatum != null)
/*      */       {
/* 1665 */         if ((localDatum instanceof STRUCT)) {
/* 1666 */           return (STRUCT)localDatum;
/*      */         }
/*      */         
/* 1669 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/* 1670 */         localSQLException.fillInStackTrace();
/* 1671 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1675 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public OPAQUE getOPAQUE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1683 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1686 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1688 */       if (localDatum != null)
/*      */       {
/* 1690 */         if ((localDatum instanceof OPAQUE)) {
/* 1691 */           return (OPAQUE)localDatum;
/*      */         }
/*      */         
/* 1694 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/* 1695 */         localSQLException.fillInStackTrace();
/* 1696 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1700 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public REF getREF(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1708 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1711 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1713 */       if (localDatum != null)
/*      */       {
/* 1715 */         if ((localDatum instanceof REF)) {
/* 1716 */           return (REF)localDatum;
/*      */         }
/*      */         
/* 1719 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/* 1720 */         localSQLException.fillInStackTrace();
/* 1721 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1725 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CHAR getCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1733 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1736 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1738 */       if (localDatum != null)
/*      */       {
/* 1740 */         if ((localDatum instanceof CHAR)) {
/* 1741 */           return (CHAR)localDatum;
/*      */         }
/*      */         
/* 1744 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/* 1745 */         localSQLException.fillInStackTrace();
/* 1746 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1750 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1758 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1761 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1763 */       if (localDatum != null)
/*      */       {
/* 1765 */         if ((localDatum instanceof RAW)) {
/* 1766 */           return (RAW)localDatum;
/*      */         }
/*      */         
/* 1769 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/* 1770 */         localSQLException.fillInStackTrace();
/* 1771 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1775 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BLOB getBLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1783 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1786 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1788 */       if (localDatum != null)
/*      */       {
/* 1790 */         if ((localDatum instanceof BLOB)) {
/* 1791 */           return (BLOB)localDatum;
/*      */         }
/*      */         
/* 1794 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/* 1795 */         localSQLException.fillInStackTrace();
/* 1796 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1800 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CLOB getCLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1808 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1811 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1813 */       if (localDatum != null)
/*      */       {
/* 1815 */         if ((localDatum instanceof CLOB)) {
/* 1816 */           return (CLOB)localDatum;
/*      */         }
/*      */         
/* 1819 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 1820 */         localSQLException.fillInStackTrace();
/* 1821 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1825 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BFILE getBFILE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1837 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1840 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/* 1842 */       if (localDatum != null)
/*      */       {
/* 1844 */         if ((localDatum instanceof BFILE)) {
/* 1845 */           return (BFILE)localDatum;
/*      */         }
/*      */         
/* 1848 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/* 1849 */         localSQLException.fillInStackTrace();
/* 1850 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 1854 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public BFILE getBfile(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokevirtual 180	oracle/jdbc/driver/ScrollableResultSet:getBFILE	(I)Loracle/sql/BFILE;
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1863	-> byte code offset #0
/*      */     //   Java source line #1866	-> byte code offset #7
/*      */     //   Java source line #1868	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	ScrollableResultSet
/*      */     //   0	20	1	paramInt	int
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/* 1875 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1878 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1883 */       return paramCustomDatumFactory.create(localDatum, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/* 1892 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1895 */       Datum localDatum = getOracleObject(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1900 */       return paramORADataFactory.create(localDatum, 0);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Object getObject(int paramInt, oracle.jdbc.OracleDataFactory paramOracleDataFactory)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_3
/*      */     //   6: monitorenter
/*      */     //   7: aload_2
/*      */     //   8: aload_0
/*      */     //   9: iload_1
/*      */     //   10: invokevirtual 183	oracle/jdbc/driver/ScrollableResultSet:getObject	(I)Ljava/lang/Object;
/*      */     //   13: iconst_0
/*      */     //   14: invokeinterface 184 3 0
/*      */     //   19: aload_3
/*      */     //   20: monitorexit
/*      */     //   21: areturn
/*      */     //   22: astore 4
/*      */     //   24: aload_3
/*      */     //   25: monitorexit
/*      */     //   26: aload 4
/*      */     //   28: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1908	-> byte code offset #0
/*      */     //   Java source line #1914	-> byte code offset #7
/*      */     //   Java source line #1916	-> byte code offset #22
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	29	0	this	ScrollableResultSet
/*      */     //   0	29	1	paramInt	int
/*      */     //   0	29	2	paramOracleDataFactory	oracle.jdbc.OracleDataFactory
/*      */     //   5	20	3	Ljava/lang/Object;	Object
/*      */     //   22	5	4	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	21	22	finally
/*      */     //   22	26	22	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: new 185	oracle/jdbc/driver/OracleResultSetMetaData
/*      */     //   10: dup
/*      */     //   11: aload_0
/*      */     //   12: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   15: aload_0
/*      */     //   16: getfield 7	oracle/jdbc/driver/ScrollableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   19: checkcast 2	oracle/jdbc/driver/OracleStatement
/*      */     //   22: aload_0
/*      */     //   23: getfield 11	oracle/jdbc/driver/ScrollableResultSet:beginColumnIndex	I
/*      */     //   26: invokespecial 186	oracle/jdbc/driver/OracleResultSetMetaData:<init>	(Loracle/jdbc/driver/PhysicalConnection;Loracle/jdbc/driver/OracleStatement;I)V
/*      */     //   29: aload_1
/*      */     //   30: monitorexit
/*      */     //   31: areturn
/*      */     //   32: astore_2
/*      */     //   33: aload_1
/*      */     //   34: monitorexit
/*      */     //   35: aload_2
/*      */     //   36: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1931	-> byte code offset #0
/*      */     //   Java source line #1934	-> byte code offset #7
/*      */     //   Java source line #1938	-> byte code offset #32
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	37	0	this	ScrollableResultSet
/*      */     //   5	29	1	Ljava/lang/Object;	Object
/*      */     //   32	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	31	32	finally
/*      */     //   32	35	32	finally
/*      */   }
/*      */   
/*      */   public int findColumn(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1943 */     synchronized (this.connection)
/*      */     {
/* 1945 */       if (this.closed)
/*      */       {
/* 1947 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1948 */         localSQLException.fillInStackTrace();
/* 1949 */         throw localSQLException;
/*      */       }
/* 1951 */       return this.resultSet.findColumn(paramString) - this.beginColumnIndex;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1962 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 1965 */       if (paramInt == 1000)
/*      */       {
/* 1967 */         this.usrFetchDirection = paramInt;
/*      */       }
/* 1969 */       else if ((paramInt == 1001) || (paramInt == 1002))
/*      */       {
/*      */ 
/* 1972 */         this.usrFetchDirection = paramInt;
/*      */         
/* 1974 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1981 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 1982 */         localSQLException.fillInStackTrace();
/* 1983 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 1995 */     return 1000;
/*      */   }
/*      */   
/*      */   public void setFetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2001 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2004 */       this.resultSet.setFetchSize(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 4	oracle/jdbc/driver/ScrollableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 5	oracle/jdbc/driver/ScrollableResultSet:resultSet	Loracle/jdbc/driver/OracleResultSetImpl;
/*      */     //   11: invokevirtual 192	oracle/jdbc/driver/OracleResultSetImpl:getFetchSize	()I
/*      */     //   14: aload_1
/*      */     //   15: monitorexit
/*      */     //   16: ireturn
/*      */     //   17: astore_2
/*      */     //   18: aload_1
/*      */     //   19: monitorexit
/*      */     //   20: aload_2
/*      */     //   21: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2011	-> byte code offset #0
/*      */     //   Java source line #2014	-> byte code offset #7
/*      */     //   Java source line #2016	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	22	0	this	ScrollableResultSet
/*      */     //   5	14	1	Ljava/lang/Object;	Object
/*      */     //   17	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	16	17	finally
/*      */     //   17	20	17	finally
/*      */   }
/*      */   
/*      */   public int getType()
/*      */     throws SQLException
/*      */   {
/* 2023 */     return this.rsetType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/* 2031 */     return this.rsetConcurency;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 2046 */     if (!needIdentifier(this.rsetType, this.rsetConcurency))
/*      */     {
/* 2048 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "refreshRow");
/* 2049 */       localSQLException1.fillInStackTrace();
/* 2050 */       throw localSQLException1;
/*      */     }
/*      */     
/* 2053 */     if (isValidRow(this.currentRow))
/*      */     {
/* 2055 */       int i = getFetchDirection();
/*      */       
/*      */       try
/*      */       {
/* 2059 */         refreshRowsInCache(this.currentRow, getFetchSize(), i);
/*      */ 
/*      */       }
/*      */       catch (SQLException localSQLException3)
/*      */       {
/* 2064 */         SQLException localSQLException4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localSQLException3, 90, "Unsupported syntax for refreshRow()");
/* 2065 */         localSQLException4.fillInStackTrace();
/* 2066 */         throw localSQLException4;
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/* 2072 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "refreshRow");
/* 2073 */       localSQLException2.fillInStackTrace();
/* 2074 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isEmptyResultSet()
/*      */     throws SQLException
/*      */   {
/* 2090 */     if (this.numRowsCached != 0)
/*      */     {
/* 2092 */       return false;
/*      */     }
/* 2094 */     if ((this.numRowsCached == 0) && (this.allRowsCached))
/*      */     {
/* 2096 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 2100 */     return !isValidRow(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isValidRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2113 */     if ((paramInt > 0) && (paramInt <= this.numRowsCached))
/*      */     {
/* 2115 */       return true;
/*      */     }
/* 2117 */     if (paramInt <= 0)
/*      */     {
/* 2119 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2123 */     return cacheRowAt(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cacheCurrentRow(OracleResultSetImpl paramOracleResultSetImpl, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2134 */     for (int i = 0; i < getColumnCount(); i++)
/*      */     {
/*      */ 
/* 2137 */       byte[] arrayOfByte = paramOracleResultSetImpl.privateGetBytes(i + 1);
/* 2138 */       OracleResultSet.AuthorizationIndicator localAuthorizationIndicator = paramOracleResultSetImpl.getAuthorizationIndicator(i + 1);
/*      */       
/* 2140 */       CachedRowElement localCachedRowElement = new CachedRowElement(paramInt, i + 1, localAuthorizationIndicator, arrayOfByte);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2145 */       int j = paramOracleResultSetImpl.statement.accessors[i].internalType;
/*      */       Object localObject;
/* 2147 */       if (j == 112)
/*      */       {
/* 2149 */         localObject = paramOracleResultSetImpl.getCLOB(i + 1);
/* 2150 */         localCachedRowElement.setData((Datum)localObject);
/*      */       }
/* 2152 */       else if (j == 113)
/*      */       {
/* 2154 */         localObject = paramOracleResultSetImpl.getBLOB(i + 1);
/* 2155 */         localCachedRowElement.setData((Datum)localObject);
/*      */       }
/*      */       
/* 2158 */       putCachedValueAt(paramInt, i + 1, localCachedRowElement);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean cacheRowAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2174 */     while ((this.numRowsCached < paramInt) && (this.resultSet.next())) {
/* 2175 */       cacheCurrentRow(this.resultSet, ++this.numRowsCached);
/*      */     }
/* 2177 */     if (this.numRowsCached < paramInt)
/*      */     {
/* 2179 */       this.allRowsCached = true;
/*      */       
/* 2181 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2185 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int cacheAllRows()
/*      */     throws SQLException
/*      */   {
/* 2197 */     while (this.resultSet.next()) {
/* 2198 */       cacheCurrentRow(this.resultSet, ++this.numRowsCached);
/*      */     }
/* 2200 */     this.allRowsCached = true;
/*      */     
/* 2202 */     return this.numRowsCached;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getColumnCount()
/*      */     throws SQLException
/*      */   {
/* 2213 */     if (this.columnCount == 0)
/*      */     {
/*      */ 
/*      */ 
/* 2217 */       int i = this.resultSet.statement.numberOfDefinePositions;
/*      */       
/* 2219 */       if ((this.resultSet.statement.accessors != null) && (i > 0)) {
/* 2220 */         this.columnCount = i;
/*      */       } else {
/* 2222 */         this.columnCount = getInternalMetadata().getColumnCount();
/*      */       }
/*      */     }
/* 2225 */     return this.columnCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ResultSetMetaData getInternalMetadata()
/*      */     throws SQLException
/*      */   {
/* 2236 */     if (this.metadata == null) {
/* 2237 */       this.metadata = this.resultSet.getMetaData();
/*      */     }
/* 2239 */     return this.metadata;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getLastRow()
/*      */     throws SQLException
/*      */   {
/* 2250 */     if (!this.allRowsCached) {
/* 2251 */       cacheAllRows();
/*      */     }
/* 2253 */     return this.numRowsCached;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int get_refetch_size(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2266 */     int i = paramInt3 == 1001 ? -1 : 1;
/*      */     
/*      */ 
/* 2269 */     int j = 0;
/*      */     
/* 2271 */     if (this.refetchRowids == null) {
/* 2272 */       this.refetchRowids = new Vector(10);
/*      */     } else {
/* 2274 */       this.refetchRowids.removeAllElements();
/*      */     }
/*      */     
/* 2277 */     while ((j < paramInt2) && (isValidRow(paramInt1 + j * i)))
/*      */     {
/* 2279 */       this.refetchRowids.addElement(getCachedDatumValueAt(paramInt1 + j * i, 1));
/*      */       
/*      */ 
/* 2282 */       j++;
/*      */     }
/*      */     
/* 2285 */     return j;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private OraclePreparedStatement prepare_refetch_statement(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2302 */     if (paramInt < 1)
/*      */     {
/* 2304 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2305 */       ((SQLException)localObject).fillInStackTrace();
/* 2306 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2309 */     Object localObject = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getRefetchSqlForScrollableResultSet(this, paramInt));
/*      */     
/*      */ 
/* 2312 */     return (OraclePreparedStatement)((OraclePreparedStatementWrapper)localObject).preparedStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepare_refetch_binds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2326 */     int i = this.scrollStmt.copyBinds(paramOraclePreparedStatement, 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2346 */     for (int j = 0; j < paramInt; j++)
/*      */     {
/* 2348 */       paramOraclePreparedStatement.setROWID(i + j + 1, (ROWID)this.refetchRowids.elementAt(j));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void save_refetch_results(OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2363 */     int i = paramInt3 == 1001 ? -1 : 1;
/*      */     
/* 2365 */     while (paramOracleResultSetImpl.next())
/*      */     {
/* 2367 */       ROWID localROWID = paramOracleResultSetImpl.getROWID(1);
/*      */       
/* 2369 */       int j = 0;
/* 2370 */       int k = paramInt1;
/*      */       
/* 2372 */       while ((j == 0) && (k < paramInt1 + paramInt2 * i))
/*      */       {
/* 2374 */         if (((ROWID)getCachedDatumValueAt(k, 1)).stringValue(this.connection).equals(localROWID.stringValue(this.connection)))
/*      */         {
/* 2376 */           j = 1;
/*      */         } else {
/* 2378 */           k += i;
/*      */         }
/*      */       }
/* 2381 */       if (j != 0) {
/* 2382 */         cacheCurrentRow(paramOracleResultSetImpl, k);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private Datum getCachedDatumValueAt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2391 */     CachedRowElement localCachedRowElement = null;
/*      */     Object localObject;
/*      */     try
/*      */     {
/* 2395 */       localCachedRowElement = (CachedRowElement)this.rsetCache.get(paramInt1, paramInt2);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2400 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2401 */       ((SQLException)localObject).fillInStackTrace();
/* 2402 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2406 */     Datum localDatum = null;
/*      */     
/* 2408 */     if (localCachedRowElement != null)
/*      */     {
/* 2410 */       localDatum = localCachedRowElement.getDataAsDatum();
/* 2411 */       localObject = localCachedRowElement.getData();
/*      */       
/* 2413 */       if ((localDatum == null) && (localObject != null) && (localObject.length > 0))
/*      */       {
/*      */ 
/* 2416 */         int i = getInternalMetadata().getColumnType(paramInt2);
/* 2417 */         int j = getInternalMetadata().getColumnDisplaySize(paramInt2);
/*      */         
/* 2419 */         int k = ((OracleResultSetMetaData)getInternalMetadata()).getDescription()[(paramInt2 - 1)].internalType;
/*      */         
/*      */ 
/*      */ 
/* 2423 */         int m = this.scrollStmt.getMaxFieldSize();
/*      */         
/* 2425 */         if ((m > 0) && (m < j)) {
/* 2426 */           j = m;
/*      */         }
/* 2428 */         String str = null;
/*      */         
/* 2430 */         if ((i == 2006) || (i == 2002) || (i == 2008) || (i == 2007) || (i == 2003))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2437 */           str = getInternalMetadata().getColumnTypeName(paramInt2);
/*      */         }
/*      */         
/* 2440 */         short s = this.resultSet.statement.accessors[(paramInt2 - 1)].formOfUse;
/*      */         
/* 2442 */         if ((s == 2) && ((k == 96) || (k == 1) || (k == 8) || (k == 112)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2451 */           localDatum = SQLUtil.makeNDatum(this.connection, (byte[])localObject, k, str, s, j);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 2457 */           localDatum = SQLUtil.makeDatum(this.connection, (byte[])localObject, k, str, j);
/*      */         }
/*      */         
/*      */ 
/* 2461 */         localCachedRowElement.setData(localDatum);
/*      */       }
/*      */     }
/*      */     
/* 2465 */     return localDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void putCachedValueAt(int paramInt1, int paramInt2, CachedRowElement paramCachedRowElement)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2476 */       this.rsetCache.put(paramInt1, paramInt2, paramCachedRowElement);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2481 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2482 */       localSQLException.fillInStackTrace();
/* 2483 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void removeCachedRowAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2495 */       this.rsetCache.remove(paramInt);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2500 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2501 */       localSQLException.fillInStackTrace();
/* 2502 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean needIdentifier(int paramInt1, int paramInt2)
/*      */   {
/* 2515 */     if (((paramInt1 == 1003) && (paramInt2 == 1007)) || ((paramInt1 == 1004) && (paramInt2 == 1007)))
/*      */     {
/*      */ 
/* 2518 */       return false;
/*      */     }
/* 2520 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean needCache(int paramInt1, int paramInt2)
/*      */   {
/* 2529 */     if ((paramInt1 == 1003) || ((paramInt1 == 1004) && (paramInt2 == 1007)))
/*      */     {
/*      */ 
/* 2532 */       return false;
/*      */     }
/* 2534 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean supportRefreshRow(int paramInt1, int paramInt2)
/*      */   {
/* 2543 */     if ((paramInt1 == 1003) || ((paramInt1 == 1004) && (paramInt2 == 1007)))
/*      */     {
/*      */ 
/* 2546 */       return false;
/*      */     }
/* 2548 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getFirstUserColumnIndex()
/*      */   {
/* 2567 */     return this.beginColumnIndex;
/*      */   }
/*      */   
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/* 2573 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2576 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 2577 */       localSQLException.fillInStackTrace();
/* 2578 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 2595 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement getOracleStatement()
/*      */     throws SQLException
/*      */   {
/* 2606 */     return this.resultSet == null ? null : this.resultSet.getOracleStatement();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2611 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/ScrollableResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */