package oracle.jdbc.pool;

import java.sql.SQLException;
import javax.sql.DataSource;
import javax.sql.PooledConnection;

public abstract interface OracleConnectionCache
  extends DataSource
{
  public abstract void reusePooledConnection(PooledConnection paramPooledConnection)
    throws SQLException;
  
  public abstract void closePooledConnection(PooledConnection paramPooledConnection)
    throws SQLException;
  
  public abstract void close()
    throws SQLException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/pool/OracleConnectionCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */