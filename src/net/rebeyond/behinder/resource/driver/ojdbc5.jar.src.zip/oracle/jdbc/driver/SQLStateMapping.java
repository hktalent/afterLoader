/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLStateMapping
/*     */ {
/*     */   public static final int SQLEXCEPTION = 0;
/*     */   public static final int SQLNONTRANSIENTEXCEPTION = 1;
/*     */   public static final int SQLTRANSIENTEXCEPTION = 2;
/*     */   public static final int SQLDATAEXCEPTION = 3;
/*     */   public static final int SQLFEATURENOTSUPPORTEDEXCEPTION = 4;
/*     */   public static final int SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION = 5;
/*     */   public static final int SQLINVALIDAUTHORIZATIONSPECEXCEPTION = 6;
/*     */   public static final int SQLNONTRANSIENTCONNECTIONEXCEPTION = 7;
/*     */   public static final int SQLSYNTAXERROREXCEPTION = 8;
/*     */   public static final int SQLTIMEOUTEXCEPTION = 9;
/*     */   public static final int SQLTRANSACTIONROLLBACKEXCEPTION = 10;
/*     */   public static final int SQLTRANSIENTCONNECTIONEXCEPTION = 11;
/*     */   public static final int SQLCLIENTINFOEXCEPTION = 12;
/*     */   public static final int SQLRECOVERABLEEXCEPTION = 13;
/*     */   int low;
/*     */   int high;
/*     */   public String sqlState;
/*     */   public int exception;
/*     */   static final String mappingResource = "errorMap.xml";
/*     */   static SQLStateMapping[] all;
/*     */   private static final int NUMEBER_OF_MAPPINGS_IN_ERRORMAP_XML = 128;
/*     */   
/*     */   public SQLStateMapping(int paramInt1, int paramInt2, String paramString, int paramInt3)
/*     */   {
/*  54 */     this.low = paramInt1;
/*  55 */     this.sqlState = paramString;
/*  56 */     this.exception = paramInt3;
/*  57 */     this.high = paramInt2;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isIncluded(int paramInt)
/*     */   {
/*  63 */     return (this.low <= paramInt) && (paramInt <= this.high);
/*     */   }
/*     */   
/*     */ 
/*     */   public SQLException newSQLException(String paramString, int paramInt)
/*     */   {
/*  69 */     switch (this.exception) {
/*     */     case 0: 
/*  71 */       return new SQLException(paramString, this.sqlState, paramInt);
/*     */     }
/*     */     
/*     */     
/*  75 */     return new SQLException(paramString, this.sqlState, paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */   boolean lessThan(SQLStateMapping paramSQLStateMapping)
/*     */   {
/*  81 */     if (this.low < paramSQLStateMapping.low) {
/*  82 */       return this.high < paramSQLStateMapping.high;
/*     */     }
/*     */     
/*  85 */     return this.high <= paramSQLStateMapping.high;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  90 */     return super.toString() + "(" + this.low + ", " + this.high + ", " + this.sqlState + ", " + this.exception + ")";
/*     */   }
/*     */   
/*     */ 
/*     */   public static void main(String[] paramArrayOfString)
/*     */     throws IOException
/*     */   {
/*  97 */     SQLStateMapping[] arrayOfSQLStateMapping = doGetMappings();
/*  98 */     System.out.println("a\t" + arrayOfSQLStateMapping);
/*  99 */     for (int i = 0; i < arrayOfSQLStateMapping.length; i++) {
/* 100 */       System.out.println("low:\t" + arrayOfSQLStateMapping[i].low + "\thigh:\t" + arrayOfSQLStateMapping[i].high + "\tsqlState:\t" + arrayOfSQLStateMapping[i].sqlState + "\tsqlException:\t" + arrayOfSQLStateMapping[i].exception);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static SQLStateMapping[] getMappings()
/*     */   {
/* 110 */     if (all == null) {
/*     */       try {
/* 112 */         all = doGetMappings();
/*     */       }
/*     */       catch (Throwable localThrowable)
/*     */       {
/* 116 */         all = new SQLStateMapping[0];
/*     */       }
/*     */     }
/* 119 */     return all;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static SQLStateMapping[] doGetMappings()
/*     */     throws IOException
/*     */   {
/* 127 */     InputStream localInputStream = SQLStateMapping.class.getResourceAsStream("errorMap.xml");
/* 128 */     ArrayList localArrayList = new ArrayList(128);
/* 129 */     load(localInputStream, localArrayList);
/* 130 */     return (SQLStateMapping[])localArrayList.toArray(new SQLStateMapping[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void load(InputStream paramInputStream, List paramList)
/*     */     throws IOException
/*     */   {
/* 152 */     BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/* 153 */     Tokenizer localTokenizer = new Tokenizer(localBufferedReader);
/* 154 */     int i = -1;
/* 155 */     int j = -1;
/* 156 */     Object localObject1 = null;
/* 157 */     int k = -1;
/* 158 */     Object localObject2 = null;
/* 159 */     int m = 0;
/*     */     String str;
/* 161 */     while ((str = localTokenizer.next()) != null) {
/* 162 */       switch (m) {
/*     */       case 0: 
/* 164 */         if (str.equals("<")) m = 1;
/*     */         break;
/*     */       case 1: 
/* 167 */         if (str.equals("!")) { m = 2;
/* 168 */         } else if (str.equals("oraErrorSqlStateSqlExceptionMapping")) m = 6; else {
/* 169 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */         }
/*     */         break;
/*     */       case 2: 
/* 173 */         if (str.equals("-")) m = 3; else {
/* 174 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */         }
/*     */         break;
/*     */       case 3: 
/* 178 */         if (str.equals("-")) m = 4;
/*     */         break;
/*     */       case 4: 
/* 181 */         if (str.equals("-")) m = 5; else
/* 182 */           m = 3;
/* 183 */         break;
/*     */       case 5: 
/* 185 */         if (str.equals(">")) m = 1; else {
/* 186 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         }
/*     */         break;
/*     */       case 6: 
/* 190 */         if (str.equals(">")) m = 7; else {
/* 191 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         }
/*     */         break;
/*     */       case 7: 
/* 195 */         if (str.equals("<")) m = 8; else {
/* 196 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"<\".");
/*     */         }
/*     */         break;
/*     */       case 8: 
/* 200 */         if (str.equals("!")) { m = 9;
/* 201 */         } else if (str.equals("error")) { m = 14;
/* 202 */         } else if (str.equals("/")) m = 16; else {
/* 203 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected one of \"!--\", \"error\", \"/\".");
/*     */         }
/*     */         break;
/*     */       case 9: 
/* 207 */         if (str.equals("-")) m = 10; else {
/* 208 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */         }
/*     */         break;
/*     */       case 10: 
/* 212 */         if (str.equals("-")) m = 11; else {
/* 213 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */         }
/*     */         break;
/*     */       case 11: 
/* 217 */         if (str.equals("-")) m = 12;
/*     */         break;
/*     */       case 12: 
/* 220 */         if (str.equals("-")) m = 13; else
/* 221 */           m = 11;
/* 222 */         break;
/*     */       case 13: 
/* 224 */         if (str.equals(">")) m = 7; else {
/* 225 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         }
/*     */         break;
/*     */       case 14: 
/* 229 */         if (str.equals("/")) { m = 15;
/* 230 */         } else if (str.equals("oraErrorFrom")) { m = 19;
/* 231 */         } else if (str.equals("oraErrorTo")) { m = 21;
/* 232 */         } else if (str.equals("sqlState")) { m = 23;
/* 233 */         } else if (str.equals("sqlException")) { m = 25;
/* 234 */         } else if (str.equals("comment")) m = 27; else {
/* 235 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected one of " + "\"oraErrorFrom\", \"oraErrorTo\", \"sqlState\", " + "\"sqlException\", \"comment\", \"/\".");
/*     */         }
/*     */         
/*     */ 
/*     */         break;
/*     */       case 15: 
/* 241 */         if (str.equals(">")) {
/*     */           try {
/* 243 */             createOne(paramList, i, j, (String)localObject1, k, (String)localObject2);
/*     */           }
/*     */           catch (IOException localIOException) {
/* 246 */             throw new IOException("Invalid error element at line " + localTokenizer.lineno + " of errorMap.xml. " + localIOException.getMessage());
/*     */           }
/*     */           
/* 249 */           i = -1;
/* 250 */           j = -1;
/* 251 */           localObject1 = null;
/* 252 */           k = -1;
/* 253 */           localObject2 = null;
/* 254 */           m = 7;
/*     */         } else {
/* 256 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         }
/*     */         break;
/*     */       case 16: 
/* 260 */         if (str.equals("oraErrorSqlStateSqlExceptionMapping")) m = 17; else {
/* 261 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */         }
/*     */         break;
/*     */       case 17: 
/* 265 */         if (str.equals(">")) m = 18; else {
/* 266 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         }
/*     */         break;
/*     */       case 18: 
/*     */         break;
/*     */       case 19: 
/* 272 */         if (str.equals("=")) m = 20; else {
/* 273 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */         }
/*     */         break;
/*     */       case 20: 
/*     */         try {
/* 278 */           i = Integer.parseInt(str);
/*     */         }
/*     */         catch (NumberFormatException localNumberFormatException1) {
/* 281 */           throw new IOException("Unexpected value \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */         }
/*     */         
/* 284 */         m = 14;
/* 285 */         break;
/*     */       case 21: 
/* 287 */         if (str.equals("=")) m = 22; else {
/* 288 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */         }
/*     */         break;
/*     */       case 22: 
/*     */         try {
/* 293 */           j = Integer.parseInt(str);
/*     */         }
/*     */         catch (NumberFormatException localNumberFormatException2) {
/* 296 */           throw new IOException("Unexpected value \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */         }
/*     */         
/* 299 */         m = 14;
/* 300 */         break;
/*     */       case 23: 
/* 302 */         if (str.equals("=")) m = 24; else {
/* 303 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */         }
/*     */         break;
/*     */       case 24: 
/* 307 */         localObject1 = str;
/* 308 */         m = 14;
/* 309 */         break;
/*     */       case 25: 
/* 311 */         if (str.equals("=")) m = 26; else {
/* 312 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */         }
/*     */         break;
/*     */       case 26: 
/*     */         try {
/* 317 */           k = valueOf(str);
/*     */         }
/*     */         catch (Exception localException) {
/* 320 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected SQLException" + " subclass name.");
/*     */         }
/*     */         
/*     */ 
/* 324 */         m = 14;
/* 325 */         break;
/*     */       case 27: 
/* 327 */         if (str.equals("=")) m = 28; else {
/* 328 */           throw new IOException("Unexpected token \"" + str + "\" at line " + localTokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */         }
/*     */         break;
/*     */       case 28: 
/* 332 */         localObject2 = str;
/* 333 */         m = 14;
/* 334 */         break;
/*     */       default: 
/* 336 */         throw new IOException("Unknown parser state " + m + " at line " + localTokenizer.lineno + " of errorMap.xml.");
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class Tokenizer
/*     */   {
/* 354 */     int lineno = 1;
/*     */     Reader r;
/*     */     int c;
/*     */     
/*     */     Tokenizer(Reader paramReader) throws IOException {
/* 359 */       this.r = paramReader;
/* 360 */       this.c = paramReader.read();
/*     */     }
/*     */     
/*     */     String next() throws IOException {
/* 364 */       StringBuffer localStringBuffer = new StringBuffer(16);
/* 365 */       int i = 1;
/*     */       
/* 367 */       while (this.c != -1) {
/* 368 */         if (this.c == 10) this.lineno += 1;
/* 369 */         if ((this.c <= 32) && (i != 0)) {
/* 370 */           this.c = this.r.read();
/*     */ 
/*     */         }
/* 373 */         else if ((this.c <= 32) && (i == 0)) {
/* 374 */           this.c = this.r.read();
/*     */ 
/*     */         }
/* 377 */         else if (this.c == 34) {
/* 378 */           while ((this.c = this.r.read()) != 34) localStringBuffer.append((char)this.c);
/* 379 */           this.c = this.r.read();
/*     */ 
/*     */         }
/* 382 */         else if (((48 <= this.c) && (this.c <= 57)) || ((65 <= this.c) && (this.c <= 90)) || ((97 <= this.c) && (this.c <= 122)) || (this.c == 95))
/*     */         {
/*     */ 
/*     */           do
/*     */           {
/* 387 */             localStringBuffer.append((char)this.c);
/*     */ 
/*     */ 
/*     */           }
/* 391 */           while (((48 <= (this.c = this.r.read())) && (this.c <= 57)) || ((65 <= this.c) && (this.c <= 90)) || ((97 <= this.c) && (this.c <= 122)) || (this.c == 95));
/*     */         }
/*     */         else {
/* 394 */           localStringBuffer.append((char)this.c);
/* 395 */           this.c = this.r.read();
/*     */         }
/*     */       }
/* 398 */       if (localStringBuffer.length() > 0) return localStringBuffer.toString();
/* 399 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static void createOne(List paramList, int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2) throws IOException
/*     */   {
/* 405 */     if (paramInt1 == -1) throw new IOException("oraErrorFrom is a required attribute");
/* 406 */     if (paramInt2 == -1) paramInt2 = paramInt1;
/* 407 */     if ((paramString1 == null) || (paramString1.length() == 0)) throw new IOException("sqlState is a required attribute");
/* 408 */     if (paramInt3 == -1) throw new IOException("sqlException is a required attribute");
/* 409 */     if ((paramString2 == null) || (paramString2.length() < 8)) throw new IOException("a lengthy comment in required");
/* 410 */     SQLStateMapping localSQLStateMapping = new SQLStateMapping(paramInt1, paramInt2, paramString1, paramInt3);
/* 411 */     add(paramList, localSQLStateMapping);
/*     */   }
/*     */   
/*     */   static void add(List paramList, SQLStateMapping paramSQLStateMapping) {
/* 415 */     for (int i = paramList.size(); 
/* 416 */         i > 0; i--) {
/* 417 */       if (((SQLStateMapping)paramList.get(i - 1)).lessThan(paramSQLStateMapping)) {
/*     */         break;
/*     */       }
/*     */     }
/* 421 */     paramList.add(i, paramSQLStateMapping);
/*     */   }
/*     */   
/*     */   static int valueOf(String paramString) throws Exception
/*     */   {
/* 426 */     if (paramString.equalsIgnoreCase("SQLEXCEPTION")) return 0;
/* 427 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTEXCEPTION")) return 1;
/* 428 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTEXCEPTION")) return 2;
/* 429 */     if (paramString.equalsIgnoreCase("SQLDATAEXCEPTION")) return 3;
/* 430 */     if (paramString.equalsIgnoreCase("SQLFEATURENOTSUPPORTEDEXCEPTION")) return 4;
/* 431 */     if (paramString.equalsIgnoreCase("SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION")) return 5;
/* 432 */     if (paramString.equalsIgnoreCase("SQLINVALIDAUTHORIZATIONSPECEXCEPTION")) return 6;
/* 433 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTCONNECTIONEXCEPTION")) return 7;
/* 434 */     if (paramString.equalsIgnoreCase("SQLSYNTAXERROREXCEPTION")) return 8;
/* 435 */     if (paramString.equalsIgnoreCase("SQLTIMEOUTEXCEPTION")) return 9;
/* 436 */     if (paramString.equalsIgnoreCase("SQLTRANSACTIONROLLBACKEXCEPTION")) return 10;
/* 437 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTCONNECTIONEXCEPTION")) return 11;
/* 438 */     if (paramString.equalsIgnoreCase("SQLCLIENTINFOEXCEPTION")) return 12;
/* 439 */     if (paramString.equalsIgnoreCase("SQLRECOVERABLEEXCEPTION")) return 13;
/* 440 */     throw new Exception("unexpected exception name: " + paramString);
/*     */   }
/*     */   
/*     */ 
/* 444 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/SQLStateMapping.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */