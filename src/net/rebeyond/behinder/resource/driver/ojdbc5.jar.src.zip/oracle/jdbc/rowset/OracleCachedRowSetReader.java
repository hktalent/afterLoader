/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Properties;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.RowSet;
/*     */ import javax.sql.RowSetInternal;
/*     */ import javax.sql.RowSetReader;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.driver.OracleDriver;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleCachedRowSetReader
/*     */   implements RowSetReader, Serializable
/*     */ {
/*     */   static final long serialVersionUID = -3565405169674271176L;
/*     */   static final transient int SETUNICODESTREAM_INTLENGTH = 1;
/*     */   static final transient int SETBINARYSTREAM_INTLENGTH = 2;
/*     */   static final transient int SETASCIISTREAM_INTLENGTH = 3;
/*     */   static final transient int SETCHARACTERSTREAM_INTLENGTH = 4;
/*     */   static final transient int TWO_PARAMETERS = 2;
/*     */   static final transient int THREE_PARAMETERS = 3;
/* 100 */   private static transient boolean driverManagerInitialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Connection getConnection(RowSetInternal paramRowSetInternal)
/*     */     throws SQLException
/*     */   {
/* 117 */     Object localObject1 = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */     Connection localConnection = paramRowSetInternal.getConnection();
/* 125 */     if ((localConnection != null) && (!localConnection.isClosed()))
/*     */     {
/* 127 */       localObject1 = localConnection; } else { Object localObject2;
/*     */       String str2;
/* 129 */       Object localObject3; if (((RowSet)paramRowSetInternal).getDataSourceName() != null)
/*     */       {
/*     */         try
/*     */         {
/* 133 */           InitialContext localInitialContext = null;
/*     */           
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/* 139 */             Properties localProperties = System.getProperties();
/* 140 */             localInitialContext = new InitialContext(localProperties);
/*     */           }
/*     */           catch (SecurityException localSecurityException) {}
/*     */           
/* 144 */           if (localInitialContext == null)
/* 145 */             localInitialContext = new InitialContext();
/* 146 */           localObject2 = (DataSource)localInitialContext.lookup(((RowSet)paramRowSetInternal).getDataSourceName());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 151 */           str2 = ((RowSet)paramRowSetInternal).getUsername();
/* 152 */           localObject3 = ((RowSet)paramRowSetInternal).getPassword();
/* 153 */           if ((str2 == null) && (localObject3 == null))
/*     */           {
/* 155 */             localObject1 = ((DataSource)localObject2).getConnection();
/*     */           }
/*     */           else
/*     */           {
/* 159 */             localObject1 = ((DataSource)localObject2).getConnection(str2, (String)localObject3);
/*     */           }
/*     */           
/*     */         }
/*     */         catch (NamingException localNamingException)
/*     */         {
/* 165 */           localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 300, localNamingException.getMessage());
/* 166 */           ((SQLException)localObject2).fillInStackTrace();
/* 167 */           throw ((Throwable)localObject2);
/*     */         }
/*     */         
/*     */       }
/* 171 */       else if (((RowSet)paramRowSetInternal).getUrl() != null)
/*     */       {
/* 173 */         if (!driverManagerInitialized)
/*     */         {
/* 175 */           DriverManager.registerDriver(new OracleDriver());
/* 176 */           driverManagerInitialized = true;
/*     */         }
/* 178 */         String str1 = ((RowSet)paramRowSetInternal).getUrl();
/* 179 */         localObject2 = ((RowSet)paramRowSetInternal).getUsername();
/* 180 */         str2 = ((RowSet)paramRowSetInternal).getPassword();
/*     */         
/*     */ 
/*     */ 
/* 184 */         if ((str1.equals("")) || (((String)localObject2).equals("")) || (str2.equals("")))
/*     */         {
/*     */ 
/* 187 */           localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
/* 188 */           ((SQLException)localObject3).fillInStackTrace();
/* 189 */           throw ((Throwable)localObject3);
/*     */         }
/*     */         
/* 192 */         localObject1 = DriverManager.getConnection(str1, (String)localObject2, str2);
/*     */       }
/*     */     }
/* 195 */     return (Connection)localObject1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setParams(Object[] paramArrayOfObject, PreparedStatement paramPreparedStatement)
/*     */     throws SQLException
/*     */   {
/* 208 */     for (int i = 0; i < paramArrayOfObject.length; i++)
/*     */     {
/* 210 */       int j = 0;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 215 */       if ((paramArrayOfObject[i] instanceof byte[]))
/*     */       {
/* 217 */         paramPreparedStatement.setObject(i + 1, paramArrayOfObject[i]);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */         try
/*     */         {
/*     */ 
/* 227 */           j = Array.getLength(paramArrayOfObject[i]);
/*     */         }
/*     */         catch (IllegalArgumentException localIllegalArgumentException)
/*     */         {
/* 231 */           paramPreparedStatement.setObject(i + 1, paramArrayOfObject[i]);
/* 232 */           continue;
/*     */         }
/*     */         
/* 235 */         Object[] arrayOfObject = (Object[])paramArrayOfObject[i];
/*     */         
/*     */         SQLException localSQLException;
/*     */         
/* 239 */         if (j == 2)
/*     */         {
/* 241 */           if (arrayOfObject[0] == null) {
/* 242 */             paramPreparedStatement.setNull(i + 1, ((Integer)arrayOfObject[1]).intValue());
/*     */           }
/* 244 */           else if ((arrayOfObject[0] instanceof Date))
/*     */           {
/* 246 */             if ((arrayOfObject[1] instanceof Calendar))
/*     */             {
/* 248 */               paramPreparedStatement.setDate(i + 1, (Date)arrayOfObject[0], (Calendar)arrayOfObject[1]);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 254 */               localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 255 */               localSQLException.fillInStackTrace();
/* 256 */               throw localSQLException;
/*     */             }
/*     */             
/*     */           }
/* 260 */           else if ((arrayOfObject[0] instanceof Time))
/*     */           {
/* 262 */             if ((arrayOfObject[1] instanceof Calendar))
/*     */             {
/* 264 */               paramPreparedStatement.setTime(i + 1, (Time)arrayOfObject[0], (Calendar)arrayOfObject[1]);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 270 */               localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 271 */               localSQLException.fillInStackTrace();
/* 272 */               throw localSQLException;
/*     */             }
/*     */             
/*     */           }
/* 276 */           else if ((arrayOfObject[0] instanceof Timestamp))
/*     */           {
/* 278 */             if ((arrayOfObject[1] instanceof Calendar))
/*     */             {
/* 280 */               paramPreparedStatement.setTimestamp(i + 1, (Timestamp)arrayOfObject[0], (Calendar)arrayOfObject[1]);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 286 */               localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 287 */               localSQLException.fillInStackTrace();
/* 288 */               throw localSQLException;
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/* 297 */           else if ((arrayOfObject[1] instanceof Integer)) {
/* 298 */             paramPreparedStatement.setObject(i + 1, arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 303 */         else if (j == 3)
/*     */         {
/* 305 */           if (arrayOfObject[0] == null)
/*     */           {
/* 307 */             paramPreparedStatement.setNull(i + 1, ((Integer)arrayOfObject[1]).intValue(), (String)arrayOfObject[2]);
/*     */ 
/*     */ 
/*     */           }
/* 311 */           else if ((arrayOfObject[0] instanceof Reader))
/*     */           {
/* 313 */             switch (((Integer)arrayOfObject[2]).intValue())
/*     */             {
/*     */             case 4: 
/* 316 */               paramPreparedStatement.setCharacterStream(i + 1, (Reader)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */               
/*     */ 
/* 319 */               break;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             default: 
/* 327 */               localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 328 */               localSQLException.fillInStackTrace();
/* 329 */               throw localSQLException;
/*     */             }
/*     */             
/*     */           }
/* 333 */           else if ((arrayOfObject[0] instanceof InputStream)) {
/* 334 */             switch (((Integer)arrayOfObject[2]).intValue())
/*     */             {
/*     */             case 1: 
/* 337 */               paramPreparedStatement.setUnicodeStream(i + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */               
/*     */ 
/* 340 */               break;
/*     */             
/*     */             case 2: 
/* 343 */               paramPreparedStatement.setBinaryStream(i + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */               
/*     */ 
/* 346 */               break;
/*     */             
/*     */             case 3: 
/* 349 */               paramPreparedStatement.setAsciiStream(i + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */               
/*     */ 
/* 352 */               break;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             default: 
/* 360 */               localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 361 */               localSQLException.fillInStackTrace();
/* 362 */               throw localSQLException;
/*     */             }
/*     */           }
/* 365 */           else if (((arrayOfObject[1] instanceof Integer)) && ((arrayOfObject[2] instanceof Integer)))
/*     */           {
/*     */ 
/* 368 */             paramPreparedStatement.setObject(i + 1, arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue(), ((Integer)arrayOfObject[2]).intValue());
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 374 */             localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 375 */             localSQLException.fillInStackTrace();
/* 376 */             throw localSQLException;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void readData(RowSetInternal paramRowSetInternal)
/*     */     throws SQLException
/*     */   {
/* 392 */     OracleCachedRowSet localOracleCachedRowSet = (OracleCachedRowSet)paramRowSetInternal;
/*     */     
/* 394 */     Connection localConnection = getConnection(paramRowSetInternal);
/*     */     
/*     */ 
/*     */ 
/* 398 */     if ((localConnection == null) || (localOracleCachedRowSet.getCommand() == null))
/*     */     {
/* 400 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 342);
/* 401 */       localSQLException1.fillInStackTrace();
/* 402 */       throw localSQLException1;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 407 */       localConnection.setTransactionIsolation(localOracleCachedRowSet.getTransactionIsolation());
/*     */     }
/*     */     catch (Exception localException1) {}
/*     */     
/*     */ 
/* 412 */     PreparedStatement localPreparedStatement = localConnection.prepareStatement(localOracleCachedRowSet.getCommand(), localOracleCachedRowSet.getType(), localOracleCachedRowSet.getConcurrency());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 417 */     setParams(paramRowSetInternal.getParams(), localPreparedStatement);
/*     */     try
/*     */     {
/* 420 */       localPreparedStatement.setMaxRows(localOracleCachedRowSet.getMaxRows());
/* 421 */       localPreparedStatement.setMaxFieldSize(localOracleCachedRowSet.getMaxFieldSize());
/* 422 */       localPreparedStatement.setEscapeProcessing(localOracleCachedRowSet.getEscapeProcessing());
/* 423 */       localPreparedStatement.setQueryTimeout(localOracleCachedRowSet.getQueryTimeout());
/*     */     }
/*     */     catch (Exception localException2) {}
/* 426 */     ResultSet localResultSet = localPreparedStatement.executeQuery();
/* 427 */     localOracleCachedRowSet.populate(localResultSet, localOracleCachedRowSet.getCurrentPage() * localOracleCachedRowSet.getPageSize());
/* 428 */     localResultSet.close();
/* 429 */     localPreparedStatement.close();
/*     */     try
/*     */     {
/* 432 */       localConnection.commit();
/*     */     }
/*     */     catch (SQLException localSQLException2) {}
/*     */     
/*     */ 
/* 437 */     if (!localOracleCachedRowSet.isConnectionStayingOpen())
/*     */     {
/* 439 */       localConnection.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleConnection getConnectionDuringExceptionHandling()
/*     */   {
/* 456 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 461 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/rowset/OracleCachedRowSetReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */