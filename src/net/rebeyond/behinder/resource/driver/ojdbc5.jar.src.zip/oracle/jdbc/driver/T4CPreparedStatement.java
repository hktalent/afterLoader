/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*      */   T4CPreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*   30 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/*      */ 
/*   33 */     this.nbPostPonedColumns = new int[1];
/*   34 */     this.nbPostPonedColumns[0] = 0;
/*   35 */     this.indexOfPostPonedColumn = new int[1][3];
/*   36 */     this.t4Connection = ((T4CConnection)paramPhysicalConnection);
/*      */     
/*   38 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   39 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   40 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   41 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   48 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CConnection t4Connection;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
/*      */     throws SQLException, IOException
/*      */   {
/*   68 */     if ((paramBoolean1) || (paramBoolean4) || (!paramBoolean2)) {
/*   69 */       this.oacdefSent = null;
/*      */     }
/*   71 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.doOall8");
/*      */     
/*   73 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED)
/*      */     {
/*      */ 
/*      */ 
/*   77 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   78 */       localSQLException1.fillInStackTrace();
/*   79 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*   83 */     if (paramBoolean3) {
/*   84 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   86 */     int i = this.numberOfDefinePositions;
/*      */     
/*   88 */     if (this.sqlKind.isDML()) {
/*   89 */       i = 0;
/*      */     }
/*      */     int j;
/*   92 */     if (this.accessors != null)
/*   93 */       for (j = 0; j < this.accessors.length; j++)
/*   94 */         if (this.accessors[j] != null)
/*   95 */           this.accessors[j].lastRowProcessed = 0;
/*   96 */     if (this.outBindAccessors != null)
/*   97 */       for (j = 0; j < this.outBindAccessors.length; j++)
/*   98 */         if (this.outBindAccessors[j] != null)
/*   99 */           this.outBindAccessors[j].lastRowProcessed = 0;
/*  100 */     if (this.returnParamAccessors != null) {
/*  101 */       for (j = 0; j < this.returnParamAccessors.length; j++) {
/*  102 */         if (this.returnParamAccessors[j] != null) {
/*  103 */           this.returnParamAccessors[j].lastRowProcessed = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     int i1;
/*      */     int i2;
/*  110 */     if (this.bindIndicators != null)
/*      */     {
/*  112 */       j = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */       
/*      */ 
/*  115 */       int k = 0;
/*      */       
/*  117 */       if (this.ibtBindChars != null) {
/*  118 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  120 */       for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */       {
/*  122 */         int n = this.bindIndicatorSubRange + 5 + 10 * m;
/*      */         
/*      */ 
/*      */ 
/*  126 */         i1 = this.bindIndicators[(n + 2)] & 0xFFFF;
/*      */         
/*      */ 
/*      */ 
/*  130 */         if (i1 != 0)
/*      */         {
/*      */ 
/*  133 */           i2 = this.bindIndicators[(n + 9)] & 0xFFFF;
/*      */           
/*      */ 
/*      */ 
/*  137 */           if (i2 == 2)
/*      */           {
/*  139 */             k = Math.max(i1 * this.connection.conversion.maxNCharSize, k);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  144 */             k = Math.max(i1 * this.connection.conversion.cMaxCharSize, k);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  150 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  152 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  154 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  156 */         this.tmpBindsByteArray = null;
/*  157 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  169 */       this.tmpBindsByteArray = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  174 */     int[] arrayOfInt1 = this.definedColumnType;
/*  175 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  176 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  182 */     if ((paramBoolean5) && (paramBoolean4) && (this.sqlObject.includeRowid))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  187 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  188 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  189 */       arrayOfInt1[0] = -8;
/*  190 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  191 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  192 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  193 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  199 */     allocateTmpByteArray();
/*      */     
/*  201 */     T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */     
/*  203 */     this.t4Connection.sendPiggyBackedMessages();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  208 */       localT4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  220 */       i1 = localT4C8Oall.getCursorId();
/*  221 */       if (i1 != 0) {
/*  222 */         this.cursorId = i1;
/*      */       }
/*  224 */       this.oacdefSent = localT4C8Oall.oacdefBindsSent;
/*      */     }
/*      */     catch (SQLException localSQLException2)
/*      */     {
/*  228 */       i2 = localT4C8Oall.getCursorId();
/*  229 */       if (i2 != 0) {
/*  230 */         this.cursorId = i2;
/*      */       }
/*  232 */       if (localSQLException2.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/*  235 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  240 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray()
/*      */   {
/*  250 */     if (this.tmpByteArray == null)
/*      */     {
/*      */ 
/*  253 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  255 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length)
/*      */     {
/*      */ 
/*      */ 
/*  259 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/*  271 */     super.releaseBuffers();
/*  272 */     this.tmpByteArray = null;
/*  273 */     this.tmpBindsByteArray = null;
/*      */     
/*  275 */     this.t4Connection.all8.bindChars = null;
/*  276 */     this.t4Connection.all8.bindBytes = null;
/*  277 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */   
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/*  284 */     this.accessors[0] = new T4CRowidAccessor(this, 128, 1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {
/*  297 */     this.needToParse = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/*  308 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*  319 */     if (paramInt1 < 1)
/*      */     {
/*  321 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  322 */       localSQLException.fillInStackTrace();
/*  323 */       throw localSQLException;
/*      */     }
/*  325 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*  329 */       if ((paramInt2 == 1) || (paramInt2 == 12))
/*      */       {
/*      */ 
/*      */ 
/*  333 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*  339 */     else if (paramInt3 < 0)
/*      */     {
/*  341 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  342 */       localSQLException.fillInStackTrace();
/*  343 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  347 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed))
/*      */     {
/*  349 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  350 */       localSQLException.fillInStackTrace();
/*  351 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  358 */     int i = paramInt1 - 1;
/*      */     int[] arrayOfInt;
/*  360 */     if ((this.definedColumnType == null) || (this.definedColumnType.length <= i))
/*      */     {
/*  362 */       if (this.definedColumnType == null)
/*      */       {
/*  364 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  376 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  378 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */         
/*      */ 
/*  381 */         this.definedColumnType = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  387 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  389 */     if ((this.definedColumnSize == null) || (this.definedColumnSize.length <= i))
/*      */     {
/*  391 */       if (this.definedColumnSize == null) {
/*  392 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  395 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  397 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */         
/*      */ 
/*  400 */         this.definedColumnSize = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  404 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  406 */     if ((this.definedColumnFormOfUse == null) || (this.definedColumnFormOfUse.length <= i))
/*      */     {
/*  408 */       if (this.definedColumnFormOfUse == null) {
/*  409 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  412 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  414 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */         
/*      */ 
/*  417 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  421 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  423 */     if ((this.accessors != null) && (i < this.accessors.length) && (this.accessors[i] != null))
/*      */     {
/*  425 */       this.accessors[i].definedColumnSize = paramInt3;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  430 */       if (((this.accessors[i].internalType == 96) || (this.accessors[i].internalType == 1)) && ((paramInt2 == 1) || (paramInt2 == 12)))
/*      */       {
/*      */ 
/*      */ 
/*  434 */         if (paramInt3 <= this.accessors[i].oacmxl)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  440 */           this.needToPrepareDefineBuffer = true;
/*  441 */           this.columnsDefinedByUser = true;
/*      */           
/*  443 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  444 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearDefines()
/*      */     throws SQLException
/*      */   {
/*  453 */     synchronized (this.connection)
/*      */     {
/*  455 */       super.clearDefines();
/*  456 */       this.definedColumnType = null;
/*  457 */       this.definedColumnSize = null;
/*  458 */       this.definedColumnFormOfUse = null;
/*  459 */       this.t4Connection.all8.definesAccessors = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  477 */     int i = this.rowPrefetchInLastFetch < this.rowPrefetch ? 1 : 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  506 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  515 */       paramArrayOfShort = new short[this.defineIndicators.length];
/*  516 */       j = this.accessors[0].lengthIndexLastRow;
/*  517 */       int k = this.accessors[0].indicatorIndexLastRow;
/*      */       
/*  519 */       int i1 = i != 0 ? this.accessors.length : 1;
/*  520 */       for (; i != 0 ? i1 >= 1 : i1 <= this.accessors.length; 
/*  521 */           i1 += (i != 0 ? -1 : 1))
/*      */       {
/*  523 */         int m = j + this.rowPrefetchInLastFetch * i1 - 1;
/*  524 */         int n = k + this.rowPrefetchInLastFetch * i1 - 1;
/*  525 */         paramArrayOfShort[n] = this.defineIndicators[n];
/*  526 */         paramArrayOfShort[m] = this.defineIndicators[m];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  533 */     int j = i != 0 ? this.accessors.length - 1 : 0;
/*  534 */     for (; i != 0 ? j > -1 : j < this.accessors.length; 
/*  535 */         j += (i != 0 ? -1 : 1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  542 */       this.accessors[j].saveDataFromOldDefineBuffers(paramArrayOfByte, paramArrayOfChar, paramArrayOfShort, this.rowPrefetchInLastFetch != -1 ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  549 */     super.saveDefineBuffersIfRequired(paramArrayOfChar, paramArrayOfByte, paramArrayOfShort, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doSetSnapshotSCN(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  559 */     this.inScn = paramLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  579 */     Object localObject = null;
/*      */     SQLException localSQLException;
/*  581 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/*  585 */       localObject = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  588 */       break;
/*      */     
/*      */     case 8: 
/*  591 */       if (!paramBoolean)
/*      */       {
/*  593 */         localObject = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  596 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/*  601 */       localObject = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  604 */       break;
/*      */     
/*      */     case 2: 
/*  607 */       localObject = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  610 */       break;
/*      */     
/*      */     case 6: 
/*  613 */       localObject = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  616 */       break;
/*      */     
/*      */     case 24: 
/*  619 */       if (!paramBoolean)
/*      */       {
/*  621 */         localObject = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  624 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/*  629 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/*  631 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  632 */         localSQLException.fillInStackTrace();
/*  633 */         throw localSQLException;
/*      */       }
/*      */       
/*  636 */       if (paramBoolean) {
/*  637 */         localObject = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       else {
/*  640 */         localObject = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*  643 */       break;
/*      */     
/*      */     case 100: 
/*  646 */       localObject = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  649 */       break;
/*      */     
/*      */     case 101: 
/*  652 */       localObject = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  655 */       break;
/*      */     
/*      */     case 104: 
/*  658 */       if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  664 */         localObject = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         
/*      */ 
/*      */ 
/*  668 */         ((Accessor)localObject).definedColumnType = -8;
/*      */       }
/*      */       else {
/*  671 */         localObject = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*      */ 
/*  675 */       break;
/*      */     
/*      */     case 102: 
/*  678 */       localObject = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  681 */       break;
/*      */     
/*      */     case 12: 
/*  684 */       localObject = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  687 */       break;
/*      */     
/*      */     case 113: 
/*  690 */       localObject = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  693 */       break;
/*      */     
/*      */     case 112: 
/*  696 */       localObject = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  699 */       break;
/*      */     
/*      */     case 114: 
/*  702 */       localObject = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  705 */       break;
/*      */     
/*      */     case 109: 
/*  708 */       localObject = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  711 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  713 */       break;
/*      */     
/*      */     case 111: 
/*  716 */       localObject = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  719 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  721 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 180: 
/*  726 */       localObject = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  729 */       break;
/*      */     
/*      */     case 181: 
/*  732 */       localObject = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  735 */       break;
/*      */     
/*      */     case 231: 
/*  738 */       localObject = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  741 */       break;
/*      */     
/*      */     case 182: 
/*  744 */       localObject = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  747 */       break;
/*      */     
/*      */     case 183: 
/*  750 */       localObject = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  753 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/*  766 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  767 */       localSQLException.fillInStackTrace();
/*  768 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*  772 */     return (Accessor)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doDescribe(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  799 */     if (!this.isOpen)
/*      */     {
/*      */ 
/*  802 */       this.connection.open(this);
/*  803 */       this.isOpen = true;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  809 */       this.t4Connection.needLine();
/*  810 */       this.t4Connection.sendPiggyBackedMessages();
/*  811 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  812 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  814 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  816 */       for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  817 */         this.accessors[i].initMetadata();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {
/*  821 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*      */ 
/*  824 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  825 */       localSQLException.fillInStackTrace();
/*  826 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  830 */     this.describedWithNames = true;
/*  831 */     this.described = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForDescribe()
/*      */     throws SQLException
/*      */   {
/*  866 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.execute_for_describe");
/*      */     try
/*      */     {
/*  869 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  875 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  879 */         doOall8(true, true, false, true, this.definedColumnType != null);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/*  885 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  889 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*  891 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  892 */       localSQLException2.fillInStackTrace();
/*  893 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  898 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  899 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     
/*  902 */     this.needToParse = false;
/*      */     
/*      */ 
/*  905 */     if (this.connection.calculateChecksum) {
/*  906 */       if (this.validRows > 0) {
/*  907 */         calculateCheckSum();
/*  908 */       } else if (this.rowsProcessed > 0) {
/*  909 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  911 */         this.checkSum = l;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  921 */     if (this.definedColumnType == null) {
/*  922 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  924 */     this.aFetchWasDoneDuringDescribe = false;
/*  925 */     if (this.t4Connection.all8.aFetchWasDone)
/*      */     {
/*  927 */       this.aFetchWasDoneDuringDescribe = true;
/*  928 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*      */     
/*      */ 
/*  932 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  933 */       this.accessors[i].initMetadata();
/*      */     }
/*  935 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForRows(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  977 */         boolean bool = false;
/*  978 */         if (this.columnsDefinedByUser) {
/*  979 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  999 */         else if ((this.t4Connection.useLobPrefetch) && (this.accessors != null) && (this.defaultLobPrefetchSize != -1) && (!this.implicitDefineForLobPrefetchDone) && (!this.aFetchWasDoneDuringDescribe) && (this.definedColumnType == null))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1007 */           int i = 0;
/* 1008 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1009 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1011 */           for (int j = 0; j < this.accessors.length; j++)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1016 */             arrayOfInt1[j] = getJDBCType(this.accessors[j].internalType);
/* 1017 */             if ((this.accessors[j].internalType == 113) || (this.accessors[j].internalType == 112) || (this.accessors[j].internalType == 114))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1023 */               i = 1;
/* 1024 */               this.accessors[j].lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1025 */               arrayOfInt2[j] = this.defaultLobPrefetchSize;
/*      */             }
/*      */           }
/*      */           
/* 1029 */           if (i != 0)
/*      */           {
/* 1031 */             this.definedColumnType = arrayOfInt1;
/* 1032 */             this.definedColumnSize = arrayOfInt2;
/* 1033 */             bool = true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1039 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1041 */         this.needToParse = false;
/* 1042 */         if (bool) {
/* 1043 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       }
/*      */       finally {
/* 1047 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1052 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1056 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/* 1057 */       calculateCheckSum();
/*      */       
/* 1059 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1060 */       localSQLException2.fillInStackTrace();
/* 1061 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetch()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1088 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1092 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1096 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException1)
/*      */         {
/* 1100 */           ((T4CConnection)this.connection).handleIOException(localIOException1);
/*      */           
/* 1102 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/* 1103 */           localSQLException.fillInStackTrace();
/* 1104 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1108 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1114 */       doOall8(false, false, true, false, false);
/*      */       
/* 1116 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/* 1120 */       ((T4CConnection)this.connection).handleIOException(localIOException2);
/*      */       
/* 1122 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/* 1123 */       localSQLException.fillInStackTrace();
/* 1124 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1130 */     calculateCheckSum();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1145 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1147 */         T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */         
/* 1149 */         localT4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1154 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1156 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1157 */       localSQLException2.fillInStackTrace();
/* 1158 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1163 */       if (localSQLException1.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/* 1166 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1171 */         throw localSQLException1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doClose()
/*      */     throws SQLException
/*      */   {
/* 1195 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.do_close");
/*      */     
/* 1197 */     if (this.cursorId != 0) {
/* 1198 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1201 */     this.tmpByteArray = null;
/* 1202 */     this.tmpBindsByteArray = null;
/* 1203 */     this.definedColumnType = null;
/* 1204 */     this.definedColumnSize = null;
/* 1205 */     this.definedColumnFormOfUse = null;
/* 1206 */     this.oacdefSent = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeQuery()
/*      */     throws SQLException
/*      */   {
/* 1226 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.closeQuery");
/*      */     
/* 1228 */     if (this.streamList != null)
/*      */     {
/* 1230 */       while (this.nextStream != null) {
/*      */         try {
/* 1232 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException) {
/* 1235 */           ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */           
/* 1237 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1238 */           localSQLException.fillInStackTrace();
/* 1239 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1243 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Binder getRowidNullBinder(int paramInt)
/*      */   {
/* 1256 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */     {
/*      */ 
/* 1259 */       this.currentRowCharLens[paramInt] = 1;
/* 1260 */       return this.theVarcharNullBinder;
/*      */     }
/*      */     
/* 1263 */     return this.theRowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doLocalInitialization()
/*      */   {
/* 1272 */     super.doLocalInitialization();
/*      */     
/* 1274 */     this.t4Connection.all8.bindChars = this.bindChars;
/* 1275 */     this.t4Connection.all8.bindBytes = this.bindBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1281 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/T4CPreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */