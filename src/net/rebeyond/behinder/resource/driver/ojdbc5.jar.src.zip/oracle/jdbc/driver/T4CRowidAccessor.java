/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CRowidAccessor
/*      */   extends RowidAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   static final int maxLength = 128;
/*      */   
/*      */   T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine)
/*      */     throws SQLException
/*      */   {
/*   40 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */     
/*   42 */     this.mare = paramT4CMAREngine;
/*   43 */     this.defineType = 104;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine)
/*      */     throws SQLException
/*      */   {
/*   53 */     super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*      */     
/*      */ 
/*   56 */     this.mare = paramT4CMAREngine;
/*   57 */     this.definedColumnType = paramInt7;
/*   58 */     this.definedColumnSize = paramInt8;
/*   59 */     this.defineType = 104;
/*      */   }
/*      */   
/*      */ 
/*      */   void processIndicator(int paramInt)
/*      */     throws IOException, SQLException
/*      */   {
/*   66 */     if (((this.internalType == 1) && (this.describeType == 112)) || ((this.internalType == 23) && (this.describeType == 113)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   73 */       this.mare.unmarshalUB2();
/*   74 */       this.mare.unmarshalUB2();
/*      */     }
/*   76 */     else if (this.statement.connection.versionNumber < 9200)
/*      */     {
/*      */ 
/*      */ 
/*   80 */       this.mare.unmarshalSB2();
/*      */       
/*   82 */       if (!this.statement.sqlKind.isPlsqlOrCall()) {
/*   83 */         this.mare.unmarshalSB2();
/*      */       }
/*   85 */     } else if ((this.statement.sqlKind.isPlsqlOrCall()) || (this.isDMLReturnedParam))
/*      */     {
/*   87 */       this.mare.processIndicator(paramInt <= 0, paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   95 */   final int[] meta = new int[1];
/*      */   static final int KGRD_EXTENDED_OBJECT = 6;
/*      */   static final int KGRD_EXTENDED_BLOCK = 6;
/*      */   static final int KGRD_EXTENDED_FILE = 3;
/*      */   static final int KGRD_EXTENDED_SLOT = 3;
/*      */   static final int kd4_ubridtype_physical = 1;
/*      */   static final int kd4_ubridtype_logical = 2;
/*      */   static final int kd4_ubridtype_remote = 3;
/*      */   static final int kd4_ubridtype_exttab = 4;
/*      */   static final int kd4_ubridtype_future2 = 5;
/*      */   static final int kd4_ubridtype_max = 5;
/*      */   static final int kd4_ubridlen_typeind = 1;
/*      */   
/*      */   boolean unmarshalOneRow() throws SQLException, IOException
/*      */   {
/*  110 */     if (this.isUseLess)
/*      */     {
/*  112 */       this.lastRowProcessed += 1;
/*      */       
/*  114 */       return false;
/*      */     }
/*      */     
/*      */     int m;
/*      */     int i2;
/*  119 */     if (this.rowSpaceIndicator == null)
/*      */     {
/*  121 */       i = this.mare.unmarshalUB1();
/*  122 */       long l1 = 0L;
/*  123 */       m = 0;
/*  124 */       int n = 0;
/*  125 */       long l3 = 0L;
/*  126 */       i2 = 0;
/*      */       
/*      */ 
/*      */ 
/*  130 */       if (i > 0)
/*      */       {
/*  132 */         l1 = this.mare.unmarshalUB4();
/*  133 */         m = this.mare.unmarshalUB2();
/*  134 */         n = this.mare.unmarshalUB1();
/*  135 */         l3 = this.mare.unmarshalUB4();
/*  136 */         i2 = this.mare.unmarshalUB2();
/*      */       }
/*      */       
/*  139 */       processIndicator(this.meta[0]);
/*      */       
/*  141 */       this.lastRowProcessed += 1;
/*      */       
/*  143 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  147 */     int i = this.indicatorIndex + this.lastRowProcessed;
/*  148 */     int j = this.lengthIndex + this.lastRowProcessed;
/*      */     
/*  150 */     if (this.isNullByDescribe)
/*      */     {
/*  152 */       this.rowSpaceIndicator[i] = -1;
/*  153 */       this.rowSpaceIndicator[j] = 0;
/*  154 */       this.lastRowProcessed += 1;
/*      */       
/*  156 */       if (this.statement.connection.versionNumber < 9200) {
/*  157 */         processIndicator(0);
/*      */       }
/*  159 */       return false;
/*      */     }
/*      */     
/*  162 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  167 */     if (this.describeType != 208)
/*      */     {
/*  169 */       m = this.mare.unmarshalUB1();
/*  170 */       long l2 = 0L;
/*  171 */       int i1 = 0;
/*  172 */       i2 = 0;
/*  173 */       long l4 = 0L;
/*  174 */       int i3 = 0;
/*      */       
/*      */ 
/*      */ 
/*  178 */       if (m > 0)
/*      */       {
/*  180 */         l2 = this.mare.unmarshalUB4();
/*  181 */         i1 = this.mare.unmarshalUB2();
/*  182 */         i2 = this.mare.unmarshalUB1();
/*  183 */         l4 = this.mare.unmarshalUB4();
/*  184 */         i3 = this.mare.unmarshalUB2();
/*      */       }
/*      */       
/*      */ 
/*  188 */       if ((l2 == 0L) && (i1 == 0) && (i2 == 0) && (l4 == 0L) && (i3 == 0))
/*      */       {
/*  190 */         this.meta[0] = 0;
/*      */       }
/*      */       else {
/*  193 */         long[] arrayOfLong = { l2, i1, l4, i3 };
/*      */         
/*      */ 
/*      */ 
/*  197 */         byte[] arrayOfByte2 = rowidToString(arrayOfLong);
/*  198 */         int i4 = 18;
/*      */         
/*  200 */         if (this.byteLength - 2 < 18) {
/*  201 */           i4 = this.byteLength - 2;
/*      */         }
/*  203 */         System.arraycopy(arrayOfByte2, 0, this.rowSpaceByte, k + 2, i4);
/*      */         
/*      */ 
/*  206 */         this.meta[0] = i4;
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*  211 */     else if ((this.meta[0] = (int)this.mare.unmarshalUB4()) > 0)
/*      */     {
/*  213 */       byte[] arrayOfByte1 = new byte[this.meta[0]];
/*  214 */       this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/*  215 */       this.meta[0] = kgrdub2c(arrayOfByte1, this.meta[0], 0, this.rowSpaceByte, k + 2);
/*      */     }
/*      */     
/*      */ 
/*  219 */     this.rowSpaceByte[k] = ((byte)((this.meta[0] & 0xFF00) >> 8));
/*  220 */     this.rowSpaceByte[(k + 1)] = ((byte)(this.meta[0] & 0xFF));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */     processIndicator(this.meta[0]);
/*      */     
/*  230 */     if (this.meta[0] == 0)
/*      */     {
/*      */ 
/*      */ 
/*  234 */       this.rowSpaceIndicator[i] = -1;
/*  235 */       this.rowSpaceIndicator[j] = 0;
/*      */     }
/*      */     else
/*      */     {
/*  239 */       this.rowSpaceIndicator[j] = ((short)this.meta[0]);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  244 */       this.rowSpaceIndicator[i] = 0;
/*      */     }
/*      */     
/*  247 */     this.lastRowProcessed += 1;
/*      */     
/*  249 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  260 */     String str = null;
/*      */     
/*  262 */     if (this.rowSpaceIndicator == null)
/*      */     {
/*  264 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  265 */       localSQLException.fillInStackTrace();
/*  266 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  271 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*  273 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */       
/*      */ 
/*      */ 
/*  277 */       int j = this.rowSpaceIndicator[(this.lengthIndex + paramInt)];
/*      */       
/*  279 */       if ((this.describeType != 208) || (this.rowSpaceByte[i] == 1))
/*      */       {
/*      */ 
/*  282 */         str = new String(this.rowSpaceByte, i + 2, j);
/*      */         
/*  284 */         long[] arrayOfLong = stringToRowid(str.getBytes(), 0, str.length());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  290 */         str = new String(rowidToString(arrayOfLong));
/*      */       }
/*      */       else
/*      */       {
/*  294 */         str = new String(this.rowSpaceByte, i + 2, j);
/*      */       }
/*      */     }
/*      */     
/*  298 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  306 */     if (this.definedColumnType == 0) {
/*  307 */       return super.getObject(paramInt);
/*      */     }
/*      */     
/*  310 */     Object localObject = null;
/*      */     SQLException localSQLException;
/*  312 */     if (this.rowSpaceIndicator == null)
/*      */     {
/*  314 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  315 */       localSQLException.fillInStackTrace();
/*  316 */       throw localSQLException;
/*      */     }
/*      */     
/*  319 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*  321 */       switch (this.definedColumnType)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/*  332 */         return getString(paramInt);
/*      */       
/*      */       case -8: 
/*  335 */         return getROWID(paramInt);
/*      */       }
/*      */       
/*      */       
/*  339 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  340 */       localSQLException.fillInStackTrace();
/*  341 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  346 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void copyRow()
/*      */     throws SQLException, IOException
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/*      */ 
/*  359 */     if (this.lastRowProcessed == 0) {
/*  360 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*      */     } else {
/*  362 */       i = this.lastRowProcessed - 1;
/*      */     }
/*      */     
/*  365 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*  366 */     int k = this.columnIndex + i * this.byteLength;
/*  367 */     int m = this.indicatorIndex + this.lastRowProcessed;
/*  368 */     int n = this.indicatorIndex + i;
/*  369 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/*  370 */     int i2 = this.lengthIndex + i;
/*  371 */     int i3 = this.rowSpaceIndicator[i2];
/*  372 */     int i4 = this.metaDataIndex + this.lastRowProcessed * 1;
/*      */     
/*  374 */     int i5 = this.metaDataIndex + i * 1;
/*      */     
/*      */ 
/*      */ 
/*  378 */     this.rowSpaceIndicator[i1] = ((short)i3);
/*  379 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*      */     
/*      */ 
/*      */ 
/*  383 */     System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, i3 + 2);
/*      */     
/*      */ 
/*      */ 
/*  387 */     System.arraycopy(this.rowSpaceMetaData, i5, this.rowSpaceMetaData, i4, 1);
/*      */     
/*      */ 
/*      */ 
/*  391 */     this.lastRowProcessed += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfByte, char[] paramArrayOfChar, short[] paramArrayOfShort, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  404 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*      */     
/*  406 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*      */     
/*  408 */     int k = this.indicatorIndex + paramInt2 - 1;
/*  409 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/*  410 */     int n = this.lengthIndex + paramInt2 - 1;
/*  411 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/*  412 */     int i2 = paramArrayOfShort[i1];
/*      */     
/*  414 */     this.rowSpaceIndicator[n] = ((short)i2);
/*  415 */     this.rowSpaceIndicator[k] = paramArrayOfShort[m];
/*      */     
/*      */ 
/*  418 */     if (i2 != 0)
/*      */     {
/*  420 */       System.arraycopy(paramArrayOfByte, j, this.rowSpaceByte, i, i2 + 2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte[] rowidToString(long[] paramArrayOfLong)
/*      */   {
/*  434 */     long l1 = paramArrayOfLong[0];
/*      */     
/*      */ 
/*  437 */     long l2 = paramArrayOfLong[1];
/*      */     
/*      */ 
/*  440 */     long l3 = paramArrayOfLong[2];
/*      */     
/*      */ 
/*  443 */     long l4 = paramArrayOfLong[3];
/*      */     
/*  445 */     int i = 18;
/*      */     
/*      */ 
/*      */ 
/*  449 */     byte[] arrayOfByte = new byte[i];
/*  450 */     int j = 0;
/*      */     
/*  452 */     j = kgrd42b(arrayOfByte, l1, 6, j);
/*      */     
/*      */ 
/*  455 */     j = kgrd42b(arrayOfByte, l2, 3, j);
/*      */     
/*      */ 
/*  458 */     j = kgrd42b(arrayOfByte, l3, 6, j);
/*      */     
/*      */ 
/*  461 */     j = kgrd42b(arrayOfByte, l4, 3, j);
/*      */     
/*      */ 
/*      */ 
/*  465 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final long[] rcToRowid(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  481 */     int i = 18;
/*      */     
/*  483 */     if (paramInt2 != i)
/*      */     {
/*  485 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  488 */     long[] arrayOfLong = new long[3];
/*  489 */     String str = new String(paramArrayOfByte, paramInt1, paramInt2);
/*      */     
/*      */ 
/*  492 */     long l1 = Long.parseLong(str.substring(0, 8), 16);
/*  493 */     long l2 = Long.parseLong(str.substring(9, 13), 16);
/*  494 */     long l3 = Long.parseLong(str.substring(14, 8), 16);
/*      */     
/*  496 */     arrayOfLong[0] = l3;
/*  497 */     arrayOfLong[1] = l1;
/*  498 */     arrayOfLong[2] = l2;
/*      */     
/*  500 */     return arrayOfLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final void kgrdr2rc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfByte, int paramInt6)
/*      */     throws SQLException
/*      */   {
/*  520 */     paramInt6 = lmx42h(paramArrayOfByte, paramInt4, 8, paramInt6);
/*  521 */     paramArrayOfByte[(paramInt6++)] = 46;
/*      */     
/*  523 */     paramInt6 = lmx42h(paramArrayOfByte, paramInt5, 4, paramInt6);
/*  524 */     paramArrayOfByte[(paramInt6++)] = 46;
/*      */     
/*  526 */     paramInt6 = lmx42h(paramArrayOfByte, paramInt2, 4, paramInt6);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int lmx42h(byte[] paramArrayOfByte, long paramLong, int paramInt1, int paramInt2)
/*      */   {
/*  541 */     String str = Long.toHexString(paramLong).toUpperCase();
/*      */     
/*      */ 
/*  544 */     int i = paramInt1;
/*  545 */     int j = 0;
/*      */     
/*      */     do
/*      */     {
/*  549 */       if (j < str.length())
/*      */       {
/*  551 */         paramArrayOfByte[(paramInt2 + paramInt1 - 1)] = ((byte)str.charAt(str.length() - j - 1));
/*      */         
/*  553 */         j++;
/*      */       }
/*      */       else
/*      */       {
/*  557 */         paramArrayOfByte[(paramInt2 + paramInt1 - 1)] = 48;
/*      */       }
/*      */       
/*  560 */       paramInt1--; } while (paramInt1 > 0);
/*      */     
/*  562 */     return i + paramInt2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int kgrdc2ub(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  579 */     int i = getRowidType(paramArrayOfByte1, paramInt1);
/*  580 */     byte[] arrayOfByte1 = paramArrayOfByte2;
/*  581 */     int j = paramInt3 - 1;
/*  582 */     int k = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  587 */     byte[] arrayOfByte2 = kgrd_index_64;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  594 */     int i2 = 1 + (3 * ((paramInt3 - 1) / 4) + ((paramInt3 - 1) % 4 != 0 ? (paramInt3 - 1) % 4 - 1 : 0));
/*      */     
/*      */ 
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*  600 */     if (j == 0)
/*      */     {
/*      */ 
/*  603 */       localSQLException = DatabaseError.createSqlException(null, 132);
/*  604 */       localSQLException.fillInStackTrace();
/*  605 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  610 */     arrayOfByte1[(paramInt2 + 0)] = i;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  618 */     k = paramInt1 + 1;
/*  619 */     int i1 = 1;
/*      */     
/*  621 */     while (j > 0)
/*      */     {
/*      */ 
/*  624 */       if (j == 1)
/*      */       {
/*      */ 
/*  627 */         localSQLException = DatabaseError.createSqlException(null, 132);
/*  628 */         localSQLException.fillInStackTrace();
/*  629 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  634 */       int m = arrayOfByte2[paramArrayOfByte1[k]];
/*  635 */       if (m == -1)
/*      */       {
/*      */ 
/*  638 */         localSQLException = DatabaseError.createSqlException(null, 132);
/*  639 */         localSQLException.fillInStackTrace();
/*  640 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*  644 */       k++;
/*  645 */       int n = arrayOfByte2[paramArrayOfByte1[k]];
/*  646 */       if (n == -1)
/*      */       {
/*      */ 
/*  649 */         localSQLException = DatabaseError.createSqlException(null, 132);
/*  650 */         localSQLException.fillInStackTrace();
/*  651 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  659 */       arrayOfByte1[(paramInt2 + i1)] = ((byte)((m & 0xFF) << 2 | (n & 0x30) >> 4));
/*      */       
/*      */ 
/*  662 */       if (j == 2) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  669 */       i1++;
/*  670 */       m = n;
/*  671 */       k++;
/*  672 */       n = arrayOfByte2[paramArrayOfByte1[k]];
/*  673 */       if (n == -1)
/*      */       {
/*      */ 
/*  676 */         localSQLException = DatabaseError.createSqlException(null, 132);
/*  677 */         localSQLException.fillInStackTrace();
/*  678 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*  682 */       arrayOfByte1[(paramInt2 + i1)] = ((byte)((m & 0xFF) << 4 | (n & 0x3C) >> 2));
/*      */       
/*      */ 
/*  685 */       if (j == 3) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  690 */       i1++;
/*  691 */       m = n;
/*  692 */       k++;
/*  693 */       n = arrayOfByte2[paramArrayOfByte1[k]];
/*  694 */       if (n == -1)
/*      */       {
/*      */ 
/*  697 */         localSQLException = DatabaseError.createSqlException(null, 132);
/*  698 */         localSQLException.fillInStackTrace();
/*  699 */         throw localSQLException;
/*      */       }
/*      */       
/*  702 */       arrayOfByte1[(paramInt2 + i1)] = ((byte)((m & 0x3) << 6 | n));
/*      */       
/*      */ 
/*      */ 
/*  706 */       j -= 4;
/*  707 */       k++;
/*  708 */       i1++;
/*      */     }
/*      */     
/*  711 */     return i2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final long[] stringToRowid(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  721 */     int i = 18;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  726 */     if (paramInt2 != i)
/*      */     {
/*  728 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  731 */     long[] arrayOfLong = new long[4];
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  737 */       arrayOfLong[0] = kgrdb42(paramArrayOfByte, 6, paramInt1);
/*      */       
/*      */ 
/*  740 */       paramInt1 += 6;
/*      */       
/*      */ 
/*  743 */       arrayOfLong[1] = kgrdb42(paramArrayOfByte, 3, paramInt1);
/*      */       
/*      */ 
/*  746 */       paramInt1 += 3;
/*      */       
/*      */ 
/*  749 */       arrayOfLong[2] = kgrdb42(paramArrayOfByte, 6, paramInt1);
/*      */       
/*      */ 
/*  752 */       paramInt1 += 6;
/*      */       
/*      */ 
/*  755 */       arrayOfLong[3] = kgrdb42(paramArrayOfByte, 3, paramInt1);
/*      */       
/*      */ 
/*  758 */       paramInt1 += 3;
/*      */     }
/*      */     catch (Exception localException)
/*      */     {
/*  762 */       arrayOfLong[0] = 0L;
/*  763 */       arrayOfLong[1] = 0L;
/*  764 */       arrayOfLong[2] = 0L;
/*  765 */       arrayOfLong[3] = 0L;
/*      */     }
/*      */     
/*  768 */     return arrayOfLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int kgrd42b(byte[] paramArrayOfByte, long paramLong, int paramInt1, int paramInt2)
/*      */   {
/*  780 */     int i = paramInt1;
/*  781 */     long l = paramLong;
/*  783 */     for (; 
/*  783 */         paramInt1 > 0; paramInt1--)
/*      */     {
/*  785 */       paramArrayOfByte[(paramInt2 + paramInt1 - 1)] = kgrd_basis_64[((int)l & 0x3F)];
/*  786 */       l = l >>> 6 & 0x3FFFFFF;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  792 */     return i + paramInt2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final long kgrdb42(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  803 */     long l = 0L;
/*      */     
/*  805 */     for (int i = 0; i < paramInt1; i++)
/*      */     {
/*  807 */       int j = paramArrayOfByte[(paramInt2 + i)];
/*      */       
/*  809 */       j = kgrd_index_64[j];
/*      */       
/*  811 */       if (j == -1) {
/*  812 */         throw new SQLException("Char data to rowid conversion failed.");
/*      */       }
/*  814 */       l <<= 6;
/*  815 */       l |= j;
/*      */     }
/*      */     
/*  818 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final void kgrdr2ec(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfByte, int paramInt6)
/*      */     throws SQLException
/*      */   {
/*  831 */     paramInt6 = kgrd42b(paramInt1, paramArrayOfByte, paramInt6, 6);
/*  832 */     paramInt6 = kgrd42b(paramInt2, paramArrayOfByte, paramInt6, 3);
/*  833 */     paramInt6 = kgrd42b(paramInt4, paramArrayOfByte, paramInt6, 6);
/*  834 */     paramInt6 = kgrd42b(paramInt5, paramArrayOfByte, paramInt6, 3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int kgrd42b(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  845 */     int i = paramInt3;
/*  846 */     while (paramInt3 > 0)
/*      */     {
/*  848 */       paramInt3--;
/*  849 */       paramArrayOfByte[(paramInt2 + paramInt3)] = kgrd_basis_64[(paramInt1 & 0x3F)];
/*      */       
/*  851 */       paramInt1 >>= 6;
/*      */     }
/*      */     
/*  854 */     return paramInt2 + i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int kgrdub2c(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  867 */     int i = -1;
/*  868 */     int j = paramArrayOfByte1[paramInt2];
/*      */     int m;
/*  870 */     int n; int i1; int i2; int i3; if (j == 1)
/*      */     {
/*      */ 
/*      */ 
/*  874 */       int[] arrayOfInt = new int[paramArrayOfByte1.length];
/*  875 */       for (m = 0; m < paramArrayOfByte1.length; m++) { paramArrayOfByte1[m] &= 0xFF;
/*      */       }
/*  877 */       m = paramInt2 + 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  885 */       n = (((arrayOfInt[(m + 0)] << 8) + arrayOfInt[(m + 1)] << 8) + arrayOfInt[(m + 2)] << 8) + arrayOfInt[(m + 3)];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  890 */       m = paramInt2 + 5;
/*      */       
/*  892 */       i1 = (arrayOfInt[(m + 0)] << 8) + arrayOfInt[(m + 1)];
/*  893 */       i2 = 0;
/*      */       
/*      */ 
/*  896 */       m = paramInt2 + 7;
/*  897 */       i3 = (((arrayOfInt[(m + 0)] << 8) + arrayOfInt[(m + 1)] << 8) + arrayOfInt[(m + 2)] << 8) + arrayOfInt[(m + 3)];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  902 */       m = paramInt2 + 11;
/*      */       
/*  904 */       int i4 = (arrayOfInt[(m + 0)] << 8) + arrayOfInt[(m + 1)];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  913 */       if (n == 0) {
/*  914 */         kgrdr2rc(n, i1, i2, i3, i4, paramArrayOfByte2, paramInt3);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*  922 */         kgrdr2ec(n, i1, i2, i3, i4, paramArrayOfByte2, paramInt3);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  930 */       i = 18;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  936 */       int k = 0;
/*  937 */       m = paramInt1 - 1;
/*  938 */       n = 4 * (paramInt1 / 3) + (paramInt1 % 3 == 0 ? paramInt1 % 3 + 1 : 0);
/*      */       
/*  940 */       i1 = 1 + n - 1;
/*      */       
/*  942 */       if (i1 != 0)
/*      */       {
/*  944 */         paramArrayOfByte2[(paramInt3 + 0)] = kgrd_indbyte_char[(j - 1)];
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  958 */         i2 = paramInt2 + 1;
/*      */         
/*  960 */         k = 1;
/*      */         
/*  962 */         i3 = 0;
/*      */         
/*  964 */         while (m > 0)
/*      */         {
/*  966 */           paramArrayOfByte2[(paramInt3 + k++)] = kgrd_basis_64[((paramArrayOfByte1[i2] & 0xFF) >> 2)];
/*      */           
/*      */ 
/*      */ 
/*  970 */           if (m == 1)
/*      */           {
/*      */ 
/*      */ 
/*  974 */             paramArrayOfByte2[(paramInt3 + k++)] = kgrd_basis_64[((paramArrayOfByte1[i2] & 0x3) << 4)];
/*      */             
/*      */ 
/*  977 */             break;
/*      */           }
/*      */           
/*      */ 
/*  981 */           i3 = (byte)(paramArrayOfByte1[(i2 + 1)] & 0xFF);
/*      */           
/*  983 */           paramArrayOfByte2[(paramInt3 + k++)] = kgrd_basis_64[((paramArrayOfByte1[i2] & 0x3) << 4 | (i3 & 0xF0) >> 4)];
/*      */           
/*      */ 
/*      */ 
/*  987 */           if (m == 2)
/*      */           {
/*  989 */             paramArrayOfByte2[(paramInt3 + k++)] = kgrd_basis_64[((i3 & 0xF) << 2)];
/*      */             
/*      */ 
/*  992 */             break;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  999 */           i2 += 2;
/* 1000 */           paramArrayOfByte2[(paramInt3 + k++)] = kgrd_basis_64[((i3 & 0xF) << 2 | (paramArrayOfByte1[i2] & 0xC0) >> 6)];
/*      */           
/*      */ 
/*      */ 
/* 1004 */           paramArrayOfByte2[(paramInt3 + k)] = kgrd_basis_64[(paramArrayOfByte1[i2] & 0x3F)];
/*      */           
/*      */ 
/*      */ 
/* 1008 */           m -= 3;
/* 1009 */           i2++;
/* 1010 */           k++;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1016 */       i = k;
/*      */     }
/*      */     
/* 1019 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */   static final boolean isUROWID(byte[] paramArrayOfByte, int paramInt)
/*      */   {
/* 1025 */     return getRowidType(paramArrayOfByte, paramInt) == 2;
/*      */   }
/*      */   
/*      */ 
/*      */   static final byte getRowidType(byte[] paramArrayOfByte, int paramInt)
/*      */   {
/* 1031 */     byte b = 5;
/* 1032 */     switch (paramArrayOfByte[paramInt])
/*      */     {
/*      */     case 65: 
/* 1035 */       b = 1;
/* 1036 */       break;
/*      */     
/*      */     case 42: 
/* 1039 */       b = 2;
/* 1040 */       break;
/*      */     
/*      */     case 45: 
/* 1043 */       b = 3;
/* 1044 */       break;
/*      */     
/*      */     case 40: 
/* 1047 */       b = 4;
/* 1048 */       break;
/*      */     
/*      */     case 41: 
/* 1051 */       b = 5;
/*      */     }
/*      */     
/*      */     
/* 1055 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1083 */   static final byte[] kgrd_indbyte_char = { 65, 42, 45, 40, 41 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1090 */   static final byte[] kgrd_basis_64 = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1105 */   static final byte[] kgrd_index_64 = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1131 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/T4CRowidAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */