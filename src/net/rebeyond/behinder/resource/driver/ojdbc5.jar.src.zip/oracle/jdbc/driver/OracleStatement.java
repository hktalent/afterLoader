/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleStatement
/*      */   implements oracle.jdbc.internal.OracleStatement, ScrollRsetStatement
/*      */ {
/*      */   static final int PLAIN_STMT = 0;
/*      */   static final int PREP_STMT = 1;
/*      */   static final int CALL_STMT = 2;
/*      */   int cursorId;
/*      */   int numberOfDefinePositions;
/*      */   int definesBatchSize;
/*      */   Accessor[] accessors;
/*      */   int defineByteSubRange;
/*      */   int defineCharSubRange;
/*      */   int defineIndicatorSubRange;
/*      */   int defineLengthSubRange;
/*      */   byte[] defineBytes;
/*      */   char[] defineChars;
/*      */   short[] defineIndicators;
/*      */   
/*      */   abstract void doDescribe(boolean paramBoolean)
/*      */     throws SQLException;
/*      */   
/*      */   abstract void executeForDescribe()
/*      */     throws SQLException;
/*      */   
/*      */   abstract void executeForRows(boolean paramBoolean)
/*      */     throws SQLException;
/*      */   
/*      */   abstract void fetch()
/*      */     throws SQLException;
/*      */   
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  292 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "continueReadRow is only implemented by the T4C statements.");
/*  293 */     localSQLException.fillInStackTrace();
/*  294 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract void doClose()
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract void closeQuery()
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int cursorIfRefCursor()
/*      */     throws SQLException
/*      */   {
/*  330 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "cursorIfRefCursor not implemented");
/*  331 */     localSQLException.fillInStackTrace();
/*  332 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeCursorOnPlainStatement()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  365 */   boolean described = false;
/*  366 */   boolean describedWithNames = false;
/*      */   
/*      */ 
/*      */   byte[] defineMetaData;
/*      */   
/*      */ 
/*      */   int defineMetaDataSubRange;
/*      */   
/*      */ 
/*      */   static final int METADATALENGTH = 1;
/*      */   
/*      */ 
/*      */   int rowsProcessed;
/*      */   
/*      */ 
/*  381 */   int cachedDefineByteSize = 0;
/*  382 */   int cachedDefineCharSize = 0;
/*  383 */   int cachedDefineIndicatorSize = 0;
/*  384 */   int cachedDefineMetaDataSize = 0;
/*      */   
/*      */ 
/*  387 */   OracleStatement children = null;
/*  388 */   OracleStatement parent = null;
/*      */   
/*      */ 
/*  391 */   OracleStatement nextChild = null;
/*      */   
/*      */ 
/*      */   OracleStatement next;
/*      */   
/*      */ 
/*      */   OracleStatement prev;
/*      */   
/*      */ 
/*      */   long c_state;
/*      */   
/*      */ 
/*      */   int numberOfBindPositions;
/*      */   
/*      */ 
/*      */   byte[] bindBytes;
/*      */   
/*      */ 
/*      */   char[] bindChars;
/*      */   
/*      */ 
/*      */   short[] bindIndicators;
/*      */   
/*      */   int bindByteOffset;
/*      */   
/*      */   int bindCharOffset;
/*      */   
/*      */   int bindIndicatorOffset;
/*      */   
/*      */   int bindByteSubRange;
/*      */   
/*      */   int bindCharSubRange;
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */   
/*      */   Accessor[] outBindAccessors;
/*      */   
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   Object[][] userStream;
/*      */   
/*      */   int firstRowInBatch;
/*      */   
/*  434 */   boolean hasIbtBind = false;
/*      */   
/*      */ 
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */ 
/*      */   char[] ibtBindChars;
/*      */   
/*      */ 
/*      */   short[] ibtBindIndicators;
/*      */   
/*      */ 
/*      */   int ibtBindByteOffset;
/*      */   
/*      */ 
/*      */   int ibtBindCharOffset;
/*      */   
/*      */ 
/*      */   int ibtBindIndicatorOffset;
/*      */   
/*      */ 
/*      */   int ibtBindIndicatorSize;
/*      */   
/*  457 */   ByteBuffer[] nioBuffers = null;
/*  458 */   Object[] lobPrefetchMetaData = null;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean hasStream;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] tmpByteArray;
/*      */   
/*      */ 
/*  469 */   int sizeTmpByteArray = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] tmpBindsByteArray;
/*      */   
/*      */ 
/*      */ 
/*  477 */   boolean needToSendOalToFetch = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  484 */   int[] definedColumnType = null;
/*  485 */   int[] definedColumnSize = null;
/*  486 */   int[] definedColumnFormOfUse = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  492 */   T4CTTIoac[] oacdefSent = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  499 */   int[] nbPostPonedColumns = null;
/*  500 */   int[][] indexOfPostPonedColumn = (int[][])null;
/*      */   
/*      */ 
/*      */ 
/*  504 */   boolean aFetchWasDoneDuringDescribe = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  511 */   boolean implicitDefineForLobPrefetchDone = false;
/*      */   
/*  513 */   long checkSum = 0L;
/*  514 */   boolean checkSumComputationFailure = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  536 */   int accessorByteOffset = 0;
/*  537 */   int accessorCharOffset = 0;
/*  538 */   int accessorShortOffset = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int VALID_ROWS_UNINIT = -999;
/*      */   
/*      */ 
/*      */ 
/*      */   PhysicalConnection connection;
/*      */   
/*      */ 
/*      */   OracleInputStream streamList;
/*      */   
/*      */ 
/*      */   OracleInputStream nextStream;
/*      */   
/*      */ 
/*      */   OracleResultSetImpl currentResultSet;
/*      */   
/*      */ 
/*      */   boolean processEscapes;
/*      */   
/*      */ 
/*      */   boolean convertNcharLiterals;
/*      */   
/*      */ 
/*      */   int queryTimeout;
/*      */   
/*      */ 
/*      */   int batch;
/*      */   
/*      */ 
/*  570 */   int numberOfExecutedElementsInBatch = -1;
/*      */   int currentRank;
/*  572 */   boolean bsendBatchInProgress = false;
/*      */   
/*      */ 
/*      */   int currentRow;
/*      */   
/*      */   int validRows;
/*      */   
/*      */   int maxFieldSize;
/*      */   
/*      */   int maxRows;
/*      */   
/*      */   int totalRowsVisited;
/*      */   
/*      */   int rowPrefetch;
/*      */   
/*  587 */   int rowPrefetchInLastFetch = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int defaultRowPrefetch;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean rowPrefetchChanged;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int defaultLobPrefetchSize;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean gotLastBatch;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean clearParameters;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean closed;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean sqlStringChanged;
/*      */   
/*      */ 
/*      */ 
/*      */   OracleSql sqlObject;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean needToParse;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean needToPrepareDefineBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean columnsDefinedByUser;
/*      */   
/*      */ 
/*      */ 
/*  638 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.SELECT;
/*  639 */   byte sqlKindByte = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   int autoRollback;
/*      */   
/*      */ 
/*      */ 
/*      */   int defaultFetchDirection;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean serverCursor;
/*      */   
/*      */ 
/*      */ 
/*  655 */   boolean fixedString = false;
/*      */   
/*      */ 
/*  658 */   boolean noMoreUpdateCounts = false;
/*      */   
/*  660 */   protected CancelLock cancelLock = new CancelLock();
/*      */   
/*      */   OracleStatementWrapper wrapper;
/*      */   
/*      */   static final byte EXECUTE_NONE = -1;
/*      */   
/*      */   static final byte EXECUTE_QUERY = 1;
/*      */   
/*      */   static final byte EXECUTE_UPDATE = 2;
/*      */   
/*      */   static final byte EXECUTE_NORMAL = 3;
/*  671 */   byte executionType = -1;
/*      */   
/*      */ 
/*      */   OracleResultSet scrollRset;
/*      */   
/*      */ 
/*      */   oracle.jdbc.OracleResultSetCache rsetCache;
/*      */   
/*      */   int userRsetType;
/*      */   
/*      */   int realRsetType;
/*      */   
/*      */   boolean needToAddIdentifier;
/*      */   
/*      */   SQLWarning sqlWarning;
/*      */   
/*  687 */   int cacheState = 3;
/*      */   
/*      */ 
/*  690 */   int creationState = 0;
/*      */   
/*  692 */   boolean isOpen = false;
/*      */   
/*      */ 
/*      */ 
/*  696 */   int statementType = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  702 */   boolean columnSetNull = false;
/*      */   
/*      */   int[] returnParamMeta;
/*      */   
/*      */   static final int DMLR_METADATA_PREFIX_SIZE = 3;
/*      */   
/*      */   static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
/*      */   
/*      */   static final int DMLR_METADATA_TYPE_OFFSET = 0;
/*      */   
/*      */   static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
/*      */   
/*      */   static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
/*      */   
/*      */   static final int DMLR_METADATA_FORM_OF_USE_OFFSET = 3;
/*      */   
/*      */   static final int DMLR_METADATA_PER_POSITION_SIZE = 4;
/*      */   
/*      */   Accessor[] returnParamAccessors;
/*      */   
/*      */   boolean returnParamsFetched;
/*      */   
/*      */   int rowsDmlReturned;
/*      */   
/*      */   int numReturnParams;
/*      */   
/*      */   byte[] returnParamBytes;
/*      */   char[] returnParamChars;
/*      */   short[] returnParamIndicators;
/*      */   int returnParamRowBytes;
/*      */   int returnParamRowChars;
/*      */   OracleReturnResultSet returnResultSet;
/*      */   boolean isAutoGeneratedKey;
/*      */   AutoKeyInfo autoKeyInfo;
/*  740 */   TimeZone defaultTimeZone = null;
/*  741 */   String defaultTimeZoneName = null;
/*      */   
/*  743 */   Calendar defaultCalendar = null;
/*  744 */   Calendar gmtCalendar = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  756 */   long inScn = 0L;
/*      */   
/*      */   public void setSnapshotSCN(long paramLong) throws SQLException
/*      */   {
/*  760 */     doSetSnapshotSCN(paramLong); }
/*      */   
/*      */ 
/*      */   void doSetSnapshotSCN(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  766 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  767 */     localSQLException.fillInStackTrace();
/*  768 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  790 */     this(paramPhysicalConnection, paramInt1, paramInt2, -1, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  805 */     this.connection = paramPhysicalConnection;
/*      */     
/*  807 */     this.connection.needLine();
/*      */     
/*      */ 
/*      */ 
/*  811 */     this.connection.registerHeartbeat();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  816 */     this.connection.addStatement(this);
/*      */     
/*  818 */     this.sqlObject = new OracleSql(this.connection.conversion);
/*      */     
/*      */ 
/*      */ 
/*  822 */     this.processEscapes = this.connection.processEscapes;
/*  823 */     this.convertNcharLiterals = this.connection.convertNcharLiterals;
/*  824 */     this.autoRollback = 2;
/*  825 */     this.gotLastBatch = false;
/*  826 */     this.closed = false;
/*  827 */     this.clearParameters = true;
/*  828 */     this.serverCursor = false;
/*  829 */     this.needToAddIdentifier = false;
/*  830 */     this.defaultFetchDirection = 1000;
/*  831 */     this.fixedString = this.connection.getDefaultFixedString();
/*  832 */     this.rowPrefetchChanged = false;
/*  833 */     this.rowPrefetch = paramInt2;
/*  834 */     this.defaultRowPrefetch = paramInt2;
/*  835 */     if (this.connection.getVersionNumber() >= 11000) {
/*  836 */       this.defaultLobPrefetchSize = this.connection.defaultLobPrefetchSize;
/*      */     } else
/*  838 */       this.defaultLobPrefetchSize = -1;
/*  839 */     this.batch = paramInt1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  845 */     this.sqlStringChanged = true;
/*  846 */     this.needToParse = true;
/*  847 */     this.needToPrepareDefineBuffer = true;
/*  848 */     this.columnsDefinedByUser = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  856 */     if ((paramInt3 != -1) || (paramInt4 != -1))
/*      */     {
/*  858 */       this.realRsetType = 0;
/*  859 */       this.userRsetType = ResultSetUtil.getRsetTypeCode(paramInt3, paramInt4);
/*      */       
/*      */ 
/*  862 */       this.needToAddIdentifier = ResultSetUtil.needIdentifier(this.userRsetType);
/*      */     }
/*      */     else
/*      */     {
/*  866 */       this.userRsetType = 1;
/*  867 */       this.realRsetType = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void initializeDefineSubRanges()
/*      */   {
/*  890 */     this.defineByteSubRange = 0;
/*  891 */     this.defineCharSubRange = 0;
/*  892 */     this.defineIndicatorSubRange = 0;
/*  893 */     this.defineMetaDataSubRange = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareDefinePreambles() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareAccessors()
/*      */     throws SQLException
/*      */   {
/*  926 */     byte[] arrayOfByte1 = null;
/*  927 */     char[] arrayOfChar = null;
/*  928 */     short[] arrayOfShort = null;
/*  929 */     boolean bool = false;
/*  930 */     byte[] arrayOfByte2 = null;
/*      */     
/*  932 */     if (this.accessors == null)
/*      */     {
/*  934 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  935 */       localSQLException1.fillInStackTrace();
/*  936 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  942 */     int i = 0;
/*  943 */     int j = 0;
/*  944 */     int k = 0;
/*  945 */     Accessor localAccessor; for (int m = 0; m < this.numberOfDefinePositions; m++)
/*      */     {
/*  947 */       localAccessor = this.accessors[m];
/*      */       
/*  949 */       if (localAccessor == null)
/*      */       {
/*  951 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  952 */         localSQLException2.fillInStackTrace();
/*  953 */         throw localSQLException2;
/*      */       }
/*  955 */       switch (localAccessor.internalType)
/*      */       {
/*      */       case 8: 
/*      */       case 24: 
/*  959 */         this.hasStream = true;
/*      */       }
/*      */       
/*      */       
/*  963 */       i += localAccessor.byteLength;
/*  964 */       j += localAccessor.charLength;
/*  965 */       k += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  970 */     if ((this.streamList != null) && (!this.connection.useFetchSizeWithLongColumn)) {
/*  971 */       this.rowPrefetch = 1;
/*      */     }
/*  973 */     m = this.rowPrefetch;
/*      */     
/*  975 */     this.definesBatchSize = m;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  983 */     initializeDefineSubRanges();
/*      */     
/*      */ 
/*  986 */     int n = k * m;
/*  987 */     if ((this.defineMetaData == null) || (this.defineMetaData.length < n))
/*      */     {
/*  989 */       if (this.defineMetaData != null)
/*  990 */         arrayOfByte2 = this.defineMetaData;
/*  991 */       this.defineMetaData = new byte[n];
/*      */     }
/*      */     
/*      */ 
/*  995 */     this.cachedDefineByteSize = (this.defineByteSubRange + i * m);
/*      */     
/*  997 */     if ((this.defineBytes == null) || (this.defineBytes.length < this.cachedDefineByteSize))
/*      */     {
/*  999 */       if (this.defineBytes != null) arrayOfByte1 = this.defineBytes;
/* 1000 */       this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
/*      */     }
/*      */     
/* 1003 */     this.defineByteSubRange += this.accessorByteOffset;
/*      */     
/*      */ 
/* 1006 */     this.cachedDefineCharSize = (this.defineCharSubRange + j * m);
/*      */     
/* 1008 */     if (((this.defineChars == null) || (this.defineChars.length < this.cachedDefineCharSize)) && (this.cachedDefineCharSize > 0))
/*      */     {
/*      */ 
/* 1011 */       if (this.defineChars != null) { arrayOfChar = this.defineChars;
/*      */       }
/* 1013 */       this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
/*      */     }
/*      */     
/* 1016 */     this.defineCharSubRange += this.accessorCharOffset;
/*      */     
/*      */ 
/*      */ 
/* 1020 */     int i1 = this.numberOfDefinePositions * m;
/* 1021 */     int i2 = this.defineIndicatorSubRange + i1 + i1;
/*      */     
/*      */ 
/* 1024 */     if ((this.defineIndicators == null) || (this.defineIndicators.length < i2))
/*      */     {
/*      */ 
/* 1027 */       if (this.defineIndicators != null) arrayOfShort = this.defineIndicators;
/* 1028 */       this.defineIndicators = new short[i2];
/* 1029 */     } else if (this.defineIndicators.length >= i2)
/*      */     {
/* 1031 */       bool = true;
/* 1032 */       arrayOfShort = this.defineIndicators;
/*      */     }
/*      */     
/* 1035 */     this.defineIndicatorSubRange += this.accessorShortOffset;
/*      */     
/* 1037 */     int i3 = this.defineIndicatorSubRange + i1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1043 */     for (int i4 = 0; i4 < this.numberOfDefinePositions; i4++)
/*      */     {
/* 1045 */       localAccessor = this.accessors[i4];
/*      */       
/* 1047 */       localAccessor.lengthIndexLastRow = localAccessor.lengthIndex;
/* 1048 */       localAccessor.indicatorIndexLastRow = localAccessor.indicatorIndex;
/* 1049 */       localAccessor.columnIndexLastRow = localAccessor.columnIndex;
/*      */       
/* 1051 */       localAccessor.setOffsets(m);
/*      */       
/* 1053 */       localAccessor.lengthIndex = i3;
/* 1054 */       localAccessor.indicatorIndex = this.defineIndicatorSubRange;
/* 1055 */       localAccessor.metaDataIndex = this.defineMetaDataSubRange;
/* 1056 */       localAccessor.rowSpaceByte = this.defineBytes;
/* 1057 */       localAccessor.rowSpaceChar = this.defineChars;
/* 1058 */       localAccessor.rowSpaceIndicator = this.defineIndicators;
/* 1059 */       localAccessor.rowSpaceMetaData = this.defineMetaData;
/* 1060 */       this.defineIndicatorSubRange += m;
/* 1061 */       i3 += m;
/* 1062 */       this.defineMetaDataSubRange += m * 1;
/*      */     }
/*      */     
/* 1065 */     prepareDefinePreambles();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1073 */     if ((this.rowPrefetchInLastFetch != -1) && (this.rowPrefetch != this.rowPrefetchInLastFetch))
/*      */     {
/* 1075 */       if (arrayOfChar == null) arrayOfChar = this.defineChars;
/* 1076 */       if (arrayOfByte1 == null) arrayOfByte1 = this.defineBytes;
/* 1077 */       if (arrayOfShort == null) arrayOfShort = this.defineIndicators;
/* 1078 */       saveDefineBuffersIfRequired(arrayOfChar, arrayOfByte1, arrayOfShort, bool);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean checkAccessorsUsable()
/*      */     throws SQLException
/*      */   {
/* 1094 */     int i = this.accessors.length;
/*      */     
/* 1096 */     if (i < this.numberOfDefinePositions) {
/* 1097 */       return false;
/*      */     }
/* 1099 */     int j = 1;
/* 1100 */     int k = 0;
/* 1101 */     boolean bool = false;
/*      */     
/* 1103 */     for (int m = 0; m < this.numberOfDefinePositions; m++)
/*      */     {
/* 1105 */       Accessor localAccessor = this.accessors[m];
/*      */       
/* 1107 */       if ((localAccessor == null) || (localAccessor.externalType == 0)) {
/* 1108 */         j = 0;
/*      */       } else {
/* 1110 */         k = 1;
/*      */       }
/*      */     }
/* 1113 */     if (j != 0)
/*      */     {
/*      */ 
/* 1116 */       bool = true;
/* 1117 */     } else { if (k != 0)
/*      */       {
/*      */ 
/*      */ 
/* 1121 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1122 */         localSQLException.fillInStackTrace();
/* 1123 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1129 */       this.columnsDefinedByUser = false;
/*      */     }
/* 1131 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeMaybeDescribe()
/*      */     throws SQLException
/*      */   {
/* 1140 */     int i = 1;
/*      */     
/* 1142 */     if (this.rowPrefetchChanged)
/*      */     {
/* 1144 */       if ((this.streamList == null) && (this.rowPrefetch != this.definesBatchSize)) {
/* 1145 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/* 1147 */       this.rowPrefetchChanged = false;
/*      */     }
/*      */     
/* 1150 */     if (!this.needToPrepareDefineBuffer)
/*      */     {
/*      */ 
/*      */ 
/* 1154 */       if (this.accessors == null)
/*      */       {
/*      */ 
/*      */ 
/* 1158 */         this.needToPrepareDefineBuffer = true;
/* 1159 */       } else if (this.columnsDefinedByUser) {
/* 1160 */         this.needToPrepareDefineBuffer = (!checkAccessorsUsable());
/*      */       }
/*      */     }
/* 1163 */     boolean bool = false;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1168 */       this.cancelLock.enterExecuting();
/*      */       
/* 1170 */       if (this.needToPrepareDefineBuffer)
/*      */       {
/*      */ 
/* 1173 */         if (!this.columnsDefinedByUser)
/*      */         {
/* 1175 */           executeForDescribe();
/*      */           
/* 1177 */           bool = true;
/*      */           
/*      */ 
/*      */ 
/* 1181 */           if (this.aFetchWasDoneDuringDescribe) {
/* 1182 */             i = 0;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1188 */         if (this.needToPrepareDefineBuffer)
/*      */         {
/*      */ 
/*      */ 
/* 1192 */           prepareAccessors();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1197 */       int j = this.accessors.length;
/*      */       
/* 1199 */       for (int k = this.numberOfDefinePositions; k < j; k++)
/*      */       {
/* 1201 */         Accessor localAccessor = this.accessors[k];
/*      */         
/* 1203 */         if (localAccessor != null)
/* 1204 */           localAccessor.rowSpaceIndicator = null;
/*      */       }
/* 1206 */       if (i != 0) {
/* 1207 */         executeForRows(bool);
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/* 1212 */       this.needToParse = true;
/* 1213 */       throw localSQLException;
/*      */     }
/*      */     finally
/*      */     {
/* 1217 */       this.cancelLock.exitExecuting();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void adjustGotLastBatch() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doExecuteWithTimeout()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1253 */       cleanOldTempLobs();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1260 */       this.connection.registerHeartbeat();
/*      */       
/*      */ 
/* 1263 */       this.rowsProcessed = 0;
/*      */       SQLException localSQLException1;
/* 1265 */       if (this.sqlKind.isSELECT())
/*      */       {
/* 1267 */         if ((this.connection.j2ee13Compliant) && (this.executionType == 2))
/*      */         {
/* 1269 */           localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 129);
/* 1270 */           localSQLException1.fillInStackTrace();
/* 1271 */           throw localSQLException1;
/*      */         }
/*      */         
/* 1274 */         this.connection.needLine();
/*      */         
/* 1276 */         if (!this.isOpen)
/*      */         {
/* 1278 */           this.connection.open(this);
/*      */           
/* 1280 */           this.isOpen = true;
/*      */         }
/*      */         
/* 1283 */         if (this.queryTimeout != 0)
/*      */         {
/*      */           try
/*      */           {
/* 1287 */             this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/* 1288 */             executeMaybeDescribe();
/*      */           }
/*      */           finally
/*      */           {
/* 1292 */             this.connection.getTimeout().cancelTimeout();
/*      */           }
/*      */           
/*      */         } else {
/* 1296 */           executeMaybeDescribe();
/*      */         }
/* 1298 */         checkValidRowsStatus();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1303 */         if (this.serverCursor) {
/* 1304 */           adjustGotLastBatch();
/*      */         }
/*      */       }
/*      */       else {
/* 1308 */         if ((this.connection.j2ee13Compliant) && (!this.sqlKind.isPlsqlOrCall()) && (this.executionType == 1))
/*      */         {
/*      */ 
/* 1311 */           localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 128);
/* 1312 */           localSQLException1.fillInStackTrace();
/* 1313 */           throw localSQLException1;
/*      */         }
/*      */         
/* 1316 */         this.currentRank += 1;
/*      */         
/* 1318 */         if (this.currentRank >= this.batch)
/*      */         {
/*      */           try
/*      */           {
/* 1322 */             this.connection.needLine();
/*      */             
/* 1324 */             this.cancelLock.enterExecuting();
/*      */             
/* 1326 */             if (!this.isOpen)
/*      */             {
/* 1328 */               this.connection.open(this);
/*      */               
/* 1330 */               this.isOpen = true;
/*      */             }
/*      */             
/* 1333 */             if (this.queryTimeout != 0) {
/* 1334 */               this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/*      */             }
/* 1336 */             executeForRows(false);
/*      */           }
/*      */           catch (SQLException localSQLException2)
/*      */           {
/* 1340 */             this.needToParse = true;
/* 1341 */             if (this.batch > 1)
/*      */             {
/* 1343 */               clearBatch();
/*      */               
/*      */               int[] arrayOfInt;
/*      */               
/*      */               int i;
/*      */               
/* 1349 */               if ((this.numberOfExecutedElementsInBatch != -1) && (this.numberOfExecutedElementsInBatch < this.batch))
/*      */               {
/*      */ 
/* 1352 */                 arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 1353 */                 for (i = 0; i < arrayOfInt.length; i++) {
/* 1354 */                   arrayOfInt[i] = -2;
/*      */                 }
/*      */               }
/*      */               else {
/* 1358 */                 arrayOfInt = new int[this.batch];
/* 1359 */                 for (i = 0; i < arrayOfInt.length; i++) {
/* 1360 */                   arrayOfInt[i] = -3;
/*      */                 }
/*      */               }
/* 1363 */               BatchUpdateException localBatchUpdateException = DatabaseError.createBatchUpdateException(localSQLException2, arrayOfInt.length, arrayOfInt);
/* 1364 */               localBatchUpdateException.fillInStackTrace();
/* 1365 */               throw localBatchUpdateException;
/*      */             }
/*      */             
/* 1368 */             resetCurrentRowBinders();
/*      */             
/* 1370 */             throw localSQLException2;
/*      */           }
/*      */           finally
/*      */           {
/* 1374 */             if (this.queryTimeout != 0) {
/* 1375 */               this.connection.getTimeout().cancelTimeout();
/*      */             }
/* 1377 */             this.currentRank = 0;
/* 1378 */             this.cancelLock.exitExecuting();
/*      */             
/* 1380 */             checkValidRowsStatus();
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException3)
/*      */     {
/*      */ 
/*      */ 
/* 1398 */       resetOnExceptionDuringExecute();
/* 1399 */       throw localSQLException3;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1409 */     this.connection.registerHeartbeat();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetOnExceptionDuringExecute()
/*      */   {
/* 1418 */     this.needToParse = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetCurrentRowBinders() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void open()
/*      */     throws SQLException
/*      */   {
/* 1440 */     if (!this.isOpen)
/*      */     {
/* 1442 */       this.connection.needLine();
/* 1443 */       this.connection.open(this);
/*      */       
/* 1445 */       this.isOpen = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet executeQuery(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1464 */     synchronized (this.connection)
/*      */     {
/* 1466 */       Object localObject1 = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1474 */         this.executionType = 1;
/*      */         
/*      */ 
/*      */ 
/* 1478 */         this.noMoreUpdateCounts = false;
/*      */         
/* 1480 */         ensureOpen();
/* 1481 */         checkIfJdbcBatchExists();
/*      */         
/* 1483 */         sendBatch();
/*      */         
/*      */ 
/* 1486 */         this.hasStream = false;
/*      */         
/*      */ 
/* 1489 */         this.sqlObject.initialize(paramString);
/*      */         
/* 1491 */         this.sqlKind = this.sqlObject.getSqlKind();
/* 1492 */         this.needToParse = true;
/*      */         
/* 1494 */         prepareForNewResults(true, true);
/*      */         
/* 1496 */         if (this.userRsetType == 1)
/*      */         {
/* 1498 */           doExecuteWithTimeout();
/*      */           
/* 1500 */           this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1501 */           localObject1 = this.currentResultSet;
/*      */         }
/*      */         else
/*      */         {
/* 1505 */           localObject1 = doScrollStmtExecuteQuery();
/*      */           
/* 1507 */           if (localObject1 == null)
/*      */           {
/* 1509 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1510 */             localObject1 = this.currentResultSet;
/*      */           }
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 1516 */         this.executionType = -1;
/*      */       }
/*      */       
/* 1519 */       return (ResultSet)localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closeWithKey(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1532 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1533 */     localSQLException.fillInStackTrace();
/* 1534 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/* 1566 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 1570 */       closeOrCache(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void closeOrCache(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1578 */     if (this.closed) {
/* 1579 */       return;
/*      */     }
/*      */     
/* 1582 */     if (this.connection.lifecycle == 2) {
/* 1583 */       this.connection.needLineUnchecked();
/*      */     } else {
/* 1585 */       this.connection.needLine();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1594 */     if ((this.statementType != 0) && (this.cacheState != 0) && (this.cacheState != 3) && (this.connection.isStatementCacheInitialized()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1605 */       if (paramString == null)
/*      */       {
/* 1607 */         if (this.connection.getImplicitCachingEnabled())
/*      */         {
/* 1609 */           this.connection.cacheImplicitStatement((OraclePreparedStatement)this, this.sqlObject.getOriginalSql(), this.statementType, this.userRsetType);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/* 1618 */           this.cacheState = 0;
/*      */           
/* 1620 */           hardClose();
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1626 */       else if (this.connection.getExplicitCachingEnabled())
/*      */       {
/* 1628 */         this.connection.cacheExplicitStatement((OraclePreparedStatement)this, paramString);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/* 1636 */         this.cacheState = 0;
/*      */         
/* 1638 */         hardClose();
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1647 */       hardClose();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void hardClose()
/*      */     throws SQLException
/*      */   {
/* 1657 */     hardClose(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void hardClose(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1668 */     alwaysOnClose();
/*      */     
/* 1670 */     this.describedWithNames = false;
/* 1671 */     this.described = false;
/*      */     
/*      */ 
/* 1674 */     this.connection.removeStatement(this);
/*      */     
/* 1676 */     cleanupDefines();
/*      */     
/* 1678 */     if ((this.isOpen) && (paramBoolean) && ((this.connection.lifecycle == 1) || (this.connection.lifecycle == 16) || (this.connection.lifecycle == 2)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1687 */       this.connection.registerHeartbeat();
/*      */       
/*      */ 
/* 1690 */       doClose();
/*      */       
/* 1692 */       this.isOpen = false;
/*      */     }
/*      */     
/* 1695 */     this.sqlObject = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void alwaysOnClose()
/*      */     throws SQLException
/*      */   {
/* 1712 */     Object localObject = this.children;
/*      */     
/* 1714 */     while (localObject != null)
/*      */     {
/* 1716 */       OracleStatement localOracleStatement = ((OracleStatement)localObject).nextChild;
/*      */       
/* 1718 */       ((OracleStatement)localObject).close();
/*      */       
/* 1720 */       localObject = localOracleStatement;
/*      */     }
/*      */     
/* 1723 */     if (this.parent != null)
/*      */     {
/* 1725 */       this.parent.removeChild(this);
/*      */     }
/*      */     
/* 1728 */     this.closed = true;
/*      */     
/*      */ 
/* 1731 */     if ((this.connection.lifecycle == 1) || (this.connection.lifecycle == 2))
/*      */     {
/*      */ 
/*      */ 
/* 1735 */       if (this.currentResultSet != null)
/*      */       {
/* 1737 */         this.currentResultSet.internal_close(false);
/*      */         
/* 1739 */         this.currentResultSet = null;
/*      */       }
/*      */       
/* 1742 */       if (this.scrollRset != null)
/*      */       {
/* 1744 */         this.scrollRset.close();
/*      */         
/* 1746 */         this.scrollRset = null;
/*      */       }
/*      */       
/* 1749 */       if (this.returnResultSet != null)
/*      */       {
/* 1751 */         this.returnResultSet.close();
/* 1752 */         this.returnResultSet = null;
/*      */       }
/*      */     }
/*      */     
/* 1756 */     clearWarnings();
/*      */     
/* 1758 */     this.m_batchItems = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeLeaveCursorOpen()
/*      */     throws SQLException
/*      */   {
/* 1774 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1780 */       if (this.closed)
/*      */       {
/* 1782 */         return;
/*      */       }
/*      */       
/* 1785 */       hardClose(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1804 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1809 */       setNonAutoKey();
/* 1810 */       return executeUpdateInternal(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int executeUpdateInternal(String paramString)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1821 */       if (this.executionType == -1) {
/* 1822 */         this.executionType = 2;
/*      */       }
/*      */       
/* 1825 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1827 */       ensureOpen();
/* 1828 */       checkIfJdbcBatchExists();
/*      */       
/* 1830 */       sendBatch();
/*      */       
/*      */ 
/* 1833 */       this.hasStream = false;
/*      */       
/*      */ 
/* 1836 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1838 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1839 */       this.needToParse = true;
/*      */       
/* 1841 */       prepareForNewResults(true, true);
/*      */       
/* 1843 */       if (this.userRsetType == 1)
/*      */       {
/* 1845 */         doExecuteWithTimeout();
/*      */       }
/*      */       else
/*      */       {
/* 1849 */         doScrollStmtExecuteQuery();
/*      */       }
/*      */       
/* 1852 */       return this.validRows;
/*      */     }
/*      */     finally
/*      */     {
/* 1856 */       this.executionType = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1872 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1877 */       setNonAutoKey();
/* 1878 */       return executeInternal(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   boolean executeInternal(String paramString)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1889 */       this.executionType = 3;
/*      */       
/* 1891 */       this.checkSum = 0L;
/* 1892 */       this.checkSumComputationFailure = false;
/*      */       
/*      */ 
/* 1895 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1897 */       ensureOpen();
/* 1898 */       checkIfJdbcBatchExists();
/*      */       
/* 1900 */       sendBatch();
/*      */       
/*      */ 
/*      */ 
/* 1904 */       this.hasStream = false;
/*      */       
/*      */ 
/* 1907 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1909 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1910 */       this.needToParse = true;
/*      */       
/* 1912 */       prepareForNewResults(true, true);
/*      */       
/* 1914 */       if (this.userRsetType == 1)
/*      */       {
/* 1916 */         doExecuteWithTimeout();
/*      */       }
/*      */       else
/*      */       {
/* 1920 */         doScrollStmtExecuteQuery();
/*      */       }
/*      */       
/* 1923 */       return this.sqlKind.isSELECT();
/*      */     }
/*      */     finally
/*      */     {
/* 1927 */       this.executionType = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   int getNumberOfColumns()
/*      */     throws SQLException
/*      */   {
/* 1935 */     ensureOpen();
/* 1936 */     if (!this.described)
/*      */     {
/* 1938 */       synchronized (this.connection) {
/* 1939 */         doDescribe(false);
/*      */         
/* 1941 */         this.described = true;
/*      */       }
/*      */     }
/*      */     
/* 1945 */     return this.numberOfDefinePositions;
/*      */   }
/*      */   
/*      */ 
/*      */   Accessor[] getDescription()
/*      */     throws SQLException
/*      */   {
/* 1952 */     ensureOpen();
/* 1953 */     if (!this.described)
/*      */     {
/* 1955 */       synchronized (this.connection) {
/* 1956 */         doDescribe(false);
/*      */         
/* 1958 */         this.described = true;
/*      */       }
/*      */     }
/*      */     
/* 1962 */     return this.accessors;
/*      */   }
/*      */   
/*      */ 
/*      */   Accessor[] getDescriptionWithNames()
/*      */     throws SQLException
/*      */   {
/* 1969 */     ensureOpen();
/* 1970 */     if (!this.describedWithNames)
/*      */     {
/* 1972 */       synchronized (this.connection) {
/* 1973 */         doDescribe(true);
/*      */         
/* 1975 */         this.described = true;
/* 1976 */         this.describedWithNames = true;
/*      */       }
/*      */     }
/*      */     
/* 1980 */     return this.accessors;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleStatement.SqlKind getSqlKind()
/*      */     throws SQLException
/*      */   {
/* 1993 */     return this.sqlObject.getSqlKind();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearDefines()
/*      */     throws SQLException
/*      */   {
/* 2013 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2016 */       freeLine();
/*      */       
/* 2018 */       this.streamList = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2025 */       this.columnsDefinedByUser = false;
/* 2026 */       this.needToPrepareDefineBuffer = true;
/*      */       
/*      */ 
/* 2029 */       this.numberOfDefinePositions = 0;
/* 2030 */       this.definesBatchSize = 0;
/*      */       
/* 2032 */       this.described = false;
/* 2033 */       this.describedWithNames = false;
/*      */       
/* 2035 */       cleanupDefines();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2057 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, (short)1, paramBoolean, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2068 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */     
/*      */     SQLException localSQLException;
/* 2073 */     if (paramInt1 < 1)
/*      */     {
/* 2075 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2076 */       localSQLException.fillInStackTrace();
/* 2077 */       throw localSQLException;
/*      */     }
/*      */     
/* 2080 */     if (paramInt2 == 0)
/*      */     {
/* 2082 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2083 */       localSQLException.fillInStackTrace();
/* 2084 */       throw localSQLException;
/*      */     }
/*      */     
/* 2087 */     int i = paramInt1 - 1;
/* 2088 */     int j = this.maxFieldSize > 0 ? this.maxFieldSize : -1;
/*      */     Object localObject1;
/* 2090 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/* 2094 */       if ((paramInt2 == 1) || (paramInt2 == 12))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2099 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2106 */       if (paramInt3 < 0)
/*      */       {
/* 2108 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/* 2109 */         ((SQLException)localObject1).fillInStackTrace();
/* 2110 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 2113 */       if (((j == -1) && (paramInt3 > 0)) || ((j > 0) && (paramInt3 < j)))
/*      */       {
/* 2115 */         j = paramInt3;
/*      */       }
/*      */     }
/* 2118 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed))
/*      */     {
/* 2120 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/* 2121 */       ((SQLException)localObject1).fillInStackTrace();
/* 2122 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/* 2125 */     if (!this.columnsDefinedByUser)
/*      */     {
/*      */ 
/*      */ 
/* 2129 */       clearDefines();
/*      */       
/* 2131 */       this.columnsDefinedByUser = true;
/*      */     }
/*      */     
/* 2134 */     if (this.numberOfDefinePositions < paramInt1)
/*      */     {
/* 2136 */       if ((this.accessors == null) || (this.accessors.length < paramInt1))
/*      */       {
/* 2138 */         localObject1 = new Accessor[paramInt1 << 1];
/*      */         
/* 2140 */         if (this.accessors != null) {
/* 2141 */           System.arraycopy(this.accessors, 0, localObject1, 0, this.numberOfDefinePositions);
/*      */         }
/* 2143 */         this.accessors = ((Accessor[])localObject1);
/*      */       }
/*      */       
/* 2146 */       this.numberOfDefinePositions = paramInt1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2153 */     int k = getInternalType(paramInt2);
/*      */     
/* 2155 */     if (((k == 109) || (k == 111)) && ((paramString == null) || (paramString.equals(""))))
/*      */     {
/*      */ 
/* 2158 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
/* 2159 */       ((SQLException)localObject2).fillInStackTrace();
/* 2160 */       throw ((Throwable)localObject2);
/*      */     }
/*      */     
/* 2163 */     Object localObject2 = this.accessors[i];
/* 2164 */     int m = 1;
/*      */     
/* 2166 */     if (localObject2 != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2171 */       int n = ((Accessor)localObject2).useForDataAccessIfPossible(k, paramInt2, j, paramString);
/*      */       
/*      */ 
/* 2174 */       if (n == 0)
/*      */       {
/* 2176 */         paramShort = ((Accessor)localObject2).formOfUse;
/* 2177 */         localObject2 = null;
/*      */         
/* 2179 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2181 */       else if (n == 1)
/*      */       {
/* 2183 */         localObject2 = null;
/*      */         
/* 2185 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2187 */       else if (n == 2) {
/* 2188 */         m = 0;
/*      */       }
/*      */     }
/* 2191 */     if (m != 0) {
/* 2192 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/* 2194 */     if (localObject2 == null)
/*      */     {
/* 2196 */       this.accessors[i] = allocateAccessor(k, paramInt2, paramInt1, j, paramShort, paramString, false);
/*      */       
/* 2198 */       this.described = false;
/* 2199 */       this.describedWithNames = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     Object localObject;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2241 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/* 2245 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2247 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2248 */         localSQLException.fillInStackTrace();
/* 2249 */         throw localSQLException;
/*      */       }
/*      */       
/* 2252 */       return new CharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 8: 
/* 2255 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2257 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2258 */         localSQLException.fillInStackTrace();
/* 2259 */         throw localSQLException;
/*      */       }
/*      */       
/* 2262 */       if (!paramBoolean) {
/* 2263 */         return new LongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */       }
/*      */     
/*      */ 
/*      */     case 1: 
/* 2268 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2270 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2271 */         localSQLException.fillInStackTrace();
/* 2272 */         throw localSQLException;
/*      */       }
/*      */       
/* 2275 */       return new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 2: 
/* 2278 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2280 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2281 */         localSQLException.fillInStackTrace();
/* 2282 */         throw localSQLException;
/*      */       }
/*      */       
/* 2285 */       return new NumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 6: 
/* 2288 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2290 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2291 */         localSQLException.fillInStackTrace();
/* 2292 */         throw localSQLException;
/*      */       }
/*      */       
/* 2295 */       return new VarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 24: 
/* 2298 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2300 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2301 */         localSQLException.fillInStackTrace();
/* 2302 */         throw localSQLException;
/*      */       }
/*      */       
/* 2305 */       if (!paramBoolean) {
/* 2306 */         return new LongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/* 2312 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2314 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2315 */         localSQLException.fillInStackTrace();
/* 2316 */         throw localSQLException;
/*      */       }
/*      */       
/* 2319 */       if (paramBoolean) {
/* 2320 */         return new OutRawAccessor(this, paramInt4, paramShort, paramInt2);
/*      */       }
/* 2322 */       return new RawAccessor(this, paramInt4, paramShort, paramInt2, false);
/*      */     
/*      */     case 100: 
/* 2325 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2327 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2328 */         localSQLException.fillInStackTrace();
/* 2329 */         throw localSQLException;
/*      */       }
/*      */       
/* 2332 */       return new BinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 101: 
/* 2336 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2338 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2339 */         localSQLException.fillInStackTrace();
/* 2340 */         throw localSQLException;
/*      */       }
/*      */       
/* 2343 */       return new BinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 104: 
/* 2347 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2349 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2350 */         localSQLException.fillInStackTrace();
/* 2351 */         throw localSQLException;
/*      */       }
/* 2353 */       if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */       {
/* 2355 */         paramInt4 = 18;
/* 2356 */         localObject = new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/* 2357 */         ((Accessor)localObject).definedColumnType = -8;
/* 2358 */         return (Accessor)localObject;
/*      */       }
/* 2360 */       return new RowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 102: 
/* 2363 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2365 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2366 */         localSQLException.fillInStackTrace();
/* 2367 */         throw localSQLException;
/*      */       }
/*      */       
/* 2370 */       return new ResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 12: 
/* 2373 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2375 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2376 */         localSQLException.fillInStackTrace();
/* 2377 */         throw localSQLException;
/*      */       }
/*      */       
/* 2380 */       return new DateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 113: 
/* 2383 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2385 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2386 */         localSQLException.fillInStackTrace();
/* 2387 */         throw localSQLException;
/*      */       }
/*      */       
/* 2390 */       localObject = new BlobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2391 */       if (!paramBoolean)
/* 2392 */         ((Accessor)localObject).lobPrefetchSizeForThisColumn = paramInt4;
/* 2393 */       return (Accessor)localObject;
/*      */     
/*      */     case 112: 
/* 2396 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2398 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2399 */         localSQLException.fillInStackTrace();
/* 2400 */         throw localSQLException;
/*      */       }
/*      */       
/* 2403 */       localObject = new ClobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2404 */       if (!paramBoolean)
/* 2405 */         ((Accessor)localObject).lobPrefetchSizeForThisColumn = paramInt4;
/* 2406 */       return (Accessor)localObject;
/*      */     
/*      */     case 114: 
/* 2409 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2411 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2412 */         localSQLException.fillInStackTrace();
/* 2413 */         throw localSQLException;
/*      */       }
/*      */       
/* 2416 */       localObject = new BfileAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/*      */ 
/* 2420 */       return (Accessor)localObject;
/*      */     
/*      */     case 109: 
/* 2423 */       if (paramString == null) {
/* 2424 */         if (paramBoolean)
/*      */         {
/* 2426 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2427 */           localSQLException.fillInStackTrace();
/* 2428 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 2432 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2433 */         localSQLException.fillInStackTrace();
/* 2434 */         throw localSQLException;
/*      */       }
/*      */       
/* 2437 */       localObject = new NamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/* 2440 */       ((Accessor)localObject).initMetadata();
/*      */       
/* 2442 */       return (Accessor)localObject;
/*      */     
/*      */     case 111: 
/* 2445 */       if (paramString == null) {
/* 2446 */         if (paramBoolean)
/*      */         {
/* 2448 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2449 */           localSQLException.fillInStackTrace();
/* 2450 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 2454 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2455 */         localSQLException.fillInStackTrace();
/* 2456 */         throw localSQLException;
/*      */       }
/*      */       
/* 2459 */       localObject = new RefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/* 2462 */       ((Accessor)localObject).initMetadata();
/*      */       
/* 2464 */       return (Accessor)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 180: 
/* 2469 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2471 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2472 */         localSQLException.fillInStackTrace();
/* 2473 */         throw localSQLException;
/*      */       }
/*      */       
/* 2476 */       return new TimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 181: 
/* 2480 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2482 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2483 */         localSQLException.fillInStackTrace();
/* 2484 */         throw localSQLException;
/*      */       }
/*      */       
/* 2487 */       return new TimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 231: 
/* 2491 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2493 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2494 */         localSQLException.fillInStackTrace();
/* 2495 */         throw localSQLException;
/*      */       }
/*      */       
/* 2498 */       return new TimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 182: 
/* 2502 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2504 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2505 */         localSQLException.fillInStackTrace();
/* 2506 */         throw localSQLException;
/*      */       }
/*      */       
/* 2509 */       return new IntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 183: 
/* 2513 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2515 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2516 */         localSQLException.fillInStackTrace();
/* 2517 */         throw localSQLException;
/*      */       }
/*      */       
/* 2520 */       return new IntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/* 2539 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 2540 */       localSQLException.fillInStackTrace();
/* 2541 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 2546 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2547 */     localSQLException.fillInStackTrace();
/* 2548 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2600 */     synchronized (this.connection)
/*      */     {
/* 2602 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2618 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2637 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, paramShort, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int lastIndex;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2708 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2711 */       defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2782 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2822 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2828 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setCursorId(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2844 */     this.cursorId = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setPrefetchInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2859 */     if (paramBoolean1)
/*      */     {
/* 2861 */       if (paramInt <= 0)
/*      */       {
/* 2863 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/* 2864 */         localSQLException.fillInStackTrace();
/* 2865 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2870 */       if (paramInt < 0)
/*      */       {
/* 2872 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchSize");
/* 2873 */         localSQLException.fillInStackTrace();
/* 2874 */         throw localSQLException;
/*      */       }
/* 2876 */       if (paramInt == 0) {
/* 2877 */         paramInt = this.connection.getDefaultRowPrefetch();
/*      */       }
/*      */     }
/*      */     
/* 2881 */     if (paramBoolean2)
/*      */     {
/* 2883 */       if (paramInt != this.defaultRowPrefetch)
/*      */       {
/* 2885 */         this.defaultRowPrefetch = paramInt;
/*      */         
/*      */ 
/*      */ 
/* 2889 */         if ((this.currentResultSet == null) || (this.currentResultSet.closed)) {
/* 2890 */           this.rowPrefetchChanged = true;
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 2897 */     else if ((paramInt != this.rowPrefetch) && (this.streamList == null))
/*      */     {
/*      */ 
/* 2900 */       this.rowPrefetch = paramInt;
/* 2901 */       this.rowPrefetchChanged = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRowPrefetch(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2928 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 2932 */       setPrefetchInternal(paramInt, true, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLobPrefetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2945 */     synchronized (this.connection)
/*      */     {
/* 2947 */       if (paramInt < -1)
/*      */       {
/* 2949 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/* 2950 */         localSQLException.fillInStackTrace();
/* 2951 */         throw localSQLException;
/*      */       }
/* 2953 */       this.defaultLobPrefetchSize = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getLobPrefetchSize()
/*      */   {
/* 2961 */     return this.defaultLobPrefetchSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getPrefetchInternal(boolean paramBoolean)
/*      */   {
/* 2978 */     int i = paramBoolean ? this.defaultRowPrefetch : this.rowPrefetch;
/*      */     
/* 2980 */     return i;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getRowPrefetch()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 71	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iconst_1
/*      */     //   9: invokevirtual 288	oracle/jdbc/driver/OracleStatement:getPrefetchInternal	(Z)I
/*      */     //   12: aload_1
/*      */     //   13: monitorexit
/*      */     //   14: ireturn
/*      */     //   15: astore_2
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: aload_2
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2995	-> byte code offset #0
/*      */     //   Java source line #2998	-> byte code offset #7
/*      */     //   Java source line #3000	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleStatement
/*      */     //   5	12	1	Ljava/lang/Object;	Object
/*      */     //   15	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public void setFixedString(boolean paramBoolean)
/*      */   {
/* 3025 */     this.fixedString = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getFixedString()
/*      */   {
/* 3050 */     return this.fixedString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void check_row_prefetch_changed()
/*      */     throws SQLException
/*      */   {
/* 3065 */     if (this.rowPrefetchChanged)
/*      */     {
/* 3067 */       if (this.streamList == null)
/*      */       {
/* 3069 */         prepareAccessors();
/*      */         
/* 3071 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/*      */       
/* 3074 */       this.rowPrefetchChanged = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDefinesInitialized(boolean paramBoolean) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void printState(String paramString)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkValidRowsStatus()
/*      */     throws SQLException
/*      */   {
/* 3111 */     if (this.validRows == -2)
/*      */     {
/*      */ 
/*      */ 
/* 3115 */       this.validRows = 1;
/* 3116 */       this.connection.holdLine(this);
/*      */       
/*      */ 
/* 3119 */       OracleInputStream localOracleInputStream = this.streamList;
/*      */       
/* 3121 */       while (localOracleInputStream != null)
/*      */       {
/* 3123 */         if (localOracleInputStream.hasBeenOpen) {
/* 3124 */           localOracleInputStream = localOracleInputStream.accessor.initForNewRow();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3131 */         localOracleInputStream.closed = false;
/* 3132 */         localOracleInputStream.hasBeenOpen = true;
/*      */         
/*      */ 
/*      */ 
/* 3136 */         localOracleInputStream = localOracleInputStream.nextStream;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3141 */       this.nextStream = this.streamList;
/*      */ 
/*      */     }
/* 3144 */     else if (this.sqlKind.isSELECT())
/*      */     {
/* 3146 */       if (this.validRows < this.rowPrefetch) {
/* 3147 */         this.gotLastBatch = true;
/*      */       }
/* 3149 */     } else if (!this.sqlKind.isPlsqlOrCall())
/*      */     {
/* 3151 */       this.rowsProcessed = this.validRows;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanupDefines()
/*      */   {
/* 3159 */     if (this.accessors != null) {
/* 3160 */       for (int i = 0; i < this.accessors.length; i++)
/* 3161 */         this.accessors[i] = null;
/*      */     }
/* 3163 */     this.accessors = null;
/*      */     
/*      */ 
/* 3166 */     this.connection.cacheBuffer(this.defineBytes);
/* 3167 */     this.defineBytes = null;
/* 3168 */     this.connection.cacheBuffer(this.defineChars);
/* 3169 */     this.defineChars = null;
/* 3170 */     this.defineIndicators = null;
/* 3171 */     this.defineMetaData = null;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getMaxFieldSize()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 71	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 211	oracle/jdbc/driver/OracleStatement:maxFieldSize	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3178	-> byte code offset #0
/*      */     //   Java source line #3180	-> byte code offset #7
/*      */     //   Java source line #3182	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public void setMaxFieldSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3187 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3190 */       if (paramInt < 0)
/*      */       {
/* 3192 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3193 */         localSQLException.fillInStackTrace();
/* 3194 */         throw localSQLException;
/*      */       }
/*      */       
/* 3197 */       this.maxFieldSize = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMaxRows()
/*      */     throws SQLException
/*      */   {
/* 3205 */     return this.maxRows;
/*      */   }
/*      */   
/*      */   public void setMaxRows(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3211 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3214 */       if (paramInt < 0)
/*      */       {
/* 3216 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3217 */         localSQLException.fillInStackTrace();
/* 3218 */         throw localSQLException;
/*      */       }
/*      */       
/* 3221 */       this.maxRows = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setEscapeProcessing(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3229 */     synchronized (this.connection)
/*      */     {
/* 3231 */       this.processEscapes = paramBoolean;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 71	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 154	oracle/jdbc/driver/OracleStatement:queryTimeout	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3245	-> byte code offset #0
/*      */     //   Java source line #3247	-> byte code offset #7
/*      */     //   Java source line #3249	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public void setQueryTimeout(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3262 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3265 */       if (paramInt < 0)
/*      */       {
/* 3267 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3268 */         localSQLException.fillInStackTrace();
/* 3269 */         throw localSQLException;
/*      */       }
/*      */       
/* 3272 */       this.queryTimeout = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/* 3285 */     doCancel();
/*      */   }
/*      */   
/*      */ 
/*      */   boolean doCancel()
/*      */     throws SQLException
/*      */   {
/* 3292 */     boolean bool = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3297 */     if (this.closed) {
/* 3298 */       return bool;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3310 */     if (this.connection.statementHoldingLine != null) {
/* 3311 */       freeLine();
/* 3312 */     } else if (this.cancelLock.enterCanceling()) {
/*      */       try
/*      */       {
/* 3315 */         bool = true;
/* 3316 */         this.connection.cancelOperationOnServer(true);
/*      */       }
/*      */       finally {
/* 3319 */         this.cancelLock.exitCanceling();
/*      */       }
/*      */       
/*      */     } else {
/* 3323 */       return bool;
/*      */     }
/* 3325 */     OracleStatement localOracleStatement = this.children;
/* 3326 */     while (localOracleStatement != null) {
/* 3327 */       bool = (bool) || (localOracleStatement.doCancel());
/* 3328 */       localOracleStatement = localOracleStatement.nextChild;
/*      */     }
/*      */     
/* 3331 */     this.connection.releaseLineForCancel();
/* 3332 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 3349 */     return this.sqlWarning;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/* 3359 */     this.sqlWarning = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void foundPlsqlCompilerWarning()
/*      */     throws SQLException
/*      */   {
/* 3367 */     SQLWarning localSQLWarning = DatabaseError.addSqlWarning(this.sqlWarning, "Found Plsql compiler warnings.", 24439);
/*      */     
/* 3369 */     if (this.sqlWarning != null)
/*      */     {
/* 3371 */       this.sqlWarning.setNextWarning(localSQLWarning);
/*      */     }
/*      */     else
/*      */     {
/* 3375 */       this.sqlWarning = localSQLWarning;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursorName(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3387 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 3388 */     localSQLException.fillInStackTrace();
/* 3389 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/* 3402 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3405 */       if (this.userRsetType == 1)
/*      */       {
/* 3407 */         if (this.sqlKind.isSELECT())
/*      */         {
/* 3409 */           if (this.currentResultSet == null) {
/* 3410 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*      */           }
/* 3412 */           return this.currentResultSet;
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/* 3417 */         return this.scrollRset;
/*      */       }
/*      */       
/* 3420 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/* 3437 */     synchronized (this.connection)
/*      */     {
/* 3439 */       int i = -1;
/*      */       
/* 3441 */       switch (this.sqlKind)
/*      */       {
/*      */       case UNINITIALIZED: 
/*      */       case SELECT_FOR_UPDATE: 
/*      */       case SELECT: 
/*      */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case ALTER_SESSION: 
/*      */       case OTHER: 
/* 3452 */         if (!this.noMoreUpdateCounts) {
/* 3453 */           i = this.rowsProcessed;
/*      */         }
/* 3455 */         this.noMoreUpdateCounts = true;
/*      */         
/* 3457 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case PLSQL_BLOCK: 
/*      */       case CALL_BLOCK: 
/* 3463 */         this.noMoreUpdateCounts = true;
/*      */         
/* 3465 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case DELETE: 
/*      */       case INSERT: 
/*      */       case MERGE: 
/*      */       case UPDATE: 
/* 3473 */         if (!this.noMoreUpdateCounts) {
/* 3474 */           i = this.rowsProcessed;
/*      */         }
/* 3476 */         this.noMoreUpdateCounts = true;
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 3481 */       return i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/* 3493 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int sendBatch()
/*      */     throws SQLException
/*      */   {
/* 3504 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareForNewResults(boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLException
/*      */   {
/* 3515 */     clearWarnings();
/*      */     
/* 3517 */     if (this.streamList != null)
/*      */     {
/*      */       Object localObject;
/*      */       
/* 3521 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 3525 */           this.nextStream.close();
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3530 */           localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3531 */           ((SQLException)localObject).fillInStackTrace();
/* 3532 */           throw ((Throwable)localObject);
/*      */         }
/*      */         
/*      */ 
/* 3536 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */       
/* 3539 */       if (paramBoolean2)
/*      */       {
/*      */ 
/* 3542 */         OracleInputStream localOracleInputStream = this.streamList;
/* 3543 */         localObject = null;
/*      */         
/* 3545 */         this.streamList = null;
/*      */         
/* 3547 */         while (localOracleInputStream != null)
/*      */         {
/* 3549 */           if (!localOracleInputStream.hasBeenOpen)
/*      */           {
/* 3551 */             if (localObject == null) {
/* 3552 */               this.streamList = localOracleInputStream;
/*      */             } else {
/* 3554 */               ((OracleInputStream)localObject).nextStream = localOracleInputStream;
/*      */             }
/* 3556 */             localObject = localOracleInputStream;
/*      */           }
/*      */           
/* 3559 */           localOracleInputStream = localOracleInputStream.nextStream;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3564 */     if (this.currentResultSet != null)
/*      */     {
/* 3566 */       this.currentResultSet.internal_close(true);
/*      */       
/* 3568 */       this.currentResultSet = null;
/*      */     }
/*      */     
/* 3571 */     this.currentRow = -1;
/* 3572 */     this.checkSum = 0L;
/* 3573 */     this.checkSumComputationFailure = false;
/* 3574 */     this.validRows = 0;
/* 3575 */     if (paramBoolean1)
/* 3576 */       this.totalRowsVisited = 0;
/* 3577 */     this.gotLastBatch = false;
/*      */     
/* 3579 */     if ((this.needToParse) && (!this.columnsDefinedByUser))
/*      */     {
/* 3581 */       if ((paramBoolean2) && (this.numberOfDefinePositions != 0)) {
/* 3582 */         this.numberOfDefinePositions = 0;
/*      */       }
/* 3584 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/*      */     
/*      */ 
/* 3588 */     if ((paramBoolean1) && (this.rowPrefetch != this.defaultRowPrefetch) && (this.streamList == null))
/*      */     {
/*      */ 
/*      */ 
/* 3592 */       this.rowPrefetch = this.defaultRowPrefetch;
/* 3593 */       this.rowPrefetchChanged = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reopenStreams()
/*      */     throws SQLException
/*      */   {
/* 3607 */     OracleInputStream localOracleInputStream = this.streamList;
/*      */     
/* 3609 */     while (localOracleInputStream != null)
/*      */     {
/* 3611 */       if (localOracleInputStream.hasBeenOpen) {
/* 3612 */         localOracleInputStream = localOracleInputStream.accessor.initForNewRow();
/*      */       }
/* 3614 */       localOracleInputStream.closed = false;
/* 3615 */       localOracleInputStream.hasBeenOpen = true;
/* 3616 */       localOracleInputStream = localOracleInputStream.nextStream;
/*      */     }
/*      */     
/* 3619 */     this.nextStream = this.streamList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void endOfResultSet(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3631 */     if (!paramBoolean)
/*      */     {
/*      */ 
/* 3634 */       prepareForNewResults(false, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3639 */     clearDefines();
/* 3640 */     this.rowPrefetchInLastFetch = -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean wasNullValue()
/*      */     throws SQLException
/*      */   {
/* 3665 */     if (this.lastIndex == 0)
/*      */     {
/* 3667 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/* 3668 */       localSQLException.fillInStackTrace();
/* 3669 */       throw localSQLException;
/*      */     }
/*      */     
/* 3672 */     if (this.sqlKind.isSELECT()) {
/* 3673 */       return this.accessors[(this.lastIndex - 1)].isNull(this.currentRow);
/*      */     }
/* 3675 */     return this.outBindAccessors[(this.lastIndex - 1)].isNull(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getColumnIndex(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3689 */     ensureOpen();
/* 3690 */     if (!this.describedWithNames)
/*      */     {
/* 3692 */       synchronized (this.connection) {
/* 3693 */         doDescribe(true);
/*      */         
/* 3695 */         this.described = true;
/* 3696 */         this.describedWithNames = true;
/*      */       }
/*      */     }
/*      */     
/* 3700 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/* 3701 */       if (this.accessors[i].columnName.equalsIgnoreCase(paramString)) {
/* 3702 */         return i + 1;
/*      */       }
/*      */     }
/* 3705 */     ??? = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3706 */     ((SQLException)???).fillInStackTrace();
/* 3707 */     throw ((Throwable)???);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int getJDBCType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3715 */     int i = 0;
/* 3716 */     switch (paramInt)
/*      */     {
/*      */     case 6: 
/* 3719 */       i = 2;
/* 3720 */       break;
/*      */     case 100: 
/* 3722 */       i = 100;
/* 3723 */       break;
/*      */     case 101: 
/* 3725 */       i = 101;
/* 3726 */       break;
/*      */     case 999: 
/* 3728 */       i = 999;
/* 3729 */       break;
/*      */     case 96: 
/* 3731 */       i = 1;
/* 3732 */       break;
/*      */     case 1: 
/* 3734 */       i = 12;
/* 3735 */       break;
/*      */     case 8: 
/* 3737 */       i = -1;
/* 3738 */       break;
/*      */     case 12: 
/* 3740 */       i = 91;
/* 3741 */       break;
/*      */     case 180: 
/* 3743 */       i = 93;
/* 3744 */       break;
/*      */     case 181: 
/* 3746 */       i = -101;
/* 3747 */       break;
/*      */     case 231: 
/* 3749 */       i = -102;
/* 3750 */       break;
/*      */     case 182: 
/* 3752 */       i = -103;
/* 3753 */       break;
/*      */     case 183: 
/* 3755 */       i = -104;
/* 3756 */       break;
/*      */     case 23: 
/* 3758 */       i = -2;
/* 3759 */       break;
/*      */     case 24: 
/* 3761 */       i = -4;
/* 3762 */       break;
/*      */     case 104: 
/* 3764 */       i = -8;
/* 3765 */       break;
/*      */     case 113: 
/* 3767 */       i = 2004;
/* 3768 */       break;
/*      */     case 112: 
/* 3770 */       i = 2005;
/* 3771 */       break;
/*      */     case 114: 
/* 3773 */       i = -13;
/* 3774 */       break;
/*      */     case 102: 
/* 3776 */       i = -10;
/* 3777 */       break;
/*      */     case 109: 
/* 3779 */       i = 2002;
/* 3780 */       break;
/*      */     case 111: 
/* 3782 */       i = 2006;
/* 3783 */       break;
/*      */     case 998: 
/* 3785 */       i = -14;
/* 3786 */       break;
/*      */     case 995: 
/* 3788 */       i = 0;
/* 3789 */       break;
/*      */     default: 
/* 3791 */       i = paramInt;
/*      */     }
/*      */     
/* 3794 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */   int getInternalType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3801 */     int i = 0;
/*      */     
/* 3803 */     switch (paramInt)
/*      */     {
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 3815 */       i = 6;
/* 3816 */       break;
/*      */     
/*      */     case 100: 
/* 3819 */       i = 100;
/* 3820 */       break;
/*      */     
/*      */     case 101: 
/* 3823 */       i = 101;
/* 3824 */       break;
/*      */     
/*      */     case 999: 
/* 3827 */       i = 999;
/* 3828 */       break;
/*      */     
/*      */     case 1: 
/* 3831 */       i = 96;
/* 3832 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 3838 */       i = 1;
/* 3839 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case -1: 
/* 3845 */       i = 8;
/* 3846 */       break;
/*      */     
/*      */     case 91: 
/*      */     case 92: 
/* 3850 */       i = 12;
/* 3851 */       break;
/*      */     
/*      */     case -100: 
/*      */     case 93: 
/* 3855 */       i = 180;
/* 3856 */       break;
/*      */     
/*      */     case -101: 
/* 3859 */       i = 181;
/* 3860 */       break;
/*      */     
/*      */     case -102: 
/* 3863 */       i = 231;
/* 3864 */       break;
/*      */     
/*      */ 
/*      */     case -103: 
/* 3868 */       i = 182;
/* 3869 */       break;
/*      */     
/*      */     case -104: 
/* 3872 */       i = 183;
/* 3873 */       break;
/*      */     
/*      */     case -3: 
/*      */     case -2: 
/* 3877 */       i = 23;
/* 3878 */       break;
/*      */     
/*      */     case -4: 
/* 3881 */       i = 24;
/* 3882 */       break;
/*      */     
/*      */     case -8: 
/* 3885 */       i = 104;
/* 3886 */       break;
/*      */     
/*      */     case 2004: 
/* 3889 */       i = 113;
/* 3890 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2005: 
/* 3896 */       i = 112;
/* 3897 */       break;
/*      */     
/*      */     case -13: 
/* 3900 */       i = 114;
/* 3901 */       break;
/*      */     
/*      */     case -10: 
/* 3904 */       i = 102;
/* 3905 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2002: 
/*      */     case 2003: 
/*      */     case 2007: 
/*      */     case 2008: 
/* 3914 */       i = 109;
/* 3915 */       break;
/*      */     
/*      */     case 2006: 
/* 3918 */       i = 111;
/* 3919 */       break;
/*      */     
/*      */     case -14: 
/* 3922 */       i = 998;
/* 3923 */       break;
/*      */     
/*      */     case 70: 
/* 3926 */       i = 1;
/* 3927 */       break;
/*      */     
/*      */     case 0: 
/* 3930 */       i = 995;
/* 3931 */       break;
/*      */     
/*      */ 
/*      */     default: 
/* 3935 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.toString(paramInt));
/* 3936 */       localSQLException.fillInStackTrace();
/* 3937 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/* 3941 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void describe()
/*      */     throws SQLException
/*      */   {
/* 3959 */     synchronized (this.connection)
/*      */     {
/* 3961 */       ensureOpen();
/* 3962 */       if (!this.described)
/*      */       {
/* 3964 */         doDescribe(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void freeLine()
/*      */     throws SQLException
/*      */   {
/* 3973 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 3977 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 3981 */           this.nextStream.close();
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3986 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3987 */           localSQLException.fillInStackTrace();
/* 3988 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 3992 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeUsedStreams(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4005 */     while ((this.nextStream != null) && (this.nextStream.columnIndex < paramInt))
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/* 4011 */         this.nextStream.close();
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 4016 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4017 */         localSQLException.fillInStackTrace();
/* 4018 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 4022 */       this.nextStream = this.nextStream.nextStream;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final void ensureOpen()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/* 4034 */     if (this.connection.lifecycle != 1)
/*      */     {
/* 4036 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4037 */       localSQLException.fillInStackTrace();
/* 4038 */       throw localSQLException;
/*      */     }
/* 4040 */     if (this.closed)
/*      */     {
/* 4042 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4043 */       localSQLException.fillInStackTrace();
/* 4044 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4078 */     synchronized (this.connection)
/*      */     {
/* 4080 */       if (paramInt == 1000)
/*      */       {
/*      */ 
/* 4083 */         this.defaultFetchDirection = paramInt;
/*      */       }
/* 4085 */       else if ((paramInt == 1001) || (paramInt == 1002))
/*      */       {
/*      */ 
/* 4088 */         this.defaultFetchDirection = 1000;
/* 4089 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 4095 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 4096 */         localSQLException.fillInStackTrace();
/* 4097 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 4120 */     return this.defaultFetchDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4139 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 4142 */       setPrefetchInternal(paramInt, false, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 4165 */     return getPrefetchInternal(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/* 4177 */     return ResultSetUtil.getUpdateConcurrency(this.userRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetType()
/*      */     throws SQLException
/*      */   {
/* 4189 */     return ResultSetUtil.getScrollType(this.userRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 4204 */     return this.connection.getWrapper();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResultSetCache(oracle.jdbc.OracleResultSetCache paramOracleResultSetCache)
/*      */     throws SQLException
/*      */   {
/* 4217 */     synchronized (this.connection)
/*      */     {
/*      */       try
/*      */       {
/* 4221 */         if (paramOracleResultSetCache == null)
/*      */         {
/* 4223 */           SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4224 */           localSQLException1.fillInStackTrace();
/* 4225 */           throw localSQLException1;
/*      */         }
/*      */         
/* 4228 */         if (this.rsetCache != null) {
/* 4229 */           this.rsetCache.close();
/*      */         }
/* 4231 */         this.rsetCache = paramOracleResultSetCache;
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 4236 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4237 */         localSQLException2.fillInStackTrace();
/* 4238 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache)
/*      */     throws SQLException
/*      */   {
/* 4255 */     synchronized (this.connection)
/*      */     {
/* 4257 */       setResultSetCache(paramOracleResultSetCache);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public OracleResultSetCache getResultSetCache()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 71	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 326	oracle/jdbc/driver/OracleStatement:rsetCache	Loracle/jdbc/OracleResultSetCache;
/*      */     //   11: checkcast 329	oracle/jdbc/driver/OracleResultSetCache
/*      */     //   14: aload_1
/*      */     //   15: monitorexit
/*      */     //   16: areturn
/*      */     //   17: astore_2
/*      */     //   18: aload_1
/*      */     //   19: monitorexit
/*      */     //   20: aload_2
/*      */     //   21: athrow
/*      */     // Line number table:
/*      */     //   Java source line #4268	-> byte code offset #0
/*      */     //   Java source line #4270	-> byte code offset #7
/*      */     //   Java source line #4272	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	22	0	this	OracleStatement
/*      */     //   5	14	1	Ljava/lang/Object;	Object
/*      */     //   17	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	16	17	finally
/*      */     //   17	20	17	finally
/*      */   }
/*      */   
/*      */   boolean isOracleBatchStyle()
/*      */   {
/* 4279 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4303 */   Vector m_batchItems = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void initBatch() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int getBatchSize()
/*      */   {
/* 4315 */     if (this.m_batchItems == null)
/*      */     {
/* 4317 */       return 0;
/*      */     }
/*      */     
/*      */ 
/* 4321 */     return this.m_batchItems.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void addBatchItem(String paramString)
/*      */   {
/* 4329 */     if (this.m_batchItems == null)
/*      */     {
/* 4331 */       this.m_batchItems = new Vector();
/*      */     }
/* 4333 */     this.m_batchItems.addElement(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   String getBatchItem(int paramInt)
/*      */   {
/* 4340 */     return (String)this.m_batchItems.elementAt(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void clearBatchItems()
/*      */   {
/* 4347 */     this.m_batchItems.removeAllElements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkIfJdbcBatchExists()
/*      */     throws SQLException
/*      */   {
/* 4363 */     if (getBatchSize() > 0)
/*      */     {
/*      */ 
/* 4366 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/* 4367 */       localSQLException.fillInStackTrace();
/* 4368 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4394 */     synchronized (this.connection)
/*      */     {
/* 4396 */       addBatchItem(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearBatch()
/*      */     throws SQLException
/*      */   {
/* 4411 */     synchronized (this.connection)
/*      */     {
/* 4413 */       clearBatchItems();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 4444 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4448 */       cleanOldTempLobs();
/* 4449 */       int i = 0;
/* 4450 */       int j = getBatchSize();
/* 4451 */       this.checkSum = 0L;
/* 4452 */       this.checkSumComputationFailure = false;
/*      */       
/*      */ 
/*      */ 
/* 4456 */       if (j <= 0)
/*      */       {
/*      */ 
/*      */ 
/* 4460 */         return new int[0];
/*      */       }
/*      */       
/* 4463 */       int[] arrayOfInt = new int[j];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4469 */       ensureOpen();
/*      */       
/*      */ 
/* 4472 */       prepareForNewResults(true, true);
/*      */       
/* 4474 */       int k = this.numberOfDefinePositions;
/* 4475 */       String str = this.sqlObject.getOriginalSql();
/* 4476 */       OracleStatement.SqlKind localSqlKind = this.sqlKind;
/*      */       
/*      */ 
/* 4479 */       this.noMoreUpdateCounts = false;
/*      */       
/* 4481 */       int m = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 4490 */         this.connection.registerHeartbeat();
/*      */         
/* 4492 */         this.connection.needLine();
/*      */         
/* 4494 */         for (i = 0; i < j; i++)
/*      */         {
/* 4496 */           this.sqlObject.initialize(getBatchItem(i));
/*      */           
/* 4498 */           this.sqlKind = this.sqlObject.getSqlKind();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4504 */           this.needToParse = true;
/* 4505 */           this.numberOfDefinePositions = 0;
/*      */           
/*      */ 
/* 4508 */           this.rowsProcessed = 0;
/* 4509 */           this.currentRank = 1;
/*      */           
/* 4511 */           if (this.sqlKind.isSELECT())
/*      */           {
/*      */ 
/* 4514 */             BatchUpdateException localBatchUpdateException1 = DatabaseError.createBatchUpdateException(80, "invalid SELECT batch command " + i, i, arrayOfInt);
/*      */             
/* 4516 */             localBatchUpdateException1.fillInStackTrace();
/* 4517 */             throw localBatchUpdateException1;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 4522 */           if (!this.isOpen)
/*      */           {
/* 4524 */             this.connection.open(this);
/*      */             
/* 4526 */             this.isOpen = true;
/*      */           }
/*      */           
/* 4529 */           int n = -1;
/*      */           
/*      */           try
/*      */           {
/* 4533 */             if (this.queryTimeout != 0) {
/* 4534 */               this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/*      */             }
/* 4536 */             this.cancelLock.enterExecuting();
/*      */             
/* 4538 */             executeForRows(false);
/*      */             
/* 4540 */             if (this.validRows > 0) {
/* 4541 */               m += this.validRows;
/*      */             }
/* 4543 */             n = this.validRows;
/*      */           }
/*      */           catch (SQLException localSQLException2)
/*      */           {
/* 4547 */             this.needToParse = true;
/* 4548 */             resetCurrentRowBinders();
/* 4549 */             throw localSQLException2;
/*      */           }
/*      */           finally
/*      */           {
/* 4553 */             if (this.queryTimeout != 0) {
/* 4554 */               this.connection.getTimeout().cancelTimeout();
/*      */             }
/* 4556 */             this.validRows = m;
/*      */             
/* 4558 */             this.cancelLock.exitExecuting();
/*      */             
/* 4560 */             checkValidRowsStatus();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 4565 */           arrayOfInt[i] = n;
/*      */           
/* 4567 */           if (arrayOfInt[i] < 0)
/*      */           {
/*      */ 
/* 4570 */             localBatchUpdateException2 = DatabaseError.createBatchUpdateException(81, "command return value " + arrayOfInt[i], i, arrayOfInt);
/*      */             
/* 4572 */             localBatchUpdateException2.fillInStackTrace();
/* 4573 */             throw localBatchUpdateException2;
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */       catch (SQLException localSQLException1)
/*      */       {
/* 4580 */         if ((localSQLException1 instanceof BatchUpdateException))
/*      */         {
/* 4582 */           throw localSQLException1;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4587 */         BatchUpdateException localBatchUpdateException2 = DatabaseError.createBatchUpdateException(81, localSQLException1.getMessage(), i, arrayOfInt);
/* 4588 */         localBatchUpdateException2.fillInStackTrace();
/* 4589 */         throw localBatchUpdateException2;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/* 4595 */         clearBatchItems();
/*      */         
/* 4597 */         this.numberOfDefinePositions = k;
/*      */         
/* 4599 */         if (str != null)
/*      */         {
/* 4601 */           this.sqlObject.initialize(str);
/*      */           
/* 4603 */           this.sqlKind = localSqlKind;
/*      */         }
/*      */         
/* 4606 */         this.currentRank = 0;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4613 */       this.connection.registerHeartbeat();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4619 */       return arrayOfInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int copyBinds(Statement paramStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4640 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyCloseRset()
/*      */     throws SQLException
/*      */   {
/* 4651 */     this.scrollRset = null;
/* 4652 */     endOfResultSet(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getOriginalSql()
/*      */     throws SQLException
/*      */   {
/* 4662 */     return this.sqlObject.getOriginalSql();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doScrollExecuteCommon()
/*      */     throws SQLException
/*      */   {
/* 4672 */     if (this.scrollRset != null)
/*      */     {
/* 4674 */       this.scrollRset.close();
/*      */       
/* 4676 */       this.scrollRset = null;
/*      */     }
/*      */     
/*      */ 
/* 4680 */     if (!this.sqlKind.isSELECT())
/*      */     {
/* 4682 */       doExecuteWithTimeout();
/*      */       
/* 4684 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4690 */     if (!this.needToAddIdentifier)
/*      */     {
/*      */ 
/*      */ 
/* 4694 */       doExecuteWithTimeout();
/*      */       
/* 4696 */       this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4697 */       this.realRsetType = this.userRsetType;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/* 4705 */         this.sqlObject.setIncludeRowid(true);
/*      */         
/* 4707 */         this.needToParse = true;
/*      */         
/*      */ 
/*      */ 
/* 4711 */         prepareForNewResults(true, false);
/*      */         
/* 4713 */         if (this.columnsDefinedByUser)
/*      */         {
/* 4715 */           Accessor[] arrayOfAccessor = this.accessors;
/*      */           
/* 4717 */           if ((this.accessors == null) || (this.accessors.length <= this.numberOfDefinePositions)) {
/* 4718 */             this.accessors = new Accessor[this.numberOfDefinePositions + 1];
/*      */           }
/* 4720 */           if (arrayOfAccessor != null) {
/* 4721 */             for (i = this.numberOfDefinePositions; i > 0; i--)
/*      */             {
/* 4723 */               localAccessor = arrayOfAccessor[(i - 1)];
/*      */               
/* 4725 */               this.accessors[i] = localAccessor;
/*      */               
/* 4727 */               if (localAccessor.isColumnNumberAware)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 4732 */                 localAccessor.updateColumnNumber(i);
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 4737 */           allocateRowidAccessor();
/*      */           
/* 4739 */           this.numberOfDefinePositions += 1;
/*      */         }
/*      */         
/* 4742 */         doExecuteWithTimeout();
/*      */         
/* 4744 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4745 */         this.realRsetType = this.userRsetType;
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/*      */         int i;
/*      */         
/*      */ 
/*      */         Accessor localAccessor;
/*      */         
/* 4754 */         if (this.userRsetType > 3) {
/* 4755 */           this.realRsetType = 3;
/*      */         } else {
/* 4757 */           this.realRsetType = 1;
/*      */         }
/* 4759 */         this.sqlObject.setIncludeRowid(false);
/*      */         
/* 4761 */         this.needToParse = true;
/*      */         
/*      */ 
/*      */ 
/* 4765 */         prepareForNewResults(true, false);
/*      */         
/* 4767 */         if (this.columnsDefinedByUser)
/*      */         {
/* 4769 */           this.needToPrepareDefineBuffer = true;
/* 4770 */           this.numberOfDefinePositions -= 1;
/*      */           
/* 4772 */           System.arraycopy(this.accessors, 1, this.accessors, 0, this.numberOfDefinePositions);
/*      */           
/* 4774 */           this.accessors[this.numberOfDefinePositions] = null;
/*      */           
/* 4776 */           for (i = 0; i < this.numberOfDefinePositions; i++)
/*      */           {
/* 4778 */             localAccessor = this.accessors[i];
/*      */             
/* 4780 */             if (localAccessor.isColumnNumberAware)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 4785 */               localAccessor.updateColumnNumber(i);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4792 */         moveAllTempLobsToFree();
/* 4793 */         doExecuteWithTimeout();
/*      */         
/* 4795 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4796 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 91, localSQLException.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4804 */     this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/* 4818 */     this.accessors[0] = new RowidAccessor(this, 128, 1, -8, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleResultSet doScrollStmtExecuteQuery()
/*      */     throws SQLException
/*      */   {
/* 4827 */     doScrollExecuteCommon();
/*      */     
/* 4829 */     return this.scrollRset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void processDmlReturningBind()
/*      */     throws SQLException
/*      */   {
/* 4839 */     if (this.returnResultSet != null) { this.returnResultSet.close();
/*      */     }
/* 4841 */     this.returnParamsFetched = false;
/* 4842 */     this.returnParamRowBytes = 0;
/* 4843 */     this.returnParamRowChars = 0;
/*      */     
/* 4845 */     int i = 0;
/* 4846 */     for (int j = 0; j < this.numberOfBindPositions; j++)
/*      */     {
/* 4848 */       Accessor localAccessor = this.returnParamAccessors[j];
/*      */       
/* 4850 */       if (localAccessor != null)
/*      */       {
/* 4852 */         i++;
/*      */         
/* 4854 */         if (localAccessor.charLength > 0)
/*      */         {
/* 4856 */           this.returnParamRowChars += localAccessor.charLength;
/*      */         }
/*      */         else
/*      */         {
/* 4860 */           this.returnParamRowBytes += localAccessor.byteLength;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4865 */     if (this.isAutoGeneratedKey)
/*      */     {
/* 4867 */       this.numReturnParams = i;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 4872 */       if (this.numReturnParams <= 0) {
/* 4873 */         this.numReturnParams = this.sqlObject.getReturnParameterCount();
/*      */       }
/* 4875 */       if (this.numReturnParams != i)
/*      */       {
/* 4877 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173);
/* 4878 */         localSQLException.fillInStackTrace();
/* 4879 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4884 */     this.returnParamMeta[0] = this.numReturnParams;
/* 4885 */     this.returnParamMeta[1] = this.returnParamRowBytes;
/* 4886 */     this.returnParamMeta[2] = this.returnParamRowChars;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateDmlReturnStorage()
/*      */   {
/* 4894 */     if (this.rowsDmlReturned == 0) { return;
/*      */     }
/* 4896 */     int i = this.returnParamRowBytes * this.rowsDmlReturned;
/* 4897 */     int j = this.returnParamRowChars * this.rowsDmlReturned;
/* 4898 */     int k = 2 * this.numReturnParams * this.rowsDmlReturned;
/*      */     
/* 4900 */     this.returnParamBytes = new byte[i];
/* 4901 */     this.returnParamChars = new char[j];
/* 4902 */     this.returnParamIndicators = new short[k];
/*      */     
/*      */ 
/* 4905 */     for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */     {
/* 4907 */       Accessor localAccessor = this.returnParamAccessors[m];
/*      */       
/*      */ 
/* 4910 */       if ((localAccessor != null) && ((localAccessor.internalType == 111) || (localAccessor.internalType == 109)))
/*      */       {
/*      */ 
/*      */ 
/* 4914 */         TypeAccessor localTypeAccessor = (TypeAccessor)localAccessor;
/* 4915 */         if ((localTypeAccessor.pickledBytes == null) || (localTypeAccessor.pickledBytes.length < this.rowsDmlReturned))
/*      */         {
/* 4917 */           localTypeAccessor.pickledBytes = new byte[this.rowsDmlReturned][];
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetchDmlReturnParams()
/*      */     throws SQLException
/*      */   {
/* 4931 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 4932 */     localSQLException.fillInStackTrace();
/* 4933 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setupReturnParamAccessors()
/*      */   {
/* 4943 */     if (this.rowsDmlReturned == 0) { return;
/*      */     }
/* 4945 */     int i = 0;
/* 4946 */     int j = 0;
/* 4947 */     int k = 0;
/* 4948 */     int m = this.numReturnParams * this.rowsDmlReturned;
/*      */     
/* 4950 */     for (int n = 0; n < this.numberOfBindPositions; n++)
/*      */     {
/* 4952 */       Accessor localAccessor = this.returnParamAccessors[n];
/*      */       
/* 4954 */       if (localAccessor != null)
/*      */       {
/* 4956 */         if (localAccessor.charLength > 0)
/*      */         {
/* 4958 */           localAccessor.rowSpaceChar = this.returnParamChars;
/* 4959 */           localAccessor.columnIndex = j;
/* 4960 */           j += this.rowsDmlReturned * localAccessor.charLength;
/*      */         }
/*      */         else
/*      */         {
/* 4964 */           localAccessor.rowSpaceByte = this.returnParamBytes;
/* 4965 */           localAccessor.columnIndex = i;
/* 4966 */           i += this.rowsDmlReturned * localAccessor.byteLength;
/*      */         }
/*      */         
/* 4969 */         localAccessor.rowSpaceIndicator = this.returnParamIndicators;
/* 4970 */         localAccessor.indicatorIndex = k;
/* 4971 */         k += this.rowsDmlReturned;
/* 4972 */         localAccessor.lengthIndex = m;
/* 4973 */         m += this.rowsDmlReturned;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void registerReturnParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString)
/*      */     throws SQLException
/*      */   {
/* 4989 */     if (this.returnParamAccessors == null) {
/* 4990 */       this.returnParamAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/* 4992 */     if (this.returnParamMeta == null)
/*      */     {
/* 4994 */       this.returnParamMeta = new int[3 + this.numberOfBindPositions * 4];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5003 */     Accessor localAccessor = allocateAccessor(paramInt2, paramInt3, paramInt1 + 1, paramInt4, paramShort, paramString, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5011 */     localAccessor.isDMLReturnedParam = true;
/* 5012 */     this.returnParamAccessors[paramInt1] = localAccessor;
/*      */     
/* 5014 */     int i = localAccessor.charLength > 0 ? 1 : 0;
/*      */     
/*      */ 
/* 5017 */     this.returnParamMeta[(3 + paramInt1 * 4 + 0)] = localAccessor.defineType;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5022 */     this.returnParamMeta[(3 + paramInt1 * 4 + 1)] = (i != 0 ? 1 : 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5027 */     this.returnParamMeta[(3 + paramInt1 * 4 + 2)] = (i != 0 ? localAccessor.charLength : localAccessor.byteLength);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5032 */     this.returnParamMeta[(3 + paramInt1 * 4 + 3)] = paramShort;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int creationState()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 71	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 51	oracle/jdbc/driver/OracleStatement:creationState	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5053	-> byte code offset #0
/*      */     //   Java source line #5055	-> byte code offset #7
/*      */     //   Java source line #5057	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public boolean isColumnSetNull(int paramInt)
/*      */   {
/* 5074 */     return this.columnSetNull;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5092 */     if (!this.described) {
/* 5093 */       describe();
/*      */     }
/* 5095 */     int i = paramInt - 1;
/* 5096 */     if ((i < 0) || (i >= this.numberOfDefinePositions))
/*      */     {
/* 5098 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 5099 */       localSQLException.fillInStackTrace();
/* 5100 */       throw localSQLException;
/*      */     }
/*      */     
/* 5103 */     boolean bool = this.accessors[i].formOfUse == 2;
/*      */     
/*      */ 
/* 5106 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void addChild(OracleStatement paramOracleStatement)
/*      */   {
/* 5114 */     paramOracleStatement.nextChild = this.children;
/* 5115 */     this.children = paramOracleStatement;
/* 5116 */     paramOracleStatement.parent = this;
/*      */   }
/*      */   
/*      */ 
/*      */   void removeChild(OracleStatement paramOracleStatement)
/*      */   {
/* 5122 */     if (paramOracleStatement == this.children) {
/* 5123 */       this.children = paramOracleStatement.nextChild;
/*      */     }
/*      */     else {
/* 5126 */       OracleStatement localOracleStatement = this.children;
/* 5127 */       while (localOracleStatement.nextChild != paramOracleStatement) {
/* 5128 */         localOracleStatement = localOracleStatement.nextChild;
/*      */       }
/* 5130 */       localOracleStatement.nextChild = paramOracleStatement.nextChild;
/*      */     }
/* 5132 */     paramOracleStatement.parent = null;
/* 5133 */     paramOracleStatement.nextChild = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5170 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 5171 */     localSQLException.fillInStackTrace();
/* 5172 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5193 */     if (this.closed)
/*      */     {
/* 5195 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 5196 */       localSQLException.fillInStackTrace();
/* 5197 */       throw localSQLException;
/*      */     }
/*      */     
/* 5200 */     if (!this.isAutoGeneratedKey)
/*      */     {
/* 5202 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 5203 */       localSQLException.fillInStackTrace();
/* 5204 */       throw localSQLException;
/*      */     }
/*      */     
/* 5207 */     if ((this.returnParamAccessors == null) || (this.numReturnParams == 0))
/*      */     {
/* 5209 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 5210 */       localSQLException.fillInStackTrace();
/* 5211 */       throw localSQLException;
/*      */     }
/*      */     
/* 5214 */     if (this.returnResultSet == null)
/*      */     {
/* 5216 */       this.returnResultSet = new OracleReturnResultSet(this);
/*      */     }
/*      */     
/* 5219 */     return this.returnResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5252 */     this.autoKeyInfo = new AutoKeyInfo(paramString);
/* 5253 */     if ((paramInt == 2) || (!this.autoKeyInfo.isInsertSqlStmt()))
/*      */     {
/*      */ 
/* 5256 */       this.autoKeyInfo = null;
/* 5257 */       return executeUpdate(paramString);
/*      */     }
/*      */     
/* 5260 */     if (paramInt != 1)
/*      */     {
/* 5262 */       this.autoKeyInfo = null;
/*      */       
/* 5264 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5265 */       localSQLException.fillInStackTrace();
/* 5266 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 5270 */     synchronized (this.connection) {
/* 5271 */       this.isAutoGeneratedKey = true;
/* 5272 */       String str = this.autoKeyInfo.getNewSql();
/* 5273 */       this.numberOfBindPositions = 1;
/*      */       
/*      */ 
/* 5276 */       autoKeyRegisterReturnParams();
/*      */       
/* 5278 */       processDmlReturningBind();
/*      */       
/* 5280 */       return executeUpdateInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 5309 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0))
/*      */     {
/* 5311 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5312 */       localSQLException.fillInStackTrace();
/* 5313 */       throw localSQLException;
/*      */     }
/*      */     
/* 5316 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfInt);
/* 5317 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5319 */       this.autoKeyInfo = null;
/* 5320 */       return executeUpdate(paramString);
/*      */     }
/*      */     
/* 5323 */     synchronized (this.connection) {
/* 5324 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5327 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5329 */       String str = this.autoKeyInfo.getNewSql();
/* 5330 */       this.numberOfBindPositions = paramArrayOfInt.length;
/*      */       
/*      */ 
/* 5333 */       autoKeyRegisterReturnParams();
/*      */       
/* 5335 */       processDmlReturningBind();
/*      */       
/* 5337 */       return executeUpdateInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, String[] paramArrayOfString)
/*      */     throws SQLException
/*      */   {
/* 5365 */     if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
/*      */     {
/* 5367 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5368 */       localSQLException.fillInStackTrace();
/* 5369 */       throw localSQLException;
/*      */     }
/*      */     
/* 5372 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/* 5373 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5375 */       this.autoKeyInfo = null;
/* 5376 */       return executeUpdate(paramString);
/*      */     }
/*      */     
/* 5379 */     synchronized (this.connection) {
/* 5380 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5383 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5385 */       String str = this.autoKeyInfo.getNewSql();
/* 5386 */       this.numberOfBindPositions = paramArrayOfString.length;
/*      */       
/*      */ 
/* 5389 */       autoKeyRegisterReturnParams();
/*      */       
/* 5391 */       processDmlReturningBind();
/*      */       
/* 5393 */       return executeUpdateInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5440 */     this.autoKeyInfo = new AutoKeyInfo(paramString);
/* 5441 */     if ((paramInt == 2) || (!this.autoKeyInfo.isInsertSqlStmt()))
/*      */     {
/*      */ 
/* 5444 */       this.autoKeyInfo = null;
/* 5445 */       return execute(paramString);
/*      */     }
/*      */     
/* 5448 */     if (paramInt != 1)
/*      */     {
/* 5450 */       this.autoKeyInfo = null;
/*      */       
/* 5452 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5453 */       localSQLException.fillInStackTrace();
/* 5454 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 5458 */     synchronized (this.connection) {
/* 5459 */       this.isAutoGeneratedKey = true;
/* 5460 */       String str = this.autoKeyInfo.getNewSql();
/* 5461 */       this.numberOfBindPositions = 1;
/*      */       
/*      */ 
/* 5464 */       autoKeyRegisterReturnParams();
/*      */       
/* 5466 */       processDmlReturningBind();
/*      */       
/* 5468 */       return executeInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 5514 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0))
/*      */     {
/* 5516 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5517 */       localSQLException.fillInStackTrace();
/* 5518 */       throw localSQLException;
/*      */     }
/*      */     
/* 5521 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfInt);
/* 5522 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5524 */       this.autoKeyInfo = null;
/* 5525 */       return execute(paramString);
/*      */     }
/*      */     
/* 5528 */     synchronized (this.connection) {
/* 5529 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5532 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5534 */       String str = this.autoKeyInfo.getNewSql();
/* 5535 */       this.numberOfBindPositions = paramArrayOfInt.length;
/*      */       
/*      */ 
/* 5538 */       autoKeyRegisterReturnParams();
/*      */       
/* 5540 */       processDmlReturningBind();
/*      */       
/* 5542 */       return executeInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, String[] paramArrayOfString)
/*      */     throws SQLException
/*      */   {
/* 5589 */     if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
/*      */     {
/* 5591 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5592 */       localSQLException.fillInStackTrace();
/* 5593 */       throw localSQLException;
/*      */     }
/*      */     
/* 5596 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/* 5597 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5599 */       this.autoKeyInfo = null;
/* 5600 */       return execute(paramString);
/*      */     }
/*      */     
/* 5603 */     synchronized (this.connection) {
/* 5604 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5607 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5609 */       String str = this.autoKeyInfo.getNewSql();
/* 5610 */       this.numberOfBindPositions = paramArrayOfString.length;
/*      */       
/*      */ 
/* 5613 */       autoKeyRegisterReturnParams();
/*      */       
/* 5615 */       processDmlReturningBind();
/*      */       
/* 5617 */       return executeInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 5637 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getcacheState()
/*      */   {
/* 5644 */     return this.cacheState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getstatementType()
/*      */   {
/* 5651 */     return this.statementType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getserverCursor()
/*      */   {
/* 5658 */     return this.serverCursor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void initializeIndicatorSubRange()
/*      */   {
/* 5666 */     this.bindIndicatorSubRange = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void autoKeyRegisterReturnParams()
/*      */     throws SQLException
/*      */   {
/* 5677 */     initializeIndicatorSubRange();
/*      */     
/* 5679 */     int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5685 */     int j = i + 2 * this.numberOfBindPositions;
/*      */     
/*      */ 
/*      */ 
/* 5689 */     this.bindIndicators = new short[j];
/*      */     
/* 5691 */     int k = this.bindIndicatorSubRange;
/*      */     
/* 5693 */     this.bindIndicators[(k + 0)] = ((short)this.numberOfBindPositions);
/*      */     
/*      */ 
/*      */ 
/* 5697 */     this.bindIndicators[(k + 1)] = 0;
/*      */     
/*      */ 
/*      */ 
/* 5701 */     this.bindIndicators[(k + 2)] = 1;
/*      */     
/*      */ 
/*      */ 
/* 5705 */     this.bindIndicators[(k + 3)] = 0;
/*      */     
/*      */ 
/*      */ 
/* 5709 */     this.bindIndicators[(k + 4)] = 1;
/*      */     
/*      */ 
/*      */ 
/* 5713 */     k += 5;
/*      */     
/*      */ 
/* 5716 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 5717 */     int[] arrayOfInt = this.autoKeyInfo.columnIndexes;
/*      */     
/* 5719 */     for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */     {
/* 5721 */       this.bindIndicators[(k + 0)] = 994;
/*      */       
/*      */ 
/*      */ 
/* 5725 */       short s = this.connection.defaultnchar ? 2 : 1;
/*      */       
/*      */ 
/* 5728 */       if ((arrayOfShort != null) && (arrayOfInt != null))
/*      */       {
/* 5730 */         if (arrayOfShort[(arrayOfInt[m] - 1)] == 2)
/*      */         {
/*      */ 
/* 5733 */           s = 2;
/* 5734 */           this.bindIndicators[(k + 9)] = s;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5740 */       k += 10;
/*      */       
/*      */ 
/* 5743 */       checkTypeForAutoKey(this.autoKeyInfo.returnTypes[m]);
/*      */       
/* 5745 */       String str = null;
/* 5746 */       if (this.autoKeyInfo.returnTypes[m] == 111) {
/* 5747 */         str = this.autoKeyInfo.tableTypeNames[(arrayOfInt[m] - 1)];
/*      */       }
/*      */       
/* 5750 */       registerReturnParameterInternal(m, this.autoKeyInfo.returnTypes[m], this.autoKeyInfo.returnTypes[m], -1, s, str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void setNonAutoKey()
/*      */   {
/* 5760 */     this.isAutoGeneratedKey = false;
/* 5761 */     this.numberOfBindPositions = 0;
/* 5762 */     this.bindIndicators = null;
/* 5763 */     this.returnParamMeta = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 5780 */     if (paramArrayOfChar != this.defineChars) this.connection.cacheBuffer(paramArrayOfChar);
/* 5781 */     if (paramArrayOfByte != this.defineBytes) { this.connection.cacheBuffer(paramArrayOfByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   final void checkTypeForAutoKey(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5789 */     if (paramInt == 109)
/*      */     {
/* 5791 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 5);
/* 5792 */       localSQLException.fillInStackTrace();
/* 5793 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 5798 */   ArrayList tempClobsToFree = null;
/* 5799 */   ArrayList tempBlobsToFree = null;
/*      */   
/* 5801 */   ArrayList oldTempClobsToFree = null;
/* 5802 */   ArrayList oldTempBlobsToFree = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void moveAllTempLobsToFree()
/*      */   {
/* 5814 */     if (this.oldTempClobsToFree != null)
/*      */     {
/* 5816 */       if (this.tempClobsToFree == null) {
/* 5817 */         this.tempClobsToFree = this.oldTempClobsToFree;
/*      */       } else {
/* 5819 */         this.tempClobsToFree.add(this.oldTempClobsToFree);
/*      */       }
/* 5821 */       this.oldTempClobsToFree = null;
/*      */     }
/*      */     
/* 5824 */     if (this.oldTempBlobsToFree != null)
/*      */     {
/* 5826 */       if (this.tempBlobsToFree == null) {
/* 5827 */         this.tempBlobsToFree = this.oldTempBlobsToFree;
/*      */       } else {
/* 5829 */         this.tempBlobsToFree.add(this.oldTempBlobsToFree);
/*      */       }
/* 5831 */       this.oldTempBlobsToFree = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void moveTempLobsToFree(CLOB paramCLOB)
/*      */   {
/*      */     int i;
/*      */     
/* 5841 */     if ((this.oldTempClobsToFree != null) && 
/* 5842 */       ((i = this.oldTempClobsToFree.indexOf(paramCLOB)) != -1))
/*      */     {
/* 5844 */       addToTempLobsToFree(paramCLOB);
/* 5845 */       this.oldTempClobsToFree.remove(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void moveTempLobsToFree(BLOB paramBLOB)
/*      */   {
/*      */     int i;
/*      */     
/* 5855 */     if ((this.oldTempBlobsToFree != null) && 
/* 5856 */       ((i = this.oldTempBlobsToFree.indexOf(paramBLOB)) != -1))
/*      */     {
/* 5858 */       addToTempLobsToFree(paramBLOB);
/* 5859 */       this.oldTempBlobsToFree.remove(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void addToTempLobsToFree(CLOB paramCLOB)
/*      */   {
/* 5868 */     if (this.tempClobsToFree == null)
/* 5869 */       this.tempClobsToFree = new ArrayList();
/* 5870 */     this.tempClobsToFree.add(paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToTempLobsToFree(BLOB paramBLOB)
/*      */   {
/* 5877 */     if (this.tempBlobsToFree == null)
/* 5878 */       this.tempBlobsToFree = new ArrayList();
/* 5879 */     this.tempBlobsToFree.add(paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToOldTempLobsToFree(CLOB paramCLOB)
/*      */   {
/* 5886 */     if (this.oldTempClobsToFree == null)
/* 5887 */       this.oldTempClobsToFree = new ArrayList();
/* 5888 */     this.oldTempClobsToFree.add(paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToOldTempLobsToFree(BLOB paramBLOB)
/*      */   {
/* 5895 */     if (this.oldTempBlobsToFree == null)
/* 5896 */       this.oldTempBlobsToFree = new ArrayList();
/* 5897 */     this.oldTempBlobsToFree.add(paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanAllTempLobs()
/*      */   {
/* 5904 */     cleanTempClobs(this.tempClobsToFree);
/* 5905 */     this.tempClobsToFree = null;
/* 5906 */     cleanTempBlobs(this.tempBlobsToFree);
/* 5907 */     this.tempBlobsToFree = null;
/* 5908 */     cleanTempClobs(this.oldTempClobsToFree);
/* 5909 */     this.oldTempClobsToFree = null;
/* 5910 */     cleanTempBlobs(this.oldTempBlobsToFree);
/* 5911 */     this.oldTempBlobsToFree = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanOldTempLobs()
/*      */   {
/* 5918 */     cleanTempClobs(this.oldTempClobsToFree);
/* 5919 */     cleanTempBlobs(this.oldTempBlobsToFree);
/* 5920 */     this.oldTempClobsToFree = this.tempClobsToFree;
/* 5921 */     this.tempClobsToFree = null;
/* 5922 */     this.oldTempBlobsToFree = this.tempBlobsToFree;
/* 5923 */     this.tempBlobsToFree = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanTempClobs(ArrayList paramArrayList)
/*      */   {
/* 5930 */     if (paramArrayList != null)
/*      */     {
/* 5932 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 5934 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 5938 */           ((CLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void cleanTempBlobs(ArrayList paramArrayList)
/*      */   {
/* 5953 */     if (paramArrayList != null)
/*      */     {
/* 5955 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 5957 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 5961 */           ((BLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   TimeZone getDefaultTimeZone()
/*      */     throws SQLException
/*      */   {
/* 5981 */     return getDefaultTimeZone(false);
/*      */   }
/*      */   
/*      */   TimeZone getDefaultTimeZone(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 5987 */     if (this.defaultTimeZone == null)
/*      */     {
/*      */       try {
/* 5990 */         this.defaultTimeZone = this.connection.getDefaultTimeZone();
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */       
/*      */ 
/* 5995 */       if (this.defaultTimeZone == null) {
/* 5996 */         this.defaultTimeZone = TimeZone.getDefault();
/*      */       }
/*      */     }
/* 5999 */     return this.defaultTimeZone;
/*      */   }
/*      */   
/*      */ 
/* 6003 */   NTFDCNRegistration registration = null;
/* 6004 */   String[] dcnTableName = null;
/* 6005 */   long dcnQueryId = -1L;
/*      */   
/*      */   public void setDatabaseChangeRegistration(DatabaseChangeRegistration paramDatabaseChangeRegistration)
/*      */     throws SQLException
/*      */   {
/* 6010 */     this.registration = ((NTFDCNRegistration)paramDatabaseChangeRegistration);
/*      */   }
/*      */   
/*      */   public String[] getRegisteredTableNames() throws SQLException
/*      */   {
/* 6015 */     return this.dcnTableName;
/*      */   }
/*      */   
/*      */   public long getRegisteredQueryId() throws SQLException {
/* 6019 */     return this.dcnQueryId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Calendar getDefaultCalendar()
/*      */     throws SQLException
/*      */   {
/* 6027 */     if (this.defaultCalendar == null)
/*      */     {
/* 6029 */       this.defaultCalendar = Calendar.getInstance(getDefaultTimeZone(), Locale.US);
/*      */     }
/*      */     
/* 6032 */     return this.defaultCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/* 6038 */     this.cachedDefineIndicatorSize = (this.defineIndicators != null ? this.defineIndicators.length : 0);
/* 6039 */     this.cachedDefineMetaDataSize = (this.defineMetaData != null ? this.defineMetaData.length : 0);
/* 6040 */     this.connection.cacheBuffer(this.defineChars);
/* 6041 */     this.defineChars = null;
/* 6042 */     this.connection.cacheBuffer(this.defineBytes);
/* 6043 */     this.defineBytes = null;
/* 6044 */     this.defineIndicators = null;
/* 6045 */     this.defineMetaData = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 6063 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Calendar getGMTCalendar()
/*      */   {
/* 6074 */     if (this.gmtCalendar == null)
/*      */     {
/* 6076 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
/*      */     }
/*      */     
/*      */ 
/* 6080 */     return this.gmtCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void extractNioDefineBuffers(int paramInt)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void internalClose()
/*      */     throws SQLException
/*      */   {
/* 6105 */     this.closed = true;
/* 6106 */     if (this.currentResultSet != null) {
/* 6107 */       this.currentResultSet.closed = true;
/*      */     }
/* 6109 */     cleanupDefines();
/* 6110 */     this.bindBytes = null;
/* 6111 */     this.bindChars = null;
/* 6112 */     this.bindIndicators = null;
/*      */     
/* 6114 */     this.outBindAccessors = null;
/* 6115 */     this.parameterStream = ((InputStream[][])null);
/* 6116 */     this.userStream = ((Object[][])null);
/*      */     
/* 6118 */     this.ibtBindBytes = null;
/* 6119 */     this.ibtBindChars = null;
/* 6120 */     this.ibtBindIndicators = null;
/*      */     
/* 6122 */     this.lobPrefetchMetaData = null;
/* 6123 */     this.tmpByteArray = null;
/*      */     
/* 6125 */     this.definedColumnType = null;
/* 6126 */     this.definedColumnSize = null;
/* 6127 */     this.definedColumnFormOfUse = null;
/*      */     
/*      */ 
/*      */ 
/* 6131 */     if (this.wrapper != null) {
/* 6132 */       this.wrapper.close();
/*      */     }
/*      */   }
/*      */   
/* 6136 */   long _checkSum = 0L;
/*      */   static final byte IS_UNINITIALIZED = 0;
/*      */   
/* 6139 */   void calculateCheckSum() throws SQLException { if (!this.connection.calculateChecksum) {
/* 6140 */       return;
/*      */     }
/* 6142 */     this._checkSum = this.checkSum;
/* 6143 */     if (this.accessors != null) {
/* 6144 */       accessorChecksum(this.accessors);
/*      */     }
/* 6146 */     if (this.outBindAccessors != null) {
/* 6147 */       accessorChecksum(this.outBindAccessors);
/*      */     }
/* 6149 */     if ((this.returnParamAccessors != null) && (this.returnParamsFetched)) {
/* 6150 */       accessorChecksum(this.returnParamAccessors);
/*      */     }
/* 6152 */     this._checkSum = CRC64.updateChecksum(this._checkSum, this.validRows);
/* 6153 */     this.checkSum = this._checkSum;
/* 6154 */     this._checkSum = 0L;
/*      */   }
/*      */   
/*      */   void accessorChecksum(Accessor[] paramArrayOfAccessor) throws SQLException
/*      */   {
/* 6159 */     int i = 0;
/* 6160 */     int j = 0;
/*      */     
/*      */ 
/* 6163 */     for (Accessor localAccessor : paramArrayOfAccessor)
/*      */     {
/* 6165 */       if (localAccessor != null)
/*      */       {
/* 6167 */         switch (localAccessor.internalType)
/*      */         {
/*      */         case 112: 
/*      */         case 113: 
/*      */         case 114: 
/* 6172 */           if (i == 0) {
/* 6173 */             j = 1;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 8: 
/*      */         case 24: 
/* 6180 */           j = 0;
/*      */           
/* 6182 */           break;
/*      */         
/*      */         default: 
/* 6185 */           j = 0;
/*      */           
/*      */ 
/*      */ 
/* 6189 */           i++;
/* 6190 */           for (int n = 0; n < this.validRows; n++)
/*      */           {
/* 6192 */             if (localAccessor.rowSpaceIndicator != null)
/* 6193 */               this._checkSum = localAccessor.updateChecksum(this._checkSum, n);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 6198 */     if (j != 0) {
/* 6199 */       this.checkSumComputationFailure = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public long getChecksum()
/*      */     throws SQLException
/*      */   {
/* 6207 */     if (this.checkSumComputationFailure)
/*      */     {
/* 6209 */       SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 6210 */       localSQLException.fillInStackTrace();
/* 6211 */       throw localSQLException;
/*      */     }
/*      */     
/* 6214 */     return this.checkSum;
/*      */   }
/*      */   
/*      */ 
/*      */   static final byte IS_SELECT = 1;
/*      */   
/*      */   static final byte IS_DELETE = 2;
/*      */   static final byte IS_INSERT = 4;
/*      */   static final byte IS_MERGE = 8;
/*      */   static final byte IS_UPDATE = 16;
/*      */   static final byte IS_PLSQL_BLOCK = 32;
/*      */   static final byte IS_CALL_BLOCK = 64;
/*      */   static final byte IS_OTHER = -128;
/*      */   static final byte IS_DML = 30;
/*      */   static final byte IS_PLSQL = 96;
/*      */   static final byte convertSqlKindEnumToByte(OracleStatement.SqlKind paramSqlKind)
/*      */   {
/* 6231 */     switch (paramSqlKind)
/*      */     {
/*      */     case DELETE: 
/* 6234 */       return 2;
/*      */     
/*      */     case INSERT: 
/* 6237 */       return 4;
/*      */     
/*      */     case MERGE: 
/* 6240 */       return 8;
/*      */     
/*      */     case UPDATE: 
/* 6243 */       return 16;
/*      */     
/*      */     case ALTER_SESSION: 
/*      */     case OTHER: 
/* 6247 */       return Byte.MIN_VALUE;
/*      */     
/*      */     case PLSQL_BLOCK: 
/* 6250 */       return 32;
/*      */     
/*      */     case CALL_BLOCK: 
/* 6253 */       return 64;
/*      */     
/*      */     case SELECT_FOR_UPDATE: 
/*      */     case SELECT: 
/* 6257 */       return 1;
/*      */     }
/*      */     
/* 6260 */     if (paramSqlKind.isPlsqlOrCall())
/* 6261 */       return 96;
/* 6262 */     if (paramSqlKind.isDML()) {
/* 6263 */       return 30;
/*      */     }
/* 6265 */     return 0;
/*      */   }
/*      */   
/*      */   static final OracleStatement.SqlKind convertSqlKindByteToEnum(byte paramByte)
/*      */   {
/* 6270 */     switch (paramByte)
/*      */     {
/*      */     case 2: 
/* 6273 */       return OracleStatement.SqlKind.DELETE;
/*      */     
/*      */     case 4: 
/* 6276 */       return OracleStatement.SqlKind.INSERT;
/*      */     
/*      */     case 8: 
/* 6279 */       return OracleStatement.SqlKind.MERGE;
/*      */     
/*      */     case 16: 
/* 6282 */       return OracleStatement.SqlKind.UPDATE;
/*      */     
/*      */     case -128: 
/* 6285 */       return OracleStatement.SqlKind.OTHER;
/*      */     
/*      */     case 32: 
/* 6288 */       return OracleStatement.SqlKind.PLSQL_BLOCK;
/*      */     
/*      */     case 64: 
/* 6291 */       return OracleStatement.SqlKind.CALL_BLOCK;
/*      */     
/*      */     case 1: 
/* 6294 */       return OracleStatement.SqlKind.SELECT;
/*      */     }
/*      */     
/*      */     
/* 6298 */     return OracleStatement.SqlKind.UNINITIALIZED;
/*      */   }
/*      */   
/*      */ 
/* 6302 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OracleStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */