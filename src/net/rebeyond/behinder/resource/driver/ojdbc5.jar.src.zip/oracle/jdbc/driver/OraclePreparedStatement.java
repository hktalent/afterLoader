/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.io.BufferedInputStream;
/*       */ import java.io.BufferedReader;
/*       */ import java.io.ByteArrayInputStream;
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.Reader;
/*       */ import java.io.StringReader;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.URL;
/*       */ import java.sql.Array;
/*       */ import java.sql.BatchUpdateException;
/*       */ import java.sql.Blob;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Date;
/*       */ import java.sql.ParameterMetaData;
/*       */ import java.sql.Ref;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.SQLData;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.Calendar;
/*       */ import java.util.Locale;
/*       */ import java.util.TimeZone;
/*       */ import oracle.jdbc.OracleData;
/*       */ import oracle.jdbc.internal.ObjectData;
/*       */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.oracore.OracleTypeNUMBER;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CHAR;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.OPAQUE;
/*       */ import oracle.sql.ORAData;
/*       */ import oracle.sql.OpaqueDescriptor;
/*       */ import oracle.sql.RAW;
/*       */ import oracle.sql.REF;
/*       */ import oracle.sql.ROWID;
/*       */ import oracle.sql.STRUCT;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ abstract class OraclePreparedStatement
/*       */   extends OracleStatement
/*       */   implements oracle.jdbc.internal.OraclePreparedStatement, ScrollRsetStatement
/*       */ {
/*       */   int numberOfBindRowsAllocated;
/*   107 */   static Binder theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
/*       */   
/*   109 */   static Binder theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
/*       */   
/*   111 */   Binder theVarnumNullBinder = theStaticVarnumNullBinder;
/*       */   
/*   113 */   static Binder theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
/*       */   
/*   115 */   Binder theBooleanBinder = theStaticBooleanBinder;
/*       */   
/*   117 */   static Binder theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
/*       */   
/*   119 */   Binder theByteBinder = theStaticByteBinder;
/*       */   
/*   121 */   static Binder theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
/*       */   
/*   123 */   Binder theShortBinder = theStaticShortBinder;
/*       */   
/*   125 */   static Binder theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
/*       */   
/*   127 */   Binder theIntBinder = theStaticIntBinder;
/*       */   
/*   129 */   static Binder theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
/*       */   
/*   131 */   Binder theLongBinder = theStaticLongBinder;
/*       */   
/*   133 */   static Binder theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
/*       */   
/*   135 */   Binder theFloatBinder = null;
/*       */   
/*   137 */   static Binder theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
/*       */   
/*   139 */   Binder theDoubleBinder = null;
/*       */   
/*   141 */   static Binder theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
/*       */   
/*   143 */   Binder theBigDecimalBinder = theStaticBigDecimalBinder;
/*       */   
/*   145 */   static Binder theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
/*       */   
/*   147 */   static Binder theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
/*       */   
/*   149 */   Binder theVarcharNullBinder = theStaticVarcharNullBinder;
/*       */   
/*   151 */   static Binder theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
/*       */   
/*   153 */   Binder theStringBinder = theStaticStringBinder;
/*       */   
/*   155 */   static Binder theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
/*       */   
/*   157 */   static Binder theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
/*       */   
/*   159 */   static Binder theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
/*       */   
/*   161 */   static Binder theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
/*       */   
/*       */   Binder theSetCHARBinder;
/*   164 */   Binder theSetCHARNullBinder = theStaticSetCHARNullBinder;
/*       */   
/*   166 */   static Binder theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
/*       */   
/*   168 */   static Binder theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
/*       */   
/*   170 */   static Binder theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
/*       */   
/*   172 */   Binder theFixedCHARBinder = theStaticFixedCHARBinder;
/*   173 */   Binder theFixedCHARNullBinder = theStaticFixedCHARNullBinder;
/*       */   
/*   175 */   static Binder theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
/*       */   
/*   177 */   static Binder theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
/*       */   
/*   179 */   static Binder theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
/*       */   
/*   181 */   Binder theDateBinder = theStaticDateBinder;
/*   182 */   Binder theDateNullBinder = theStaticDateNullBinder;
/*       */   
/*   184 */   static Binder theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
/*       */   
/*   186 */   static Binder theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
/*       */   
/*   188 */   Binder theTimeBinder = theStaticTimeBinder;
/*       */   
/*   190 */   static Binder theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
/*       */   
/*   192 */   static Binder theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
/*       */   
/*   194 */   static Binder theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
/*       */   
/*   196 */   Binder theTimestampBinder = theStaticTimestampBinder;
/*   197 */   Binder theTimestampNullBinder = theStaticTimestampNullBinder;
/*       */   
/*   199 */   static Binder theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
/*       */   
/*   201 */   Binder theOracleNumberBinder = theStaticOracleNumberBinder;
/*       */   
/*   203 */   static Binder theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
/*       */   
/*   205 */   Binder theOracleDateBinder = theStaticOracleDateBinder;
/*       */   
/*   207 */   static Binder theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
/*       */   
/*   209 */   Binder theOracleTimestampBinder = theStaticOracleTimestampBinder;
/*       */   
/*   211 */   static Binder theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
/*       */   
/*   213 */   static Binder theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
/*       */   
/*   215 */   static Binder theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
/*       */   
/*   217 */   Binder theTSTZBinder = theStaticTSTZBinder;
/*   218 */   Binder theTSTZNullBinder = theStaticTSTZNullBinder;
/*       */   
/*   220 */   static Binder theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
/*       */   
/*   222 */   static Binder theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
/*       */   
/*   224 */   static Binder theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
/*       */   
/*   226 */   Binder theTSLTZBinder = theStaticTSLTZBinder;
/*   227 */   Binder theTSLTZNullBinder = theStaticTSLTZNullBinder;
/*       */   
/*   229 */   static Binder theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
/*       */   
/*   231 */   static Binder theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
/*       */   
/*   233 */   static Binder theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
/*       */   
/*   235 */   static Binder theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
/*       */   
/*   237 */   static Binder theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
/*       */   
/*       */   Binder theRowidBinder;
/*   240 */   Binder theRowidNullBinder = theStaticRowidNullBinder;
/*       */   
/*       */   Binder theURowidBinder;
/*   243 */   Binder theURowidNullBinder = theStaticURowidNullBinder;
/*       */   
/*   245 */   static Binder theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
/*       */   
/*   247 */   static Binder theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
/*       */   
/*   249 */   static Binder theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
/*       */   
/*   251 */   Binder theIntervalDSBinder = theStaticIntervalDSBinder;
/*   252 */   Binder theIntervalDSNullBinder = theStaticIntervalDSNullBinder;
/*       */   
/*   254 */   static Binder theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
/*       */   
/*   256 */   static Binder theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
/*       */   
/*   258 */   static Binder theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
/*       */   
/*   260 */   Binder theIntervalYMBinder = theStaticIntervalYMBinder;
/*   261 */   Binder theIntervalYMNullBinder = theStaticIntervalYMNullBinder;
/*       */   
/*   263 */   static Binder theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
/*       */   
/*   265 */   static Binder theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
/*       */   
/*   267 */   static Binder theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
/*       */   
/*   269 */   Binder theBfileBinder = theStaticBfileBinder;
/*   270 */   Binder theBfileNullBinder = theStaticBfileNullBinder;
/*       */   
/*   272 */   static Binder theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
/*       */   
/*   274 */   static Binder theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
/*       */   
/*   276 */   static Binder theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
/*       */   
/*   278 */   Binder theBlobBinder = theStaticBlobBinder;
/*   279 */   Binder theBlobNullBinder = theStaticBlobNullBinder;
/*       */   
/*   281 */   static Binder theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
/*       */   
/*   283 */   static Binder theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
/*       */   
/*   285 */   static Binder theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
/*       */   
/*   287 */   Binder theClobBinder = theStaticClobBinder;
/*   288 */   Binder theClobNullBinder = theStaticClobNullBinder;
/*       */   
/*   290 */   static Binder theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
/*       */   
/*   292 */   static Binder theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
/*       */   
/*   294 */   static Binder theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
/*       */   
/*   296 */   Binder theRawBinder = theStaticRawBinder;
/*   297 */   Binder theRawNullBinder = theStaticRawNullBinder;
/*       */   
/*   299 */   static Binder theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
/*       */   
/*   301 */   static Binder theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
/*       */   
/*   303 */   Binder thePlsqlRawBinder = theStaticPlsqlRawBinder;
/*       */   
/*   305 */   static Binder theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
/*       */   
/*   307 */   static Binder theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
/*       */   
/*   309 */   static Binder theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
/*       */   
/*   311 */   Binder theBinaryFloatBinder = theStaticBinaryFloatBinder;
/*   312 */   Binder theBinaryFloatNullBinder = theStaticBinaryFloatNullBinder;
/*       */   
/*   314 */   static Binder theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
/*       */   
/*   316 */   static Binder theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
/*       */   
/*   318 */   static Binder theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
/*       */   
/*   320 */   Binder theBINARY_FLOATBinder = theStaticBINARY_FLOATBinder;
/*   321 */   Binder theBINARY_FLOATNullBinder = theStaticBINARY_FLOATNullBinder;
/*       */   
/*   323 */   static Binder theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
/*       */   
/*   325 */   static Binder theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
/*       */   
/*   327 */   static Binder theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
/*       */   
/*   329 */   Binder theBinaryDoubleBinder = theStaticBinaryDoubleBinder;
/*   330 */   Binder theBinaryDoubleNullBinder = theStaticBinaryDoubleNullBinder;
/*       */   
/*   332 */   static Binder theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
/*       */   
/*   334 */   static Binder theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
/*       */   
/*   336 */   static Binder theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   338 */   Binder theBINARY_DOUBLEBinder = theStaticBINARY_DOUBLEBinder;
/*   339 */   Binder theBINARY_DOUBLENullBinder = theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   341 */   static Binder theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
/*       */   
/*   343 */   Binder theLongStreamBinder = theStaticLongStreamBinder;
/*       */   
/*   345 */   static Binder theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
/*       */   
/*   347 */   Binder theLongStreamForStringBinder = theStaticLongStreamForStringBinder;
/*   348 */   static Binder theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
/*       */   
/*       */ 
/*   351 */   static Binder theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
/*       */   
/*   353 */   Binder theLongRawStreamBinder = theStaticLongRawStreamBinder;
/*       */   
/*   355 */   static Binder theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
/*       */   
/*   357 */   Binder theLongRawStreamForBytesBinder = theStaticLongRawStreamForBytesBinder;
/*   358 */   static Binder theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
/*       */   
/*       */ 
/*   361 */   static Binder theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
/*       */   
/*   363 */   static Binder theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
/*       */   
/*   365 */   static Binder theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
/*       */   
/*   367 */   Binder theNamedTypeBinder = theStaticNamedTypeBinder;
/*   368 */   Binder theNamedTypeNullBinder = theStaticNamedTypeNullBinder;
/*       */   
/*   370 */   static Binder theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
/*       */   
/*   372 */   static Binder theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
/*       */   
/*   374 */   static Binder theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
/*       */   
/*   376 */   Binder theRefTypeBinder = theStaticRefTypeBinder;
/*   377 */   Binder theRefTypeNullBinder = theStaticRefTypeNullBinder;
/*       */   
/*   379 */   static Binder theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
/*       */   
/*   381 */   static Binder theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
/*       */   
/*   383 */   static Binder theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
/*       */   
/*   385 */   Binder thePlsqlIbtBinder = theStaticPlsqlIbtBinder;
/*   386 */   Binder thePlsqlNullBinder = theStaticPlsqlIbtNullBinder;
/*       */   
/*   388 */   static Binder theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
/*       */   
/*   390 */   Binder theOutBinder = theStaticOutBinder;
/*       */   
/*   392 */   static Binder theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
/*       */   
/*   394 */   Binder theReturnParamBinder = theStaticReturnParamBinder;
/*       */   
/*   396 */   static Binder theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
/*       */   
/*   398 */   static Binder theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
/*       */   
/*   400 */   static Binder theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
/*       */   
/*   402 */   static Binder theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   409 */   private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
/*   410 */   private static final Calendar UTC_US_CALENDAR = Calendar.getInstance(UTC_TIME_ZONE, Locale.US);
/*       */   
/*   412 */   protected Calendar cachedUTCUSCalendar = (Calendar)UTC_US_CALENDAR.clone();
/*       */   
/*       */   public static final int TypeBinder_BYTELEN = 24;
/*       */   
/*   416 */   char[] digits = new char[20];
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Binder[][] binders;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int[][] parameterInt;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   long[][] parameterLong;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   float[][] parameterFloat;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   double[][] parameterDouble;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   BigDecimal[][] parameterBigDecimal;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   String[][] parameterString;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Date[][] parameterDate;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Time[][] parameterTime;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Timestamp[][] parameterTimestamp;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   byte[][][] parameterDatum;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleTypeADT[][] parameterOtype;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   CLOB[] lastBoundClobs;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   BLOB[] lastBoundBlobs;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   PlsqlIbtBindInfo[][] parameterPlsqlIbt;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Binder[] currentRowBinders;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int[] currentRowCharLens;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Accessor[] currentRowBindAccessors;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   short[] currentRowFormOfUse;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*   534 */   boolean currentRowNeedToPrepareBinds = true;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int[] currentBatchCharLens;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Accessor[] currentBatchBindAccessors;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   short[] currentBatchFormOfUse;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean currentBatchNeedToPrepareBinds;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   PushedBatch pushedBatches;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   PushedBatch pushedBatchesTail;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   874 */   int cachedBindByteSize = 0;
/*   875 */   int cachedBindCharSize = 0;
/*   876 */   int cachedBindIndicatorSize = 0;
/*       */   
/*       */ 
/*       */ 
/*       */   int totalBindByteLength;
/*       */   
/*       */ 
/*       */ 
/*       */   int totalBindCharLength;
/*       */   
/*       */ 
/*       */ 
/*       */   int totalBindIndicatorLength;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_TYPE_OFFSET = 0;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_PER_POSITION_SIZE = 10;
/*       */   
/*       */ 
/*       */   static final int SETLOB_NO_LENGTH = -1;
/*       */   
/*       */ 
/*       */   int bindBufferCapacity;
/*       */   
/*       */ 
/*       */   int numberOfBoundRows;
/*       */   
/*       */ 
/*       */   int indicatorsOffset;
/*       */   
/*       */ 
/*       */   int valueLengthsOffset;
/*       */   
/*       */ 
/*       */   boolean preparedAllBinds;
/*       */   
/*       */ 
/*       */   boolean preparedCharBinds;
/*       */   
/*       */ 
/*       */   Binder[] lastBinders;
/*       */   
/*       */ 
/*       */   byte[] lastBoundBytes;
/*       */   
/*       */ 
/*       */   int lastBoundByteOffset;
/*       */   
/*       */ 
/*       */   char[] lastBoundChars;
/*       */   
/*       */ 
/*       */   int lastBoundCharOffset;
/*       */   
/*       */ 
/*       */   int[] lastBoundByteOffsets;
/*       */   
/*       */ 
/*       */   int[] lastBoundCharOffsets;
/*       */   
/*       */ 
/*       */   int[] lastBoundByteLens;
/*       */   
/*       */ 
/*       */   int[] lastBoundCharLens;
/*       */   
/*       */ 
/*       */   short[] lastBoundInds;
/*       */   
/*       */ 
/*       */   short[] lastBoundLens;
/*       */   
/*       */ 
/*   996 */   boolean lastBoundNeeded = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   byte[][] lastBoundTypeBytes;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleTypeADT[] lastBoundTypeOtypes;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   InputStream[] lastBoundStream;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final int STREAM_MAX_BYTES_SQL = Integer.MAX_VALUE;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxRawBytesSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxRawBytesPlsql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsCharsSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsNCharsSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsBytesPlsql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1097 */   private int maxCharSize = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1103 */   private int maxNCharSize = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1111 */   private int charMaxCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1119 */   private int charMaxNCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1126 */   private int maxVcsCharsPlsql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1133 */   private int maxVcsNCharsPlsql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1139 */   int maxIbtVarcharElementLength = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1147 */   private int maxStreamCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1155 */   private int maxStreamNCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1161 */   protected boolean isServerCharSetFixedWidth = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1167 */   private boolean isServerNCharSetFixedWidth = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int minVcsBindSize;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int prematureBatchCount;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1218 */   boolean checkBindTypes = true;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean scrollRsetTypeSolved;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final double MIN_NUMBER = 1.0E-130D;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final double MAX_NUMBER = 1.0E126D;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  1251 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*       */     
/*       */ 
/*  1254 */     this.cacheState = 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*       */     throws SQLException
/*       */   {
/*  1266 */     super(paramPhysicalConnection, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */     
/*       */ 
/*       */ 
/*  1270 */     this.cacheState = 1;
/*       */     
/*  1272 */     if (paramInt1 > 1) {
/*  1273 */       setOracleBatchStyle();
/*       */     }
/*  1275 */     this.theSetCHARBinder = (paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianSetCHARBinder : theStaticSetCHARBinder);
/*       */     
/*       */ 
/*       */ 
/*  1279 */     this.theURowidBinder = (this.theRowidBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianRowidBinder : theStaticRowidBinder);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1285 */     this.statementType = 1;
/*  1286 */     this.currentRow = -1;
/*  1287 */     this.needToParse = true;
/*       */     
/*  1289 */     this.processEscapes = paramPhysicalConnection.processEscapes;
/*  1290 */     this.sqlObject.initialize(paramString);
/*       */     
/*  1292 */     this.sqlKind = this.sqlObject.getSqlKind();
/*       */     
/*  1294 */     this.clearParameters = true;
/*  1295 */     this.scrollRsetTypeSolved = false;
/*  1296 */     this.prematureBatchCount = 0;
/*       */     
/*  1298 */     initializeBinds();
/*       */     
/*  1300 */     this.minVcsBindSize = paramPhysicalConnection.minVcsBindSize;
/*  1301 */     this.maxRawBytesSql = paramPhysicalConnection.maxRawBytesSql;
/*  1302 */     this.maxRawBytesPlsql = paramPhysicalConnection.maxRawBytesPlsql;
/*  1303 */     this.maxVcsCharsSql = paramPhysicalConnection.maxVcsCharsSql;
/*  1304 */     this.maxVcsNCharsSql = paramPhysicalConnection.maxVcsNCharsSql;
/*  1305 */     this.maxVcsBytesPlsql = paramPhysicalConnection.maxVcsBytesPlsql;
/*  1306 */     this.maxIbtVarcharElementLength = paramPhysicalConnection.maxIbtVarcharElementLength;
/*  1307 */     this.maxCharSize = this.connection.conversion.sMaxCharSize;
/*  1308 */     this.maxNCharSize = this.connection.conversion.maxNCharSize;
/*  1309 */     this.maxVcsCharsPlsql = (this.maxVcsBytesPlsql / this.maxCharSize);
/*  1310 */     this.maxVcsNCharsPlsql = (this.maxVcsBytesPlsql / this.maxNCharSize);
/*  1311 */     this.maxStreamCharsSql = (Integer.MAX_VALUE / this.maxCharSize);
/*  1312 */     this.maxStreamNCharsSql = (this.maxRawBytesSql / this.maxNCharSize);
/*  1313 */     this.isServerCharSetFixedWidth = this.connection.conversion.isServerCharSetFixedWidth;
/*  1314 */     this.isServerNCharSetFixedWidth = this.connection.conversion.isServerNCharSetFixedWidth;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void allocBinds(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  1330 */     int i = paramInt > this.numberOfBindRowsAllocated ? 1 : 0;
/*       */     
/*       */ 
/*       */ 
/*  1334 */     initializeIndicatorSubRange();
/*       */     
/*       */ 
/*       */ 
/*  1338 */     int j = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1345 */     int k = paramInt * this.numberOfBindPositions;
/*       */     
/*       */ 
/*  1348 */     int m = j + 2 * k;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1354 */     if (m > this.totalBindIndicatorLength)
/*       */     {
/*  1356 */       short[] arrayOfShort = this.bindIndicators;
/*  1357 */       i1 = this.bindIndicatorOffset;
/*       */       
/*  1359 */       this.bindIndicatorOffset = 0;
/*  1360 */       this.bindIndicators = new short[m];
/*  1361 */       this.totalBindIndicatorLength = m;
/*       */       
/*  1363 */       if ((arrayOfShort != null) && (i != 0))
/*       */       {
/*       */ 
/*  1366 */         System.arraycopy(arrayOfShort, i1, this.bindIndicators, this.bindIndicatorOffset, j);
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  1371 */     this.bindIndicatorSubRange += this.bindIndicatorOffset;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1378 */     this.bindIndicators[(this.bindIndicatorSubRange + 0)] = ((short)this.numberOfBindPositions);
/*       */     
/*       */ 
/*       */ 
/*  1382 */     this.indicatorsOffset = (this.bindIndicatorOffset + j);
/*  1383 */     this.valueLengthsOffset = (this.indicatorsOffset + k);
/*       */     
/*  1385 */     int n = this.indicatorsOffset;
/*  1386 */     int i1 = this.valueLengthsOffset;
/*  1387 */     int i2 = this.bindIndicatorSubRange + 5;
/*       */     
/*       */ 
/*       */ 
/*  1391 */     for (int i3 = 0; i3 < this.numberOfBindPositions; i3++)
/*       */     {
/*       */ 
/*       */ 
/*  1395 */       this.bindIndicators[(i2 + 5)] = ((short)(n >> 16));
/*       */       
/*       */ 
/*  1398 */       this.bindIndicators[(i2 + 6)] = ((short)(n & 0xFFFF));
/*       */       
/*       */ 
/*  1401 */       this.bindIndicators[(i2 + 7)] = ((short)(i1 >> 16));
/*       */       
/*  1403 */       this.bindIndicators[(i2 + 8)] = ((short)(i1 & 0xFFFF));
/*       */       
/*       */ 
/*       */ 
/*  1407 */       n += paramInt;
/*  1408 */       i1 += paramInt;
/*  1409 */       i2 += 10;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void initializeBinds()
/*       */     throws SQLException
/*       */   {
/*  1429 */     this.numberOfBindPositions = this.sqlObject.getParameterCount();
/*  1430 */     this.numReturnParams = this.sqlObject.getReturnParameterCount();
/*       */     
/*  1432 */     if (this.numberOfBindPositions == 0)
/*       */     {
/*       */ 
/*       */ 
/*  1436 */       this.currentRowNeedToPrepareBinds = false;
/*       */       
/*  1438 */       return;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1444 */     this.numberOfBindRowsAllocated = this.batch;
/*       */     
/*       */ 
/*  1447 */     this.binders = new Binder[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     
/*  1449 */     this.currentRowBinders = this.binders[0];
/*       */     
/*  1451 */     this.currentRowCharLens = new int[this.numberOfBindPositions];
/*  1452 */     this.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/*  1454 */     this.currentRowFormOfUse = new short[this.numberOfBindPositions];
/*  1455 */     this.currentBatchFormOfUse = new short[this.numberOfBindPositions];
/*       */     
/*  1457 */     this.lastBoundClobs = new CLOB[this.numberOfBindPositions];
/*  1458 */     this.lastBoundBlobs = new BLOB[this.numberOfBindPositions];
/*       */     
/*  1460 */     int i = 1;
/*       */     
/*  1462 */     if (this.connection.defaultnchar) {
/*  1463 */       i = 2;
/*       */     }
/*  1465 */     for (int j = 0; j < this.numberOfBindPositions; j++)
/*       */     {
/*  1467 */       this.currentRowFormOfUse[j] = i;
/*  1468 */       this.currentBatchFormOfUse[j] = i;
/*       */     }
/*       */     
/*  1471 */     this.lastBinders = new Binder[this.numberOfBindPositions];
/*  1472 */     this.lastBoundCharLens = new int[this.numberOfBindPositions];
/*  1473 */     this.lastBoundByteOffsets = new int[this.numberOfBindPositions];
/*  1474 */     this.lastBoundCharOffsets = new int[this.numberOfBindPositions];
/*  1475 */     this.lastBoundByteLens = new int[this.numberOfBindPositions];
/*  1476 */     this.lastBoundInds = new short[this.numberOfBindPositions];
/*  1477 */     this.lastBoundLens = new short[this.numberOfBindPositions];
/*       */     
/*  1479 */     this.lastBoundTypeBytes = new byte[this.numberOfBindPositions][];
/*  1480 */     this.lastBoundTypeOtypes = new OracleTypeADT[this.numberOfBindPositions];
/*       */     
/*       */ 
/*  1483 */     allocBinds(this.numberOfBindRowsAllocated);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void growBinds(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  1502 */     Binder[][] arrayOfBinder = this.binders;
/*       */     
/*  1504 */     this.binders = new Binder[paramInt][];
/*       */     
/*       */ 
/*  1507 */     if (arrayOfBinder != null) {
/*  1508 */       System.arraycopy(arrayOfBinder, 0, this.binders, 0, this.numberOfBindRowsAllocated);
/*       */     }
/*       */     
/*       */ 
/*  1512 */     for (int i = this.numberOfBindRowsAllocated; i < paramInt; 
/*  1513 */         i++) {
/*  1514 */       this.binders[i] = new Binder[this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1520 */     allocBinds(paramInt);
/*       */     
/*       */     Object localObject;
/*       */     
/*  1524 */     if (this.parameterInt != null)
/*       */     {
/*  1526 */       localObject = this.parameterInt;
/*       */       
/*  1528 */       this.parameterInt = new int[paramInt][];
/*       */       
/*  1530 */       System.arraycopy(localObject, 0, this.parameterInt, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1533 */       for (i = this.numberOfBindRowsAllocated; 
/*  1534 */           i < paramInt; i++) {
/*  1535 */         this.parameterInt[i] = new int[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1538 */     if (this.parameterLong != null)
/*       */     {
/*  1540 */       localObject = this.parameterLong;
/*       */       
/*  1542 */       this.parameterLong = new long[paramInt][];
/*       */       
/*  1544 */       System.arraycopy(localObject, 0, this.parameterLong, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1547 */       for (i = this.numberOfBindRowsAllocated; 
/*  1548 */           i < paramInt; i++) {
/*  1549 */         this.parameterLong[i] = new long[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1552 */     if (this.parameterFloat != null)
/*       */     {
/*  1554 */       localObject = this.parameterFloat;
/*       */       
/*  1556 */       this.parameterFloat = new float[paramInt][];
/*       */       
/*  1558 */       System.arraycopy(localObject, 0, this.parameterFloat, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1561 */       for (i = this.numberOfBindRowsAllocated; 
/*  1562 */           i < paramInt; i++) {
/*  1563 */         this.parameterFloat[i] = new float[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1566 */     if (this.parameterDouble != null)
/*       */     {
/*  1568 */       localObject = this.parameterDouble;
/*       */       
/*  1570 */       this.parameterDouble = new double[paramInt][];
/*       */       
/*  1572 */       System.arraycopy(localObject, 0, this.parameterDouble, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1575 */       for (i = this.numberOfBindRowsAllocated; 
/*  1576 */           i < paramInt; i++) {
/*  1577 */         this.parameterDouble[i] = new double[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1580 */     if (this.parameterBigDecimal != null)
/*       */     {
/*  1582 */       localObject = this.parameterBigDecimal;
/*       */       
/*  1584 */       this.parameterBigDecimal = new BigDecimal[paramInt][];
/*       */       
/*       */ 
/*  1587 */       System.arraycopy(localObject, 0, this.parameterBigDecimal, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1590 */       for (i = this.numberOfBindRowsAllocated; 
/*  1591 */           i < paramInt; i++) {
/*  1592 */         this.parameterBigDecimal[i] = new BigDecimal[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1595 */     if (this.parameterString != null)
/*       */     {
/*  1597 */       localObject = this.parameterString;
/*       */       
/*  1599 */       this.parameterString = new String[paramInt][];
/*       */       
/*  1601 */       System.arraycopy(localObject, 0, this.parameterString, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1604 */       for (i = this.numberOfBindRowsAllocated; 
/*  1605 */           i < paramInt; i++) {
/*  1606 */         this.parameterString[i] = new String[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1609 */     if (this.parameterDate != null)
/*       */     {
/*  1611 */       localObject = this.parameterDate;
/*       */       
/*  1613 */       this.parameterDate = new Date[paramInt][];
/*       */       
/*  1615 */       System.arraycopy(localObject, 0, this.parameterDate, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1618 */       for (i = this.numberOfBindRowsAllocated; 
/*  1619 */           i < paramInt; i++) {
/*  1620 */         this.parameterDate[i] = new Date[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1623 */     if (this.parameterTime != null)
/*       */     {
/*  1625 */       localObject = this.parameterTime;
/*       */       
/*  1627 */       this.parameterTime = new Time[paramInt][];
/*       */       
/*  1629 */       System.arraycopy(localObject, 0, this.parameterTime, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1632 */       for (i = this.numberOfBindRowsAllocated; 
/*  1633 */           i < paramInt; i++) {
/*  1634 */         this.parameterTime[i] = new Time[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1637 */     if (this.parameterTimestamp != null)
/*       */     {
/*  1639 */       localObject = this.parameterTimestamp;
/*       */       
/*  1641 */       this.parameterTimestamp = new Timestamp[paramInt][];
/*       */       
/*  1643 */       System.arraycopy(localObject, 0, this.parameterTimestamp, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1646 */       for (i = this.numberOfBindRowsAllocated; 
/*  1647 */           i < paramInt; i++) {
/*  1648 */         this.parameterTimestamp[i] = new Timestamp[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1651 */     if (this.parameterDatum != null)
/*       */     {
/*  1653 */       localObject = this.parameterDatum;
/*       */       
/*  1655 */       this.parameterDatum = new byte[paramInt][][];
/*       */       
/*  1657 */       System.arraycopy(localObject, 0, this.parameterDatum, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1660 */       for (i = this.numberOfBindRowsAllocated; 
/*  1661 */           i < paramInt; i++) {
/*  1662 */         this.parameterDatum[i] = new byte[this.numberOfBindPositions][];
/*       */       }
/*       */     }
/*  1665 */     if (this.parameterOtype != null)
/*       */     {
/*  1667 */       localObject = this.parameterOtype;
/*       */       
/*  1669 */       this.parameterOtype = new OracleTypeADT[paramInt][];
/*       */       
/*  1671 */       System.arraycopy(localObject, 0, this.parameterOtype, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1674 */       for (i = this.numberOfBindRowsAllocated; 
/*  1675 */           i < paramInt; i++) {
/*  1676 */         this.parameterOtype[i] = new OracleTypeADT[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1679 */     if (this.parameterStream != null)
/*       */     {
/*  1681 */       localObject = this.parameterStream;
/*       */       
/*  1683 */       this.parameterStream = new InputStream[paramInt][];
/*       */       
/*  1685 */       System.arraycopy(localObject, 0, this.parameterStream, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1688 */       for (i = this.numberOfBindRowsAllocated; 
/*  1689 */           i < paramInt; i++) {
/*  1690 */         this.parameterStream[i] = new InputStream[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1693 */     if (this.userStream != null)
/*       */     {
/*  1695 */       localObject = this.userStream;
/*       */       
/*  1697 */       this.userStream = new Object[paramInt][];
/*       */       
/*  1699 */       System.arraycopy(localObject, 0, this.userStream, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1702 */       for (i = this.numberOfBindRowsAllocated; 
/*  1703 */           i < paramInt; i++) {
/*  1704 */         this.userStream[i] = new Object[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1707 */     if (this.parameterPlsqlIbt != null)
/*       */     {
/*  1709 */       localObject = this.parameterPlsqlIbt;
/*       */       
/*  1711 */       this.parameterPlsqlIbt = new PlsqlIbtBindInfo[paramInt][];
/*       */       
/*       */ 
/*  1714 */       System.arraycopy(localObject, 0, this.parameterPlsqlIbt, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1717 */       for (i = this.numberOfBindRowsAllocated; 
/*  1718 */           i < paramInt; i++) {
/*  1719 */         this.parameterPlsqlIbt[i] = new PlsqlIbtBindInfo[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*       */     
/*  1723 */     this.numberOfBindRowsAllocated = paramInt;
/*       */     
/*       */ 
/*  1726 */     this.currentRowNeedToPrepareBinds = true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void processCompletedBindRow(int paramInt, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  1800 */     if (this.numberOfBindPositions == 0)
/*       */     {
/*       */ 
/*  1803 */       return;
/*       */     }
/*       */     
/*  1806 */     int j = 0;
/*  1807 */     int k = 0;
/*  1808 */     int m = 0;
/*  1809 */     int n = this.currentRank == this.firstRowInBatch ? 1 : 0;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1816 */     Binder[] arrayOfBinder = this.currentRank == 0 ? this.lastBinders : this.lastBinders[0] == null ? null : this.binders[(this.currentRank - 1)];
/*       */     
/*       */     Object localObject2;
/*       */     Object localObject3;
/*  1820 */     if (this.currentRowBindAccessors == null)
/*       */     {
/*  1822 */       int i1 = (this.isAutoGeneratedKey) && (this.clearParameters) ? 1 : 0;
/*       */       
/*       */ 
/*  1825 */       if (arrayOfBinder == null)
/*       */       {
/*       */ 
/*       */ 
/*  1829 */         for (i = 0; i < this.numberOfBindPositions; i++) {
/*  1830 */           if (this.currentRowBinders[i] == null)
/*       */           {
/*  1832 */             if (i1 != 0)
/*       */             {
/*  1834 */               registerReturnParamsForAutoKey();
/*  1835 */               i1 = 0;
/*       */             }
/*       */             else {
/*  1838 */               localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  1839 */               ((SQLException)localObject2).fillInStackTrace();
/*  1840 */               throw ((Throwable)localObject2);
/*       */             } }
/*       */         }
/*       */       }
/*  1844 */       if (this.checkBindTypes)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*  1849 */         localObject2 = this.parameterOtype == null ? null : this.currentRank == 0 ? this.lastBoundTypeOtypes : this.parameterOtype[(this.currentRank - 1)];
/*       */         
/*       */ 
/*       */ 
/*  1853 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  1855 */           if ((this.currentRowBinders[i] == null) && (i1 != 0))
/*       */           {
/*  1857 */             registerReturnParamsForAutoKey();
/*  1858 */             i1 = 0;
/*       */           }
/*  1860 */           localObject3 = this.currentRowBinders[i];
/*       */           
/*  1862 */           if (localObject3 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  1867 */             if (this.clearParameters)
/*       */             {
/*  1869 */               SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  1870 */               localSQLException2.fillInStackTrace();
/*  1871 */               throw localSQLException2;
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1880 */             this.currentRowBinders[i] = arrayOfBinder[i].copyingBinder();
/*       */             
/*       */ 
/*  1883 */             if (this.currentRank == 0) {
/*  1884 */               this.currentRowBinders[i].lastBoundValueCleanup(this, i);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1891 */             this.currentRowCharLens[i] = -1;
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1897 */             k = 1;
/*       */           }
/*       */           else
/*       */           {
/*  1901 */             int i6 = ((Binder)localObject3).type;
/*       */             
/*  1903 */             if ((i6 == arrayOfBinder[i].type) && (((i6 != 109) && (i6 != 111)) || (this.parameterOtype[this.currentRank][i].isInHierarchyOf(localObject2[i])))) { if (i6 == 9) { if ((((Binder)localObject3).bytelen == 0 ? 1 : 0) == (arrayOfBinder[i].bytelen == 0 ? 1 : 0)) {}
/*       */               }
/*       */               
/*       */ 
/*       */ 
/*       */ 
/*       */             }
/*       */             else
/*       */             {
/*  1912 */               j = 1;
/*       */             }
/*       */           }
/*  1915 */           if (this.currentBatchFormOfUse[i] != this.currentRowFormOfUse[i])
/*       */           {
/*       */ 
/*       */ 
/*  1919 */             j = 1;
/*       */           }
/*       */           
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  1928 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  1930 */           localObject2 = this.currentRowBinders[i];
/*       */           
/*  1932 */           if (localObject2 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  1937 */             if (this.clearParameters)
/*       */             {
/*  1939 */               localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  1940 */               ((SQLException)localObject3).fillInStackTrace();
/*  1941 */               throw ((Throwable)localObject3);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1950 */             this.currentRowBinders[i] = arrayOfBinder[i].copyingBinder();
/*       */             
/*       */ 
/*  1953 */             if (this.currentRank == 0) {
/*  1954 */               this.currentRowBinders[i].lastBoundValueCleanup(this, i);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*  1960 */             this.currentRowCharLens[i] = -1;
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1966 */             k = 1;
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*  1971 */       if ((k != 0) && ((n != 0) || (this.m_batchStyle == 2)))
/*       */       {
/*  1973 */         this.lastBoundNeeded = true;
/*       */       }
/*       */     }
/*       */     else
/*       */     {
/*       */       Object localObject1;
/*  1979 */       if (arrayOfBinder == null)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1985 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  1987 */           localObject1 = this.currentRowBinders[i];
/*  1988 */           localObject2 = this.currentRowBindAccessors[i];
/*       */           
/*  1990 */           if (localObject1 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  1995 */             if (localObject2 == null)
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*  2000 */               localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  2001 */               ((SQLException)localObject3).fillInStackTrace();
/*  2002 */               throw ((Throwable)localObject3);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*  2008 */             this.currentRowBinders[i] = this.theOutBinder;
/*       */           }
/*  2010 */           else if ((localObject2 != null) && (((Accessor)localObject2).defineType != ((Binder)localObject1).type))
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2018 */             if ((!this.connection.permitTimestampDateMismatch) || (((Binder)localObject1).type != 180) || (((Accessor)localObject2).defineType != 12))
/*       */             {
/*       */ 
/*       */ 
/*  2022 */               m = 1;
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*  2027 */       if (this.checkBindTypes)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2034 */         localObject1 = this.parameterOtype == null ? null : this.currentRank == 0 ? this.lastBoundTypeOtypes : this.parameterOtype[(this.currentRank - 1)];
/*       */         
/*       */ 
/*       */ 
/*  2038 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2040 */           localObject2 = this.currentRowBinders[i];
/*  2041 */           localObject3 = this.currentRowBindAccessors[i];
/*       */           
/*  2043 */           if (localObject2 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2049 */             if ((this.clearParameters) && (arrayOfBinder[i] != this.theOutBinder))
/*       */             {
/*       */ 
/*  2052 */               SQLException localSQLException3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  2053 */               localSQLException3.fillInStackTrace();
/*  2054 */               throw localSQLException3;
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2065 */             localObject2 = arrayOfBinder[i];
/*  2066 */             this.currentRowBinders[i] = localObject2;
/*  2067 */             this.currentRowCharLens[i] = -1;
/*       */             
/*  2069 */             if (localObject2 != this.theOutBinder)
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2075 */               k = 1;
/*       */             }
/*       */           }
/*       */           else {
/*  2079 */             int i7 = ((Binder)localObject2).type;
/*       */             
/*  2081 */             if ((i7 == arrayOfBinder[i].type) && (((i7 != 109) && (i7 != 111)) || (this.parameterOtype[this.currentRank][i].isInHierarchyOf(localObject1[i])))) { if (i7 == 9) { if ((((Binder)localObject2).bytelen == 0 ? 1 : 0) == (arrayOfBinder[i].bytelen == 0 ? 1 : 0)) {}
/*       */               }
/*       */               
/*       */ 
/*       */ 
/*       */ 
/*       */             }
/*       */             else
/*       */             {
/*  2090 */               j = 1;
/*       */             }
/*       */           }
/*  2093 */           if (this.currentBatchFormOfUse[i] != this.currentRowFormOfUse[i])
/*       */           {
/*       */ 
/*       */ 
/*  2097 */             j = 1;
/*       */           }
/*  2099 */           Accessor localAccessor = this.currentBatchBindAccessors[i];
/*       */           
/*  2101 */           if (localObject3 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2107 */             localObject3 = localAccessor;
/*  2108 */             this.currentRowBindAccessors[i] = localObject3;
/*       */           }
/*  2110 */           else if ((localAccessor != null) && (((Accessor)localObject3).defineType != localAccessor.defineType))
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  2115 */             j = 1;
/*       */           }
/*  2117 */           if ((localObject3 != null) && (localObject2 != this.theOutBinder) && (((Accessor)localObject3).defineType != ((Binder)localObject2).type))
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2126 */             if ((!this.connection.permitTimestampDateMismatch) || (((Binder)localObject2).type != 180) || (((Accessor)localObject3).defineType != 12))
/*       */             {
/*       */ 
/*       */ 
/*  2130 */               m = 1;
/*       */             }
/*       */             
/*       */           }
/*       */           
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  2141 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2143 */           localObject1 = this.currentRowBinders[i];
/*       */           
/*  2145 */           if (localObject1 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2151 */             if ((this.clearParameters) && (arrayOfBinder[i] != this.theOutBinder))
/*       */             {
/*  2153 */               localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  2154 */               ((SQLException)localObject2).fillInStackTrace();
/*  2155 */               throw ((Throwable)localObject2);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2165 */             localObject1 = arrayOfBinder[i];
/*  2166 */             this.currentRowBinders[i] = localObject1;
/*  2167 */             this.currentRowCharLens[i] = -1;
/*       */             
/*  2169 */             if (localObject1 != this.theOutBinder)
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2175 */               k = 1;
/*       */             }
/*       */           }
/*  2178 */           if (this.currentRowBindAccessors[i] == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  2183 */             this.currentRowBindAccessors[i] = this.currentBatchBindAccessors[i];
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2195 */       if ((k != 0) && (n != 0)) {
/*  2196 */         this.lastBoundNeeded = true;
/*       */       }
/*       */     }
/*  2199 */     if (j != 0)
/*       */     {
/*       */ 
/*       */ 
/*  2203 */       if (n == 0)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2209 */         if (this.m_batchStyle == 2)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2216 */           pushBatch(false);
/*       */ 
/*       */ 
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/*       */ 
/*       */ 
/*  2225 */           int i2 = this.validRows;
/*       */           
/*  2227 */           this.prematureBatchCount = sendBatch();
/*  2228 */           this.validRows = i2;
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  2233 */           for (i = 0; i < this.numberOfBindPositions; i++) {
/*  2234 */             this.currentRowBinders[i].lastBoundValueCleanup(this, i);
/*       */           }
/*       */           
/*       */ 
/*  2238 */           if (k != 0) {
/*  2239 */             this.lastBoundNeeded = true;
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*  2245 */       this.needToParse = true;
/*       */       
/*       */ 
/*       */ 
/*  2249 */       this.currentRowNeedToPrepareBinds = true;
/*       */       
/*       */ 
/*  2252 */       this.needToPrepareDefineBuffer = true;
/*       */     }
/*  2254 */     else if (paramBoolean)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2260 */       pushBatch(false);
/*       */       
/*       */ 
/*       */ 
/*  2264 */       this.needToParse = false;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2272 */       this.currentBatchNeedToPrepareBinds = false;
/*       */     }
/*       */     
/*  2275 */     if (m != 0)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2282 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12);
/*  2283 */       localSQLException1.fillInStackTrace();
/*  2284 */       throw localSQLException1;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2296 */     for (int i = 0; i < this.numberOfBindPositions; i++)
/*       */     {
/*  2298 */       int i3 = this.currentRowCharLens[i];
/*       */       
/*  2300 */       if ((i3 == -1) && (this.currentRank == this.firstRowInBatch)) {
/*  2301 */         i3 = this.lastBoundCharLens[i];
/*       */       }
/*  2303 */       if (this.currentBatchCharLens[i] < i3) {
/*  2304 */         this.currentBatchCharLens[i] = i3;
/*       */       }
/*  2306 */       this.currentRowCharLens[i] = 0;
/*  2307 */       this.currentBatchFormOfUse[i] = this.currentRowFormOfUse[i];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  2312 */     if (this.currentRowNeedToPrepareBinds) {
/*  2313 */       this.currentBatchNeedToPrepareBinds = true;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2322 */     if (this.currentRowBindAccessors != null)
/*       */     {
/*  2324 */       Accessor[] arrayOfAccessor = this.currentBatchBindAccessors;
/*       */       
/*  2326 */       this.currentBatchBindAccessors = this.currentRowBindAccessors;
/*       */       
/*  2328 */       if (arrayOfAccessor == null) {
/*  2329 */         arrayOfAccessor = new Accessor[this.numberOfBindPositions];
/*       */       } else {
/*  2331 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*  2332 */           arrayOfAccessor[i] = null;
/*       */       }
/*  2334 */       this.currentRowBindAccessors = arrayOfAccessor;
/*       */     }
/*       */     
/*  2337 */     int i4 = this.currentRank + 1;
/*       */     
/*  2339 */     if (i4 < paramInt)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  2344 */       if (i4 >= this.numberOfBindRowsAllocated)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2350 */         int i5 = this.numberOfBindRowsAllocated << 1;
/*       */         
/*  2352 */         if (i5 <= i4) {
/*  2353 */           i5 = i4 + 1;
/*       */         }
/*  2355 */         growBinds(i5);
/*       */         
/*  2357 */         this.currentBatchNeedToPrepareBinds = true;
/*       */         
/*  2359 */         if (this.pushedBatches != null) {
/*  2360 */           this.pushedBatches.current_batch_need_to_prepare_binds = true;
/*       */         }
/*       */       }
/*       */       
/*  2364 */       this.currentRowBinders = this.binders[i4];
/*       */ 
/*       */ 
/*       */ 
/*       */     }
/*       */     else
/*       */     {
/*       */ 
/*       */ 
/*  2373 */       setupBindBuffers(0, paramInt);
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2380 */       this.currentRowBinders = this.binders[0];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  2385 */     this.currentRowNeedToPrepareBinds = false;
/*       */     
/*  2387 */     this.clearParameters = false;
/*       */   }
/*       */   
/*       */ 
/*       */   void processPlsqlIndexTabBinds(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  2394 */     int i = 0;
/*  2395 */     int j = 0;
/*  2396 */     int k = 0;
/*  2397 */     int m = 0;
/*       */     
/*  2399 */     Binder[] arrayOfBinder = this.binders[paramInt];
/*  2400 */     PlsqlIbtBindInfo[] arrayOfPlsqlIbtBindInfo = this.parameterPlsqlIbt == null ? null : this.parameterPlsqlIbt[paramInt];
/*       */     
/*       */     Accessor localAccessor3;
/*       */     
/*  2404 */     for (Accessor localAccessor1 = 0; localAccessor1 < this.numberOfBindPositions; localAccessor1++)
/*       */     {
/*  2406 */       Binder localBinder1 = arrayOfBinder[localAccessor1];
/*  2407 */       localAccessor3 = this.currentBatchBindAccessors == null ? null : this.currentBatchBindAccessors[localAccessor1];
/*       */       
/*  2409 */       PlsqlIndexTableAccessor localPlsqlIndexTableAccessor1 = (localAccessor3 == null) || (localAccessor3.defineType != 998) ? null : (PlsqlIndexTableAccessor)localAccessor3;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2415 */       if (localBinder1.type == 998)
/*       */       {
/*  2417 */         PlsqlIbtBindInfo localPlsqlIbtBindInfo1 = arrayOfPlsqlIbtBindInfo[localAccessor1];
/*       */         
/*  2419 */         if (localPlsqlIndexTableAccessor1 != null)
/*       */         {
/*  2421 */           if (localPlsqlIbtBindInfo1.element_internal_type != localPlsqlIndexTableAccessor1.elementInternalType)
/*       */           {
/*       */ 
/*  2424 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12);
/*  2425 */             localSQLException.fillInStackTrace();
/*  2426 */             throw localSQLException;
/*       */           }
/*       */           
/*  2429 */           if (localPlsqlIbtBindInfo1.maxLen < localPlsqlIndexTableAccessor1.maxNumberOfElements) {
/*  2430 */             localPlsqlIbtBindInfo1.maxLen = localPlsqlIndexTableAccessor1.maxNumberOfElements;
/*       */           }
/*  2432 */           if (localPlsqlIbtBindInfo1.elemMaxLen < localPlsqlIndexTableAccessor1.elementMaxLen) {
/*  2433 */             localPlsqlIbtBindInfo1.elemMaxLen = localPlsqlIndexTableAccessor1.elementMaxLen;
/*       */           }
/*  2435 */           if (localPlsqlIbtBindInfo1.ibtByteLength > 0) {
/*  2436 */             localPlsqlIbtBindInfo1.ibtByteLength = (localPlsqlIbtBindInfo1.elemMaxLen * localPlsqlIbtBindInfo1.maxLen);
/*       */           }
/*       */           else {
/*  2439 */             localPlsqlIbtBindInfo1.ibtCharLength = (localPlsqlIbtBindInfo1.elemMaxLen * localPlsqlIbtBindInfo1.maxLen);
/*       */           }
/*       */         }
/*       */         
/*  2443 */         i++;
/*  2444 */         k += localPlsqlIbtBindInfo1.ibtByteLength;
/*  2445 */         m += localPlsqlIbtBindInfo1.ibtCharLength;
/*  2446 */         j += localPlsqlIbtBindInfo1.maxLen;
/*       */       }
/*  2448 */       else if (localPlsqlIndexTableAccessor1 != null)
/*       */       {
/*  2450 */         i++;
/*  2451 */         k += localPlsqlIndexTableAccessor1.ibtByteLength;
/*  2452 */         m += localPlsqlIndexTableAccessor1.ibtCharLength;
/*  2453 */         j += localPlsqlIndexTableAccessor1.maxNumberOfElements;
/*       */       }
/*       */     }
/*       */     
/*  2457 */     if (i == 0) {
/*  2458 */       return;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2485 */     this.ibtBindIndicatorSize = (6 + i * 8 + j * 2);
/*       */     
/*       */ 
/*  2488 */     this.ibtBindIndicators = new short[this.ibtBindIndicatorSize];
/*  2489 */     this.ibtBindIndicatorOffset = 0;
/*       */     
/*  2491 */     if (k > 0)
/*  2492 */       this.ibtBindBytes = new byte[k];
/*  2493 */     this.ibtBindByteOffset = 0;
/*       */     
/*  2495 */     if (m > 0)
/*  2496 */       this.ibtBindChars = new char[m];
/*  2497 */     this.ibtBindCharOffset = 0;
/*       */     
/*  2499 */     localAccessor1 = this.ibtBindByteOffset;
/*  2500 */     Accessor localAccessor2 = this.ibtBindCharOffset;
/*       */     
/*  2502 */     int n = this.ibtBindIndicatorOffset;
/*  2503 */     int i1 = n + 6 + i * 8;
/*       */     
/*  2505 */     this.ibtBindIndicators[(n++)] = ((short)(i >> 16));
/*  2506 */     this.ibtBindIndicators[(n++)] = ((short)(i & 0xFFFF));
/*       */     
/*  2508 */     this.ibtBindIndicators[(n++)] = ((short)(k >> 16));
/*  2509 */     this.ibtBindIndicators[(n++)] = ((short)(k & 0xFFFF));
/*  2510 */     this.ibtBindIndicators[(n++)] = ((short)(m >> 16));
/*  2511 */     this.ibtBindIndicators[(n++)] = ((short)(m & 0xFFFF));
/*       */     
/*       */ 
/*  2514 */     for (int i2 = 0; i2 < this.numberOfBindPositions; i2++)
/*       */     {
/*  2516 */       Binder localBinder2 = arrayOfBinder[i2];
/*  2517 */       Accessor localAccessor4 = this.currentBatchBindAccessors == null ? null : this.currentBatchBindAccessors[i2];
/*       */       
/*  2519 */       PlsqlIndexTableAccessor localPlsqlIndexTableAccessor2 = (localAccessor4 == null) || (localAccessor4.defineType != 998) ? null : (PlsqlIndexTableAccessor)localAccessor4;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2525 */       if (localBinder2.type == 998)
/*       */       {
/*  2527 */         PlsqlIbtBindInfo localPlsqlIbtBindInfo2 = arrayOfPlsqlIbtBindInfo[i2];
/*  2528 */         int i4 = localPlsqlIbtBindInfo2.maxLen;
/*       */         
/*  2530 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIbtBindInfo2.element_internal_type);
/*       */         
/*  2532 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIbtBindInfo2.elemMaxLen);
/*  2533 */         this.ibtBindIndicators[(n++)] = ((short)(i4 >> 16));
/*  2534 */         this.ibtBindIndicators[(n++)] = ((short)(i4 & 0xFFFF));
/*  2535 */         this.ibtBindIndicators[(n++)] = ((short)(localPlsqlIbtBindInfo2.curLen >> 16));
/*  2536 */         this.ibtBindIndicators[(n++)] = ((short)(localPlsqlIbtBindInfo2.curLen & 0xFFFF));
/*       */         
/*  2538 */         if (localPlsqlIbtBindInfo2.ibtByteLength > 0)
/*       */         {
/*  2540 */           localAccessor3 = localAccessor1;
/*  2541 */           localAccessor1 += localPlsqlIbtBindInfo2.ibtByteLength;
/*       */         }
/*       */         else
/*       */         {
/*  2545 */           localAccessor3 = localAccessor2;
/*  2546 */           localAccessor2 += localPlsqlIbtBindInfo2.ibtCharLength;
/*       */         }
/*       */         
/*  2549 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 >> 16));
/*  2550 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 & 0xFFFF));
/*  2551 */         localPlsqlIbtBindInfo2.ibtValueIndex = localAccessor3;
/*       */         
/*  2553 */         localPlsqlIbtBindInfo2.ibtIndicatorIndex = i1;
/*  2554 */         localPlsqlIbtBindInfo2.ibtLengthIndex = (i1 + i4);
/*       */         
/*  2556 */         if (localPlsqlIndexTableAccessor2 != null)
/*       */         {
/*  2558 */           localPlsqlIndexTableAccessor2.ibtIndicatorIndex = localPlsqlIbtBindInfo2.ibtIndicatorIndex;
/*  2559 */           localPlsqlIndexTableAccessor2.ibtLengthIndex = localPlsqlIbtBindInfo2.ibtLengthIndex;
/*  2560 */           localPlsqlIndexTableAccessor2.ibtMetaIndex = (n - 8);
/*  2561 */           localPlsqlIndexTableAccessor2.ibtValueIndex = localAccessor3;
/*       */         }
/*       */         
/*  2564 */         i1 += 2 * i4;
/*       */       }
/*  2566 */       else if (localPlsqlIndexTableAccessor2 != null)
/*       */       {
/*       */ 
/*  2569 */         int i3 = localPlsqlIndexTableAccessor2.maxNumberOfElements;
/*       */         
/*  2571 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIndexTableAccessor2.elementInternalType);
/*       */         
/*  2573 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIndexTableAccessor2.elementMaxLen);
/*  2574 */         this.ibtBindIndicators[(n++)] = ((short)(i3 >> 16));
/*  2575 */         this.ibtBindIndicators[(n++)] = ((short)(i3 & 0xFFFF));
/*  2576 */         this.ibtBindIndicators[(n++)] = 0;
/*  2577 */         this.ibtBindIndicators[(n++)] = 0;
/*       */         
/*  2579 */         if (localPlsqlIndexTableAccessor2.ibtByteLength > 0)
/*       */         {
/*  2581 */           localAccessor3 = localAccessor1;
/*  2582 */           localAccessor1 += localPlsqlIndexTableAccessor2.ibtByteLength;
/*       */         }
/*       */         else
/*       */         {
/*  2586 */           localAccessor3 = localAccessor2;
/*  2587 */           localAccessor2 += localPlsqlIndexTableAccessor2.ibtCharLength;
/*       */         }
/*       */         
/*  2590 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 >> 16));
/*  2591 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 & 0xFFFF));
/*  2592 */         localPlsqlIndexTableAccessor2.ibtValueIndex = localAccessor3;
/*       */         
/*  2594 */         localPlsqlIndexTableAccessor2.ibtIndicatorIndex = i1;
/*  2595 */         localPlsqlIndexTableAccessor2.ibtLengthIndex = (i1 + i3);
/*  2596 */         localPlsqlIndexTableAccessor2.ibtMetaIndex = (n - 8);
/*       */         
/*  2598 */         i1 += 2 * i3;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void initializeBindSubRanges(int paramInt1, int paramInt2)
/*       */   {
/*  2623 */     this.bindByteSubRange = 0;
/*  2624 */     this.bindCharSubRange = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   int calculateIndicatorSubRangeSize()
/*       */   {
/*  2632 */     return 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   short getInoutIndicator(int paramInt)
/*       */   {
/*  2639 */     return 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void initializeIndicatorSubRange()
/*       */   {
/*  2646 */     this.bindIndicatorSubRange = calculateIndicatorSubRangeSize();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void prepareBindPreambles(int paramInt1, int paramInt2) {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setupBindBuffers(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*       */     try
/*       */     {
/*  2709 */       if (this.numberOfBindPositions == 0)
/*       */       {
/*  2711 */         if (paramInt2 != 0)
/*       */         {
/*  2713 */           if (this.bindIndicators == null) { allocBinds(paramInt2);
/*       */           }
/*  2715 */           this.numberOfBoundRows = paramInt2;
/*  2716 */           this.bindIndicators[(this.bindIndicatorSubRange + 3)] = ((short)((this.numberOfBoundRows & 0xFFFF0000) >> 16));
/*       */           
/*       */ 
/*  2719 */           this.bindIndicators[(this.bindIndicatorSubRange + 4)] = ((short)(this.numberOfBoundRows & 0xFFFF));
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*  2724 */         return;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2731 */       this.preparedAllBinds = this.currentBatchNeedToPrepareBinds;
/*  2732 */       this.preparedCharBinds = false;
/*       */       
/*       */ 
/*       */ 
/*  2736 */       this.currentBatchNeedToPrepareBinds = false;
/*       */       
/*       */ 
/*  2739 */       this.numberOfBoundRows = paramInt2;
/*  2740 */       this.bindIndicators[(this.bindIndicatorSubRange + 3)] = ((short)((this.numberOfBoundRows & 0xFFFF0000) >> 16));
/*       */       
/*       */ 
/*  2743 */       this.bindIndicators[(this.bindIndicatorSubRange + 4)] = ((short)(this.numberOfBoundRows & 0xFFFF));
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2751 */       int j = this.bindBufferCapacity;
/*       */       
/*  2753 */       if (this.numberOfBoundRows > this.bindBufferCapacity)
/*       */       {
/*  2755 */         j = this.numberOfBoundRows;
/*  2756 */         this.preparedAllBinds = true;
/*       */       }
/*       */       
/*  2759 */       if (this.currentBatchBindAccessors != null)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2766 */         if (this.outBindAccessors == null) {
/*  2767 */           this.outBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */         }
/*  2769 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2771 */           Accessor localAccessor1 = this.currentBatchBindAccessors[i];
/*       */           
/*  2773 */           this.outBindAccessors[i] = localAccessor1;
/*       */           
/*  2775 */           if (localAccessor1 != null)
/*       */           {
/*  2777 */             m = localAccessor1.charLength;
/*       */             
/*  2779 */             if ((m == 0) || (this.currentBatchCharLens[i] < m))
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*  2784 */               this.currentBatchCharLens[i] = m;
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*  2790 */       int k = 0;
/*  2791 */       int m = 0;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2797 */       int n = this.bindIndicatorSubRange + 5;
/*       */       
/*  2799 */       int i1 = n;
/*       */       
/*  2801 */       if (this.preparedAllBinds)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*  2806 */         this.preparedCharBinds = true;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2812 */         Binder[] arrayOfBinder = this.binders[paramInt1];
/*       */         
/*  2814 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2816 */           Binder localBinder = arrayOfBinder[i];
/*       */           
/*       */ 
/*  2819 */           i6 = this.currentBatchCharLens[i];
/*       */           
/*  2821 */           if (localBinder == this.theOutBinder)
/*       */           {
/*  2823 */             Accessor localAccessor2 = this.currentBatchBindAccessors[i];
/*  2824 */             i5 = localAccessor2.byteLength;
/*  2825 */             i4 = (short)localAccessor2.defineType;
/*       */           }
/*       */           else
/*       */           {
/*  2829 */             i5 = localBinder.bytelen;
/*  2830 */             i4 = localBinder.type;
/*       */           }
/*       */           
/*       */ 
/*  2834 */           if ((localBinder == this.theRawNullBinder) && (this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK))
/*       */           {
/*  2836 */             i5 = 32767;
/*       */           }
/*       */           
/*  2839 */           m += i5;
/*  2840 */           k += i6;
/*  2841 */           this.bindIndicators[(i1 + 0)] = i4;
/*  2842 */           this.bindIndicators[(i1 + 1)] = ((short)i5);
/*       */           
/*  2844 */           this.bindIndicators[(i1 + 2)] = ((short)i6);
/*       */           
/*  2846 */           this.bindIndicators[(i1 + 9)] = this.currentBatchFormOfUse[i];
/*       */           
/*  2848 */           i1 += 10;
/*       */         }
/*       */       } else {
/*  2851 */         if (this.preparedCharBinds)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2857 */           for (i = 0; i < this.numberOfBindPositions; i++)
/*       */           {
/*  2859 */             i2 = this.currentBatchCharLens[i];
/*       */             
/*  2861 */             k += i2;
/*  2862 */             this.bindIndicators[(i1 + 2)] = ((short)i2);
/*       */             
/*  2864 */             i1 += 10;
/*       */           }
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2879 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2881 */           i2 = i1 + 2;
/*  2882 */           i3 = this.currentBatchCharLens[i];
/*  2883 */           i4 = this.bindIndicators[i2];
/*  2884 */           i5 = (this.bindIndicators[(i1 + 5)] << 16) + (this.bindIndicators[(i1 + 6)] & 0xFFFF);
/*       */           
/*       */ 
/*  2887 */           i6 = this.bindIndicators[i5] == -1 ? 1 : 0;
/*       */           
/*       */ 
/*       */ 
/*  2891 */           if ((i6 != 0) && (i3 > 1))
/*       */           {
/*  2893 */             this.preparedCharBinds = true;
/*       */           }
/*       */           
/*  2896 */           if ((i4 >= i3) && (!this.preparedCharBinds))
/*       */           {
/*  2898 */             this.currentBatchCharLens[i] = i4;
/*  2899 */             k += i4;
/*       */           }
/*       */           else
/*       */           {
/*  2903 */             this.bindIndicators[i2] = ((short)i3);
/*  2904 */             k += i3;
/*  2905 */             this.preparedCharBinds = true;
/*       */           }
/*       */           
/*  2908 */           i1 += 10;
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2920 */       if (this.preparedCharBinds) {
/*  2921 */         initializeBindSubRanges(this.numberOfBoundRows, j);
/*       */       }
/*  2923 */       if (this.preparedAllBinds)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2929 */         i2 = this.bindByteSubRange + m * j;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*  2934 */         if ((this.lastBoundNeeded) || (i2 > this.totalBindByteLength))
/*       */         {
/*       */ 
/*       */ 
/*  2938 */           this.bindByteOffset = 0;
/*  2939 */           this.bindBytes = this.connection.getByteBuffer(i2);
/*       */           
/*       */ 
/*  2942 */           this.totalBindByteLength = i2;
/*       */         }
/*       */         
/*       */ 
/*  2946 */         this.bindBufferCapacity = j;
/*       */         
/*       */ 
/*  2949 */         this.bindIndicators[(this.bindIndicatorSubRange + 1)] = ((short)((this.bindBufferCapacity & 0xFFFF0000) >> 16));
/*       */         
/*       */ 
/*  2952 */         this.bindIndicators[(this.bindIndicatorSubRange + 2)] = ((short)(this.bindBufferCapacity & 0xFFFF));
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  2958 */       if (this.preparedCharBinds)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2964 */         i2 = this.bindCharSubRange + k * this.bindBufferCapacity;
/*       */         
/*       */ 
/*       */ 
/*  2968 */         if ((this.lastBoundNeeded) || (i2 > this.totalBindCharLength))
/*       */         {
/*       */ 
/*       */ 
/*  2972 */           this.bindCharOffset = 0;
/*  2973 */           this.bindChars = this.connection.getCharBuffer(i2);
/*       */           
/*       */ 
/*  2976 */           this.totalBindCharLength = i2;
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*  2981 */         this.bindByteSubRange += this.bindByteOffset;
/*  2982 */         this.bindCharSubRange += this.bindCharOffset;
/*       */       }
/*       */       
/*       */ 
/*  2986 */       int i2 = this.bindByteSubRange;
/*  2987 */       int i3 = this.bindCharSubRange;
/*  2988 */       int i4 = this.indicatorsOffset;
/*  2989 */       int i5 = this.valueLengthsOffset;
/*       */       
/*  2991 */       i1 = n;
/*       */       
/*  2993 */       if (this.preparedCharBinds)
/*       */       {
/*  2995 */         if (this.currentBatchBindAccessors == null)
/*       */         {
/*       */ 
/*       */ 
/*  2999 */           for (i = 0; i < this.numberOfBindPositions; i++)
/*       */           {
/*       */ 
/*       */ 
/*  3003 */             i6 = this.bindIndicators[(i1 + 1)];
/*       */             
/*  3005 */             i7 = this.currentBatchCharLens[i];
/*       */             
/*  3007 */             i8 = i7 == 0 ? i2 : i3;
/*       */             
/*       */ 
/*  3010 */             this.bindIndicators[(i1 + 3)] = ((short)(i8 >> 16));
/*       */             
/*       */ 
/*  3013 */             this.bindIndicators[(i1 + 4)] = ((short)(i8 & 0xFFFF));
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*  3018 */             i2 += i6 * this.bindBufferCapacity;
/*  3019 */             i3 += i7 * this.bindBufferCapacity;
/*  3020 */             i1 += 10;
/*       */           }
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3029 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*       */ 
/*       */ 
/*  3033 */           i6 = this.bindIndicators[(i1 + 1)];
/*       */           
/*  3035 */           i7 = this.currentBatchCharLens[i];
/*       */           
/*  3037 */           i8 = i7 == 0 ? i2 : i3;
/*       */           
/*       */ 
/*  3040 */           this.bindIndicators[(i1 + 3)] = ((short)(i8 >> 16));
/*       */           
/*       */ 
/*  3043 */           this.bindIndicators[(i1 + 4)] = ((short)(i8 & 0xFFFF));
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  3048 */           localObject = this.currentBatchBindAccessors[i];
/*       */           
/*  3050 */           if (localObject != null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  3055 */             if (i7 > 0)
/*       */             {
/*  3057 */               ((Accessor)localObject).columnIndex = i3;
/*  3058 */               ((Accessor)localObject).charLength = i7;
/*       */             }
/*       */             else
/*       */             {
/*  3062 */               ((Accessor)localObject).columnIndex = i2;
/*  3063 */               ((Accessor)localObject).byteLength = i6;
/*       */             }
/*       */             
/*  3066 */             ((Accessor)localObject).lengthIndex = i5;
/*  3067 */             ((Accessor)localObject).indicatorIndex = i4;
/*  3068 */             ((Accessor)localObject).rowSpaceByte = this.bindBytes;
/*  3069 */             ((Accessor)localObject).rowSpaceChar = this.bindChars;
/*  3070 */             ((Accessor)localObject).rowSpaceIndicator = this.bindIndicators;
/*       */             
/*  3072 */             if ((((Accessor)localObject).defineType == 109) || (((Accessor)localObject).defineType == 111))
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*  3077 */               ((Accessor)localObject).setOffsets(this.bindBufferCapacity);
/*       */             }
/*       */           }
/*       */           
/*       */ 
/*  3082 */           i2 += i6 * this.bindBufferCapacity;
/*  3083 */           i3 += i7 * this.bindBufferCapacity;
/*  3084 */           i4 += this.numberOfBindRowsAllocated;
/*  3085 */           i5 += this.numberOfBindRowsAllocated;
/*  3086 */           i1 += 10;
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*  3092 */         i2 = this.bindByteSubRange;
/*  3093 */         i3 = this.bindCharSubRange;
/*  3094 */         i4 = this.indicatorsOffset;
/*  3095 */         i5 = this.valueLengthsOffset;
/*  3096 */         i1 = n;
/*       */       }
/*       */       
/*       */ 
/*  3100 */       int i6 = this.bindBufferCapacity - this.numberOfBoundRows;
/*  3101 */       int i7 = this.numberOfBoundRows - 1;
/*  3102 */       int i8 = i7 + paramInt1;
/*  3103 */       Object localObject = this.binders[i8];
/*       */       
/*  3105 */       if (this.parameterOtype != null)
/*       */       {
/*  3107 */         System.arraycopy(this.parameterDatum[i8], 0, this.lastBoundTypeBytes, 0, this.numberOfBindPositions);
/*       */         
/*  3109 */         System.arraycopy(this.parameterOtype[i8], 0, this.lastBoundTypeOtypes, 0, this.numberOfBindPositions);
/*       */       }
/*       */       
/*       */ 
/*  3113 */       if (this.hasIbtBind) {
/*  3114 */         processPlsqlIndexTabBinds(paramInt1);
/*       */       }
/*  3116 */       if ((this.numReturnParams > 0) && ((this.returnParamAccessors == null) || (this.returnParamAccessors.length < this.numReturnParams)))
/*       */       {
/*       */ 
/*       */ 
/*  3120 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173);
/*  3121 */         localSQLException2.fillInStackTrace();
/*  3122 */         throw localSQLException2;
/*       */       }
/*       */       
/*  3125 */       if (this.returnParamAccessors != null) { processDmlReturningBind();
/*       */       }
/*  3127 */       boolean bool = (!this.sqlKind.isPlsqlOrCall()) || (this.currentRowBindAccessors == null);
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3137 */       for (int i = 0; i < this.numberOfBindPositions; i++)
/*       */       {
/*       */ 
/*       */ 
/*  3141 */         int i9 = this.bindIndicators[(i1 + 1)];
/*       */         
/*  3143 */         int i10 = this.currentBatchCharLens[i];
/*       */         
/*       */ 
/*  3146 */         this.lastBinders[i] = localObject[i];
/*  3147 */         this.lastBoundByteLens[i] = i9;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3156 */         for (int i11 = 0; i11 < this.numberOfBoundRows; 
/*  3157 */             i11++)
/*       */         {
/*  3159 */           int i12 = paramInt1 + i11;
/*       */           
/*  3161 */           this.binders[i12][i].bind(this, i, i11, i12, this.bindBytes, this.bindChars, this.bindIndicators, i9, i10, i2, i3, i5 + i11, i4 + i11, bool);
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3168 */           this.binders[i12][i] = null;
/*  3169 */           if (this.userStream != null) { this.userStream[i11][i] = null;
/*       */           }
/*  3171 */           i2 += i9;
/*  3172 */           i3 += i10;
/*       */         }
/*       */         
/*       */ 
/*  3176 */         this.lastBoundByteOffsets[i] = (i2 - i9);
/*  3177 */         this.lastBoundCharOffsets[i] = (i3 - i10);
/*  3178 */         this.lastBoundInds[i] = this.bindIndicators[(i4 + i7)];
/*  3179 */         this.lastBoundLens[i] = this.bindIndicators[(i5 + i7)];
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*  3184 */         this.lastBoundCharLens[i] = 0;
/*       */         
/*       */ 
/*  3187 */         i2 += i6 * i9;
/*  3188 */         i3 += i6 * i10;
/*  3189 */         i4 += this.numberOfBindRowsAllocated;
/*  3190 */         i5 += this.numberOfBindRowsAllocated;
/*  3191 */         i1 += 10;
/*       */       }
/*       */       
/*       */ 
/*  3195 */       this.lastBoundBytes = this.bindBytes;
/*  3196 */       this.lastBoundByteOffset = this.bindByteOffset;
/*  3197 */       this.lastBoundChars = this.bindChars;
/*  3198 */       this.lastBoundCharOffset = this.bindCharOffset;
/*  3199 */       if (this.parameterStream != null) {
/*  3200 */         this.lastBoundStream = this.parameterStream[(paramInt1 + this.numberOfBoundRows - 1)];
/*       */       }
/*       */       
/*       */ 
/*  3204 */       int[] arrayOfInt = this.currentBatchCharLens;
/*       */       
/*  3206 */       this.currentBatchCharLens = this.lastBoundCharLens;
/*  3207 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/*       */ 
/*  3210 */       this.lastBoundNeeded = false;
/*       */       
/*       */ 
/*       */ 
/*  3214 */       prepareBindPreambles(this.numberOfBoundRows, this.bindBufferCapacity);
/*       */ 
/*       */ 
/*       */     }
/*       */     catch (NullPointerException localNullPointerException)
/*       */     {
/*       */ 
/*  3221 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  3222 */       localSQLException1.fillInStackTrace();
/*  3223 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void releaseBuffers()
/*       */   {
/*  3235 */     this.cachedBindCharSize = (this.bindChars != null ? this.bindChars.length : 0);
/*  3236 */     if (this.bindChars != this.lastBoundChars) this.connection.cacheBuffer(this.lastBoundChars);
/*  3237 */     this.lastBoundChars = null;
/*  3238 */     this.connection.cacheBuffer(this.bindChars);
/*  3239 */     this.bindChars = null;
/*       */     
/*  3241 */     this.cachedBindByteSize = (this.bindBytes != null ? this.bindBytes.length : 0);
/*  3242 */     if (this.bindBytes != this.lastBoundBytes) this.connection.cacheBuffer(this.lastBoundBytes);
/*  3243 */     this.lastBoundBytes = null;
/*  3244 */     this.connection.cacheBuffer(this.bindBytes);
/*  3245 */     this.bindBytes = null;
/*       */     
/*  3247 */     super.releaseBuffers();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void enterImplicitCache()
/*       */     throws SQLException
/*       */   {
/*  3265 */     alwaysOnClose();
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  3270 */     if (!this.connection.isClosed())
/*       */     {
/*  3272 */       cleanAllTempLobs();
/*       */     }
/*       */     
/*  3275 */     if (this.connection.clearStatementMetaData)
/*       */     {
/*  3277 */       this.lastBoundBytes = null;
/*  3278 */       this.lastBoundChars = null;
/*       */     }
/*       */     
/*  3281 */     clearParameters();
/*       */     
/*       */ 
/*       */ 
/*  3285 */     this.cacheState = 2;
/*  3286 */     this.creationState = 1;
/*       */     
/*       */ 
/*       */ 
/*  3290 */     this.currentResultSet = null;
/*  3291 */     this.lastIndex = 0;
/*       */     
/*  3293 */     this.queryTimeout = 0;
/*  3294 */     this.autoRollback = 2;
/*       */     
/*       */ 
/*  3297 */     this.rowPrefetchChanged = false;
/*  3298 */     this.currentRank = 0;
/*  3299 */     this.currentRow = -1;
/*  3300 */     this.validRows = 0;
/*  3301 */     this.maxRows = 0;
/*  3302 */     this.totalRowsVisited = 0;
/*  3303 */     this.maxFieldSize = 0;
/*  3304 */     this.gotLastBatch = false;
/*  3305 */     this.clearParameters = true;
/*  3306 */     this.scrollRset = null;
/*  3307 */     this.defaultFetchDirection = 1000;
/*  3308 */     this.defaultTimeZone = null;
/*  3309 */     this.defaultCalendar = null;
/*  3310 */     this.checkSum = 0L;
/*  3311 */     this.checkSumComputationFailure = false;
/*       */     
/*  3313 */     if (this.sqlKind.isOTHER())
/*       */     {
/*  3315 */       this.needToParse = true;
/*  3316 */       this.needToPrepareDefineBuffer = true;
/*  3317 */       this.columnsDefinedByUser = false;
/*       */     }
/*       */     
/*  3320 */     releaseBuffers();
/*       */     
/*       */ 
/*  3323 */     this.definedColumnType = null;
/*  3324 */     this.definedColumnSize = null;
/*  3325 */     this.definedColumnFormOfUse = null;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  3330 */     if (this.accessors != null)
/*       */     {
/*  3332 */       int i = this.accessors.length;
/*       */       
/*  3334 */       for (int j = 0; j < i; j++)
/*       */       {
/*  3336 */         if (this.accessors[j] != null)
/*       */         {
/*  3338 */           this.accessors[j].rowSpaceByte = null;
/*  3339 */           this.accessors[j].rowSpaceChar = null;
/*  3340 */           this.accessors[j].rowSpaceIndicator = null;
/*  3341 */           if (this.columnsDefinedByUser) {
/*  3342 */             this.accessors[j].externalType = 0;
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  3349 */     this.fixedString = this.connection.getDefaultFixedString();
/*  3350 */     this.defaultRowPrefetch = this.rowPrefetch;
/*  3351 */     this.rowPrefetchInLastFetch = -1;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3357 */     if (this.connection.clearStatementMetaData)
/*       */     {
/*       */ 
/*       */ 
/*  3361 */       this.sqlStringChanged = true;
/*  3362 */       this.needToParse = true;
/*  3363 */       this.needToPrepareDefineBuffer = true;
/*  3364 */       this.columnsDefinedByUser = false;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  3369 */       if (this.userRsetType == 0)
/*       */       {
/*  3371 */         this.userRsetType = 1;
/*  3372 */         this.realRsetType = 1;
/*       */       }
/*  3374 */       this.currentRowNeedToPrepareBinds = true;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void enterExplicitCache()
/*       */     throws SQLException
/*       */   {
/*  3392 */     this.cacheState = 2;
/*  3393 */     this.creationState = 2;
/*  3394 */     this.defaultTimeZone = null;
/*       */     
/*  3396 */     alwaysOnClose();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitImplicitCacheToActive()
/*       */     throws SQLException
/*       */   {
/*  3411 */     this.cacheState = 1;
/*  3412 */     this.closed = false;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3419 */     if (this.rowPrefetch != this.connection.getDefaultRowPrefetch())
/*       */     {
/*  3421 */       if (this.streamList == null)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3429 */         this.rowPrefetch = this.connection.getDefaultRowPrefetch();
/*  3430 */         this.defaultRowPrefetch = this.rowPrefetch;
/*       */         
/*       */ 
/*  3433 */         this.rowPrefetchChanged = true;
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3442 */     if (this.batch != this.connection.getDefaultExecuteBatch())
/*       */     {
/*  3444 */       resetBatch();
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3452 */     this.processEscapes = this.connection.processEscapes;
/*       */     
/*  3454 */     if (this.cachedDefineIndicatorSize != 0)
/*       */     {
/*  3456 */       this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
/*  3457 */       this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
/*  3458 */       this.defineIndicators = new short[this.cachedDefineIndicatorSize];
/*  3459 */       if (this.accessors != null)
/*       */       {
/*  3461 */         int i = this.accessors.length;
/*       */         
/*  3463 */         for (int j = 0; j < i; j++)
/*       */         {
/*  3465 */           if (this.accessors[j] != null)
/*       */           {
/*  3467 */             this.accessors[j].rowSpaceByte = this.defineBytes;
/*  3468 */             this.accessors[j].rowSpaceChar = this.defineChars;
/*  3469 */             this.accessors[j].rowSpaceIndicator = this.defineIndicators;
/*       */           }
/*       */         }
/*  3472 */         doInitializationAfterDefineBufferRestore();
/*       */       }
/*       */     }
/*       */     
/*  3476 */     if ((this.cachedBindCharSize != 0) || (this.cachedBindByteSize != 0))
/*       */     {
/*  3478 */       if (this.cachedBindByteSize > 0)
/*  3479 */         this.bindBytes = this.connection.getByteBuffer(this.cachedBindByteSize);
/*  3480 */       if (this.cachedBindCharSize > 0)
/*  3481 */         this.bindChars = this.connection.getCharBuffer(this.cachedBindCharSize);
/*  3482 */       doLocalInitialization();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doLocalInitialization() {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doInitializationAfterDefineBufferRestore() {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitExplicitCacheToActive()
/*       */     throws SQLException
/*       */   {
/*  3514 */     this.cacheState = 1;
/*  3515 */     this.closed = false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitImplicitCacheToClose()
/*       */     throws SQLException
/*       */   {
/*  3530 */     this.cacheState = 0;
/*  3531 */     this.closed = false;
/*       */     
/*  3533 */     synchronized (this.connection) {
/*  3534 */       hardClose();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitExplicitCacheToClose()
/*       */     throws SQLException
/*       */   {
/*  3550 */     this.cacheState = 0;
/*  3551 */     this.closed = false;
/*       */     
/*  3553 */     synchronized (this.connection) {
/*  3554 */       hardClose();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void closeWithKey(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3570 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  3575 */       closeOrCache(paramString);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   int executeInternal()
/*       */     throws SQLException
/*       */   {
/*  3583 */     this.noMoreUpdateCounts = false;
/*  3584 */     this.checkSum = 0L;
/*  3585 */     this.checkSumComputationFailure = false;
/*       */     
/*  3587 */     ensureOpen();
/*       */     
/*       */ 
/*  3590 */     if ((this.currentRank > 0) && (this.m_batchStyle == 2))
/*       */     {
/*       */ 
/*  3593 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/*  3594 */       localSQLException.fillInStackTrace();
/*  3595 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  3599 */     int i = this.userRsetType == 1 ? 1 : 0;
/*       */     
/*  3601 */     prepareForNewResults(true, false);
/*       */     
/*  3603 */     processCompletedBindRow(this.sqlKind.isSELECT() ? 1 : this.batch, false);
/*       */     
/*  3605 */     if ((i == 0) && (!this.scrollRsetTypeSolved)) {
/*  3606 */       return doScrollPstmtExecuteUpdate() + this.prematureBatchCount;
/*       */     }
/*  3608 */     doExecuteWithTimeout();
/*       */     
/*  3610 */     int j = (this.prematureBatchCount != 0) && (this.validRows > 0) ? 1 : 0;
/*       */     
/*  3612 */     if (i == 0)
/*       */     {
/*  3614 */       this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*  3615 */       this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType);
/*       */       
/*       */ 
/*       */ 
/*  3619 */       if (!this.connection.accumulateBatchResult) {
/*  3620 */         j = 0;
/*       */       }
/*       */     }
/*  3623 */     if (j != 0)
/*       */     {
/*       */ 
/*  3626 */       this.validRows += this.prematureBatchCount;
/*  3627 */       this.prematureBatchCount = 0;
/*       */     }
/*  3629 */     if (this.sqlKind.isOTHER()) this.needToParse = true;
/*  3630 */     return this.validRows;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public ResultSet executeQuery()
/*       */     throws SQLException
/*       */   {
/*  3644 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3650 */       this.executionType = 1;
/*       */       
/*  3652 */       executeInternal();
/*       */       
/*  3654 */       if (this.userRsetType == 1)
/*       */       {
/*  3656 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*       */         
/*  3658 */         return this.currentResultSet;
/*       */       }
/*       */       
/*       */ 
/*  3662 */       if (this.scrollRset == null)
/*       */       {
/*  3664 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*  3665 */         this.scrollRset = this.currentResultSet;
/*       */       }
/*       */       
/*  3668 */       return this.scrollRset;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int executeUpdate()
/*       */     throws SQLException
/*       */   {
/*  3682 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  3687 */       this.executionType = 2;
/*       */       
/*  3689 */       return executeInternal();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean execute()
/*       */     throws SQLException
/*       */   {
/*  3702 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  3707 */       this.executionType = 3;
/*       */       
/*  3709 */       executeInternal();
/*       */       
/*  3711 */       return this.sqlKind.isSELECT();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void slideDownCurrentRow(int paramInt)
/*       */   {
/*  3729 */     if (this.binders != null)
/*       */     {
/*  3731 */       this.binders[paramInt] = this.binders[0];
/*  3732 */       this.binders[0] = this.currentRowBinders;
/*       */     }
/*       */     
/*       */     Object localObject;
/*  3736 */     if (this.parameterInt != null)
/*       */     {
/*  3738 */       localObject = this.parameterInt[0];
/*       */       
/*  3740 */       this.parameterInt[0] = this.parameterInt[paramInt];
/*  3741 */       this.parameterInt[paramInt] = localObject;
/*       */     }
/*       */     
/*  3744 */     if (this.parameterLong != null)
/*       */     {
/*  3746 */       localObject = this.parameterLong[0];
/*       */       
/*  3748 */       this.parameterLong[0] = this.parameterLong[paramInt];
/*  3749 */       this.parameterLong[paramInt] = localObject;
/*       */     }
/*       */     
/*  3752 */     if (this.parameterFloat != null)
/*       */     {
/*  3754 */       localObject = this.parameterFloat[0];
/*       */       
/*  3756 */       this.parameterFloat[0] = this.parameterFloat[paramInt];
/*  3757 */       this.parameterFloat[paramInt] = localObject;
/*       */     }
/*       */     
/*  3760 */     if (this.parameterDouble != null)
/*       */     {
/*  3762 */       localObject = this.parameterDouble[0];
/*       */       
/*  3764 */       this.parameterDouble[0] = this.parameterDouble[paramInt];
/*  3765 */       this.parameterDouble[paramInt] = localObject;
/*       */     }
/*       */     
/*  3768 */     if (this.parameterBigDecimal != null)
/*       */     {
/*  3770 */       localObject = this.parameterBigDecimal[0];
/*       */       
/*  3772 */       this.parameterBigDecimal[0] = this.parameterBigDecimal[paramInt];
/*  3773 */       this.parameterBigDecimal[paramInt] = localObject;
/*       */     }
/*       */     
/*  3776 */     if (this.parameterString != null)
/*       */     {
/*  3778 */       localObject = this.parameterString[0];
/*       */       
/*  3780 */       this.parameterString[0] = this.parameterString[paramInt];
/*  3781 */       this.parameterString[paramInt] = localObject;
/*       */     }
/*       */     
/*  3784 */     if (this.parameterDate != null)
/*       */     {
/*  3786 */       localObject = this.parameterDate[0];
/*       */       
/*  3788 */       this.parameterDate[0] = this.parameterDate[paramInt];
/*  3789 */       this.parameterDate[paramInt] = localObject;
/*       */     }
/*       */     
/*  3792 */     if (this.parameterTime != null)
/*       */     {
/*  3794 */       localObject = this.parameterTime[0];
/*       */       
/*  3796 */       this.parameterTime[0] = this.parameterTime[paramInt];
/*  3797 */       this.parameterTime[paramInt] = localObject;
/*       */     }
/*       */     
/*  3800 */     if (this.parameterTimestamp != null)
/*       */     {
/*  3802 */       localObject = this.parameterTimestamp[0];
/*       */       
/*  3804 */       this.parameterTimestamp[0] = this.parameterTimestamp[paramInt];
/*  3805 */       this.parameterTimestamp[paramInt] = localObject;
/*       */     }
/*       */     
/*  3808 */     if (this.parameterDatum != null)
/*       */     {
/*  3810 */       localObject = this.parameterDatum[0];
/*       */       
/*  3812 */       this.parameterDatum[0] = this.parameterDatum[paramInt];
/*  3813 */       this.parameterDatum[paramInt] = localObject;
/*       */     }
/*       */     
/*  3816 */     if (this.parameterOtype != null)
/*       */     {
/*  3818 */       localObject = this.parameterOtype[0];
/*       */       
/*  3820 */       this.parameterOtype[0] = this.parameterOtype[paramInt];
/*  3821 */       this.parameterOtype[paramInt] = localObject;
/*       */     }
/*       */     
/*  3824 */     if (this.parameterStream != null)
/*       */     {
/*  3826 */       localObject = this.parameterStream[0];
/*       */       
/*  3828 */       this.parameterStream[0] = this.parameterStream[paramInt];
/*  3829 */       this.parameterStream[paramInt] = localObject;
/*       */     }
/*       */     
/*  3832 */     if (this.userStream != null)
/*       */     {
/*  3834 */       localObject = this.userStream[0];
/*       */       
/*  3836 */       this.userStream[0] = this.userStream[paramInt];
/*  3837 */       this.userStream[paramInt] = localObject;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void resetBatch()
/*       */   {
/*  3845 */     this.batch = this.connection.getDefaultExecuteBatch();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int sendBatch()
/*       */     throws SQLException
/*       */   {
/*  3875 */     if (isJdbcBatchStyle())
/*       */     {
/*  3877 */       return 0;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  3882 */     synchronized (this.connection)
/*       */     {
/*  3884 */       if ((!this.connection.isUsable()) || (this.bsendBatchInProgress))
/*       */       {
/*  3886 */         clearBatch();
/*  3887 */         this.bsendBatchInProgress = false;
/*  3888 */         return 0;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       try
/*       */       {
/*  3900 */         ensureOpen();
/*       */         
/*       */ 
/*       */ 
/*  3904 */         if (this.currentRank <= 0) {
/*  3905 */           i = this.connection.accumulateBatchResult ? 0 : this.validRows;
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3956 */           this.currentRank = 0;
/*  3957 */           this.bsendBatchInProgress = false;return i;
/*       */         }
/*  3913 */         int i = this.batch;
/*  3914 */         this.bsendBatchInProgress = true;
/*       */         
/*       */         try
/*       */         {
/*  3918 */           j = this.currentRank;
/*       */           
/*  3920 */           if (this.batch != this.currentRank) {
/*  3921 */             this.batch = this.currentRank;
/*       */           }
/*  3923 */           setupBindBuffers(0, this.currentRank);
/*       */           
/*  3925 */           this.currentRank -= 1;
/*       */           
/*  3927 */           doExecuteWithTimeout();
/*       */           
/*       */ 
/*       */ 
/*  3931 */           slideDownCurrentRow(j);
/*       */ 
/*       */         }
/*       */         finally
/*       */         {
/*  3936 */           if (this.batch != i) {
/*  3937 */             this.batch = i;
/*       */           }
/*       */         }
/*       */         
/*       */ 
/*  3942 */         if (this.connection.accumulateBatchResult)
/*       */         {
/*       */ 
/*  3945 */           this.validRows += this.prematureBatchCount;
/*  3946 */           this.prematureBatchCount = 0;
/*       */         }
/*       */         
/*  3949 */         int j = this.validRows;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3956 */         this.currentRank = 0;
/*  3957 */         this.bsendBatchInProgress = false;return j;
/*       */       }
/*       */       finally
/*       */       {
/*  3956 */         this.currentRank = 0;
/*  3957 */         this.bsendBatchInProgress = false;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setExecuteBatch(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  3998 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4001 */       setOracleBatchStyle();
/*  4002 */       set_execute_batch(paramInt);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void set_execute_batch(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4013 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4016 */       if (paramInt <= 0)
/*       */       {
/*  4018 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
/*  4019 */         localSQLException.fillInStackTrace();
/*  4020 */         throw localSQLException;
/*       */       }
/*       */       
/*  4023 */       if (paramInt == this.batch) {
/*  4024 */         return;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  4030 */       if (this.currentRank > 0)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*  4035 */         i = this.validRows;
/*       */         
/*  4037 */         this.prematureBatchCount = sendBatch();
/*  4038 */         this.validRows = i;
/*       */       }
/*       */       
/*  4041 */       int i = this.batch;
/*       */       
/*  4043 */       this.batch = paramInt;
/*       */       
/*  4045 */       if (this.numberOfBindRowsAllocated < this.batch) {
/*  4046 */         growBinds(this.batch);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public final int getExecuteBatch()
/*       */   {
/*  4060 */     return this.batch;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  4092 */     synchronized (this.connection)
/*       */     {
/*       */       SQLException localSQLException;
/*  4095 */       if (paramInt3 < 0)
/*       */       {
/*  4097 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  4098 */         localSQLException.fillInStackTrace();
/*  4099 */         throw localSQLException;
/*       */       }
/*       */       
/*  4102 */       if (paramInt1 < 1)
/*       */       {
/*  4104 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4105 */         localSQLException.fillInStackTrace();
/*  4106 */         throw localSQLException;
/*       */       }
/*       */       
/*  4109 */       switch (paramInt2)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       case -7: 
/*       */       case -6: 
/*       */       case -5: 
/*       */       case 2: 
/*       */       case 3: 
/*       */       case 4: 
/*       */       case 5: 
/*       */       case 6: 
/*       */       case 7: 
/*       */       case 8: 
/*  4134 */         paramInt2 = 6;
/*       */         
/*  4136 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 1: 
/*  4141 */         paramInt2 = 96;
/*       */         
/*  4143 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 12: 
/*  4148 */         paramInt2 = 1;
/*       */         
/*  4150 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       case 91: 
/*       */       case 92: 
/*  4157 */         paramInt2 = 12;
/*       */         
/*  4159 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -103: 
/*  4164 */         paramInt2 = 182;
/*       */         
/*  4166 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -104: 
/*  4171 */         paramInt2 = 183;
/*       */         
/*  4173 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       case -100: 
/*       */       case 93: 
/*  4180 */         paramInt2 = 180;
/*       */         
/*  4182 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -101: 
/*  4187 */         paramInt2 = 181;
/*       */         
/*  4189 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -102: 
/*  4194 */         paramInt2 = 231;
/*       */         
/*  4196 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       case -3: 
/*       */       case -2: 
/*  4203 */         paramInt2 = 23;
/*       */         
/*  4205 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 100: 
/*  4210 */         paramInt2 = 100;
/*       */         
/*  4212 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 101: 
/*  4217 */         paramInt2 = 101;
/*       */         
/*  4219 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -8: 
/*  4224 */         paramInt2 = 104;
/*       */         
/*  4226 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 2004: 
/*  4231 */         paramInt2 = 113;
/*       */         
/*  4233 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 2005: 
/*  4238 */         paramInt2 = 112;
/*       */         
/*  4240 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -13: 
/*  4245 */         paramInt2 = 114;
/*       */         
/*  4247 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -10: 
/*  4252 */         paramInt2 = 102;
/*       */         
/*  4254 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 0: 
/*  4259 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  4260 */         localSQLException.fillInStackTrace();
/*  4261 */         throw localSQLException;
/*       */       
/*       */ 
/*       */ 
/*       */       default: 
/*  4266 */         localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4267 */         localSQLException.fillInStackTrace();
/*  4268 */         throw localSQLException;
/*       */       }
/*       */       
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  4306 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  4311 */       int i = this.connection.getNlsRatio();
/*       */       
/*  4313 */       if ((paramInt2 == 1) || (paramInt2 == 12)) {
/*  4314 */         defineParameterTypeBytes(paramInt1, paramInt2, paramInt3 * i);
/*       */       } else {
/*  4316 */         defineParameterTypeBytes(paramInt1, paramInt2, paramInt3);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  4330 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*  4334 */       defineParameterTypeBytes(paramInt1, paramInt2, paramInt3);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public ResultSetMetaData getMetaData()
/*       */     throws SQLException
/*       */   {
/*  4351 */     if (this.sqlObject.getSqlKind().isSELECT()) {
/*  4352 */       return new OracleResultSetMetaData(this.connection, this);
/*       */     }
/*  4354 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNull(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/*  4393 */     setNullInternal(paramInt1, paramInt2, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNullInternal(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/*  4401 */     int i = paramInt1 - 1;
/*       */     
/*  4403 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  4405 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4406 */       localSQLException.fillInStackTrace();
/*  4407 */       throw localSQLException;
/*       */     }
/*       */     
/*  4410 */     if ((paramInt2 == 2002) || (paramInt2 == 2008) || (paramInt2 == 2003) || (paramInt2 == 2007) || (paramInt2 == 2006))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  4419 */       synchronized (this.connection) {
/*  4420 */         setNullCritical(i, paramInt2, paramString);
/*       */         
/*  4422 */         this.currentRowCharLens[i] = 0;
/*       */       }
/*       */       
/*       */     }
/*       */     else
/*       */     {
/*  4428 */       setNullInternal(paramInt1, paramInt2);
/*       */       
/*  4430 */       return;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setNullInternal(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4438 */     synchronized (this.connection)
/*       */     {
/*  4440 */       setNullCritical(paramInt1, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNullCritical(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/*  4449 */     Object localObject1 = null;
/*  4450 */     Binder localBinder = this.theNamedTypeNullBinder;
/*       */     Object localObject2;
/*  4452 */     switch (paramInt2)
/*       */     {
/*       */ 
/*       */     case 2006: 
/*  4456 */       localBinder = this.theRefTypeNullBinder;
/*       */     
/*       */ 
/*       */ 
/*       */     case 2002: 
/*       */     case 2008: 
/*  4462 */       localObject2 = StructDescriptor.createDescriptor(paramString, this.connection);
/*       */       
/*       */ 
/*  4465 */       localObject1 = ((StructDescriptor)localObject2).getOracleTypeADT();
/*       */       
/*  4467 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */     case 2003: 
/*  4472 */       localObject2 = ArrayDescriptor.createDescriptor(paramString, this.connection);
/*       */       
/*       */ 
/*  4475 */       localObject1 = ((ArrayDescriptor)localObject2).getOracleTypeCOLLECTION();
/*       */       
/*  4477 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2007: 
/*  4485 */       localObject2 = OpaqueDescriptor.createDescriptor(paramString, this.connection);
/*       */       
/*       */ 
/*  4488 */       localObject1 = (OracleTypeADT)((OpaqueDescriptor)localObject2).getPickler();
/*       */       
/*  4490 */       break;
/*       */     }
/*       */     
/*       */     
/*  4494 */     this.currentRowBinders[paramInt1] = localBinder;
/*       */     
/*  4496 */     if (this.parameterDatum == null) {
/*  4497 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  4502 */     this.parameterDatum[this.currentRank][paramInt1] = null;
/*       */     
/*  4504 */     if (localObject1 != null) {
/*  4505 */       ((OracleTypeADT)localObject1).getTOID();
/*       */     }
/*  4507 */     if (this.parameterOtype == null) {
/*  4508 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*  4511 */     this.parameterOtype[this.currentRank][paramInt1] = localObject1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNullAtName(String paramString1, int paramInt, String paramString2)
/*       */     throws SQLException
/*       */   {
/*  4530 */     String str = paramString1.intern();
/*  4531 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  4532 */     int i = 0;
/*  4533 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  4535 */     for (int k = 0; k < j; k++) {
/*  4536 */       if (arrayOfString[k] == str)
/*       */       {
/*  4538 */         setNullInternal(k + 1, paramInt, paramString2);
/*       */         
/*  4540 */         i = 1;
/*       */       }
/*       */     }
/*  4543 */     if (i == 0)
/*       */     {
/*  4545 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/*  4546 */       localSQLException.fillInStackTrace();
/*  4547 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNull(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4566 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4569 */       setNullCritical(paramInt1, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setNullCritical(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4577 */     int i = paramInt1 - 1;
/*       */     
/*  4579 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  4581 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4582 */       ((SQLException)localObject).fillInStackTrace();
/*  4583 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  4586 */     Object localObject = null;
/*  4587 */     int j = getInternalType(paramInt2);
/*       */     SQLException localSQLException;
/*  4589 */     switch (j)
/*       */     {
/*       */ 
/*       */     case 6: 
/*  4593 */       localObject = this.theVarnumNullBinder;
/*       */       
/*  4595 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 1: 
/*       */     case 8: 
/*       */     case 96: 
/*       */     case 995: 
/*  4604 */       localObject = this.theVarcharNullBinder;
/*  4605 */       this.currentRowCharLens[i] = 1;
/*       */       
/*  4607 */       break;
/*       */     
/*       */     case 999: 
/*  4610 */       localObject = this.theFixedCHARNullBinder;
/*       */       
/*  4612 */       break;
/*       */     
/*       */     case 12: 
/*  4615 */       localObject = this.theDateNullBinder;
/*       */       
/*  4617 */       break;
/*       */     
/*       */ 
/*       */     case 180: 
/*  4621 */       localObject = this.theTimestampNullBinder;
/*       */       
/*  4623 */       break;
/*       */     
/*       */     case 181: 
/*  4626 */       localObject = this.theTSTZNullBinder;
/*       */       
/*  4628 */       break;
/*       */     
/*       */     case 231: 
/*  4631 */       localObject = this.theTSLTZNullBinder;
/*       */       
/*  4633 */       break;
/*       */     
/*       */     case 104: 
/*  4636 */       localObject = getRowidNullBinder(i);
/*       */       
/*  4638 */       break;
/*       */     
/*       */     case 183: 
/*  4641 */       localObject = this.theIntervalDSNullBinder;
/*       */       
/*  4643 */       break;
/*       */     
/*       */     case 182: 
/*  4646 */       localObject = this.theIntervalYMNullBinder;
/*       */       
/*  4648 */       break;
/*       */     
/*       */ 
/*       */     case 23: 
/*       */     case 24: 
/*  4653 */       localObject = this.theRawNullBinder;
/*       */       
/*  4655 */       break;
/*       */     
/*       */     case 100: 
/*  4658 */       localObject = this.theBinaryFloatNullBinder;
/*       */       
/*  4660 */       break;
/*       */     
/*       */     case 101: 
/*  4663 */       localObject = this.theBinaryDoubleNullBinder;
/*       */       
/*  4665 */       break;
/*       */     
/*       */     case 113: 
/*  4668 */       localObject = this.theBlobNullBinder;
/*       */       
/*  4670 */       break;
/*       */     
/*       */     case 112: 
/*  4673 */       localObject = this.theClobNullBinder;
/*       */       
/*  4675 */       break;
/*       */     
/*       */     case 114: 
/*  4678 */       localObject = this.theBfileNullBinder;
/*       */       
/*  4680 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */     case 109: 
/*       */     case 111: 
/*  4686 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "sqlType=" + paramInt2);
/*  4687 */       localSQLException.fillInStackTrace();
/*  4688 */       throw localSQLException;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 102: 
/*       */     case 998: 
/*       */     default: 
/*  4699 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "sqlType=" + paramInt2);
/*  4700 */       localSQLException.fillInStackTrace();
/*  4701 */       throw localSQLException;
/*       */     }
/*       */     
/*       */     
/*  4705 */     this.currentRowBinders[i] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   Binder getRowidNullBinder(int paramInt)
/*       */   {
/*  4712 */     return this.theRowidNullBinder;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNullAtName(String paramString, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4728 */     String str = paramString.intern();
/*  4729 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  4730 */     int i = 0;
/*  4731 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  4733 */     for (int k = 0; k < j; k++) {
/*  4734 */       if (arrayOfString[k] == str)
/*       */       {
/*  4736 */         setNull(k + 1, paramInt);
/*       */         
/*  4738 */         i = 1;
/*       */       }
/*       */     }
/*  4741 */     if (i == 0)
/*       */     {
/*  4743 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  4744 */       localSQLException.fillInStackTrace();
/*  4745 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBoolean(int paramInt, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4761 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4764 */       setBooleanInternal(paramInt, paramBoolean);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBooleanInternal(int paramInt, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4772 */     int i = paramInt - 1;
/*       */     
/*  4774 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4776 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4777 */       localSQLException.fillInStackTrace();
/*  4778 */       throw localSQLException;
/*       */     }
/*       */     
/*  4781 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4783 */     this.currentRowBinders[i] = this.theBooleanBinder;
/*       */     
/*  4785 */     if (this.parameterInt == null) {
/*  4786 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4790 */     this.parameterInt[this.currentRank][i] = (paramBoolean ? 1 : 0);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setByte(int paramInt, byte paramByte)
/*       */     throws SQLException
/*       */   {
/*  4803 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4806 */       setByteInternal(paramInt, paramByte);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setByteInternal(int paramInt, byte paramByte)
/*       */     throws SQLException
/*       */   {
/*  4814 */     int i = paramInt - 1;
/*       */     
/*  4816 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4818 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4819 */       localSQLException.fillInStackTrace();
/*  4820 */       throw localSQLException;
/*       */     }
/*       */     
/*  4823 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4825 */     this.currentRowBinders[i] = this.theByteBinder;
/*       */     
/*  4827 */     if (this.parameterInt == null) {
/*  4828 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4832 */     this.parameterInt[this.currentRank][i] = paramByte;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setShort(int paramInt, short paramShort)
/*       */     throws SQLException
/*       */   {
/*  4846 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4849 */       setShortInternal(paramInt, paramShort);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setShortInternal(int paramInt, short paramShort)
/*       */     throws SQLException
/*       */   {
/*  4857 */     int i = paramInt - 1;
/*       */     
/*  4859 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4861 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4862 */       localSQLException.fillInStackTrace();
/*  4863 */       throw localSQLException;
/*       */     }
/*       */     
/*  4866 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4868 */     this.currentRowBinders[i] = this.theShortBinder;
/*       */     
/*  4870 */     if (this.parameterInt == null) {
/*  4871 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4875 */     this.parameterInt[this.currentRank][i] = paramShort;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setInt(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4889 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4892 */       setIntInternal(paramInt1, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setIntInternal(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4900 */     int i = paramInt1 - 1;
/*       */     
/*  4902 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  4904 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4905 */       localSQLException.fillInStackTrace();
/*  4906 */       throw localSQLException;
/*       */     }
/*       */     
/*  4909 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4911 */     this.currentRowBinders[i] = this.theIntBinder;
/*       */     
/*  4913 */     if (this.parameterInt == null) {
/*  4914 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4918 */     this.parameterInt[this.currentRank][i] = paramInt2;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setLong(int paramInt, long paramLong)
/*       */     throws SQLException
/*       */   {
/*  4931 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4934 */       setLongInternal(paramInt, paramLong);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setLongInternal(int paramInt, long paramLong)
/*       */     throws SQLException
/*       */   {
/*  4942 */     int i = paramInt - 1;
/*       */     
/*  4944 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4946 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4947 */       localSQLException.fillInStackTrace();
/*  4948 */       throw localSQLException;
/*       */     }
/*       */     
/*  4951 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4953 */     this.currentRowBinders[i] = this.theLongBinder;
/*       */     
/*  4955 */     if (this.parameterLong == null) {
/*  4956 */       this.parameterLong = new long[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  4961 */     this.parameterLong[this.currentRank][i] = paramLong;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFloat(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  4975 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4978 */       setFloatInternal(paramInt, paramFloat);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setFloatInternal(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  4986 */     int i = paramInt - 1;
/*       */     
/*  4988 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4990 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4991 */       localSQLException.fillInStackTrace();
/*  4992 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  5000 */     if (!this.connection.setFloatAndDoubleUseBinary)
/*       */     {
/*  5002 */       if (Float.isNaN(paramFloat)) {
/*  5003 */         throw new IllegalArgumentException("NaN");
/*       */       }
/*       */     }
/*       */     
/*  5007 */     if (this.theFloatBinder == null) {
/*  5008 */       this.theFloatBinder = theStaticFloatBinder;
/*  5009 */       if (this.connection.setFloatAndDoubleUseBinary) {
/*  5010 */         this.theFloatBinder = theStaticBinaryFloatBinder;
/*       */       }
/*       */     }
/*  5013 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  5015 */     this.currentRowBinders[i] = this.theFloatBinder;
/*       */     
/*  5017 */     if (this.theFloatBinder == theStaticFloatBinder)
/*       */     {
/*  5019 */       if (this.parameterDouble == null) {
/*  5020 */         this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5025 */       this.parameterDouble[this.currentRank][i] = paramFloat;
/*       */     }
/*       */     else
/*       */     {
/*  5029 */       if (this.parameterFloat == null) {
/*  5030 */         this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5035 */       this.parameterFloat[this.currentRank][i] = paramFloat;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryFloat(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  5051 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5054 */       setBinaryFloatInternal(paramInt, paramFloat);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBinaryFloatInternal(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  5062 */     int i = paramInt - 1;
/*       */     
/*  5064 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5066 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5067 */       localSQLException.fillInStackTrace();
/*  5068 */       throw localSQLException;
/*       */     }
/*       */     
/*  5071 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  5073 */     this.currentRowBinders[i] = this.theBinaryFloatBinder;
/*       */     
/*  5075 */     if (this.parameterFloat == null) {
/*  5076 */       this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5081 */     this.parameterFloat[this.currentRank][i] = paramFloat;
/*       */   }
/*       */   
/*       */ 
/*       */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT)
/*       */     throws SQLException
/*       */   {
/*  5088 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5091 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryFloatInternal(int paramInt, BINARY_FLOAT paramBINARY_FLOAT)
/*       */     throws SQLException
/*       */   {
/*  5100 */     int i = paramInt - 1;
/*       */     
/*  5102 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5104 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5105 */       localSQLException.fillInStackTrace();
/*  5106 */       throw localSQLException;
/*       */     }
/*       */     
/*  5109 */     if (paramBINARY_FLOAT == null)
/*       */     {
/*  5111 */       this.currentRowBinders[i] = this.theBINARY_FLOATNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  5115 */       this.currentRowBinders[i] = this.theBINARY_FLOATBinder;
/*       */       
/*  5117 */       if (this.parameterDatum == null)
/*       */       {
/*  5119 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5124 */       this.parameterDatum[this.currentRank][i] = paramBINARY_FLOAT.getBytes();
/*       */     }
/*       */     
/*  5127 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDouble(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5142 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5145 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBinaryDoubleInternal(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5153 */     int i = paramInt - 1;
/*       */     
/*  5155 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5157 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5158 */       localSQLException.fillInStackTrace();
/*  5159 */       throw localSQLException;
/*       */     }
/*       */     
/*  5162 */     this.currentRowBinders[i] = this.theBinaryDoubleBinder;
/*       */     
/*  5164 */     if (this.parameterDouble == null) {
/*  5165 */       this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*  5168 */     this.currentRowCharLens[i] = 0;
/*       */     
/*       */ 
/*       */ 
/*  5172 */     this.parameterDouble[this.currentRank][i] = paramDouble;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE)
/*       */     throws SQLException
/*       */   {
/*  5188 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5191 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryDoubleInternal(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE)
/*       */     throws SQLException
/*       */   {
/*  5200 */     int i = paramInt - 1;
/*       */     
/*  5202 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5204 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5205 */       localSQLException.fillInStackTrace();
/*  5206 */       throw localSQLException;
/*       */     }
/*       */     
/*  5209 */     if (paramBINARY_DOUBLE == null)
/*       */     {
/*  5211 */       this.currentRowBinders[i] = this.theBINARY_DOUBLENullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  5215 */       this.currentRowBinders[i] = this.theBINARY_DOUBLEBinder;
/*       */       
/*  5217 */       if (this.parameterDatum == null)
/*       */       {
/*  5219 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5224 */       this.parameterDatum[this.currentRank][i] = paramBINARY_DOUBLE.getBytes();
/*       */     }
/*       */     
/*  5227 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDouble(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5241 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5244 */       setDoubleInternal(paramInt, paramDouble);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setDoubleInternal(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5252 */     int i = paramInt - 1;
/*       */     
/*  5254 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5256 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5257 */       localSQLException.fillInStackTrace();
/*  5258 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  5266 */     if (!this.connection.setFloatAndDoubleUseBinary) {
/*  5267 */       if (Double.isNaN(paramDouble)) {
/*  5268 */         throw new IllegalArgumentException("NaN");
/*       */       }
/*       */       
/*  5271 */       double d = Math.abs(paramDouble);
/*  5272 */       if ((d != 0.0D) && (d < 1.0E-130D)) {
/*  5273 */         throw new IllegalArgumentException("Underflow");
/*       */       }
/*  5275 */       if (d >= 1.0E126D) {
/*  5276 */         throw new IllegalArgumentException("Overflow");
/*       */       }
/*       */     }
/*       */     
/*  5280 */     if (this.theDoubleBinder == null) {
/*  5281 */       this.theDoubleBinder = theStaticDoubleBinder;
/*  5282 */       if (this.connection.setFloatAndDoubleUseBinary) {
/*  5283 */         this.theDoubleBinder = theStaticBinaryDoubleBinder;
/*       */       }
/*       */     }
/*  5286 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  5288 */     this.currentRowBinders[i] = this.theDoubleBinder;
/*       */     
/*  5290 */     if (this.parameterDouble == null) {
/*  5291 */       this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5296 */     this.parameterDouble[this.currentRank][i] = paramDouble;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*       */     throws SQLException
/*       */   {
/*  5310 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5313 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBigDecimalInternal(int paramInt, BigDecimal paramBigDecimal)
/*       */     throws SQLException
/*       */   {
/*  5321 */     int i = paramInt - 1;
/*       */     
/*  5323 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5325 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5326 */       localSQLException.fillInStackTrace();
/*  5327 */       throw localSQLException;
/*       */     }
/*       */     
/*  5330 */     if (paramBigDecimal == null) {
/*  5331 */       this.currentRowBinders[i] = this.theVarnumNullBinder;
/*       */     }
/*       */     else {
/*  5334 */       this.currentRowBinders[i] = this.theBigDecimalBinder;
/*       */       
/*  5336 */       if (this.parameterBigDecimal == null) {
/*  5337 */         this.parameterBigDecimal = new BigDecimal[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5342 */       this.parameterBigDecimal[this.currentRank][i] = paramBigDecimal;
/*       */     }
/*       */     
/*  5345 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*  5350 */   int SetBigStringTryClob = 0;
/*       */   
/*       */ 
/*       */   static final int BSTYLE_UNKNOWN = 0;
/*       */   
/*       */ 
/*       */   static final int BSTYLE_ORACLE = 1;
/*       */   
/*       */ 
/*       */   static final int BSTYLE_JDBC = 2;
/*       */   
/*       */ 
/*       */   public void setString(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5365 */     setStringInternal(paramInt, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setStringInternal(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5373 */     int i = paramInt - 1;
/*  5374 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5376 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5377 */       localSQLException.fillInStackTrace();
/*  5378 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  5382 */     int j = paramString != null ? paramString.length() : 0;
/*       */     
/*  5384 */     if (j == 0) {
/*  5385 */       setNull(paramInt, 12);
/*       */     } else {
/*       */       int k;
/*  5388 */       if (this.currentRowFormOfUse[(paramInt - 1)] == 1) {
/*  5389 */         if (this.sqlKind.isPlsqlOrCall()) {
/*  5390 */           if ((j > this.maxVcsBytesPlsql) || ((j > this.maxVcsCharsPlsql) && (this.isServerCharSetFixedWidth)))
/*       */           {
/*       */ 
/*  5393 */             setStringForClobCritical(paramInt, paramString);
/*       */           }
/*  5395 */           else if (j > this.maxVcsCharsPlsql)
/*       */           {
/*  5397 */             k = this.connection.conversion.encodedByteLength(paramString, false);
/*       */             
/*  5399 */             if (k > this.maxVcsBytesPlsql) {
/*  5400 */               setStringForClobCritical(paramInt, paramString);
/*       */             }
/*       */             else {
/*  5403 */               basicBindString(paramInt, paramString);
/*       */             }
/*       */           }
/*       */           else {
/*  5407 */             basicBindString(paramInt, paramString);
/*       */           }
/*       */           
/*       */         }
/*  5411 */         else if (j <= this.maxVcsCharsSql) {
/*  5412 */           basicBindString(paramInt, paramString);
/*       */         }
/*  5414 */         else if (j <= this.maxStreamCharsSql)
/*       */         {
/*  5416 */           basicBindCharacterStream(paramInt, new StringReader(paramString), j, true);
/*       */         }
/*       */         else
/*       */         {
/*  5420 */           setStringForClobCritical(paramInt, paramString);
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  5425 */       else if (this.sqlKind.isPlsqlOrCall()) {
/*  5426 */         if ((j > this.maxVcsBytesPlsql) || ((j > this.maxVcsNCharsPlsql) && (this.isServerNCharSetFixedWidth)))
/*       */         {
/*       */ 
/*  5429 */           setStringForClobCritical(paramInt, paramString);
/*       */         }
/*  5431 */         else if (j > this.maxVcsNCharsPlsql)
/*       */         {
/*  5433 */           k = this.connection.conversion.encodedByteLength(paramString, true);
/*       */           
/*  5435 */           if (k > this.maxVcsBytesPlsql) {
/*  5436 */             setStringForClobCritical(paramInt, paramString);
/*       */           }
/*       */           else {
/*  5439 */             basicBindString(paramInt, paramString);
/*       */           }
/*       */         }
/*       */         else {
/*  5443 */           basicBindString(paramInt, paramString);
/*       */         }
/*       */         
/*       */       }
/*  5447 */       else if (j <= this.maxVcsCharsSql) {
/*  5448 */         basicBindString(paramInt, paramString);
/*       */       }
/*       */       else {
/*  5451 */         setStringForClobCritical(paramInt, paramString);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void basicBindNullString(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  5461 */     synchronized (this.connection)
/*       */     {
/*  5463 */       int i = paramInt - 1;
/*  5464 */       this.currentRowBinders[i] = this.theVarcharNullBinder;
/*       */       
/*  5466 */       if (this.sqlKind.isPlsqlOrCall()) {
/*  5467 */         this.currentRowCharLens[i] = this.minVcsBindSize;
/*       */       } else {
/*  5469 */         this.currentRowCharLens[i] = 1;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */   void basicBindString(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5477 */     synchronized (this.connection)
/*       */     {
/*  5479 */       int i = paramInt - 1;
/*  5480 */       this.currentRowBinders[i] = this.theStringBinder;
/*  5481 */       int j = paramString.length();
/*       */       
/*  5483 */       if (this.sqlKind.isPlsqlOrCall())
/*       */       {
/*  5485 */         int k = this.connection.minVcsBindSize;
/*  5486 */         int m = j + 1;
/*       */         
/*  5488 */         this.currentRowCharLens[i] = (m < k ? k : m);
/*       */       }
/*       */       else {
/*  5491 */         this.currentRowCharLens[i] = (j + 1);
/*       */       }
/*  5493 */       if (this.parameterString == null) {
/*  5494 */         this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  5497 */       this.parameterString[this.currentRank][i] = paramString;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStringForClob(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5516 */     if (paramString == null)
/*       */     {
/*  5518 */       setNull(paramInt, 1);
/*  5519 */       return;
/*       */     }
/*  5521 */     int i = paramString.length();
/*  5522 */     if (i == 0)
/*       */     {
/*  5524 */       setNull(paramInt, 1);
/*  5525 */       return;
/*       */     }
/*       */     
/*  5528 */     if (this.sqlKind.isPlsqlOrCall())
/*       */     {
/*  5530 */       if (i <= this.maxVcsCharsPlsql)
/*       */       {
/*  5532 */         setStringInternal(paramInt, paramString);
/*       */       }
/*       */       else
/*       */       {
/*  5536 */         setStringForClobCritical(paramInt, paramString);
/*       */       }
/*       */       
/*       */ 
/*       */     }
/*  5541 */     else if (i <= this.maxVcsCharsSql)
/*       */     {
/*  5543 */       setStringInternal(paramInt, paramString);
/*       */     }
/*       */     else
/*       */     {
/*  5547 */       setStringForClobCritical(paramInt, paramString);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setStringForClobCritical(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5556 */     synchronized (this.connection) {
/*  5557 */       CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[(paramInt - 1)]);
/*       */       
/*       */ 
/*  5560 */       localCLOB.setString(1L, paramString);
/*  5561 */       addToTempLobsToFree(localCLOB);
/*  5562 */       this.lastBoundClobs[(paramInt - 1)] = localCLOB;
/*  5563 */       setCLOBInternal(paramInt, localCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setReaderContentsForClobCritical(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  5573 */     synchronized (this.connection)
/*       */     {
/*       */       try
/*       */       {
/*  5577 */         if ((paramReader = isReaderEmpty(paramReader)) == null)
/*       */         {
/*  5579 */           if (paramBoolean)
/*       */           {
/*  5581 */             throw new IOException(paramLong + " char of CLOB data cannot be read");
/*       */           }
/*  5583 */           setCLOBInternal(paramInt, null);
/*  5584 */           return;
/*       */         }
/*       */         
/*       */       }
/*       */       catch (IOException localIOException1)
/*       */       {
/*  5590 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/*  5591 */         ((SQLException)localObject1).fillInStackTrace();
/*  5592 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*  5596 */       CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[(paramInt - 1)]);
/*       */       
/*       */ 
/*  5599 */       Object localObject1 = (OracleClobWriter)localCLOB.setCharacterStream(1L);
/*  5600 */       int i = localCLOB.getBufferSize();
/*  5601 */       char[] arrayOfChar = new char[i];
/*  5602 */       long l = 0L;
/*  5603 */       int j = 0;
/*       */       
/*       */ 
/*  5606 */       l = paramBoolean ? paramLong : Long.MAX_VALUE;
/*       */       
/*       */       try
/*       */       {
/*  5610 */         while (l > 0L)
/*       */         {
/*  5612 */           if (l >= i) {
/*  5613 */             j = paramReader.read(arrayOfChar);
/*       */           } else {
/*  5615 */             j = paramReader.read(arrayOfChar, 0, (int)l);
/*       */           }
/*  5617 */           if (j == -1)
/*       */           {
/*  5619 */             if (!paramBoolean)
/*       */               break;
/*  5621 */             throw new IOException(l + " char of CLOB data cannot be read");
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  5627 */           ((OracleClobWriter)localObject1).write(arrayOfChar, 0, j);
/*       */           
/*  5629 */           l -= j;
/*       */         }
/*  5631 */         ((OracleClobWriter)localObject1).flush();
/*       */ 
/*       */       }
/*       */       catch (IOException localIOException2)
/*       */       {
/*  5636 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/*  5637 */         localSQLException.fillInStackTrace();
/*  5638 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*  5642 */       addToTempLobsToFree(localCLOB);
/*  5643 */       this.lastBoundClobs[(paramInt - 1)] = localCLOB;
/*  5644 */       setCLOBInternal(paramInt, localCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setAsciiStreamContentsForClobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  5654 */     synchronized (this.connection)
/*       */     {
/*       */       try
/*       */       {
/*  5658 */         if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null)
/*       */         {
/*  5660 */           if (paramBoolean)
/*       */           {
/*  5662 */             throw new IOException(paramLong + " byte of CLOB data cannot be read");
/*       */           }
/*  5664 */           setCLOBInternal(paramInt, null);
/*  5665 */           return;
/*       */         }
/*       */         
/*       */       }
/*       */       catch (IOException localIOException1)
/*       */       {
/*  5671 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/*  5672 */         ((SQLException)localObject1).fillInStackTrace();
/*  5673 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*  5676 */       CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[(paramInt - 1)]);
/*       */       
/*       */ 
/*  5679 */       Object localObject1 = (OracleClobWriter)localCLOB.setCharacterStream(1L);
/*  5680 */       int i = localCLOB.getBufferSize();
/*  5681 */       byte[] arrayOfByte = new byte[i];
/*  5682 */       char[] arrayOfChar = new char[i];
/*  5683 */       int j = 0;
/*       */       
/*  5685 */       long l = paramBoolean ? paramLong : Long.MAX_VALUE;
/*       */       
/*       */       try
/*       */       {
/*  5689 */         while (l > 0L)
/*       */         {
/*  5691 */           if (l >= i) {
/*  5692 */             j = paramInputStream.read(arrayOfByte);
/*       */           } else {
/*  5694 */             j = paramInputStream.read(arrayOfByte, 0, (int)l);
/*       */           }
/*  5696 */           if (j == -1)
/*       */           {
/*  5698 */             if (!paramBoolean)
/*       */               break;
/*  5700 */             throw new IOException(l + " byte of CLOB data cannot be read");
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  5707 */           DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*  5708 */           ((OracleClobWriter)localObject1).write(arrayOfChar, 0, j);
/*       */           
/*  5710 */           l -= j;
/*       */         }
/*  5712 */         ((OracleClobWriter)localObject1).flush();
/*       */ 
/*       */       }
/*       */       catch (IOException localIOException2)
/*       */       {
/*  5717 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/*  5718 */         localSQLException.fillInStackTrace();
/*  5719 */         throw localSQLException;
/*       */       }
/*       */       
/*  5722 */       addToTempLobsToFree(localCLOB);
/*  5723 */       this.lastBoundClobs[(paramInt - 1)] = localCLOB;
/*  5724 */       setCLOBInternal(paramInt, localCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStringForClobAtName(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/*  5742 */     String str = paramString1.intern();
/*  5743 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  5744 */     int i = 0;
/*  5745 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  5747 */     for (int k = 0; k < j; k++) {
/*  5748 */       if (arrayOfString[k] == str)
/*       */       {
/*  5750 */         setStringForClob(k + 1, paramString2);
/*       */         
/*  5752 */         i = 1;
/*       */       }
/*       */     }
/*  5755 */     if (i == 0)
/*       */     {
/*  5757 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/*  5758 */       localSQLException.fillInStackTrace();
/*  5759 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFixedCHAR(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5777 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5780 */       setFixedCHARInternal(paramInt, paramString);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setFixedCHARInternal(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5788 */     int i = paramInt - 1;
/*       */     
/*  5790 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5792 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5793 */       localSQLException1.fillInStackTrace();
/*  5794 */       throw localSQLException1;
/*       */     }
/*       */     
/*  5797 */     int j = 0;
/*       */     
/*  5799 */     if (paramString != null) {
/*  5800 */       j = paramString.length();
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5805 */     if (j > 32766)
/*       */     {
/*  5807 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 157);
/*  5808 */       localSQLException2.fillInStackTrace();
/*  5809 */       throw localSQLException2;
/*       */     }
/*       */     
/*  5812 */     if (paramString == null)
/*       */     {
/*  5814 */       this.currentRowBinders[i] = this.theFixedCHARNullBinder;
/*  5815 */       this.currentRowCharLens[i] = 1;
/*       */     }
/*       */     else
/*       */     {
/*  5819 */       this.currentRowBinders[i] = this.theFixedCHARBinder;
/*  5820 */       this.currentRowCharLens[i] = (j + 1);
/*       */       
/*  5822 */       if (this.parameterString == null) {
/*  5823 */         this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  5826 */       this.parameterString[this.currentRank][i] = paramString;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void setCursor(int paramInt, ResultSet paramResultSet)
/*       */     throws SQLException
/*       */   {
/*  5846 */     synchronized (this.connection)
/*       */     {
/*  5848 */       setCursorInternal(paramInt, paramResultSet);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setCursorInternal(int paramInt, ResultSet paramResultSet)
/*       */     throws SQLException
/*       */   {
/*  5857 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5858 */     localSQLException.fillInStackTrace();
/*  5859 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setROWID(int paramInt, ROWID paramROWID)
/*       */     throws SQLException
/*       */   {
/*  5877 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5880 */       setROWIDInternal(paramInt, paramROWID);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setROWIDInternal(int paramInt, ROWID paramROWID)
/*       */     throws SQLException
/*       */   {
/*  5888 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*       */     {
/*  5890 */       if (paramROWID == null)
/*       */       {
/*  5892 */         setNull(paramInt, 12);
/*       */       }
/*       */       else {
/*  5895 */         setStringInternal(paramInt, paramROWID.stringValue());
/*       */       }
/*       */       
/*  5898 */       return;
/*       */     }
/*       */     
/*  5901 */     int i = paramInt - 1;
/*       */     
/*  5903 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5905 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5906 */       localSQLException.fillInStackTrace();
/*  5907 */       throw localSQLException;
/*       */     }
/*       */     
/*  5910 */     if ((paramROWID == null) || (paramROWID.shareBytes() == null))
/*       */     {
/*  5912 */       this.currentRowBinders[i] = this.theRowidNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  5916 */       this.currentRowBinders[i] = (T4CRowidAccessor.isUROWID(paramROWID.shareBytes(), 0) ? this.theURowidBinder : this.theRowidBinder);
/*       */       
/*  5918 */       if (this.parameterDatum == null)
/*       */       {
/*  5920 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5925 */       this.parameterDatum[this.currentRank][i] = paramROWID.getBytes();
/*       */     }
/*       */     
/*  5928 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setArray(int paramInt, Array paramArray)
/*       */     throws SQLException
/*       */   {
/*  5947 */     setARRAYInternal(paramInt, (ARRAY)paramArray);
/*       */   }
/*       */   
/*       */ 
/*       */   void setArrayInternal(int paramInt, Array paramArray)
/*       */     throws SQLException
/*       */   {
/*  5954 */     setARRAYInternal(paramInt, (ARRAY)paramArray);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setARRAY(int paramInt, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/*  5972 */     setARRAYInternal(paramInt, paramARRAY);
/*       */   }
/*       */   
/*       */ 
/*       */   void setARRAYInternal(int paramInt, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/*  5979 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  5981 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5983 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5984 */       localSQLException.fillInStackTrace();
/*  5985 */       throw localSQLException;
/*       */     }
/*       */     
/*  5988 */     if (paramARRAY == null)
/*       */     {
/*       */ 
/*  5991 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5992 */       localSQLException.fillInStackTrace();
/*  5993 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5998 */     synchronized (this.connection) {
/*  5999 */       setArrayCritical(i, paramARRAY);
/*       */       
/*  6001 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setArrayCritical(int paramInt, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/*  6018 */     ArrayDescriptor localArrayDescriptor = paramARRAY.getDescriptor();
/*       */     
/*  6020 */     if (localArrayDescriptor == null)
/*       */     {
/*       */ 
/*       */ 
/*  6024 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
/*  6025 */       ((SQLException)localObject).fillInStackTrace();
/*  6026 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6031 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  6033 */     if (this.parameterDatum == null)
/*       */     {
/*  6035 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6040 */     this.parameterDatum[this.currentRank][paramInt] = paramARRAY.toBytes();
/*       */     
/*  6042 */     Object localObject = localArrayDescriptor.getOracleTypeCOLLECTION();
/*       */     
/*  6044 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  6046 */     if (this.parameterOtype == null)
/*       */     {
/*  6048 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  6052 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/*  6070 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*       */   }
/*       */   
/*       */ 
/*       */   void setOPAQUEInternal(int paramInt, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/*  6077 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  6079 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6081 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6082 */       localSQLException.fillInStackTrace();
/*  6083 */       throw localSQLException;
/*       */     }
/*       */     
/*  6086 */     if (paramOPAQUE == null)
/*       */     {
/*       */ 
/*  6089 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6090 */       localSQLException.fillInStackTrace();
/*  6091 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6096 */     synchronized (this.connection) {
/*  6097 */       setOPAQUECritical(i, paramOPAQUE);
/*       */       
/*  6099 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setOPAQUECritical(int paramInt, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/*  6116 */     OpaqueDescriptor localOpaqueDescriptor = paramOPAQUE.getDescriptor();
/*       */     
/*  6118 */     if (localOpaqueDescriptor == null)
/*       */     {
/*       */ 
/*       */ 
/*  6122 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
/*  6123 */       ((SQLException)localObject).fillInStackTrace();
/*  6124 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6129 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  6131 */     if (this.parameterDatum == null)
/*       */     {
/*  6133 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6138 */     this.parameterDatum[this.currentRank][paramInt] = paramOPAQUE.toBytes();
/*       */     
/*  6140 */     Object localObject = (OracleTypeADT)localOpaqueDescriptor.getPickler();
/*       */     
/*  6142 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  6144 */     if (this.parameterOtype == null)
/*       */     {
/*  6146 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  6150 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6172 */     setStructDescriptorInternal(paramInt, paramStructDescriptor);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setStructDescriptorInternal(int paramInt, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6180 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  6182 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6184 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6185 */       localSQLException.fillInStackTrace();
/*  6186 */       throw localSQLException;
/*       */     }
/*       */     
/*  6189 */     if (paramStructDescriptor == null)
/*       */     {
/*  6191 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6192 */       localSQLException.fillInStackTrace();
/*  6193 */       throw localSQLException;
/*       */     }
/*       */     
/*  6196 */     synchronized (this.connection) {
/*  6197 */       setStructDescriptorCritical(i, paramStructDescriptor);
/*       */       
/*  6199 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setStructDescriptorCritical(int paramInt, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6215 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  6217 */     if (this.parameterDatum == null) {
/*  6218 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*  6221 */     OracleTypeADT localOracleTypeADT = paramStructDescriptor.getOracleTypeADT();
/*       */     
/*  6223 */     localOracleTypeADT.getTOID();
/*       */     
/*  6225 */     if (this.parameterOtype == null) {
/*  6226 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  6230 */     this.parameterOtype[this.currentRank][paramInt] = localOracleTypeADT;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6249 */     String str = paramString.intern();
/*  6250 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  6251 */     int i = 0;
/*  6252 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  6254 */     for (int k = 0; k < j; k++) {
/*  6255 */       if (arrayOfString[k] == str)
/*       */       {
/*  6257 */         setStructDescriptorInternal(k + 1, paramStructDescriptor);
/*       */         
/*  6259 */         i = 1;
/*       */       }
/*       */     }
/*  6262 */     if (i == 0)
/*       */     {
/*  6264 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  6265 */       localSQLException.fillInStackTrace();
/*  6266 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setPreBindsCompelete()
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/*  6295 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*       */   }
/*       */   
/*       */ 
/*       */   void setSTRUCTInternal(int paramInt, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/*  6302 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  6304 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6306 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6307 */       localSQLException.fillInStackTrace();
/*  6308 */       throw localSQLException;
/*       */     }
/*       */     
/*  6311 */     if (paramSTRUCT == null)
/*       */     {
/*       */ 
/*  6314 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6315 */       localSQLException.fillInStackTrace();
/*  6316 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6321 */     synchronized (this.connection) {
/*  6322 */       setSTRUCTCritical(i, paramSTRUCT);
/*       */       
/*  6324 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setSTRUCTCritical(int paramInt, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/*  6342 */     StructDescriptor localStructDescriptor = paramSTRUCT.getDescriptor();
/*       */     
/*  6344 */     if (localStructDescriptor == null)
/*       */     {
/*       */ 
/*       */ 
/*  6348 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
/*  6349 */       ((SQLException)localObject).fillInStackTrace();
/*  6350 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6355 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  6357 */     if (this.parameterDatum == null)
/*       */     {
/*  6359 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6364 */     this.parameterDatum[this.currentRank][paramInt] = paramSTRUCT.toBytes();
/*       */     
/*       */ 
/*       */ 
/*  6368 */     Object localObject = localStructDescriptor.getOracleTypeADT();
/*       */     
/*  6370 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  6372 */     if (this.parameterOtype == null)
/*       */     {
/*  6374 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  6378 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRAW(int paramInt, RAW paramRAW)
/*       */     throws SQLException
/*       */   {
/*  6396 */     setRAWInternal(paramInt, paramRAW);
/*       */   }
/*       */   
/*       */ 
/*       */   void setRAWInternal(int paramInt, RAW paramRAW)
/*       */     throws SQLException
/*       */   {
/*  6403 */     int i = 0;
/*  6404 */     synchronized (this.connection) {
/*  6405 */       int j = paramInt - 1;
/*       */       
/*  6407 */       if ((j < 0) || (paramInt > this.numberOfBindPositions))
/*       */       {
/*  6409 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6410 */         localSQLException.fillInStackTrace();
/*  6411 */         throw localSQLException;
/*       */       }
/*       */       
/*  6414 */       this.currentRowCharLens[j] = 0;
/*       */       
/*  6416 */       if (paramRAW == null) {
/*  6417 */         this.currentRowBinders[j] = this.theRawNullBinder;
/*       */       } else
/*  6419 */         i = 1;
/*       */     }
/*  6421 */     if (i != 0) {
/*  6422 */       setBytesInternal(paramInt, paramRAW.getBytes());
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCHAR(int paramInt, CHAR paramCHAR)
/*       */     throws SQLException
/*       */   {
/*  6438 */     synchronized (this.connection)
/*       */     {
/*  6440 */       setCHARInternal(paramInt, paramCHAR);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setCHARInternal(int paramInt, CHAR paramCHAR)
/*       */     throws SQLException
/*       */   {
/*  6448 */     int i = paramInt - 1;
/*       */     
/*  6450 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6452 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6453 */       localSQLException.fillInStackTrace();
/*  6454 */       throw localSQLException;
/*       */     }
/*       */     
/*  6457 */     if ((paramCHAR == null) || (paramCHAR.getLength() == 0L))
/*       */     {
/*       */ 
/*  6460 */       this.currentRowBinders[i] = this.theSetCHARNullBinder;
/*  6461 */       this.currentRowCharLens[i] = 1;
/*       */     }
/*       */     else
/*       */     {
/*  6465 */       int j = (short)paramCHAR.oracleId();
/*  6466 */       this.currentRowBinders[i] = this.theSetCHARBinder;
/*       */       
/*  6468 */       if (this.parameterDatum == null)
/*       */       {
/*  6470 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*  6474 */       CharacterSet localCharacterSet = this.currentRowFormOfUse[i] == 2 ? this.connection.setCHARNCharSetObj : this.connection.setCHARCharSetObj;
/*       */       
/*       */ 
/*       */ 
/*       */       byte[] arrayOfByte1;
/*       */       
/*       */ 
/*  6481 */       if ((localCharacterSet != null) && (localCharacterSet.getOracleId() != j))
/*       */       {
/*  6483 */         byte[] arrayOfByte2 = paramCHAR.shareBytes();
/*       */         
/*  6485 */         arrayOfByte1 = localCharacterSet.convert(paramCHAR.getCharacterSet(), arrayOfByte2, 0, arrayOfByte2.length);
/*       */       }
/*       */       else {
/*  6488 */         arrayOfByte1 = paramCHAR.getBytes();
/*       */       }
/*  6490 */       this.parameterDatum[this.currentRank][i] = arrayOfByte1;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  6496 */       this.currentRowCharLens[i] = ((arrayOfByte1.length + 1 >> 1) + 1);
/*       */     }
/*       */     
/*       */ 
/*  6500 */     if (this.sqlKind.isPlsqlOrCall())
/*       */     {
/*       */ 
/*       */ 
/*  6504 */       if (this.currentRowCharLens[i] < this.minVcsBindSize) {
/*  6505 */         this.currentRowCharLens[i] = this.minVcsBindSize;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDATE(int paramInt, DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/*  6528 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6531 */       setDATEInternal(paramInt, paramDATE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setDATEInternal(int paramInt, DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/*  6539 */     int i = paramInt - 1;
/*       */     
/*  6541 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6543 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6544 */       localSQLException.fillInStackTrace();
/*  6545 */       throw localSQLException;
/*       */     }
/*       */     
/*  6548 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6550 */     if (paramDATE == null)
/*       */     {
/*  6552 */       this.currentRowBinders[i] = this.theDateNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  6556 */       this.currentRowBinders[i] = this.theOracleDateBinder;
/*       */       
/*  6558 */       if (this.parameterDatum == null)
/*       */       {
/*  6560 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6565 */       this.parameterDatum[this.currentRank][i] = paramDATE.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNUMBER(int paramInt, NUMBER paramNUMBER)
/*       */     throws SQLException
/*       */   {
/*  6582 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6585 */       setNUMBERInternal(paramInt, paramNUMBER);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setNUMBERInternal(int paramInt, NUMBER paramNUMBER)
/*       */     throws SQLException
/*       */   {
/*  6593 */     int i = paramInt - 1;
/*       */     
/*  6595 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6597 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6598 */       localSQLException.fillInStackTrace();
/*  6599 */       throw localSQLException;
/*       */     }
/*       */     
/*  6602 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6604 */     if (paramNUMBER == null)
/*       */     {
/*  6606 */       this.currentRowBinders[i] = this.theVarnumNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  6610 */       this.currentRowBinders[i] = this.theOracleNumberBinder;
/*       */       
/*  6612 */       if (this.parameterDatum == null)
/*       */       {
/*  6614 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6619 */       this.parameterDatum[this.currentRank][i] = paramNUMBER.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBLOB(int paramInt, BLOB paramBLOB)
/*       */     throws SQLException
/*       */   {
/*  6636 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6639 */       setBLOBInternal(paramInt, paramBLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBLOBInternal(int paramInt, BLOB paramBLOB)
/*       */     throws SQLException
/*       */   {
/*  6647 */     int i = paramInt - 1;
/*       */     
/*  6649 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6651 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6652 */       localSQLException.fillInStackTrace();
/*  6653 */       throw localSQLException;
/*       */     }
/*       */     
/*  6656 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6658 */     if (paramBLOB == null) {
/*  6659 */       this.currentRowBinders[i] = this.theBlobNullBinder;
/*       */     }
/*       */     else {
/*  6662 */       this.currentRowBinders[i] = this.theBlobBinder;
/*       */       
/*  6664 */       if (this.parameterDatum == null) {
/*  6665 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6670 */       this.parameterDatum[this.currentRank][i] = paramBLOB.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlob(int paramInt, Blob paramBlob)
/*       */     throws SQLException
/*       */   {
/*  6687 */     synchronized (this.connection)
/*       */     {
/*  6689 */       setBLOBInternal(paramInt, (BLOB)paramBlob);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBlobInternal(int paramInt, Blob paramBlob)
/*       */     throws SQLException
/*       */   {
/*  6697 */     setBLOBInternal(paramInt, (BLOB)paramBlob);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCLOB(int paramInt, CLOB paramCLOB)
/*       */     throws SQLException
/*       */   {
/*  6714 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6717 */       setCLOBInternal(paramInt, paramCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setCLOBInternal(int paramInt, CLOB paramCLOB)
/*       */     throws SQLException
/*       */   {
/*  6725 */     int i = paramInt - 1;
/*       */     
/*  6727 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6729 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6730 */       localSQLException.fillInStackTrace();
/*  6731 */       throw localSQLException;
/*       */     }
/*       */     
/*  6734 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6736 */     if (paramCLOB == null) {
/*  6737 */       this.currentRowBinders[i] = this.theClobNullBinder;
/*       */     }
/*       */     else {
/*  6740 */       this.currentRowBinders[i] = this.theClobBinder;
/*       */       
/*  6742 */       if (this.parameterDatum == null) {
/*  6743 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6748 */       this.parameterDatum[this.currentRank][i] = paramCLOB.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClob(int paramInt, Clob paramClob)
/*       */     throws SQLException
/*       */   {
/*  6765 */     synchronized (this.connection)
/*       */     {
/*  6767 */       setCLOBInternal(paramInt, (CLOB)paramClob);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setClobInternal(int paramInt, Clob paramClob)
/*       */     throws SQLException
/*       */   {
/*  6775 */     setCLOBInternal(paramInt, (CLOB)paramClob);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBFILE(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6791 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6794 */       setBFILEInternal(paramInt, paramBFILE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBFILEInternal(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6802 */     int i = paramInt - 1;
/*       */     
/*  6804 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6806 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6807 */       localSQLException.fillInStackTrace();
/*  6808 */       throw localSQLException;
/*       */     }
/*       */     
/*  6811 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6813 */     if (paramBFILE == null) {
/*  6814 */       this.currentRowBinders[i] = this.theBfileNullBinder;
/*       */     }
/*       */     else {
/*  6817 */       this.currentRowBinders[i] = this.theBfileBinder;
/*       */       
/*  6819 */       if (this.parameterDatum == null) {
/*  6820 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6825 */       this.parameterDatum[this.currentRank][i] = paramBFILE.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBfile(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6842 */     synchronized (this.connection)
/*       */     {
/*  6844 */       setBFILEInternal(paramInt, paramBFILE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBfileInternal(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6852 */     setBFILEInternal(paramInt, paramBFILE);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytes(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6868 */     setBytesInternal(paramInt, paramArrayOfByte);
/*       */   }
/*       */   
/*       */ 
/*       */   void setBytesInternal(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6875 */     int i = paramInt - 1;
/*       */     
/*  6877 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6879 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6880 */       localSQLException.fillInStackTrace();
/*  6881 */       throw localSQLException;
/*       */     }
/*  6883 */     int j = paramArrayOfByte != null ? paramArrayOfByte.length : 0;
/*  6884 */     if (j == 0)
/*       */     {
/*  6886 */       setNullInternal(paramInt, -2);
/*       */ 
/*       */ 
/*       */     }
/*  6890 */     else if (this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK)
/*       */     {
/*  6892 */       if (j > this.maxRawBytesPlsql) {
/*  6893 */         setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */       } else {
/*  6895 */         basicBindBytes(paramInt, paramArrayOfByte);
/*       */       }
/*  6897 */     } else if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*       */     {
/*  6899 */       if (j > this.maxRawBytesPlsql) {
/*  6900 */         setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */       } else {
/*  6902 */         basicBindBytes(paramInt, paramArrayOfByte);
/*       */       }
/*       */       
/*       */     }
/*  6906 */     else if (j > this.maxRawBytesSql)
/*       */     {
/*  6908 */       bindBytesAsStream(paramInt, paramArrayOfByte);
/*       */     }
/*       */     else {
/*  6911 */       basicBindBytes(paramInt, paramArrayOfByte);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void bindBytesAsStream(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6920 */     int i = paramArrayOfByte.length;
/*  6921 */     byte[] arrayOfByte = new byte[i];
/*  6922 */     System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, i);
/*  6923 */     set_execute_batch(1);
/*  6924 */     basicBindBinaryStream(paramInt, new ByteArrayInputStream(arrayOfByte), i, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void basicBindBytes(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6932 */     synchronized (this.connection)
/*       */     {
/*  6934 */       int i = paramInt - 1;
/*  6935 */       Binder localBinder = this.sqlKind.isPlsqlOrCall() ? this.thePlsqlRawBinder : this.theRawBinder;
/*  6936 */       this.currentRowBinders[i] = localBinder;
/*       */       
/*  6938 */       if (this.parameterDatum == null) {
/*  6939 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*  6942 */       this.parameterDatum[this.currentRank][i] = paramArrayOfByte;
/*  6943 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  6953 */     basicBindBinaryStream(paramInt1, paramInputStream, paramInt2, false);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  6961 */     synchronized (this.connection)
/*       */     {
/*  6963 */       int i = paramInt1 - 1;
/*       */       
/*  6965 */       if (paramBoolean) {
/*  6966 */         this.currentRowBinders[i] = this.theLongRawStreamForBytesBinder;
/*       */       } else {
/*  6968 */         this.currentRowBinders[i] = this.theLongRawStreamBinder;
/*       */       }
/*  6970 */       if (this.parameterStream == null) {
/*  6971 */         this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  6974 */       this.parameterStream[this.currentRank][i] = (paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramInputStream, 6, paramInt2) : this.connection.conversion.ConvertStream(paramInputStream, 6, paramInt2));
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  6979 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6999 */     if (paramArrayOfByte == null)
/*       */     {
/*  7001 */       setNull(paramInt, -2);
/*  7002 */       return;
/*       */     }
/*  7004 */     int i = paramArrayOfByte.length;
/*  7005 */     if (i == 0)
/*       */     {
/*  7007 */       setNull(paramInt, -2);
/*  7008 */       return;
/*       */     }
/*  7010 */     if (this.sqlKind.isPlsqlOrCall())
/*       */     {
/*  7012 */       if (i <= this.maxRawBytesPlsql)
/*       */       {
/*  7014 */         setBytes(paramInt, paramArrayOfByte);
/*       */       }
/*       */       else
/*       */       {
/*  7018 */         setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */       }
/*       */       
/*       */ 
/*       */     }
/*  7023 */     else if (i <= this.maxRawBytesSql)
/*       */     {
/*  7025 */       setBytes(paramInt, paramArrayOfByte);
/*       */ 
/*       */ 
/*       */ 
/*       */     }
/*       */     else
/*       */     {
/*       */ 
/*       */ 
/*  7034 */       setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setBytesForBlobCritical(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  7044 */     BLOB localBLOB = BLOB.createTemporary(this.connection, true, 10);
/*       */     
/*  7046 */     localBLOB.putBytes(1L, paramArrayOfByte);
/*  7047 */     addToTempLobsToFree(localBLOB);
/*  7048 */     this.lastBoundBlobs[(paramInt - 1)] = localBLOB;
/*  7049 */     setBLOBInternal(paramInt, localBLOB);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setBinaryStreamContentsForBlobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7060 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */       try
/*       */       {
/*  7065 */         if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null)
/*       */         {
/*  7067 */           if (paramBoolean)
/*       */           {
/*  7069 */             throw new IOException(paramLong + " byte of BLOB data cannot be read");
/*       */           }
/*  7071 */           setBLOBInternal(paramInt, null);
/*  7072 */           return;
/*       */         }
/*       */         
/*       */       }
/*       */       catch (IOException localIOException1)
/*       */       {
/*  7078 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/*  7079 */         ((SQLException)localObject1).fillInStackTrace();
/*  7080 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*  7084 */       BLOB localBLOB = BLOB.createTemporary(this.connection, true, 10);
/*       */       
/*       */ 
/*  7087 */       Object localObject1 = (OracleBlobOutputStream)localBLOB.setBinaryStream(1L);
/*       */       
/*  7089 */       int i = localBLOB.getBufferSize();
/*  7090 */       byte[] arrayOfByte = new byte[i];
/*  7091 */       long l = 0L;
/*  7092 */       int j = 0;
/*       */       
/*       */ 
/*  7095 */       l = paramBoolean ? paramLong : Long.MAX_VALUE;
/*       */       
/*       */       try
/*       */       {
/*  7099 */         while (l > 0L)
/*       */         {
/*  7101 */           if (l >= i) {
/*  7102 */             j = paramInputStream.read(arrayOfByte);
/*       */           } else {
/*  7104 */             j = paramInputStream.read(arrayOfByte, 0, (int)l);
/*       */           }
/*  7106 */           if (j == -1)
/*       */           {
/*  7108 */             if (!paramBoolean)
/*       */               break;
/*  7110 */             throw new IOException(l + " byte of BLOB data cannot be read");
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  7116 */           ((OracleBlobOutputStream)localObject1).write(arrayOfByte, 0, j);
/*  7117 */           l -= j;
/*       */         }
/*  7119 */         ((OracleBlobOutputStream)localObject1).flush();
/*       */ 
/*       */       }
/*       */       catch (IOException localIOException2)
/*       */       {
/*  7124 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/*  7125 */         localSQLException.fillInStackTrace();
/*  7126 */         throw localSQLException;
/*       */       }
/*       */       
/*  7129 */       addToTempLobsToFree(localBLOB);
/*  7130 */       this.lastBoundBlobs[(paramInt - 1)] = localBLOB;
/*  7131 */       setBLOBInternal(paramInt, localBLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  7149 */     String str = paramString.intern();
/*  7150 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  7151 */     int i = 0;
/*  7152 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  7154 */     for (int k = 0; k < j; k++) {
/*  7155 */       if (arrayOfString[k] == str)
/*       */       {
/*  7157 */         setBytesForBlob(k + 1, paramArrayOfByte);
/*       */         
/*  7159 */         i = 1;
/*       */       }
/*       */     }
/*  7162 */     if (i == 0)
/*       */     {
/*  7164 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  7165 */       localSQLException.fillInStackTrace();
/*  7166 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setInternalBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7180 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7183 */       setInternalBytesInternal(paramInt1, paramArrayOfByte, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setInternalBytesInternal(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7195 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7196 */     localSQLException.fillInStackTrace();
/*  7197 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDate(int paramInt, Date paramDate)
/*       */     throws SQLException
/*       */   {
/*  7212 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7215 */       setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, getDefaultCalendar()));
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setDateInternal(int paramInt, Date paramDate)
/*       */     throws SQLException
/*       */   {
/*  7225 */     setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, getDefaultCalendar()));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTime(int paramInt, Time paramTime)
/*       */     throws SQLException
/*       */   {
/*  7241 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7244 */       setTimeInternal(paramInt, paramTime);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setTimeInternal(int paramInt, Time paramTime)
/*       */     throws SQLException
/*       */   {
/*  7252 */     int i = paramInt - 1;
/*       */     
/*  7254 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7256 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7257 */       localSQLException.fillInStackTrace();
/*  7258 */       throw localSQLException;
/*       */     }
/*       */     
/*  7261 */     if (paramTime == null) {
/*  7262 */       this.currentRowBinders[i] = this.theDateNullBinder;
/*       */     }
/*       */     else {
/*  7265 */       this.currentRowBinders[i] = this.theTimeBinder;
/*       */       
/*  7267 */       if (this.parameterTime == null) {
/*  7268 */         this.parameterTime = new Time[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7273 */       this.parameterTime[this.currentRank][i] = paramTime;
/*       */     }
/*       */     
/*  7276 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/*  7291 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7294 */       setTimestampInternal(paramInt, paramTimestamp);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/*  7304 */     int i = paramInt - 1;
/*       */     
/*  7306 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7308 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*       */       
/*  7310 */       localSQLException.fillInStackTrace();
/*  7311 */       throw localSQLException;
/*       */     }
/*       */     
/*  7314 */     if (paramTimestamp == null) {
/*  7315 */       this.currentRowBinders[i] = this.theTimestampNullBinder;
/*       */     }
/*       */     else {
/*  7318 */       this.currentRowBinders[i] = this.theTimestampBinder;
/*       */       
/*  7320 */       if (this.parameterTimestamp == null) {
/*  7321 */         this.parameterTimestamp = new Timestamp[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7326 */       this.parameterTimestamp[this.currentRank][i] = paramTimestamp;
/*       */     }
/*       */     
/*  7329 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM)
/*       */     throws SQLException
/*       */   {
/*  7350 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7353 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setINTERVALYMInternal(int paramInt, INTERVALYM paramINTERVALYM)
/*       */     throws SQLException
/*       */   {
/*  7361 */     int i = paramInt - 1;
/*       */     
/*  7363 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7365 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7366 */       localSQLException.fillInStackTrace();
/*  7367 */       throw localSQLException;
/*       */     }
/*       */     
/*  7370 */     if (paramINTERVALYM == null)
/*       */     {
/*  7372 */       this.currentRowBinders[i] = this.theIntervalYMNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7376 */       this.currentRowBinders[i] = this.theIntervalYMBinder;
/*       */       
/*  7378 */       if (this.parameterDatum == null)
/*       */       {
/*  7380 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7385 */       this.parameterDatum[this.currentRank][i] = paramINTERVALYM.getBytes();
/*       */     }
/*       */     
/*  7388 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS)
/*       */     throws SQLException
/*       */   {
/*  7409 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7412 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setINTERVALDSInternal(int paramInt, INTERVALDS paramINTERVALDS)
/*       */     throws SQLException
/*       */   {
/*  7420 */     int i = paramInt - 1;
/*       */     
/*  7422 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7424 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7425 */       localSQLException.fillInStackTrace();
/*  7426 */       throw localSQLException;
/*       */     }
/*       */     
/*  7429 */     if (paramINTERVALDS == null)
/*       */     {
/*  7431 */       this.currentRowBinders[i] = this.theIntervalDSNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7435 */       this.currentRowBinders[i] = this.theIntervalDSBinder;
/*       */       
/*  7437 */       if (this.parameterDatum == null)
/*       */       {
/*  7439 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7444 */       this.parameterDatum[this.currentRank][i] = paramINTERVALDS.getBytes();
/*       */     }
/*       */     
/*  7447 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP)
/*       */     throws SQLException
/*       */   {
/*  7468 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7471 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setTIMESTAMPInternal(int paramInt, TIMESTAMP paramTIMESTAMP)
/*       */     throws SQLException
/*       */   {
/*  7479 */     int i = paramInt - 1;
/*       */     
/*  7481 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7483 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7484 */       localSQLException.fillInStackTrace();
/*  7485 */       throw localSQLException;
/*       */     }
/*       */     
/*  7488 */     if (paramTIMESTAMP == null)
/*       */     {
/*  7490 */       this.currentRowBinders[i] = this.theTimestampNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7494 */       this.currentRowBinders[i] = this.theOracleTimestampBinder;
/*       */       
/*  7496 */       if (this.parameterDatum == null)
/*       */       {
/*  7498 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7503 */       this.parameterDatum[this.currentRank][i] = paramTIMESTAMP.getBytes();
/*       */     }
/*       */     
/*  7506 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*       */     throws SQLException
/*       */   {
/*  7527 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7530 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTIMESTAMPTZInternal(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*       */     throws SQLException
/*       */   {
/*  7539 */     int i = paramInt - 1;
/*       */     
/*  7541 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7543 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7544 */       localSQLException.fillInStackTrace();
/*  7545 */       throw localSQLException;
/*       */     }
/*       */     
/*  7548 */     if (paramTIMESTAMPTZ == null)
/*       */     {
/*  7550 */       this.currentRowBinders[i] = this.theTSTZNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7554 */       this.currentRowBinders[i] = this.theTSTZBinder;
/*       */       
/*  7556 */       if (this.parameterDatum == null)
/*       */       {
/*  7558 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7563 */       this.parameterDatum[this.currentRank][i] = paramTIMESTAMPTZ.getBytes();
/*       */     }
/*       */     
/*  7566 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*       */     throws SQLException
/*       */   {
/*  7591 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7594 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTIMESTAMPLTZInternal(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*       */     throws SQLException
/*       */   {
/*  7603 */     if (this.connection.getSessionTimeZone() == null)
/*       */     {
/*       */ 
/*  7606 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 105);
/*  7607 */       localSQLException1.fillInStackTrace();
/*  7608 */       throw localSQLException1;
/*       */     }
/*       */     
/*       */ 
/*  7612 */     int i = paramInt - 1;
/*       */     
/*  7614 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7616 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7617 */       localSQLException2.fillInStackTrace();
/*  7618 */       throw localSQLException2;
/*       */     }
/*       */     
/*  7621 */     if (paramTIMESTAMPLTZ == null)
/*       */     {
/*  7623 */       this.currentRowBinders[i] = this.theTSLTZNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7627 */       this.currentRowBinders[i] = this.theTSLTZBinder;
/*       */       
/*  7629 */       if (this.parameterDatum == null)
/*       */       {
/*  7631 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7636 */       this.parameterDatum[this.currentRank][i] = paramTIMESTAMPLTZ.getBytes();
/*       */     }
/*       */     
/*  7639 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private Reader isReaderEmpty(Reader paramReader)
/*       */     throws IOException
/*       */   {
/*  7650 */     if (!paramReader.markSupported())
/*  7651 */       paramReader = new BufferedReader(paramReader, 5);
/*  7652 */     paramReader.mark(100);
/*  7653 */     int i; if ((i = paramReader.read()) == -1) {
/*  7654 */       return null;
/*       */     }
/*       */     
/*  7657 */     paramReader.reset();
/*  7658 */     return paramReader;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   private InputStream isInputStreamEmpty(InputStream paramInputStream)
/*       */     throws IOException
/*       */   {
/*  7666 */     if (!paramInputStream.markSupported())
/*  7667 */       paramInputStream = new BufferedInputStream(paramInputStream, 5);
/*  7668 */     paramInputStream.mark(100);
/*  7669 */     int i; if ((i = paramInputStream.read()) == -1) {
/*  7670 */       return null;
/*       */     }
/*       */     
/*  7673 */     paramInputStream.reset();
/*  7674 */     return paramInputStream;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7700 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7703 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setAsciiStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7712 */     setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7720 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  7722 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7724 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7725 */       localSQLException.fillInStackTrace();
/*  7726 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  7732 */     set_execute_batch(1);
/*  7733 */     checkUserStreamForDuplicates(paramInputStream, i);
/*  7734 */     if (paramInputStream == null) {
/*  7735 */       basicBindNullString(paramInt);
/*  7736 */     } else { if ((this.userRsetType != 1) && ((paramLong > this.maxVcsCharsSql) || (!paramBoolean)))
/*       */       {
/*  7738 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  7739 */         localSQLException.fillInStackTrace();
/*  7740 */         throw localSQLException;
/*       */       }
/*  7742 */       if (!paramBoolean) {
/*  7743 */         setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*  7744 */       } else if (this.currentRowFormOfUse[i] == 1)
/*       */       {
/*  7746 */         if (this.sqlKind.isPlsqlOrCall())
/*       */         {
/*  7748 */           if ((paramLong <= this.maxVcsCharsPlsql) && (!this.connection.retainV9BindBehavior))
/*       */           {
/*  7750 */             setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */           }
/*       */           else
/*       */           {
/*  7755 */             setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */ 
/*       */           }
/*       */           
/*       */ 
/*       */         }
/*  7761 */         else if ((paramLong <= this.maxVcsCharsSql) && (!this.connection.retainV9BindBehavior))
/*       */         {
/*  7763 */           setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */         }
/*  7766 */         else if (paramLong > 2147483647L)
/*       */         {
/*  7768 */           setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/*  7773 */           basicBindAsciiStream(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  7779 */       else if (this.sqlKind.isPlsqlOrCall())
/*       */       {
/*  7781 */         if ((paramLong <= this.maxVcsNCharsPlsql) && (!this.connection.retainV9BindBehavior))
/*       */         {
/*  7783 */           setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/*  7788 */           setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */ 
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  7794 */       else if ((paramLong <= this.maxVcsNCharsSql) && (!this.connection.retainV9BindBehavior))
/*       */       {
/*  7796 */         setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  7801 */         setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void basicBindAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7813 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7816 */       if (this.userRsetType != 1)
/*       */       {
/*  7818 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  7819 */         localSQLException.fillInStackTrace();
/*  7820 */         throw localSQLException;
/*       */       }
/*  7822 */       int i = paramInt1 - 1;
/*  7823 */       this.currentRowBinders[i] = this.theLongStreamBinder;
/*       */       
/*  7825 */       if (this.parameterStream == null) {
/*  7826 */         this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  7829 */       this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 5, paramInt2);
/*       */       
/*       */ 
/*       */ 
/*  7833 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setAsciiStreamContentsForStringInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7843 */     byte[] arrayOfByte = new byte[paramInt2];
/*  7844 */     int i = 0;
/*  7845 */     int j = paramInt2;
/*       */     
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  7851 */       while ((j > 0) && ((k = paramInputStream.read(arrayOfByte, i, j)) != -1)) {
/*  7852 */         i += k;
/*  7853 */         j -= k;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  7859 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  7860 */       localSQLException.fillInStackTrace();
/*  7861 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  7866 */     char[] arrayOfChar = new char[paramInt2];
/*  7867 */     DBConversion.asciiBytesToJavaChars(arrayOfByte, i, arrayOfChar);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  7872 */     basicBindString(paramInt1, new String(arrayOfChar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7899 */     setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7907 */     setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void checkUserStreamForDuplicates(Object paramObject, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  7915 */     if (paramObject == null)
/*       */     {
/*  7917 */       return;
/*       */     }
/*  7919 */     if (this.userStream != null)
/*       */     {
/*  7921 */       for (Object[] arrayOfObject1 : this.userStream)
/*       */       {
/*  7923 */         for (Object localObject : arrayOfObject1)
/*       */         {
/*  7925 */           if (localObject == paramObject)
/*       */           {
/*       */ 
/*  7928 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 270, Integer.valueOf(paramInt + 1));
/*  7929 */             localSQLException.fillInStackTrace();
/*  7930 */             throw localSQLException;
/*       */           }
/*       */           
/*       */         }
/*       */         
/*       */       }
/*       */       
/*       */     } else {
/*  7938 */       this.userStream = new Object[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*  7940 */     this.userStream[this.currentRank][paramInt] = paramObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7948 */     synchronized (this.connection)
/*       */     {
/*  7950 */       int i = paramInt - 1;
/*       */       SQLException localSQLException;
/*  7952 */       if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */       {
/*  7954 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7955 */         localSQLException.fillInStackTrace();
/*  7956 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7961 */       set_execute_batch(1);
/*       */       
/*  7963 */       checkUserStreamForDuplicates(paramInputStream, i);
/*       */       
/*  7965 */       if (paramInputStream == null) {
/*  7966 */         setRAWInternal(paramInt, null);
/*  7967 */       } else { if ((this.userRsetType != 1) && ((paramLong > this.maxRawBytesSql) || (!paramBoolean)))
/*       */         {
/*       */ 
/*  7970 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  7971 */           localSQLException.fillInStackTrace();
/*  7972 */           throw localSQLException;
/*       */         }
/*  7974 */         if (!paramBoolean) {
/*  7975 */           setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */         }
/*  7977 */         else if (this.sqlKind.isPlsqlOrCall())
/*       */         {
/*  7979 */           if (paramLong > this.maxRawBytesPlsql)
/*       */           {
/*  7981 */             setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */ 
/*       */           }
/*       */           else
/*       */           {
/*  7986 */             setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */           }
/*       */           
/*       */ 
/*       */         }
/*  7992 */         else if (paramLong > 2147483647L)
/*       */         {
/*  7994 */           setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */ 
/*       */         }
/*  7997 */         else if (paramLong > this.maxRawBytesSql)
/*       */         {
/*  7999 */           basicBindBinaryStream(paramInt, paramInputStream, (int)paramLong);
/*       */         }
/*       */         else
/*       */         {
/*  8003 */           setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong);
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setBinaryStreamContentsForByteArrayInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8017 */     Object localObject = new byte[paramInt2];
/*  8018 */     int i = 0;
/*  8019 */     int j = paramInt2;
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  8026 */       while ((j > 0) && ((k = paramInputStream.read((byte[])localObject, i, j)) != -1))
/*       */       {
/*  8028 */         i += k;
/*  8029 */         j -= k;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  8035 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  8036 */       localSQLException.fillInStackTrace();
/*  8037 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  8041 */     if (i != paramInt2)
/*       */     {
/*  8043 */       byte[] arrayOfByte = new byte[i];
/*       */       
/*  8045 */       System.arraycopy(localObject, 0, arrayOfByte, 0, i);
/*       */       
/*  8047 */       localObject = arrayOfByte;
/*       */     }
/*       */     
/*  8050 */     setBytesInternal(paramInt1, (byte[])localObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8081 */     setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setUnicodeStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8089 */     synchronized (this.connection)
/*       */     {
/*  8091 */       int i = paramInt1 - 1;
/*       */       Object localObject1;
/*  8093 */       if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */       {
/*  8095 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  8096 */         ((SQLException)localObject1).fillInStackTrace();
/*  8097 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  8103 */       set_execute_batch(1);
/*  8104 */       checkUserStreamForDuplicates(paramInputStream, i);
/*  8105 */       if (paramInputStream == null) {
/*  8106 */         setStringInternal(paramInt1, null);
/*  8107 */       } else { if ((this.userRsetType != 1) && (paramInt2 > this.maxVcsCharsSql))
/*       */         {
/*  8109 */           localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  8110 */           ((SQLException)localObject1).fillInStackTrace();
/*  8111 */           throw ((Throwable)localObject1);
/*       */         }
/*  8113 */         if ((this.sqlKind.isPlsqlOrCall()) || (paramInt2 <= this.maxVcsCharsSql))
/*       */         {
/*  8115 */           localObject1 = new byte[paramInt2];
/*  8116 */           int j = 0;
/*  8117 */           int k = paramInt2;
/*       */           
/*       */ 
/*       */           try
/*       */           {
/*       */             int m;
/*       */             
/*  8124 */             while ((k > 0) && ((m = paramInputStream.read((byte[])localObject1, j, k)) != -1))
/*       */             {
/*  8126 */               j += m;
/*  8127 */               k -= m;
/*       */             }
/*       */             
/*       */           }
/*       */           catch (IOException localIOException)
/*       */           {
/*  8133 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  8134 */             localSQLException.fillInStackTrace();
/*  8135 */             throw localSQLException;
/*       */           }
/*       */           
/*       */ 
/*  8139 */           char[] arrayOfChar = new char[j >> 1];
/*       */           
/*  8141 */           DBConversion.ucs2BytesToJavaChars((byte[])localObject1, j, arrayOfChar);
/*       */           
/*       */ 
/*  8144 */           setStringInternal(paramInt1, new String(arrayOfChar));
/*       */         }
/*       */         else
/*       */         {
/*  8148 */           this.currentRowBinders[i] = this.theLongStreamBinder;
/*       */           
/*  8150 */           if (this.parameterStream == null) {
/*  8151 */             this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */           }
/*       */           
/*  8154 */           this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 4, paramInt2);
/*       */           
/*       */ 
/*       */ 
/*  8158 */           this.currentRowCharLens[i] = 0;
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum)
/*       */     throws SQLException
/*       */   {
/*  8178 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8184 */       setObjectInternal(paramInt, this.connection.toDatum(paramCustomDatum));
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setCustomDatumInternal(int paramInt, CustomDatum paramCustomDatum)
/*       */     throws SQLException
/*       */   {
/*  8192 */     synchronized (this.connection)
/*       */     {
/*  8194 */       Datum localDatum = this.connection.toDatum(paramCustomDatum);
/*  8195 */       int i = sqlTypeForObject(localDatum);
/*       */       
/*  8197 */       setObjectCritical(paramInt, localDatum, i, 0);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setORAData(int paramInt, ORAData paramORAData)
/*       */     throws SQLException
/*       */   {
/*  8217 */     setORADataInternal(paramInt, paramORAData);
/*       */   }
/*       */   
/*       */   void setORADataInternal(int paramInt, ORAData paramORAData)
/*       */     throws SQLException
/*       */   {
/*  8223 */     synchronized (this.connection)
/*       */     {
/*  8225 */       Datum localDatum = paramORAData.toDatum(this.connection);
/*  8226 */       int i = sqlTypeForObject(localDatum);
/*       */       
/*  8228 */       setObjectCritical(paramInt, localDatum, i, 0);
/*       */       
/*  8230 */       if ((i == 2002) || (i == 2008) || (i == 2003))
/*       */       {
/*       */ 
/*       */ 
/*  8234 */         this.currentRowCharLens[(paramInt - 1)] = 0;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */   void setOracleDataInternal(int paramInt, OracleData paramOracleData)
/*       */     throws SQLException
/*       */   {
/*  8242 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  8245 */       Object localObject1 = paramOracleData.toJDBCObject(this.connection);
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8251 */       int i = sqlTypeForObject(localObject1);
/*       */       
/*  8253 */       setObjectCritical(paramInt, localObject1, i, 0);
/*       */       
/*  8255 */       if ((i == 2002) || (i == 2008) || (i == 2003))
/*       */       {
/*       */ 
/*       */ 
/*  8259 */         this.currentRowCharLens[(paramInt - 1)] = 0;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  8289 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  8292 */       setObjectInternal(paramInt1, paramObject, paramInt2, paramInt3);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  8304 */     if ((paramObject == null) && (paramInt2 != 2002) && (paramInt2 != 2008) && (paramInt2 != 2003) && (paramInt2 != 2007) && (paramInt2 != 2006))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8315 */       setNullInternal(paramInt1, paramInt2);
/*       */ 
/*       */ 
/*       */     }
/*  8319 */     else if ((paramInt2 == 2002) || (paramInt2 == 2008) || (paramInt2 == 2003))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8328 */       setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3);
/*       */       
/*  8330 */       this.currentRowCharLens[(paramInt1 - 1)] = 0;
/*       */ 
/*       */     }
/*       */     else
/*       */     {
/*       */ 
/*  8336 */       setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setObjectCritical(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8361 */     switch (paramInt2)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 1: 
/*  8368 */       if ((paramObject instanceof CHAR)) {
/*  8369 */         setCHARInternal(paramInt1, (CHAR)paramObject);
/*  8370 */       } else if ((paramObject instanceof String)) {
/*  8371 */         setStringInternal(paramInt1, (String)paramObject);
/*  8372 */       } else if ((paramObject instanceof Boolean)) {
/*  8373 */         setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*  8375 */       else if ((paramObject instanceof Integer)) {
/*  8376 */         setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue());
/*  8377 */       } else if ((paramObject instanceof Long)) {
/*  8378 */         setStringInternal(paramInt1, "" + ((Long)paramObject).longValue());
/*  8379 */       } else if ((paramObject instanceof Float)) {
/*  8380 */         setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue());
/*  8381 */       } else if ((paramObject instanceof Double)) {
/*  8382 */         setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue());
/*  8383 */       } else if ((paramObject instanceof BigDecimal)) {
/*  8384 */         setStringInternal(paramInt1, ((BigDecimal)paramObject).toString());
/*  8385 */       } else if ((paramObject instanceof Date)) {
/*  8386 */         setStringInternal(paramInt1, "" + ((Date)paramObject).toString());
/*  8387 */       } else if ((paramObject instanceof Time)) {
/*  8388 */         setStringInternal(paramInt1, "" + ((Time)paramObject).toString());
/*  8389 */       } else if ((paramObject instanceof Timestamp)) {
/*  8390 */         setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString());
/*       */       }
/*       */       else {
/*  8393 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8395 */         localSQLException.fillInStackTrace();
/*  8396 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       break;
/*       */     case 12: 
/*  8405 */       if ((paramObject instanceof String)) {
/*  8406 */         setStringInternal(paramInt1, (String)paramObject);
/*  8407 */       } else if ((paramObject instanceof Boolean)) {
/*  8408 */         setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*  8410 */       else if ((paramObject instanceof Integer)) {
/*  8411 */         setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue());
/*  8412 */       } else if ((paramObject instanceof Long)) {
/*  8413 */         setStringInternal(paramInt1, "" + ((Long)paramObject).longValue());
/*  8414 */       } else if ((paramObject instanceof Float)) {
/*  8415 */         setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue());
/*  8416 */       } else if ((paramObject instanceof Double)) {
/*  8417 */         setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue());
/*  8418 */       } else if ((paramObject instanceof BigDecimal)) {
/*  8419 */         setStringInternal(paramInt1, ((BigDecimal)paramObject).toString());
/*  8420 */       } else if ((paramObject instanceof Date)) {
/*  8421 */         setStringInternal(paramInt1, "" + ((Date)paramObject).toString());
/*  8422 */       } else if ((paramObject instanceof Time)) {
/*  8423 */         setStringInternal(paramInt1, "" + ((Time)paramObject).toString());
/*  8424 */       } else if ((paramObject instanceof Timestamp)) {
/*  8425 */         setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString());
/*       */       }
/*       */       else {
/*  8428 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8430 */         localSQLException.fillInStackTrace();
/*  8431 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 999: 
/*  8437 */       setFixedCHARInternal(paramInt1, (String)paramObject);
/*       */       
/*  8439 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case -1: 
/*  8445 */       if ((paramObject instanceof String)) {
/*  8446 */         setStringInternal(paramInt1, (String)paramObject);
/*  8447 */       } else if ((paramObject instanceof Boolean)) {
/*  8448 */         setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */ 
/*       */       }
/*  8451 */       else if ((paramObject instanceof Integer)) {
/*  8452 */         setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue());
/*       */       }
/*  8454 */       else if ((paramObject instanceof Long)) {
/*  8455 */         setStringInternal(paramInt1, "" + ((Long)paramObject).longValue());
/*       */       }
/*  8457 */       else if ((paramObject instanceof Float)) {
/*  8458 */         setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue());
/*       */       }
/*  8460 */       else if ((paramObject instanceof Double)) {
/*  8461 */         setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue());
/*       */       }
/*  8463 */       else if ((paramObject instanceof BigDecimal)) {
/*  8464 */         setStringInternal(paramInt1, ((BigDecimal)paramObject).toString());
/*  8465 */       } else if ((paramObject instanceof Date)) {
/*  8466 */         setStringInternal(paramInt1, "" + ((Date)paramObject).toString());
/*  8467 */       } else if ((paramObject instanceof Time)) {
/*  8468 */         setStringInternal(paramInt1, "" + ((Time)paramObject).toString());
/*  8469 */       } else if ((paramObject instanceof Timestamp)) {
/*  8470 */         setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString());
/*       */       }
/*       */       else
/*       */       {
/*  8474 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8476 */         localSQLException.fillInStackTrace();
/*  8477 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */       break;
/*       */     case 2: 
/*  8484 */       if ((paramObject instanceof NUMBER)) {
/*  8485 */         setNUMBERInternal(paramInt1, (NUMBER)paramObject);
/*  8486 */       } else if ((paramObject instanceof Integer)) {
/*  8487 */         setIntInternal(paramInt1, ((Integer)paramObject).intValue());
/*  8488 */       } else if ((paramObject instanceof Long)) {
/*  8489 */         setLongInternal(paramInt1, ((Long)paramObject).longValue());
/*  8490 */       } else if ((paramObject instanceof Float)) {
/*  8491 */         setFloatInternal(paramInt1, ((Float)paramObject).floatValue());
/*  8492 */       } else if ((paramObject instanceof Double)) {
/*  8493 */         setDoubleInternal(paramInt1, ((Double)paramObject).doubleValue());
/*  8494 */       } else if ((paramObject instanceof BigDecimal)) {
/*  8495 */         setBigDecimalInternal(paramInt1, (BigDecimal)paramObject);
/*  8496 */       } else if ((paramObject instanceof BigInteger)) {
/*  8497 */         setBigDecimalInternal(paramInt1, new BigDecimal((BigInteger)paramObject));
/*  8498 */       } else if ((paramObject instanceof String)) {
/*  8499 */         setNUMBERInternal(paramInt1, new NUMBER((String)paramObject, paramInt3));
/*  8500 */       } else if ((paramObject instanceof Boolean)) {
/*  8501 */         setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0);
/*  8502 */       } else if ((paramObject instanceof Short)) {
/*  8503 */         setShortInternal(paramInt1, ((Short)paramObject).shortValue());
/*  8504 */       } else if ((paramObject instanceof Byte)) {
/*  8505 */         setByteInternal(paramInt1, ((Byte)paramObject).byteValue());
/*       */       }
/*       */       else {
/*  8508 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8510 */         localSQLException.fillInStackTrace();
/*  8511 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 3: 
/*  8517 */       if ((paramObject instanceof BigDecimal)) {
/*  8518 */         setBigDecimalInternal(paramInt1, (BigDecimal)paramObject);
/*  8519 */       } else if ((paramObject instanceof Number)) {
/*  8520 */         setBigDecimalInternal(paramInt1, new BigDecimal(((Number)paramObject).doubleValue()));
/*       */       }
/*  8522 */       else if ((paramObject instanceof NUMBER)) {
/*  8523 */         setBigDecimalInternal(paramInt1, ((NUMBER)paramObject).bigDecimalValue());
/*  8524 */       } else if ((paramObject instanceof String)) {
/*  8525 */         setBigDecimalInternal(paramInt1, new BigDecimal((String)paramObject));
/*  8526 */       } else if ((paramObject instanceof Boolean)) {
/*  8527 */         setBigDecimalInternal(paramInt1, new BigDecimal(((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D));
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  8532 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8534 */         localSQLException.fillInStackTrace();
/*  8535 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -7: 
/*  8541 */       if ((paramObject instanceof Boolean)) {
/*  8542 */         setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*  8544 */       else if ((paramObject instanceof String)) {
/*  8545 */         setByteInternal(paramInt1, (byte)(("true".equalsIgnoreCase((String)paramObject)) || ("1".equals(paramObject)) ? 1 : 0));
/*       */ 
/*       */ 
/*       */       }
/*  8549 */       else if ((paramObject instanceof Number)) {
/*  8550 */         setIntInternal(paramInt1, ((Number)paramObject).byteValue() != 0 ? 1 : 0);
/*       */       }
/*       */       else {
/*  8553 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8555 */         localSQLException.fillInStackTrace();
/*  8556 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       break;
/*       */     case -6: 
/*  8564 */       if ((paramObject instanceof Number)) {
/*  8565 */         setByteInternal(paramInt1, ((Number)paramObject).byteValue());
/*  8566 */       } else if ((paramObject instanceof String)) {
/*  8567 */         setByteInternal(paramInt1, Byte.parseByte((String)paramObject));
/*  8568 */       } else if ((paramObject instanceof Boolean)) {
/*  8569 */         setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*       */       else
/*       */       {
/*  8573 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8575 */         localSQLException.fillInStackTrace();
/*  8576 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       break;
/*       */     case 5: 
/*  8584 */       if ((paramObject instanceof Number)) {
/*  8585 */         setShortInternal(paramInt1, ((Number)paramObject).shortValue());
/*  8586 */       } else if ((paramObject instanceof String)) {
/*  8587 */         setShortInternal(paramInt1, Short.parseShort((String)paramObject));
/*  8588 */       } else if ((paramObject instanceof Boolean)) {
/*  8589 */         setShortInternal(paramInt1, (short)(((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*       */       else
/*       */       {
/*  8593 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8595 */         localSQLException.fillInStackTrace();
/*  8596 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 4: 
/*  8602 */       if ((paramObject instanceof Number)) {
/*  8603 */         setIntInternal(paramInt1, ((Number)paramObject).intValue());
/*  8604 */       } else if ((paramObject instanceof String)) {
/*  8605 */         setIntInternal(paramInt1, Integer.parseInt((String)paramObject));
/*  8606 */       } else if ((paramObject instanceof Boolean)) {
/*  8607 */         setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0);
/*       */       }
/*       */       else {
/*  8610 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8612 */         localSQLException.fillInStackTrace();
/*  8613 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -5: 
/*  8619 */       if ((paramObject instanceof Number)) {
/*  8620 */         setLongInternal(paramInt1, ((Number)paramObject).longValue());
/*  8621 */       } else if ((paramObject instanceof String)) {
/*  8622 */         setLongInternal(paramInt1, Long.parseLong((String)paramObject));
/*  8623 */       } else if ((paramObject instanceof Boolean)) {
/*  8624 */         setLongInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1L : 0L);
/*       */       }
/*       */       else {
/*  8627 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8629 */         localSQLException.fillInStackTrace();
/*  8630 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 7: 
/*  8636 */       if ((paramObject instanceof Number)) {
/*  8637 */         setFloatInternal(paramInt1, ((Number)paramObject).floatValue());
/*  8638 */       } else if ((paramObject instanceof String)) {
/*  8639 */         setFloatInternal(paramInt1, Float.valueOf((String)paramObject).floatValue());
/*  8640 */       } else if ((paramObject instanceof Boolean)) {
/*  8641 */         setFloatInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0F : 0.0F);
/*       */       }
/*       */       else {
/*  8644 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8646 */         localSQLException.fillInStackTrace();
/*  8647 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */       break;
/*       */     case 6: 
/*       */     case 8: 
/*  8655 */       if ((paramObject instanceof Number)) {
/*  8656 */         setDoubleInternal(paramInt1, ((Number)paramObject).doubleValue());
/*  8657 */       } else if ((paramObject instanceof String)) {
/*  8658 */         setDoubleInternal(paramInt1, Double.valueOf((String)paramObject).doubleValue());
/*       */       }
/*  8660 */       else if ((paramObject instanceof Boolean)) {
/*  8661 */         setDoubleInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D);
/*       */       }
/*       */       else
/*       */       {
/*  8665 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8667 */         localSQLException.fillInStackTrace();
/*  8668 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -2: 
/*  8674 */       if ((paramObject instanceof RAW)) {
/*  8675 */         setRAWInternal(paramInt1, (RAW)paramObject);
/*       */       } else {
/*  8677 */         setBytesInternal(paramInt1, (byte[])paramObject);
/*       */       }
/*  8679 */       break;
/*       */     
/*       */     case -3: 
/*  8682 */       setBytesInternal(paramInt1, (byte[])paramObject);
/*       */       
/*  8684 */       break;
/*       */     
/*       */     case -4: 
/*  8687 */       setBytesInternal(paramInt1, (byte[])paramObject);
/*       */       
/*  8689 */       break;
/*       */     
/*       */     case 91: 
/*  8692 */       if ((paramObject instanceof DATE)) {
/*  8693 */         setDATEInternal(paramInt1, (DATE)paramObject);
/*  8694 */       } else if ((paramObject instanceof Date)) {
/*  8695 */         setDATEInternal(paramInt1, new DATE(paramObject, getDefaultCalendar()));
/*  8696 */       } else if ((paramObject instanceof Timestamp)) {
/*  8697 */         setDATEInternal(paramInt1, new DATE((Timestamp)paramObject));
/*  8698 */       } else if ((paramObject instanceof String)) {
/*  8699 */         setDateInternal(paramInt1, Date.valueOf((String)paramObject));
/*       */       }
/*       */       else {
/*  8702 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8704 */         localSQLException.fillInStackTrace();
/*  8705 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 92: 
/*  8711 */       if ((paramObject instanceof Time)) {
/*  8712 */         setTimeInternal(paramInt1, (Time)paramObject);
/*  8713 */       } else if ((paramObject instanceof Timestamp)) {
/*  8714 */         setTimeInternal(paramInt1, new Time(((Timestamp)paramObject).getTime()));
/*       */       }
/*  8716 */       else if ((paramObject instanceof Date)) {
/*  8717 */         setTimeInternal(paramInt1, new Time(((Date)paramObject).getTime()));
/*  8718 */       } else if ((paramObject instanceof String)) {
/*  8719 */         setTimeInternal(paramInt1, Time.valueOf((String)paramObject));
/*       */       }
/*       */       else {
/*  8722 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8724 */         localSQLException.fillInStackTrace();
/*  8725 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 93: 
/*  8731 */       if ((paramObject instanceof TIMESTAMP)) {
/*  8732 */         setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject);
/*  8733 */       } else if ((paramObject instanceof Timestamp)) {
/*  8734 */         setTimestampInternal(paramInt1, (Timestamp)paramObject);
/*  8735 */       } else if ((paramObject instanceof Date)) {
/*  8736 */         setTIMESTAMPInternal(paramInt1, new TIMESTAMP((Date)paramObject));
/*  8737 */       } else if ((paramObject instanceof DATE)) {
/*  8738 */         setTIMESTAMPInternal(paramInt1, new TIMESTAMP(((DATE)paramObject).timestampValue()));
/*  8739 */       } else if ((paramObject instanceof String)) {
/*  8740 */         setTimestampInternal(paramInt1, Timestamp.valueOf((String)paramObject));
/*       */       }
/*       */       else {
/*  8743 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8745 */         localSQLException.fillInStackTrace();
/*  8746 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -100: 
/*  8752 */       setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject);
/*       */       
/*  8754 */       break;
/*       */     
/*       */     case -101: 
/*  8757 */       setTIMESTAMPTZInternal(paramInt1, (TIMESTAMPTZ)paramObject);
/*       */       
/*  8759 */       break;
/*       */     
/*       */     case -102: 
/*  8762 */       setTIMESTAMPLTZInternal(paramInt1, (TIMESTAMPLTZ)paramObject);
/*       */       
/*  8764 */       break;
/*       */     
/*       */     case -103: 
/*  8767 */       setINTERVALYMInternal(paramInt1, (INTERVALYM)paramObject);
/*       */       
/*  8769 */       break;
/*       */     
/*       */     case -104: 
/*  8772 */       setINTERVALDSInternal(paramInt1, (INTERVALDS)paramObject);
/*       */       
/*  8774 */       break;
/*       */     
/*       */     case -8: 
/*  8777 */       setROWIDInternal(paramInt1, (ROWID)paramObject);
/*       */       
/*  8779 */       break;
/*       */     
/*       */     case 100: 
/*  8782 */       setBinaryFloatInternal(paramInt1, (BINARY_FLOAT)paramObject);
/*       */       
/*  8784 */       break;
/*       */     
/*       */     case 101: 
/*  8787 */       setBinaryDoubleInternal(paramInt1, (BINARY_DOUBLE)paramObject);
/*       */       
/*  8789 */       break;
/*       */     
/*       */     case 2004: 
/*  8792 */       setBLOBInternal(paramInt1, (BLOB)paramObject);
/*       */       
/*  8794 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2005: 
/*  8800 */       setCLOBInternal(paramInt1, (CLOB)paramObject);
/*  8801 */       if (((CLOB)paramObject).isNCLOB())
/*       */       {
/*  8803 */         setFormOfUse(paramInt1, (short)2);
/*       */       }
/*       */       
/*       */       break;
/*       */     case -13: 
/*  8808 */       setBFILEInternal(paramInt1, (BFILE)paramObject);
/*       */       
/*  8810 */       break;
/*       */     
/*       */ 
/*       */     case 2002: 
/*       */     case 2008: 
/*  8815 */       setSTRUCTInternal(paramInt1, STRUCT.toSTRUCT(paramObject, this.connection));
/*       */       
/*  8817 */       break;
/*       */     
/*       */     case 2003: 
/*  8820 */       setARRAYInternal(paramInt1, ARRAY.toARRAY(paramObject, this.connection));
/*       */       
/*       */ 
/*  8823 */       break;
/*       */     
/*       */     case 2007: 
/*  8826 */       setOPAQUEInternal(paramInt1, (OPAQUE)paramObject);
/*       */       
/*  8828 */       break;
/*       */     
/*       */     case 2006: 
/*  8831 */       setREFInternal(paramInt1, (REF)paramObject);
/*       */       
/*  8833 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     default: 
/*  8841 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  8842 */       localSQLException.fillInStackTrace();
/*  8843 */       throw localSQLException;
/*       */     }
/*       */     
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8864 */     String str = paramString.intern();
/*  8865 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  8866 */     int i = 0;
/*  8867 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  8869 */     for (int k = 0; k < j; k++) {
/*  8870 */       if (arrayOfString[k] == str)
/*       */       {
/*  8872 */         setObjectInternal(k + 1, paramObject);
/*       */         
/*  8874 */         i = 1;
/*       */       }
/*       */     }
/*  8877 */     if (i == 0)
/*       */     {
/*  8879 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  8880 */       localSQLException.fillInStackTrace();
/*  8881 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8901 */     setObjectInternal(paramInt1, paramObject, paramInt2, 0);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8910 */     setObjectInternal(paramInt1, paramObject, paramInt2, 0);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRefType(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8926 */     setREFInternal(paramInt, paramREF);
/*       */   }
/*       */   
/*       */ 
/*       */   void setRefTypeInternal(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8933 */     setREFInternal(paramInt, paramREF);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRef(int paramInt, Ref paramRef)
/*       */     throws SQLException
/*       */   {
/*  8950 */     setREFInternal(paramInt, (REF)paramRef);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setRefInternal(int paramInt, Ref paramRef)
/*       */     throws SQLException
/*       */   {
/*  8958 */     setREFInternal(paramInt, (REF)paramRef);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setREF(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8975 */     setREFInternal(paramInt, paramREF);
/*       */   }
/*       */   
/*       */ 
/*       */   void setREFInternal(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8982 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  8984 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  8986 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  8987 */       localSQLException.fillInStackTrace();
/*  8988 */       throw localSQLException;
/*       */     }
/*       */     
/*  8991 */     if (paramREF == null)
/*       */     {
/*       */ 
/*  8994 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  8995 */       localSQLException.fillInStackTrace();
/*  8996 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  9002 */     setREFCritical(i, paramREF);
/*       */     
/*  9004 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setREFCritical(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  9021 */     StructDescriptor localStructDescriptor = paramREF.getDescriptor();
/*       */     
/*       */ 
/*  9024 */     if (localStructDescriptor == null)
/*       */     {
/*  9026 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 52);
/*  9027 */       ((SQLException)localObject).fillInStackTrace();
/*  9028 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*  9032 */     this.currentRowBinders[paramInt] = this.theRefTypeBinder;
/*       */     
/*  9034 */     if (this.parameterDatum == null)
/*       */     {
/*  9036 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  9041 */     this.parameterDatum[this.currentRank][paramInt] = paramREF.getBytes();
/*       */     
/*  9043 */     Object localObject = localStructDescriptor.getOracleTypeADT();
/*       */     
/*  9045 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  9047 */     if (this.parameterOtype == null)
/*       */     {
/*  9049 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  9053 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObject(int paramInt, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  9074 */     setObjectInternal(paramInt, paramObject);
/*       */   }
/*       */   
/*       */ 
/*       */   void setObjectInternal(int paramInt, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  9081 */     if ((paramObject instanceof ORAData))
/*       */     {
/*  9083 */       setORADataInternal(paramInt, (ORAData)paramObject);
/*       */     }
/*  9085 */     else if ((paramObject instanceof CustomDatum))
/*       */     {
/*  9087 */       setCustomDatumInternal(paramInt, (CustomDatum)paramObject);
/*       */     }
/*  9089 */     else if ((paramObject instanceof OracleData))
/*       */     {
/*  9091 */       setOracleDataInternal(paramInt, (OracleData)paramObject);
/*       */     }
/*       */     else
/*       */     {
/*  9095 */       int i = sqlTypeForObject(paramObject);
/*       */       
/*  9097 */       setObjectInternal(paramInt, paramObject, i, 0);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOracleObject(int paramInt, Datum paramDatum)
/*       */     throws SQLException
/*       */   {
/*  9115 */     setObjectInternal(paramInt, paramDatum);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setOracleObjectInternal(int paramInt, Datum paramDatum)
/*       */     throws SQLException
/*       */   {
/*  9123 */     setObjectInternal(paramInt, paramDatum);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*       */     throws SQLException
/*       */   {
/*  9150 */     synchronized (this.connection)
/*       */     {
/*  9152 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setPlsqlIndexTableInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*       */     throws SQLException
/*       */   {
/*  9166 */     int i = paramInt1 - 1;
/*       */     SQLException localSQLException;
/*  9168 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  9170 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9171 */       localSQLException.fillInStackTrace();
/*  9172 */       throw localSQLException;
/*       */     }
/*       */     
/*  9175 */     if (paramObject == null)
/*       */     {
/*  9177 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 271);
/*  9178 */       localSQLException.fillInStackTrace();
/*  9179 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  9184 */     int j = getInternalType(paramInt4);
/*       */     
/*  9186 */     Object localObject1 = null;
/*       */     
/*       */     Object localObject2;
/*  9189 */     switch (j)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */     case 1: 
/*       */     case 96: 
/*  9196 */       localObject2 = null;
/*  9197 */       int k = 0;
/*       */       
/*       */       Object localObject3;
/*  9200 */       if ((paramObject instanceof CHAR[]))
/*       */       {
/*  9202 */         localObject3 = (CHAR[])paramObject;
/*  9203 */         k = localObject3.length;
/*       */         
/*  9205 */         localObject2 = new String[k];
/*       */         
/*  9207 */         for (int n = 0; n < k; n++)
/*       */         {
/*  9209 */           Object localObject5 = localObject3[n];
/*  9210 */           if (localObject5 != null) {
/*  9211 */             localObject2[n] = ((CHAR)localObject5).getString();
/*       */           }
/*       */         }
/*  9214 */       } else if ((paramObject instanceof String[]))
/*       */       {
/*  9216 */         localObject2 = (String[])paramObject;
/*  9217 */         k = localObject2.length;
/*       */       }
/*       */       else {
/*  9220 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*  9221 */         ((SQLException)localObject3).fillInStackTrace();
/*  9222 */         throw ((Throwable)localObject3);
/*       */       }
/*       */       
/*       */ 
/*  9226 */       if ((paramInt5 == 0) && (localObject2 != null)) {
/*  9227 */         for (int m = 0; m < k; m++)
/*       */         {
/*  9229 */           Object localObject4 = localObject2[m];
/*  9230 */           if ((localObject4 != null) && (paramInt5 < ((String)localObject4).length()))
/*  9231 */             paramInt5 = ((String)localObject4).length();
/*       */         }
/*       */       }
/*  9234 */       localObject1 = localObject2;
/*       */       
/*  9236 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2: 
/*       */     case 6: 
/*  9243 */       localObject1 = OracleTypeNUMBER.toNUMBERArray(paramObject, this.connection, 1L, paramInt3);
/*       */       
/*       */ 
/*  9246 */       if ((paramInt5 == 0) && (localObject1 != null))
/*       */       {
/*  9248 */         paramInt5 = 22;
/*       */       }
/*       */       
/*  9251 */       this.currentRowCharLens[i] = 0;
/*       */       
/*  9253 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     default: 
/*  9272 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*  9273 */       ((SQLException)localObject2).fillInStackTrace();
/*  9274 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */     
/*  9278 */     if ((localObject1.length == 0) && (paramInt2 == 0))
/*       */     {
/*  9280 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 272);
/*  9281 */       ((SQLException)localObject2).fillInStackTrace();
/*  9282 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*  9285 */     this.currentRowBinders[i] = this.thePlsqlIbtBinder;
/*       */     
/*  9287 */     if (this.parameterPlsqlIbt == null) {
/*  9288 */       this.parameterPlsqlIbt = new PlsqlIbtBindInfo[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*  9291 */     this.parameterPlsqlIbt[this.currentRank][i] = new PlsqlIbtBindInfo((Object[])localObject1, paramInt2, paramInt3, j, paramInt5);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9298 */     this.hasIbtBind = true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setPlsqlIndexTableAtName(String paramString, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*       */     throws SQLException
/*       */   {
/*  9321 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*  9325 */       String str = paramString.intern();
/*  9326 */       String[] arrayOfString = this.sqlObject.getParameterList();
/*  9327 */       int i = 0;
/*  9328 */       int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */       
/*  9330 */       for (int k = 0; k < j; k++) {
/*  9331 */         if (arrayOfString[k] == str)
/*       */         {
/*  9333 */           setPlsqlIndexTableInternal(k + 1, paramObject, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */           
/*       */ 
/*  9336 */           i = 1;
/*       */         }
/*       */       }
/*  9339 */       if (i == 0)
/*       */       {
/*  9341 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  9342 */         localSQLException.fillInStackTrace();
/*  9343 */         throw localSQLException;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void endOfResultSet(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9365 */     if (!paramBoolean)
/*       */     {
/*       */ 
/*       */ 
/*  9369 */       prepareForNewResults(false, false); }
/*  9370 */     this.rowPrefetchInLastFetch = -1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int sqlTypeForObject(Object paramObject)
/*       */   {
/*  9382 */     if (paramObject == null)
/*       */     {
/*  9384 */       return 0;
/*       */     }
/*       */     
/*  9387 */     if (!(paramObject instanceof Datum))
/*       */     {
/*  9389 */       if ((paramObject instanceof String))
/*       */       {
/*       */ 
/*  9392 */         return this.fixedString ? 999 : 12;
/*       */       }
/*  9394 */       if ((paramObject instanceof BigDecimal)) {
/*  9395 */         return 2;
/*       */       }
/*  9397 */       if ((paramObject instanceof BigInteger)) {
/*  9398 */         return 2;
/*       */       }
/*  9400 */       if ((paramObject instanceof Boolean)) {
/*  9401 */         return -7;
/*       */       }
/*  9403 */       if ((paramObject instanceof Integer)) {
/*  9404 */         return 4;
/*       */       }
/*  9406 */       if ((paramObject instanceof Long)) {
/*  9407 */         return -5;
/*       */       }
/*  9409 */       if ((paramObject instanceof Float)) {
/*  9410 */         return 7;
/*       */       }
/*  9412 */       if ((paramObject instanceof Double)) {
/*  9413 */         return 8;
/*       */       }
/*  9415 */       if ((paramObject instanceof byte[])) {
/*  9416 */         return -3;
/*       */       }
/*       */       
/*       */ 
/*  9420 */       if ((paramObject instanceof Short)) {
/*  9421 */         return 5;
/*       */       }
/*  9423 */       if ((paramObject instanceof Byte)) {
/*  9424 */         return -6;
/*       */       }
/*  9426 */       if ((paramObject instanceof Date)) {
/*  9427 */         return 91;
/*       */       }
/*  9429 */       if ((paramObject instanceof Time)) {
/*  9430 */         return 92;
/*       */       }
/*  9432 */       if ((paramObject instanceof Timestamp)) {
/*  9433 */         return 93;
/*       */       }
/*  9435 */       if ((paramObject instanceof SQLData)) {
/*  9436 */         return 2002;
/*       */       }
/*  9438 */       if ((paramObject instanceof ObjectData)) {
/*  9439 */         return 2002;
/*       */       }
/*       */     }
/*       */     else {
/*  9443 */       if ((paramObject instanceof BINARY_FLOAT)) {
/*  9444 */         return 100;
/*       */       }
/*  9446 */       if ((paramObject instanceof BINARY_DOUBLE)) {
/*  9447 */         return 101;
/*       */       }
/*  9449 */       if ((paramObject instanceof BLOB)) {
/*  9450 */         return 2004;
/*       */       }
/*  9452 */       if ((paramObject instanceof CLOB)) {
/*  9453 */         return 2005;
/*       */       }
/*  9455 */       if ((paramObject instanceof BFILE)) {
/*  9456 */         return -13;
/*       */       }
/*  9458 */       if ((paramObject instanceof ROWID)) {
/*  9459 */         return -8;
/*       */       }
/*  9461 */       if ((paramObject instanceof NUMBER)) {
/*  9462 */         return 2;
/*       */       }
/*  9464 */       if ((paramObject instanceof DATE)) {
/*  9465 */         return 91;
/*       */       }
/*  9467 */       if ((paramObject instanceof TIMESTAMP)) {
/*  9468 */         return 93;
/*       */       }
/*  9470 */       if ((paramObject instanceof TIMESTAMPTZ)) {
/*  9471 */         return -101;
/*       */       }
/*  9473 */       if ((paramObject instanceof TIMESTAMPLTZ)) {
/*  9474 */         return -102;
/*       */       }
/*  9476 */       if ((paramObject instanceof REF)) {
/*  9477 */         return 2006;
/*       */       }
/*  9479 */       if ((paramObject instanceof CHAR)) {
/*  9480 */         return 1;
/*       */       }
/*  9482 */       if ((paramObject instanceof RAW)) {
/*  9483 */         return -2;
/*       */       }
/*  9485 */       if ((paramObject instanceof ARRAY)) {
/*  9486 */         return 2003;
/*       */       }
/*  9488 */       if ((paramObject instanceof STRUCT)) {
/*  9489 */         return 2002;
/*       */       }
/*  9491 */       if ((paramObject instanceof OPAQUE)) {
/*  9492 */         return 2007;
/*       */       }
/*  9494 */       if ((paramObject instanceof INTERVALYM)) {
/*  9495 */         return -103;
/*       */       }
/*  9497 */       if ((paramObject instanceof INTERVALDS)) {
/*  9498 */         return -104;
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  9505 */     return 1111;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void clearParameters()
/*       */     throws SQLException
/*       */   {
/*  9518 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9524 */       this.clearParameters = true;
/*       */       
/*  9526 */       for (int i = 0; i < this.numberOfBindPositions; i++) {
/*  9527 */         this.currentRowBinders[i] = null;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void printByteArray(byte[] paramArrayOfByte)
/*       */   {
/*  9538 */     if (paramArrayOfByte != null)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9545 */       int j = paramArrayOfByte.length;
/*       */       
/*  9547 */       for (int i = 0; i < j; i++)
/*       */       {
/*  9549 */         int k = paramArrayOfByte[i] & 0xFF;
/*       */         
/*  9551 */         if (k >= 16) {}
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  9598 */     setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  9607 */     setCharacterStreamInternal(paramInt1, paramReader, paramInt2, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9615 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  9617 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  9619 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9620 */       localSQLException.fillInStackTrace();
/*  9621 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  9627 */     set_execute_batch(1);
/*  9628 */     checkUserStreamForDuplicates(paramReader, i);
/*  9629 */     if (paramReader == null)
/*       */     {
/*  9631 */       basicBindNullString(paramInt);
/*       */     } else {
/*  9633 */       if ((this.userRsetType != 1) && ((paramLong > this.maxVcsCharsSql) || (!paramBoolean)))
/*       */       {
/*       */ 
/*       */ 
/*  9637 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  9638 */         localSQLException.fillInStackTrace();
/*  9639 */         throw localSQLException;
/*       */       }
/*       */       
/*  9642 */       if (!paramBoolean)
/*       */       {
/*  9644 */         setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */ 
/*       */       }
/*  9647 */       else if (this.currentRowFormOfUse[i] == 1)
/*       */       {
/*  9649 */         if (this.sqlKind.isPlsqlOrCall())
/*       */         {
/*  9651 */           if ((paramLong > this.maxVcsBytesPlsql) || ((paramLong > this.maxVcsCharsPlsql) && (this.isServerCharSetFixedWidth)))
/*       */           {
/*       */ 
/*       */ 
/*  9655 */             setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */ 
/*       */           }
/*  9658 */           else if ((paramLong <= this.maxVcsCharsPlsql) && (!this.connection.retainV9BindBehavior))
/*       */           {
/*       */ 
/*  9661 */             setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */ 
/*       */ 
/*       */           }
/*       */           else
/*       */           {
/*       */ 
/*       */ 
/*  9669 */             setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, false);
/*       */ 
/*       */ 
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */         }
/*  9677 */         else if ((paramLong <= this.maxVcsCharsSql) && (!this.connection.retainV9BindBehavior))
/*       */         {
/*  9679 */           setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */ 
/*       */         }
/*  9682 */         else if (paramLong > 2147483647L)
/*       */         {
/*  9684 */           setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/*  9689 */           basicBindCharacterStream(paramInt, paramReader, (int)paramLong, false);
/*       */ 
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  9695 */       else if (this.sqlKind.isPlsqlOrCall())
/*       */       {
/*  9697 */         if ((paramLong > this.maxVcsBytesPlsql) || ((paramLong > this.maxVcsNCharsPlsql) && (this.isServerCharSetFixedWidth)))
/*       */         {
/*       */ 
/*       */ 
/*  9701 */           setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */ 
/*       */         }
/*  9704 */         else if ((paramLong <= this.maxVcsNCharsPlsql) && (!this.connection.retainV9BindBehavior))
/*       */         {
/*       */ 
/*  9707 */           setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/*  9712 */           setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, true);
/*       */ 
/*       */ 
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */       }
/*  9720 */       else if ((paramLong <= this.maxVcsNCharsSql) && (!this.connection.retainV9BindBehavior))
/*       */       {
/*  9722 */         setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  9727 */         setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void basicBindCharacterStream(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9740 */     synchronized (this.connection)
/*       */     {
/*  9742 */       int i = paramInt1 - 1;
/*       */       
/*  9744 */       if (paramBoolean)
/*       */       {
/*  9746 */         this.currentRowBinders[i] = this.theLongStreamForStringBinder;
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  9751 */         this.currentRowBinders[i] = this.theLongStreamBinder;
/*       */       }
/*       */       
/*  9754 */       if (this.parameterStream == null) {
/*  9755 */         this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  9758 */       this.parameterStream[this.currentRank][i] = (paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]) : this.connection.conversion.ConvertStream(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]));
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9767 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setReaderContentsForStringOrClobInVariableWidthCase(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9787 */     Object localObject = new char[paramInt2];
/*  9788 */     int i = 0;
/*  9789 */     int j = paramInt2;
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  9796 */       while ((j > 0) && ((k = paramReader.read((char[])localObject, i, j)) != -1))
/*       */       {
/*  9798 */         i += k;
/*  9799 */         j -= k;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  9805 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  9806 */       localSQLException.fillInStackTrace();
/*  9807 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  9811 */     if (i != paramInt2)
/*       */     {
/*  9813 */       char[] arrayOfChar = new char[i];
/*       */       
/*  9815 */       System.arraycopy(localObject, 0, arrayOfChar, 0, i);
/*       */       
/*  9817 */       localObject = arrayOfChar;
/*       */     }
/*  9819 */     int m = this.connection.conversion.encodedByteLength((char[])localObject, paramBoolean);
/*       */     
/*  9821 */     if ((m < this.maxVcsBytesPlsql) && (!this.connection.retainV9BindBehavior))
/*       */     {
/*       */ 
/*  9824 */       setStringInternal(paramInt1, new String((char[])localObject));
/*       */     }
/*       */     else
/*       */     {
/*  9828 */       setStringForClobCritical(paramInt1, new String((char[])localObject));
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setReaderContentsForStringInternal(int paramInt1, Reader paramReader, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  9838 */     Object localObject = new char[paramInt2];
/*  9839 */     int i = 0;
/*  9840 */     int j = paramInt2;
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  9847 */       while ((j > 0) && ((k = paramReader.read((char[])localObject, i, j)) != -1))
/*       */       {
/*  9849 */         i += k;
/*  9850 */         j -= k;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  9856 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  9857 */       localSQLException.fillInStackTrace();
/*  9858 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  9862 */     if (i != paramInt2)
/*       */     {
/*  9864 */       char[] arrayOfChar = new char[i];
/*       */       
/*  9866 */       System.arraycopy(localObject, 0, arrayOfChar, 0, i);
/*       */       
/*  9868 */       localObject = arrayOfChar;
/*       */     }
/*  9870 */     setStringInternal(paramInt1, new String((char[])localObject));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9888 */     setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setDateInternal(int paramInt, Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9896 */     setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9913 */     setDATEInternal(paramInt, paramTime == null ? null : new DATE(paramTime, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTimeInternal(int paramInt, Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9921 */     setDATEInternal(paramInt, paramTime == null ? null : new DATE(paramTime, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9938 */     setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9946 */     setTIMESTAMPInternal(paramInt, paramTimestamp == null ? null : new TIMESTAMP(paramTimestamp, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCheckBindTypes(boolean paramBoolean)
/*       */   {
/*  9963 */     this.checkBindTypes = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9992 */   int m_batchStyle = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   final void setOracleBatchStyle()
/*       */     throws SQLException
/*       */   {
/* 10003 */     if (this.m_batchStyle == 2)
/*       */     {
/*       */ 
/* 10006 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
/* 10007 */       localSQLException.fillInStackTrace();
/* 10008 */       throw localSQLException;
/*       */     }
/*       */     
/* 10011 */     if (this.m_batchStyle == 0) {}
/*       */     
/*       */ 
/*       */ 
/*       */ 
/* 10016 */     this.m_batchStyle = 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   boolean isOracleBatchStyle()
/*       */   {
/* 10023 */     return this.m_batchStyle == 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   final void setJdbcBatchStyle()
/*       */     throws SQLException
/*       */   {
/* 10036 */     if (this.m_batchStyle == 1)
/*       */     {
/*       */ 
/* 10039 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
/* 10040 */       localSQLException.fillInStackTrace();
/* 10041 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/* 10045 */     this.m_batchStyle = 2;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   final void checkIfJdbcBatchExists()
/*       */     throws SQLException
/*       */   {
/* 10061 */     if (doesJdbcBatchExist())
/*       */     {
/*       */ 
/* 10064 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/* 10065 */       localSQLException.fillInStackTrace();
/* 10066 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean doesJdbcBatchExist()
/*       */   {
/* 10075 */     if ((this.currentRank > 0) && (this.m_batchStyle == 2)) {
/* 10076 */       return true;
/*       */     }
/* 10078 */     return false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   boolean isJdbcBatchStyle()
/*       */   {
/* 10085 */     return this.m_batchStyle == 2;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void addBatch()
/*       */     throws SQLException
/*       */   {
/* 10106 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10121 */       setJdbcBatchStyle();
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10131 */       processCompletedBindRow(this.currentRank + 2, (this.currentRank > 0) && (this.sqlKind.isPlsqlOrCall()));
/*       */       
/*       */ 
/*       */ 
/* 10135 */       this.currentRank += 1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public void addBatch(String paramString)
/*       */     throws SQLException
/*       */   {
/* 10145 */     synchronized (this.connection)
/*       */     {
/*       */ 
/* 10148 */       SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10149 */       localSQLException.fillInStackTrace();
/* 10150 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void clearBatch()
/*       */     throws SQLException
/*       */   {
/* 10169 */     synchronized (this.connection)
/*       */     {
/* 10171 */       for (int i = this.currentRank - 1; i >= 0; i--) {
/* 10172 */         for (int j = 0; j < this.numberOfBindPositions; j++)
/* 10173 */           this.binders[i][j] = null;
/*       */       }
/* 10175 */       this.currentRank = 0;
/*       */       
/* 10177 */       if (this.binders != null) {
/* 10178 */         this.currentRowBinders = this.binders[0];
/*       */       }
/* 10180 */       this.pushedBatches = null;
/* 10181 */       this.pushedBatchesTail = null;
/* 10182 */       this.firstRowInBatch = 0;
/*       */       
/* 10184 */       this.clearParameters = true;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void executeForRowsWithTimeout(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/* 10197 */     if (this.queryTimeout > 0)
/*       */     {
/*       */       try
/*       */       {
/* 10201 */         this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/* 10202 */         this.cancelLock.enterExecuting();
/* 10203 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally
/*       */       {
/* 10207 */         this.connection.getTimeout().cancelTimeout();
/* 10208 */         this.cancelLock.exitExecuting();
/*       */       }
/*       */       
/*       */     }
/*       */     else {
/*       */       try
/*       */       {
/* 10215 */         this.cancelLock.enterExecuting();
/* 10216 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally
/*       */       {
/* 10220 */         this.cancelLock.exitExecuting();
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int[] executeBatch()
/*       */     throws SQLException
/*       */   {
/* 10247 */     synchronized (this.connection)
/*       */     {
/*       */ 
/* 10250 */       int[] arrayOfInt = new int[this.currentRank];
/* 10251 */       this.checkSum = 0L;
/* 10252 */       this.checkSumComputationFailure = false;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10258 */       int i = 0;
/*       */       
/* 10260 */       cleanOldTempLobs();
/* 10261 */       setJdbcBatchStyle();
/*       */       
/* 10263 */       if (this.currentRank > 0)
/*       */       {
/*       */ 
/*       */ 
/* 10267 */         ensureOpen();
/*       */         
/*       */ 
/* 10270 */         prepareForNewResults(true, true);
/*       */         
/* 10272 */         if (this.sqlKind.isSELECT())
/*       */         {
/*       */ 
/* 10275 */           BatchUpdateException localBatchUpdateException1 = DatabaseError.createBatchUpdateException(80, 0, null);
/* 10276 */           localBatchUpdateException1.fillInStackTrace();
/* 10277 */           throw localBatchUpdateException1;
/*       */         }
/*       */         
/*       */ 
/*       */ 
/* 10282 */         this.noMoreUpdateCounts = false;
/*       */         
/* 10284 */         int j = 0;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         try
/*       */         {
/* 10296 */           this.connection.registerHeartbeat();
/*       */           
/* 10298 */           this.connection.needLine();
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10304 */           if (!this.isOpen)
/*       */           {
/* 10306 */             this.connection.open(this);
/*       */             
/* 10308 */             this.isOpen = true;
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/* 10314 */           int k = this.currentRank;
/*       */           
/* 10316 */           if (this.pushedBatches == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/* 10321 */             setupBindBuffers(0, this.currentRank);
/* 10322 */             executeForRowsWithTimeout(false);
/*       */ 
/*       */ 
/*       */           }
/*       */           else
/*       */           {
/*       */ 
/*       */ 
/* 10330 */             if (this.currentRank > this.firstRowInBatch)
/*       */             {
/*       */ 
/*       */ 
/* 10334 */               pushBatch(true);
/*       */             }
/* 10336 */             boolean bool = this.needToParse;
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             do
/*       */             {
/* 10344 */               localObject1 = this.pushedBatches;
/*       */               
/* 10346 */               this.currentBatchCharLens = ((PushedBatch)localObject1).currentBatchCharLens;
/* 10347 */               this.lastBoundCharLens = ((PushedBatch)localObject1).lastBoundCharLens;
/* 10348 */               this.lastBoundNeeded = ((PushedBatch)localObject1).lastBoundNeeded;
/* 10349 */               this.currentBatchBindAccessors = ((PushedBatch)localObject1).currentBatchBindAccessors;
/* 10350 */               this.needToParse = ((PushedBatch)localObject1).need_to_parse;
/* 10351 */               this.currentBatchNeedToPrepareBinds = ((PushedBatch)localObject1).current_batch_need_to_prepare_binds;
/*       */               
/* 10353 */               this.firstRowInBatch = ((PushedBatch)localObject1).first_row_in_batch;
/*       */               
/* 10355 */               setupBindBuffers(((PushedBatch)localObject1).first_row_in_batch, ((PushedBatch)localObject1).number_of_rows_to_be_bound);
/*       */               
/*       */ 
/*       */ 
/*       */ 
/* 10360 */               this.currentRank = ((PushedBatch)localObject1).number_of_rows_to_be_bound;
/*       */               
/* 10362 */               executeForRowsWithTimeout(false);
/*       */               
/* 10364 */               j += this.validRows;
/* 10365 */               if (this.sqlKind.isPlsqlOrCall())
/*       */               {
/* 10367 */                 arrayOfInt[(i++)] = this.validRows;
/*       */               }
/*       */               
/* 10370 */               this.pushedBatches = ((PushedBatch)localObject1).next;
/*       */ 
/*       */             }
/* 10373 */             while (this.pushedBatches != null);
/*       */             
/*       */ 
/* 10376 */             this.pushedBatchesTail = null;
/* 10377 */             this.firstRowInBatch = 0;
/*       */             
/* 10379 */             this.needToParse = bool;
/*       */           }
/*       */           
/*       */ 
/*       */ 
/* 10384 */           slideDownCurrentRow(k);
/*       */ 
/*       */ 
/*       */         }
/*       */         catch (SQLException localSQLException)
/*       */         {
/*       */ 
/*       */ 
/* 10392 */           int m = this.currentRank;
/* 10393 */           clearBatch();
/* 10394 */           this.needToParse = true;
/*       */           
/* 10396 */           if (!this.sqlKind.isPlsqlOrCall())
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/* 10401 */             if ((this.numberOfExecutedElementsInBatch != -1) && (this.numberOfExecutedElementsInBatch != m))
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/* 10406 */               arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 10407 */               for (i = 0; i < this.numberOfExecutedElementsInBatch;) {
/* 10408 */                 arrayOfInt[i] = -2;i++; continue;
/*       */                 
/*       */ 
/* 10411 */                 for (i = 0; i < arrayOfInt.length; i++)
/* 10412 */                   arrayOfInt[i] = -3;
/*       */               } } }
/* 10414 */           resetCurrentRowBinders();
/*       */           
/*       */ 
/* 10417 */           Object localObject1 = DatabaseError.createBatchUpdateException(localSQLException, this.sqlKind.isPlsqlOrCall() ? i : arrayOfInt.length, arrayOfInt);
/* 10418 */           ((BatchUpdateException)localObject1).fillInStackTrace();
/* 10419 */           throw ((Throwable)localObject1);
/*       */ 
/*       */         }
/*       */         finally
/*       */         {
/* 10424 */           if ((this.sqlKind.isPlsqlOrCall()) || (j > this.validRows)) {
/* 10425 */             this.validRows = j;
/*       */           }
/* 10427 */           checkValidRowsStatus();
/*       */           
/* 10429 */           this.currentRank = 0;
/*       */         }
/*       */         
/* 10432 */         if (this.validRows < 0)
/*       */         {
/* 10434 */           for (i = 0; i < arrayOfInt.length; i++) {
/* 10435 */             arrayOfInt[i] = -3;
/*       */           }
/*       */           
/* 10438 */           BatchUpdateException localBatchUpdateException2 = DatabaseError.createBatchUpdateException(81, 0, arrayOfInt);
/* 10439 */           localBatchUpdateException2.fillInStackTrace();
/* 10440 */           throw localBatchUpdateException2;
/*       */         }
/*       */         
/* 10443 */         if (!this.sqlKind.isPlsqlOrCall())
/*       */         {
/* 10445 */           for (i = 0; i < arrayOfInt.length; i++) {
/* 10446 */             arrayOfInt[i] = -2;
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/* 10454 */       this.connection.registerHeartbeat();
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10460 */       return arrayOfInt;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void pushBatch(boolean paramBoolean)
/*       */   {
/* 10468 */     PushedBatch localPushedBatch = new PushedBatch();
/*       */     
/* 10470 */     localPushedBatch.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10472 */     System.arraycopy(this.currentBatchCharLens, 0, localPushedBatch.currentBatchCharLens, 0, this.numberOfBindPositions);
/*       */     
/*       */ 
/* 10475 */     localPushedBatch.lastBoundCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10477 */     System.arraycopy(this.lastBoundCharLens, 0, localPushedBatch.lastBoundCharLens, 0, this.numberOfBindPositions);
/*       */     
/*       */ 
/* 10480 */     if (this.currentBatchBindAccessors != null)
/*       */     {
/* 10482 */       localPushedBatch.currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */       
/* 10484 */       System.arraycopy(this.currentBatchBindAccessors, 0, localPushedBatch.currentBatchBindAccessors, 0, this.numberOfBindPositions);
/*       */     }
/*       */     
/*       */ 
/* 10488 */     localPushedBatch.lastBoundNeeded = this.lastBoundNeeded;
/* 10489 */     localPushedBatch.need_to_parse = this.needToParse;
/* 10490 */     localPushedBatch.current_batch_need_to_prepare_binds = this.currentBatchNeedToPrepareBinds;
/* 10491 */     localPushedBatch.first_row_in_batch = this.firstRowInBatch;
/* 10492 */     localPushedBatch.number_of_rows_to_be_bound = (this.currentRank - this.firstRowInBatch);
/*       */     
/* 10494 */     if (this.pushedBatches == null) {
/* 10495 */       this.pushedBatches = localPushedBatch;
/*       */     } else {
/* 10497 */       this.pushedBatchesTail.next = localPushedBatch;
/*       */     }
/* 10499 */     this.pushedBatchesTail = localPushedBatch;
/*       */     
/* 10501 */     if (!paramBoolean)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10507 */       int[] arrayOfInt = this.currentBatchCharLens;
/*       */       
/* 10509 */       this.currentBatchCharLens = this.lastBoundCharLens;
/* 10510 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/* 10512 */       this.lastBoundNeeded = false;
/*       */       
/* 10514 */       for (int i = 0; i < this.numberOfBindPositions; i++) {
/* 10515 */         this.currentBatchCharLens[i] = 0;
/*       */       }
/* 10517 */       this.firstRowInBatch = this.currentRank;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int doScrollPstmtExecuteUpdate()
/*       */     throws SQLException
/*       */   {
/* 10531 */     doScrollExecuteCommon();
/*       */     
/* 10533 */     if (this.sqlKind.isSELECT()) {
/* 10534 */       this.scrollRsetTypeSolved = true;
/*       */     }
/* 10536 */     return this.validRows;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int copyBinds(Statement paramStatement, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 10551 */     if (this.numberOfBindPositions > 0)
/*       */     {
/* 10553 */       OraclePreparedStatement localOraclePreparedStatement = (OraclePreparedStatement)paramStatement;
/*       */       
/* 10555 */       int i = this.bindIndicatorSubRange + 5;
/*       */       
/* 10557 */       int j = this.bindByteSubRange;
/* 10558 */       int k = this.bindCharSubRange;
/* 10559 */       int m = this.indicatorsOffset;
/* 10560 */       int n = this.valueLengthsOffset;
/*       */       
/* 10562 */       for (int i1 = 0; i1 < this.numberOfBindPositions; i1++)
/*       */       {
/* 10564 */         short s = this.bindIndicators[(i + 0)];
/*       */         
/* 10566 */         int i2 = this.bindIndicators[(i + 1)];
/*       */         
/* 10568 */         int i3 = this.bindIndicators[(i + 2)];
/*       */         
/*       */ 
/* 10571 */         int i4 = i1 + paramInt;
/*       */         
/*       */ 
/*       */ 
/* 10575 */         if (localOraclePreparedStatement.parameterDatum == null) {
/* 10576 */           localOraclePreparedStatement.parameterDatum = new byte[localOraclePreparedStatement.numberOfBindRowsAllocated][localOraclePreparedStatement.numberOfBindPositions][];
/*       */         }
/*       */         
/* 10579 */         if (localOraclePreparedStatement.parameterOtype == null) {
/* 10580 */           localOraclePreparedStatement.parameterOtype = new OracleTypeADT[localOraclePreparedStatement.numberOfBindRowsAllocated][localOraclePreparedStatement.numberOfBindPositions];
/*       */         }
/*       */         
/* 10583 */         if (this.bindIndicators[m] == -1)
/*       */         {
/* 10585 */           localOraclePreparedStatement.currentRowBinders[i4] = copiedNullBinder(s, i2);
/*       */           
/* 10587 */           if (i3 > 0)
/* 10588 */             localOraclePreparedStatement.currentRowCharLens[i4] = 1;
/*       */         } else { Object localObject;
/* 10590 */           if ((s == 109) || (s == 111))
/*       */           {
/* 10592 */             localOraclePreparedStatement.currentRowBinders[i4] = (s == 109 ? this.theNamedTypeBinder : this.theRefTypeBinder);
/*       */             
/*       */ 
/*       */ 
/*       */ 
/* 10597 */             localObject = this.parameterDatum[0][i1];
/* 10598 */             int i5 = localObject.length;
/* 10599 */             byte[] arrayOfByte = new byte[i5];
/*       */             
/* 10601 */             localOraclePreparedStatement.parameterDatum[0][i4] = arrayOfByte;
/*       */             
/* 10603 */             System.arraycopy(localObject, 0, arrayOfByte, 0, i5);
/*       */             
/* 10605 */             localOraclePreparedStatement.parameterOtype[0][i4] = this.parameterOtype[0][i1];
/*       */           }
/* 10607 */           else if (i2 > 0)
/*       */           {
/* 10609 */             localOraclePreparedStatement.currentRowBinders[i4] = copiedByteBinder(s, this.bindBytes, j, i2, this.bindIndicators[n]);
/*       */ 
/*       */           }
/* 10612 */           else if (i3 > 0)
/*       */           {
/* 10614 */             localOraclePreparedStatement.currentRowBinders[i4] = copiedCharBinder(s, this.bindChars, k, i3, this.bindIndicators[n], getInoutIndicator(i1));
/*       */             
/* 10616 */             localOraclePreparedStatement.currentRowCharLens[i4] = i3;
/*       */           }
/*       */           else
/*       */           {
/* 10620 */             localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "copyBinds doesn't understand type " + s);
/* 10621 */             ((SQLException)localObject).fillInStackTrace();
/* 10622 */             throw ((Throwable)localObject);
/*       */           }
/*       */         }
/* 10625 */         j += this.bindBufferCapacity * i2;
/* 10626 */         k += this.bindBufferCapacity * i3;
/* 10627 */         m += this.numberOfBindRowsAllocated;
/* 10628 */         n += this.numberOfBindRowsAllocated;
/* 10629 */         i += 10;
/*       */       }
/*       */     }
/*       */     
/* 10633 */     return this.numberOfBindPositions;
/*       */   }
/*       */   
/*       */ 
/*       */   Binder copiedNullBinder(short paramShort, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 10640 */     return new CopiedNullBinder(paramShort, paramInt);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   Binder copiedByteBinder(short paramShort1, byte[] paramArrayOfByte, int paramInt1, int paramInt2, short paramShort2)
/*       */     throws SQLException
/*       */   {
/* 10648 */     byte[] arrayOfByte = new byte[paramInt2];
/*       */     
/* 10650 */     System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 0, paramInt2);
/*       */     
/* 10652 */     return new CopiedByteBinder(paramShort1, paramInt2, arrayOfByte, paramShort2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   Binder copiedCharBinder(short paramShort1, char[] paramArrayOfChar, int paramInt1, int paramInt2, short paramShort2, short paramShort3)
/*       */     throws SQLException
/*       */   {
/* 10660 */     char[] arrayOfChar = new char[paramInt2];
/*       */     
/* 10662 */     System.arraycopy(paramArrayOfChar, paramInt1, arrayOfChar, 0, paramInt2);
/*       */     
/* 10664 */     return new CopiedCharBinder(paramShort1, arrayOfChar, paramShort2, paramShort3);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   protected void hardClose()
/*       */     throws SQLException
/*       */   {
/* 10672 */     super.hardClose();
/*       */     
/* 10674 */     this.connection.cacheBuffer(this.bindBytes);
/* 10675 */     this.bindBytes = null;
/* 10676 */     this.connection.cacheBuffer(this.bindChars);
/* 10677 */     this.bindChars = null;
/* 10678 */     this.bindIndicators = null;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/* 10683 */     if (!this.connection.isClosed())
/*       */     {
/* 10685 */       cleanAllTempLobs();
/*       */     }
/*       */     
/* 10688 */     this.lastBoundBytes = null;
/* 10689 */     this.lastBoundChars = null;
/*       */     
/* 10691 */     clearParameters();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   protected void alwaysOnClose()
/*       */     throws SQLException
/*       */   {
/* 10703 */     if (this.currentRank > 0)
/*       */     {
/* 10705 */       if (this.m_batchStyle == 2) {
/* 10706 */         clearBatch();
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*       */ 
/* 10712 */         int i = this.validRows;
/*       */         
/* 10714 */         this.prematureBatchCount = sendBatch();
/* 10715 */         this.validRows = i;
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10730 */     if (this.sqlKind.isSELECT()) {
/* 10731 */       Object localObject = this.children;
/*       */       
/* 10733 */       while (localObject != null) {
/* 10734 */         OracleStatement localOracleStatement = ((OracleStatement)localObject).nextChild;
/*       */         
/*       */ 
/* 10737 */         if (((OracleStatement)localObject).serverCursor) {
/* 10738 */           ((OracleStatement)localObject).cursorId = 0;
/*       */         }
/* 10740 */         localObject = localOracleStatement;
/*       */       }
/*       */     }
/*       */     
/* 10744 */     super.alwaysOnClose();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDisableStmtCaching(boolean paramBoolean)
/*       */   {
/* 10757 */     synchronized (this.connection)
/*       */     {
/* 10759 */       if (paramBoolean == true) {
/* 10760 */         this.cacheState = 3;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFormOfUse(int paramInt, short paramShort)
/*       */   {
/* 10770 */     synchronized (this.connection)
/*       */     {
/*       */ 
/* 10773 */       int i = paramInt - 1;
/*       */       
/* 10775 */       if (this.currentRowFormOfUse[i] != paramShort)
/*       */       {
/* 10777 */         this.currentRowFormOfUse[i] = paramShort;
/*       */         
/*       */         Accessor localAccessor;
/*       */         
/* 10781 */         if (this.currentRowBindAccessors != null)
/*       */         {
/* 10783 */           localAccessor = this.currentRowBindAccessors[i];
/*       */           
/* 10785 */           if (localAccessor != null) {
/* 10786 */             localAccessor.setFormOfUse(paramShort);
/*       */           }
/*       */         }
/*       */         
/* 10790 */         if (this.returnParamAccessors != null)
/*       */         {
/* 10792 */           localAccessor = this.returnParamAccessors[i];
/*       */           
/* 10794 */           if (localAccessor != null) {
/* 10795 */             localAccessor.setFormOfUse(paramShort);
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setURL(int paramInt, URL paramURL)
/*       */     throws SQLException
/*       */   {
/* 10822 */     setURLInternal(paramInt, paramURL);
/*       */   }
/*       */   
/*       */ 
/*       */   void setURLInternal(int paramInt, URL paramURL)
/*       */     throws SQLException
/*       */   {
/* 10829 */     setStringInternal(paramInt, paramURL.toString());
/*       */   }
/*       */   
/*       */ 
/*       */   public ParameterMetaData getParameterMetaData()
/*       */     throws SQLException
/*       */   {
/* 10836 */     return new OracleParameterMetaData(this.sqlObject.getParameterCount());
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public oracle.jdbc.OracleParameterMetaData OracleGetParameterMetaData()
/*       */     throws SQLException
/*       */   {
/* 10859 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10860 */     localSQLException.fillInStackTrace();
/* 10861 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException1;
/*       */     
/* 10871 */     if (this.numberOfBindPositions <= 0)
/*       */     {
/* 10873 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10874 */       localSQLException1.fillInStackTrace();
/* 10875 */       throw localSQLException1;
/*       */     }
/*       */     
/* 10878 */     if (this.numReturnParams <= 0)
/*       */     {
/* 10880 */       this.numReturnParams = this.sqlObject.getReturnParameterCount();
/* 10881 */       if (this.numReturnParams <= 0)
/*       */       {
/* 10883 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10884 */         localSQLException1.fillInStackTrace();
/* 10885 */         throw localSQLException1;
/*       */       }
/*       */     }
/*       */     
/* 10889 */     int i = paramInt1 - 1;
/* 10890 */     if ((i < this.numberOfBindPositions - this.numReturnParams) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*       */ 
/* 10893 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10894 */       localSQLException2.fillInStackTrace();
/* 10895 */       throw localSQLException2;
/*       */     }
/*       */     
/* 10898 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10900 */     short s = 0;
/* 10901 */     if ((this.currentRowFormOfUse != null) && (this.currentRowFormOfUse[i] != 0)) {
/* 10902 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10904 */     registerReturnParameterInternal(i, j, paramInt2, -1, s, null);
/*       */     
/*       */ 
/* 10907 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/* 10918 */     if (this.numberOfBindPositions <= 0)
/*       */     {
/* 10920 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10921 */       localSQLException1.fillInStackTrace();
/* 10922 */       throw localSQLException1;
/*       */     }
/*       */     
/* 10925 */     int i = paramInt1 - 1;
/* 10926 */     SQLException localSQLException2; if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/* 10928 */       localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10929 */       localSQLException2.fillInStackTrace();
/* 10930 */       throw localSQLException2;
/*       */     }
/*       */     
/* 10933 */     if ((paramInt2 != 1) && (paramInt2 != 12) && (paramInt2 != -1) && (paramInt2 != -2) && (paramInt2 != -3) && (paramInt2 != -4) && (paramInt2 != 12))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10942 */       localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10943 */       localSQLException2.fillInStackTrace();
/* 10944 */       throw localSQLException2;
/*       */     }
/*       */     
/*       */ 
/* 10948 */     if (paramInt3 <= 0)
/*       */     {
/*       */ 
/* 10951 */       localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10952 */       localSQLException2.fillInStackTrace();
/* 10953 */       throw localSQLException2;
/*       */     }
/*       */     
/*       */ 
/* 10957 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10959 */     short s = 0;
/* 10960 */     if ((this.currentRowFormOfUse != null) && (this.currentRowFormOfUse[i] != 0)) {
/* 10961 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10963 */     registerReturnParameterInternal(i, j, paramInt2, paramInt3, s, null);
/*       */     
/*       */ 
/* 10966 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/* 10977 */     if (this.numberOfBindPositions <= 0)
/*       */     {
/* 10979 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10980 */       localSQLException1.fillInStackTrace();
/* 10981 */       throw localSQLException1;
/*       */     }
/*       */     
/* 10984 */     int i = paramInt1 - 1;
/* 10985 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/* 10987 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10988 */       localSQLException2.fillInStackTrace();
/* 10989 */       throw localSQLException2;
/*       */     }
/*       */     
/* 10992 */     int j = getInternalTypeForDmlReturning(paramInt2);
/* 10993 */     if ((j != 111) && (j != 109))
/*       */     {
/*       */ 
/*       */ 
/* 10997 */       SQLException localSQLException3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10998 */       localSQLException3.fillInStackTrace();
/* 10999 */       throw localSQLException3;
/*       */     }
/*       */     
/*       */ 
/* 11003 */     registerReturnParameterInternal(i, j, paramInt2, -1, (short)0, paramString);
/*       */     
/*       */ 
/* 11006 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */   
/*       */ 
/*       */   public ResultSet getReturnResultSet()
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException;
/* 11014 */     if (this.closed)
/*       */     {
/* 11016 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 11017 */       localSQLException.fillInStackTrace();
/* 11018 */       throw localSQLException;
/*       */     }
/*       */     
/* 11021 */     if ((this.returnParamAccessors == null) || (this.numReturnParams == 0))
/*       */     {
/* 11023 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 11024 */       localSQLException.fillInStackTrace();
/* 11025 */       throw localSQLException;
/*       */     }
/*       */     
/* 11028 */     if ((this.returnResultSet == null) || (this.numReturnParams == 0) || (!this.isOpen))
/*       */     {
/*       */ 
/*       */ 
/* 11032 */       this.returnResultSet = new OracleReturnResultSet(this);
/*       */     }
/*       */     
/* 11035 */     return this.returnResultSet;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int getInternalTypeForDmlReturning(int paramInt)
/*       */     throws SQLException
/*       */   {
/* 11049 */     int i = 0;
/*       */     
/* 11051 */     switch (paramInt)
/*       */     {
/*       */     case -7: 
/*       */     case -6: 
/*       */     case -5: 
/*       */     case 2: 
/*       */     case 3: 
/*       */     case 4: 
/*       */     case 5: 
/*       */     case 6: 
/*       */     case 7: 
/*       */     case 8: 
/* 11063 */       i = 6;
/* 11064 */       break;
/*       */     
/*       */     case 100: 
/* 11067 */       i = 100;
/* 11068 */       break;
/*       */     
/*       */     case 101: 
/* 11071 */       i = 101;
/* 11072 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 1: 
/* 11078 */       i = 96;
/* 11079 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 12: 
/* 11085 */       i = 1;
/* 11086 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case -1: 
/* 11092 */       i = 8;
/* 11093 */       break;
/*       */     
/*       */     case 91: 
/*       */     case 92: 
/* 11097 */       i = 12;
/* 11098 */       break;
/*       */     
/*       */     case 93: 
/* 11101 */       i = 180;
/* 11102 */       break;
/*       */     
/*       */     case -101: 
/* 11105 */       i = 181;
/* 11106 */       break;
/*       */     
/*       */     case -102: 
/* 11109 */       i = 231;
/* 11110 */       break;
/*       */     
/*       */     case -103: 
/* 11113 */       i = 182;
/* 11114 */       break;
/*       */     
/*       */     case -104: 
/* 11117 */       i = 183;
/* 11118 */       break;
/*       */     
/*       */     case -3: 
/*       */     case -2: 
/* 11122 */       i = 23;
/* 11123 */       break;
/*       */     
/*       */     case -4: 
/* 11126 */       i = 24;
/* 11127 */       break;
/*       */     
/*       */     case -8: 
/* 11130 */       i = 104;
/* 11131 */       break;
/*       */     
/*       */     case 2004: 
/* 11134 */       i = 113;
/* 11135 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2005: 
/* 11141 */       i = 112;
/* 11142 */       break;
/*       */     
/*       */     case -13: 
/* 11145 */       i = 114;
/* 11146 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2002: 
/*       */     case 2003: 
/*       */     case 2007: 
/*       */     case 2008: 
/* 11155 */       i = 109;
/* 11156 */       break;
/*       */     
/*       */     case 2006: 
/* 11159 */       i = 111;
/* 11160 */       break;
/*       */     
/*       */     case 70: 
/* 11163 */       i = 1;
/* 11164 */       break;
/*       */     
/*       */ 
/*       */     default: 
/* 11168 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 11169 */       localSQLException.fillInStackTrace();
/* 11170 */       throw localSQLException;
/*       */     }
/*       */     
/*       */     
/*       */ 
/* 11175 */     return i;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void registerReturnParamsForAutoKey()
/*       */     throws SQLException
/*       */   {
/* 11183 */     int[] arrayOfInt1 = this.autoKeyInfo.returnTypes;
/* 11184 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 11185 */     int[] arrayOfInt2 = this.autoKeyInfo.columnIndexes;
/*       */     
/* 11187 */     int i = arrayOfInt1.length;
/*       */     
/*       */ 
/* 11190 */     int j = this.numberOfBindPositions - i;
/*       */     
/*       */ 
/* 11193 */     for (int k = 0; k < i; k++)
/*       */     {
/* 11195 */       int m = j + k;
/* 11196 */       this.currentRowBinders[m] = this.theReturnParamBinder;
/*       */       
/* 11198 */       short s = this.connection.defaultnchar ? 2 : 1;
/*       */       
/*       */ 
/* 11201 */       if ((arrayOfShort != null) && (arrayOfInt2 != null))
/*       */       {
/* 11203 */         if (arrayOfShort[(arrayOfInt2[k] - 1)] == 2)
/*       */         {
/*       */ 
/* 11206 */           s = 2;
/* 11207 */           setFormOfUse(m + 1, s);
/*       */         }
/*       */       }
/*       */       
/* 11211 */       checkTypeForAutoKey(arrayOfInt1[k]);
/*       */       
/* 11213 */       String str = null;
/* 11214 */       if (arrayOfInt1[k] == 111) {
/* 11215 */         str = this.autoKeyInfo.tableTypeNames[(arrayOfInt2[k] - 1)];
/*       */       }
/* 11217 */       registerReturnParameterInternal(m, arrayOfInt1[k], arrayOfInt1[k], -1, s, str);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void cleanOldTempLobs()
/*       */   {
/* 11227 */     if ((this.m_batchStyle != 1) || (this.currentRank == this.batch - 1))
/*       */     {
/* 11229 */       super.cleanOldTempLobs();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void resetOnExceptionDuringExecute()
/*       */   {
/* 11236 */     super.resetOnExceptionDuringExecute();
/* 11237 */     this.currentRank = 0;
/* 11238 */     this.currentBatchNeedToPrepareBinds = true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void resetCurrentRowBinders()
/*       */   {
/* 11247 */     Binder[] arrayOfBinder = this.currentRowBinders;
/* 11248 */     if ((this.binders != null) && (this.currentRowBinders != null) && (arrayOfBinder != this.binders[0]))
/*       */     {
/*       */ 
/*       */ 
/* 11252 */       this.currentRowBinders = this.binders[0];
/* 11253 */       this.binders[this.numberOfBoundRows] = arrayOfBinder;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setArrayAtName(String paramString, Array paramArray)
/*       */     throws SQLException
/*       */   {
/* 11283 */     String str = paramString.intern();
/* 11284 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11285 */     int i = 0;
/* 11286 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11288 */     for (int k = 0; k < j; k++) {
/* 11289 */       if (arrayOfString[k] == str)
/*       */       {
/* 11291 */         setArray(k + 1, paramArray);
/*       */         
/* 11293 */         i = 1;
/*       */       }
/*       */     }
/* 11296 */     if (i == 0)
/*       */     {
/* 11298 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11299 */       localSQLException.fillInStackTrace();
/* 11300 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal)
/*       */     throws SQLException
/*       */   {
/* 11320 */     String str = paramString.intern();
/* 11321 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11322 */     int i = 0;
/* 11323 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11325 */     for (int k = 0; k < j; k++) {
/* 11326 */       if (arrayOfString[k] == str)
/*       */       {
/* 11328 */         setBigDecimal(k + 1, paramBigDecimal);
/*       */         
/* 11330 */         i = 1;
/*       */       }
/*       */     }
/* 11333 */     if (i == 0)
/*       */     {
/* 11335 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11336 */       localSQLException.fillInStackTrace();
/* 11337 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlobAtName(String paramString, Blob paramBlob)
/*       */     throws SQLException
/*       */   {
/* 11357 */     String str = paramString.intern();
/* 11358 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11359 */     int i = 0;
/* 11360 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11362 */     for (int k = 0; k < j; k++) {
/* 11363 */       if (arrayOfString[k] == str)
/*       */       {
/* 11365 */         setBlob(k + 1, paramBlob);
/*       */         
/* 11367 */         i = 1;
/*       */       }
/*       */     }
/* 11370 */     if (i == 0)
/*       */     {
/* 11372 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11373 */       localSQLException.fillInStackTrace();
/* 11374 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBooleanAtName(String paramString, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/* 11394 */     String str = paramString.intern();
/* 11395 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11396 */     int i = 0;
/* 11397 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11399 */     for (int k = 0; k < j; k++) {
/* 11400 */       if (arrayOfString[k] == str)
/*       */       {
/* 11402 */         setBoolean(k + 1, paramBoolean);
/*       */         
/* 11404 */         i = 1;
/*       */       }
/*       */     }
/* 11407 */     if (i == 0)
/*       */     {
/* 11409 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11410 */       localSQLException.fillInStackTrace();
/* 11411 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setByteAtName(String paramString, byte paramByte)
/*       */     throws SQLException
/*       */   {
/* 11431 */     String str = paramString.intern();
/* 11432 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11433 */     int i = 0;
/* 11434 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11436 */     for (int k = 0; k < j; k++) {
/* 11437 */       if (arrayOfString[k] == str)
/*       */       {
/* 11439 */         setByte(k + 1, paramByte);
/*       */         
/* 11441 */         i = 1;
/*       */       }
/*       */     }
/* 11444 */     if (i == 0)
/*       */     {
/* 11446 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11447 */       localSQLException.fillInStackTrace();
/* 11448 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytesAtName(String paramString, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/* 11468 */     String str = paramString.intern();
/* 11469 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11470 */     int i = 0;
/* 11471 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11473 */     for (int k = 0; k < j; k++) {
/* 11474 */       if (arrayOfString[k] == str)
/*       */       {
/* 11476 */         setBytes(k + 1, paramArrayOfByte);
/*       */         
/* 11478 */         i = 1;
/*       */       }
/*       */     }
/* 11481 */     if (i == 0)
/*       */     {
/* 11483 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11484 */       localSQLException.fillInStackTrace();
/* 11485 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClobAtName(String paramString, Clob paramClob)
/*       */     throws SQLException
/*       */   {
/* 11505 */     String str = paramString.intern();
/* 11506 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11507 */     int i = 0;
/* 11508 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11510 */     for (int k = 0; k < j; k++) {
/* 11511 */       if (arrayOfString[k] == str)
/*       */       {
/* 11513 */         setClob(k + 1, paramClob);
/*       */         
/* 11515 */         i = 1;
/*       */       }
/*       */     }
/* 11518 */     if (i == 0)
/*       */     {
/* 11520 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11521 */       localSQLException.fillInStackTrace();
/* 11522 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDateAtName(String paramString, Date paramDate)
/*       */     throws SQLException
/*       */   {
/* 11542 */     String str = paramString.intern();
/* 11543 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11544 */     int i = 0;
/* 11545 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11547 */     for (int k = 0; k < j; k++) {
/* 11548 */       if (arrayOfString[k] == str)
/*       */       {
/* 11550 */         setDate(k + 1, paramDate);
/*       */         
/* 11552 */         i = 1;
/*       */       }
/*       */     }
/* 11555 */     if (i == 0)
/*       */     {
/* 11557 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11558 */       localSQLException.fillInStackTrace();
/* 11559 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/* 11579 */     String str = paramString.intern();
/* 11580 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11581 */     int i = 0;
/* 11582 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11584 */     for (int k = 0; k < j; k++) {
/* 11585 */       if (arrayOfString[k] == str)
/*       */       {
/* 11587 */         setDate(k + 1, paramDate, paramCalendar);
/*       */         
/* 11589 */         i = 1;
/*       */       }
/*       */     }
/* 11592 */     if (i == 0)
/*       */     {
/* 11594 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11595 */       localSQLException.fillInStackTrace();
/* 11596 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDoubleAtName(String paramString, double paramDouble)
/*       */     throws SQLException
/*       */   {
/* 11616 */     String str = paramString.intern();
/* 11617 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11618 */     int i = 0;
/* 11619 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11621 */     for (int k = 0; k < j; k++) {
/* 11622 */       if (arrayOfString[k] == str)
/*       */       {
/* 11624 */         setDouble(k + 1, paramDouble);
/*       */         
/* 11626 */         i = 1;
/*       */       }
/*       */     }
/* 11629 */     if (i == 0)
/*       */     {
/* 11631 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11632 */       localSQLException.fillInStackTrace();
/* 11633 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFloatAtName(String paramString, float paramFloat)
/*       */     throws SQLException
/*       */   {
/* 11653 */     String str = paramString.intern();
/* 11654 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11655 */     int i = 0;
/* 11656 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11658 */     for (int k = 0; k < j; k++) {
/* 11659 */       if (arrayOfString[k] == str)
/*       */       {
/* 11661 */         setFloat(k + 1, paramFloat);
/*       */         
/* 11663 */         i = 1;
/*       */       }
/*       */     }
/* 11666 */     if (i == 0)
/*       */     {
/* 11668 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11669 */       localSQLException.fillInStackTrace();
/* 11670 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setIntAtName(String paramString, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 11690 */     String str = paramString.intern();
/* 11691 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11692 */     int i = 0;
/* 11693 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11695 */     for (int k = 0; k < j; k++) {
/* 11696 */       if (arrayOfString[k] == str)
/*       */       {
/* 11698 */         setInt(k + 1, paramInt);
/*       */         
/* 11700 */         i = 1;
/*       */       }
/*       */     }
/* 11703 */     if (i == 0)
/*       */     {
/* 11705 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11706 */       localSQLException.fillInStackTrace();
/* 11707 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setLongAtName(String paramString, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11727 */     String str = paramString.intern();
/* 11728 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11729 */     int i = 0;
/* 11730 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11732 */     for (int k = 0; k < j; k++) {
/* 11733 */       if (arrayOfString[k] == str)
/*       */       {
/* 11735 */         setLong(k + 1, paramLong);
/*       */         
/* 11737 */         i = 1;
/*       */       }
/*       */     }
/* 11740 */     if (i == 0)
/*       */     {
/* 11742 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11743 */       localSQLException.fillInStackTrace();
/* 11744 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObjectAtName(String paramString, Object paramObject)
/*       */     throws SQLException
/*       */   {
/* 11764 */     String str = paramString.intern();
/* 11765 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11766 */     int i = 0;
/* 11767 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11769 */     for (int k = 0; k < j; k++) {
/* 11770 */       if (arrayOfString[k] == str)
/*       */       {
/* 11772 */         setObject(k + 1, paramObject);
/*       */         
/* 11774 */         i = 1;
/*       */       }
/*       */     }
/* 11777 */     if (i == 0)
/*       */     {
/* 11779 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11780 */       localSQLException.fillInStackTrace();
/* 11781 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 11801 */     String str = paramString.intern();
/* 11802 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11803 */     int i = 0;
/* 11804 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11806 */     for (int k = 0; k < j; k++) {
/* 11807 */       if (arrayOfString[k] == str)
/*       */       {
/* 11809 */         setObject(k + 1, paramObject, paramInt);
/*       */         
/* 11811 */         i = 1;
/*       */       }
/*       */     }
/* 11814 */     if (i == 0)
/*       */     {
/* 11816 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11817 */       localSQLException.fillInStackTrace();
/* 11818 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRefAtName(String paramString, Ref paramRef)
/*       */     throws SQLException
/*       */   {
/* 11838 */     String str = paramString.intern();
/* 11839 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11840 */     int i = 0;
/* 11841 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11843 */     for (int k = 0; k < j; k++) {
/* 11844 */       if (arrayOfString[k] == str)
/*       */       {
/* 11846 */         setRef(k + 1, paramRef);
/*       */         
/* 11848 */         i = 1;
/*       */       }
/*       */     }
/* 11851 */     if (i == 0)
/*       */     {
/* 11853 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11854 */       localSQLException.fillInStackTrace();
/* 11855 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setShortAtName(String paramString, short paramShort)
/*       */     throws SQLException
/*       */   {
/* 11875 */     String str = paramString.intern();
/* 11876 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11877 */     int i = 0;
/* 11878 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11880 */     for (int k = 0; k < j; k++) {
/* 11881 */       if (arrayOfString[k] == str)
/*       */       {
/* 11883 */         setShort(k + 1, paramShort);
/*       */         
/* 11885 */         i = 1;
/*       */       }
/*       */     }
/* 11888 */     if (i == 0)
/*       */     {
/* 11890 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11891 */       localSQLException.fillInStackTrace();
/* 11892 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStringAtName(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/* 11912 */     String str = paramString1.intern();
/* 11913 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11914 */     int i = 0;
/* 11915 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11917 */     for (int k = 0; k < j; k++) {
/* 11918 */       if (arrayOfString[k] == str)
/*       */       {
/* 11920 */         setString(k + 1, paramString2);
/*       */         
/* 11922 */         i = 1;
/*       */       }
/*       */     }
/* 11925 */     if (i == 0)
/*       */     {
/* 11927 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 11928 */       localSQLException.fillInStackTrace();
/* 11929 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimeAtName(String paramString, Time paramTime)
/*       */     throws SQLException
/*       */   {
/* 11949 */     String str = paramString.intern();
/* 11950 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11951 */     int i = 0;
/* 11952 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11954 */     for (int k = 0; k < j; k++) {
/* 11955 */       if (arrayOfString[k] == str)
/*       */       {
/* 11957 */         setTime(k + 1, paramTime);
/*       */         
/* 11959 */         i = 1;
/*       */       }
/*       */     }
/* 11962 */     if (i == 0)
/*       */     {
/* 11964 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11965 */       localSQLException.fillInStackTrace();
/* 11966 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/* 11986 */     String str = paramString.intern();
/* 11987 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11988 */     int i = 0;
/* 11989 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11991 */     for (int k = 0; k < j; k++) {
/* 11992 */       if (arrayOfString[k] == str)
/*       */       {
/* 11994 */         setTime(k + 1, paramTime, paramCalendar);
/*       */         
/* 11996 */         i = 1;
/*       */       }
/*       */     }
/* 11999 */     if (i == 0)
/*       */     {
/* 12001 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12002 */       localSQLException.fillInStackTrace();
/* 12003 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/* 12023 */     String str = paramString.intern();
/* 12024 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12025 */     int i = 0;
/* 12026 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12028 */     for (int k = 0; k < j; k++) {
/* 12029 */       if (arrayOfString[k] == str)
/*       */       {
/* 12031 */         setTimestamp(k + 1, paramTimestamp);
/*       */         
/* 12033 */         i = 1;
/*       */       }
/*       */     }
/* 12036 */     if (i == 0)
/*       */     {
/* 12038 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12039 */       localSQLException.fillInStackTrace();
/* 12040 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/* 12060 */     String str = paramString.intern();
/* 12061 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12062 */     int i = 0;
/* 12063 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12065 */     for (int k = 0; k < j; k++) {
/* 12066 */       if (arrayOfString[k] == str)
/*       */       {
/* 12068 */         setTimestamp(k + 1, paramTimestamp, paramCalendar);
/*       */         
/* 12070 */         i = 1;
/*       */       }
/*       */     }
/* 12073 */     if (i == 0)
/*       */     {
/* 12075 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12076 */       localSQLException.fillInStackTrace();
/* 12077 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setURLAtName(String paramString, URL paramURL)
/*       */     throws SQLException
/*       */   {
/* 12097 */     String str = paramString.intern();
/* 12098 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12099 */     int i = 0;
/* 12100 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12102 */     for (int k = 0; k < j; k++) {
/* 12103 */       if (arrayOfString[k] == str)
/*       */       {
/* 12105 */         setURL(k + 1, paramURL);
/*       */         
/* 12107 */         i = 1;
/*       */       }
/*       */     }
/* 12110 */     if (i == 0)
/*       */     {
/* 12112 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12113 */       localSQLException.fillInStackTrace();
/* 12114 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setARRAYAtName(String paramString, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/* 12134 */     String str = paramString.intern();
/* 12135 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12136 */     int i = 0;
/* 12137 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12139 */     for (int k = 0; k < j; k++) {
/* 12140 */       if (arrayOfString[k] == str)
/*       */       {
/* 12142 */         setARRAY(k + 1, paramARRAY);
/*       */         
/* 12144 */         i = 1;
/*       */       }
/*       */     }
/* 12147 */     if (i == 0)
/*       */     {
/* 12149 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12150 */       localSQLException.fillInStackTrace();
/* 12151 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBFILEAtName(String paramString, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/* 12171 */     String str = paramString.intern();
/* 12172 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12173 */     int i = 0;
/* 12174 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12176 */     for (int k = 0; k < j; k++) {
/* 12177 */       if (arrayOfString[k] == str)
/*       */       {
/* 12179 */         setBFILE(k + 1, paramBFILE);
/*       */         
/* 12181 */         i = 1;
/*       */       }
/*       */     }
/* 12184 */     if (i == 0)
/*       */     {
/* 12186 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12187 */       localSQLException.fillInStackTrace();
/* 12188 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBfileAtName(String paramString, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/* 12208 */     String str = paramString.intern();
/* 12209 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12210 */     int i = 0;
/* 12211 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12213 */     for (int k = 0; k < j; k++) {
/* 12214 */       if (arrayOfString[k] == str)
/*       */       {
/* 12216 */         setBfile(k + 1, paramBFILE);
/*       */         
/* 12218 */         i = 1;
/*       */       }
/*       */     }
/* 12221 */     if (i == 0)
/*       */     {
/* 12223 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12224 */       localSQLException.fillInStackTrace();
/* 12225 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryFloatAtName(String paramString, float paramFloat)
/*       */     throws SQLException
/*       */   {
/* 12245 */     String str = paramString.intern();
/* 12246 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12247 */     int i = 0;
/* 12248 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12250 */     for (int k = 0; k < j; k++) {
/* 12251 */       if (arrayOfString[k] == str)
/*       */       {
/* 12253 */         setBinaryFloat(k + 1, paramFloat);
/*       */         
/* 12255 */         i = 1;
/*       */       }
/*       */     }
/* 12258 */     if (i == 0)
/*       */     {
/* 12260 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12261 */       localSQLException.fillInStackTrace();
/* 12262 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT)
/*       */     throws SQLException
/*       */   {
/* 12282 */     String str = paramString.intern();
/* 12283 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12284 */     int i = 0;
/* 12285 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12287 */     for (int k = 0; k < j; k++) {
/* 12288 */       if (arrayOfString[k] == str)
/*       */       {
/* 12290 */         setBinaryFloat(k + 1, paramBINARY_FLOAT);
/*       */         
/* 12292 */         i = 1;
/*       */       }
/*       */     }
/* 12295 */     if (i == 0)
/*       */     {
/* 12297 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12298 */       localSQLException.fillInStackTrace();
/* 12299 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDoubleAtName(String paramString, double paramDouble)
/*       */     throws SQLException
/*       */   {
/* 12319 */     String str = paramString.intern();
/* 12320 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12321 */     int i = 0;
/* 12322 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12324 */     for (int k = 0; k < j; k++) {
/* 12325 */       if (arrayOfString[k] == str)
/*       */       {
/* 12327 */         setBinaryDouble(k + 1, paramDouble);
/*       */         
/* 12329 */         i = 1;
/*       */       }
/*       */     }
/* 12332 */     if (i == 0)
/*       */     {
/* 12334 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12335 */       localSQLException.fillInStackTrace();
/* 12336 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE)
/*       */     throws SQLException
/*       */   {
/* 12356 */     String str = paramString.intern();
/* 12357 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12358 */     int i = 0;
/* 12359 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12361 */     for (int k = 0; k < j; k++) {
/* 12362 */       if (arrayOfString[k] == str)
/*       */       {
/* 12364 */         setBinaryDouble(k + 1, paramBINARY_DOUBLE);
/*       */         
/* 12366 */         i = 1;
/*       */       }
/*       */     }
/* 12369 */     if (i == 0)
/*       */     {
/* 12371 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12372 */       localSQLException.fillInStackTrace();
/* 12373 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBLOBAtName(String paramString, BLOB paramBLOB)
/*       */     throws SQLException
/*       */   {
/* 12393 */     String str = paramString.intern();
/* 12394 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12395 */     int i = 0;
/* 12396 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12398 */     for (int k = 0; k < j; k++) {
/* 12399 */       if (arrayOfString[k] == str)
/*       */       {
/* 12401 */         setBLOB(k + 1, paramBLOB);
/*       */         
/* 12403 */         i = 1;
/*       */       }
/*       */     }
/* 12406 */     if (i == 0)
/*       */     {
/* 12408 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12409 */       localSQLException.fillInStackTrace();
/* 12410 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCHARAtName(String paramString, CHAR paramCHAR)
/*       */     throws SQLException
/*       */   {
/* 12430 */     String str = paramString.intern();
/* 12431 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12432 */     int i = 0;
/* 12433 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12435 */     for (int k = 0; k < j; k++) {
/* 12436 */       if (arrayOfString[k] == str)
/*       */       {
/* 12438 */         setCHAR(k + 1, paramCHAR);
/*       */         
/* 12440 */         i = 1;
/*       */       }
/*       */     }
/* 12443 */     if (i == 0)
/*       */     {
/* 12445 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12446 */       localSQLException.fillInStackTrace();
/* 12447 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCLOBAtName(String paramString, CLOB paramCLOB)
/*       */     throws SQLException
/*       */   {
/* 12467 */     String str = paramString.intern();
/* 12468 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12469 */     int i = 0;
/* 12470 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12472 */     for (int k = 0; k < j; k++) {
/* 12473 */       if (arrayOfString[k] == str)
/*       */       {
/* 12475 */         setCLOB(k + 1, paramCLOB);
/*       */         
/* 12477 */         i = 1;
/*       */       }
/*       */     }
/* 12480 */     if (i == 0)
/*       */     {
/* 12482 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12483 */       localSQLException.fillInStackTrace();
/* 12484 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCursorAtName(String paramString, ResultSet paramResultSet)
/*       */     throws SQLException
/*       */   {
/* 12504 */     String str = paramString.intern();
/* 12505 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12506 */     int i = 0;
/* 12507 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12509 */     for (int k = 0; k < j; k++) {
/* 12510 */       if (arrayOfString[k] == str)
/*       */       {
/* 12512 */         setCursor(k + 1, paramResultSet);
/*       */         
/* 12514 */         i = 1;
/*       */       }
/*       */     }
/* 12517 */     if (i == 0)
/*       */     {
/* 12519 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12520 */       localSQLException.fillInStackTrace();
/* 12521 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum)
/*       */     throws SQLException
/*       */   {
/* 12541 */     String str = paramString.intern();
/* 12542 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12543 */     int i = 0;
/* 12544 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12546 */     for (int k = 0; k < j; k++) {
/* 12547 */       if (arrayOfString[k] == str)
/*       */       {
/* 12549 */         setCustomDatum(k + 1, paramCustomDatum);
/*       */         
/* 12551 */         i = 1;
/*       */       }
/*       */     }
/* 12554 */     if (i == 0)
/*       */     {
/* 12556 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12557 */       localSQLException.fillInStackTrace();
/* 12558 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDATEAtName(String paramString, DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/* 12578 */     String str = paramString.intern();
/* 12579 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12580 */     int i = 0;
/* 12581 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12583 */     for (int k = 0; k < j; k++) {
/* 12584 */       if (arrayOfString[k] == str)
/*       */       {
/* 12586 */         setDATE(k + 1, paramDATE);
/*       */         
/* 12588 */         i = 1;
/*       */       }
/*       */     }
/* 12591 */     if (i == 0)
/*       */     {
/* 12593 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12594 */       localSQLException.fillInStackTrace();
/* 12595 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFixedCHARAtName(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/* 12615 */     String str = paramString1.intern();
/* 12616 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12617 */     int i = 0;
/* 12618 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12620 */     for (int k = 0; k < j; k++) {
/* 12621 */       if (arrayOfString[k] == str)
/*       */       {
/* 12623 */         setFixedCHAR(k + 1, paramString2);
/*       */         
/* 12625 */         i = 1;
/*       */       }
/*       */     }
/* 12628 */     if (i == 0)
/*       */     {
/* 12630 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12631 */       localSQLException.fillInStackTrace();
/* 12632 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS)
/*       */     throws SQLException
/*       */   {
/* 12652 */     String str = paramString.intern();
/* 12653 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12654 */     int i = 0;
/* 12655 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12657 */     for (int k = 0; k < j; k++) {
/* 12658 */       if (arrayOfString[k] == str)
/*       */       {
/* 12660 */         setINTERVALDS(k + 1, paramINTERVALDS);
/*       */         
/* 12662 */         i = 1;
/*       */       }
/*       */     }
/* 12665 */     if (i == 0)
/*       */     {
/* 12667 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12668 */       localSQLException.fillInStackTrace();
/* 12669 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM)
/*       */     throws SQLException
/*       */   {
/* 12689 */     String str = paramString.intern();
/* 12690 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12691 */     int i = 0;
/* 12692 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12694 */     for (int k = 0; k < j; k++) {
/* 12695 */       if (arrayOfString[k] == str)
/*       */       {
/* 12697 */         setINTERVALYM(k + 1, paramINTERVALYM);
/*       */         
/* 12699 */         i = 1;
/*       */       }
/*       */     }
/* 12702 */     if (i == 0)
/*       */     {
/* 12704 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12705 */       localSQLException.fillInStackTrace();
/* 12706 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER)
/*       */     throws SQLException
/*       */   {
/* 12726 */     String str = paramString.intern();
/* 12727 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12728 */     int i = 0;
/* 12729 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12731 */     for (int k = 0; k < j; k++) {
/* 12732 */       if (arrayOfString[k] == str)
/*       */       {
/* 12734 */         setNUMBER(k + 1, paramNUMBER);
/*       */         
/* 12736 */         i = 1;
/*       */       }
/*       */     }
/* 12739 */     if (i == 0)
/*       */     {
/* 12741 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12742 */       localSQLException.fillInStackTrace();
/* 12743 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/* 12763 */     String str = paramString.intern();
/* 12764 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12765 */     int i = 0;
/* 12766 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12768 */     for (int k = 0; k < j; k++) {
/* 12769 */       if (arrayOfString[k] == str)
/*       */       {
/* 12771 */         setOPAQUE(k + 1, paramOPAQUE);
/*       */         
/* 12773 */         i = 1;
/*       */       }
/*       */     }
/* 12776 */     if (i == 0)
/*       */     {
/* 12778 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12779 */       localSQLException.fillInStackTrace();
/* 12780 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOracleObjectAtName(String paramString, Datum paramDatum)
/*       */     throws SQLException
/*       */   {
/* 12800 */     String str = paramString.intern();
/* 12801 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12802 */     int i = 0;
/* 12803 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12805 */     for (int k = 0; k < j; k++) {
/* 12806 */       if (arrayOfString[k] == str)
/*       */       {
/* 12808 */         setOracleObject(k + 1, paramDatum);
/*       */         
/* 12810 */         i = 1;
/*       */       }
/*       */     }
/* 12813 */     if (i == 0)
/*       */     {
/* 12815 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12816 */       localSQLException.fillInStackTrace();
/* 12817 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setORADataAtName(String paramString, ORAData paramORAData)
/*       */     throws SQLException
/*       */   {
/* 12837 */     String str = paramString.intern();
/* 12838 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12839 */     int i = 0;
/* 12840 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12842 */     for (int k = 0; k < j; k++) {
/* 12843 */       if (arrayOfString[k] == str)
/*       */       {
/* 12845 */         setORAData(k + 1, paramORAData);
/*       */         
/* 12847 */         i = 1;
/*       */       }
/*       */     }
/* 12850 */     if (i == 0)
/*       */     {
/* 12852 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12853 */       localSQLException.fillInStackTrace();
/* 12854 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRAWAtName(String paramString, RAW paramRAW)
/*       */     throws SQLException
/*       */   {
/* 12874 */     String str = paramString.intern();
/* 12875 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12876 */     int i = 0;
/* 12877 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12879 */     for (int k = 0; k < j; k++) {
/* 12880 */       if (arrayOfString[k] == str)
/*       */       {
/* 12882 */         setRAW(k + 1, paramRAW);
/*       */         
/* 12884 */         i = 1;
/*       */       }
/*       */     }
/* 12887 */     if (i == 0)
/*       */     {
/* 12889 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12890 */       localSQLException.fillInStackTrace();
/* 12891 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setREFAtName(String paramString, REF paramREF)
/*       */     throws SQLException
/*       */   {
/* 12911 */     String str = paramString.intern();
/* 12912 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12913 */     int i = 0;
/* 12914 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12916 */     for (int k = 0; k < j; k++) {
/* 12917 */       if (arrayOfString[k] == str)
/*       */       {
/* 12919 */         setREF(k + 1, paramREF);
/*       */         
/* 12921 */         i = 1;
/*       */       }
/*       */     }
/* 12924 */     if (i == 0)
/*       */     {
/* 12926 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12927 */       localSQLException.fillInStackTrace();
/* 12928 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRefTypeAtName(String paramString, REF paramREF)
/*       */     throws SQLException
/*       */   {
/* 12948 */     String str = paramString.intern();
/* 12949 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12950 */     int i = 0;
/* 12951 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12953 */     for (int k = 0; k < j; k++) {
/* 12954 */       if (arrayOfString[k] == str)
/*       */       {
/* 12956 */         setRefType(k + 1, paramREF);
/*       */         
/* 12958 */         i = 1;
/*       */       }
/*       */     }
/* 12961 */     if (i == 0)
/*       */     {
/* 12963 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12964 */       localSQLException.fillInStackTrace();
/* 12965 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setROWIDAtName(String paramString, ROWID paramROWID)
/*       */     throws SQLException
/*       */   {
/* 12985 */     String str = paramString.intern();
/* 12986 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12987 */     int i = 0;
/* 12988 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12990 */     for (int k = 0; k < j; k++) {
/* 12991 */       if (arrayOfString[k] == str)
/*       */       {
/* 12993 */         setROWID(k + 1, paramROWID);
/*       */         
/* 12995 */         i = 1;
/*       */       }
/*       */     }
/* 12998 */     if (i == 0)
/*       */     {
/* 13000 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13001 */       localSQLException.fillInStackTrace();
/* 13002 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/* 13022 */     String str = paramString.intern();
/* 13023 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13024 */     int i = 0;
/* 13025 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13027 */     for (int k = 0; k < j; k++) {
/* 13028 */       if (arrayOfString[k] == str)
/*       */       {
/* 13030 */         setSTRUCT(k + 1, paramSTRUCT);
/*       */         
/* 13032 */         i = 1;
/*       */       }
/*       */     }
/* 13035 */     if (i == 0)
/*       */     {
/* 13037 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13038 */       localSQLException.fillInStackTrace();
/* 13039 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*       */     throws SQLException
/*       */   {
/* 13059 */     String str = paramString.intern();
/* 13060 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13061 */     int i = 0;
/* 13062 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13064 */     for (int k = 0; k < j; k++) {
/* 13065 */       if (arrayOfString[k] == str)
/*       */       {
/* 13067 */         setTIMESTAMPLTZ(k + 1, paramTIMESTAMPLTZ);
/*       */         
/* 13069 */         i = 1;
/*       */       }
/*       */     }
/* 13072 */     if (i == 0)
/*       */     {
/* 13074 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13075 */       localSQLException.fillInStackTrace();
/* 13076 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ)
/*       */     throws SQLException
/*       */   {
/* 13096 */     String str = paramString.intern();
/* 13097 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13098 */     int i = 0;
/* 13099 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13101 */     for (int k = 0; k < j; k++) {
/* 13102 */       if (arrayOfString[k] == str)
/*       */       {
/* 13104 */         setTIMESTAMPTZ(k + 1, paramTIMESTAMPTZ);
/*       */         
/* 13106 */         i = 1;
/*       */       }
/*       */     }
/* 13109 */     if (i == 0)
/*       */     {
/* 13111 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13112 */       localSQLException.fillInStackTrace();
/* 13113 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP)
/*       */     throws SQLException
/*       */   {
/* 13133 */     String str = paramString.intern();
/* 13134 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13135 */     int i = 0;
/* 13136 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13138 */     for (int k = 0; k < j; k++) {
/* 13139 */       if (arrayOfString[k] == str)
/*       */       {
/* 13141 */         setTIMESTAMP(k + 1, paramTIMESTAMP);
/*       */         
/* 13143 */         i = 1;
/*       */       }
/*       */     }
/* 13146 */     if (i == 0)
/*       */     {
/* 13148 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13149 */       localSQLException.fillInStackTrace();
/* 13150 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 13172 */     String str = paramString.intern();
/* 13173 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13174 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13175 */     int j = 1;
/*       */     
/* 13177 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13179 */       if (arrayOfString[k] == str)
/*       */       {
/* 13181 */         if (j != 0)
/*       */         {
/* 13183 */           setAsciiStream(k + 1, paramInputStream, paramInt);
/*       */           
/* 13185 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13190 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13191 */           localSQLException2.fillInStackTrace();
/* 13192 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13197 */     if (j != 0)
/*       */     {
/* 13199 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13200 */       localSQLException1.fillInStackTrace();
/* 13201 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 13221 */     String str = paramString.intern();
/* 13222 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13223 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13224 */     int j = 1;
/*       */     
/* 13226 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13228 */       if (arrayOfString[k] == str)
/*       */       {
/* 13230 */         if (j != 0)
/*       */         {
/* 13232 */           setBinaryStream(k + 1, paramInputStream, paramInt);
/*       */           
/* 13234 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13239 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13240 */           localSQLException2.fillInStackTrace();
/* 13241 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13246 */     if (j != 0)
/*       */     {
/* 13248 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13249 */       localSQLException1.fillInStackTrace();
/* 13250 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 13270 */     String str = paramString.intern();
/* 13271 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13272 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13273 */     int j = 1;
/*       */     
/* 13275 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13277 */       if (arrayOfString[k] == str)
/*       */       {
/* 13279 */         if (j != 0)
/*       */         {
/* 13281 */           setCharacterStream(k + 1, paramReader, paramInt);
/*       */           
/* 13283 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13288 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13289 */           localSQLException2.fillInStackTrace();
/* 13290 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13295 */     if (j != 0)
/*       */     {
/* 13297 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13298 */       localSQLException1.fillInStackTrace();
/* 13299 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 13319 */     String str = paramString.intern();
/* 13320 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13321 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13322 */     int j = 1;
/*       */     
/* 13324 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13326 */       if (arrayOfString[k] == str)
/*       */       {
/* 13328 */         if (j != 0)
/*       */         {
/* 13330 */           setUnicodeStream(k + 1, paramInputStream, paramInt);
/*       */           
/* 13332 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13337 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13338 */           localSQLException2.fillInStackTrace();
/* 13339 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13344 */     if (j != 0)
/*       */     {
/* 13346 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13347 */       localSQLException1.fillInStackTrace();
/* 13348 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 13357 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final boolean TRACE = false;
/*       */   
/*       */   class PushedBatch
/*       */   {
/*       */     int[] currentBatchCharLens;
/*       */     int[] lastBoundCharLens;
/*       */     Accessor[] currentBatchBindAccessors;
/*       */     boolean lastBoundNeeded;
/*       */     boolean need_to_parse;
/*       */     boolean current_batch_need_to_prepare_binds;
/*       */     int first_row_in_batch;
/*       */     int number_of_rows_to_be_bound;
/*       */     PushedBatch next;
/*       */     
/*       */     PushedBatch() {}
/*       */   }
/*       */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/OraclePreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */