package oracle.jdbc.aq;

import java.sql.SQLException;

public abstract interface AQAgent
{
  public abstract void setAddress(String paramString)
    throws SQLException;
  
  public abstract String getAddress();
  
  public abstract void setName(String paramString)
    throws SQLException;
  
  public abstract String getName();
  
  public abstract void setProtocol(int paramInt)
    throws SQLException;
  
  public abstract int getProtocol();
  
  public abstract String toString();
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/aq/AQAgent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */