/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormatSymbols;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Properties;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CVarcharAccessor
/*      */   extends VarcharAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   static final int t4MaxLength = 4000;
/*      */   static final int t4CallMaxLength = 4001;
/*      */   static final int t4PlsqlMaxLength = 32766;
/*      */   static final int t4SqlMinLength = 32;
/*   64 */   boolean underlyingLong = false;
/*      */   
/*      */ 
/*      */   T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine)
/*      */     throws SQLException
/*      */   {
/*   70 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */     
/*   72 */     this.mare = paramT4CMAREngine;
/*      */     
/*   74 */     calculateSizeTmpByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine)
/*      */     throws SQLException
/*      */   {
/*   84 */     super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*      */     
/*      */ 
/*      */ 
/*   88 */     this.mare = paramT4CMAREngine;
/*   89 */     this.definedColumnType = paramInt8;
/*   90 */     this.definedColumnSize = paramInt9;
/*      */     
/*   92 */     calculateSizeTmpByteArray();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */     this.oacmxl = paramInt7;
/*      */     
/*  100 */     if (this.oacmxl == -1)
/*      */     {
/*  102 */       this.underlyingLong = true;
/*  103 */       this.oacmxl = 4000;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void processIndicator(int paramInt)
/*      */     throws IOException, SQLException
/*      */   {
/*  112 */     if (((this.internalType == 1) && (this.describeType == 112)) || ((this.internalType == 23) && (this.describeType == 113)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  119 */       this.mare.unmarshalUB2();
/*  120 */       this.mare.unmarshalUB2();
/*      */     }
/*  122 */     else if (this.statement.connection.versionNumber < 9200)
/*      */     {
/*      */ 
/*      */ 
/*  126 */       this.mare.unmarshalSB2();
/*      */       
/*  128 */       if (!this.statement.sqlKind.isPlsqlOrCall()) {
/*  129 */         this.mare.unmarshalSB2();
/*      */       }
/*  131 */     } else if ((this.statement.sqlKind.isPlsqlOrCall()) || (this.isDMLReturnedParam))
/*      */     {
/*  133 */       this.mare.processIndicator(paramInt <= 0, paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  141 */   final int[] meta = new int[1];
/*  142 */   final int[] tmp = new int[1];
/*  143 */   final int[] escapeSequenceArr = new int[1];
/*  144 */   final boolean[] readHeaderArr = new boolean[1];
/*  145 */   final boolean[] readAsNonStreamArr = new boolean[1];
/*      */   static final int NONE = -1;
/*      */   static final int DAY = 1;
/*      */   static final int MM_MONTH = 2;
/*      */   static final int FULL_MONTH = 3;
/*      */   
/*      */   boolean unmarshalOneRow()
/*      */     throws SQLException, IOException
/*      */   {
/*  154 */     if (this.isUseLess)
/*      */     {
/*  156 */       this.lastRowProcessed += 1;
/*      */       
/*  158 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  162 */     int i = this.indicatorIndex + this.lastRowProcessed;
/*  163 */     int j = this.lengthIndex + this.lastRowProcessed;
/*      */     
/*      */ 
/*      */ 
/*  167 */     byte[] arrayOfByte1 = this.statement.tmpByteArray;
/*  168 */     int k = this.columnIndex + this.lastRowProcessed * this.charLength;
/*      */     
/*  170 */     if (!this.underlyingLong)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  175 */       if (this.rowSpaceIndicator == null)
/*      */       {
/*      */ 
/*      */ 
/*  179 */         byte[] arrayOfByte2 = new byte['㺀'];
/*      */         
/*  181 */         this.mare.unmarshalCLR(arrayOfByte2, 0, this.meta);
/*  182 */         processIndicator(this.meta[0]);
/*      */         
/*  184 */         this.lastRowProcessed += 1;
/*      */         
/*  186 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  191 */       if (this.isNullByDescribe)
/*      */       {
/*  193 */         this.rowSpaceIndicator[i] = -1;
/*  194 */         this.rowSpaceIndicator[j] = 0;
/*  195 */         this.lastRowProcessed += 1;
/*      */         
/*  197 */         if (this.statement.connection.versionNumber < 9200) {
/*  198 */           processIndicator(0);
/*      */         }
/*  200 */         return false;
/*      */       }
/*      */       
/*  203 */       if (this.statement.maxFieldSize > 0) {
/*  204 */         this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta, this.statement.maxFieldSize);
/*      */       } else {
/*  206 */         this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  212 */       this.escapeSequenceArr[0] = this.mare.unmarshalUB1();
/*      */       
/*      */ 
/*  215 */       if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0]))
/*      */       {
/*      */ 
/*      */ 
/*  219 */         this.meta[0] = 0;
/*      */         
/*  221 */         this.mare.processIndicator(false, 0);
/*      */         
/*  223 */         m = this.mare.unmarshalUB2();
/*      */       }
/*      */       else
/*      */       {
/*  227 */         m = 0;
/*  228 */         int n = 0;
/*  229 */         byte[] arrayOfByte3 = arrayOfByte1;
/*  230 */         int i1 = 0;
/*      */         
/*  232 */         this.readHeaderArr[0] = true;
/*  233 */         this.readAsNonStreamArr[0] = false;
/*      */         
/*  235 */         while (m != -1)
/*      */         {
/*  237 */           if ((arrayOfByte3 == arrayOfByte1) && (n + 255 > arrayOfByte1.length))
/*      */           {
/*      */ 
/*      */ 
/*  241 */             arrayOfByte3 = new byte['ÿ'];
/*      */           }
/*  243 */           if (arrayOfByte3 == arrayOfByte1) {
/*  244 */             i1 = n;
/*      */           } else {
/*  246 */             i1 = 0;
/*      */           }
/*  248 */           m = T4CLongAccessor.readStreamFromWire(arrayOfByte3, i1, 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
/*      */           
/*      */ 
/*      */ 
/*  252 */           if ((this.statement.connection.calculateChecksum) && (m != -1))
/*      */           {
/*      */ 
/*  255 */             long l = CRC64.updateChecksum(this.statement.checkSum, arrayOfByte3, i1, m);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  260 */             this.statement.checkSum = l;
/*      */           }
/*      */           
/*      */ 
/*  264 */           if (m != -1)
/*      */           {
/*  266 */             if (arrayOfByte3 == arrayOfByte1) {
/*  267 */               n += m;
/*  268 */             } else if (arrayOfByte1.length - n > 0)
/*      */             {
/*      */ 
/*      */ 
/*  272 */               int i2 = arrayOfByte1.length - n;
/*      */               
/*  274 */               System.arraycopy(arrayOfByte3, 0, arrayOfByte1, n, i2);
/*      */               
/*      */ 
/*  277 */               n += i2;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  282 */         if (arrayOfByte3 != arrayOfByte1) {
/*  283 */           arrayOfByte3 = null;
/*      */         }
/*  285 */         this.meta[0] = n;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  290 */     this.tmp[0] = this.meta[0];
/*      */     
/*  292 */     int m = 0;
/*      */     
/*  294 */     if (this.formOfUse == 2) {
/*  295 */       m = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte1, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */       m = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte1, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*      */     }
/*      */     
/*      */ 
/*  312 */     this.rowSpaceChar[k] = ((char)(m * 2));
/*      */     
/*      */ 
/*      */ 
/*  316 */     if (!this.underlyingLong) {
/*  317 */       processIndicator(this.meta[0]);
/*      */     }
/*  319 */     if (this.meta[0] == 0)
/*      */     {
/*      */ 
/*      */ 
/*  323 */       this.rowSpaceIndicator[i] = -1;
/*  324 */       this.rowSpaceIndicator[j] = 0;
/*      */     }
/*      */     else
/*      */     {
/*  328 */       this.rowSpaceIndicator[j] = ((short)(this.meta[0] * 2));
/*      */       
/*      */ 
/*      */ 
/*  332 */       this.rowSpaceIndicator[i] = 0;
/*      */     }
/*      */     
/*  335 */     this.lastRowProcessed += 1;
/*      */     
/*  337 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void copyRow()
/*      */     throws SQLException, IOException
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/*  348 */     if (this.lastRowProcessed == 0) {
/*  349 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*      */     } else {
/*  351 */       i = this.lastRowProcessed - 1;
/*      */     }
/*      */     
/*  354 */     int j = this.columnIndex + this.lastRowProcessed * this.charLength;
/*  355 */     int k = this.columnIndex + i * this.charLength;
/*  356 */     int m = this.indicatorIndex + this.lastRowProcessed;
/*  357 */     int n = this.indicatorIndex + i;
/*  358 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/*  359 */     int i2 = this.lengthIndex + i;
/*  360 */     int i3 = this.rowSpaceIndicator[i2];
/*  361 */     int i4 = this.metaDataIndex + this.lastRowProcessed * 1;
/*      */     
/*  363 */     int i5 = this.metaDataIndex + i * 1;
/*      */     
/*      */ 
/*      */ 
/*  367 */     this.rowSpaceIndicator[i1] = ((short)i3);
/*  368 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*      */     
/*      */ 
/*  371 */     if (!this.isNullByDescribe)
/*      */     {
/*  373 */       System.arraycopy(this.rowSpaceChar, k, this.rowSpaceChar, j, this.rowSpaceChar[k] / '\002' + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  378 */     System.arraycopy(this.rowSpaceMetaData, i5, this.rowSpaceMetaData, i4, 1);
/*      */     
/*      */ 
/*      */ 
/*  382 */     this.lastRowProcessed += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfByte, char[] paramArrayOfChar, short[] paramArrayOfShort, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  395 */     int i = this.columnIndex + (paramInt2 - 1) * this.charLength;
/*      */     
/*  397 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.charLength;
/*      */     
/*  399 */     int k = this.indicatorIndex + paramInt2 - 1;
/*  400 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/*  401 */     int n = this.lengthIndex + paramInt2 - 1;
/*  402 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/*  403 */     int i2 = paramArrayOfShort[i1];
/*      */     
/*  405 */     this.rowSpaceIndicator[n] = ((short)i2);
/*  406 */     this.rowSpaceIndicator[k] = paramArrayOfShort[m];
/*      */     
/*      */ 
/*  409 */     if (i2 != 0)
/*      */     {
/*  411 */       System.arraycopy(paramArrayOfChar, j, this.rowSpaceChar, i, paramArrayOfChar[j] / '\002' + 1);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  416 */       this.rowSpaceChar[i] = '\000';
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final int MON_MONTH = 4;
/*      */   
/*      */ 
/*      */   static final int YY_YEAR = 5;
/*      */   
/*      */ 
/*      */   static final int RR_YEAR = 6;
/*      */   
/*      */ 
/*      */   static final int HH_HOUR = 7;
/*      */   
/*      */ 
/*      */   void calculateSizeTmpByteArray()
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/*  439 */     if (this.formOfUse == 2)
/*      */     {
/*      */ 
/*      */ 
/*  443 */       i = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
/*      */     }
/*      */     else
/*      */     {
/*  447 */       i = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
/*      */     }
/*      */     
/*  450 */     if (this.statement.sizeTmpByteArray < i) {
/*  451 */       this.statement.sizeTmpByteArray = i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  464 */     String str = super.getString(paramInt);
/*      */     
/*  466 */     if ((str != null) && (this.definedColumnSize > 0) && (str.length() > this.definedColumnSize))
/*      */     {
/*  468 */       str = str.substring(0, this.definedColumnSize);
/*      */     }
/*  470 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  480 */     NUMBER localNUMBER = null;
/*      */     
/*  482 */     if (this.definedColumnType == 0) {
/*  483 */       localNUMBER = super.getNUMBER(paramInt);
/*      */     }
/*      */     else {
/*  486 */       String str = getString(paramInt);
/*  487 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  496 */         return StringToNUMBER(str);
/*      */       }
/*      */     }
/*      */     
/*  500 */     return localNUMBER;
/*      */   }
/*      */   
/*      */ 
/*      */   DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  507 */     DATE localDATE = null;
/*      */     
/*  509 */     if (this.definedColumnType == 0) {
/*  510 */       localDATE = super.getDATE(paramInt);
/*      */     }
/*      */     else {
/*  513 */       Date localDate = getDate(paramInt);
/*  514 */       if (localDate != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  523 */         localDATE = new DATE(localDate);
/*      */       }
/*      */     }
/*      */     
/*  527 */     return localDATE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  535 */     TIMESTAMP localTIMESTAMP = null;
/*      */     
/*  537 */     if (this.definedColumnType == 0) {
/*  538 */       localTIMESTAMP = super.getTIMESTAMP(paramInt);
/*      */     }
/*      */     else {
/*  541 */       String str = getString(paramInt);
/*  542 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  552 */         int[] arrayOfInt = new int[1];
/*  553 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*      */         
/*      */ 
/*  556 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  557 */         localTimestamp.setNanos(arrayOfInt[0]);
/*  558 */         localTIMESTAMP = new TIMESTAMP(localTimestamp);
/*      */       }
/*      */     }
/*      */     
/*  562 */     return localTIMESTAMP;
/*      */   }
/*      */   
/*      */ 
/*      */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  569 */     TIMESTAMPTZ localTIMESTAMPTZ = null;
/*      */     
/*  571 */     if (this.definedColumnType == 0) {
/*  572 */       localTIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt);
/*      */     }
/*      */     else {
/*  575 */       String str = getString(paramInt);
/*  576 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  587 */         int[] arrayOfInt = new int[1];
/*  588 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */         
/*      */ 
/*  591 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  592 */         localTimestamp.setNanos(arrayOfInt[0]);
/*  593 */         localTIMESTAMPTZ = new TIMESTAMPTZ(this.statement.connection, localTimestamp, localCalendar);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  599 */     return localTIMESTAMPTZ;
/*      */   }
/*      */   
/*      */ 
/*      */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  606 */     TIMESTAMPLTZ localTIMESTAMPLTZ = null;
/*      */     
/*  608 */     if (this.definedColumnType == 0) {
/*  609 */       localTIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt);
/*      */     }
/*      */     else {
/*  612 */       String str = getString(paramInt);
/*  613 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  624 */         int[] arrayOfInt = new int[1];
/*  625 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */         
/*      */ 
/*  628 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  629 */         localTimestamp.setNanos(arrayOfInt[0]);
/*  630 */         localTIMESTAMPLTZ = new TIMESTAMPLTZ(this.statement.connection, localTimestamp, localCalendar);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  636 */     return localTIMESTAMPLTZ;
/*      */   }
/*      */   
/*      */ 
/*      */   RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  643 */     RAW localRAW = null;
/*      */     
/*  645 */     if (this.definedColumnType == 0) {
/*  646 */       localRAW = super.getRAW(paramInt);
/*      */     }
/*      */     else {
/*  649 */       if (this.rowSpaceIndicator == null)
/*      */       {
/*      */ 
/*      */ 
/*  653 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  654 */         localSQLException.fillInStackTrace();
/*  655 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  661 */       if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */       {
/*  663 */         if ((this.definedColumnType == -2) || (this.definedColumnType == -3) || (this.definedColumnType == -4))
/*      */         {
/*      */ 
/*  666 */           localRAW = new RAW(getBytesFromHexChars(paramInt));
/*      */         } else {
/*  668 */           localRAW = new RAW(super.getBytes(paramInt));
/*      */         }
/*      */       }
/*      */     }
/*  672 */     return localRAW;
/*      */   }
/*      */   
/*      */ 
/*      */   Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  679 */     if (this.definedColumnType == 0) {
/*  680 */       return super.getOracleObject(paramInt);
/*      */     }
/*      */     
/*  683 */     Datum localDatum = null;
/*      */     SQLException localSQLException;
/*  685 */     if (this.rowSpaceIndicator == null)
/*      */     {
/*  687 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  688 */       localSQLException.fillInStackTrace();
/*  689 */       throw localSQLException;
/*      */     }
/*      */     
/*  692 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*  694 */       switch (this.definedColumnType)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/*  703 */         return super.getOracleObject(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -7: 
/*      */       case -6: 
/*      */       case -5: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 7: 
/*      */       case 8: 
/*      */       case 16: 
/*  726 */         return getNUMBER(paramInt);
/*      */       
/*      */       case 91: 
/*  729 */         return getDATE(paramInt);
/*      */       
/*      */       case 92: 
/*  732 */         return getDATE(paramInt);
/*      */       
/*      */       case 93: 
/*  735 */         return getTIMESTAMP(paramInt);
/*      */       
/*      */       case -101: 
/*  738 */         return getTIMESTAMPTZ(paramInt);
/*      */       
/*      */       case -102: 
/*  741 */         return getTIMESTAMPLTZ(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*  748 */         return getRAW(paramInt);
/*      */       
/*      */       case -8: 
/*  751 */         return getROWID(paramInt);
/*      */       }
/*      */       
/*      */       
/*  755 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  756 */       localSQLException.fillInStackTrace();
/*  757 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  763 */     return localDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  772 */     if (this.definedColumnType == 0) {
/*  773 */       return super.getBytes(paramInt);
/*      */     }
/*  775 */     Datum localDatum = getOracleObject(paramInt);
/*  776 */     if (localDatum != null) {
/*  777 */       return localDatum.shareBytes();
/*      */     }
/*  779 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  787 */     boolean bool = false;
/*      */     
/*  789 */     if (this.definedColumnType == 0) {
/*  790 */       bool = super.getBoolean(paramInt);
/*      */     }
/*      */     else {
/*  793 */       bool = getNUMBER(paramInt).booleanValue();
/*      */     }
/*      */     
/*  796 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  804 */     byte b = 0;
/*      */     
/*  806 */     if (this.definedColumnType == 0) {
/*  807 */       b = super.getByte(paramInt);
/*      */     }
/*      */     else {
/*  810 */       NUMBER localNUMBER = getNUMBER(paramInt);
/*  811 */       if (localNUMBER != null) {
/*  812 */         b = localNUMBER.byteValue();
/*      */       }
/*      */     }
/*  815 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  823 */     int i = 0;
/*      */     
/*  825 */     if (this.definedColumnType == 0) {
/*  826 */       i = super.getInt(paramInt);
/*      */     }
/*      */     else {
/*  829 */       NUMBER localNUMBER = getNUMBER(paramInt);
/*  830 */       if (localNUMBER != null) {
/*  831 */         i = localNUMBER.intValue();
/*      */       }
/*      */     }
/*  834 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  842 */     short s = 0;
/*      */     
/*  844 */     if (this.definedColumnType == 0) {
/*  845 */       s = super.getShort(paramInt);
/*      */     }
/*      */     else {
/*  848 */       NUMBER localNUMBER = getNUMBER(paramInt);
/*  849 */       if (localNUMBER != null) {
/*  850 */         s = localNUMBER.shortValue();
/*      */       }
/*      */     }
/*  853 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  861 */     long l = 0L;
/*      */     
/*  863 */     if (this.definedColumnType == 0) {
/*  864 */       l = super.getLong(paramInt);
/*      */     }
/*      */     else {
/*  867 */       NUMBER localNUMBER = getNUMBER(paramInt);
/*  868 */       if (localNUMBER != null) {
/*  869 */         l = localNUMBER.longValue();
/*      */       }
/*      */     }
/*  872 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  880 */     float f = 0.0F;
/*      */     
/*  882 */     if (this.definedColumnType == 0) {
/*  883 */       f = super.getFloat(paramInt);
/*      */     }
/*      */     else {
/*  886 */       NUMBER localNUMBER = getNUMBER(paramInt);
/*  887 */       if (localNUMBER != null) {
/*  888 */         f = localNUMBER.floatValue();
/*      */       }
/*      */     }
/*  891 */     return f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  899 */     double d = 0.0D;
/*      */     
/*  901 */     if (this.definedColumnType == 0) {
/*  902 */       d = super.getDouble(paramInt);
/*      */     }
/*      */     else {
/*  905 */       NUMBER localNUMBER = getNUMBER(paramInt);
/*  906 */       if (localNUMBER != null) {
/*  907 */         d = localNUMBER.doubleValue();
/*      */       }
/*      */     }
/*  910 */     return d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  920 */     Date localDate = null;
/*      */     
/*  922 */     if (this.definedColumnType == 0) {
/*  923 */       localDate = super.getDate(paramInt);
/*      */     }
/*      */     else {
/*  926 */       String str = getString(paramInt);
/*  927 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  936 */         int[] arrayOfInt = new int[1];
/*      */         
/*  938 */         localDate = new Date(DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  944 */     return localDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  952 */     Timestamp localTimestamp = null;
/*      */     
/*  954 */     if (this.definedColumnType == 0) {
/*  955 */       localTimestamp = super.getTimestamp(paramInt);
/*      */     }
/*      */     else {
/*  958 */       String str = getString(paramInt);
/*  959 */       if (str != null)
/*      */       {
/*  961 */         int[] arrayOfInt = new int[1];
/*  962 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*      */         
/*      */ 
/*  965 */         localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  966 */         localTimestamp.setNanos(arrayOfInt[0]);
/*      */       }
/*      */     }
/*      */     
/*  970 */     return localTimestamp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  978 */     Time localTime = null;
/*      */     
/*  980 */     if (this.definedColumnType == 0) {
/*  981 */       localTime = super.getTime(paramInt);
/*      */     }
/*      */     else {
/*  984 */       String str = getString(paramInt);
/*  985 */       if (str != null)
/*      */       {
/*  987 */         int[] arrayOfInt = new int[1];
/*  988 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */         
/*      */ 
/*  991 */         localTime = new Time(localCalendar.getTimeInMillis());
/*      */       }
/*      */     }
/*      */     
/*  995 */     return localTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1004 */     if (this.definedColumnType == 0) {
/* 1005 */       return super.getObject(paramInt);
/*      */     }
/*      */     
/* 1008 */     Object localObject = null;
/*      */     SQLException localSQLException;
/* 1010 */     if (this.rowSpaceIndicator == null)
/*      */     {
/* 1012 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1013 */       localSQLException.fillInStackTrace();
/* 1014 */       throw localSQLException;
/*      */     }
/*      */     
/* 1017 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/* 1019 */       switch (this.definedColumnType)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 1028 */         return getString(paramInt);
/*      */       
/*      */ 
/*      */       case 2: 
/*      */       case 3: 
/* 1033 */         return getBigDecimal(paramInt);
/*      */       
/*      */       case 4: 
/* 1036 */         return Integer.valueOf(getInt(paramInt));
/*      */       
/*      */       case -6: 
/* 1039 */         return Byte.valueOf(getByte(paramInt));
/*      */       
/*      */       case 5: 
/* 1042 */         return Short.valueOf(getShort(paramInt));
/*      */       
/*      */ 
/*      */       case -7: 
/*      */       case 16: 
/* 1047 */         return Boolean.valueOf(getBoolean(paramInt));
/*      */       
/*      */       case -5: 
/* 1050 */         return Long.valueOf(getLong(paramInt));
/*      */       
/*      */       case 7: 
/* 1053 */         return Float.valueOf(getFloat(paramInt));
/*      */       
/*      */ 
/*      */       case 6: 
/*      */       case 8: 
/* 1058 */         return Double.valueOf(getDouble(paramInt));
/*      */       
/*      */       case 91: 
/* 1061 */         return getDate(paramInt);
/*      */       
/*      */       case 92: 
/* 1064 */         return getTime(paramInt);
/*      */       
/*      */       case 93: 
/* 1067 */         return getTimestamp(paramInt);
/*      */       
/*      */       case -101: 
/* 1070 */         return getTIMESTAMPTZ(paramInt);
/*      */       
/*      */       case -102: 
/* 1073 */         return getTIMESTAMPLTZ(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/* 1080 */         return getBytesFromHexChars(paramInt);
/*      */       
/*      */       case -8: 
/* 1083 */         return getROWID(paramInt);
/*      */       }
/*      */       
/*      */       
/* 1087 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1088 */       localSQLException.fillInStackTrace();
/* 1089 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1095 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final NUMBER StringToNUMBER(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1104 */     return new NUMBER(new BigDecimal(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final int HH24_HOUR = 8;
/*      */   
/*      */ 
/*      */   static final int MINUTE = 9;
/*      */   
/*      */ 
/*      */   static final int SECOND = 10;
/*      */   
/*      */ 
/*      */   static final int NSECOND = 11;
/*      */   
/*      */ 
/*      */   static final int AM = 12;
/*      */   
/*      */ 
/*      */   static final int TZR = 13;
/*      */   
/*      */   static final int TZH = 14;
/*      */   
/*      */   static final int TZM = 15;
/*      */   
/*      */   static final Calendar DATEStringToCalendar(String paramString1, String paramString2, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 1133 */     char[] arrayOfChar = (paramString2 + " ").toCharArray();
/* 1134 */     paramString1 = paramString1 + " ";
/*      */     
/*      */ 
/* 1137 */     int i = Math.min(paramString1.length(), arrayOfChar.length);
/*      */     
/* 1139 */     int j = -1;
/* 1140 */     int k = -1;
/*      */     
/* 1142 */     int m = 0;
/* 1143 */     int n = 0;
/*      */     
/* 1145 */     String str1 = 0;
/* 1146 */     int i1 = 0;
/*      */     
/* 1148 */     int i2 = 0;
/* 1149 */     int i3 = 0;
/* 1150 */     int i4 = 0;
/*      */     
/* 1152 */     int i5 = 0;
/* 1153 */     int i6 = 0;
/* 1154 */     int i7 = 0;
/* 1155 */     int i8 = 0;
/*      */     
/* 1157 */     String str2 = null;
/* 1158 */     String str3 = null;
/*      */     
/* 1160 */     int i9 = 0;
/*      */     
/*      */ 
/* 1163 */     String[] arrayOfString1 = null;
/* 1164 */     String[] arrayOfString2 = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1182 */     for (int i10 = 0; i10 < i; i10++)
/*      */     {
/* 1184 */       switch (arrayOfChar[i10])
/*      */       {
/*      */       case 'R': 
/*      */       case 'r': 
/* 1188 */         if (j != 6)
/*      */         {
/* 1190 */           j = 6;
/* 1191 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'Y': 
/*      */       case 'y': 
/* 1197 */         if (j != 5)
/*      */         {
/* 1199 */           j = 5;
/* 1200 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'D': 
/*      */       case 'd': 
/* 1206 */         if (j != 1)
/*      */         {
/* 1208 */           j = 1;
/* 1209 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'M': 
/*      */       case 'm': 
/* 1215 */         if ((j != 2) || (j != 4) || (j != 3) || (j != 9))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1221 */           m = i10;
/*      */           
/* 1223 */           if ((i10 + 4 < i) && ((arrayOfChar[(i10 + 1)] == 'O') || (arrayOfChar[(i10 + 1)] == 'o')) && ((arrayOfChar[(i10 + 2)] == 'N') || (arrayOfChar[(i10 + 2)] == 'n')) && ((arrayOfChar[(i10 + 3)] == 'T') || (arrayOfChar[(i10 + 3)] == 't')) && ((arrayOfChar[(i10 + 4)] == 'H') || (arrayOfChar[(i10 + 4)] == 'h')))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1229 */             j = 3;
/* 1230 */             i10 += 4;
/* 1231 */           } else if ((i10 + 2 < i) && ((arrayOfChar[(i10 + 1)] == 'O') || (arrayOfChar[(i10 + 1)] == 'o')) && ((arrayOfChar[(i10 + 2)] == 'N') || (arrayOfChar[(i10 + 2)] == 'n')))
/*      */           {
/*      */ 
/*      */ 
/* 1235 */             j = 4;
/* 1236 */             i10 += 2;
/* 1237 */           } else if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'M') || (arrayOfChar[(i10 + 1)] == 'm')))
/*      */           {
/*      */ 
/* 1240 */             j = 2;
/* 1241 */             i10++;
/* 1242 */           } else if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'I') || (arrayOfChar[(i10 + 1)] == 'i')))
/*      */           {
/*      */ 
/* 1245 */             j = 9;
/* 1246 */             i10++;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 'H': 
/*      */       case 'h': 
/* 1255 */         if (j != 7)
/*      */         {
/* 1257 */           j = 7;
/* 1258 */           m = i10;
/* 1259 */         } else if ((i10 + 2 < i) && ((arrayOfChar[(i10 + 1)] == '2') || (arrayOfChar[(i10 + 4)] == '4')))
/*      */         {
/*      */ 
/* 1262 */           j = 8;
/* 1263 */           i10 += 2;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'S': 
/*      */       case 's': 
/* 1269 */         if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'S') || (arrayOfChar[(i10 + 1)] == 's')))
/*      */         {
/*      */ 
/* 1272 */           j = 10;
/* 1273 */           m = i10;
/* 1274 */           i10++;
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 'F': 
/*      */       case 'f': 
/* 1281 */         if (j != 11)
/*      */         {
/* 1283 */           j = 11;
/* 1284 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'A': 
/*      */       case 'a': 
/* 1290 */         if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'M') || (arrayOfChar[(i10 + 1)] == 'm')))
/*      */         {
/*      */ 
/* 1293 */           j = 12;
/* 1294 */           m = i10;
/* 1295 */           i10++;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'T': 
/*      */       case 't': 
/* 1301 */         if ((i10 + 2 < i) && ((arrayOfChar[(i10 + 1)] == 'Z') || (arrayOfChar[(i10 + 1)] == 'z')) && ((arrayOfChar[(i10 + 2)] == 'R') || (arrayOfChar[(i10 + 2)] == 'r')))
/*      */         {
/*      */ 
/*      */ 
/* 1305 */           j = 13;
/* 1306 */           m = i10;
/* 1307 */           i10 += 2;
/*      */         }
/*      */         break;
/*      */       case 'B': case 'C': case 'E': case 'G': case 'I': case 'J': case 'K': case 'L': case 'N': case 'O': 
/*      */       case 'P': case 'Q': case 'U': case 'V': case 'W': case 'X': case 'Z': case '[': case '\\': case ']': 
/*      */       case '^': case '_': case '`': case 'b': case 'c': case 'e': case 'g': case 'i': case 'j': case 'k': 
/*      */       case 'l': case 'n': case 'o': case 'p': case 'q': case 'u': case 'v': case 'w': case 'x': default: 
/* 1314 */         i9 = 1;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1325 */       if ((i9 != 0) && (j != -1))
/*      */       {
/* 1327 */         int i11 = i10 - m;
/* 1328 */         int i12 = m - n;
/* 1329 */         str1 = i1 + i12;
/*      */         
/* 1331 */         i1 = str1 + i11;
/* 1332 */         Object localObject; String str4; int i15; switch (j)
/*      */         {
/*      */         case 1: 
/* 1335 */           i2 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1336 */           break;
/*      */         
/*      */         case 2: 
/* 1339 */           i3 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1340 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 3: 
/* 1345 */           int i16 = str1;
/* 1346 */           i1 = str1;
/* 1347 */           for (i16 = str1; i16 < paramString1.length(); i16++)
/* 1348 */             if (paramString1.charAt(i16) == arrayOfChar[i10])
/*      */               break;
/* 1350 */           i1 = i16;
/*      */           
/* 1352 */           localObject = null;
/* 1353 */           if (i1 != str1) {
/* 1354 */             localObject = paramString1.substring(str1, i1);
/*      */             
/*      */ 
/*      */ 
/* 1358 */             localObject = ((String)localObject).trim();
/*      */             
/* 1360 */             if (arrayOfString2 == null)
/* 1361 */               arrayOfString2 = new DateFormatSymbols().getMonths();
/* 1362 */             for (i3 = 0; i3 < arrayOfString2.length; i3++) {
/* 1363 */               if (((String)localObject).equalsIgnoreCase(arrayOfString2[i3]))
/*      */                 break;
/*      */             }
/* 1366 */             if (i3 >= 12)
/*      */             {
/* 1368 */               SQLException localSQLException = DatabaseError.createSqlException(null, 59);
/* 1369 */               localSQLException.fillInStackTrace();
/* 1370 */               throw localSQLException;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1379 */           break;
/*      */         
/*      */         case 4: 
/* 1382 */           int i13 = str1;
/* 1383 */           i1 = str1;
/* 1384 */           for (int i14 = str1; i14 < paramString1.length(); i14++)
/* 1385 */             if (paramString1.charAt(i14) == arrayOfChar[i10])
/*      */               break;
/* 1387 */           i1 = i14;
/*      */           
/* 1389 */           str4 = null;
/* 1390 */           if (i1 != str1) {
/* 1391 */             str4 = paramString1.substring(str1, i1);
/*      */             
/*      */ 
/*      */ 
/* 1395 */             str4 = str4.trim();
/*      */             
/* 1397 */             if (arrayOfString1 == null)
/* 1398 */               arrayOfString1 = new DateFormatSymbols().getShortMonths();
/* 1399 */             for (i3 = 0; i3 < arrayOfString1.length; i3++) {
/* 1400 */               if (str4.equalsIgnoreCase(arrayOfString1[i3]))
/*      */                 break;
/*      */             }
/* 1403 */             if (i3 >= 12)
/*      */             {
/* 1405 */               localObject = DatabaseError.createSqlException(null, 59);
/* 1406 */               ((SQLException)localObject).fillInStackTrace();
/* 1407 */               throw ((Throwable)localObject);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1416 */           break;
/*      */         
/*      */         case 5: 
/* 1419 */           i4 = Integer.parseInt(paramString1.substring(str1, i1));
/*      */           
/*      */ 
/*      */ 
/* 1423 */           if (i11 == 2) {
/* 1424 */             i4 += 2000;
/*      */           }
/*      */           break;
/*      */         case 6: 
/* 1428 */           i4 = Integer.parseInt(paramString1.substring(str1, i1));
/*      */           
/*      */ 
/*      */ 
/* 1432 */           if ((i11 == 2) && (i4 < 50)) {
/* 1433 */             i4 += 2000;
/*      */           } else
/* 1435 */             i4 += 1900;
/* 1436 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 7: 
/*      */         case 8: 
/* 1442 */           i1 = str1 + 2;
/* 1443 */           i5 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1444 */           break;
/*      */         
/*      */         case 9: 
/* 1447 */           i6 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1448 */           break;
/*      */         
/*      */         case 10: 
/* 1451 */           i7 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1452 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case 11: 
/* 1461 */           str4 = str1;
/* 1462 */           i1 = str1;
/* 1463 */           for (str4 = str1; str4 < paramString1.length(); str4++)
/* 1464 */             if (((i15 = paramString1.charAt(str4)) < '0') || (i15 > 57))
/*      */               break;
/* 1466 */           i1 += str4 - str1;
/*      */           
/* 1468 */           if (i1 != str1) {
/* 1469 */             i8 = Integer.parseInt(paramString1.substring(str1, i1));
/*      */           }
/*      */           break;
/*      */         case 12: 
/* 1473 */           if (i1 > 0) {
/* 1474 */             str2 = paramString1.substring(str1, i1);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 13: 
/* 1484 */           int i17 = str1;
/* 1485 */           i1 = str1;
/* 1486 */           for (int i18 = str1; i18 < paramString1.length(); i18++) {
/* 1487 */             if ((((i15 = paramString1.charAt(i18)) < '0') || (i15 > 57)) && ((i15 < 97) || (i15 > 122)) && ((i15 < 65) || (i15 > 90))) {
/*      */               break;
/*      */             }
/*      */             
/*      */ 
/* 1492 */             i1 = i18;
/*      */           }
/* 1494 */           if (i1 != str1) {
/* 1495 */             str3 = paramString1.substring(str1, i1);
/*      */           }
/*      */           
/*      */           break;
/*      */         default: 
/* 1500 */           System.out.println("\n\n\n             ***** ERROR(1) ****\n");
/*      */         }
/*      */         
/*      */         
/* 1504 */         n = i10;
/* 1505 */         j = -1;
/* 1506 */         i9 = 0;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1513 */     GregorianCalendar localGregorianCalendar = new GregorianCalendar(i4, i3, i2, i5, i6, i7);
/* 1514 */     if (str2 != null) {
/* 1515 */       localGregorianCalendar.set(9, str2.equalsIgnoreCase("AM") ? 0 : 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1520 */     if ((str3 == null) || 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1526 */       (i8 != 0)) {
/* 1527 */       paramArrayOfInt[0] = i8;
/*      */     }
/* 1529 */     return localGregorianCalendar;
/*      */   }
/*      */   
/*      */ 
/* 1533 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/T4CVarcharAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */