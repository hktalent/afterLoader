package oracle.jdbc;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

public abstract interface OracleBlob
  extends Blob
{
  public abstract void open(LargeObjectAccessMode paramLargeObjectAccessMode)
    throws SQLException;
  
  public abstract void close()
    throws SQLException;
  
  public abstract boolean isOpen()
    throws SQLException;
  
  public abstract int getBytes(long paramLong, int paramInt, byte[] paramArrayOfByte)
    throws SQLException;
  
  public abstract boolean isEmptyLob()
    throws SQLException;
  
  public abstract boolean isSecureFile()
    throws SQLException;
  
  public abstract InputStream getBinaryStream(long paramLong)
    throws SQLException;
  
  public abstract boolean isTemporary()
    throws SQLException;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/OracleBlob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */