package oracle.jdbc.internal;

public abstract interface ClientDataSupport
{
  public abstract Object getClientData(Object paramObject);
  
  public abstract Object setClientData(Object paramObject1, Object paramObject2);
  
  public abstract Object removeClientData(Object paramObject);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/internal/ClientDataSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */