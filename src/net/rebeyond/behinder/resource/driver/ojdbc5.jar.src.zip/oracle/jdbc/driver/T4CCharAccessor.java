/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Properties;
/*     */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NUMBER;
/*     */ import oracle.sql.RAW;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPLTZ;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CCharAccessor
/*     */   extends CharAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*  57 */   boolean underlyingLong = false;
/*     */   
/*     */ 
/*     */   T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine)
/*     */     throws SQLException
/*     */   {
/*  63 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */     
/*  65 */     this.mare = paramT4CMAREngine;
/*     */     
/*  67 */     calculateSizeTmpByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine)
/*     */     throws SQLException
/*     */   {
/*  77 */     super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*     */     
/*     */ 
/*     */ 
/*  81 */     this.mare = paramT4CMAREngine;
/*  82 */     this.definedColumnType = paramInt8;
/*  83 */     this.definedColumnSize = paramInt9;
/*     */     
/*  85 */     calculateSizeTmpByteArray();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     this.oacmxl = paramInt7;
/*     */     
/*  93 */     if (this.oacmxl == -1)
/*     */     {
/*  95 */       this.underlyingLong = true;
/*  96 */       this.oacmxl = 4000;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void processIndicator(int paramInt)
/*     */     throws IOException, SQLException
/*     */   {
/* 105 */     if (((this.internalType == 1) && (this.describeType == 112)) || ((this.internalType == 23) && (this.describeType == 113)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */       this.mare.unmarshalUB2();
/* 113 */       this.mare.unmarshalUB2();
/*     */     }
/* 115 */     else if (this.statement.connection.versionNumber < 9200)
/*     */     {
/*     */ 
/*     */ 
/* 119 */       this.mare.unmarshalSB2();
/*     */       
/* 121 */       if (!this.statement.sqlKind.isPlsqlOrCall()) {
/* 122 */         this.mare.unmarshalSB2();
/*     */       }
/* 124 */     } else if ((this.statement.sqlKind.isPlsqlOrCall()) || (this.isDMLReturnedParam))
/*     */     {
/* 126 */       this.mare.processIndicator(paramInt <= 0, paramInt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */   final int[] meta = new int[1];
/* 135 */   final int[] tmp = new int[1];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean unmarshalOneRow()
/*     */     throws SQLException, IOException
/*     */   {
/* 144 */     if (this.isUseLess)
/*     */     {
/* 146 */       this.lastRowProcessed += 1;
/*     */       
/* 148 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 152 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 153 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */     
/*     */ 
/*     */ 
/* 157 */     byte[] arrayOfByte1 = this.statement.tmpByteArray;
/* 158 */     int k = this.columnIndex + this.lastRowProcessed * this.charLength;
/*     */     
/*     */ 
/*     */ 
/* 162 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 166 */       byte[] arrayOfByte2 = new byte['㺀'];
/*     */       
/* 168 */       this.mare.unmarshalCLR(arrayOfByte2, 0, this.meta);
/* 169 */       processIndicator(this.meta[0]);
/*     */       
/* 171 */       this.lastRowProcessed += 1;
/*     */       
/* 173 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 178 */     if (this.isNullByDescribe)
/*     */     {
/* 180 */       this.rowSpaceIndicator[i] = -1;
/* 181 */       this.rowSpaceIndicator[j] = 0;
/* 182 */       this.lastRowProcessed += 1;
/*     */       
/* 184 */       if (this.statement.connection.versionNumber < 9200) {
/* 185 */         processIndicator(0);
/*     */       }
/* 187 */       return false;
/*     */     }
/*     */     
/* 190 */     if (this.statement.maxFieldSize > 0) {
/* 191 */       this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta, this.statement.maxFieldSize);
/*     */     } else {
/* 193 */       this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/*     */     }
/* 195 */     this.tmp[0] = this.meta[0];
/*     */     
/* 197 */     int m = 0;
/*     */     
/* 199 */     if (this.formOfUse == 2) {
/* 200 */       m = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte1, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */       m = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte1, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*     */     }
/*     */     
/*     */ 
/* 218 */     this.rowSpaceChar[k] = ((char)(m * 2));
/*     */     
/*     */ 
/*     */ 
/* 222 */     processIndicator(this.meta[0]);
/*     */     
/* 224 */     if (this.meta[0] == 0)
/*     */     {
/*     */ 
/*     */ 
/* 228 */       this.rowSpaceIndicator[i] = -1;
/* 229 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else
/*     */     {
/* 233 */       this.rowSpaceIndicator[j] = ((short)(this.meta[0] * 2));
/*     */       
/*     */ 
/*     */ 
/* 237 */       this.rowSpaceIndicator[i] = 0;
/*     */     }
/*     */     
/* 240 */     this.lastRowProcessed += 1;
/*     */     
/* 242 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void copyRow()
/*     */     throws SQLException, IOException
/*     */   {
/*     */     int i;
/*     */     
/* 252 */     if (this.lastRowProcessed == 0) {
/* 253 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 255 */       i = this.lastRowProcessed - 1;
/*     */     }
/*     */     
/* 258 */     int j = this.columnIndex + this.lastRowProcessed * this.charLength;
/* 259 */     int k = this.columnIndex + i * this.charLength;
/* 260 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 261 */     int n = this.indicatorIndex + i;
/* 262 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 263 */     int i2 = this.lengthIndex + i;
/* 264 */     int i3 = this.rowSpaceIndicator[i2];
/* 265 */     int i4 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 267 */     int i5 = this.metaDataIndex + i * 1;
/*     */     
/*     */ 
/*     */ 
/* 271 */     this.rowSpaceIndicator[i1] = ((short)i3);
/* 272 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */     
/*     */ 
/* 275 */     if (!this.isNullByDescribe)
/*     */     {
/* 277 */       System.arraycopy(this.rowSpaceChar, k, this.rowSpaceChar, j, this.rowSpaceChar[k] / '\002' + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 282 */     System.arraycopy(this.rowSpaceMetaData, i5, this.rowSpaceMetaData, i4, 1);
/*     */     
/*     */ 
/* 285 */     this.lastRowProcessed += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfByte, char[] paramArrayOfChar, short[] paramArrayOfShort, int paramInt1, int paramInt2)
/*     */     throws SQLException
/*     */   {
/* 298 */     int i = this.columnIndex + (paramInt2 - 1) * this.charLength;
/*     */     
/* 300 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.charLength;
/*     */     
/* 302 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 303 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 304 */     int n = this.lengthIndex + paramInt2 - 1;
/* 305 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 306 */     int i2 = paramArrayOfShort[i1];
/*     */     
/* 308 */     this.rowSpaceIndicator[n] = ((short)i2);
/* 309 */     this.rowSpaceIndicator[k] = paramArrayOfShort[m];
/*     */     
/*     */ 
/* 312 */     if (i2 != 0)
/*     */     {
/* 314 */       System.arraycopy(paramArrayOfChar, j, this.rowSpaceChar, i, paramArrayOfChar[j] / '\002' + 1);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 319 */       this.rowSpaceChar[i] = '\000';
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void calculateSizeTmpByteArray()
/*     */   {
/*     */     int i;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */     if (this.formOfUse == 2)
/*     */     {
/*     */ 
/*     */ 
/* 346 */       i = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
/*     */     }
/*     */     else
/*     */     {
/* 350 */       i = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
/*     */     }
/*     */     
/* 353 */     if (this.statement.sizeTmpByteArray < i) {
/* 354 */       this.statement.sizeTmpByteArray = i;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getString(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 367 */     String str = super.getString(paramInt);
/*     */     
/* 369 */     if ((str != null) && (this.definedColumnSize > 0) && (str.length() > this.definedColumnSize))
/*     */     {
/* 371 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 373 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NUMBER getNUMBER(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 383 */     NUMBER localNUMBER = null;
/*     */     
/* 385 */     if (this.definedColumnType == 0) {
/* 386 */       localNUMBER = super.getNUMBER(paramInt);
/*     */     }
/*     */     else {
/* 389 */       String str = getString(paramInt);
/* 390 */       if (str != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 399 */         return T4CVarcharAccessor.StringToNUMBER(str);
/*     */       }
/*     */     }
/*     */     
/* 403 */     return localNUMBER;
/*     */   }
/*     */   
/*     */ 
/*     */   DATE getDATE(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 410 */     DATE localDATE = null;
/*     */     
/* 412 */     if (this.definedColumnType == 0) {
/* 413 */       localDATE = super.getDATE(paramInt);
/*     */     }
/*     */     else {
/* 416 */       Date localDate = getDate(paramInt);
/* 417 */       if (localDate != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 426 */         localDATE = new DATE(localDate);
/*     */       }
/*     */     }
/*     */     
/* 430 */     return localDATE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   TIMESTAMP getTIMESTAMP(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 438 */     TIMESTAMP localTIMESTAMP = null;
/*     */     
/* 440 */     if (this.definedColumnType == 0) {
/* 441 */       localTIMESTAMP = super.getTIMESTAMP(paramInt);
/*     */     }
/*     */     else {
/* 444 */       String str = getString(paramInt);
/* 445 */       if (str != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 455 */         int[] arrayOfInt = new int[1];
/* 456 */         Calendar localCalendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*     */         
/*     */ 
/* 459 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/* 460 */         localTimestamp.setNanos(arrayOfInt[0]);
/* 461 */         localTIMESTAMP = new TIMESTAMP(localTimestamp);
/*     */       }
/*     */     }
/*     */     
/* 465 */     return localTIMESTAMP;
/*     */   }
/*     */   
/*     */ 
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 472 */     TIMESTAMPTZ localTIMESTAMPTZ = null;
/*     */     
/* 474 */     if (this.definedColumnType == 0) {
/* 475 */       localTIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt);
/*     */     }
/*     */     else {
/* 478 */       String str = getString(paramInt);
/* 479 */       if (str != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 490 */         int[] arrayOfInt = new int[1];
/* 491 */         Calendar localCalendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*     */         
/*     */ 
/* 494 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/* 495 */         localTimestamp.setNanos(arrayOfInt[0]);
/* 496 */         localTIMESTAMPTZ = new TIMESTAMPTZ(this.statement.connection, localTimestamp, localCalendar);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 502 */     return localTIMESTAMPTZ;
/*     */   }
/*     */   
/*     */ 
/*     */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 509 */     TIMESTAMPLTZ localTIMESTAMPLTZ = null;
/*     */     
/* 511 */     if (this.definedColumnType == 0) {
/* 512 */       localTIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt);
/*     */     }
/*     */     else {
/* 515 */       String str = getString(paramInt);
/* 516 */       if (str != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 527 */         int[] arrayOfInt = new int[1];
/* 528 */         Calendar localCalendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*     */         
/*     */ 
/* 531 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/* 532 */         localTimestamp.setNanos(arrayOfInt[0]);
/* 533 */         localTIMESTAMPLTZ = new TIMESTAMPLTZ(this.statement.connection, localTimestamp, localCalendar);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 539 */     return localTIMESTAMPLTZ;
/*     */   }
/*     */   
/*     */ 
/*     */   RAW getRAW(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 546 */     RAW localRAW = null;
/*     */     
/* 548 */     if (this.definedColumnType == 0) {
/* 549 */       localRAW = super.getRAW(paramInt);
/*     */     }
/*     */     else {
/* 552 */       if (this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 556 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 557 */         localSQLException.fillInStackTrace();
/* 558 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 564 */       if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*     */       {
/* 566 */         if ((this.definedColumnType == -2) || (this.definedColumnType == -3) || (this.definedColumnType == -4))
/*     */         {
/*     */ 
/* 569 */           localRAW = new RAW(getBytesFromHexChars(paramInt));
/*     */         } else {
/* 571 */           localRAW = new RAW(super.getBytes(paramInt));
/*     */         }
/*     */       }
/*     */     }
/* 575 */     return localRAW;
/*     */   }
/*     */   
/*     */ 
/*     */   Datum getOracleObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 582 */     if (this.definedColumnType == 0) {
/* 583 */       return super.getOracleObject(paramInt);
/*     */     }
/*     */     
/* 586 */     Datum localDatum = null;
/*     */     SQLException localSQLException;
/* 588 */     if (this.rowSpaceIndicator == null)
/*     */     {
/* 590 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 591 */       localSQLException.fillInStackTrace();
/* 592 */       throw localSQLException;
/*     */     }
/*     */     
/* 595 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*     */     {
/* 597 */       switch (this.definedColumnType)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       case -1: 
/*     */       case 1: 
/*     */       case 12: 
/* 606 */         return super.getOracleObject(paramInt);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       case -7: 
/*     */       case -6: 
/*     */       case -5: 
/*     */       case 2: 
/*     */       case 3: 
/*     */       case 4: 
/*     */       case 5: 
/*     */       case 6: 
/*     */       case 7: 
/*     */       case 8: 
/*     */       case 16: 
/* 629 */         return getNUMBER(paramInt);
/*     */       
/*     */       case 91: 
/* 632 */         return getDATE(paramInt);
/*     */       
/*     */       case 92: 
/* 635 */         return getDATE(paramInt);
/*     */       
/*     */       case 93: 
/* 638 */         return getTIMESTAMP(paramInt);
/*     */       
/*     */       case -101: 
/* 641 */         return getTIMESTAMPTZ(paramInt);
/*     */       
/*     */       case -102: 
/* 644 */         return getTIMESTAMPLTZ(paramInt);
/*     */       
/*     */ 
/*     */ 
/*     */       case -4: 
/*     */       case -3: 
/*     */       case -2: 
/* 651 */         return getRAW(paramInt);
/*     */       
/*     */       case -8: 
/* 654 */         return getROWID(paramInt);
/*     */       }
/*     */       
/*     */       
/* 658 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 659 */       localSQLException.fillInStackTrace();
/* 660 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 666 */     return localDatum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 675 */     if (this.definedColumnType == 0) {
/* 676 */       return super.getBytes(paramInt);
/*     */     }
/* 678 */     Datum localDatum = getOracleObject(paramInt);
/* 679 */     if (localDatum != null) {
/* 680 */       return localDatum.shareBytes();
/*     */     }
/* 682 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   boolean getBoolean(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 690 */     boolean bool = false;
/*     */     
/* 692 */     if (this.definedColumnType == 0) {
/* 693 */       bool = super.getBoolean(paramInt);
/*     */     }
/*     */     else {
/* 696 */       bool = getNUMBER(paramInt).booleanValue();
/*     */     }
/*     */     
/* 699 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   byte getByte(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 707 */     byte b = 0;
/*     */     
/* 709 */     if (this.definedColumnType == 0) {
/* 710 */       b = super.getByte(paramInt);
/*     */     }
/*     */     else {
/* 713 */       NUMBER localNUMBER = getNUMBER(paramInt);
/* 714 */       if (localNUMBER != null) {
/* 715 */         b = localNUMBER.byteValue();
/*     */       }
/*     */     }
/* 718 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getInt(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 726 */     int i = 0;
/*     */     
/* 728 */     if (this.definedColumnType == 0) {
/* 729 */       i = super.getInt(paramInt);
/*     */     }
/*     */     else {
/* 732 */       NUMBER localNUMBER = getNUMBER(paramInt);
/* 733 */       if (localNUMBER != null) {
/* 734 */         i = localNUMBER.intValue();
/*     */       }
/*     */     }
/* 737 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   short getShort(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 745 */     short s = 0;
/*     */     
/* 747 */     if (this.definedColumnType == 0) {
/* 748 */       s = super.getShort(paramInt);
/*     */     }
/*     */     else {
/* 751 */       NUMBER localNUMBER = getNUMBER(paramInt);
/* 752 */       if (localNUMBER != null) {
/* 753 */         s = localNUMBER.shortValue();
/*     */       }
/*     */     }
/* 756 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   long getLong(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 764 */     long l = 0L;
/*     */     
/* 766 */     if (this.definedColumnType == 0) {
/* 767 */       l = super.getLong(paramInt);
/*     */     }
/*     */     else {
/* 770 */       NUMBER localNUMBER = getNUMBER(paramInt);
/* 771 */       if (localNUMBER != null) {
/* 772 */         l = localNUMBER.longValue();
/*     */       }
/*     */     }
/* 775 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   float getFloat(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 783 */     float f = 0.0F;
/*     */     
/* 785 */     if (this.definedColumnType == 0) {
/* 786 */       f = super.getFloat(paramInt);
/*     */     }
/*     */     else {
/* 789 */       NUMBER localNUMBER = getNUMBER(paramInt);
/* 790 */       if (localNUMBER != null) {
/* 791 */         f = localNUMBER.floatValue();
/*     */       }
/*     */     }
/* 794 */     return f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   double getDouble(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 802 */     double d = 0.0D;
/*     */     
/* 804 */     if (this.definedColumnType == 0) {
/* 805 */       d = super.getDouble(paramInt);
/*     */     }
/*     */     else {
/* 808 */       NUMBER localNUMBER = getNUMBER(paramInt);
/* 809 */       if (localNUMBER != null) {
/* 810 */         d = localNUMBER.doubleValue();
/*     */       }
/*     */     }
/* 813 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Date getDate(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 823 */     Date localDate = null;
/*     */     
/* 825 */     if (this.definedColumnType == 0) {
/* 826 */       localDate = super.getDate(paramInt);
/*     */     }
/*     */     else {
/* 829 */       String str = getString(paramInt);
/* 830 */       if (str != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 839 */         int[] arrayOfInt = new int[1];
/*     */         
/* 841 */         localDate = new Date(T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 847 */     return localDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Timestamp getTimestamp(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 855 */     Timestamp localTimestamp = null;
/*     */     
/* 857 */     if (this.definedColumnType == 0) {
/* 858 */       localTimestamp = super.getTimestamp(paramInt);
/*     */     }
/*     */     else {
/* 861 */       String str = getString(paramInt);
/* 862 */       if (str != null)
/*     */       {
/* 864 */         int[] arrayOfInt = new int[1];
/* 865 */         Calendar localCalendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*     */         
/*     */ 
/* 868 */         localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/* 869 */         localTimestamp.setNanos(arrayOfInt[0]);
/*     */       }
/*     */     }
/*     */     
/* 873 */     return localTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Time getTime(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 881 */     Time localTime = null;
/*     */     
/* 883 */     if (this.definedColumnType == 0) {
/* 884 */       localTime = super.getTime(paramInt);
/*     */     }
/*     */     else {
/* 887 */       String str = getString(paramInt);
/* 888 */       if (str != null)
/*     */       {
/* 890 */         int[] arrayOfInt = new int[1];
/* 891 */         Calendar localCalendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*     */         
/*     */ 
/* 894 */         localTime = new Time(localCalendar.getTimeInMillis());
/*     */       }
/*     */     }
/*     */     
/* 898 */     return localTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 906 */     if (this.definedColumnType == 0) {
/* 907 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 910 */     Object localObject = null;
/*     */     SQLException localSQLException;
/* 912 */     if (this.rowSpaceIndicator == null)
/*     */     {
/* 914 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 915 */       localSQLException.fillInStackTrace();
/* 916 */       throw localSQLException;
/*     */     }
/*     */     
/* 919 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*     */     {
/* 921 */       switch (this.definedColumnType)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       case -1: 
/*     */       case 1: 
/*     */       case 12: 
/* 930 */         return getString(paramInt);
/*     */       
/*     */ 
/*     */       case 2: 
/*     */       case 3: 
/* 935 */         return getBigDecimal(paramInt);
/*     */       
/*     */       case 4: 
/* 938 */         return Integer.valueOf(getInt(paramInt));
/*     */       
/*     */       case -6: 
/* 941 */         return Byte.valueOf(getByte(paramInt));
/*     */       
/*     */       case 5: 
/* 944 */         return Short.valueOf(getShort(paramInt));
/*     */       
/*     */ 
/*     */       case -7: 
/*     */       case 16: 
/* 949 */         return Boolean.valueOf(getBoolean(paramInt));
/*     */       
/*     */       case -5: 
/* 952 */         return Long.valueOf(getLong(paramInt));
/*     */       
/*     */       case 7: 
/* 955 */         return Float.valueOf(getFloat(paramInt));
/*     */       
/*     */ 
/*     */       case 6: 
/*     */       case 8: 
/* 960 */         return Double.valueOf(getDouble(paramInt));
/*     */       
/*     */       case 91: 
/* 963 */         return getDate(paramInt);
/*     */       
/*     */       case 92: 
/* 966 */         return getTime(paramInt);
/*     */       
/*     */       case 93: 
/* 969 */         return getTimestamp(paramInt);
/*     */       
/*     */ 
/*     */ 
/*     */       case -4: 
/*     */       case -3: 
/*     */       case -2: 
/* 976 */         return getBytesFromHexChars(paramInt);
/*     */       }
/*     */       
/*     */       
/* 980 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 981 */       localSQLException.fillInStackTrace();
/* 982 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 988 */     return localObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 993 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/driver/ojdbc5.jar!/oracle/jdbc/driver/T4CCharAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */